#Important Decisions
default choice73a = False
default choice73b = False
default choice74a = False
default choice74b = False
default choice75a = False
default choice75b = False
default choice77a = False
default choice77b = False
default choice78a = False
default choice78b = False
default choice78c = False
default choice79a = False
default choice79b = False



# Start Episode 6
label ep6:

    $ renpy.movie_cutscene("videos/anger.ogv")

    scene ima1350 with dissolve
    play music "audio/foundletters.mp3"
    dp "Oh, honey, I'm glad you came over..."
    p "I'm gonna need your help, doc, I'm not in the right mind..."
    scene ima1351 with dissolve
    dp "We'll get there, [p], we'll get there."
    scene black with dissolve
    scene ima1352 with dissolve
    dp "Eli told me how much she meant to you..."
    p "My mom didn't know...\"I\" didn't know...how could I be so stupid? I did not see her...Day to day, I'm getting angrier at myself..."
    dp "Don't blame yourself, it wasn't your fault."
    p "It was, doc, I could've saved her...she did, for Christ's sake!"
    scene ima1353 with dissolve
    dp "Hold it right there, I've always told you to embrace all your feelings: happiness, sadness, anger...there's time for each of them in life...But this time you've been through a traumatic event..."
    dp "It's not gonna be easy, but remember: the mind controls the emotion. You're going to have to make an extra effort to control these thoughts..."
    dp "You can have them, of course, but do not let them overpower you. These could'ves, should'ves can take you to a place where you won't be able to come back from..."
    dp "I'm serious about this: let them win once and then fight them, that's your battle."
    scene ima1354 with dissolve
    p "That night's all I can think of...I just go over and over it all the time..."
    p "And it's different from what happened to my dad...the guilt makes it unbearable...makes me sad, makes me angry, drives me crazy..."
    p "Some years ago you told me: \"You're going to have to learn to live with an open wound. It's going to hurt for the rest of your life!\""
    scene ima1355 with dissolve
    dp "Did I really tell you that? I don't think so...you were...how old? Eleven? Twelve?"
    p "Probably not with those exact words, but that was what I kept in my head...And you were right, it still hurts, but hurts differently, you know, like a little cut, some discomfort more than sadness now..."
    p "But as I was saying...this time...is this guilt gonna last forever too, doc?"
    scene ima1353 with dissolve
    dp "Do not go that far, let's take small steps first, remember what your coping mechanism was when your dad just passed away?"
    p "Yeah, I needed to somehow have my father with me, it was so sudden, that's why I started wearing his favorite watch...never stopped actually...it's broken down now, but I like to wear it..."
    dp "Well, that worked for you. Now you can speak about it without crying...you know you can survive, you know you'll be ok..."
    p "Yes..."
    dp "Some people need to get rid of their loved ones' belongings because they suffer everytime they see their stuff; others, like you, need to keep something that reminds them of the person constantly..."
    p "Yeah, that was how I knew I was going to be ok, doc: one day I just looked at the watch and it didn't hurt anymore, well, at least not as much as it used to...I want to do the same!"
    scene ima1353a with dissolve
    dp "You, sir, are a little masochist, let me tell you..."
    p "Ha, and you're the realest, doc."
    dp "I know...it's good to see you smile..."
    scene ima1356 with dissolve
    dp "Very well then, find something that brings to your mind a happy moment with her. When these thoughts of the tragedy come to your head, look at the object and force your mind to go to that happy memory."
    dp "Come on now, let's go for a walk, honey, you need to release stress, ease your tension a little bit..."
    p "All right, doc, let's go."
    stop music fadeout 2
    scene black with Dissolve(2)
    scene ima1357 with dissolve
    play sound "audio/streetsound.ogg"
    dp "You know you can call me Amanda, right?"
    p "Can I?"
    ama "Of course, Franz already does."
    p "I like \"doc\", but ok...and how are YOU doing, Amanda?"
    ama "Good, everything's good...I'm going to London next week, but I'll be back in a couple of weeks for our next session..."
    scene ima1358 with dissolve
    ama "Hold on, are you going to be ok?"
    p "Yes, Amanda, it's only a couple of weeks, you don't have to wo..."
    pt "Huh? Wait a minute, that stupid hat..."
    scene ima1359 with dissolve
    pt "Is that...? No way...I don't want to believe it's Brenda...can't really tell from this angle, but that woman definitely looks like her..."
    scene ima1360 with dissolve
    p "Amanda, I'm so sorry, I just remember I had to be somewhere else by now...I'm really sorry, but I gotta go!"
    scene ima1361 with dissolve
    ama "It's all right, honey, text me later when you get home, ok?"
    p "Sure, see you in two weeks...enjoy your trip!"
    ama "Thanks, honey!"
    stop sound fadeout 1.0
    scene black with dissolve
    play music "audio/russian2.mp3"
    scene ima1363 with dissolve
    pt "Time to find out what's going on here...I'm pretty sure it's them, but...ok, they could still be friends...right? Didn't see a kiss...yet."
    pt "I hate that motherfucker, he failed me for no reason...and then quit! What a pussy! Wait, did he quit to be with her? To avoid trouble if I had opened my mouth?"
    pt "Makes sense...you better pray I'm wrong..."
    scene ima1362 with dissolve
    pt "The fuck? They're holding hands now? This's looking bad for you two..."
    pt "But where are they going?"

if choice62a:
    pt "Uhmmm, the hotel I went to with Valentina is around the corner...I'm getting so mad, but...damn, I did the same fucking thing..."
    jump continuebrenda

label continuebrenda:
    scene ima1364 with dissolve
    pause
    scene ima1365 with dissolve
    pt "Hell no! They're not going in!"
    scene ima1366 with dissolve
    stop music
    play sound "audio/djstop.mp3"
    p "Hey, Anderson!"
    scene ima1367 with dissolve
    scene ima1368 with dissolve
    p "That's right, bitch."
    ma "Huh?"
    p "Small world, isn't it?"
    scene ima1369 with dissolve
    p "You son of a bitch!"
    play sound "audio/punchslowmo.ogg"
    scene ima1370 with Dissolve(0.0666)
    scene ima1371 with Dissolve(0.0666)
    scene ima1372 with Dissolve(0.0666)
    scene ima1373 with Dissolve(0.0666)
    scene ima1374 with Dissolve(0.0666)
    scene ima1375 with Dissolve(0.0666)
    scene ima1376 with Dissolve(0.0666)
    scene ima1377 with Dissolve(0.0666)
    scene ima1378 with Dissolve(0.0666)
    scene ima1379 with Dissolve(0.0666)
    scene ima1380 with Dissolve(0.311)
    scene ima1381 with Dissolve(0.311)
    pause 2.2
    scene ima1381 with Dissolve(0.0555)
    scene ima1380 with Dissolve(0.0555)
    scene ima1379 with Dissolve(0.0555)
    scene ima1378 with Dissolve(0.0555)
    scene ima1377 with Dissolve(0.0555)
    scene ima1376 with Dissolve(0.0555)
    scene ima1375 with Dissolve(0.0555)
    scene ima1374 with Dissolve(0.0555)
    scene ima1373 with Dissolve(0.0555)
    scene ima1372 with Dissolve(0.0555)
    scene ima1371 with Dissolve(0.0555)
    scene ima1370 with Dissolve(0.0555)
    pause

    scene ima1370:
        pause 0.0333
        "ima1371"
        pause 0.0333
        "ima1372"
        pause 0.0333
        "ima1373"
        pause 0.0333
        "ima1374"
        pause 0.0333
        "ima1375"
        pause 0.0333
        "ima1376"
        pause 0.0333
        "ima1377"
        pause 0.0333
        "ima1378"
        pause 0.0333
        "ima1379"
        pause 0.0333
        "ima1380"
        pause 0.0333
        "ima1381"
        pause 0.0333
    play sound "audio/punchko.ogg"
    pause 0.3996
    scene ima1381 with hpunch
    scene ima1381 with hpunch
    scene ima1382 with dissolve
    pt "Holy shit!! I put him to sleep!! That felt..."
    play music "audio/gettingdirty.ogg" volume 0.7
    pt "AWESOME!!!"


menu:
    "Kick him!":
        jump choice73a

    "He's already K.O.":
        jump choice73b

label choice73a:
    scene ima1383 with dissolve
    pt "This bitch failed me!"
    scene ima1384 with dissolve
    p "And this is for failing me, you fucking piece of shit!"
    play sound "audio/kick.ogg"
    scene ima1385a with hpunch
    scene ima1385a with hpunch
    scene ima1385
    p "I did everything..."
    br "Oh my God!"
    scene ima1386 with dissolve
    p "...you..."
    br "Wait! What are you..."
    play sound "audio/kick.ogg"
    scene ima1387a with hpunch
    scene ima1387a with hpunch
    scene ima1387
    p "...asked for, bitch!"
    br "Oh God!"

menu:
    "Enough.":
        jump choice74a

    "Lo0OoOs55seeE~iItTtTT!!!":
        jump choice74b

label choice74a:
    scene ima1388 with dissolve
    p "And you...you're a fucking liar! Fuck you!"
    scene ima1389 with dissolve
    pause 1
    jump talkbrenda

label choice74b:

    $ choice74b = True

    pt "I've been wanting to do this for a long time...no way I'm stopping now!"
    scene ima1383 with dissolve
    pt "He's not moving..."
    br "What did you do?!"
    scene ima1388 with dissolve
    p "Shut up, just shut up, you lying bitch!"
    scene ima1386 with dissolve
    br "No, not again..."
    play sound "audio/kick.ogg"
    scene ima1387a with hpunch
    scene ima1387a with hpunch
    scene ima1387
    p "Take that, son of a bitch! You like to cheat, huh?!"
    scene ima1390 with dissolve
    br "Noo! Don't! You may..."
    play sound "audio/bonecrack.ogg"
    scene ima1391a with vpunch
    scene ima1391a with vpunch
    scene ima1391
    br "Noooo!!"
    p "Cheat now, you fucking cunt..."
    scene ima1392 with dissolve
    of "Hey, you there! Freeze!"
    stop music fadeout 3
    scene black with Dissolve(3)
    pause
    play music "audio/darkside.mp3" fadein 3
    scene ima1393 with Dissolve(3)
    pause
    scene ima1394 with dissolve
    pause 1
    scene ima1395 with dissolve
    of "You're free to go."
    scene black with dissolve
    scene ima1396 with dissolve
    pt "Franz and...The Sheriff? What's he doing here? I thought he'd moved..."
    scene ima1397 with dissolve
    fz "How are your hands?"
    p "Fine."
    fz "Yeah?"
    she "Anderson's not pressing any charges, kid, even though you broke his noise..."
    p "I did?"
    fz "You don't remember doing it?"
    p "No...maybe when I stomped on his head..."
    scene ima1398 with dissolve
    she "Hahaha, I knew you were crazy since the day I saw you walking towards a loaded gun!"
    p "I wasn't thinking when I did it to be honest."
    she "That's why I said \"crazy\", not brave."
    scene ima1399 with dissolve
    fz "Come on, let's go home, brother."
    scene ima1400 with dissolve
    p "And how do you know each other?"
    she "I was just here for some paperwork and saw Anderson and your brother arguing...couldn't avoid asking what happened..."
    fz "William here told me you helped his son not long ago and wanted to pay you back somehow: he talked with your teacher, that's why you're not getting charged..."
    p "Oh, really? Thank you, Sheriff...William, right? Billy, William, makes sense...anyway, thank you again."
    she "We're cool, I owed you one and we're even now."
    scene black with Dissolve(2)
    scene ima1401 with dissolve
    fz "How are you, brother?"
    p "Sad...angry...sad most of the times...Franz, I wanted to ask you something..."
    fz "What is it?"
    p "Uuhmmm...do you have any enemies?"
    fz "Enemies? Not that I know of...why you ask?"
    p "It's just that I'm starting to remember things about that night...I think the killer said my name just before he pulled the trigger...or my last name..."
    scene ima1402 with dissolve
    p "Or perhaps nothing at all and it's just my mind playing tricks on me, trying to protect myself..."
    p "Fuck, brother, I can't deal with this guilt...I'm sure he was coming after me, but why? I haven't harmed anybody to wish me dead..."
    fz "Hey, hey, listen..."
    scene ima1403 with dissolve
    fz "You gotta stop blaming yourself, you didn't pull the trigger, you didn't kill her...evil exists, crazy exists...bad people do bad things and they need no reason, they just want to..."
    fz "You'll go crazy if you keep asking yourself \"why\" it happened...it just did...cry, suffer, and then you gotta focus on getting back on your feet..."
    fz "Go out with your friends, train, play soccer, talk to me, to mom, to Amanda...paint! You painted a lot when dad passed away or..."
    fz "Kick somebody's ass if you need to..."
    p "..."
    p "Franz...thank you, you've always had my back..."
    scene ima1404 with dissolve
    fz "I got you, little brother...you know, I can teach you some kickboxing moves if you feel like it..."
    p "I don't know...if I'm going to break my leg again, I'd rather do it playing football..."
    fz "Hehe, yeah, that's your thing, pursue that dream! Go get some sleep now, you need it..."
    p "Talk to you soon, brother."
    fz "Yeah...love you."
    p "I know."
    stop music fadeout 3

    jump talkbrenda

label choice73b:
    scene ima1388 with dissolve
    p "And you...you're a fucking liar! Fuck you!"
    scene ima1389 with dissolve
    pause 1
    jump talkbrenda

label talkbrenda:
    scene black with Dissolve(3)
    scene ima1405 with dissolve
    pt "I'm exhausted..."
    play music "audio/russian5.mp3"


if choice74b:
    pt "Man, I went crazy today, I didn't know I had it in me...could've gotten into so much trouble...I bet Sheriff threatened Anderson or something, I got off too easy..."
    jump talkbrenda1

label talkbrenda1:
    pt "I can't believe Brenda lied to me...I mean...she'd already lied to her husband, why was I expecting something different?"
    pt "I guess I just wanted to give her a chance because I had this mental image of her as this sweet, innocent, kind lady, but I was blind..."
    pt "So was Samantha: I'm sure that to her I was ten times better than what I really am...I not only lied...I was a lie!"
    pt "Can't even look at our pictures without feeling ashamed..."
    play sound "audio/knock.ogg"
    mm "Son, are you awake?"
    mm "Brenda's here, she wants to know how you're doing..."
    pt "What?! What's she doing here? She should be talking to her family...I'm done with her..."
    scene ima1406 with dissolve
    p "Tell her I'm tired, mom..."
    scene ima1405 with dissolve
    br "[p], can I talk with you for a minute?"
    p "..."
    scene ima1406 with dissolve
    p "Fine."
    scene black with dissolve
    scene ima1407 with dissolve
    p "What do you want, Brenda? I have nothing to say to you."
    br "But I do, I feel so terrible for lying to you..."
    p "No, you don't. You don't feel bad for lying to ME, or anyone for that matter, you feel bad 'cause I caught you lying, there's a big difference..."
    p "Do you feel bad when you lie? No. You feel bad because you got caught, period."
    scene ima1408 with dissolve
    p "And just to let you know, I'm telling Daniel first thing in the morning...you should be home telling them yourself instead of being here trying to talk me out of it..."
    br "That's not what I came here for..."
    scene ima1409 with dissolve
    p "No?"
    scene ima1410 with dissolve
    br "No..."
    scene ima1411 with dissolve
    p "Then why you're here?"
    scene ima1413 with dissolve
    br "It's about what you did to Paul..."
    p "I don't regret it, I'd do it again."
    br "That's exactly what I wanted to know...why? Why would you do it again?"
    p "Why? I don't know...I just hated to see you with him...again."
    scene ima1412 with dissolve
    br "Yeah, but what was going through your mind when you did it? Were you thinking about Paul, Daniel, Juan...me?"
    scene ima1411 with dissolve
    pause
    scene ima1412 with dissolve
    p "Mmm...probably, everyone...all I know is that I was not going to let him touch you...again...so when I saw you two going straight to the hotel, I just lost it..."
    scene ima1414 with dissolve
    br "I'd never seen anyone act like that...I wasn't expecting you to be the one I'd see act so violently..."
    p "Me, neither...and I'm not violent, Brenda, I've just been so angry lately, you know what I'm dealing with right now..."
    scene ima1415 with dissolve
    br "I know and I'm just adding more problems to your life...I'm so sorry..."
    scene ima1416 with dissolve
    p "If you really are, take some weight off my shoulders, go tell your family yourself tonight...don't make me do it, it's simply not fair."
    scene ima1417 with dissolve
    pause
    scene ima1418 with dissolve
    stop music
    play sound "audio/scratch.ogg"
    pt "Whoops..."
    scene ima1419 with dissolve
    play music "audio/youmakemeso.mp3"
    br "You know I have my own theory about why you punched Paul."
    p "Which is..."
    br "Jealousy."
    p "Jealousy? Elaborate..."
    br "Ok, I will if you promise to tell me the truth and only the truth."
    p "From now on, truth's the only language I'll speak."
    scene ima1420 with dissolve
    br "You said you hated the idea of him touching me, your words not mine, so, in my opinion, you were jealous of him because he was the one who got to do it, he was the one who touched my body: you wanted to be him."
    br "Am I right?"
    pt "Fuck it, I have nothing to lose...or I simply don't care about anything anymore..."
    scene ima1421 with dissolve
    p "I'm gonna say yes, you're right: I would love to touch your body, but you being my best friend's mom complicates things...and there's Juan too, you know, he's always been good to me."
    scene ima1422 with dissolve
    br "I love your honesty, [p], that's what I need in my life...someone real! I could easily fall in love with you..."
    p "If I were older?"
    br "No, no ifs..."
    scene ima1423 with dissolve
    br "You know, too many ifs may paralize you, they keep you from doing, from living!"
    scene ima1424 with dissolve
    br "Sometimes I feel you think just a little too much about what-if this, what-if that..."
    scene ima1423 with dissolve
    br "Instead of a \"what-if\" thinking, I have a \"why-not\" mindset, you should try it every now and then!"
    pt "That's why you get yourself into so much trouble..."
    scene ima1425 with dissolve
    br "And there's this other thing about you that intrigues me...I don't know if this whole decent guy is what you really are like or it's just a facade..."
    br "\"Oooh, you should tell your family.\" \"I can't believe you're cheating.\""
    br "I bet that given the right stimulus you'd be just like any other men..."
    scene ima1426 with dissolve
    br "Uhmmm, it was kind of hot seeing you punch Paul...you looked so strong, so manly..."
    br "And the way you look at my tits..."
    p "Nope, I'm not buying it..."
    scene ima1427 with dissolve
    br "I'm not playing with you, [p]...I'd really like to see this other side of you..."
    scene ima1428 with vpunch
    p "Damn!!!"
    br "Do you want to touch it?"
    pt "I want to touch it, pinch it, suck it, bite it..."
    p "Where are you going with this?"
    br "I don't know...where do you want to take it?"
    p "Errr..."
    scene ima1427a with dissolve
    br "And...that's enough."
    p "Whaaaat..."
    scene ima1423 with dissolve
    br "Haha, [p], you didn't really think we were going to do something, did you?"
    p "I'm pretty positive we were..."
    scene ima1433 with dissolve
    br "Hehehe, you're funny..."
    scene ima1434 with dissolve
    p "Not trying to be."
    scene ima1435 with dissolve
    br "Mmmm..."
    scene ima1436 with dissolve
    br "Listen, I gotta go now, but I'll give you this: Juan's taking Daniel fishing for a couple of days, you know, their usual vacation plan...perhaps, you'd like to join them..."
    p "Riiight...when are they leaving?"
    br "Tomorrow morning...you do whatever you want with that info...sleep well if you go visit me..."
    scene black with Dissolve(1)
    scene ima1437 with dissolve
    pt "Holy shit, what just happened? She's up to something, I don't trust her for a second, I already did it once and she let me down...lesson learned!"
    pt "But man, those tits...that nipple looked so tasty...imagine her pussy..."
    pt "Wait...is she looking for someone to replace Anderson? Is she thinking of me? That would be perfect for her: I won't open my mouth and she gets someone to fuck her! What a clever bitch!"
    pt "It sounds very exciting, not gonna lie, but at the same time I don't wanna be trapped in a web of lies...what if...no, no, like she said, maybe I should drop the what-ifs and start with the why-nots..."
    pt "I don't know, man, she's Metal's mom...what I do know is that, at least tonight, I won't be crying, she gave me something else to keep my mind busy..."
    stop music fadeout 3
    scene black with Dissolve(3)

label brendasex1:

    if _in_replay:
        $ pf = persistent.p

    scene ima1438 with dissolve
    play music "audio/sensual15.mp3"
    pause
    scene ima1439 with dissolve
    pause
    scene ima1440 with dissolve
    pause
    scene ima1441 with dissolve
    br "I'm so naughty..."
    scene ima1442 with dissolve
    br "I bet he can totally bust through that door with a simple kick...and how he treated me yesterday, he was so pissed off...got me so turned on!"
    scene ima1443 with dissolve
    br "Brenda, behave! Stop being kinky! Hehehe."
    scene ima1444 with dissolve
    br "Lalala..."
    scene ima1445 with dissolve
    pause
    scene ima1446 with dissolve
    pause
    play sound "audio/bell.mp3"
    scene ima1446 with dissolve
    scene ima1447 with dissolve
    br "Huh?"
    scene ima1448 with dissolve
    br "Who is it?"
    p "It's me, [p]!"
    br "What?! I just sent you a message..."
    p "Yeah, to come by noon, but I was on my way here already."
    br "But I'm not ready!"
    p "Come on, Brenda, it's really hot outside!"
    scene ima1449 with dissolve
    br "I was not expecting you so early..."
    pt "My God! She's so beautiful!"
    scene ima1450 with hpunch
    pt "Daaaaammnnn! She opened the door wearing that? Yes! She wants me to fuck her! I'm not gonna waste any minute!"
    scene ima1451 with dissolve
    br "What are you doing?"
    p "What you want me to."
    scene ima1452 with dissolve
    scene ima1453 with dissolve
    pause
    scene ima1454 with dissolve
    p "Your lips are so delicate, Brenda..."
    br "Close the door! Someone can see us!"
    p "I want everybody to see us."
    br "No, you don't...please?"
    p "Only because you said please."
    scene black with dissolve
    scene ima1456 with dissolve
    br "Ok, now you can show me how rough you really are!"
    scene ima1457 with dissolve
    br "Oooh, my baby!"
    scene ima1458 with dissolve
    br "[p], I don't think I can do this...you're my Daniel's best friend..."
    stop music fadeout 3

menu:
    "Fuck Metal!":
        jump choice75a

    "You sure?":
        jump choice75b

label choice75a:

    $ choice75a = True

    p "And?"
    br "Don't you feel guilty?"
    p "I'm done feeling that way...let me show you how guilty I feel..."
    scene ima1459 with dissolve
    br "What do you mean?"
    p "I want you, Brenda, I don't care about anything else."
    play music "audio/needyoutonight.mp3" volume 0.8
    scene ima1464 with dissolve
    scene ima1465 with dissolve
    play sound "audio/glasscrunch.ogg"
    scene ima1466 with hpunch
    br "Aaahh! What are you doing?!"
    p "Showing you how much I want this, and don't lie to yourself, you want it, too..."
    br "What?"
    scene ima1467 with dissolve
    p "Yeah, a wet pussy doesn't lie, my fingers went in so easily...you're ready to be penetrated, aren't you?"
    scene ima1468 with dissolve
    p "And I could swear you've been eyeballing me too, haven't you?"
    p "I'm only gonna ask once, you decide: Do you want to feel my dick inside of you?"
    scene ima1469 with dissolve
    scene ima1470 with dissolve
    scene ima1469 with dissolve
    scene ima1470 with dissolve
    scene ima1469 with dissolve
    pause
    scene ima1471 with dissolve
    p "Good girl..."
    scene black with dissolve
    scene ima1472 with dissolve
    p "Yeah, I love feeling your pubes on my cock, Brenda..."
    br "Oohh, you're dirty! I'm loving this..."
    p "You feel how hard you make me?"
    br "I do..."
    scene ima1473 with dissolve
    br "You're a breath of fresh air, [p]..."
    scene ima1474 with vpunch
    p "Shut up, you're a liar!"
    scene ima1473 with dissolve
    br "I'm not lying this time..."
    scene ima1475 with dissolve
    p "I don't believe you anyways..."
    scene ima1476 with hpunch
    br "Aaahh!"
    p "Yeah, take this off, I want to feel that pussy of yours..."
    scene black with dissolve
    scene ima1477 with dissolve

    scene ima1477:
        pause 0.0333
        "ima1478"
        pause 0.0333
        "ima1479"
        pause 0.0333
        "ima1480"
        pause 0.0333
        "ima1481"
        pause 0.0333
        "ima1482"
        pause 0.0333
        "ima1483"
        pause 0.0333
        "ima1484"
        pause 0.0333
        "ima1485"
        pause 0.0333
        "ima1486"
        pause 0.0333
        "ima1487"
        pause 0.0333
        "ima1488"
        pause 0.0333
        "ima1489"
        pause 0.0333
        "ima1490"
        pause 0.0333
        "ima1491"
        pause 0.0333
        "ima1492"
        pause 0.0333
        "ima1493"
        pause 0.0333
        "ima1494"
        pause 0.0333
        "ima1495"
        pause 0.0333
        "ima1496"
        pause 0.0333
        "ima1497"
        pause 0.0333
        "ima1498"
        pause 0.0333
        "ima1499"
        pause 0.0333
        "ima1500"
        pause 0.0333
        "ima1501"
        pause 0.0333
        "ima1502"
        pause 0.0333
        "ima1503"
        pause 0.0333
        "ima1504"
        pause 0.0333
        "ima1505"
        pause 0.0333
        "ima1506"
        pause 0.0333
        repeat
    pause

    p "Shit, just like I imagined it..."

    scene ima1477:
        pause 0.0222
        "ima1478"
        pause 0.0222
        "ima1479"
        pause 0.0222
        "ima1480"
        pause 0.0222
        "ima1481"
        pause 0.0222
        "ima1482"
        pause 0.0222
        "ima1483"
        pause 0.0222
        "ima1484"
        pause 0.0222
        "ima1485"
        pause 0.0222
        "ima1486"
        pause 0.0222
        "ima1487"
        pause 0.0222
        "ima1488"
        pause 0.0222
        "ima1489"
        pause 0.0222
        "ima1490"
        pause 0.0222
        "ima1491"
        pause 0.0222
        "ima1492"
        pause 0.0222
        "ima1493"
        pause 0.0222
        "ima1494"
        pause 0.0222
        "ima1495"
        pause 0.0222
        "ima1496"
        pause 0.0222
        "ima1497"
        pause 0.0222
        "ima1498"
        pause 0.0222
        "ima1499"
        pause 0.0222
        "ima1500"
        pause 0.0222
        "ima1501"
        pause 0.0222
        "ima1502"
        pause 0.0222
        "ima1503"
        pause 0.0222
        "ima1504"
        pause 0.0222
        "ima1505"
        pause 0.0222
        "ima1506"
        pause 0.0222
        repeat
    pause
    br "Oh, [p], I'm so close..."
    p "So soon?"
    br "You got me so wet yesterday, I couldn't stop thinking about this, it's your fault!"
    br "Oh, baby, I'm gonna cum all over your cock!"
    p "Cum, cum on my dick..."

    play sound "audio/femorg5.ogg"
    scene ima1507 with hpunch
    scene ima1507 with hpunch
    p "Yeah..."
    stop music fadeout 3
    scene ima1508 with dissolve
    p "Show me the way to your room, this's just the beginning..."
    stop sound
    scene black with Dissolve(1)
    scene ima1509 with dissolve
    play music "audio/barsong.mp3"
    br "This's where I sleep with my husband, [p]..."
    p "Why are you trying to cover your pussy while saying that?"
    br "Doesn't it turn you on?"
    p "It does..."
    scene ima1509a with dissolve
    p "And here I thought you were the sweetest woman ever..."
    br "I can be sweet..."
    p "And cold."
    br "I'm not cold, I'm hot as fuck...your words..."
    scene ima1509b with dissolve
    br "Hehe, I like how we understand each other...get closer..."
    scene black with dissolve
    scene ima1538 with dissolve
    p "Oh, fuck! I fit perfectly in you, Brenda!"
    scene ima1539 with dissolve
    br "Yes, honey, my pussy's been made for your cock...we're a perfect match!"
    p "I won't argue that!"
    play sound "audio/ahhfemale1.ogg"
    scene ima1540 with hpunch
    pause
    scene ima1539 with dissolve
    br "Do it again, baby!"
    play sound "audio/ahhfemaleloud.ogg"
    scene ima1540 with hpunch
    scene ima1540 with hpunch
    pause

    scene ima1510 with dissolve
    play sound "audio/sex5.mp3"

    scene ima1510:
        pause 0.0222
        "ima1511"
        pause 0.0222
        "ima1512"
        pause 0.0222
        "ima1513"
        pause 0.0222
        "ima1514"
        pause 0.0222
        "ima1515"
        pause 0.0222
        "ima1516"
        pause 0.0222
        "ima1517"
        pause 0.0222
        "ima1518"
        pause 0.0222
        "ima1519"
        pause 0.0222
        "ima1520"
        pause 0.0222
        "ima1521"
        pause 0.0222
        "ima1522"
        pause 0.0222
        "ima1523"
        pause 0.0222
        "ima1524"
        pause 0.0222
        "ima1525"
        pause 0.0222
        "ima1526"
        pause 0.0222
        "ima1527"
        pause 0.0222
        "ima1528"
        pause 0.0222
        "ima1529"
        pause 0.0222
        "ima1530"
        pause 0.0222
        "ima1531"
        pause 0.0222
        "ima1532"
        pause 0.0222
        "ima1533"
        pause 0.0222
        "ima1534"
        pause 0.0222
        "ima1535"
        pause 0.0222
        "ima1536"
        pause 0.0222
        "ima1537"
        pause 0.0222
        repeat
    pause
    p "Holy shit, this feels amazing!"
    br "Faster, baby, cum in me! Fuck my pussy!"
    p "Yes, I'll give it all to you!"

    play sound "audio/sex5.mp3"
    scene ima1510:
        pause 0.0166
        "ima1511"
        pause 0.0166
        "ima1512"
        pause 0.0166
        "ima1513"
        pause 0.0166
        "ima1514"
        pause 0.0166
        "ima1515"
        pause 0.0166
        "ima1516"
        pause 0.0166
        "ima1517"
        pause 0.0166
        "ima1518"
        pause 0.0166
        "ima1519"
        pause 0.0166
        "ima1520"
        pause 0.0166
        "ima1521"
        pause 0.0166
        "ima1522"
        pause 0.0166
        "ima1523"
        pause 0.0166
        "ima1524"
        pause 0.0166
        "ima1525"
        pause 0.0166
        "ima1526"
        pause 0.0166
        "ima1527"
        pause 0.0166
        "ima1528"
        pause 0.0166
        "ima1529"
        pause 0.0166
        "ima1530"
        pause 0.0166
        "ima1531"
        pause 0.0166
        "ima1532"
        pause 0.0166
        "ima1533"
        pause 0.0166
        "ima1534"
        pause 0.0166
        "ima1535"
        pause 0.0166
        "ima1536"
        pause 0.0166
        "ima1537"
        pause 0.0166
        repeat
    pause

    play sound "audio/maleorg1.ogg"
    scene ima1573 with vpunch
    scene ima1573 with vpunch
    scene ima1573 with flash
    pause 1
    play sound "audio/maleorg3.ogg"
    scene ima1572 with vpunch
    scene ima1572 with vpunch
    scene ima1572 with flash
    p "Fuuuuck!!!"
    scene black with Dissolve(1.5)

    scene ima1541 with dissolve
    p "Oh, no, you're not going anywhere, come here!"
    br "Haha, I just wanted to clean myself."
    p "It can wait!"

    scene ima1542 with dissolve
    play sound "audio/sex10.mp3"

    scene ima1542:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0199
        "ima1543"
        pause 0.0199
        "ima1544"
        pause 0.0199
        "ima1545"
        pause 0.0199
        "ima1546"
        pause 0.0199
        "ima1547"
        pause 0.0199
        "ima1548"
        pause 0.0199
        "ima1549"
        pause 0.0199
        "ima1550"
        pause 0.0199
        "ima1551"
        pause 0.0199
        "ima1552"
        pause 0.0199
        "ima1553"
        pause 0.0199
        "ima1554"
        pause 0.0199
        "ima1555"
        pause 0.0199
        "ima1556"
        pause 0.0199
        "ima1557"
        pause 0.0199
        "ima1558"
        pause 0.0199
        "ima1559"
        pause 0.0199
        "ima1560"
        pause 0.0199
        "ima1561"
        pause 0.0199
        "ima1562"
        pause 0.0199
        "ima1563"
        pause 0.0199
        "ima1564"
        pause 0.0199
        "ima1565"
        pause 0.0199
        "ima1566"
        pause 0.0199
        "ima1567"
        pause 0.0199
        "ima1568"
        pause 0.0199
        "ima1569"
        pause 0.0199
        "ima1570"
        pause 0.0199
        "ima1571"
        pause 0.0199
        repeat
    pause

    play sound "audio/sex10.mp3"
    scene ima1542:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0166
        "ima1543"
        pause 0.0166
        "ima1544"
        pause 0.0166
        "ima1545"
        pause 0.0166
        "ima1546"
        pause 0.0166
        "ima1547"
        pause 0.0166
        "ima1548"
        pause 0.0166
        "ima1549"
        pause 0.0166
        "ima1550"
        pause 0.0166
        "ima1551"
        pause 0.0166
        "ima1552"
        pause 0.0166
        "ima1553"
        pause 0.0166
        "ima1554"
        pause 0.0166
        "ima1555"
        pause 0.0166
        "ima1556"
        pause 0.0166
        "ima1557"
        pause 0.0166
        "ima1558"
        pause 0.0166
        "ima1559"
        pause 0.0166
        "ima1560"
        pause 0.0166
        "ima1561"
        pause 0.0166
        "ima1562"
        pause 0.0166
        "ima1563"
        pause 0.0166
        "ima1564"
        pause 0.0166
        "ima1565"
        pause 0.0166
        "ima1566"
        pause 0.0166
        "ima1567"
        pause 0.0166
        "ima1568"
        pause 0.0166
        "ima1569"
        pause 0.0166
        "ima1570"
        pause 0.0166
        "ima1571"
        pause 0.0166
        repeat
    pause
    br "Oh, yeah, baby, it's so deep..."

    play sound "audio/sex10.mp3"
    scene ima1542:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0166
        "ima1543"
        pause 0.0166
        "ima1544"
        pause 0.0166
        "ima1545"
        pause 0.0166
        "ima1546"
        pause 0.0166
        "ima1547"
        pause 0.0166
        "ima1548"
        pause 0.0166
        "ima1549"
        pause 0.0166
        "ima1550"
        pause 0.0166
        "ima1551"
        pause 0.0166
        "ima1552"
        pause 0.0166
        "ima1553"
        pause 0.0166
        "ima1554"
        pause 0.0166
        "ima1555"
        pause 0.0166
        "ima1556"
        pause 0.0166
        "ima1557"
        pause 0.0166
        "ima1558"
        pause 0.0166
        "ima1559"
        pause 0.0166
        "ima1560"
        pause 0.0166
        "ima1561"
        pause 0.0166
        "ima1562"
        pause 0.0166
        "ima1563"
        pause 0.0166
        "ima1564"
        pause 0.0166
        "ima1566"
        pause 0.0166
        "ima1568"
        pause 0.0166
        "ima1570"
        pause 0.0166
        repeat
    pause

    play sound "audio/sex10.mp3"
    scene ima1542:
        xpos 0.7 ypos 0.5 xanchor 0.5 yanchor 0.5 zoom 1.5
        pause 0.0166
        "ima1543"
        pause 0.0166
        "ima1544"
        pause 0.0166
        "ima1545"
        pause 0.0166
        "ima1546"
        pause 0.0166
        "ima1547"
        pause 0.0166
        "ima1548"
        pause 0.0166
        "ima1549"
        pause 0.0166
        "ima1550"
        pause 0.0166
        "ima1551"
        pause 0.0166
        "ima1552"
        pause 0.0166
        "ima1553"
        pause 0.0166
        "ima1554"
        pause 0.0166
        "ima1555"
        pause 0.0166
        "ima1556"
        pause 0.0166
        "ima1557"
        pause 0.0166
        "ima1558"
        pause 0.0166
        "ima1559"
        pause 0.0166
        "ima1560"
        pause 0.0166
        "ima1561"
        pause 0.0166
        "ima1562"
        pause 0.0166
        "ima1563"
        pause 0.0166
        "ima1564"
        pause 0.0166
        "ima1566"
        pause 0.0166
        "ima1568"
        pause 0.0166
        "ima1570"
        pause 0.0166
        repeat
    pause
    p "Fuck! This ass!"
    p "It's asking me to come on it!"
    br "Oh, my God!"
    p "Don't you ever lie to me again! You hear me?!"
    br "I won't, baby!"

    play sound "audio/sex10.mp3"
    scene ima1542:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0166
        "ima1543"
        pause 0.0166
        "ima1544"
        pause 0.0166
        "ima1545"
        pause 0.0166
        "ima1546"
        pause 0.0166
        "ima1547"
        pause 0.0166
        "ima1548"
        pause 0.0166
        "ima1549"
        pause 0.0166
        "ima1550"
        pause 0.0166
        "ima1551"
        pause 0.0166
        "ima1552"
        pause 0.0166
        "ima1553"
        pause 0.0166
        "ima1554"
        pause 0.0166
        "ima1555"
        pause 0.0166
        "ima1556"
        pause 0.0166
        "ima1557"
        pause 0.0166
        "ima1558"
        pause 0.0166
        "ima1559"
        pause 0.0166
        "ima1560"
        pause 0.0166
        "ima1561"
        pause 0.0166
        "ima1562"
        pause 0.0166
        "ima1563"
        pause 0.0166
        "ima1564"
        pause 0.0166
        "ima1566"
        pause 0.0166
        "ima1568"
        pause 0.0166
        "ima1570"
        pause 0.0166
        repeat

    p "You can lie to your husband all you want, but not to me!"
    br "I won't, I won't..."
    br "Oh, God, I'm cumming again!"
    p "Yeah, I'm close too..."
    br "It's too hard!"
    p "Take it! Almost there!"
    stop music fadeout 3
    play sound "audio/maleorg4.ogg"
    scene ima1574 with dissolve
    play sound "audio/cumload.mp3"
    scene ima1574 with flash
    scene ima1574 with dissolve
    play sound "audio/cumload.mp3"
    scene ima1574 with flash
    scene ima1576 with dissolve
    p "Wooow!!!"
    scene ima1578 with dissolve
    p "Yeah, look at that...I just marked you as mine!"
    br "Yes, mark me as much as you want, whenever you want..."
    br "I'm exhausted, I'm not twenty anymore..."
    scene ima1577 with dissolve
    br "Come rest with me...hug me..."
    scene ima1578a with dissolve
    p "You're fantastic, Brenda...you don't know how much I needed that..."
    br "I can imagine...I loved it, too..."
    scene black with Dissolve(3)

    $ renpy.end_replay()

    jump endbrenda

label choice75b:

    $ choice75b = True

    br "I think so...I'm sorry..."
    p "Then why'd you text me?!"
    scene ima1463 with dissolve
    br "I know! I'm sorry, I just can't do it..."
    scene ima1460 with dissolve
    pt "This bitch plays too much: yes, no...yeah, those are huge tits, but there are other girls I could fuck..."
    pt "I'm done with this bitch!"
    p "I don't want to say anything I'll regret later, so I'm just gonna go."
    scene ima1461 with dissolve
    br "Don't you want to talk?"
    p "Talk? We have nothing to talk about...talk with your husband."
    scene ima1462 with dissolve
    pause 1
    scene black with Dissolve(3)

    $ renpy.end_replay()

    scene ima1800 with dissolve
    pt "Where to go now? Who can I call? Uhmmm..."

if choice65a:
    pt "I don't want to go to The Gold Rush, paying for sex is gay..."
    pt "I wouldn't mind seeing Elle again though, that woman's so fucking hot! Maybe I'll run into her somewhere else..."
    jump nope

label nope:
    scene ima1801 with dissolve
    pt "Mmm...let's see...nope, nope, definitely not..."

if choice62a:
    scene ima1802 with dissolve
    pt "Oh, yeah, Valentina!"
    scene ima1803 with dissolve
    p "Hey, Valentina, how you doing?"
    val "Hi! How YOU doing? I thought you were never gonna call..."
    p "Why? We had a good time together, didn't we?"
    scene ima1805 with dissolve
    val "We did, yeah..."
    p "I was thinking maybe you want to do it again?"
    scene ima1806 with dissolve
    val "You mean sex or you're asking me out?"
    p "Mmm...more like asking you IN the same hotel we went to..."
    scene ima1807 with dissolve
    val "Haha, it's 11 am! And I already tasted you!"
    p "You didn't like it?"
    val "Haha, what do you think? But I'm more interested in a date today, you know, lunch maybe?"
    p "Nnghh...it's not really a good time for dating, Val...Am I on speaker? I hear you far away..."
    scene ima1808 with dissolve
    val "Hehehe, you are, but don't worry nobody's listening, I'm just drinking my coffee."
    p "Oh, okay..."
    scene ima1809 with dissolve
    val "You're not in the mood for dating and I'm not in the mood to be your booty call..."
    scene ima1810 with dissolve
    val "...today, haha..."
    val "I don't close any door, maybe I'll see you at a club and want to hook up with you again...it was fun the first time."
    p "Maybe I'll text you more often then..."
    scene ima1811 with dissolve
    val "Maybe you will."
    p "I'll see you around, Val."
    val "Bye!"
    scene ima1812 with dissolve
    pt "I like this girl, she's cool...don't know much about her though...should've asked something else...nah, not in the mood for that..."
    scene ima1813 with dissolve
    pt "Well, I guess I'm watching some good old porn..."
    scene black with Dissolve(3)

    jump endbrenda

if choice76b:

    scene ima1802 with dissolve
    pt "Oh, I know! Vanessa!"
    scene ima1814 with dissolve
    va "Heeeeey! And this miracle?"
    scene ima1804a with dissolve
    p "I was just thinking about you...Are you free right now?"
    va "Nope, I'm working, wanna come to the shop and keep me some company?"
    p "On my way."
    scene ima1804b with dissolve
    va "Hahaha, that was fast!"
    scene ima1804c with dissolve
    p "Are you kidding me? YOU told me to go just after I said \"Hello.\""
    va "Haha, just come!"
    p "Give me 30 minutes..."
    va "I'm going nowhere!"

label vanessasex2:

    if _in_replay:
        $ pf = persistent.p

    scene black with Dissolve(1)
    play music "audio/sensual14.mp3"
    scene ima1816 with dissolve
    va "Hey! I've been wanting to see you for quite some time!"
    p "Same here, Vanessa!"

    scene ima1817:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "Daaamn, I remember those legs on my shoulder...very nice body!"
    pt "Not the prettiest face, but that's ok...she knows how to ride! That's what I need right now!"
    scene ima1818 with dissolve
    va "Come here, give me a kiss, handsome!"
    scene ima1819 with dissolve
    pause
    scene ima1820 with dissolve
    pause
    scene ima1821 with dissolve
    pause
    scene ima1822 with Dissolve(1)
    p "You didn't close your eyes..."
    scene ima1823 with dissolve
    va "Haha, neither did you, haha...and why would we? This's not love, we're just having fun..."
    scene ima1824 with dissolve
    va "Hurry, let's get to the back room, we don't have much time!"
    scene ima1825 with dissolve
    pause
    scene ima1826 with dissolve
    pt "Wait a minute..."
    scene ima1827 with dissolve
    pt "That's..."
    stop music
    play sound "audio/breathwoosh.mp3"

    scene flashback1:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.5
        pause 0.0666
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
    pause 0.1162

    scene ima1827 with dissolve
    pt "What the fuck was that?!"
    pt "That guitar..."
    pt "No, don't think about it, block it, I don't wanna go home and cry all day...I'm done with that shit!"
    va "What are you waiting for?"
    play music "audio/sensual14.mp3"
    scene ima1828 with dissolve
    pt "Sssss..."
    pt "Yeah, that's what I need right now: a distraction!"
    scene ima1829 with dissolve
    va "Are we gonna do it or what?"
    pt "Look at that, she's so fucking sexy..."
    scene ima1830 with dissolve
    p "I'm gonna take you right here!"
    va "Hahaha, that'd be hot! Haha, but we can't, I really need this job...come on, follow me!"
    stop music fadeout 2
    scene black with Dissolve(1)
    scene ima1831 with dissolve
    va "Don't be shy, come here, baby..."
    p "I don't understand why you're not naked already..."
    va "Hahaha..."
    scene ima1832 with dissolve
    va "Let me show you why..."
    play music "audio/trainingday.mp3" volume 0.8
    scene ima1833 with Dissolve(1.5)

    scene ima1833:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.3
        pause 0.5

    scene ima1833 with dissolve
    va "And?"
    va "Is it really necessary? Haha."
    p "Holy shit!"
    p "I'm about to cum in my pants!"
    va "Hahaha."
    scene ima1834 with dissolve
    p "That looks like a tasty pussy, not gonna lie..."
    p "Don't move! I need to taste that!"
    va "Hahaha."
    scene ima1835 with dissolve
    pause
    scene ima1836 with dissolve
    va "Yes, baby, you know how..."
    scene ima1837 with dissolve
    va "Aahh, ahh..."
    scene ima1838 with dissolve
    pause
    scene ima1839 with dissolve
    va "Sweet as honey, isn't it?"
    p "A little sour, to tell the truth."
    va "Haha, asshole!"
    scene ima1839a with dissolve
    va "Ooohh! You're gonna hurt me with that..."
    scene ima1840 with hpunch
    p "I'll be kind..."

    scene ima1840:
        pause 0.0222
        "ima1841"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "ima1842"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "ima1843"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "ima1844"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "ima1845"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "ima1846"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "ima1847"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "ima1848"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "ima1849"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "ima1850"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0222
        "ima1851"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "ima1852"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "ima1853"
        xpos 0.5 ypos 0.598 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "ima1854"
        xpos 0.5 ypos 0.599 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "ima1855"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "ima1856"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "ima1857"
        xpos 0.5 ypos 0.601 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "ima1858"
        xpos 0.5 ypos 0.602 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "ima1859"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "ima1860"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "ima1861"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0222
        "ima1862"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "ima1863"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "ima1864"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "ima1865"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "ima1866"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "ima1867"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "ima1868"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "ima1869"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "ima1870"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "ima1871"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        repeat
    pause

    scene ima1840:
        pause 0.0166
        "ima1841"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "ima1842"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "ima1843"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "ima1844"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "ima1845"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "ima1846"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "ima1847"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "ima1848"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "ima1849"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "ima1850"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0166
        "ima1851"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0166
        "ima1852"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0166
        "ima1853"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "ima1854"
        xpos 0.5 ypos 0.594 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "ima1855"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "ima1856"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "ima1857"
        xpos 0.5 ypos 0.606 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "ima1858"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "ima1859"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0166
        "ima1860"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0166
        "ima1861"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0166
        "ima1862"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "ima1863"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "ima1864"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "ima1865"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "ima1866"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "ima1867"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "ima1868"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "ima1869"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "ima1870"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "ima1871"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        repeat
    pause

    stop music fadeout 3
    play sound "audio/girlcum.ogg"
    scene ima1872 with vpunch
    scene ima1872 with vpunch
    scene ima1872 with vpunch
    pause
    va "Aaahhhh, yes!"
    scene ima1873 with dissolve
    p "What the fuck?! You didn't warn me!"
    va "Hahaha, a little squirt won't hurt."
    p "Oh, you find this funny, huh? Get down, now!"
    scene black with dissolve
    play sound "audio/rip.ogg"
    pause
    va "Hey! You owe me a skirt!"
    play music "audio/rockjoy.ogg" volume 0.7
    scene ima1874 with dissolve
    p "Shut up! You peed my shirt!"
    va "Hahaha, you should've seen your face, haha...hilarious!"
    p "Oh, and you keep laughing..."
    scene ima1875 with dissolve
    p "You're not going to laugh anymore..."
    va "What are you doing?"
    p "Your butthole's supposed to be tighter, right?"
    scene ima1876 with dissolve
    va "Hahaha, your first anal? What an honor!"
    p "Shut up!"
    scene ima1877 with dissolve
    p "You're not supposed to like it!"
    va "Oh, baby, but I love anal!"
    p "After me, you won't..."
    p "There!"
    scene ima1878b with dissolve

    scene ima1878b:
        pause 0.0133
        "ima1879b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "ima1880b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "ima1881b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "ima1882b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "ima1883b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "ima1884b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "ima1885b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "ima1886b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "ima1887b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "ima1888b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "ima1889b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "ima1890b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "ima1891b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "ima1892b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima1893b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "ima1894b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "ima1895b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "ima1896b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "ima1897b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "ima1898b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "ima1899b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "ima1900b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "ima1901b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "ima1902b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "ima1903b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima1904b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "ima1905b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "ima1906b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "ima1907b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "ima1908b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "ima1909b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "ima1910b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "ima1911b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "ima1912b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "ima1913b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "ima1914b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "ima1915b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "ima1916b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "ima1917b"
        pause 0.0133
        repeat
    pause
    p "Fuck! It IS tight!"

    scene ima1895b:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0133
        "ima1896b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0133
        "ima1897b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0133
        "ima1898b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0133
        "ima1899b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0133
        "ima1900b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0133
        "ima1901b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.09
        pause 0.0133
        "ima1902b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.08
        pause 0.0133
        "ima1903b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0133
        "ima1904b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.06
        pause 0.0133
        "ima1905b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.05
        pause 0.0133
        "ima1906b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.04
        pause 0.0133
        "ima1907b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0133
        "ima1908b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0133
        "ima1909b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "ima1910b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1911b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1912b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1913b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1914b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1915b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1916b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1917b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1878b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1879b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1880b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1881b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1882b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1883b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1884b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1885b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0133
        "ima1886b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "ima1887b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0133
        "ima1888b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0133
        "ima1889b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.04
        pause 0.0133
        "ima1890b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.05
        pause 0.0133
        "ima1891b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.06
        pause 0.0133
        "ima1892b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0133
        "ima1893b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.08
        pause 0.0133
        "ima1894b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.09
        pause 0.0133
        repeat
    pause

    va "Yeah, baby, keep going! Harder!"
    p "Shit, this feels amazing!"
    va "Cum, daddy, cum in my asshole, daddy!"
    p "Shut up, I'm not your daddy..."
    va "Yes, you are! Fill up your bitch, daddy!"

    scene ima1878b:
        pause 0.0133
        "ima1879b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "ima1880b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "ima1881b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "ima1882b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "ima1883b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "ima1884b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "ima1885b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "ima1886b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "ima1887b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.00665
        "ima1888b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.00665
        "ima1889b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.00665
        "ima1890b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.00665
        "ima1891b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.00665
        "ima1892b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.00665
        "ima1893b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.00665
        "ima1894b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.00665
        "ima1895b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.00665
        "ima1896b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.00665
        "ima1897b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.00665
        "ima1898b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.00665
        "ima1899b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.00665
        "ima1900b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.00665
        "ima1901b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.00665
        "ima1902b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.00665
        "ima1903b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.00665
        "ima1904b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.00665
        "ima1905b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.00665
        "ima1906b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.00665
        "ima1907b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.00665
        "ima1908b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "ima1909b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "ima1910b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "ima1911b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "ima1912b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "ima1913b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "ima1914b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "ima1915b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "ima1916b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "ima1917b"
        pause 0.0133
        repeat
    pause


    play sound "audio/maleorg1.ogg"
    stop music fadeout 3
    scene ima1880b with vpunch
    scene ima1880b with vpunch
    scene ima1880c with flash
    scene ima1880c with dissolve
    va "I loved it, daddy!"
    p "Fuck, I needed this shit!"
    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    jump endbrenda

if choice76a:

    scene ima1801 with dissolve
    pt "Damn, I really need more contacts..."
    scene ima1813 with dissolve
    pt "Well, I guess I'm watching some good old porn today..."
    scene black with Dissolve(3.0)

    jump endbrenda

label endbrenda:

    pause
    play sound "audio/footballtraining.mp3"
    play music "audio/formation.mp3" volume 0.8
    scene ima1920 with Dissolve(1)
    coa "Not 4-5-1 anymore, Blanco! Go to the right wing!"
    coa "You're doing it all wrong!"
    coa "Come here, come here!"
    scene black with dissolve
    scene ima1921 with dissolve
    coa "Look, this's our new formation: 4-3-3!"
    scene ima1922 with dissolve
    coa "I want you there as a right winger, very wide!"
    scene ima1923 with dissolve
    coa "You're staying in the center for too long as in our classic formation..."
    scene ima1924 with dissolve
    coa "Don't leave the right side open for the left-back, and yes, I know, you're a playmaker more than a winger."
    p "Sorry, coach, it's just a natural thing...you know I like to roam free to create chances."
    coa "I know, I know, but we don't have right midfielders this season, you're gonna have to adapt to your new role..."
    scene ima1925 with dissolve
    coa "Virgilio and Renilic can cover you sometimes, but you have to work defensively, too, get it?"
    scene ima1926 with dissolve
    coa "Can you play there or not?"
    p "Yes, coach!"
    coa "I'm counting on you, keep training hard and remember who brought you back! Go!"
    stop sound fadeout 1
    scene black with dissolve
    scene ima1927 with dissolve
    coa "Hit the gym now! One hour and then go home, we'll have a hard day on the beach tomorrow!"
    scene ima1943 with Dissolve(1)
    cj "Robinson's crazy wanting you to do all the wing work..."
    p "I know, but I want to play...I need to play, I'll do what he wants."
    cj "You ok?"
    p "I'm not...don't ask that stupid question again."
    cj "Sorry..."
    stop music fadeout 2
    scene black with Dissolve(2)
    play music "audio/beachtraining.mp3"
    scene ima1928 with dissolve
    coa "Eighty percent!"
    scene ima1929 with dissolve
    coa "One hundred percent! Come on now!"
    pt "I have to train harder than anybody, I owe it to her!"
    scene ima1930 with dissolve
    ren "Hey, where do you think you're going? Hell no! You're not beating me, [p]!"
    p "Let go, Joker! You're too slow!"
    scene ima1931 with dissolve
    kp "This's as far as you'll get!"
    p "Hey! What the hell?! Oh, I see what this is: two bitches jealous of my speed!"
    kp "Shut up, you're not that fast."
    p "I'm faster than you!"
    kp "And I'm stronger than you!"
    p "This's not MMA!"
    scene ima1932 with dissolve
    coa "Blanco! Shut up! Get serious and stop playing!"
    p "What?! I'm not playing..."
    coa "If you continue like that, yeah, you're definitely not playing!"
    ren "Hahaha."
    scene black with dissolve
    scene ima1933 with dissolve
    coa "Great work, team! That's what I want of you!"
    kp "That's it, coach? I didn't even sweat!"
    scene ima1934 with dissolve
    coa "That's because you're a freak, Phillips, you can keep running if you want..."
    kp "I think I'll do that."
    pt "Yeah, I can keep going a little longer, too."
    scene black with dissolve
    scene ima1935 with dissolve
    cj "Yo, homie...I'm dead...the sun...killed me..."
    p "Duuuuude, you better get in shape soon, otherwise, Arthur will start the games...you can't even breathe..."
    scene ima1936 with dissolve
    cj "I'm ok, man, just need...some water..."
    p "Yeah, you go and drink some...I'm gonna keep running, brother..."
    scene black with dissolve
    scene ima1937 with Dissolve(1)
    kp "Come on, minions, keep the pace!"
    scene ima1938 with Dissolve(2)
    ren "Gilmar's falling behind, Dog..."
    kp "Come on, Gilmar! I thought you had it in you...even the new guy can keep up!"
    p "Shut up, Phillips, I'm not new to this..."
    kp "[p]! Quick question: what's your goal?"
    p "My goal? To win the Championship, of course!"
    kp "Pfft, forget about that shitty tournament...Gilmar! What's your goal?!"
    scene ima1939 with dissolve
    gil "To be a professional..."
    kp "I can't hear you!"
    scene ima1940 with dissolve
    gil "To become a pro!!!"
    scene ima1941 with dissolve
    gil "O melhor do mundo!!!"
    kp "Then keep it up, puta!"
    gil "Your mom!"
    scene black with dissolve
    scene ima1942a with dissolve
    kp "We'll rest when we retire!"
    ren "Hell, yeah!"
    gil "Too long, Dog! Too hard!"
    ren "Hahaha, gay!"
    gil "Teu pai!"
    stop music fadeout 3
    scene black with Dissolve(3)
    pause

    scene ima1944 with Dissolve(1)
    p "I don't want to watch videos anymore..."
    play sound "audio/vibrator.mp3"
    scene ima1945 with dissolve
    p "Who is it?"
    p "Ann!"
    stop sound
    scene ima1946 with dissolve
    p "Hi, Annie!"
    scene ima1946a with dissolve
    an "Where are you?!"
    p "In my room."
    an "Do you want to go out?"
    p "Where you at?"
    scene ima1946b with dissolve
    an "At the bar with Rivka."
    scene ima1946c with dissolve
    ri "IN A bar."
    an "You heard her...Wanna come?"
    p "Yeah, yeah, but it's a bar, right? Not a club, I don't feel like dancing..."
    an "I know you don't like it, buddy, this place's cozy and not that loud, just the way you like it..."
    p "Alright, I'm coming, share your location...wait, wait, wait, don't hang up, I just remember you're a super lightweight! Does Rivka know?"
    an "Just hurry, [p]..."
    play sound "audio/hangup.ogg"
    scene ima1946
    pause 2
    scene ima1947 with dissolve
    pt "What the hell? Better call Rivka..."
    scene ima1946 with dissolve
    play sound "audio/phoneanswered.mp3"
    pause 2
    scene ima1948
    an "You're soooo predictable, [p]!"
    p "Are you drunk already?"
    an "Nope."
    scene ima1949 with dissolve
    p "You sure?"
    an "Maybe I am, maybe I'm not..."
    play sound "audio/hangup.ogg"
    scene ima1946
    pause 2
    scene ima1947 with vpunch
    p "Oh, come on!"
    pt "I don't want to babysit, but...two young girls all by themselves, surrounded by drunk men...crazy people out there these days, I wouldn't forgive myself if something..."
    pt "Don't even think like that... better go check on them..."
    p "Sorry, Panther, we have to move..."
    play sound "audio/sadcat.mp3"
    scene black with Dissolve(4)
    stop sound
    pause
    play music "audio/jazz1.ogg"
    scene ima1950 with dissolve
    pt "Heeeyyy, Rivka put on some makeup tonight...she looks pretty!"
    p "I thought you'd be on the floor by now, Annie."
    scene ima1951 with dissolve
    an "[p]! My buddy!"
    pt "She's always happy to see me...what a good friend she's become..."
    scene ima1952 with dissolve
    pause
    scene ima1953 with dissolve
    p "And you?"
    ri "Don't."
    p "What...why not? I have to: you look very pretty tonight, Riv!"
    scene ima1954 with dissolve
    ri "Ugh, I told you not to."
    p "Come on, Riv, just take the compliment."
    ri "Compliments are okay when they're about my performance, other than that, err...no thanks...what's the merit in putting on some makeup?"
    p "Geez, Riv, look around, you're in a bar, chill out..."
    p "Do you ever smile?"
    scene ima1955 with dissolve
    ri "Di yii ivir smili?"
    an "Hahaha, how ugly! Don't do that!"
    scene ima1956 with dissolve
    p "Hahaha, that's better!"
    scene ima1957 with dissolve
    an "You want to see how fast she can lose her head? Pretend I'm telling you something super funny..."
    p "Hahahahaha..."
    an "Hahaha, hilaaaaarious, isn't it?"
    an "{size=-6}That was too much, by the way...{/size}"
    scene ima1958 with dissolve
    ri "What are you doing? I don't like inside jokes. Don't do that."
    an "It was nothing, don't worry about it."
    scene ima1959 with dissolve
    ri "What do you mean it was nothing?! You guys were just laughing so hard...at me?! I demand to know...now!"
    an "You wouldn't get it anyways, it's a Jersey thing."
    ri "What?! Neither of you is from Jersey!"
    an "See?"
    p "Hahaha."
    stop music fadeout 2
    yu "Heeeeey!"
    scene ima1960 with dissolve
    yu "Wanna play?"
    play music "audio/benmoose.ogg"
    scene ima1960 with hpunch
    p "Heeeeey, youuuu...Yua! How have you been?! Don't tell me you work here too!"
    scene ima1961 with dissolve
    yu "Hahaha, I already sent my resume, hahaha...just kidding, two jobs are more than enough."
    an "Cough, cough, ahem..."
    scene ima1962 with dissolve
    p "Oh! Yua, these are my friends: Annie..."
    yu "Hi, nice to meet you!"
    scene ima1963 with dissolve
    pause
    p "And Rivka."
    scene ima1962 with dissolve
    yu "Come again?"
    scene ima1964 with dissolve
    ri "Rivka, R-I-V-K-A, Rivka."
    yu "Oh, Rivka! What a beautiful name!"
    ri "Thanks."
    scene ima1965 with dissolve
    p "Oh, so you DO know how to take a compliment..."
    scene ima1966 with dissolve
    ri "Si yii di kniw hiw ti..."
    p "Hahaha, don't do that! Haha."
    scene ima1967 with dissolve
    yu "So? You guys wanna play?"
    p "I've never pla..."
    scene ima1968 with dissolve
    an "Oh, I'm playing...I break!"
    yu "Sugoi!"
    scene black with dissolve
    scene ima1969 with dissolve
    an "You said you've never played before, [p]?"
    p "Nope, but how hard can it be? You put the balls into the holes..."
    scene ima1970 with dissolve
    an "Haha, balls into holes, haha."
    ri "Focus and show us how to do it, Ann."
    an "Ok, ok, sorry..."
    scene ima1971 with dissolve
    an "You have to make sure your bridge hand is planted firmly first, then you just need to hit the cue ball, not too low, just slightly above center...with power and speed..."
    an "Use your thumb to guide the cue..."
    scene ima1972 with dissolve
    pause
    play sound "audio/billiardsbreak.ogg"
    scene ima1972 with dissolve
    scene ima1973 with hpunch:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.08
    scene ima1973 with dissolve
    pause
    yu "Sweet! Very nice shot! You pocket two!"
    scene ima1974 with dissolve
    an "Not bad, huh? Haha, now you have to pocket all the stripes or solids and when you're done with those, pocket the black one for the win!"
    p "Got it!"
    scene ima1975 with dissolve
    yu "Hey, I can see you're good!"
    an "Yeah, I know. Are you impressed?"
    yu "Not really, I think I'm better."
    an "Oh, is that so? Wanna put your money where your mouth is? Let's say...ten dollars a ball?"
    yu "Make it twenty and you got yourself a game..."
    an "So confident...don't blame me if you lose that smile..."
    scene ima1976 with dissolve

    play sound "audio/versussound.ogg"
    scene ima197740 with Dissolve(0.006)
    scene ima197736 with Dissolve(0.006)
    scene ima197732 with Dissolve(0.006)
    scene ima197728 with Dissolve(0.006)
    scene ima197724 with Dissolve(0.006)
    scene ima197720 with Dissolve(0.006)
    scene ima197716 with Dissolve(0.006)
    scene ima197712 with Dissolve(0.006)
    scene ima19778 with Dissolve(0.006)
    scene ima19774 with Dissolve(0.006)
    scene ima1977a with Dissolve(0.006)
    scene ima1977c with Dissolve(0.006)
    scene ima1977e with Dissolve(0.006)
    scene ima1977g with Dissolve(0.006)
    scene ima1977i with Dissolve(0.006)
    scene ima1977k with Dissolve(0.006)
    scene ima1977l with hpunch
    play sound "audio/versussound.ogg"
    scene ima1978j with Dissolve(0.026)
    scene ima1978h with Dissolve(0.026)
    scene ima1978f with Dissolve(0.026)
    scene ima1978d with Dissolve(0.026)
    scene ima1978b with Dissolve(0.026)
    scene ima19781 with Dissolve(0.026)
    scene ima19783 with Dissolve(0.026)
    scene ima19785 with Dissolve(0.026)
    scene ima19787 with Dissolve(0.026)
    scene ima19789 with Dissolve(0.026)
    scene ima197810 with vpunch
    play sound "audio/versussound.ogg"
    scene ima197969 with Dissolve(0.006)
    scene ima197963 with Dissolve(0.006)
    scene ima197957 with Dissolve(0.006)
    scene ima197951 with Dissolve(0.006)
    scene ima197945 with Dissolve(0.006)
    scene ima197939 with Dissolve(0.006)
    scene ima197933 with Dissolve(0.006)
    scene ima197927 with Dissolve(0.006)
    scene ima197921 with Dissolve(0.006)
    scene ima197915 with Dissolve(0.006)
    scene ima19799 with Dissolve(0.006)
    scene ima19793 with Dissolve(0.006)
    scene ima1979d with Dissolve(0.006)
    scene ima1979j with Dissolve(0.006)
    scene ima1979n with hpunch
    play sound "audio/fightmk.ogg"
    scene ima1979n with dissolve
    scene ima1979o with vpunch
    scene ima1979o with vpunch
    pause
    scene ima1980 with dissolve
    ri "This might take a while...wanna go grab a beer?"
    p "I wanted to play first, but yeah, you're right, this's not gonna be quick...let's go."
    scene black with dissolve
    scene ima1981 with dissolve
    ba "Hi, honey bunny! I see you are with my friend Yua!"
    pt "Great, same bitch from the beach..."
    ba "Sorry I'm not wearing any makeup tonight...I heard you like it, baby darling..."
    p "What the fuck?!" with hpunch
    p "Dude...last time: I'm not fucking gay, don't call me \"honey bunny\", \"baby darling\"...Don't ever call me any of that shit again!"
    scene ima1982 with dissolve
    lgb "Dude?! You didn't even ask me for my pronouns!"
    pt "Ugh, here comes that crap..."
    p "Listen, du..."
    scene ima1983 with dissolve
    ri "You people are exhausting really..."
    scene ima1984 with dissolve
    ri "Yii didn't ivin isk mi fir mi priniins..."
    scene ima1985 with dissolve
    ri "Shut up already, would you? And give my friend a beer!"
    p "Hahaha."
    scene ima1986 with dissolve
    pause 1.5
    scene ima1987
    ri "And put it on his tab!"
    p "Hahaha."
    stop music fadeout 3
    scene black with dissolve
    scene ima1988 with dissolve
    p "You're awesome, Riv."
    ri "Did you doubt it?"
    p "Nope, not even for a second."
    scene ima1989 with dissolve
    ri "Mr. Revello!"
    p "Huh?"
    scene ima1990 with dissolve
    giu "[p], can I talk to you privately?"
    ri "Of course, of course, go ahead, don't mind me..."
    p "I guess..."
    giu "Let's go outside..."
    scene black with dissolve
    play music "audio/groovetube.ogg"
    scene ima1991 with dissolve
    pause
    scene ima1993 with dissolve
    pt "He's lost a lot of weight in just a couple of weeks...that's not normal...is he sick or super depressed? He's not eating at all apparently..."
    pt "That cigarrete may be his only food...well, I don't care, never liked him, never liked the way he talked about his family..."
    pt "But that doesn't mean he treated them badly, right? Samantha only said good things about him..."
    play sound "audio/exhalesmoke.mp3"
    scene ima1994 with dissolve
    pt "Was he just bullshitting all the way around as I initially thought?"
    pt "\"A man isn't his words, a man is his actions.\""
    pt "And to be fair, he's never done anything to me...Vittoria even said he defended me when their relatives tried to blame me...but why?"
    scene ima1995 with dissolve
    giu "Hey, listen, I just wanted to ask you one thing..."
    giu "If you got the chance to kill Sam's murderer, would you do it?"
    scene ima1996 with dissolve
    p "If I could go back in time and save her, yeah, without a doubt."
    scene ima1997 with dissolve
    giu "No, you didn't get it...I mean NOW, would you kill the person who did that to her, would you avenge her?"
    p "Avenge her? Why are you asking that?"
    giu "Do not answer with a question..."
    p "It's a tough one...to be honest, I...I don't know if I have it in me...I would be saving nobody..."
    scene ima1998 with dissolve
    giu "You'd rather go out and live your life, right?"
    p "It's not like that...I'm just trying to think more like Samantha...I'm sure she wouldn't kill anybody...I want to be more like her..."
    scene ima1999 with vpunch
    giu "You'll never be like her! What the fuck are you talking about?! Nobody will ever be like my daughter!"
    giu "Listen, kid, I'm getting real tired of your bullshit...How long did you know Samantha? Six months? I bet you don't even know what her favorite book was!"
    giu "\"Think like Samantha.\"...\"Be more like her.\"...Fuck you! She's dead! And you're still here! Breathing!"
    p "I'm sorry...I..."
    giu "Don't just be sorry! Do something!"
    scene ima2000 with dissolve
    p "Do something? What can I do now? Tell me, I'd love to know..."
    pt "Perhaps his question wasn't hypothetical..."
    p "You know more than you're letting on, don't you? What is this really about?"
    giu "..."
    pt "He knows something...what is it? He wants me to kill someone...no, not just anyone, S's murderer...Does he really know who did it?"
    scene ima2000 with vpunch
    pt "Yeah! It makes sense! That's why this son of a bitch told his family I had nothing to do with it! He knows who did it! That must be it!"
    scene ima2001 with dissolve
    giu "That face tells me you figured it out, I knew you were not that slow...Do you have it in you now?"
    p "You know who killed S?! Have you called the police?"
    scene ima2002 with dissolve
    giu "Pft, the police..."
    scene ima2003 with dissolve
    giu "You see this ring?"
    scene ima2004 with dissolve
    pause
    p "I've seen that ring before...my dad had one...what does it have to do with anything?!"
    giu "What do you know about it?"
    p "You're not answering my question...Ugh, fine...I don't know anything, he explained the meaning of that stupid symbol to me, but I've completely forgotten, why?"
    giu "First..."
    scene ima2005 with dissolve
    giu "What are you going to do when I tell you who did it?"
    stop music
    play sound "audio/breathwoosh.mp3"

    scene flashback1:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.5
        pause 0.0666
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
    pause 0.1162
    scene ima2005 with dissolve
    pt "What the hell?!"
    pt "What's happening to my brain?!"
    p "Eeerr...I don't know...go to the police I guess."
    giu "You can't, they won't help...would you kill the man who murdered my daughter?"
    scene ima2005 with vpunch
    p "What?! Man...honestly, I don't know...I'm overwhelmed by this whole situation, don't know what to say..."
    p "If killing him brought her back, I'd do it, that I'm sure of...don't ask me how, I don't even know how to fight, but I'd do it..."
    p "Right now, after it happened...it's just...it won't solve anything...there's nothing I can do to make it right...NOW..."
    scene ima2006 with dissolve
    giu "I don't understand how you can look at yourself in the mirror every day..."
    giu "Oh, I get it: you never loved her, huh? Her curse was loving you too much...sorry to bother you..."
    scene ima2007 with dissolve
    pause 1.5
    scene black with dissolve
    play music "audio/disturbingevent.mp3"
    scene ima2008 with dissolve
    giu "Oh, [p], and one more thing in case I don't see you again...it's nothing, something you already know..."
    scene ima2009 with dissolve
    giu "He wanted you."
    p "Huh?"
    giu "The man who killed my daughter...he was after you."
    scene ima2009 with vpunch
    scene ima2009 with vpunch
    p "What?! Wanted me?! How the fuck do you know that?! Who is he?!"
    scene ima2010 with dissolve
    giu "You want answers? Help me."
    giu "In the meantime, enjoy your fucking life and think of my daughter every time you do..."
    giu "That's right: every time you smile, every time you laugh with your stupid friends remember you get to do it because my daughter's dead..."
    p "Man..."
    scene ima2011 with dissolve
    giu "Every time you smile, [p]..."
    giu "Every time you smile."
    an "Every time you smile?"
    stop music fadeout 3
    scene ima2012 with dissolve
    an "What was that all about?"
    p "Annie...I don't wanna talk about it."
    an "And...he's gone."
    yu "[p]!!!"
    scene ima2013 with dissolve
    yu "I'm so sorry, I didn't know about your gi..."
    scene ima2014 with dissolve
    an "Oh, my God!"
    p "Yua!"
    scene ima2016 with dissolve
    yu "Aaargh, my knee!"
    an "Is it your knee or your ankle? Because from where I was standing it looked like you sprained your ankle...bad."
    yu "I think it's both! [p], take me to the hospital, please!"
    p "Yeah, right away!"
    ri "Lift her carefully...I'm already calling a cab!"
    scene black with Dissolve(1)
    scene ima2017 with dissolve
    p "Hurry, please!"
    yu "No, wait, it won't be necessary, take me home instead."
    scene ima2018 with dissolve
    p "What?! Are you sure? It looked bad from where I was."
    scene ima2019 with dissolve
    yu "I'll be fine, don't worry, just take me home..."
    yu "And thanks for looking after me..."
    scene black with Dissolve(1)
    play music "audio/silkymove.mp3"
    scene ima2020 with dissolve
    p "Watch out, can you walk?"
    yu "I think so...again, thank you so much for your help, [p]."
    p "Don't mention it...which building is it?"
    yu "There, 336."
    scene ima2021 with dissolve
    yu "A little far from Sunny Beach, isn't it?"
    p "A little? They must pay you pretty well over there to make the trip every day..."
    scene ima2023 with dissolve
    yu "Hahaha, yeah, Cara pays me reeeaaally well, haha."
    p "Cara? Oh, your friend, the chubby one...with beautiful eyes...didn't remember her name...she owns that spot on the beach?"
    scene ima2024 with dissolve
    yu "Yeah, yeah, where we met, and the big club nearby, and a restaurant...her dad owns many places in the city."
    p "Even the ice cream shop?"
    yu "Oh, no, that belongs to an old woman, well not that old...she owns a lot of places as well...the bar we've just been to is hers, for example...and she's a real character!"
    p "You seem to know a lot of business owners..."
    scene ima2022 with dissolve
    yu "Hehe, you think? That happens when you're poor, you gotta move and spend a long time looking for work everywhere, hehe."
    scene ima2025 with dissolve
    yu "[p]...uhm...I don't want this to sound cliché, but I'm very sorry for your loss...I know I don't know you guys very well, didn't know..."
    scene ima2026 with dissolve
    yu "Oh, gosh, that really sounded dumb, empty...I'm sorry I just keep making it worse...forgive me..."
    p "There's nothing to forgive, I know you're being sincere...it's hard to find the right words in a situation like this..."
    stop music fadeout 3

menu:
    "I don't have your number...":
        jump choice77a

    "Timing, my friend.":
        jump choice77b

label choice77a:

    $ choice77a = True

    p "Perhaps we need to change the subject...uhm, Yua..."
    scene ima2025 with dissolve
    yu "Yeah?"
    p "I just realized I don't have your number...uhm, can I have it?"
    scene ima2027 with dissolve
    yu "Eeerrr...I don't know...eeerrr...what do you want my number for?"
    p "To text you? Get to know you?"
    yu "Eeerrr...I don't know, [p]...would you let me give you some advice?"
    p "Yeah, sure."
    yu "It's something my grandma used to say: \"Broken people break.\""
    p "That's...that's really good advice, actually...I like it, wise woman."
    scene ima2028 with dissolve
    yu "She was, indeed...Uhm, do you feel ready to start dating? I don't think you are..."
    yu "And I'm not ready, either! I'm busy working all the time, don't have time for a relationship..."
    p "Hold it right there, Yua...Dating? I just asked you for your number, where did your mind go? To our wedding?"
    scene ima2022 with dissolve
    yu "Hehe, so you just want us to be friends then? To be honest, that'd be a letdown, I kind of like you, hehe..."
    p "Uuuhm, I kind of like you, too..."
    scene ima2029 with dissolve
    yu "Of course you do! Haha...and I'm not the kind of girl to have a fling with...dating's my thing!"
    p "Timing's a bitch sometimes, isn't it?"
    yu "It sure is..."
    p "Well, I guess I'll see you around..."
    scene ima2030 with dissolve
    yu "Wait! If you think about it, you don't need my number, [p]: you know where I work, and now you know where I live! When you heal, come find me! Perhaps, I'm still single, haha."
    p "Ha, yeah, I'll have to think about it..."
    yu "You go and do that...thanks for everything again! I was so happy to see you tonight!"
    p "Yeah, so was I..."

    jump choice77_common

label choice77b:

    $ choice77b = True

    scene ima2025 with dissolve
    p "Well, I have to go, Yua, I'm glad your knee's better...it was good to see you, really!"
    scene ima2028 with dissolve
    yu "Yeah, it was good to see you, too! Thank you so much for your help...I hope we run into each other again..."
    p "I'm sure we will...you're everywhere!"
    scene ima2022 with dissolve
    yu "Haha, bye, [p]!"

    jump choice77_common

label choice77_common:

    scene black with Dissolve(3)
    pause
    play music "audio/firstmatchwelcome.mp3"
    scene ima2031 with Dissolve(2)
    com "Moooooooorrrrrrning, Citizens! City TV welcomes you to our first game of the season! I'm Fumino Takase, streaming live on all our platforms..."
    fu "The Under-21 National Championship's about to start and we have big surprises for you this year! And I'm not only talking about the renovations in our stadium..."
    fu "Next to me, to give us his incredible analyses throughout the season, a football superstar who recently made it back home after ten years in Europe, our legend: Roooooooob Davies!"
    scene ima2032 with dissolve
    rd "Haha, good morning to you, Fumino, and to all Citizens out there! Very excited to begin with this amazing project and special thanks to Josephine Garnier for the opportunity to be a commentator..."
    rd "I'm looking forward to seeing how our team performs in the first match of the season, Fumino, we have unbelievable talent on this squad...and they have no excuse: the pitch looks like the carpet in my living room!"
    scene ima2033 with dissolve
    fu "I couldn't agree more: great conditions to have a great performance...Rob, the MVP of the last two seasons: Ethan \"Poker Face\" Phillips is still with us, I thought he'll be playing with the first team this year..."
    rd "Yes, he's been training with us lately...he and his brother, Kalvin, a fantastic defender! We'll be hearing from them sooner than later..."
    fu "Who else should we keep an eye on this squad, Rob?"
    rd "Definitely the attackers: players like Gilmar, [p] Blanco and Arthur dos Santos...I'm sure they won't disappoint..."
    scene ima2034 with dissolve
    fu "Now that you mentioned [p] Blanco, he's back into the team after recovering from a horrible injury that almost ended his career prematurely..."
    rd "The kid's been through a lot, I wish him the best."
    fu "Well said, Rob, nothing but good wishes to all our players..."
    scene ima2035 with dissolve
    fu "The team's coming out now, Rob! What an exciting moment! Let's go, Citizens!"
    scene black with Dissolve(1)
    scene ima2036 with Dissolve(1)
    pause
    cd "[p]!"
    scene ima2037a with dissolve
    pause 1
    scene ima2038 with dissolve
    cd "You got it, brother! Love you!"
    pt "I love you, too, Candy!"
    scene ima2039 with dissolve
    pt "It's so great to see you all!"
    scene ima2040 with dissolve
    pt "Vittoria's here today, supporting me...I have to play well!"

    play sound "audio/breathwoosh.mp3"

    scene flashback1:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.5
        pause 0.0666
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
    pause 0.1162
    scene ima2040 with dissolve
    pt "That shit again?! What could it be?"
    pt "I won't let it distract me now...gotta focus on the game..."
    vi "Come on, [p]! You have to score today!"
    pt "Yeah! I'll try my best..."
    scene ima2041 with dissolve
    pt "Even Metal came...he needs a wardrobe intervention urgently..."
    pt "Man, he's always been a good friend to me...when dad died, when I got injured, he was there..."
    pt "I should've helped him with Annie...that ship sailed long ago though...I don't think he ever stood a chance to be honest, she's never asked me anything about him..."

if choice75a:

    pt "And now I'm sleeping with his mom? Damn...you're cold, [p]..."
    pt "I was about to tell him the truth and ended up fucking his mom...fucking our friendship for good that's what I did..."
    pt "I've become the reason why his parents will divorce! It's just a matter of time before he finds out...the truth always comes to light..."
    pt "And you know what the worst part is? I don't even feel guilty about it...where has the guilt gone? It only took Brenda's wonderful tits to make it disappear..."
    pt "I feel nothing, seriously...something's wrong with me..."
    pt "Nah...I did what I had to do...I'm just trying to heal..."

    jump resumefirstgame

label resumefirstgame:

    la "[p], [p], wake up!"
    scene ima2042 with dissolve
    la "Listen, I'm gonna play a long ball between their left back and their number 3 as soon as I get the ball, be ready!"
    p "Your first assist right from the start, huh?"
    la "Haha, that'd be great if you can score from that spot...shoot if you can, but I'm sure Gilmar or CJ will be free, cross it..."
    p "Let me play, Lalas, don't tell me what to do, just pass me the ball..."
    stop music fadeout 2
    scene black with dissolve
    play sound "audio/whistle.mp3"
    scene ima2043 with dissolve
    pause 1
    scene ima2044 with dissolve
    la "Here, CJ!"

    scene ima2045 with Dissolve(0.3)
    play sound "audio/cardentrance.mp3" volume 2
    scene ima2045a with Dissolve(0.00004)
    scene ima2045b with Dissolve(0.00004)
    scene ima2045c with Dissolve(0.00004)
    scene ima2045d with Dissolve(0.00004)
    scene ima2045e with Dissolve(0.00004)
    scene ima2045f with Dissolve(0.00004)
    scene ima2045g with Dissolve(0.00004)
    scene ima2045h with Dissolve(0.00004)
    scene ima2045i with Dissolve(0.00004)
    scene ima2045j with Dissolve(0.00004)
    scene ima2045k with Dissolve(0.00004)
    scene ima2045l with Dissolve(0.00004)
    scene ima2045m with Dissolve(0.00004)
    scene ima2045n with Dissolve(0.00004)
    scene ima2045o with Dissolve(0.00004)
    scene ima2045p with Dissolve(0.00004)
    scene ima2045q with Dissolve(0.00004)
    scene ima2045r with Dissolve(0.00004)
    scene ima2045s with Dissolve(0.00004)
    scene ima2045t with Dissolve(0.00004)
    scene ima2045u with Dissolve(0.00004)
    scene ima2045v with hpunch
    play music "audio/firstmatchplaying.mp3"
    pt "Bruce \"Corky\" Lalas, 21 years old, midfielder, the clear example of why we shouldn't judge a book by its cover..."
    pt "He's not agile nor fast, never presses the opponents, he's not even strong although he spends hours in the gym...but he has something many other more athletic players lack: vision."
    pt "Run? Anybody can run, this is football, you have to use your head to play it..."
    pt "Lalas's always scanning the pitch, he can set up plays in his mind a second before anybody else...and in soccer, that second makes the difference..."
    scene ima2046 with dissolve
    pt "Of course, knowing where to send a long ball isn't enough, you have to get it done and, to do it, you need unbelievable long range passing skills..."
    pt "One thing's certain: Lalas possesses the most accurate long pass in the team...no, in the whole country, I'm sure about it..."
    scene ima2047 with dissolve
    pt "What a ball, you son of a bitch!"
    scene ima2048 with dissolve
    pause 0.5
    scene ima2049 with dissolve
    pause 0.5
    scene ima2050 with dissolve
    fu "Woooow, amazing ball control in the air, Rob!"
    scene ima2052 with dissolve
    rd "Haha, Blanco showing off a little too early in the game, but yeah, incredible first touch...he looks so motivated from the very first moment he stepped on the pitch..."
    fu "Quick question, Rob: is it a pitch or a field?"
    rd "Hahaha, well, it's never a pitch in America, but after being so many years in Europe you just get used to it...Do not ask me if it's football or soccer, eh!"
    scene ima2051 with dissolve
    fu "Hahaha, I like \"football\", it's what the whole world calls it! And you play it with your feet!"
    rd "I'm just gonna say that I'm playing for the MLS..."
    fu "Haha, here comes Blanco!"
    scene ima2053 with dissolve
    pt "Nice run, bro...quick, before he's offside..."

    menu:
        "No-look pass.":
            scene ima2054 with dissolve
            pause 0.6
            scene ima2055 with dissolve
            fu "A no-look pass! Blanco's confidence's sky-high today!"
            jump resumegame

        "Trivela.":
            scene ima2058a with dissolve
            scene ima2058b with dissolve
            scene ima2058c with dissolve
            rd "That's a nice pass, great technique."
            fu "Close those legs or you'll get megged by [p]!"
            jump resumegame

label resumegame:

    play sound "audio/whistle.mp3"
    scene ima2056 with hpunch
    gil "Heeeyyyy, red card!"
    scene ima2057 with dissolve
    pl "Oh, come on! You need glasses, ref! It was no foul!"
    ref "You did touch him."
    pl "I did not! He's diving!"
    fu "Looked like a clear foul to me, Rob, I don't know why he protests..."
    scene ima2058 with dissolve
    rd "Clear foul, indeed...and nobody's taking the ball away from [p]...he's so focused, look at him!"
    fu "Oh, I'm looking, Rob, I'm looking..."
    rd "Haha, are we still talking about soccer?"
    fu "Hehehe, I am!"
    scene ima2059 with Dissolve(1)
    pause 1.2
    scene ima2059g with Dissolve(1)
    stop music fadeout 2
    pause
    play music "audio/roadtrip.ogg"
    pt "Football's so unpredictable, anything can happen, anything can change all of a sudden..."
    pt "There's only one certainty: at some point, you're gonna get the ball. No player ever has left the field without touching it in 90 minutes..."
    pt "It doesn't matter if you only get to touch it once, you can score with one touch..."
    scene ima2059b with dissolve
    pt "I got this free kick...I got one touch..."
    pt "What are you gonna do with it, [p]? Has this moment caught you prepared?"
    scene ima2059d with dissolve
    ada "Cross it, [p]! We got this!"
    pt "You want the ball, Adams? Nah, you never want it, don't lie...you want legs, heads, not the ball!"
    pt "Players like you, like Kalvin only want to destroy...You don't need the ball for that!"
    pt "To you, football is like being on a battlefield, a war where losing means dying...and yeah, you need that kind of player to win, they're a necessary evil..."
    pt "Help me win, Adams, I know you've been to battle before..."
    scene ima2059e with dissolve
    pt "Way too many times in some cases..."
    pt "Is that dude even twenty? No way!"
    scene ima2059f with dissolve
    pt "Others, like Gilmar or CJ, see football as a lifesaver, a springboard to get out of poverty..."
    pt "They do love the game, but I'm sure they'll end up playing for the club that pays the most, money comes first...nothing wrong with that, they have families to provide for..."
    pt "I don't want to be like them...I never want to see this sport as a job, I'm no mercenary..."
    scene ima2059a with dissolve
    pt "To me, football is sheer art! It's like...like painting: the ball is my brush...I want it all the time, I need it! And the field is my canvas...a blank canvas waiting for a masterpiece!"
    scene ima2059b with dissolve
    pause 1
    scene ima2059c with dissolve
    pause 1
    scene ima2059b with dissolve
    pt "You're going in! You're going in! I can do this!"
    fu "You know he's scoring, right Rob?"
    rd "Haha, how do you know that?"
    scene ima2211 with dissolve
    fu "Hasn't it happened to you that you know something's going to happen before it happens? A precognition!"
    rd "Isn't it a premonition?"
    fu "Nope, with a \"c\", precognition: you KNOW it's gonna happen!"
    rd "Well, let's hope you're right, that's what we all Citizens want..."
    scene black with dissolve
    scene ima2060a with dissolve
    pause
    pt "Breathe..."
    stop music fadeout 3
    pt "Focus..."
    scene ima2060 with dissolve
    pt "Show them..."
    pt "This is the way I paint!"

    scene ima2060x with dissolve
    pause

    scene ima2060 with dissolve

    call screen freekick1

    screen freekick1():
        add "freekick"
        modal True

        imagebutton auto "fk1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "fk1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("freekick1")

image freekick:
    "ima2064"
    pause 0.0777
    "ima2065"
    pause 0.0777
    "ima2066"
    pause 0.0777
    "ima2067"
    pause 0.0777
    "ima2068"
    pause 0.0777
    "ima2069"
    pause 0.0777
    "ima2070"
    pause 0.0777
    "ima2071"
    pause 0.0777
    "ima2072"
    pause 0.0777
    "ima2073"
    pause 0.0777
    "ima2074"
    pause 0.0777
    "ima2075"
    pause 0.0777
    "ima2076"
    pause 0.0777
    "ima2077"
    pause 0.0777
    "ima2077"
    pause 0.0777
    "ima2077"
    pause 0.0777
    "ima2076"
    pause 0.0777
    "ima2075"
    pause 0.0777
    "ima2074"
    pause 0.0777
    "ima2073"
    pause 0.0777
    "ima2072"
    pause 0.0777
    "ima2071"
    pause 0.0777
    "ima2070"
    pause 0.0777
    "ima2069"
    pause 0.0777
    "ima2068"
    pause 0.0777
    "ima2067"
    pause 0.0777
    "ima2066"
    pause 0.0777
    "ima2065"
    pause 0.0777
    "ima2064"
    pause 0.0777
    repeat
pause


label freekick1:

    play sound "audio/deepbreath.mp3"
    scene ima2060 with Dissolve(0.1)

    scene ima2060:
        pause 0.0166
        "ima2061"
        pause 0.0166
        "ima2062"
        pause 0.0166
        "ima2063"
        pause 0.0166
        "ima2064"
        pause 0.0166
        "ima2065"
        pause 0.0166
        "ima2066"
        pause 0.0166
        "ima2067"
        pause 0.0166
        "ima2068"
        pause 0.0166
        "ima2069"
        pause 0.0166
        "ima2070"
        pause 0.0166
        "ima2071"
        pause 0.0166
        "ima2072"
        pause 0.0166
        "ima2073"
        pause 0.0166
        "ima2074"
        pause 0.0166
        "ima2075"
        pause 0.0166
        "ima2076"
        pause 0.0166
        "ima2077"
        pause 0.0166
        "ima2078"
        pause 0.0166
        "ima2079"
        pause 0.0166
        "ima2080"
        pause 0.0166
        "ima2081"
        pause 0.0166
        "ima2082"
        pause 0.0166
        "ima2083"
        pause 0.0166
        "ima2084"
        pause 0.0166
        "ima2085"
        pause 0.0166
        "ima2086"
        pause 0.0166
        "ima2087"
        pause 0.0166
        "ima2088"
        pause 0.0166
        "ima2089"
        pause 0.0166
        "ima2090"
        pause 0.0166
        "ima2091"
        pause 0.0166
        "ima2092"
        pause 0.0166
        "ima2093"
        pause 0.0166
        "ima2094"
        pause 0.0166
        "ima2095"
        pause 0.0166
        "ima2096"
        pause 0.0166
        "ima2097"
        pause 0.0166
        "ima2098"
        pause 0.0166
        "ima2099"
        pause 0.0166
        "ima2100"
        pause 0.0166
        "ima2101"
        pause 0.0166
        "ima2102"
        pause 0.0166
        "ima2103"
        pause 0.0166
        "ima2104"
        pause 0.0266
        "ima2105"
        pause 0.0266
        "ima2106"
        pause 0.0266
        "ima2107"
        pause 0.0266
        "ima2108"
        pause 0.0266
        "ima2109"
        pause 0.0266
        "ima2110"
        pause 0.0266
        "ima2111"
        pause 0.0266
        "ima2112"
        pause 0.0266
        "ima2113"
        pause 0.0266
        "ima2114"
        pause 0.0266
        "ima2115"
        pause 0.0266
        "ima2116"
        pause 0.0266
        "ima2117"
        pause 0.0266
        "ima2118"
        pause 0.0266
        "ima2119"
        pause 0.0266
        "ima2120"
        pause 0.0266
        "ima2121"
        pause 0.0266
        "ima2122"
        pause 0.0266
        "ima2123"
        pause 0.0266
        "ima2124"
        pause 0.0166
        "ima2125"
        pause 0.0166
        "ima2126"
        pause 0.0166
        "ima2127"
        pause 0.0166
        "ima2128"
        pause 0.0166
        "ima2129"
        pause 0.0166
        "ima2130"
        pause 0.0166
        "ima2131"
        pause 0.0166
        "ima2132"
        pause 0.0166
        "ima2133"
        pause 0.0166
        "ima2134"
        pause 0.0166
        "ima2135"
        pause 0.0166
        "ima2136"
        pause 0.0166
        "ima2137"
        pause 0.0166
        "ima2138"
        pause 0.0084
        "ima2139"
        pause 0.0084
        "ima2140"
        pause 0.0084
        "ima2141"
        pause 0.0084
        "ima2142"
        pause 0.0084
        "ima2143"
        pause 0.0084
        "ima2144"
        pause 0.0084
        "ima2145"
        pause 0.0084
        "ima2146"
        pause 0.0084
        "ima2147"
        pause 0.0084
        "ima2148"
        pause 0.0084
        "ima2149"
        pause 0.0084
        "ima2150"
        pause 0.0084
        "ima2151"
        pause 0.0084
        "ima2152"
        pause 0.0084
        "ima2153"
        pause 0.0084
        "ima2154"
        pause 0.0084
        "ima2155"
        pause 0.0084
        "ima2156"
        pause 0.0084
        "ima2157"
        pause 0.0084
        "ima2158"
        pause 0.0084
        "ima2159"
        pause 0.0084
        "ima2160"
        pause 0.0084
        "ima2161"
        pause 0.0084
        "ima2162"
        pause 0.0084
        "ima2163"
        pause 0.0084
        "ima2164"
        pause 0.0084
        "ima2165"
        pause 0.0084
        "ima2166"
        pause 0.0084
        "ima2167"
        pause 0.0084
        "ima2168"
        pause 0.0084
        "ima2169"
        pause 0.0199
        "ima2170"
        pause 0.0199
        "ima2171"
        pause 0.0199
        "ima2172"
        pause 0.0199
        "ima2173"
        pause 0.0199
        "ima2174"
        pause 0.0199
        "ima2175"
        pause 0.0199
        "ima2176"
        pause 0.0199
        "ima2177"
        pause 0.0199
        "ima2178"
        pause 0.0199
        "ima2179"
        pause 0.0199
        "ima2180"
        pause 0.0199
        "ima2181"
        pause 0.0199
        "ima2182"
        pause 0.0199
        "ima2183"
        pause 0.0199
        "ima2184"
        pause 0.0199
        "ima2185"
        pause 0.0199
        "ima2186"
        pause 0.0199
        "ima2187"
        pause 0.0199
        "ima2188"
        pause 0.0199
        "ima2189"
        pause 0.0199
        "ima2190"
        pause 0.0199
        "ima2191"
        pause 0.0199
        "ima2192"
        pause 0.0199
        "ima2193"
        pause 0.0199
        "ima2194"
        pause 0.0199
        "ima2195"
        pause 0.0199
        "ima2196"
        pause 0.0199
        "ima2197"
        pause 0.0199
        "ima2198"
        pause 0.0199
        "ima2199"
        pause 0.0199
        "ima2200"
        pause 0.0199
        "ima2201"
        pause 0.0199
        "ima2202"
        pause 0.0199
        "ima2203"
        pause 0.0199
        "ima2204"
        pause 0.0199
        "ima2205"
        pause 0.0199
        "ima2206"
        pause 0.0199
        "ima2207"
        pause 0.0199
        "ima2208"
        pause 0.0199
        "ima2209"
        pause 0.0199
        "ima2210" with hpunch
        pause 0.0199
        "ima2210" with hpunch
        pause 0.0199
    pause 6.2
    play music "audio/cleansuccessgoal.mp3"
    fu "Oh, my goodness, what did I tell you, Rob?! What did I tell you?! What a crazy curve!"
    rd "Unbelievable goal, Fumino...it looked like a knuckleball, but it was a curve at the end, I don't know how he did it, honestly, I'll have to watch the replay..."
    rd "This kid does nothing but surprise me every time I see him play..."
    scene ima2212 with dissolve
    fu "Wooow, did you see that?! The goalkeeper didn't stand a chance! I'm still amazed!"
    rd "One more thing to add: we may only see players' parents and friends in here today, but imagine the sound of a full stadium after a goal like that...what a wonderful shot!"
    scene ima2213 with dissolve
    fu "Look, look! His celebration, pointing up..."
    scene ima2214 with dissolve
    fu "To the sky...oh, my God, Rob...if you guys need some context for that, go look it up online..."
    scene ima2215a with dissolve
    fu "Beautiful!"
    scene ima2215b with dissolve
    fu "Awwww...bye, I'm gonna cry..."
    scene ima2215 with Dissolve(1.5)
    rd "No, wait, Fumino! He's looking for someone in the stands, do not miss this..."
    scene ima2216 with dissolve
    fu "Nooo, he's getting a yellow card for that..."
    rd "I don't think he cares much about it...Look! Even that guard loved the goal so much he forgot to stop him, haha..."
    fu "Nothing can stop him! Blanco's a man on a mission right now, and I know where he's heading..."
    scene ima2217 with dissolve
    fu "Oh, my God, Rob! We've been told not to bring that up, but...what a moment! What do you think she's saying to him? This's too much for me, Rob, I'm sorry..."
    rd "Perfect goal, perfect celebration...what else can I say?"
    fu "After that very serious injury, an even more difficult surgery, almost a year and a half later...he's refused to give up and is still standing, not only that, he's back on top form!"
    rd "Well said, Fumino, I see you did your homework..."
    fu "And let's not forget the recent events in his life, Rob, I don't think he even realizes what a true warrior he is!"
    rd "We're lucky he's a Citizen!"
    stop music fadeout 3
    scene black with dissolve
    scene ima2219 with Dissolve(1)
    sku "Is that him?"
    uk "Yes, ma'am."
    sku "Who fucked it up?"
    uk "Gordon, but that's been taken care of."
    play music "audio/darkambient.mp3"
    scene ima2218 with dissolve
    sku "Good. How much does the kid know?"
    uk "He knows nothing."
    sku "We can't really be sure about it, can we? Where are Franz and George?"
    uk "Same place."
    scene ima2220 with dissolve
    sku "The girl?"
    uk "With them."
    sku "William?"
    uk "Still in the city."
    scene ima2221 with dissolve
    sku "Mmm...why wouldn't he leave? We had an agreement, I smell trouble there..."
    scene ima2222 with dissolve
    vtu "Dad should've killed that man long time ago, Sarka, you know it..."
    sk "I know, brother, I know...but dad needs his toys...don't we all?"
    scene ima2221 with dissolve
    sk "What's Giuseppe Revello doing these days?"
    uk "Drinking himself to death, ma'am."
    scene ima2223 with dissolve
    vtu "Don't worry about him, we got a lot of dirt on that rat...he knows his place, won't do shit."
    sk "He's got nothing to lose now, that's a dangerous man right there...he's certainly not William, but...keep an eye on that man, Niko."
    scene ima2224 with dissolve
    nk "Yes, ma'am. Anything else?"
    sk "Yes, I want to meet Franz, we don't need any loose ends this time."
    nk "It's done. And his brother?"
    scene ima2225 with dissolve
    sk "He plays for my club! Let him play!"
    vtu "Haha, found a new toy?"
    stop music fadeout 2.5
    scene black with Dissolve(2)
    scene ima2226 with Dissolve(1)
    play music "audio/cleansuccess.mp3"

    scene ima2226:
        pause 0.0999
        "ima2226"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0999
        "ima2226"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0999
        "ima2226"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0999
        "ima2226"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0999
        "ima2226"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0999
        "ima2226"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0999
        "ima2226"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0999
        "ima2226"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0999
        "ima2226"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0999
        "ima2226"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0999
        "ima2226"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0999
        "ima2226"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0999
        "ima2226"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0999
        "ima2226"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0999
        "ima2226"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0999
        "ima2226"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0999
        "ima2226"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0999
        "ima2226"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0999
        "ima2226"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0999
        "ima2226"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0999
        "ima2226"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0999
        "ima2226"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0999
        "ima2226"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0999
        "ima2226"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0999
        "ima2226"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0999
        "ima2226"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0999
        "ima2226"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0999
        "ima2226"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0999
        "ima2226"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0999
        "ima2226"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0999
        "ima2226"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0999
        "ima2226"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0999
        "ima2226"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0999
        "ima2226"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0999
        "ima2226"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0999
        "ima2226"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0999
        "ima2226"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0999
        "ima2226"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0999
        "ima2226"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0999
        "ima2226"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0999
    pause 3
    scene ima2227 with dissolve

    scene ima2227:
        pause 0.0999
        "ima2227"
        xpos 0.5 ypos 0.7 xanchor 0.5 yanchor 0.7 zoom 1.001
        pause 0.0999
        "ima2227"
        xpos 0.5001 ypos 0.701 xanchor 0.5 yanchor 0.701 zoom 1.002
        pause 0.0999
        "ima2227"
        xpos 0.5002 ypos 0.702 xanchor 0.5 yanchor 0.702 zoom 1.003
        pause 0.0999
        "ima2227"
        xpos 0.5003 ypos 0.703 xanchor 0.5 yanchor 0.703 zoom 1.004
        pause 0.0999
        "ima2227"
        xpos 0.5004 ypos 0.704 xanchor 0.5 yanchor 0.704 zoom 1.005
        pause 0.0999
        "ima2227"
        xpos 0.5005 ypos 0.705 xanchor 0.5 yanchor 0.705 zoom 1.006
        pause 0.0999
        "ima2227"
        xpos 0.5006 ypos 0.706 xanchor 0.5 yanchor 0.706 zoom 1.007
        pause 0.0999
        "ima2227"
        xpos 0.5007 ypos 0.707 xanchor 0.5 yanchor 0.707 zoom 1.008
        pause 0.0999
        "ima2227"
        xpos 0.5008 ypos 0.708 xanchor 0.5 yanchor 0.708 zoom 1.009
        pause 0.0999
        "ima2227"
        xpos 0.5009 ypos 0.709 xanchor 0.5 yanchor 0.709 zoom 1.01
        pause 0.0999
        "ima2227"
        xpos 0.5010 ypos 0.710 xanchor 0.5 yanchor 0.710 zoom 1.011
        pause 0.0999
        "ima2227"
        xpos 0.5011 ypos 0.711 xanchor 0.5 yanchor 0.711 zoom 1.012
        pause 0.0999
        "ima2227"
        xpos 0.5012 ypos 0.712 xanchor 0.5 yanchor 0.712 zoom 1.013
        pause 0.0999
        "ima2227"
        xpos 0.5013 ypos 0.713 xanchor 0.5 yanchor 0.713 zoom 1.014
        pause 0.0999
        "ima2227"
        xpos 0.5014 ypos 0.714 xanchor 0.5 yanchor 0.714 zoom 1.015
        pause 0.0999
        "ima2227"
        xpos 0.5015 ypos 0.715 xanchor 0.5 yanchor 0.715 zoom 1.016
        pause 0.0999
        "ima2227"
        xpos 0.5016 ypos 0.716 xanchor 0.5 yanchor 0.716 zoom 1.017
        pause 0.0999
        "ima2227"
        xpos 0.5017 ypos 0.717 xanchor 0.5 yanchor 0.717 zoom 1.018
        pause 0.0999
        "ima2227"
        xpos 0.5018 ypos 0.718 xanchor 0.5 yanchor 0.718 zoom 1.019
        pause 0.0999
        "ima2227"
        xpos 0.5019 ypos 0.719 xanchor 0.5 yanchor 0.719 zoom 1.020
        pause 0.0999
        "ima2227"
        xpos 0.5020 ypos 0.720 xanchor 0.5 yanchor 0.720 zoom 1.021
        pause 0.0999
        "ima2227"
        xpos 0.5021 ypos 0.721 xanchor 0.5 yanchor 0.721 zoom 1.022
        pause 0.0999
        "ima2227"
        xpos 0.5022 ypos 0.722 xanchor 0.5 yanchor 0.722 zoom 1.023
        pause 0.0999
        "ima2227"
        xpos 0.5023 ypos 0.723 xanchor 0.5 yanchor 0.723 zoom 1.024
        pause 0.0999
        "ima2227"
        xpos 0.5024 ypos 0.724 xanchor 0.5 yanchor 0.724 zoom 1.025
        pause 0.0999
        "ima2227"
        xpos 0.5025 ypos 0.725 xanchor 0.5 yanchor 0.725 zoom 1.026
        pause 0.0999
        "ima2227"
        xpos 0.5026 ypos 0.726 xanchor 0.5 yanchor 0.726 zoom 1.027
        pause 0.0999
        "ima2227"
        xpos 0.5027 ypos 0.727 xanchor 0.5 yanchor 0.727 zoom 1.028
        pause 0.0999
        "ima2227"
        xpos 0.5028 ypos 0.728 xanchor 0.5 yanchor 0.728 zoom 1.029
        pause 0.0999
        "ima2227"
        xpos 0.5029 ypos 0.729 xanchor 0.5 yanchor 0.729 zoom 1.03
        pause 0.0999
        "ima2227"
        xpos 0.5030 ypos 0.730 xanchor 0.5 yanchor 0.730 zoom 1.031
        pause 0.0999
        "ima2227"
        xpos 0.5031 ypos 0.731 xanchor 0.5 yanchor 0.731 zoom 1.032
        pause 0.0999
        "ima2227"
        xpos 0.5032 ypos 0.732 xanchor 0.5 yanchor 0.732 zoom 1.033
        pause 0.0999
        "ima2227"
        xpos 0.5033 ypos 0.733 xanchor 0.5 yanchor 0.733 zoom 1.034
        pause 0.0999
        "ima2227"
        xpos 0.5034 ypos 0.734 xanchor 0.5 yanchor 0.734 zoom 1.035
        pause 0.0999
        "ima2227"
        xpos 0.5035 ypos 0.735 xanchor 0.5 yanchor 0.735 zoom 1.036
        pause 0.0999
        "ima2227"
        xpos 0.5036 ypos 0.736 xanchor 0.5 yanchor 0.736 zoom 1.037
        pause 0.0999
        "ima2227"
        xpos 0.5037 ypos 0.737 xanchor 0.5 yanchor 0.737 zoom 1.038
        pause 0.0999
        "ima2227"
        xpos 0.5038 ypos 0.738 xanchor 0.5 yanchor 0.738 zoom 1.039
        pause 0.0999
        "ima2227"
        xpos 0.5039 ypos 0.739 xanchor 0.5 yanchor 0.739 zoom 1.040
        pause 0.0999
    pause 3

    scene ima2229 with Dissolve(1)

    scene ima2229:
        pause 0.0999
        "ima2229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0999
        "ima2229"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0999
        "ima2229"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0999
        "ima2229"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0999
        "ima2229"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0999
        "ima2229"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0999
        "ima2229"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0999
        "ima2229"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0999
        "ima2229"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0999
        "ima2229"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0999
        "ima2229"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0999
        "ima2229"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0999
        "ima2229"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0999
        "ima2229"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0999
        "ima2229"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0999
        "ima2229"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0999
        "ima2229"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0999
        "ima2229"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0999
        "ima2229"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0999
        "ima2229"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0999
        "ima2229"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0999
        "ima2229"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0999
        "ima2229"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0999
        "ima2229"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0999
        "ima2229"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0999
        "ima2229"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0999
        "ima2229"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0999
        "ima2229"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0999
        "ima2229"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0999
        "ima2229"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0999
        "ima2229"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0999
        "ima2229"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0999
        "ima2229"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0999
        "ima2229"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0999
        "ima2229"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0999
        "ima2229"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0999
        "ima2229"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0999
        "ima2229"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0999
        "ima2229"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0999
        "ima2229"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0999
    pause 3

    scene ima2228 with Dissolve(1)

    scene ima2228:
        pause 0.0999
        "ima2228"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0999
        "ima2228"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0999
        "ima2228"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0999
        "ima2228"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0999
        "ima2228"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0999
        "ima2228"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0999
        "ima2228"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0999
        "ima2228"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0999
        "ima2228"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0999
        "ima2228"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0999
        "ima2228"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0999
        "ima2228"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0999
        "ima2228"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0999
        "ima2228"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0999
        "ima2228"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0999
        "ima2228"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0999
        "ima2228"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0999
        "ima2228"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0999
        "ima2228"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0999
        "ima2228"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0999
        "ima2228"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0999
        "ima2228"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0999
        "ima2228"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0999
        "ima2228"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0999
        "ima2228"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0999
        "ima2228"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0999
        "ima2228"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0999
        "ima2228"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0999
        "ima2228"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0999
        "ima2228"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0999
        "ima2228"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0999
        "ima2228"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0999
        "ima2228"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0999
        "ima2228"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0999
        "ima2228"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0999
        "ima2228"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0999
        "ima2228"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0999
        "ima2228"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0999
        "ima2228"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0999
        "ima2228"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0999
    play sound "audio/endgamewhistle.ogg"
    pause 3

    scene ima2230 with dissolve
    rd "And the ref blows the whistle!"
    fu "An important win to start off the season on the right foot, Rob, your thoughts?"
    stop sound
    rd "We had to win today, Fumino, and we did, but that's all."
    rd "This team still needs some adjustments: we couldn't maintain possession of the ball, Carl was invisible for the majority of the match, we only saw some individual attempts by Gilmar and Blanco today..."
    rd "When they lost their intensity in the second half, the team suffered it...Robinson's definitely going to need them this season if he wants to win matches..."
    fu "First game of the season and we won, Rob! Go easy on the boys, hehe. I have no doubts our team will improve for the next match, the more playing time the better!"
    scene ima2231 with dissolve
    fu "And well, that was all for today, Citizens! Do not miss out our next match, stay tuned for more!"
    stop music fadeout 3
    scene black with Dissolve(3)

    scene ima2232 with dissolve
    play music "audio/notthatactive.mp3"
    pause
    scene ima2233 with dissolve
    ho "Excuse me, kid..."
    scene ima2234 with dissolve
    ho "Won't you have a dollar to spare?"
    scene ima2235 with dissolve
    uk "Yes, yes, honorable man...give me one second...meep..."
    scene ima2236 with dissolve
    ho "{size=-6}Meep? What the hell?{/size}"
    scene ima2237 with dissolve
    pause 1.5
    scene ima2238 with dissolve
    uk "Excuse me, sir, aren't you..."
    ho "I'm not!"
    scene ima2239 with dissolve
    pause 1.5
    scene ima2240 with dissolve
    pause 1.5
    scene black with Dissolve(1.5)
    scene ima2241 with dissolve
    uk "Honeybee! I'm home!"
    luk "Yaaayyy!"
    scene ima2242 with dissolve
    pause 1.5
    scene ima2243 with dissolve
    luk "How was your day, baby? We missed you so much!"
    uk "I missed you, too, bunny!"
    scene ima2244 with dissolve
    uk "How's my little princess doing?"
    luk "She's been quiet as usual, well, this's week 16! According to the doctor, she's supposed to start moving by now..."
    uk "Can't wait to feel her kicking! Meep..."
    scene ima2245 with dissolve
    uk "Oh, bunny, I want to show you something!"
    scene black with dissolve
    scene ima2246 with dissolve
    uk "Tadaaa!"
    luk "Who's Blanco?"
    uk "Hehe, an amateur player I watched today...bunny, this boy scored an impossible goal, he's going to be a star! This jersey's gonna be worth thousands! We could buy a big house with this!"
    luk "Hahaha, oh baby, even if that's true, don't lie to yourself: you'd never sell it if he becomes famous..."
    uk "Haha, you know me pretty well, bunny!"
    stop music fadeout 3
    scene black with Dissolve(3)
    pause

    scene ima2420 with dissolve
    play music "audio/secret.ogg"
    vi "Are you ready for this?"
    p "Not really, no."
    vi "Well, you asked for it."
    p "I know."
    scene ima2421 with dissolve
    vi "I've been coming in here every single day, and it doesn't seem to be getting any easier, you know?"
    p "I'm sorry for having you do this..."
    scene ima2422 with dissolve
    vi "Oh, no, no need to be sorry, it's ok...I can handle it and want to help you any way I can, I know how much you loved my daughter...we all are looking for ways to deal with our pain..."
    vi "Do you have something specific in your mind?"
    p "No...I just wanted to look around and hope something brings back a beautiful memory..."
    scene ima2423 with dissolve
    vi "Yes, probably, that's the best idea, you'll know when you see it...take your time..."
    scene ima2424 with Dissolve(2)
    vi "One of her books, maybe?"
    p "She loved reading all kinds of stuff...wait a minute..."
    scene ima2425 with hpunch
    p "No way she solved The Lament Configuration!"
    vi "The what?"
    scene ima2426 with dissolve
    p "The Lament Configuration! It's like the hardest puzzle ever!"
    vi "I thought that was called \"The Tesseract\"..."
    p "The Tesse...no! Didn't you know she hated Narvel movies?"
    scene ima2427 with dissolve
    vi "I didn't know that...I do know that she loved horror movies..."
    p "Yeah, horror and indie films...this thing is from a horror movie actually...a gore and super weird movie...they used it to open up portals and summon entities..."
    scene ima2428 with dissolve
    vi "That sounds just like The Tesseract: portals, interdimensional travel..."
    p "Oh, yeah...yeah, you're right, haha, it's the same idea...I guess they're not very creative like S said, I remember one day she was all like..."
    stop music
    play sound "audio/cinematicflashback.mp3"
    scene ima2429a with Fade(0.5, 0, 0, color='#fff')
    scene ima2429b with dissolve
    scene ima2429c with dissolve
    scene ima2429 with dissolve
    play music "audio/motivacional.ogg"
    sa "They all have the same plot, cat, it's like watching the same movie over and over again!"
    scene ima2430 with dissolve
    sa "There's always this \"bad guy\" who needs to be defeated in order to save mankind...come on, Narvel! You bored us already!"
    sa "And, to add insult to injury, their \"bad guy\" is not really the bad guy..."
    scene ima2431 with dissolve
    p "How so?"
    scene ima2432 with dissolve
    sa "Give Dex to me..."
    scene ima2433 with dissolve
    p "Go on, babe, why the villain isn't the bad guy?"
    scene ima2434 with dissolve
    sa "Oh, yeah, yeah...let me ask you this: do you think this's a fair world we live in?"
    p "Fair? Not at all...you told me yourself that more than half of the world's wealth is owned by the richest 1 percent of the population..."
    scene ima2435 with dissolve
    sa "Exactly, babe, you were paying attention!"
    p "Haha, I always listen to you, cat...and well, society is far from being fair...plus we're living crazy times: war, hunger, corruption, twisted people, the list goes on..."
    scene ima2436 with dissolve
    sa "Demna agrees with you! And any \"villain\" would! Something's wrong with this world and changing it is a must! We \"villains\" exist to do so!"
    scene ima2437 with dissolve
    dem "It's necessary to destroy this unfair system to create something better! It is the hero who thinks nothing's wrong with society...the world's perfect according to them, can you believe it?!"
    p "Haha, calm down, Demna!"
    dem "No! Heroes hate change! They're ok with this brutal world and want to keep things just the way they are! Don't you see they only exist to eliminate whoever wants a better world and restore the so-called \"order\"?"
    scene ima2438 with dissolve
    dem "They're the real villains! Fuck you, Sergeant America!"
    p "Hahaha..."
    scene ima2439 with dissolve
    p "But holy fuck, cat, you're right! Those \"villains\" are not the real villains, they just want to change this fucked up world...daaamn, you just unlocked a new level up in my brain!"
    scene ima2440 with dissolve
    sa "That's why you love me so much!"
    p "Haha, it is, babe, it is..."
    stop music fadeout 3
    scene ima2441 with Dissolve(3, color='#fff')
    vi "She used to be so passionate about her ideas..."
    p "Yeah, I loved that in her, she was so full of life, I miss her so much..."
    scene ima2442 with dissolve
    vi "Why don't you keep looking, [p]? I'm sure you'll find something..."
    pt "What a stupid comment! Why did I even say that?!"
    scene ima2443 with dissolve
    play music "audio/russian5.mp3"
    pt "I'd better start looking around..."


label samroomobjects:

    call screen samroom

    screen samroom():
        add "ima2443"
        modal True

        imagebutton auto "guitar_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "guitar")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("samroomguitar")

        imagebutton auto "lamp_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "lamp")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("samroomlamp")

        imagebutton auto "book_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "book")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("samroombook")

        imagebutton auto "dexter_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "dexter")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("samroomdexter")

        imagebutton auto "picture_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "picture")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("samroompicture")

label samroomguitar:

    scene ima2443
    pt "I don't even want to see that guitar...it breaks my heart..."
    jump samroomobjects

label samroombook:

    scene ima2444
    pt "I didn't know she liked this author..."
    pt "\"In the midst of chaos, there is also opportunity.\"...I think that's from this book..."
    jump samroomobjects

label samroomlamp:

    scene ima2443
    pt "Her new lamp..."
    jump samroomobjects

label samroomdexter:

    scene ima2447
    pt "The good Dexter...where's my buddy Demna?"
    jump samroomobjects

label samroompicture:

    scene ima2445
    pt "This wasn't here, I haven't seen this picture before..."
    pt "You look so beautiful, S, I mis...wait what..."
    scene ima2446 with hpunch
    pt "This isn't an old photo...what the hell?!"
    vi "The first time you see Giuseppe with his long hair?"
    p "Yeah, I barely recognize him...when was this taken?"
    vi "Last year."
    p "Last year?"
    scene ima2448 with dissolve
    vi "Yeah, right before he started with his chemo..."
    scene ima2448 with hpunch
    pt "Chemo?! He's got cancer?!"
    scene ima2449 with dissolve
    vi "He's changed a lot ever since...not only physically..."
    pt "How come S never told me about it?! She'd been going through a lot...alone! They all have been dealing with this...where the fuck was I?!"
    p "Where's Giuseppe, Vittoria? Haven't seen him here these couple of times I've come.."
    scene ima2450 with dissolve
    vi "That's a good question, I'd like to know, too...he's never home lately and when he is doesn't say a word to me..."
    pt "Uhmm, shady as usual...he must be planning to go kill that man..."
    pt "He has cancer...shit! All's starting to make sense now...gotta talk to him soon..."
    scene ima2451 with dissolve
    vi "I'm worried about him, [p], and I can't be the partner I'd like to be, he won't let me, he's so proud...doesn't even want me to go to his chemo with him..."
    p "Everybody grieves in a different way..."
    vi "That's what my sister says...talking about her, she's been a blessing these weeks, I feel too weak most of the time and she's been my strength..."
    scene ima2452 with dissolve
    vi "But she'll be going back to France soon...I don't know what I'm gonna do without her..."
    scene ima2453 with dissolve
    p "I can come more often, Vittoria...I want to help somehow...I care about you...you promised you'll be there for me to help me be a better man, I want to be there for you, too!"
    scene ima2454 with dissolve
    vi "Thank you, [p], my Sammy chose well, you're a good person..."
    pt "I'm not."
    vi "Did you find anything?"
    stop music fadeout 3

menu:
    "Demna.":
        jump choice78a

    "The Lament Configuration.":
        jump choice78b

    "Don't take anything from her room.":
        jump choice78c

label choice78c:

    $ choice78c = True

    scene ima2455 with dissolve
    pause
    stop music
    play sound "audio/cinematicflashback.mp3"
    scene ima2456a with Fade(0.5, 0, 0, color='#fff')
    scene ima2456b with dissolve
    scene ima2456c with dissolve
    scene ima2456 with dissolve
    play music "audio/loft.ogg"
    sa "Hahaha, unbelievable...come here, cat, look at this!"
    p "I can never see anything, only lights, babe, watery lights..."
    scene ima2457 with dissolve
    sa "Haha, told ya! Come, come!"
    p "What...what is it?"
    scene ima2458 with dissolve
    sa "Look! What do you think that is?!"
    p "Uhm, a blurred candle? A low-resolution flame? Oh, I know! Your phone was in your pants and took a picture by accident..."
    sa "Haha, nope, believe it or not, it's a 20 billion-dollar picture..."
    p "Yeah, right, no way a crap like that costs twenty billion, babe..."
    scene ima2459 with dissolve
    sa "I'm not kidding, it does, that's FASA's annual budget! You're looking at the first-ever picture of a black hole...according to them obviously!"
    p "What the hell?! That can be anything..."
    scene ima2460 with dissolve
    sa "That's what I've been telling you: they're liars! This is what they do with taxpayers' money, instead of solving the homelessness crisis or improving our health care system! It's ridiculous!"
    p "Yeah, I'll give you that, if that's the kind of photos they're giving us, well...yeah...it looks like a bad joke..."
    sa "Go to their official website, you'll see everything is computer generated...CGIs, that's all they show!"
    p "You know I'm gonna look into it, but I'm afraid of what I'll find out, cat...is it gonna be shocking?"
    scene ima2461 with dissolve
    sa "Besides realizing that there's no space, nah, I don't think so..."
    scene ima2461 with hpunch
    p "What?! What are you talking about, babe?! Don't tell me that, I love space! Aliens, The Covenant...Commander Shepard!"
    scene ima2462 with dissolve
    sa "Haha, those are all pretty good sci-fi stories, aren't they?"
    p "Babe! You're the most intelligent person I know, seriously, and I'm sure you'll end up convincing me of whatever you have in that brain of yours...but I'm not ready..."
    scene ima2463 with dissolve
    sa "Cat, I used to love space just like you...loved it so much in fact that I needed to know everything...and here I am! I finally know everything!"
    sa "Only the truth will set us free!"
    stop music fadeout 3
    scene ima2464 with Dissolve(3, color='#fff')
    p "I don't want to take anything from here, Vittoria, I want to keep her room as it is right now, but I'd like to come more often...you know, besides keeping you company, being here can help me heal..."
    scene ima2454 with dissolve
    vi "Sure, honey, you can come whenever you want..."
    scene ima2465 with dissolve
    vi "Thank you for loving my daughter the way you did...still do..."
    scene ima2466 with dissolve
    pause

    jump choice78_common

label choice78a:

    $ choice78a = True

    scene ima2455 with dissolve
    pause
    scene ima2464 with dissolve
    p "I may have found what I want..."
    scene ima2465 with dissolve
    vi "Hope it helps with your healing process."
    p "I hope that too..."
    scene ima2466 with dissolve
    pause

    jump choice78_common

label choice78b:

    $ choice78b = True

    scene ima2464 with dissolve
    p "Yeah, I have something in mind..."
    scene ima2454 with dissolve
    vi "I'm glad to hear that."
    scene ima2465 with dissolve
    vi "I hope it helps you heal somehow."
    p "I hope that too..."
    scene ima2466 with dissolve
    pause

    jump choice78_common

label choice78_common:

    scene black with Dissolve(3)
    pause

if choice78a:

    scene ima2467 with Dissolve(2)
    play music "audio/escapingforever.mp3"
    pause
    pt "If I hadn't met you, you'd still be alive..."
    scene ima2468 with dissolve
    pt "I would've never gotten into college if I hadn't had my leg broken..."
    scene ima2469 with dissolve
    pt "If Diaz hadn't broken my leg..."
    scene ima2470 with dissolve
    pt "Diaz."
    stop music fadeout 2.5
    jump startinjuryrevenge

if choice78b:

    scene ima2467 with Dissolve(2)
    play music "audio/escapingforever.mp3"
    pause
    pt "If I hadn't met you, you'd still be alive..."
    scene ima2471 with dissolve
    pt "I would've never gotten into college if I hadn't had my leg broken..."
    scene ima2469 with dissolve
    pt "If Diaz hadn't broken my leg..."
    scene ima2470 with dissolve
    pt "Diaz."
    stop music fadeout 2.5
    jump startinjuryrevenge

if choice78c:

    scene ima2467 with Dissolve(2)
    play music "audio/escapingforever.mp3"
    pause
    pt "If I hadn't met you, you'd still be alive..."
    scene ima2472 with dissolve
    pt "I would've never gotten into college if I hadn't had my leg broken..."
    scene ima2469 with dissolve
    pt "If Diaz hadn't broken my leg..."
    scene ima2470 with dissolve
    pt "Diaz."
    stop music fadeout 2.5
    jump startinjuryrevenge

label startinjuryrevenge:

    scene black with Dissolve(3)
    play music "audio/readyornot.mp3"
    scene ima2248 with dissolve
    pt "Second match of the season and we're already here..."
    pt "This stadium..."
    scene ima2249 with dissolve
    pause 0.5
    pt "That piece of shit..."
    scene ima2250 with dissolve
    pause
    scene ima2247a with dissolve
    pt "I remember you, son of a bitch..."
    scene ima2247 with dissolve
    pt "Like it was yesterday..."
    scene ima2251 with dissolve
    pt "Come on, look at me! We'll see if you keep that smile..."
    scene ima2252 with dissolve
    pause
    scene black with dissolve
    scene ima2253 with Dissolve(1)
    cj "Daaammnn, I'm hyped up about this match, homie! Pay back time!"
    gil "If you don't do it, I do it! That puta is gonna taste my elbow!"
    scene ima2254 with dissolve
    uk "Hey, [p]! We are with you!"
    p "You too, Smith?!"
    sm "I don't like dirty players like Diaz...he's gonna get it!"
    scene ima2255 with Dissolve(0.3)

    play sound "audio/cardentrance.mp3" volume 2
    scene ima2255a with Dissolve(0.00004)
    scene ima2255b with Dissolve(0.00004)
    scene ima2255c with Dissolve(0.00004)
    scene ima2255d with Dissolve(0.00004)
    scene ima2255e with Dissolve(0.00004)
    scene ima2255f with Dissolve(0.00004)
    scene ima2255g with Dissolve(0.00004)
    scene ima2255h with Dissolve(0.00004)
    scene ima2255i with Dissolve(0.00004)
    scene ima2255j with Dissolve(0.00004)
    scene ima2255k with Dissolve(0.00004)
    scene ima2255l with Dissolve(0.00004)
    scene ima2255m with Dissolve(0.00004)
    scene ima2255n with Dissolve(0.00004)
    scene ima2255o with Dissolve(0.00004)
    scene ima2255p with Dissolve(0.00004)
    scene ima2255q with Dissolve(0.00004)
    scene ima2255r with hpunch
    pt "Randy \"Cerberus\" Smith, 21 years old, central defender..."
    pt "The cleanest defender I've seen, although he gets a red card every two games...How so? Well, he's simply too strong..."
    pt "He always goes for the ball, unlike Diaz, but if you make the slightest contact with him, that's it, you're going to the hospital with a fractured bone...it's like bumping into stone!"
    scene ima2256 with dissolve
    pt "\"The Dog of War\" and \"Cerberus\"...man, that's a sick defense right there...\"The Hounds of Destruction!\""
    pt "They're the best defensive pairing in the league by far. Probably the main reason why Ethan's still unbeaten after two seasons..."
    scene ima2257 with dissolve
    pause 0.5
    scene ima2258 with dissolve
    pt "Kalvin and Smith in the center, a violent Adams on the left, a crazy Joker on the right...pft, come on! Don't play, it's useless, quit and go home!"
    pt "Yeah, we definitely have the best defense, but our attack needs to improve..."
    scene ima2259 with dissolve
    pt "CJ, my boy, can score impossible goals and, at the same time, miss an open goal..."
    scene ima2260 with dissolve
    pt "Gilmar's fast and very skilled, but hogs the ball way too much...the only angry Brazilian I know of, hehe..."
    pt "He wasn't even in the team when I got injured, but has my back today...he says he knows about codes, about loyalty, and he's about to prove it..."
    scene ima2261 with dissolve
    pt "All these guys are ready to go to war with me..."
    scene ima2264 with dissolve
    pt "We're like The Ginyu Force..."
    scene ima2262 with Dissolve(2)
    pt "Gilmar would be Guldo..."
    scene ima2263 with dissolve
    pause 1
    scene ima2265 with Dissolve(0.0066)
    scene ima2266 with Dissolve(0.0066)
    scene ima2267 with Dissolve(0.0066)
    scene ima2266 with Dissolve(0.0066)
    scene ima2265 with Dissolve(0.0066)
    scene ima2268 with Dissolve(0.0066)
    scene ima2269 with Dissolve(0.0066)
    scene ima2268 with Dissolve(0.0066)
    scene ima2265 with Dissolve(0.0066)
    scene ima2266 with Dissolve(0.0066)
    scene ima2267 with Dissolve(0.0066)
    scene ima2266 with Dissolve(0.0066)
    scene ima2265 with Dissolve(0.0066)
    scene ima2268 with Dissolve(0.0066)
    scene ima2269 with Dissolve(0.0066)
    scene ima2268 with Dissolve(0.0066)
    scene ima2265 with Dissolve(0.0066)
    scene ima2264 with dissolve
    pt "Focus! Do not get lost in your thoughts, you got a job to do!"
    scene ima2261 with dissolve
    stop music fadeout 3

menu:
    "Break that fucking cunt yourself!":
        jump choice79a

    "I'm a pussy.":
        jump choice79b

label choice79a:

    $ choice79a = True

    pt "You're mine, bitch!"
    play sound "audio/whistle.mp3"
    scene black with dissolve
    play music "audio/adrenalinerush.mp3"
    scene ima2272 with dissolve
    pt "I don't give a fuck about this game, there's only one thing in my mind right now: Revenge!"
    pt "This is personal, he almost ruined my life! Come on, give him the ball!"
    scene ima2274 with dissolve
    pt "It looks like we all have the same thing in mind...let's go CJ!"
    scene ima2275 with dissolve
    pt "They're giving it all to get the ball, yeah, that's my team!"
    scene ima2276 with dissolve
    pt "Haha, so easy."
    scene ima2277 with dissolve
    ada "[p]!"
    scene ima2280 with dissolve
    pt "That's a perfect pass!"
    scene ima2279 with Dissolve(1)
    pt "Hahaha, well done, Adams!"
    scene ima2278 with dissolve
    pt "You want to see the world burn already, don't you?"
    scene ima2281 with dissolve
    pt "Fuck this game...you're gonna get fucked, Diaz!"
    scene ima2282 with dissolve

    scene ima2282:
        pause 0.0233
        "ima2283"
        pause 0.0233
        "ima2284"
        pause 0.0233
        "ima2285"
        pause 0.0233
        "ima2286"
        pause 0.0233
        "ima2287"
        pause 0.0233
        "ima2288"
        pause 0.0233
        "ima2289"
        pause 0.0233
        "ima2290"
        pause 0.0233
        "ima2291"
        pause 0.0233
        "ima2292"
        pause 0.0233
        "ima2293"
        pause 0.0233
        "ima2294"
        pause 0.0233
        "ima2295"
        pause 0.0233
        "ima2296"
        pause 0.0233
        "ima2297"
        pause 0.0233
        "ima2298"
        pause 0.0233
        "ima2299"
        pause 0.0233
        "ima2300"
        pause 0.0233
        "ima2301"
        pause 0.0233
        "ima2302"
        pause 0.0233
        "ima2303"
        pause 0.0233
        "ima2304"
        pause 0.0233
        "ima2305"
        pause 0.0233
        "ima2306"
        pause 0.0233
        "ima2307"
        pause 0.0233
        "ima2308"
        pause 0.0233
        "ima2309"
        pause 0.0233
        "ima2310"
        pause 0.0233
        "ima2311"
        pause 0.0233
        "ima2312"
        pause 0.0233
        "ima2313"
        pause 0.0233
        "ima2314"
        pause 0.0233
        "ima2315"
        pause 0.0233
        "ima2316"
        pause 0.0233
        "ima2317"
        pause 0.0233
        "ima2318"
        pause 0.0233
        "ima2319"
        pause 0.0233
        "ima2320"
        pause 0.0233
        "ima2321"
        pause 0.0233
        "ima2322"
        pause 0.0233
        "ima2323"
        pause 0.0233
        "ima2324"
        pause 0.0233
        "ima2325"
        pause 0.0233
        "ima2326"
        pause 0.0233
        "ima2327"
        pause 0.0233
        "ima2328"
        pause 0.0233
        "ima2329"
        pause 0.0233
        "ima2330"
        pause 0.0233
    play sound "audio/bonebreaking.mp3"
    pause
    play sound "audio/whistle1.mp3"
    scene ima2331 with dissolve
    pt "I did it...I felt it break!"
    gil "Porra!"
    scene ima2332 with dissolve
    gil "Nothing, ref! All ball!"
    scene ima2333 with Dissolve(1)
    pause
    stop music fadeout 3
    scene black with Dissolve(2)
    scene ima2334 with Dissolve(1)
    pause
    play music "audio/shower2.ogg"
    scene ima2335 with Dissolve(1)
    pause
    scene ima2336 with Dissolve(1)
    pause
    scene ima2337 with Dissolve(1)
    pause
    scene ima2338 with Dissolve(1)
    pause
    scene ima2339 with Dissolve(1)
    pt "What am I doing?"
    scene ima2340 with Dissolve(1)

    call screen markpunchwall

    screen markpunchwall():
        add "ima2340"
        modal True

        imagebutton auto "fist_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "fist")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("markpunchwallend")

label markpunchwallend:

    play sound "audio/triplepunchfast.mp3"
    scene ima2340:
        pause 0.0233
        "ima2341"
        pause 0.0233
        "ima2342"
        pause 0.0233
        "ima2343"
        pause 0.0233
        "ima2344"
        pause 0.0233
        "ima2345"
        pause 0.0233
        "ima2346"
        pause 0.0233
        "ima2347"
        pause 0.0233
        "ima2348"
        pause 0.0233
        "ima2349"
        pause 0.0233
        "ima2350"
        pause 0.0233
        "ima2351"
        pause 0.0233
        "ima2352"
        pause 0.0233
        "ima2353"
        pause 0.0233
        "ima2354"
        pause 0.0233
        "ima2355"
        pause 0.0233
        "ima2356"
        pause 0.0233
        "ima2357"
        pause 0.039
        "ima2358"
        pause 0.039
        "ima2359"
        pause 0.039
        "ima2360"
        pause 0.039
        "ima2361"
        pause 0.039
        "ima2362"
        pause 0.039
        "ima2363"
        pause 0.039
        "ima2364"
        pause 0.039
        "ima2365"
        pause 0.039
        "ima2356"
        pause 0.039
        "ima2357"
        pause 0.0366
        "ima2358"
        pause 0.0366
        "ima2359"
        pause 0.0366
        "ima2360"
        pause 0.0366
        "ima2361"
        pause 0.0366
        "ima2362"
        pause 0.0366
        "ima2363"
        pause 0.0366
        "ima2364"
        pause 0.0366
        "ima2365"
        pause 0.0366
        "ima2356" with hpunch
        pause 0.0366
        "ima2356" with hpunch
        pause 0.0366
    pause

    scene ima2366 with Dissolve(1)
    pt "Why did you have to do it?"
    scene ima2356a with Dissolve(2.5)
    pt "What did you see in me?"
    scene ima2367 with Dissolve(2)
    pt "I did nothing!"
    pt "I'm so sorry..."

    stop music fadeout 2.0
    stop sound

    jump endinjury

label choice79b:

    $ choice79b = True

    scene ima2261 with dissolve
    scene ima2270 with dissolve
    pause 1
    scene ima2271 with dissolve
    gil "Leave that little bitch to me!"
    play sound "audio/whistle.mp3"
    scene black with dissolve
    play music "audio/stompitaway.ogg"
    scene ima2368 with dissolve
    pt "I wish I could blame this motherfucker for S's death...it would be so much easier..."
    scene ima2369 with dissolve
    pt "{i}\"He wanted you.\"{/i}"

    stop music
    play sound "audio/breathwoosh.mp3"

    scene flashback1:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.5
        pause 0.0666
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
    pause 0.1162

    scene ima2369 with dissolve
    pt "Jesus!" with vpunch
    pt "I don't want to get used to that shit..."
    pt "But who wanted me? And why? I need to talk to that baldhead..."
    play sound "audio/hey.mp3"
    sm "Hey, [p], wake up!" with vpunch
    p "Yeah, yeah, I'm here!"
    play sound "audio/rockburn.ogg"
    scene ima2370 with dissolve
    pt "That smile's infuriating..."
    scene ima2371 with dissolve
    pt "Huh?"
    scene ima2372 with dissolve
    pause
    scene ima2373 with dissolve
    p "You think you can dribble past me? I'm right here, you bitch!"
    scene ima2374 with dissolve
    pause
    scene ima2375 with dissolve
    pt "What the..."
    scene ima2376 with dissolve
    pt "He's giving me the ball? Why?"
    scene ima2376 with vpunch
    pt "Oh, this fucker wants to tackle me!"
    scene ima2377 with dissolve
    pt "You son of a bitch! I can't believe I was giving you a free p..."
    play music "audio/manscreaming.mp3" fadein 2
    scene ima2377 with Dissolve(1)
    scene ima2378:
        pause 0.0166
        "ima2379"
        pause 0.0166
        "ima2380"
        pause 0.0166
        "ima2381"
        pause 0.0166
        "ima2382"
        pause 0.0166
        "ima2383"
        pause 0.0166
        "ima2384"
        pause 0.0166
        "ima2385"
        pause 0.0166
        "ima2386"
        pause 0.0166
        "ima2387"
        pause 0.0236
        "ima2388"
        pause 0.0236
        "ima2389"
        pause 0.0236
        "ima2390"
        pause 0.0236
        "ima2391"
        pause 0.0236
        "ima2392"
        pause 0.0236
        "ima2393"
        pause 0.0236
        "ima2394"
        pause 0.0236
        "ima2395"
        pause 0.0236
        "ima2396"
        pause 0.0236
        "ima2397"
        pause 0.0236
        "ima2398"
        pause 0.0236
        "ima2399"
        pause 0.0236
        "ima2400"
        pause 0.0236
        "ima2401"
        pause 0.0236
        "ima2402"
        pause 0.0236
        "ima2403"
        pause 0.0233
        "ima2404" with hpunch
        pause 0.0233
        "ima2405" with hpunch
        pause 0.0233
        "ima2406" with hpunch
        pause 0.0233
    play sound "audio/kick.mp3"
    stop music fadeout 0.5
    pause
    gil "Take that, puta!"
    p "Holy fuck!" with vpunch
    pt "You had it coming, Diaz..."
    play sound "audio/whistle1.mp3"
    scene ima2407 with dissolve
    play music "audio/training.mp3"
    p "That was a nasty K.O., brother!"
    cj "He won't be smiling again!"
    scene ima2408 with dissolve
    gil "What the hell, man?! I didn't do nothing to this puta!"
    pt "Gilmar's crazy! He even complains about the red card, hahaha. That should be jail, bruh!"
    pt "Man, I was so naive...should've done something...Diaz was a reeeal piece of shit!"
    scene black with dissolve
    scene ima2409 with dissolve
    pause
    scene ima2410 with dissolve
    pt "What the hell? Why are they all coming after me?"
    scene ima2411 with dissolve
    coa "This's not going to end up well, they want to hurt the kid...the whole fucking team plays like that..."
    scene ima2412 with dissolve
    coa "Arthur! Get ready!"
    scene black with dissolve
    scene ima2413 with dissolve
    pause
    scene ima2413 with hpunch
    pt "What?!"
    scene ima2414 with dissolve
    p "Come on, coach! Let me play!"
    scene ima2415 with dissolve
    pt "No, don't argue, he already made the substitution..."
    pt "Besides, he brought me back, show some respect for the old man, he knows what he's doing...I guess that's it for me today..."
    scene ima2416 with dissolve
    pt "Fuck! I really wanted to defeat these bastards..."
    stop music fadeout 3

    jump endinjury

label endinjury:

    scene black with Dissolve(3)
    pause

    jump ep7
