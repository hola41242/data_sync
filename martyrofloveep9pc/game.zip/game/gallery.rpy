
#Gallery

define config.enter_replay_transition = dissolve


screen gallery():
    tag menu
    add "vittoriaback"

    textbutton _("Return"):
        style "return_button"
        action Return()

    default page = 1
    hbox:
        xalign 0.8
        yalign 0.85
        textbutton "1" action SetScreenVariable("page", 1)
        textbutton "2" action SetScreenVariable("page", 2)
        textbutton "3" action SetScreenVariable("page", 3)

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20
        if page ==1:
            grid 3 3:
                spacing 10
                vbox:
                    imagebutton auto"Gallery/samsex1_%s.png" insensitive"Gallery/samsex1_idle.png" action Replay("samsex1")

                vbox:
                    imagebutton auto"Gallery/samsex2_%s.png" insensitive"Gallery/samsex2_idle.png" action Replay("samsex2")

                vbox:
                    imagebutton auto"Gallery/camsex1_%s.png" insensitive"Gallery/camsex1_idle.png" action Replay("camsex1")

                vbox:
                    imagebutton auto"Gallery/valesex1_%s.png" insensitive"Gallery/valesex1_idle.png" action Replay("valesex1")

                vbox:
                    imagebutton auto"Gallery/vanesex1_%s.png" insensitive"Gallery/vanesex1_idle.png" action Replay("vanesex1")

                vbox:
                    imagebutton auto"Gallery/camsex2_%s.png" insensitive"Gallery/camsex2_idle.png" action Replay("camsex2")

                vbox:
                    imagebutton auto"Gallery/piasex1_%s.png" insensitive"Gallery/piasex1_idle.png" action Replay("piasex1")

                vbox:
                    imagebutton auto"Gallery/destinysex1_%s.png" insensitive"Gallery/destinysex1_idle.png" action Replay("destinysex1")

                vbox:
                    imagebutton auto"Gallery/chrissex1_%s.png" insensitive"Gallery/chrissex1_idle.png" action Replay("chrissex1")

        if page ==2:
            grid 3 3:
                spacing 10
                vbox:
                    imagebutton auto"Gallery/ameliasex1_%s.png" insensitive"Gallery/ameliasex1_idle.png" action Replay("ameliasex1")

                vbox:
                    imagebutton auto"Gallery/brendasex1_%s.png" insensitive"Gallery/brendasex1_idle.png" action Replay("brendasex1")

                vbox:
                    imagebutton auto"Gallery/vanesex2_%s.png" insensitive"Gallery/vanesex2_idle.png" action Replay("vanessasex2")

                vbox:
                    imagebutton auto"Gallery/brendasex2_%s.png" insensitive"Gallery/brendasex2_idle.png" action Replay("brendasex2")

                vbox:
                    imagebutton auto"Gallery/camsex3_%s.png" insensitive"Gallery/camsex3_idle.png" action Replay("camsex3")
            
                vbox:
                    imagebutton auto"Gallery/ellesex1_%s.png" insensitive"Gallery/ellesex1_idle.png" action Replay("ellesex1")                
                
                vbox:
                    imagebutton auto"Gallery/vanesex3_%s.png" insensitive"Gallery/vanesex3_idle.png" action Replay("vanesex3")             

                vbox:
                    imagebutton auto"Gallery/djsex1_%s.png" insensitive"Gallery/djsex1_idle.png" action Replay("djsex1")
            
                vbox:
                    imagebutton auto"Gallery/notyet_%s.png" insensitive"Gallery/notyet_idle.png" action Replay("notyet")
