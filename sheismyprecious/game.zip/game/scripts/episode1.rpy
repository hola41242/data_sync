label game_start:
    menu:
        "Play latest update (Episode [latest_episode])":

            $ D_p = 11
            $ Alecia_p = 1
            $ Sophie_p = 1
            $ Eileen_p = 4
            $ Maya_p = 1
            $ Carla_p = 2
            $ Charlie_p = 0

            $ ep1_confess = True
            $ ep1_eileen_fav  = True
            $ ep1_alecia_grab = True
            $ ep1_door_peek = True


            $ ep2_belt_method = "lube"
            $ ep2_belt_look = True
            $ ep2_bra_fall = True
            $ ep2_listen_talk = True
            $ ep2_eileen_handy = True
            $ ep2_d_kiss = "forehead"

            $ ep3_d_movie = "horror"
            $ ep3_panties = "release"
            $ ep3_celebration = "birthyear"
            $ ep3_eileen_buttjob = "accepted"
            $ ep3_job_return = "accept"
            $ ep3_d_kiss = "forehead"
            $ ep3_d_grind = "still"
            $ ep4_guilt = True

            $ ep4_hotel_FAP = "seen" 
            $ ep4_d_kiss = "forehead"
            $ ep4_d_breasts = "release"
            $ ep4_d_sauna_fall = "yes"
            $ ep4_stairs_prior = "D"
            $ ep4_d_movie_fap = "looked"
            $ ep4_d_shower_look = "yes"
            $ ep4_d_bed_hump = "yes"
            $ ep4_carla_nude = "yes"

            python:
                pov_mc = renpy.input("What is your name?", length=32,screen="input")
                pov_mc = pov_mc.strip()

                if not pov_mc:
                    pov_mc = "Emsy"
            define X = Character("[pov_mc]")

            python:
                pov_d = renpy.input("What is her name?", length=32,screen="input")
                pov_d = pov_d.strip()

                if not pov_d:
                    pov_d = "Vera"



            jump ep5_greenhouse
        "Start from the beginning":
            pass
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    $renpy.music.stop(channel=u'ambience', fadeout=None)
    $renpy.music.stop(channel=u'sound', fadeout=None)
    $quick_menu = False
    scene ep1_000_black with dissolve
    python:
        pov_mc = renpy.input("What is your name?", length=32,screen="input")
        pov_mc = pov_mc.strip()

        if not pov_mc:
            pov_mc = "Emsy"
    define X = Character("[pov_mc]")
    pause 0.5
    show screen series_title
    pause 5.5
    hide screen series_title
    show screen episode_title("Episode 1","An Old Hope")
    pause 5.5
    hide screen episode_title

label ep1_01_dream:
    $renpy.music.play("audio/ambience/seawaves_calm.ogg", channel=u'ambience', loop=True, fadein=3)
    $renpy.music.play("audio/music/intro_dream_2.ogg", channel=u'music', loop=True, fadein=3)
    scene ep1_001_sky with curtains_slow
    $quick_menu = True
    X "You don't have to leave."
    show ep1_dream_bird
    X "We can run away instead!"
    Emily "It's the final year for us."
    scene ep1_002_Emily_side with ml
    Emily "If we leave now, then going to university is out of the picture."
    Emily "Also you did promise to shoot for first place this year."
    scene ep1_003_Emily_side_low with ml
    X "And what about you?"
    scene ep1_005_Emily_head_side with ml
    Emily "They said it's a really nice school."
    scene ep1_006_Emily_head_back with ml
    Emily "I can get anything I need, so it's fine."
    X "That's good."
    scene ep1_002_Emily_side with ml
    Emily "We can meet here next summer. Same place."
    X "Same time."
    Emily "It's a promise."
    scene ep1_003_Emily_side_low with ml
    X "I'll be be here waiting."
    show ep1_dream_bird with ml
    X "Hey, does it seem hotter today?"
    scene ep1_002_Emily_side with ml
    Emily "A bit. Want to go for a swim?"
    scene ep1_004_Emily_back with ml
    X "What you got a swimsuit under there?"
    Emily "No..."
    scene ep1_002_Emily_side with ml
    X "Do you... need some space?"
    Emily "No..."
    Emily "I don't mind."
    Emily "Do you want to look?"
    scene ep1_007_Emily_side_anim_START with ml
    X "I... yes. I want to!"
    $renpy.movie_cutscene("animations/ep1/ep1_dream_emily_raise_hand.webm", delay=None, loops=0, stop_music=False)
    show ep1_008_Emily_side_anim_END
    X "Emily."
    scene ep1_012_Emily_strap_front_low with ml
    Emily "Yes?"
    scene ep1_011_Emily_strap_front with ml
    X "It's the last day we get."
    scene ep1_009_Emily_strap_close with ml
    X "We won't see each other for a long time."
    scene ep1_010_Emily_strap_head with ml
    Emily"True."
    Emily"We should make the most of it then."
    scene ep1_013_Emily_strap_anim_START with ml
    X "Agreed!"
    $renpy.movie_cutscene("animations/ep1/ep1_dream_emily_lower_strap.webm", delay=None, loops=0, stop_music=False)
    show ep1_014_Emily_strap_anim_END
    Emily "Can you give me a hand..."
    scene ep1_000_black with dissolve
    pause 2
    $renpy.music.play("audio/music/intro_dream_5.ogg", channel=u'music', loop=True, fadein=2,fadeout=2)
    scene ep1_015_Emily_ride_kiss with dissolve
    "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}💕💋💞{/font}"
    scene ep1_017_Emily_ride_back with ml
    Emily "You've gotten better at this!"
    X "I've been practicing."
    Emily "Really? How?"
    scene ep1_016_Emily_ride_side with ml
    X "With you, in my dreams..."
    scene ep1_018_Emily_prone_between with ml
    X "I'm putting in slowly, tell me if it hurts."
    scene ep1_019_Emily_prone_under with ml
    Emily "Keep going."
    scene ep1_020_Emily_prone_side with ml
    Emily "Aaa!"
    scene ep1_021_Emily_prone_above with ml
    Emily "Hold like this for a moment..."
    pause 1
    scene ep1_023_Emily_missionary_side_embrace with ml
    Emily"...it's better now."
    scene ep1_025_Emily_missionary_LOOP with ml
    X "Here I go!"

    scene ep1_dream_sex_slow with animf
    pause 3
    Emily "Just like that! Yes!"
    scene ep1_025_Emily_missionary_LOOP with animf
    X "You feel so good [Emily]!"
    X "I'm already close."
    Emily "I want to go all the way with you [X]."
    Emily "So don't stop!"
    X"[Emily]..."
    scene ep1_dream_sex with animf
    pause 3
    X "It's too good!"
    menu:
        "Give her your love":
            X "I want to give you everything [Emily]!"
    Emily "I'm all yours [X]!"
    scene ep1_dream_sex_finish with animf
    pause 5.0
    scene ep1_026_Emily_missionary_inside with animfo
    X "[Emily]!"
    Emily"[X]!"
    scene ep1_022_Emily_missionary_side with ml
    Emily"I feel it all!"
    scene ep1_024_Emily_missionary_faces with ml

    X "I need to tell you something."
    X "I wanted to say it for a long time."
    Emily "Say what?"
    menu:
        Emily "{cps=0}Say what?"
        "Say it":
            $ep1_confess = True
            X "I want you to know that I--"
            #suddenly waking up
            scene ep1_000_black with dissolve
            X "I love you Emily!"
        "Hesitate":
            $ep1_confess = False
            X "You know!"
            Emily "I don't. What is it?"
            X "It's that..."

            scene ep1_000_black with dissolve
            pause 1
    $renpy.music.stop(channel=u'music', fadeout=None)
    $renpy.music.stop(channel=u'ambience', fadeout=None)
    $renpy.music.play("audio/sfx/ringtone_1.ogg", channel=u'sound', loop=True, fadein=16)
    scene ep1_027_room_mc_ceiling with eye_open
    scene ep1_028_room_mc_phone with ml
    X"What time is it?"
    scene ep1_029_room_mc_phone_pick with ml
    X"And who would be calling?"
    $renpy.music.stop(channel=u'sound', fadeout=None)
    scene ep1_031_room_mc_phone_answer with ml



    X "Hello?"
    Maya "Good morning [X], it's [Maya] from the orphanage."
    X "[Maya], yes, good morning!"
    Maya "We talked some time ago about what we needed here."
    X "I remember. What came up?"
    Maya "You mentioned tutoring as one of the jobs."
    X "That's right. But I need to brush up first."
    Maya "Of course. There are 2 girls who are in need."
    Maya "The thing is with mathematics, if you can do more advanced stuff."
    scene ep1_032_room_mc_bed_side with ml
    X "How advanced are we talking?"
    Maya "National Olympiad level."
    Maya "She has won a few on national."
    X "I see. If it's just the math then it's doable."
    Maya "I don't want it be too much trouble for you."
    X "With just 2 students it should be fine."
    scene ep1_031_room_mc_phone_answer with ml
    Maya "I thought about your line of work. Data engineering right?"
    X "Yes."
    Maya "You apply math regularly no?"
    X "That's correct. So it's right up my alley."
    Maya "And so can we come by this afternoon?"
    X "I'm open."
    Maya "Great! We'll meet you then."
    scene ep1_034_room_mc_bed_laying with ml
    "Same dream again."
    scene ep1_033_room_mc_bed_sitting with ml
    "Still can't remember her face..."
    scene ep1_304_room_mc_washingmachine with ml
    "Same dream on the same day."
    scene ep1_305_room_mc_sink_water_run with ml
    "Maybe they found something about her."
    scene ep1_307_room_mc_sink_water_hold with ml
    "Probably not."
    scene ep1_000_black with ml
    pause 1
    scene ep1_306_room_mc_sink_water_run_alt with ml
    "[Charlie] would call if anything came up..."
    scene ep1_035_hallway_day with downtop
    pause 2
    $renpy.music.play("audio/music/morning-routine-house.ogg", channel=u'music', loop=True, fadein=5,fadeout=5)
    scene ep1_036_floor_up_day with ml
    pause 2
    scene ep1_037_floor_down_stairs with ml
    pause 2
    scene ep1_040_kitchen_fridge_empty with ml
    "Of course it's empty, I barely live here."
    scene ep1_038_kitchen_coffee_make with ml
    "Restocking for about a week should do it."
    scene ep1_039_kitchen_coffee_take with ml
    "At least the coffee is in ample supply."
    scene ep1_041_office_laptop_open with downtop
    "3 days worth of mails, let's get to it."
    scene ep1_042_office_laptop_login with ml
    "Is the system down?"
    scene ep1_043_leave_house_keys_pick with downtop
    "Screw it! I'll check them later."



    scene ep1_044_car_shift with rightleft
    $renpy.music.play("audio/ambience/car-interior-driving-02.ogg", channel=u'ambience', loop=True, fadein=3)
    pause 2
    scene ep1_045_car_call_button with ml
    pause 2
    scene ep1_046_car_call_work with ml

    Brad "Yeah?"
    X "Hey [Brad]. How are things at base, any crashes?"
    X "I can't log in to the system."
    Brad "[X] you haven't heard?!"
    X "Hear what?"
    Brad "The new owner fired the whole department!"
    scene ep1_047_car_call_work_talk with ml

    X "You're fucking with me."
    Brad "Read the mail dude."
    X "I didn't get any."
    Brad "The company mail."
    scene ep1_048_car_call_work_talk2 with ml

    X "I can't get in the system because they locked me out!"
    Brad "Oh right."
    Brad "I'll send you a copy then."
    scene ep1_046_car_call_work with ml

    X "Thanks. Were you there when it happened?"
    Brad "Yeah. He called us in for a briefing."
    Brad "Gave a speech for 2 minutes and told everyone to clean out their desks."
    scene ep1_048_car_call_work_talk2 with ml
    X "Why the fuck did he fire everyone?"
    Brad "I'm really not sure. He was going on about 'freezing peaches' or something."
    scene ep1_047_car_call_work_talk with ml
    X "What?!"
    Brad "I don't know man. Anyway my lawyer said it's an easy suit."
    Brad "So there's that."
    scene ep1_044_car_shift with ml
    X "I bet."
    Brad "I'm already set with a new job though."
    X "Damn you don't waste a second!"
    scene ep1_049_car_drive with ml
    Brad "I figured it might happen since so many were leaving. So I was preped for it."
    Brad "If you need work I can talk to a friend."
    X "Thanks, I'll think about it."
    Brad "Well I need to go. I'll be seeing you!"
    scene ep1_045_car_call_button with ml
    X "Take care man."
    scene ep1_049_car_drive with ml
    "Guess I'll extend my vacation here..."
    $renpy.music.stop(channel=u'ambience', fadeout=None)
    scene ep1_050_store_jam with rightleft
    "Whoa, blackberry jam this time!"
    scene ep1_051_store_sauce with ml
    "Can't find the sauce, but these are better."
    scene ep1_052_store_sugar with ml
    "This will be handy if the sauce turns up too sour."
    scene ep1_053_store_rice with ml
    "Some rice would be nice."
    scene ep1_054_store_bread with ml
    "[Eileen] would never forgive me if I got bread from somewhere else."
    scene ep1_055_store_ready_meals with ml
    "No I got time to cook, don't need these."
    scene ep1_056_store_onions_potatoes with ml
    "Potatoes, onions and then there's..."


    $renpy.music.play("audio/music/morning-routine-outside.ogg", channel=u'music', loop=True, fadein=2,fadeout=2)
    "???" "Yo we got a shady lookin' mofo' over here!"
    scene ep1_057_store_khalil_meet with rightleft
    "???" "Think he might be a homeless dude."
    X "Hey Khalil!"
    scene ep1_058_store_khalil_intro with ml
    Khalil "[X]?! Shit, I didn't recognize you man!"
    scene ep1_059_store_khalil_talk with ml

    Khalil "You still rockin' that bum drip."
    scene ep1_060_store_khalil_listen with ml

    X "You're talking! With that high-school gear?"
    scene ep1_061_store_khalil_point_beer with ml

    X "Got ID on you? They won't let you buy those beers otherwise."
    scene ep1_062_store_khalil_point_side with ml

    Khalil "Man how's it like getting told every time to get out of those swanky stores?"
    scene ep1_060_store_khalil_listen with ml

    X "I bet you get pulled over and asked why you're skipping school."
    scene ep1_063_store_khalil_point_mc with ml

    Khalil "Hey does the pizza guy tip YOU?"
    scene ep1_064_store_khalil_handshake with ml

    X "Haha! What's going on man."
    scene ep1_071_parking_khalil_talk_listen with rightleft

    X "Isn't it a little early to drink?"
    scene ep1_065_parking_khalil_beercans with ml

    Khalil "It's for after training."
    scene ep1_066_parking_khalil_talk_hand with ml

    Khalil "Got a couple of matches next month."
    scene ep1_067_parking_khalil_talk_fist with ml

    Khalil "So everyday I gotta grind it."
    scene ep1_071_parking_khalil_talk_listen with ml

    X "Well you did go pro after all."
    scene ep1_068_parking_khalil_talk_point with ml

    Khalil "Yeah. And I got those fuckers to thank."
    X "Had any problems with them lately?"
    scene ep1_066_parking_khalil_talk_hand with ml

    Khalil "No, haven't seen them in a bit."
    scene ep1_069_parking_khalil_talk_look_side with ml

    Khalil "Anyway I'm going around the block for a hot-dog. Wanna come?"
    scene ep1_071_parking_khalil_talk_listen with ml

    X "Actually yes, haven't had breakfast yet."
    scene ep1_070_parking_khalil_talk_touch with ml

    Khalil "Oh you poor bastard! Come on, it's my treat."



    scene ep1_072_walk_khalil_talk_hands with rightleft

    Khalil "So he fired all of you?!"
    scene ep1_077_walk_khalil_listen_hand with ml

    X "Everyone in the department."
    scene ep1_074_walk_khalil_talk_point with ml

    Khalil "That fucking asshole! I never liked that guy."
    scene ep1_078_walk_khalil_listen_hand_low with ml

    X "Maybe it's better actually."
    scene ep1_075_walk_khalil_talk with ml

    Khalil "How's that?"
    scene ep1_076_walk_khalil_listen with ml

    X "I got more time to think now. Maybe do something else."
    scene ep1_073_walk_khalil_talk_fist with ml

    Khalil "Roll with the punches! That's more your style."
    scene ep1_079_hotdog_intro_talk with rightleft

    Jimmy "How's it going my dudes?"
    scene ep1_080_hotdog_khalil_talk with ml

    Khalil "Just doing my good deed for the day."
    Khalil "Feeding the hungry over here."
    scene ep1_081_hotdog_mc_point with ml

    X "Yeah real upstanding citizen this guy!"
    scene ep1_082_hotdog_bun with ml

    Jimmy "Double up and hold the ketchup, right [X]?"
    X "You know me!"
    scene ep1_083_hotdog_sauce with ml

    Khalil "Extra ketchup here!"
    Jimmy "I got you!"
    scene ep1_084_hotdog_ready with ml
    Jimmy "Have a good one you hear!"
    X "Thanks [Jimmy]!"

    scene ep1_091_walkback_khalil_listen with rightleft

    X "You finally getting in the big leagues man."
    scene ep1_085_walkback_khalil_point with ml

    Khalil "Can't stop till I'm on top!"
    scene ep1_087_walkback_khalil_pinch with ml

    Khalil "You on the other hand got soft."
    Khalil "Hanging out with all those tech nerds."
    scene ep1_089_walkback_khalil_bite with ml

    X "'the fuck you talking about?"
    X "You seem to need a reminder of what I'm capable of."
    scene ep1_086_walkback_khalil_talk_away with ml
    Khalil "Hohoho!"
    Khalil "Like I said, I'll be at the gym everyday."
    scene ep1_088_walkback_khalil_point_head with ml
    Khalil "So feel free to come by and... refresh my memory."
    scene ep1_093_car_khalil_talk with downtop
    X "Hey no worries, I won't go too hard."
    X "Don't want you to get hurt before the match."
    Khalil "You just worry about your own silicone ass."
    scene ep1_095_car_khalil_lovesign_alt with ml
    Khalil "Anyway, gotta bounce."
    Khalil "Love you man."
    scene ep1_094_car_khalil_lovesign with ml
    X "Love you too."


    $renpy.music.play("audio/music/pastry-shop.ogg", channel=u'music', loop=True, fadein=3,fadeout=3)

    scene ep1_096_eileen_shop_entrance with rightleft
    $renpy.music.play("audio/sfx/shop-doorbell.ogg", channel=u'sound')

    Eileen "I'll be there in a sec!"
    scene ep1_097_eileen_shop_counter with ml
    Eileen "Well well well!"
    X "It's been a while [Eileen]. How's business?"
    scene ep1_122_eileen_counter_talk_hand with ml
    Eileen "Can't really complain."
    scene ep1_123_eileen_counter_talk_hand_point with ml
    Eileen "Grab a seat, I'll be right up."
    scene ep1_098_eileen_table_stand with downtop
    Eileen "Want some coffee?"
    X "I'm good, thanks."
    scene ep1_105_eileen_table_talk with ml
    Eileen "So what have you been up to since last year?"
    $t_flag.reset
    scene ep1_100_eileen_table_listen
    label ep1_table_chat:
            menu:
                "Talk work" if  t_flag.x1==False:
                    $t_flag.x1=True
                    X "Been busy with the job mostly."
                    scene ep1_109_eileen_table_talk_look_side with ml
                    Eileen "Always working. You barely have time to visit me!"
                    scene ep1_101_eileen_table_listen_alt with ml
                    X "If it makes you feel better, I'm unemployed now."
                    X "So I'll have more time for you."
                    scene ep1_105_eileen_table_talk with ml
                    Eileen "How did that happen?"
                    scene ep1_108_eileen_table_talk_point_mc with ml
                    Eileen "You didn't beat up someone did you?"
                    scene ep1_104_eileen_table_listen_smile with ml
                    X "Come on!" 
                    X "Is that how you see me, as some violent thug?"
                    scene ep1_109_eileen_table_talk_look_side with ml
                    Eileen "Among other things."
                    scene ep1_105_eileen_table_talk with ml
                    Eileen "So how did it get to that?"
                    scene ep1_101_eileen_table_listen_alt with ml
                    X "Not really sure. Think it's because the new boss didn't like me."
                    scene ep1_105_eileen_table_talk with ml
                    Eileen "That's it?"
                    scene ep1_100_eileen_table_listen
                    X "The e-mail didn't mention any personal work complaints or anything."
                    scene ep1_107_eileen_table_talk_point_side_alt with ml
                    Eileen "Sounds like a wrongful termination to me. You should sue."
                    X "Maybe you're right."
                    scene ep1_105_eileen_table_talk with ml
                    Eileen "Anything else interesting?"
                    scene ep1_100_eileen_table_listen
                    jump ep1_table_chat
                "Talk fitness" if  t_flag.x2==False:
                    $t_flag.x2=True
                    X "Been wanting to workout more."
                    scene ep1_105_eileen_table_talk
                    Eileen "Looking to lose some weight?"
                    scene ep1_100_eileen_table_listen
                    X "Not really. Just want to get in shape."
                    scene ep1_106_eileen_table_talk_handsup with ml
                    Eileen "I see. Was worried you might cut back on the sweets."
                    X "Wouldn't dream of it!"
                    scene ep1_106_eileen_table_talk_point_side with ml
                    Eileen "So what made you think about it?"
                    scene ep1_100_eileen_table_listen with ml
                    X "A few times I decide to walk to the office, because of the insane traffic."
                    scene ep1_105_eileen_table_talk
                    Eileen "Was it far?"
                    scene ep1_100_eileen_table_listen
                    X "Not even 2 miles."
                    X "And there I was at the entrance all winded and sweaty."
                    scene ep1_105_eileen_table_talk
                    Eileen "Hot!"
                    scene ep1_104_eileen_table_listen_smile with ml
                    X "It was hot, but it wasn't just that."
                    scene ep1_111_eileen_table_talk_both with ml
                    X "So I was thinking of doing some running, heading to the gym for awhile."
                    Eileen "[Khalil]'s doing his training there now."
                    X "Yeah we met this morning."
                    scene ep1_105_eileen_table_talk with ml
                    Eileen "So what other stuff you got?"
                    scene ep1_100_eileen_table_listen
                    jump ep1_table_chat
                "Continue":
                    X "Actually right now I just want to enjoy some pastries."
    scene ep1_106_eileen_table_talk_handsup with ml
    Eileen "Ask and ye shall receive!"
    scene ep1_109_eileen_table_talk_look_side with ml
    Eileen "Got all your breads ready."
    scene ep1_101_eileen_table_listen_alt with ml
    X "How do you know what I want?"
    scene ep1_112_eileen_table_talk_leaning with ml
    Eileen "You get the same thing when you come by this time of year."
    scene ep1_113_eileen_table_talk_leaning_alt with ml
    Eileen "Then you go make some sandwiches and drive to the beach."
    Eileen "And wait for Emily."
    scene ep1_103_eileen_table_listen_leaning_alt with ml
    X "You know me so well."
    scene ep1_113_eileen_table_talk_leaning_alt with ml
    Eileen "Of course I do! We've known each other since school."
    scene ep1_115_eileen_table_talk_leaning_touch_hand with ml
    Eileen "I miss her too you know."
    scene ep1_114_eileen_table_talk_leaning_point_mc with ml
    Eileen "By the way, you don't need to come shop here for my sake."
    scene ep1_116_eileen_table_talk_leaning_touch_hand_alt with ml
    X "What do you mean?"
    scene ep1_118_eileen_table_talk_leaning_touch_hand_point_alt with ml
    Eileen "Since you can afford the high-end stuff."
    menu:
        "Favorite shop":
            $ep1_eileen_fav = True
            $Eileen_p+=1
            scene ep1_103_eileen_table_listen_leaning_alt with ml
            X "What are you talking about?"
            scene ep1_102_eileen_table_listen_leaning with ml

            X "Your buns are my favorite!"
            scene ep1_119_eileen_table_talk_touch_foot with ml
            Eileen "That's nice. Thank you."
            scene ep1_117_eileen_table_talk_leaning_touch_hand_point with ml
            Eileen "Wait a minute!"
            Eileen "Are you trying to get a discount?"
            scene ep1_104_eileen_table_listen_smile with ml
            X "Hypothetically, if I was, would you give it?"
            scene ep1_098_eileen_table_stand with ml
            Eileen "Even for such a blatant attempt."
            Eileen "I have to say yes."
            scene ep1_099_eileen_table_leave with ml
            X "In that case. I'll take some sweets too."
            X "Something like an afternoon snack."
            Eileen "Coming right up."
        "Nostalgia":
            $ep1_eileen_fav = False
            scene ep1_103_eileen_table_listen_leaning_alt with ml
            X "It's not the same. Yours just taste better."
            scene ep1_102_eileen_table_listen_leaning with ml
            X "Like the ones your mom used to make when we were little."
            scene ep1_119_eileen_table_talk_touch_foot with ml
            Eileen "Okay, I'll happily take that."
            scene ep1_099_eileen_table_leave with ml
            X "And can I get some sweet stuff too?"
            X "Something like an afternoon snack."
            Eileen "Coming right up."
    $Eileen_p_t+=1
    scene ep1_123_eileen_counter_talk_hand_point with downtop
    Eileen "Are we changing it up this year?"
    scene ep1_120_eileen_counter_listen with ml

    X "Just got some tutoring today."

    X "I figured having some stuff on hand will make it easier."
    scene ep1_122_eileen_counter_talk_hand with ml

    Eileen "Since when are you tutoring?"
    scene ep1_121_eileen_counter_listen_alt with ml
    X "Since today. Maya called me this morning for a couple of students."
    scene ep1_125_eileen_counter_talk_look_side with ml
    Eileen "I see."
    Eileen "In that case, there's somethings I recommend..."
    scene ep1_127_eileen_counter_talk_package with ml
    Eileen "We should hang out some time. Catch up properly."
    scene ep1_128_eileen_counter_talk_package_alt with ml
    X "Are you free this week-end?"
    Eileen "See you then!"

    $renpy.music.play("audio/music/morning-routine-house.ogg", channel=u'music', loop=True, fadein=3,fadeout=3)
    scene ep1_129_floor_overview_day with rightleft
    X "Better tidy up before they get here."
    $t_flag.reset
    menu tidy_house_loop:
        "Check livingroom" if t_flag.x1 == False:
            $t_flag.x1 = True
            scene ep1_130_clean_table with downtop
            "Get this stuff out of the way."
            scene ep1_129_floor_overview_day with topdown
            jump tidy_house_loop
        "Check lower bathroom" if t_flag.x2 == False:
            $t_flag.x2 = True
            scene ep1_132_change_tp with downtop
            "Can't forget the toilet paper."
            scene ep1_129_floor_overview_day with topdown
            jump tidy_house_loop
        "Check your room" if t_flag.x3 == False:
            $t_flag.x3 = True
            scene ep1_131_make_bed with downtop
            "There."
            scene ep1_129_floor_overview_day with topdown
            jump tidy_house_loop
        "Wait for [Maya]":
            $Maya_p_t+=1
            $Alecia_p_t+=1
            $Sophie_p_t+=1
            $renpy.music.play("audio/sfx/house-doorbell.ogg", channel=u'sound', loop=True)
            pause 2
            X "They're here."
            
    if t_flag.x1 == True:
        $Maya_p+=1
    if t_flag.x2 == True:
        $Alecia_p+=1
    if t_flag.x3 == True:
        $Sophie_p+=1
    $renpy.music.stop(channel=u'sound')
    $renpy.music.play("audio/music/livingroom-study.ogg", channel=u'music', loop=True, fadein=3,fadeout=3)
    scene ep1_133_maya_meet_door with leftright
    Maya "Good afternoon!"
    X "Welcome! Come in."
    scene ep1_134_girls_meet_introduce_mc with downtop
    Maya "So this is mister [X]!"
    Maya "He'll be helping you with mathematics [Sophie]."
    scene ep1_135_girls_meet_introduce_sophie with ml
    Sophie "Hello mister [X]."
    X "Hi [Sophie]."
    scene ep1_136_girls_meet_mc_talk_sophie with ml
    X "And please, no 'mister'!"
    scene ep1_137_girls_meet_alecia_talk with ml
    "???" "Pretty big house, you live with your wife?"
    X "I'm not married, and it's just me."
    scene ep1_138_girls_meet_introduce_alecia with ml

    Maya "And that is [Alecia]."
    Maya "She could use help with most subjects."
    X "I see."
    scene ep1_139_girls_meet_mc_talk_girls with ml
    X "You can use the living room over there."
    X "And make yourselves at home."
    scene ep1_140_maya_talk_look_side with ml
    Maya "Can we talk for a bit?"
    X "Sure."
    scene ep1_144_maya_talk_normal with ml
    Maya "I apologize for asking you to do this."
    scene ep1_145_maya_talk_normal_alt with ml
    Maya "Since you have already helped the orphanage so much."
    scene ep1_149_maya_talk_look_side with ml
    Maya "But no one has been available for tutoring [Sophie]."
    scene ep1_141_maya_listen with ml
    X "You mentioned she competed and won on nationals."
    scene ep1_144_maya_talk_normal
    Maya "That's correct."
    scene ep1_141_maya_listen
    X "So how is it possible that no one's helping her?"
    scene ep1_147_maya_talk_hand_raise with ml
    Maya "All the teachers have very high rates. And we simply cannot afford it."
    scene ep1_143_maya_listen_mc_hand with ml

    X "Wow! Sounds like the market's booming."
    scene ep1_144_maya_talk_normal with ml

    Maya "I wouldn't know."
    scene ep1_149_maya_talk_look_side with ml

    Maya "But [Sophie] is very diligent!"
    scene ep1_145_maya_talk_normal_alt with ml

    Maya "And if you can do even a few short sessions. That would be of tremendous help."
    scene ep1_144_maya_talk_normal with ml

    Maya "I don't want to add too much to the work you already do."
    scene ep1_141_maya_listen
    X "Actually, I'll be free for some time. So there's no need to worry about that."
    X "Also about [Alecia], what does she need help with?"
    scene ep1_144_maya_talk_normal
    Maya "She has had some problems with her grades last year."
    scene ep1_147_maya_talk_hand_raise with ml
    Maya "Now she has to attend school during the summer along with [Sophie]."
    Maya "She's a smart girl. So what she needs the most is to be convinced to study."
    scene ep1_142_maya_listen_alt with ml
    X "Think I got the general picture with both of them."
    scene ep1_145_maya_talk_normal_alt with ml
    Maya "In that case, I will leave you to it."
    Maya "And will return to pick them up."
    Maya "If there are any issues, you can always call me."
    scene ep1_146_maya_talk_smile with ml
    Maya "And thank you again!"
    X "Don't mention it."
    scene ep1_150_maya_talk_hands_together with ml
    Maya "I'm leaving, you girls behave now!"
    Sophie "Yes miss [Maya]!"
    Alecia "She wasn't talking about you [Sophie]."
    scene ep1_151_maya_leave_wave with downtop
    X "I'll show you out."
    Maya "No it's okay, I know the way!"
    scene ep1_152_girls_livingroom_intro with rightleft
    X "Do you girls want anything to drink or eat?"
    scene ep1_153_girls_livingroom_talk with ml
    Sophie "No thank you."
    Alecia "I'll have some tap water."
    scene ep1_152_girls_livingroom_intro with ml
    X "Tap water?"
    X "I have some fresh orange juice, or pomegranate if you prefer."
    Alecia "Tap water's fine."
    X "All right."
    scene ep1_156_girls_livingroom_sophie_writing with downtop
    X "Is that homework?"
    scene ep1_161_girls_livingroom_sophie_talk with ml
    Sophie "Yes, for summer classes."
    scene ep1_158_girls_livingroom_sophie_listen with ml
    X "Cool. You can just go on with that for now."
    scene ep1_160_girls_livingroom_sophie_listen_alt2 with ml
    X "I have to first take a look at the material and remember all of this."
    scene ep1_162_girls_livingroom_sophie_talk_alt with ml
    Sophie "Okay."
    scene ep1_157_girls_livingroom_sophie_writing_alt with ml
    X "Heard you made it all the way to the nationals last year."
    scene ep1_159_girls_livingroom_sophie_listen_alt1 with ml
    X "Did you study for it all on your own?"
    scene ep1_162_girls_livingroom_sophie_talk_alt with ml
    Sophie "I had some help."
    scene ep1_172_girls_livingroom_alecia_talk_sophie with ml
    Alecia "Getting a few pointers from the teachers after school doesn't count [Sophie]."
    scene ep1_173_girls_livingroom_alecia_talk_mc with ml
    Alecia "She had to do all of it by herself."
    scene ep1_163_girls_livingroom_sophie_talk_alecia with ml
    Sophie "The school did pay for the trip."
    scene ep1_177_girls_livingroom_alecia_talk_sophie_point with ml
    Alecia "Carla got the school to pay for it!"
    X "Carla?"
    scene ep1_161_girls_livingroom_sophie_talk with ml
    Sophie "The principal."
    scene ep1_173_girls_livingroom_alecia_talk_mc with ml
    Alecia "She seems like the only one who gives a shit."
    scene ep1_175_girls_livingroom_alecia_talk_mc_point with ml
    Alecia "Even tried tutoring [Sophie], but she teaches history."
    scene ep1_170_girls_livingroom_alecia_listen with ml
    X "Wow! Is it that bad?"
    scene ep1_176_girls_livingroom_alecia_talk_mc_point_alt with ml
    Alecia "They all probably think it's not worth bothering for an orphan girl."
    Alecia "And they want boatloads of cash too."
    scene ep1_173_girls_livingroom_alecia_talk_mc with ml
    Alecia "By the way, are you coming to teach at school or something?"
    scene ep1_170_girls_livingroom_alecia_listen with ml
    X "I don't have any qualifications for that."
    scene ep1_176_girls_livingroom_alecia_talk_mc_point_alt with ml
    Alecia "But you ARE being paid for this right?"
    scene ep1_171_girls_livingroom_alecia_listen_alt with ml
    X "Just doing this to help, I don't need any money."
    scene ep1_179_girls_livingroom_alecia_talk_side_look_alt with ml
    Alecia "Is that right..."
    scene ep1_157_girls_livingroom_sophie_writing_alt with ml
    X "[Sophie], when did you start getting serious with it?"
    scene ep1_162_girls_livingroom_sophie_talk_alt with ml
    Sophie "I have always liked it."
    scene ep1_160_girls_livingroom_sophie_listen_alt2 with ml
    X "I competed in a few rounds myself back in the day."
    scene ep1_159_girls_livingroom_sophie_listen_alt1 with ml
    X "Problem was that I realized that I had a talent for it late."
    scene ep1_162_girls_livingroom_sophie_talk_alt with ml
    Sophie "Why is that?"
    scene ep1_158_girls_livingroom_sophie_listen with ml
    X "Wasn't much in to studying for most of my school years."
    X "Then I found someone who helped me discover it, among other things."
    scene ep1_161_girls_livingroom_sophie_talk with ml
    Sophie "I'm glad that you found it eventually."
    scene ep1_158_girls_livingroom_sophie_listen
    X "Me too."

    scene ep1_156_girls_livingroom_sophie_writing with ml

    Alecia "Do you play [X]?"
    scene ep1_205_piano_alecia_check with downtop

    X "Play what?"
    X "Oh that! I dabble from time to time."
    scene ep1_206_piano_alecia_check_alt with ml

    Alecia "You bought a whole piano just for that?"
    X "No, it's for someone else really. Someone who can actually play it well."
    scene ep1_205_piano_alecia_check with ml

    X "You can go ahead if you want."
    Alecia "Some other time maybe."
    X "And feel free to look around."
    scene ep1_167_girls_livingroom_sophie_stretch with downtop

    X "It's been some time. How about a snack break?"
    $renpy.music.play("audio/music/kitchen-food.ogg", channel=u'music', loop=True, fadein=3,fadeout=3)
    scene ep1_183_girls_kitchen_listen_alecia_alt_ALT with rightleft

    X "If you girls don't like these, tell me and I'll bring something else."
    scene ep1_186_girls_kitchen_talk_alecia_look_down with ml

    Alecia "Not in to sweets."
    X "I can fix up something else."
    scene ep1_187_girls_kitchen_talk_alecia_raise_hand with ml
    Alecia "Don't bother, I'm not hungry anyway."
    scene ep1_185_girls_kitchen_idle_alecia_alt with ml


    X "Suit yourself."
    scene ep1_184_girls_kitchen_listen_sophie with ml

    X "You like it Sophie?"
    scene ep1_190_girls_kitchen_talk_sophie

    Sophie "Yes. They taste homemade."
    scene ep1_180_girls_kitchen_idle with ml

    X "My friend will like to hear that, it's exactly what she was going for."
    scene ep1_188_girls_kitchen_talk_alecia_point_mc with ml

    Alecia "Your girlfriend?"
    scene ep1_181_girls_kitchen_listen with ml

    X "Oh no! But we've known each other since grade school."

    scene ep1_192_girls_kitchen_alecia_leave with ml

    Alecia "Where's the bathroom?"
    scene ep1_204_kitchen_mc_point_bathroom with ml

    X "It's right over there."
    scene ep1_193_girls_kitchen_alecia_leave_alt with ml
    Alecia "I won't take too long."
    X "Ok..."
    scene ep1_194_sophie_kitchen_muffin_point with downtop
    Sophie "Are these with chocolate too?"
    scene ep1_195_sophie_kitchen_muffin_reach with ml
    X "They have some cream filling. Not sure what exactly."
    scene ep1_196_sophie_kitchen_muffin_reach_alt with ml
    Sophie "Hope it's chocolate."
    scene ep1_198_sophie_kitchen_water_spill_alt with ml

    Sophie "Oh no!"
    scene ep1_197_sophie_kitchen_water_spill with ml

    X "Let me get you a towel!"
    scene ep1_199_sophie_kitchen_towel_talk with downtop
    Sophie "I'm sorry, I wasn't paying attention!"
    scene ep1_201_sophie_kitchen_towel_listen with ml
    X "Don't worry about it."
    X "You should get to the bathroom to dry up."
    scene ep1_200_sophie_kitchen_towel_talk_alt with ml
    Sophie "Okay."
    scene ep1_202_sophie_kitchen_towel_leave with ml

    X "It's up the stairs, left door, just go straight through the bedroom."
    scene ep1_203_sophie_kitchen_towel_leave_alt with ml
    X "There's a drier somewhere."
    Sophie "Thank you!"
    scene ep1_208_kitchen_sandwich_prep_alt with ml
    "I got time to make some sandwiches."
    scene ep1_207_kitchen_sandwich_prep with ml
    "Maybe a few extra for the girls."
    scene ep1_209_kitchen_confusion_alecia_walk with rightleft
    Alecia "Where's Sophie?"
    X "Oh she went to dry up, had some water spill on her."
    Alecia "Where?"
    X "The bathroom upstairs."
    scene ep1_210_kitchen_confusion_alecia_point with ml
    Alecia "Over there?"
    X "The door on the left there."
    scene ep1_211_kitchen_confusion_alecia_point_alt with ml
    Alecia "On your left?"
    X "Yes."
    scene ep1_212_kitchen_confusion_sandwich_board with ml
    X "You've been really inquisitive."
    X "Do you maybe have some questions about--"
    $renpy.music.play("audio/music/kitchen-confusion.ogg", channel=u'music', loop=True, fadein=0,fadeout=0)
    scene ep1_214_kitchen_confusion_ballgrab_alt1
    X "Hey!"
    scene ep1_213_kitchen_confusion_ballgrab with ml
    X "What are you doing??"
    scene ep1_226_kitchen_confusion_ballgrab_talk_frown with ml

    Alecia "There are two bedrooms upstairs, I checked!"
    scene ep1_230_kitchen_confusion_ballgrab_talk_point

    Alecia "If you hurt Sophie in any way, you won't live to regret it!"
    X "Wait! Wait!"
    scene ep1_223_kitchen_confusion_ballgrab_listen_frown
    X "The bathroom's further down at the end!"
    scene ep1_227_kitchen_confusion_ballgrab_talk_eyebrows with ml

    Alecia "Oh really?"
    scene ep1_228_kitchen_confusion_ballgrab_talk_callout with ml

    Alecia "[Sophie]!"
    Alecia "[Sophie]!!"
    scene ep1_223_kitchen_confusion_ballgrab_listen_frown
    X "She's probably using the dryer right now. So she can't hear."
    scene ep1_229_kitchen_confusion_ballgrab_talk_smile with ml

    Alecia "Well isn't that convenient!"
    scene ep1_223_kitchen_confusion_ballgrab_listen_frown
    X "Convenient for what??"
    scene ep1_230_kitchen_confusion_ballgrab_talk_point
    Alecia "A rich playboy like you!"
    scene ep1_231_kitchen_confusion_ballgrab_talk
    Alecia "Living alone in a massive apartment."
    scene ep1_215_kitchen_confusion_ballgrab_alt2 with ml

    Alecia "Who takes in some orphan girls, gives them 'treats'."
    Alecia "And doing some tutoring for free."
    scene ep1_216_kitchen_confusion_ballgrab_alt3 with ml

    Alecia "Then they let their guard down, and you take advantage of them!"
    scene ep1_226_kitchen_confusion_ballgrab_talk_frown with ml

    Alecia "People like you just can't wait to see how much they can get away with!"
    scene ep1_223_kitchen_confusion_ballgrab_listen_frown

    X "Alright, you're jumping to conclusions here!"
    scene ep1_227_kitchen_confusion_ballgrab_talk_eyebrows

    Alecia "Is that so? Then you must have a good explanation then!"
    scene ep1_229_kitchen_confusion_ballgrab_talk_smile
    Alecia "Right?"
    scene ep1_223_kitchen_confusion_ballgrab_listen_frown
    "This is ridiculous."
    menu:
        "Grab her arm":
            $ep1_alecia_grab = True
            X"Now"
            scene ep1_217_kitchen_confusion_ballgrab_counter
            X "hold"
            scene ep1_218_kitchen_confusion_handle_listen
            X "the phone!"
            scene ep1_220_kitchen_confusion_handle_talk_alt
            Alecia "I knew it!"
            scene ep1_219_kitchen_confusion_handle_talk with ml
            Alecia "You won't get away with this!"
            scene ep1_218_kitchen_confusion_handle_listen
            X "Look, Maya called this morning to ask if I can do some tutoring."
            X "I told her a while ago that I can do a bunch a things, so we made a list."
            X "It's also not my first time helping out at the orphanage."
            scene ep1_219_kitchen_confusion_handle_talk
            Alecia "Right."
            scene ep1_220_kitchen_confusion_handle_talk_alt with ml
            Alecia "And why do you care so much?"
            scene ep1_218_kitchen_confusion_handle_listen with ml
            X "I know it's been getting budget cuts every year now."
            X "Plus I grew up there!"
            scene ep1_222_kitchen_confusion_handle_release_alt with ml
            Alecia "At the orphanage?"
            X "Yes."
            scene ep1_221_kitchen_confusion_handle_release with ml
            Alecia "Well shit!"
            $renpy.music.play("audio/music/morning-routine-outside.ogg", channel=u'music', loop=True, fadein=1.5,fadeout=1)
            scene ep1_232_kitchen_confusion_sophie_coming with leftright
            Sophie "Sorry I took so long!"
            scene ep1_233_kitchen_confusion_sophie_talk with ml
            X "It's Ok. I'm making sandwiches, tell me what you like."
            scene ep1_234_kitchen_confusion_alecia_leave with ml
            Sophie "Oh I don't know."
            scene ep1_235_kitchen_confusion_alecia_leave_alt with ml
            Sophie "Whatever is fine."
        "Explain":
            $ep1_alecia_grab = False
            X "Look, Maya called this morning to ask if I can do some tutoring."
            scene ep1_224_kitchen_confusion_ballgrab_listen

            X "I told her a while ago that I can do a bunch a things, so we made a list."
            X "It's also not my first time helping out at the orphanage."
            scene ep1_227_kitchen_confusion_ballgrab_talk_eyebrows
            Alecia "And why do you care so much?"
            scene ep1_224_kitchen_confusion_ballgrab_listen
            X "I know it's been getting budget cuts every year now."
            X "Plus I grew up there!"
            scene ep1_227_kitchen_confusion_ballgrab_talk_eyebrows
            Alecia "At the orphanage?"
            scene ep1_225_kitchen_confusion_listen with ml
            X "Yes."
            X "Ever since I was little."

            $renpy.music.play("audio/music/morning-routine-outside.ogg", channel=u'music', loop=True, fadein=1.5,fadeout=1)

            scene ep1_232_kitchen_confusion_sophie_coming with leftright
            Sophie "Sorry I took so long!"
            scene ep1_233_kitchen_confusion_sophie_talk with ml
            X "It's Ok. I'm making sandwiches, tell me what you like."
            scene ep1_234_kitchen_confusion_alecia_leave with ml
            Sophie "Oh I don't know."
            scene ep1_235_kitchen_confusion_alecia_leave_alt with ml
            Sophie "Whatever is fine."
            
    scene ep1_236_piano_mc_smartphone_day with rightleft
    Maya "I'll be running a little late."
    Maya "Can you stay with them a bit longer please?"
    X "I don't mind taking them home."
    Maya "That would be too much of a bother!"
    X "Actually I'm going out later. And it's on the way, so it's no trouble."
    Maya "In that case, thank you!"
    scene ep1_237_orphanage_car_arrive with rightleft
    X "Here we are!"
    scene ep1_238_orphanage_car_sophie_leave with downtop
    Sophie "Thanks mister-- I mean [X]!"
    scene ep1_239_orphanage_car_sophie_ouside with ml
    X "Don't forget the food."
    Sophie "It's in my bag."
    Alecia "You go ahead Sophie, I'll be there in a minute."
    scene ep1_240_orphanage_car_alecia_talk_raise_hand with ml
    Alecia "Hey so... I'm sorry about what I did earlier!"
    Alecia "It's fine if you don't want me to come anymore."
    scene ep1_241_orphanage_car_alecia_talk_point_side with ml

    Alecia "But please don't give up on Sophie, she really needs this."
    scene ep1_242_orphanage_car_alecia_listen with ml
    X "I'm not giving up on her, don't worry."
    X "As far as you're concerned, I want a little more than a 'sorry'."
    scene ep1_243_orphanage_car_alecia_talk
    Alecia "What do you mean?"
    scene ep1_242_orphanage_car_alecia_listen
    X "You're going to have to keep coming and also try to actually study something."
    X "Then after that, maybe we can call it even."
    scene ep1_244_orphanage_car_alecia_talk_eyebrow with ml
    Alecia "Are you serious?"
    X "Very."
    scene ep1_245_orphanage_car_alecia_talk_leaving with ml
    Alecia "Fine, whatever."
    scene ep1_246_orphanage_car_alecia_wave with ml
    X "See you next time!"
    Alecia "Sure."
    $renpy.music.stop(channel=u'music', fadeout=6)
    $renpy.music.play("audio/ambience/seawaves_calm.ogg", channel=u'ambience', loop=True, fadein=3)
    
    scene ep1_247_beach_spot_sunset with rightleft
    "This day certainly broke the monotony."
    "[Alecia] has some trust issues. Can't really blame her."
    scene ep1_248_beach_spot_grotto_enter with ml
    pause 2
    scene ep1_249_beach_spot_grotto_see_d with ml
    "Did someone else find this place?"
    scene ep1_250_beach_spot_grotto_approach_d with ml
    "Is she..."
    scene ep1_251_beach_spot_grotto_d_sit with ml
    $renpy.music.play("audio/music/d-meet.ogg", channel=u'music', loop=True, fadein=2,fadeout=2)
    X "[Emily]?!"
    scene ep1_252_beach_spot_grotto_d_sit_talk with ml
    "???" "That was my mom's name."
    "Her face... she looks just like..."
    X "Are you...  [D]?"
    scene ep1_253_beach_spot_d_surprised
    D "Yes. W-Who are you?"
    X "It's OK, my name is [X]. [Emily] and I were in school together."
    scene ep1_254_beach_spot_d_listen with ml
    X "She had to leave before we finished it."
    scene ep1_255_beach_spot_d_talk with ml
    D "[X]... mom wrote about you."
    D "She said you were my dad."
    scene ep1_254_beach_spot_d_listen
    X "I... I am your father?"
    scene ep1_257_beach_spot_d_talk_alt2 with ml

    D "Yes."
    scene ep1_258_beach_spot_d_listen_hands_close with ml

    pause 1
    X"Wow this is..."
    pause 2
    X "Hold on."
    X "Who did you come here with?"
    scene ep1_256_beach_spot_d_talk_alt1 with ml
    D "I came by myself. Mom wrote that she promised to meet you back here."
    scene ep1_257_beach_spot_d_talk_alt2 with ml
    D "I didn't know where else to go."
    scene ep1_258_beach_spot_d_listen_hands_close with ml
    X "That's right, we promised to meet back here."
    X "I've been...{w=1} coming here ever since."
    X "And [Emily]. Where is she now?"
    scene ep1_259_beach_spot_d_talk_look_side with ml
    D "When I was little they... they told me she ran away."
    X "What?"
    scene ep1_260_beach_spot_d_talk_look_side_alt1 with ml
    D "When I was five, that's when I last saw her."
    scene ep1_258_beach_spot_d_listen_hands_close with ml
    X "Who told you she ran away?"
    scene ep1_261_beach_spot_d_talk_look_side_alt2 with ml

    D "The people I lived with, the ones who adopted her."
    "Her foster parents."
    scene ep1_254_beach_spot_d_listen with ml

    X "And do they know you're here?"
    scene ep1_259_beach_spot_d_talk_look_side with ml
    D "No, I ran away."
    X "Why?"
    scene ep1_257_beach_spot_d_talk_alt2 with ml
    D "They lied to me, they forced my mom to pretend she was a maid!"
    scene ep1_264_beach_spot_d_sneeze_alt
    D "Achoo!"
    scene ep1_263_beach_spot_d_sneeze with ml
    X "OK we have to go, it's getting cold."
    scene ep1_265_beach_spot_d_listen_hand_back with ml
    X "We'll talk back at the house."


    $renpy.music.stop(channel=u'ambience', fadeout=None)
    $renpy.music.play("audio/music/d-house.ogg", channel=u'music', loop=True, fadein=2,fadeout=2)

    scene ep1_266_entrance_d_arrive_back with rightleft
    X"Here we are."
    scene ep1_267_entrance_d_arrive_front with ml
    D"I can see everything outside!"
    X "You like it?"
    D "It's amazing!"
    scene ep1_268_entrance_d_arrive_pov with ml
    X "Are you hungry? Do you want something to eat?"
    D "Yes please."
    scene ep1_269_kitchen_d_sandwiches_place with downtop

    X "I don't have anything ready but these."
    D "It's fine, thank you!"
    scene ep1_273_kitchen_d_sandwiches_listen_2S with ml

    X "Is it far where you came from?"
    X "How long have you been on the road?"
    scene ep1_270_kitchen_d_sandwiches_talk_2S with ml

    D "It's been 6 days I think."
    scene ep1_277_kitchen_d_sandwiches_bite_2S with ml

    X "I'm sorry, didn't ask for your name."
    scene ep1_275_kitchen_d_sandwiches_talk_lookdown_2S with ml

    D "I don't want my name."
    scene ep1_277_kitchen_d_sandwiches_bite_2S with ml

    X "You don't WANT your name?"
    scene ep1_271_kitchen_d_sandwiches_talk_1S with ml

    D "It's the same one they gave to my mom."
    scene ep1_276_kitchen_d_sandwiches_talk_lookdown_1S with ml

    D "I hate it!"
    scene ep1_278_kitchen_d_sandwiches_bite_1S with ml

    X "OK. So then what should I call you?"
    scene ep1_272_kitchen_d_sandwiches_talk_alt with ml

    D "You choose it!"
    X "What?"
    scene ep1_271_kitchen_d_sandwiches_talk_1S with ml

    D "You are my dad after all."
    scene ep1_278_kitchen_d_sandwiches_bite_1S with ml

    X "Yeah I'm still trying to wrap my head around that."
    X "But if you want, I could just call you--"
    scene ep1_272_kitchen_d_sandwiches_talk_alt
    D "Wait!"
    scene ep1_279_kitchen_d_sandwiches_finished with ml

    D"Not yet."
    scene ep1_280_kitchen_d_sandwiches_standing with ml

    D "I'll go outside in front of the door..."
    scene ep1_281_kitchen_d_sandwiches_standing_alt with ml

    D "You open it and then say it!"
    X "That's... sure! We'll do it your way."
    scene ep1_282_kitchen_d_sandwiches_empty_counter with ml

    "They gave the same name to [Emily]?"
    "That's strange."
    "And I'm a father, it must have been that time at the beach..."

    python:
        pov_d = renpy.input("What should I name my daughter?", length=32,screen="input")
        pov_d = pov_d.strip()

        if not pov_d:
            pov_d = "Vera"

    pause 0.5
    scene ep1_379_entrance_d_givename_open with ml
    X "I'm opening the door."
    scene ep1_284_entrance_d_givename_listen with leftright
    X "Hello [D]!"
    scene ep1_283_entrance_d_givename_wave with ml
    D "Hi dad!"
    scene ep1_286_entrance_d_givename_yawn with ml
    D"{font=fonts/NotoEmoji-Bold.ttf}{color=#69094c}🥱{/font}"
    X "You must be tired."
    scene ep1_285_entrance_d_givename_listen_alt with ml
    X "I'll go run a bath. Then show you where you'll be sleeping."

    scene ep1_287_room_d_intro with rightleft
    X "This is your room."
    scene ep1_288_room_d_intro_listen with ml

    X "You can leave your clothes in the hamper."
    X "You've got towels, soaps and everything there."
    X "I'll find something for you to wear."
    scene ep1_289_room_d_intro_talk with ml
    D "Okay."
    scene ep1_290_room_d_intro_preped with rightleft
    "All done here."
    scene ep1_291_room_d_aftershower with ml
    X "I only have my own clothes."
    X "It'll have to do for now."
    scene ep1_294_room_d_aftershower_talk
    D "I don't mind."
    scene ep1_292_room_d_aftershower_point_wardrobe with ml
    X "Just pick whatever you want out of the wardrobe."
    scene ep1_293_room_d_aftershower_point_bed with ml
    X "Bed's made and ready."
    scene ep1_296_room_d_aftershower_listen with ml

    X "I'll leave you to get dressed then."
    scene ep1_294_room_d_aftershower_talk with ml
    D "Thank you!"
    scene ep1_295_room_d_aftershower_feet with ml
    X "You're welcome!"
    scene ep1_298_room_d_door with downtop
    "Forgot to mention a few things."
    menu:
        "Knock on the door":
            $ep1_door_peek = False
            scene ep1_299_room_d_door_knock with ml
            $renpy.music.play("audio/sfx/door-knock.ogg", channel=u'sound', loop=False)
            X "[D], can I come in?"
            pause 1
            D "Yes."

        "Open the door":
            $D_p += 1
            $ep1_door_peek = True
            scene ep1_300_room_d_door_open_changing with ml
            "Ooops..."
            scene ep1_299_room_d_door_knock with ml
            $renpy.music.play("audio/sfx/door-knock.ogg", channel=u'sound', loop=False)
            X "[D], can I come in?"
            pause 1
            D "Yes."
    $D_p_t += 1
    scene ep1_301_room_d_listen with downtop
    X "If you're still hungry, I can make you something."
    scene ep1_302_room_d_talk with ml
    D "No, it's fine."
    scene ep1_301_room_d_listen with ml
    X "Ok, but if you get hungry, go ahead and eat whatever you want."
    scene ep1_302_room_d_talk with ml
    D "I understand, thanks you!"


    scene ep1_297_office_overview_night with rightleft
    "I need to look in to who these people are."
    "Wait! Forgot to ask about them!"
    scene ep1_299_room_d_door_knock with ml
    $renpy.music.play("audio/sfx/door-knock.ogg", channel=u'sound', loop=False)
    X "[D]."
    X "I need to you ask you about a few things!"
    pause 1
    "Not answering..."
    $renpy.music.stop(channel=u'music', fadeout=10)
    scene ep1_303_room_d_sleeping with ml
    "Fast asleep. She must have been exhausted."
    scene ep1_331_livingroom_mc_thinking with rightleft
    "Maybe they lied about her disapearing."
    "I need to find out what happened."
    scene ep1_033_room_mc_bed_sitting with downtop
    "Gotta try and get some rest."
    scene ep1_034_room_mc_bed_laying with ml
    "I need a clear head for all of this"
    scene ep1_027_room_mc_ceiling with ml
    scene ep1_000_black  with eye_close
    pause 4
    "???" "{cps=10}Don't let her go...{w=1}"
    $renpy.music.play("audio/sfx/bed-shuffle-short2.ogg", channel=u'sound', loop=False)
    scene ep1_030_room_mc_bed_feet
    X "[Emily]!"
    scene ep1_034_room_mc_bed_laying with ml
    "Was that another dream?"
    "Can't recall anything..."
    scene ep1_035_hallway_day with downtop
    "What's that smell?"
    $renpy.music.play("audio/music/morning-breakfast.ogg", channel=u'music', loop=True, fadein=4,fadeout=4)

    scene ep1_308_kitchen_d_breakfast_topview with ml
    "So it wasn't all a dream..."
    scene ep1_309_kitchen_d_breakfast_back with downtop
    X "Good morning!"
    D "Good morning!"
    D "I made breakfast since I ate your sandwiches yesterday."
    scene ep1_310_kitchen_d_breakfast_talk with ml
    D "Have a seat, it's almost ready."
    scene ep1_330_breakfast_plate_mc with downtop
    D "I didn't know what you liked so I varied it."
    scene ep1_319_breakfast_d_cereal_pour_alt with ml
    X "It's a treat!"
    scene ep1_318_breakfast_d_cereal_pour with ml
    X "But you didn't have to."
    scene ep1_314_breakfast_d_talk with dissolve
    D "It's fine, I enjoy cooking."
    scene ep1_311_breakfast_d_listen
    X "[D]."
    scene ep1_314_breakfast_d_talk
    D "Yes?"
    scene ep1_311_breakfast_d_listen 
    X "Are you sure you want me calling you that?"
    scene ep1_314_breakfast_d_talk
    D "I like it!"
    scene ep1_320_breakfast_d_cereal_spoon with ml
    D "If you're sure..."
    scene ep1_322_breakfast_d_cereal_eat with ml

    X "About the people you stayed with."
    scene ep1_321_breakfast_d_cereal_spoon_alt with ml
    X "I need to know some stuff about them."
    scene ep1_316_breakfast_d_listen_eyesdown_alt with ml
    pause 2
    X "If you're worried."
    scene ep1_315_breakfast_d_listen_eyesdown with ml

    X "I won't tell them about you. I promise!"
    scene ep1_325_breakfast_d_talk_lookdown with ml
    D "Their names are [Radford] and [Odelia], and they called me Adalinda."
    scene ep1_315_breakfast_d_listen_eyesdown with ml
    X "Do you know the address of the house?"
    scene ep1_325_breakfast_d_talk_lookdown
    D "Yes."
    scene ep1_312_breakfast_d_listen_handontable with animf
    X "And they told you that [Emily] was just a maid?"
    scene ep1_323_breakfast_d_talk_hand

    D "She was the one who took care of me when I was little."
    scene ep1_312_breakfast_d_listen_handontable 
    X "You mentioned she wrote this somewhere."
    scene ep1_324_breakfast_d_talk_hand_lookaway with ml

    D "Yes, a journal. Buried in the grounds."
    D "It started from after I was born."
    scene ep1_312_breakfast_d_listen_handontable
    X "And they called you both [Adalinda]?"
    scene ep1_323_breakfast_d_talk_hand with ml

    D "When she was adopted, they changed her name."
    scene ep1_324_breakfast_d_talk_hand_lookaway
    D "But after I was born they called me by that. And she became [Emily] again."
    X "That is not right!"
    scene ep1_317_breakfast_d_listen_eyesdown_handontable with ml
    X "Have you tried talking to other people, at school maybe?"
    scene ep1_326_breakfast_d_talk_lookdown_handontable
    D "I wasn't in school. A tutor came by sometimes."
    scene ep1_317_breakfast_d_listen_eyesdown_handontable 
    X "So you were home-schooled for most of your life?"
    scene ep1_326_breakfast_d_talk_lookdown_handontable
    D "They told me that the outside world was too dangerous, that it would corrupt me."
    "What the hell..."
    scene ep1_317_breakfast_d_listen_eyesdown_handontable
    X "Did you meet other people besides them?"
    scene ep1_323_breakfast_d_talk_hand with ml

    D "I wasn't allowed outside the grounds."
    scene ep1_312_breakfast_d_listen_handontable

    X "What about medical checkups? When have you last seen a doctor?"
    scene ep1_323_breakfast_d_talk_hand 
    D "I think he has visited maybe three years ago."
    "Of course..."
    scene ep1_329_breakfast_d_yawn with downtop
    D"{font=fonts/NotoEmoji-Bold.ttf}{color=#69094c}🥱{/font}"
    X "How and where have you been sleeping?"
    scene ep1_327_breakfast_d_talk_finished with ml

    D "On the train, the bus, once in a library."
    scene ep1_313_breakfast_d_listen_finished
    X "Figures, you couldn't have slept well."
    X "Better go get more rest, don't push yourself."
    scene ep1_327_breakfast_d_talk_finished 
    D "I'll be up before lunch."
    scene ep1_313_breakfast_d_listen_finished
    X "Don't worry about cooking if that's what you're thinking!"
    X "I can do that. Just sleep as much as you need."
    scene ep1_327_breakfast_d_talk_finished 
    D "I understand..."
    $renpy.music.stop(channel=u'music', fadeout=10)
    scene ep1_236_piano_mc_smartphone_day with rightleft

    X "...yes a full checkup, as soon as possible."
    "Operator" "I see your insurance has recently been canceled mister [X]."
    "Well that was fast."
    X "That doesn't matter, it's not for me. It's for a young girl, my... dad."
    "Operator""I see."
    "Operator""In that case we can schedule you for tomorrow."
    "Operator""However that is a premium option, so the fees are higher."
    X "That's fine, I'll pay whatever it costs."
    "Operator""OK then! And what name should I put the patient under?"
    X "[D]."
    pause 1
    "Operator""Done! You have the first appointment tomorrow at 9 o'clock."
    "Operator""Have a good day mister [X]!"

    scene ep1_380_office_mc_laptop_day with rightleft

    $renpy.music.play("audio/sfx/keyboard-laptop.ogg", channel=u'sound', loop=True)

    "No wonder I didn't find her, there are barely any records about them."
    "At least [Charlie] has some leads to  go by now..."
    $renpy.music.stop(channel=u'sound', fadeout=None)


    scene ep1_331_livingroom_mc_thinking with rightleft
    pause 1.6
    $renpy.music.play("audio/music/beach-theme.ogg", channel=u'music', loop=True, fadein=2,fadeout=1)
    D "dad!"
    scene ep1_332_livingroom_tv_approach_talk with ml
    X "Yes [D]?"
    D "Is that... a television?"
    scene ep1_334_livingroom_tv_night with ml

    X "The fact that you refer to it like that, and that you have to ask."
    scene ep1_333_livingroom_tv_approach_listen with ml
    X "Leads me to think you didn't have one."
    scene ep1_340_livingroom_tv_d_talk with downtop

    D "There was one, but it was big, and more like a box."
    scene ep1_339_livingroom_tv_d_listen
    X "Those are really old."
    scene ep1_340_livingroom_tv_d_talk

    D "But most of the time, all it showed were fleas."
    scene ep1_339_livingroom_tv_d_listen

    X "Fleas? You mean static?"
    scene ep1_340_livingroom_tv_d_talk

    D "I think so, yes."
    scene ep1_335_livingroom_tv_d_remote_instruct with downtop

    X "...so that's how you navigate."
    $renpy.music.play("audio/sfx/ringtone_1.ogg", channel=u'sound', loop=True, fadein=3)
    D "I get it."
    scene ep1_336_livingroom_tv_d_remote_use with ml
    X "Go ahead and watch whatever you like."
    X "I have to get this."
    scene ep1_345_livingroom_mc_smartphone_night with rightleft
    $renpy.music.stop(channel=u'sound')

    Charlie "Hey [X]! I received your message."
    Charlie"Are you sure this is a good lead?"
    X "Positive, they're the ones who adopted her."
    Charlie"How did you find this anyway?"
    scene ep1_342_livingroom_tv_d_overview with ml
    X "More like it found me."
    X "To be more precise, my dad found me."
    Charlie"Your dad?!"
    X"Yeah, me and [Emily] we met... before she was adopted."
    Charlie"..."
    Charlie"I see... won't hold it against you for not mentioning this."
    Charlie"But you can give me all the details when we meet."
    Charlie"I'll see what I can dig up till then."
    scene ep1_345_livingroom_mc_smartphone_night with ml
    X "Sure, and thanks for getting on this right away."
    Charlie"Not a problem, I have to finish what I started after all."
    Charlie"Call you when it's done."

    scene ep1_338_livingroom_tv_d_watching_alt with downtop
    X "It's around dinner time."
    scene ep1_339_livingroom_tv_d_listen with ml

    X"I can make something or we could order a pizza."
    scene ep1_341_livingroom_tv_d_talk_alt with ml

    D "No, I can cook!"
    scene ep1_339_livingroom_tv_d_listen with ml

    X "There's no need [D]. Plus you already made breakfast this morning?"
    scene ep1_343_livingroom_tv_d_standingup with ml

    D "No, it's my pleasure!"
    scene ep1_344_livingroom_tv_d_point_kitchen with downtop

    D "I got to practice all the time."

    scene ep1_347_kitchen_d_prep_herbs_alt with rightleft

    X "I looked at the house, it's more like a mansion."
    X "Did you sneak away, how did you escape?"
    scene ep1_346_kitchen_d_prep_herbs with ml

    D "We actually went to visit someone who was getting married."
    scene ep1_348_kitchen_d_prep_pickup_chicken with ml

    D "There was always a guardian with me, they told me it was for my safety."
    scene ep1_349_kitchen_d_cook_chicken with ml

    D "He always watched me."
    X "Always?"
    scene ep1_350_kitchen_d_cook_chicken_alt with ml

    D "Except when I used the bathroom, then he just stood outside."
    D "It's how I got away."
    scene ep1_351_dinner_d_listen_mc_talk with rightleft

    X "If they had someone watching you 24/7, then they probably expected you to run away."
    scene ep1_352_dinner_d_talk_sidelook_alt with ml

    D "One time when I was little, I followed a kitten outside."
    scene ep1_353_dinner_d_talk_sidelook_hands_alt with ml
    D "They became angry and told me I wasn't allowed to be alone anymore."
    D "Ever since then, I had to have someone with me all of the time."

    scene ep1_355_dinner_d_talk_sidelook_hands with ml

    D "They said I would disappear just like [Emily] if I ever went out alone again."
    "Christ..."
    scene ep1_359_dinner_d_listen_both_hands with ml

    X "But despite that you still left, that couldn't have been easy."
    scene ep1_354_dinner_d_talk_look_mc with ml

    D "After finding the journal, I just didn't believe anything they said."
    scene ep1_358_dinner_d_listen with ml

    X "Did you bring it with you?"
    scene ep1_356_dinner_d_talk_sidelook with ml

    D "I couldn't, but I left it hidden."
    
    scene ep1_362_dinner_d_finish_listen with downtop
    X "That was delicious!"

    X "Practice does indeed make perfect."
    scene ep1_363_dinner_d_finish_talk

    D "I'm happy you liked it."
    scene ep1_361_dinner_under_table with topdown
    X "And by the way, tomorrow we're going to get you a full medical check-up."
    scene ep1_362_dinner_d_finish_listen with ml

    X "Since you mentioned not seeing a doctor in years."
    scene ep1_363_dinner_d_finish_talk
    D "A full check-up?"
    scene ep1_362_dinner_d_finish_listen
    X "Yes, we need some samples and they'll take a look at everything."
    scene ep1_364_dinner_d_finish_talk_lookdown with ml

    D "Everything? Even down... there?"
    X "That too, yes."
    scene ep1_361_dinner_under_table with topdown
    X "A woman doctor will do that, so don't worry!"
    scene ep1_365_dinner_d_finish_pickup_plate with ml

    D "Thank you, I'll go wash the dishes."
    X "Wait!"
    scene ep1_366_dinner_d_finish_hands_raise

    X "There's a certain someone who takes care of that."
    scene ep1_367_kitchen_mc_point_washingmachine with rightleft
    X "He can deal with anything you throw in there."
    X "Pots, pans, whatever."
    scene ep1_368_kitchen_mc_point_d with ml
    X "He'll wipe out any stains, even the little ones."
    X "I call him... 'Dish Vader'!"
    scene ep1_369_kitchen_d_listen with ml
    pause 1
    scene ep1_370_kitchen_d_talk
    D "Why?"
    scene ep1_369_kitchen_d_listen
    pause 0.5
    D "Why?!"
    scene ep1_368_kitchen_mc_point_d with ml
    X "You know... 'I am your father'!"
    scene ep1_370_kitchen_d_talk with ml
    D "I know!"
    scene ep1_369_kitchen_d_listen
    X "No that's not what I... nevermind."
    X "You need to watch more TV!"
    scene ep1_371_kitchen_d_talk_alt

    D "Agreed!"
    scene ep1_370_kitchen_d_talk with ml
    D "Can I use the bathroom?"
    scene ep1_369_kitchen_d_listen
    X "Yes, and you do not have to ask!"
    scene ep1_297_office_overview_night with rightleft
    "It's probably best to get her samples from home."
    scene ep1_298_room_d_door with downtop
    "She might be too uncomfortable doing it at the hospital."
    scene ep1_290_room_d_intro_preped with ml
    "Is she still in the bathroom?"
    scene ep1_372_bathroom_lower_mc_knock with rightleft
    $renpy.music.play("audio/sfx/door-knock.ogg", channel=u'sound', loop=False)
    X "[D], is everything all right?"
    pause 1
    D "I... I need some help."
    $renpy.music.stop(channel=u'music', fadeout=6)
    X "You need me to get you something?"
    D "Can you come inside please?"
    scene ep1_373_bathroom_lower_d_listen with downtop
    X "What's wrong, what happened?"
    scene ep1_374_bathroom_lower_d_talk with ml
    D "I can't get it to come off."
    scene ep1_373_bathroom_lower_d_listen with ml
    X "Get what off?"
    scene ep1_375_bathroom_lower_reveal_front with ml
    X "Hey what are you..."
    scene ep1_376_bathroom_lower_reveal_front_alt with ml
    D "I've tried, but it just won't come off."
    scene ep1_377_bathroom_lower_reveal_back with ml
    D "It's locked in the back."
    scene ep1_378_bathroom_lower_reveal_back_alt with ml
    X "Locked?"
    X "Is... is that a chastity-belt?!"
    scene ep1_000_black with curtains_slow_r
    #show screen episode_end
    menu:
        "Continue":
            jump ep2_01_bedroom

    #scene ep1_000_black with curtains_slow_r
    #show screen episode_end
    #menu:
        #"To be continued...":
            #pass






        


