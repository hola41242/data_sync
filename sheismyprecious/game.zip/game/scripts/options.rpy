













define config.name = _("She Is My Precious")





define gui.show_name = True




define config.version = "0.5"





define gui.about = _p("""
""")






define build.name = "SheIsMyPrecious"








define config.has_sound = True
define config.has_music = True
define config.has_voice = False














define config.main_menu_music = "audio/music/She Is My Precious C1.wav"










define config.enter_transition = dissolve
define config.exit_transition = dissolve




define config.intra_transition = dissolve




define config.after_load_transition = None




define config.end_game_transition = None
















define config.window = "auto"




define config.window_show_transition = Dissolve(.15)
define config.window_hide_transition = Dissolve(.15)







default preferences.text_cps = 90





default preferences.afm_time = 15
















define config.save_directory = "SIMP-1676916284"






define config.window_icon = "gui/window_icon.png"






init python:




















    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)




    build.classify('game/**.png', 'archive')
    build.classify('game/**.jpg', 'archive')
    build.classify('game/**.ogg', 'archive')
    build.classify('game/**.ttf', 'archive')
    build.classify('game/**.rpy', 'archive')
    build.classify('game/**.rpyc', 'archive')
    build.classify('game/**.rpym', 'archive')
    build.classify('game/**.rpymc', 'archive')
    build.classify('game/**.json', 'archive')
    build.classify('game/**.webm', 'archive')




    build.documentation('*.html')
    build.documentation('*.txt')







define config.default_music_volume = 0.75
define config.default_sfx_volume = 0.7


define config.developer = False
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
