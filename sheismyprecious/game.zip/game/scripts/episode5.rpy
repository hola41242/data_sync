
label ep5_greenhouse:
    hide screen episode_end
    $ renpy.music.stop(channel=u'music', fadeout=1.0)
    $ renpy.music.stop(channel=u'ambience', fadeout=None)
    $ renpy.music.stop(channel=u'sound', fadeout=None)
    scene ep1_000_black with dissolve
    pause 0.5
    show screen episode_title("Episode 5","Deep wounds")
    pause 5.5
    hide screen episode_title
    pause 1.0
    $ renpy.music.play("audio/music/free-night-134023.ogg", channel=u'music', loop=True, fadein=3)
    scene ep5_MC_Tied_Odelia_A1_FREE_Look_1 with eye_open
    X "Ughh!"
    "That bitch! She fucking tased me!"
    scene ep5_MC_Tied_Odelia_A1_FREE_Look_2 with ml
    "Looks like some sort of a greenroom."
    scene ep5_MC_Tied_Odelia_A1_FREE_Look_1 with hpunch
    pause 1
    "What the hell, I can't move!"
    scene ep5_MC_Tied_Odelia_A1_FREE_Hands with ml
    "They tied me up!?"
    scene ep5_MC_Tied_Odelia_A1_FREE_Feet with ml
    "I'm strapped to this chair."
    "Maybe I have some room to move."
    scene ep5_MC_Tied_Odelia_A1_FREE_Look_1 with ml
    X "**Hnng**!" with hpunch
    Radford "...what do we do with them?"
    scene ep5_MC_Tied_Odelia_A1_FREE_Outside_Talk with ml
    Radford "They can track them here!"
    Odelia "Calm down! [John] will take care of them when he gets here."
    "Shit! Did that bastard get out?"
    Odelia "You just go watch that detective."
    Odelia "If she tries something, shoot her with the taser."
    Odelia "You can do that much."
    "Gotta get outta here."
    scene ep5_MC_Tied_Odelia_A1_FREE_Hands with ml
    "I need to loosen the binds."
    scene ep5_MC_Tied_Odelia_A1_FREE_Look_2 with ml
    X "**Hnnnnghh**!" with hpunch
    pause 1.0
    X "Come on!!" with vpunch
    pause 1.0
    scene ep5_MC_Tied_Odelia_A1_FREE_Approach_1 with ml
    Odelia "Thought I heard something."
    scene ep5_MC_Tied_Odelia_A1_FREE_Approach_2 with ml
    Odelia "Don't bother! Even breaking some bones won't help."
    X "Are you insane?! What the fuck are you doing?"
    scene ep5_MC_Tied_Odelia_A1_POV_Slap with hpunch
    Odelia "Don't you dare swear in front of me!"
    scene ep5_MC_Tied_Odelia_A1_POV_Talk_Close with ml
    Odelia "Boorish villeins like you need to learn their place!"
    "Who talks like that.."
    scene ep5_MC_Tied_Odelia_A1_POV_Listen with ml
    X "What did you do to [Charlie]?"
    scene ep5_MC_Tied_Odelia_A1_POV_Talk with ml
    Odelia "Don't worry, you'll be together eventually."
    Odelia "However, if you want to meet sooner tell me where [Adalinda] is."
    X "Who?"
    scene ep5_MC_Tied_Odelia_A1_POV_Talk_Close
    Odelia "Don't play dumb!"
    scene ep5_MC_Tied_Odelia_A1_POV_Talk
    Odelia "She runs away and then someone asks to know about our family."
    Odelia "It is obvious."
    scene ep5_MC_Tied_Odelia_A1_POV_Listen with ml
    X "Maybe she doesn't want to come back. Have you thought about that?"
    scene ep5_MC_Tied_Odelia_A1_POV_Talk
    Odelia "What {i}she{/i} wants is of no importance, here is where she belongs!"
    scene ep5_MC_Tied_Odelia_A1_POV_Talk_Close
    Odelia "And who do you think you are to say otherwise!"
    X "I'm her father you bitch!"
    scene ep5_MC_Tied_Odelia_A1_POV_Slap with hpunch
    Odelia "I told you not to swear!!"
    scene ep5_MC_Tied_Odelia_A1_POV_Talk
    Odelia "Yet that would explain so many things."
    scene ep5_MC_Tied_Odelia_John_A1_POV_Entrance with ml
    Odelia "[John]! You're here!"
    scene ep5_MC_Tied_Odelia_John_A1_POV_Embrace with ml
    John "Told you I would return."
    scene ep5_MC_Tied_Odelia_John_A1_POV_Talk with ml
    Odelia "I've missed youuuu!"
    scene ep5_MC_Tied_Odelia_John_A1_POV_Talk_MC
    Odelia "I tied him up real good, just like you taught me!"
    John "That's a good girl [Ode]."
    scene ep5_MC_Tied_Odelia_John_A1_POV_Talk
    John "Now I need you to listen, we're going to do the ritual."
    Odelia "Right now? But she's not here."
    John "Don't worry, I'll take care of that."
    scene ep5_MC_Tied_Odelia_John_A1_POV_Odelia_Leave with ml
    John "You need to make sure everything is ready at the altar."
    John "I'll deal with our guest here."
    Odelia "I understand Father!"
    "Altar, what is he talking about?"
    scene ep5_MC_Tied_John_A1_POV_Approach with ml
    John "Now..."
    X "How the hell did you get ou--"
    scene ep5_MC_Tied_John_A1_POV_Punch with hpunch
    pause 1.0
    scene ep5_MC_Tied_John_A1_POV_Grounded with ml
    X "Ugh!"
    X "Sonofabitch!"
    scene ep5_MC_Tied_John_A1_POV_Look_John_Talk with ml
    John "I didn't say you could speak."
    X "Eat shit!"
    scene ep5_MC_Tied_John_A1_POV_Look_John_Point with ml
    John "It seems like you don't quite grasp the situation here."
    John "Fortunately, there is a use for your body."
    scene ep5_MC_Tied_John_A1_POV_Look_John_Listen
    X "My body? What are you talking about?"
    scene ep5_MC_Tied_John_A1_POV_Look_John_Talk
    John "You'll see."
    scene ep5_MC_Tied_John_A1_POV_Phone_Pickup with ml
    X "Do whatever you want, I won't tell you where she is!"
    scene ep5_MC_Tied_John_A1_POV_Phone_Unlock with ml
    John "There's no need."
    John "I have a feeling she'll be eager to come."
    scene ep5_MC_Tied_John_A1_POV_Phone_Touch with ml
    John "Now, what was the code..."
    pause 1.0
    scene ep5_MC_Tied_John_A1_POV_Phone_Hand
    John "There it is."
    John "[Carla] was it?"
    X "What?"
    John "The person you left [D] with."
    "How does he know? I don't even have her name in there..."
    X "Who's [Carla]?"
    scene ep5_MC_Tied_John_A1_POV_Phone_Unlock
    John "You're probably wondering how I know."
    John "That's very simple."
    scene ep5_MC_Tied_John_A1_POV_Phone_Touch
    John "However, it's a little beyond your comprehension."
    John "So don't worry about that."
    scene ep5_MC_Tied_John_A1_POV_Phone_Touch
    pause 0.5
    John "That should do it."
    scene ep5_MC_Tied_John_A1_POV_Phone_Call with ml
    John "I'm going to leave this here."
    scene ep5_MC_Tied_John_A1_POV_John_Sitting with ml
    X "Do you really expect me to go along with whatever this is?"
    X "You can fuck right off!"
    scene ep5_MC_Tied_John_A1_POV_John_Sit with ml
    John "Silence now!"
    X "..."
    pause 1.0
    X ".....!"
    $ renpy.music.play("audio/music/Executor.ogg", channel=u'music', loop=True, fadein=3)
    "What the fuck?!"
    "I can't talk!!"
    scene ep5_MC_Tied_John_A1_FREE_Hands_Tied with ml
    "Can't move my hands!"
    "WHAT THE FUCK!!"
    Carla "Hello?"
    scene ep5_MC_Tied_John_A1_POV_Phone_Talk_1 with ml
    John_p "It's me."
    Carla "[X]!"
    Carla "Are you alright?"
    "That's.. MY VOICE!"
    "No no no! That's not me!!"
    scene ep5_MC_Tied_John_A1_POV_Phone_Talk_2
    John_p "I'm fine, now listen carefully."
    "No no no! That's not me!!"
    "Don't listen to it!!!"
    scene ep5_MC_Tied_John_A1_POV_Phone_Talk_1
    John_p "I need you to pack up and bring her to this location."
    Carla "OK I'm listening."
    "Shit! How is he doing this??"
    scene ep1_000_black with dissolve
    pause 2.0
    scene ep5_MC_Tied_John_A1_POV_John_Wake with dissolve
    John "Ah!"
    John "Somehow you put up some resistance."
    John "It makes no difference however."
    X "How..."
    X "...did you do that?"
    scene ep5_MC_Tied_John_A1_POV_John_Finish with ml

    John "Wish we could chat some more, but there is work to be done."
    John "You can sleep for now."
    $ renpy.music.play("audio/sfx/boot_hit.ogg", channel=u'sound', loop=False)

    scene ep5_MC_Tied_John_A1_POV_John_Boot with vpunch
    $ renpy.music.stop(channel=u'music', fadeout=1)
    scene ep1_000_black with eye_close

    pause 2.0
    John "I am ready."
    John "Let us begin."
    John_p "{i}Wake up!"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_Chair_Down with eye_open
    X "..."

    $ renpy.music.play("audio/music/Gothic Horror.ogg", channel=u'music', loop=True, fadein=6, fadeout=6)

    scene ep5_Cult_Chamber_Altar_D_Intro_POV_Chair_Front with ml
    "[D]!"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_Stairs_Front with ml
    "What did you do to her?"
    John_p "{i}Gave her a little fairy dust to help her sleep."
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_Sleep with ml
    John_p "{i}See how peaceful she looks?"
    John_p "{i}Doesn't that make you want to.."
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_Touch_Leg with ml
    John_p "{i}..feel her sexy body!"
    "Don't touch her you bastard!"
    John_p "{i}Oh come on! You get a share of the fun."
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_Touch_Leg with ml
    John_p "{i}Just look at those plump lips!"
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_Touch_Pussy with ml
    John_p "{i}You want some of this don't you!"
    "You twisted fuck!"
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_Touch_Leg with ml
    John_p "{i}Oh I know what I am."
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_Erect_Dick with ml
    John_p "{i}But your little guy here has something else in mind."
    "You're the one doing this!"
    John_p "{i}No, that's something deeper, even I can't take full control of it."
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_Spread_Legs with fade
    John_p "{i}Now to get this started while the iron's hot."
    "Don't you fucking DARE!!"
    John_p "Time to wake up [D]!"
    John_p "Daddy needs something from you!"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_wakeup with ml
    D "**mmmmh**"
    D "Dad.."
    "[D]!"
    "GET AWAY!"
    John_p "{i}I'm gonna need you to be quiet now."
    John_p "{i}Just enjoy the show **hahaha**!"
    John_p "{i}Yes, it's me honey!"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Talk_MC with ml
    D "What's going on?"
    D "I was with [Carla] then--"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC
    John_p "It's OK baby."
    John_p "[Carla]'s alright, she had to go for an emergency."
    "What did you do to her?"
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_D_Look_Dick with ml
    D "W-why are you naked?"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC with ml
    John_p "You see, I also have an emergency."
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Talk_MC
    D "What's wrong?"
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_D_Look_Dick with ml
    John_p "It's daddy's penis, see how big it is?"
    D "It is big!"
    John_p "And it's going to get even bigger."
    John_p "But you can help me."
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Talk_MC with ml
    D "How?"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC
    John_p "I need to rub my penis on your pussy [D]."
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_D_Look_Dick with ml
    D "My.. pussy?"
    John_p "That's right, but only if you let me."
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC with ml
    John_p "But you have to explicitly allow it."
    John_p "Can I rub my penis on your pussy [D]?"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Talk_MC
    D "Y-yes.. you can rub my pussy dad."
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC
    John_p "Good girl!"
    "Nooo! [D]!"
    scene black
    call screen Episode5_D_Altar_animations with fade
    $ anim_speed_base = 0.05
    $ anim_curve = "linear"
    scene ep5_D_Altar_anim_POVp
    John_p "How is it, does it feel good?"
    D "It feels like when I touch it, but different."
    scene ep5_D_Altar_anim_POVf
    John_p "Oh you do touch yourself."
    D "S-sometimes..."
    scene black
    call screen Episode5_D_Altar_animations with fade
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_D_Look_Dick with dissolve
    John_p "I'm afraid this isn't going to work."
    John_p "I'll need to put it inside you."
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Talk_MC with ml
    D "Inside me?"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC
    John_p "It's the only way."
    John_p "Have you or someone else even put something inside your pussy [D]?"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Talk_MC
    D "No! I've never done anything like that!"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC
    John_p "Then that means you're still a virgin."
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_D_Look_Dick with dissolve
    John_p "And if I put my penis inside your pussy, then I'll take that away from you."
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC with ml
    John_p "And again I need you to be explicit."
    John_p "Will you give it to me [D]?"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Talk_MC
    D "Yes, you can take my virginity daddy!"
    scene ep5_Cult_Chamber_Altar_D_Intro_POV_D_Listen_MC
    John_p "Such a good girl!"
    scene ep5_Cult_Chamber_Altar_D_Intro_FREE_D_Listen_MC with ml
    John_p "I need you to spread your legs as much as you can."
    D "Like this?"
    John_p "Yes, that's perfect."
    John_p "{i}Look at that! She's spread so wide and yet her lips haven't even parted."
    John_p "{i}This is going to be so TIGHT!"
    scene ep5_Cult_Chamber_Altar_D_A1_FREE_Mount with ml
    D "It's really big!"
    John_p "It will hurt at first, but after a minute it will all pass."
    John_p "And don't worry, it will stretch so I can fit it all."
    scene ep5_Cult_Chamber_Altar_D_A1_POV_Mount with ml
    D "You're going to put it all inside?"
    John_p "Yes but I'll go slow don't worry."
    John_p "Do you trust me?"
    D "I-I do..."
    "I won't let you do it!!"
    scene ep5_Cult_Chamber_Altar_D_A1_FREE_Mount with ml
    John_p "Here I go."
    John_p "3..."
    "NOT..."
    John_p "2..."
    scene ep5_Cult_Chamber_Altar_D_A1_FREE_Fist with ml
    "LIKE..."
    John_p " 1...."

    $ renpy.music.play("audio/sfx/punch_balls.ogg", channel=u'sound', loop=False)

    scene ep5_Cult_Chamber_Altar_D_A1_FREE_Dick_Punch with hpunch
    scene ep5_Cult_Chamber_Altar_D_A1_FREE_Dick_Punch with hpunch
    scene ep5_Cult_Chamber_Altar_D_A1_FREE_Dick_Punch with hpunch
    X "THIS!!!!!"
    John "AH! FUUUCK!"
    scene ep5_Cult_Chamber_Altar_D_A1_POV_Released with ml
    X "I'm back!"
    D "Dad? What's wrong?"
    scene ep5_Cult_Chamber_Altar_D_A1_POV_Released_D with ml
    X "[D], that...it... I lost myself there."
    X "Stay here for now!"
    D "Okay.."
    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Archgate with ml
    "That was his voice, he's close..."
    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Chair_Enter with dissolve
    "'the hell is this?"
    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Chair_Approach with ml
    Odelia "What is it Father?"
    John "He somehow... took back..."
    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Chair_Push_Odelia with vpunch
    X "You insane fucks!"
    Odelia "Aaaaah!"
    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Chair_John_Tackle
    John "How did y--"

    $ renpy.music.play("audio/sfx/punch-140236.ogg", channel=u'sound', loop=False)

    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Chair_John_Punch with hpunch
    John "*oof*"
    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Chair_John_Down with ml
    Odelia "Father, Father!!"
    Odelia "Wake up!"
    Radford "[John]!"
    Odelia "Nooooo!!"
    "I gotta get the fuck out!"
    scene ep1_000_black with fade
    pause 1.0

    $ renpy.music.play("audio/music/Dark Shadows.ogg", channel=u'music', loop=True, fadein=9)

    scene ep5_Cult_Chamber_Leave_A1_POV_D_Talk with fade
    X "[D] that wasn't... I don't know how to explain it..."
    X "But we have to go now!"
    X "We need to find [Charlie]."
    X "Stick close to me!"
    D "I will."
    scene ep5_Dungeon_Hallway_Escape_A1_POV_Hallway_Empty with ml
    "She mentioned that they locked her somewhere..."
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Enter with ml
    "I have to check this dungeon."
    "Is that her?"
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Cell_Door_Find with ml
    X "[Charlie]?!"
    X "Wake up!"
    scene ep5_Dungeon_Hallway_Charlie_A1_FREE_Lying_Down with ml
    X "We have to get out!"
    scene ep5_Dungeon_Hallway_Charlie_A1_FREE_Turn_Ground with ml
    Charlie "[X]!"
    Charlie "Are you alright?"
    X "We're fine fortunately."
    scene ep5_Dungeon_Hallway_Charlie_A1_FREE_Untie with ml
    Charlie "I was waiting for someone to get in and ambush them."
    Charlie "And who's 'we'?"
    X "They got [D], but she's safe now."
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Door_Point with ml
    Charlie "Great! Didn't see a key."
    Charlie "But there's an axe over by the fireplace."
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Axe_Take with ml
    X "Got it!"
    scene ep5_Dungeon_Hallway_Escape_A1_POV_Enter_Hallway with ml
    X "Come here, and watch the hallway."
    X "Shout if you see or hear someone."
    D "Okay dad!"
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Door_Axe_Swing with ml
    X "Stand back!"
    $ renpy.music.play("audio/sfx/hit_metal.ogg", channel=u'sound', loop=False)
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Door_Axe_Hit with vpunch
    pause 0.4
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Door_Axe_Swing
    pause 0.2
    $ renpy.music.play("audio/sfx/hit_metal.ogg", channel=u'sound', loop=False)
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Door_Axe_Hit with vpunch

    pause 0.4
    X "Come on!"
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Door_Axe_Swing
    pause 0.7
    $ renpy.music.play("audio/sfx/hit_metal.ogg", channel=u'sound', loop=False)
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Door_Axe_Hit with vpunch
    scene ep5_Dungeon_Hallway_Charlie_A1_POV_Door_Axe_Hit with vpunch
    X "It's loose!"
    scene ep5_Dungeon_Hallway_Charlie_Open_Cell_Door with dissolve
    Charlie "Let's move!"
    scene ep5_Dungeon_Hallway_Escape_A1_POV_Exit_D_look_Hallway with ml
    X "Hear anything [D]?"
    scene ep5_Dungeon_Hallway_Escape_A1_FREE_D_back with ml
    D "No, it's quiet."
    scene ep5_Dungeon_Hallway_Escape_A1_POV_Exit_Hallway with dissolve
    Charlie "There's a slight breeze this way."
    Charlie "Let's go!"
    scene black with fade
    pause 1.0
    D "It's really dark!"
    X "Just follow my voice [D]."
    Charlie "I see something..."
    scene ep5_Foyer_Exit_Dungeon_POV_D_Charlie_Back with dissolve

    X "This is the entrance."
    Charlie "I can't tell if the car is still there."
    X "[John] mentioned something about staging an accident."
    Charlie "That could mean it's still around."
    X "We could make a run for it."
    scene ep5_Foyer_Exit_Dungeon_FREE_Charlie_Out with ml
    Charlie "No! If there are others, we could all get caught."
    Charlie "Listen, I'll go out and look for it."
    Charlie "There's a gun hidden, I doubt they found it."
    Charlie "You two wait here and stay quiet."
    scene ep5_Foyer_Exit_Dungeon_POV_D_Listen with dissolve
    "What the happened here..."
    X "Are you cold? I'll get you something."
    scene ep5_Foyer_Exit_Dungeon_POV_Sheet with ml
    X "We need to find a spot to--"
    $ renpy.music.play("audio/music/psycho_track.ogg", channel=u'music', loop=True, fadein=3)

    Odelia "YOU!!"
    scene ep5_Foyer_Exit_Dungeon_POV_Odelia_Enter with ml
    Odelia "You've ruined everything!!"
    X "Shit!"
    Odelia "Father is-is-is DEAD!!"
    Odelia "Now my [Adalinda] can never come back to me!"
    "She's insane!"
    X "Calm down and put the gun away, you don't want to hurt anyone!"
    "I need to get closer.."
    Odelia "Silence!!"
    scene ep5_Foyer_Exit_Dungeon_POV_Odelia_Point_D with ml

    Odelia "And you!"
    Odelia "You can go meet your ungrateful whore of a mother!"
    X "NOO!"
    Odelia "DIE!!"
    $ renpy.music.play("audio/sfx/Gunshot_2.ogg", channel=u'sound', loop=False)

    scene ep5_Foyer_Exit_Dungeon_POV_MC_Jump
    X "**Ah**!"
    scene ep5_Foyer_Exit_Dungeon_POV_MC_takes_D
    X "Duck!"
    scene ep5_Foyer_Exit_Dungeon_POV_Odelia_Close with ml
    Odelia "I should have killed you from the beginning!"
    Odelia "Father wanted you alive, and now he's de--"
    $ renpy.music.play("audio/sfx/Gunshot_3.ogg", channel=u'sound', loop=False)

    scene ep5_Foyer_Exit_Dungeon_POV_Odelia_Shot
    pause 1.0
    scene ep5_Foyer_Exit_Dungeon_POV_Odelia_Floor with ml
    D "Dad you're bleeding!!"
    scene ep5_Foyer_Exit_Dungeon_POV_MC_Wound with ml
    X "Yeah.."
    Charlie "Hurry we need to get to the car!"
    scene ep5_Leave_After_Escape_A1_POV_D_scared with ml
    Charlie "[D], I'm counting on you to keep pressure on that wound."
    D "I will!"
    X "That's not.. necessary, I can hold..."
    Charlie "Try to stay awake [X]!"
    X "I am! I just..."
    D "Dad!"
    X "It's getting.. blurry..."
    D "DAD!!"
    scene black with eye_close
    $ renpy.music.play("audio/music/requiem in white.ogg", channel=u'music', loop=True, fadein=2,fadeout=2)
    pause 3.0

    scene ep5_Dream_Emily_Theatre_Entrance with fade
    "...didn't know this place existed."
    scene ep5_Dream_Emily_Theatre_Stage with ml
    "Can't hurt if I get closer.."
    scene ep5_Dream_Emily_Stage_FREE_Keys_1 with ml
    "Who is she?"
    scene ep5_Dream_Emily_Stage_FREE_Keys_2 with ml
    "Never seen her around"
    scene ep5_Dream_Emily_Stage_POV_Keys_1 with ml

    X "It's beautiful!"
    $ renpy.music.stop(channel=u'music', fadeout=0)
    scene ep5_School_Stage_Emily_Meet_POV_Emily_Stop with ml
    "Piano girl" "Uh, thank you?"
    X "Sorry, didn't mean to scare you."
    scene ep5_School_Stage_Emily_Meet_POV_Emily_Listen with ml
    X "Just wanted to hear the song better."
    scene ep5_School_Stage_Emily_Meet_POV_Emily_Talk
    "Piano girl" "Oh, are you here to play?"
    scene ep5_School_Stage_Emily_Meet_POV_Emily_Listen
    X "What? No, I was just passing by. Had no clue this hall was here even."
    X "I'm [X] by the way."
    scene ep5_School_Stage_Emily_Meet_POV_Emily_Talk
    Emily "[Emily], pleased to meet you."
    scene ep5_School_Stage_Emily_Meet_POV_Emily_Listen
    X "So, do you have a show later or something?"
    scene ep5_School_Stage_Emily_Meet_POV_Emily_Talk
    Emily "No, I'm just practicing."
    scene ep5_School_Stage_Emily_Meet_POV_Emily_Sit_Invite with ml
    Emily "Do you wanna sit down?"
    Emily "It's the best seat in the house."
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Listen with ml
    X "Well it sounds good to me."
    X "If that's worth anything."
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Talk_A with ml
    Emily "Still need some more practice."
    Emily "But I'll take the compliment."
    scene ep5_School_Stage_Seats_Empty with ml
    X "We're all alone here."
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Listen with ml
    X "Aren't you scared I might try something?"
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Talk_A
    Emily "You do have a tough facade."
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Lean_In with ml
    Emily "But your eyes tell a different story."
    X "What if you're wrong, is it worth the risk?"
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Talk_Away
    Emily "Can't really know unless someone takes it."
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Listen
    X "That's one way to look at it."
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Talk_B
    Emily "So what are you doing around here?"
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Listen
    X "Actually, I'm not supposed to be here."
    scene ep5_School_Stage_Emily_Sit_A1_POV_Emily_Talk_Away
    Emily "We have something in common then."
    scene ep5_School_Stage_Seats_Empty with ml
    X "I don't even where here is."
    $ renpy.music.play("audio/ambience/seawaves_calm.ogg", channel=u'ambience', loop=True, fadein=3)
    $ renpy.music.play("audio/music/intro_dream_2.ogg", channel=u'music', loop=True, fadein=3)
    Emily "It's our spot silly."
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Listen_2 with dissolve
    X "What spot?"
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Talk_2 with ml
    Emily "Where we used to meet. Remember?"
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Listen_2 with ml
    X "Oh yeah the beach!"
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Listen_1 with ml
    X "I came here every year after..."
    X "...after you left!"
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Poke with ml
    Emily "You never skipped the day."
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Listen_1 with ml
    X "I waited, I even got a big house."
    X "For a big family, that was the plan."
    X "But..."
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Talk_2 with ml
    Emily "There was someone else at the beach that day."
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Listen_1 with ml
    X "Our daughter...."
    X "Her name... I gave it.. it's [D]!"
    X "Do you like it?"
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Talk with ml
    Emily "It's beautiful."
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Listen_2 with ml
    X "She likes it too."
    X "And she also looks just like... you."
    X "I... missed... you [Emily]!"
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Poke with ml
    Emily "I missed you too big guy!"
    Emily "But it's time to wake up now."
    X "What? No, I wanna stay here with you."
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Stand_Up with dissolve
    Emily "We can't do that, she needs you."
    X "I wanna come with you!"
    scene ep5_Emily_Coma_Dream_A1_POV_Emily_Depart with dissolve
    Emily "You must protect her [X]."
    Emily "She is still in danger!"
    X "[Emily]..."
    scene black with fade
    $ renpy.music.stop(channel=u'ambience', fadeout=None)
    pause 2
    $ renpy.music.play("audio/music/bathroom-chill-background-music-14977.ogg", channel=u'music', loop=True, fadein=9)

    scene ep5_Hospital_Room_Bed_A1__POV_D_Resting with eye_open

    "Where am I?"
    "Head's all fuzzy."
    scene ep5_Hospital_Room_Bed_A1__FREE_Hand_Squeeze with ml

    X "[D]!"
    D "*mmmh*"
    scene ep5_Hospital_Room_Bed_A1__POV_D_Wakeup with ml
    D "Dad!!"
    scene ep5_Hospital_Room_Bed_A1__POV_D_Hug with ml
    D "You're awake!!"
    X "Ah!"
    scene ep5_Hospital_Room_Bed_A1__POV_D_Worried with ml
    D "I'm sorry, I'm sorry!"
    D "Did I hurt you?"
    X "No it's fine, don't worry."
    X "I'm just a bit stiff."
    scene ep5_Hospital_Room_Bed_A1__POV_D_Sit_Listen with ml
    X "How long has it been since..."
    scene ep5_Hospital_Room_Bed_A1__POV_D_Sit_Talk_1
    D "Two weeks I think."
    scene ep5_Hospital_Room_Bed_A1__POV_D_Sit_Listen
    X "And where have you been staying, who's been taking care of you?"
    scene ep5_Hospital_Room_Bed_A1__POV_D_Sit_Talk_1
    D "I've been with [Eileen] at the shop."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_D_Eileen_Enter with ml
    Eileen "Only when she had to leave."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_Eileen_Talk_D with ml
    Eileen "As soon as visiting hours came, she would be right back here."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_Eileen_Talk_MC_2
    Eileen "And welcome back!"
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_Eileen_MC_Listen
    X "Wait what?!"
    X "So is that why you were sleeping here?"
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_D_Talk_MC
    D "The doctor said you could wake up at any time."
    D "And maybe even go back in a coma after."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_Eileen_Talk_MC_2
    Eileen "She overheard when I was speaking to the doctor."
    Eileen "So it's on me for getting her all worked up."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_Eileen_MC_Listen
    X "Well I'm up now and not going back."
    X "But I could use a bite to eat."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_Eileen_Talk_D
    Eileen "[D], how about you select breakfast."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_Eileen_Talk_MC_1
    Eileen "I'm sure dad's starving."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_D_point_exit
    D "What do you want? They have donuts, cookies, macaroni, sandwiches..."
    X "Anything's fine really, pick whatever {i}you{/i} like."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_Eileen_Talk_D
    Eileen "We can get those hotdogs you really enjoyed."
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_D_Talk_Eileen
    D "Really, can we?"
    scene ep5_Hospital_Room_Bed_D_Eileen_A1_POV_D_stand_Listen with ml
    Eileen "Of course dear!"
    Eileen "You go on ahead, I'll be down in a few minutes."
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Talk with fade
    Eileen "So, what have you been up to? Anything interesting you want to share?"
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Listen
    X "Do I have the right to remain silent?"
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Talk
    Eileen "No!"
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Listen
    X "Yeah I figured."
    X "So I met her 'parents'."
    X "Didn't do anything stupid."
    X "We just came in the front gate, sat down and talked."
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Talk
    Eileen "The front gate?"
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Listen
    X "Yeah, it was a huge mansion."
    X "[Charlie] asked them a few questions, see what they had to say."
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Talk
    Eileen "Right. And then you got shot?"
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Listen
    X "That came a little later."
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Talk
    Eileen "Well you can fill me in, your detective friend didn't say anything."
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Listen
    X "Thanks for taking care of her [Eileen]!"
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Talk
    Eileen "Of course, and you better have a good story for this."
    Eileen "[D] hasn't spoken about it and I don't want to push."
    Eileen "You should talk to her."
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Listen
    X "Yeah there's a lot to deal with."
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Talk
    Eileen "Also the school principal is in a coma."
    X "[Carla]?"
    Eileen "Yes."
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Listen
    X "Is she here?"
    scene ep5_Hospital_Room_Bed_Eileen_A1_POV_Eileen_Stand_Point with ml
    Eileen "Yeah."
    Eileen "I'll call the doctor now and get you some actual food."


    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Enter with fade
    Joan "Look who decided to remain with us mortals."
    X "Hey Doc! Are you here for me?"
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1 with ml
    Joan "I don't know. Are you the blood loss induced coma patient with a gunshot wound who recently woke up?"

    X "That's probably right. But I feel fine, maybe a little dazed."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_2 with ml
    Joan "Think you can walk?"
    X "Probably."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1
    Joan "There wasn't any major brain damage, you got lucky."
    X "{i}Major{/i} brain damage?"
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1
    Joan "The scans look good."
    Joan "But to be really sure, I need to see you move."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Listen
    X "Give me some music then, I'll show you my moves."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1
    Joan "You'll get a chance to shine."
    Joan "But we still have to run some tests, it'll take a day or so."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_2
    Joan "Oh and congratulations by the way!"
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Listen
    X "What for?"
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1
    Joan "I'm not allowed to share the results of your paternity test like this, but since we're alone."
    X "So it's official, I'm a... father?"
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Listen
    X "I mean I knew, but it's still good to hear it from someone."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_2
    Joan "Figured the news would help."
    Joan "And I would like to do that check-up ASAP, if you're feeling up for it."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_MC_Stand with dissolve
    X "Let's go, I need to stretch anyway."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_MC_Walk with ml
    Joan "Don't force it, the wound can still open."
    scene ep5_Hospital_Hallway_A1_POV_Hallway with fade
    Joan "It's not far, take it slow."
    X "I got this!"

    scene black with fade
    pause .3
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1 with ml
    Joan "So far everything looks good."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_2
    Joan "For today, just get some rest."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Listen
    X "There's another comatose patient, [Carla] if you know where she is."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1
    Joan "I do. Is she a friend?"
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Listen
    X "Yes, if I could get her room..."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_2
    Joan "So long as you don't sprint over."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Listen
    X "I'll be a patient patient, promise!"

    scene ep5_Hospital_Room_Carla_A1_POV_Door_Entrance_2 with fade
    "This is her."
    scene ep5_Hospital_Room_Carla_A1_POV_Bed_Carla with ml
    "At least she's still alive."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Read with ml

    X "Hey [Sophie]!"
    X "How are you holding up?"
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Wound with ml
    Sophie "[X] you woke up?!"
    Sophie "Should you be walking around?"
    X "Everyone's so worried!"
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Listen with ml
    X "I'm even tougher than I look you know!"
    X "You didn't want to leave her alone, I get it."
    X "So you're keeping her company."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Talk_Away with ml
    Sophie "I read that it helps to talk when in a coma."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Look_Away with ml
    X "I'm sure [Carla] will be very happy with you when she wakes up."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Listen with ml
    X "And you're also keeping up with your studies."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Talk with ml
    Sophie "She would be upset if I fell behind."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Look_Away

    Sophie "Hello Ms. [Maya]!"
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Bedside_Talk_Carla with ml
    Maya "Still no change?"
    Sophie "Not yet."
    X "Hello there!"
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Bedside_Talk_MC with ml
    Maya "[X]! You're recovered?"
    X "I can walk at least, waiting for the tests."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Talk_MC with ml
    Maya "Hope everything will be fine."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Listen_MC
    X "Me too, but after hearing about [Carla] I had to come."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Listen with ml
    X "And found [Sophie] here keeping her company."
    X "So she's in good hands."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Listen_MC with ml
    X "Did they say how this happened?"
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Talk_MC
    Maya "I was told it was a mugging."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Listen_MC
    X "I see."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Look_Carla with ml
    Maya "I think we have time to pass by the chapel for a few prayers."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Talk_Sophie with ml
    Maya "If that's fine with you [Sophie]?"
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Listen with ml
    X "Hey don't worry, I'll visit her while I'm here."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Listen_MC with ml
    X "And did they build a chapel in town?"
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Talk_MC
    Maya "Yes, it's at the park near the river."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Listen_MC
    X "Aren't they still working on the old church that burned down?"
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Talk_MC
    Maya "It's still ongoing."
    Maya "But at least there's a place we can gather."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Look_Carla with ml
    Maya "I've been praying there every day these past weeks."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Listen_MC with ml
    X "Appreciated, thank you."
    X "Might go visit it one day."
    scene ep5_Hospital_Room_Maya_A1_POV_Couch_Maya_Sitting_Talk_MC
    Maya "Most people come on Sundays, so it's very quiet during the week."
    X "Good to know."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Listen with ml
    X "I'll se you around [Sophie], we gotta catch up on the math."
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Talk
    Sophie "I'm okay right now."
    Sophie "You just get better [X]!"
    scene ep5_Hospital_Room_Sophie_A1_POV_Couch_Sophie_Listen
    X "That's a very levelheaded response."

    scene ep5_Hospital_Hallway_Bailey_A1 with fade
    "Dammit, it's my fault this happened to her."
    scene ep5_Hospital_Hallway_Bailey_A2_POV_Meet with ml
    "???" "Good day Mr. [X]!"
    scene ep5_Hospital_Hallway_Bailey_A2_POV_Listen_A1 with ml
    X "Hello, do we know each other?"
    scene ep5_Hospital_Hallway_Bailey_A2_POV_Talk_A1 with ml
    Bailey "I am Detective [Bailey], I'm working on your case with [Charlie]."
    scene ep5_Hospital_Hallway_Bailey_A2_POV_Talk_A3
    Bailey "If you could answer a few about what you've been through."
    scene ep5_Hospital_Hallway_Bailey_A2_POV_Listen_A1
    X "[Charlie] never mentioned you, so I won't be answering anything."
    X "And I'm still recovering."
    scene ep5_Hospital_Hallway_Bailey_A2_POV_Talk_A2
    Bailey "Of course take your time."
    Bailey "I understand it is a very difficult period for you."
    scene ep5_Hospital_Hallway_Bailey_A2_POV_Hand_Card with ml
    Bailey "So when you're feeling better we can meet at the station."
    Bailey "Here is my card."
    X "Yeah sure."

    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Enter with fade
    Charlie "Hey, how are you holding up?"
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Listen with ml
    X "Good, all things considered."
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Talk_MC_1
    Charlie "You talked to a detective earlier?"
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Listen
    X "No! I mean I did but didn't tell him anything."
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Talk_MC_2
    Charlie "Good, you should focus on getting better first."
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Listen
    X "So what happened after I passed out?"
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Talk_MC_1
    Charlie "[D] held on to the wound all the way, she was quite the trooper!"
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Talk_Away
    Charlie "And we got lucky that the hospital wasn't too far."
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Listen
    X "Yeah she's been through so much."
    X "Have you talked to her about it?"
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Talk_MC_2
    Charlie "I didn't want to pressure her."
    Charlie "Told her to talk when she feels ready."
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Listen
    X "I appreciate that, thank you!"
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Talk_MC_1
    Charlie "Call me when they let you out, I'll come get you."
    X "Is that necessary?"
    scene ep5_Hospital_Room_Bed_Charlie_A1_POV_Charlie_Exit with ml
    Charlie "Yes, it is. We'll talk more then."


    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_give_Hotdog with fade
    D "Are the toppings okay dad?"
    X "It's perfect!"
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_talk_MC_Dogs with ml
    D "They're much better if you get them later in the day."
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Eileen_Listen_Dogs
    X "That's right, the broth is more concentrated."
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_Eileen_talk_MC_Dogs
    Eileen "Also they were on the house, [Jimmy] sends his regards."
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Eileen_Listen_Dogs
    X "I'll have to drop by some day."
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_All_Eating with ml
    "**collective chomps**"
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_All_Eating
    pause 0.3
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Talk_MC with fade
    D "How much longer will you stay here?"
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Eileen_Listen
    X "Just need to get some tests done."
    X "I 'm out as soon as the doc gives me the green light."
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Talk_MC with ml
    D "They said it takes months for the wound to fully heal."
    D "So please don't rush!"
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Eileen_Listen
    X "I won't, promise!"
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_Eileen_Talk_MC with ml
    Eileen "She hasn't been sleeping well all this time."
    Eileen "So we should be going home now."
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Close_MC with ml
    X "Don't you worry about me [D], only need some rest and then I'll be out."
    D "If you get hungry I can bring food."
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Hug_MC_1 with dissolve
    X "You just get yourself a good night's sleep."
    X "I'll survive whatever they feed me here."
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Hug_MC_2 with ml
    D "I've been learning how to bake from [Eileen]!"
    X "Really?"
    X "That's something to look forward to!"
    scene ep5_Hospital_Room_Bed_D_Eileen_A2_POV_D_Eileen_Leaving with dissolve
    Eileen "Be careful now [X]! She'll be waiting for you."
    X "I will."
    D "Get well dad!"
    X "I will."
    X "See you girls soon!"
    $ renpy.music.stop(channel=u'music', fadeout=5.0)
    scene black with fade
    pause 0.3
    scene ep5_Hospital_Room_Window_Night with dissolve
    "What the hell happened back there?"
    scene ep5_Hospital_Room_Window_Night_Door with ml
    "Can't even sleep, I need to think."
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Long with fade
    "It's so quiet now..."
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Entrance with ml
    "I promised I'd check on [Carla]."
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Room_Carla with ml
    "She's still under."
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Bed_Carla with ml
    X "Shouldn't have involved you in this mess."
    X "I could've left town or even the country."
    X "I was too focused on finding out about her 'parents'."
    X "If you can hear me, I'm sorry!"
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Bed_Carla
    pause 1.0
    "???" "{size=-18}{i}Fuck her face!"

    $ renpy.music.play("audio/sfx/impact_metal.ogg", channel=u'sound', loop=False)

    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Room_Door

    X "What the hell!"
    X "Who's there?"
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Room_Door
    pause 2.0
    "I'm fucking hearing things."
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Room_Carla with ml
    "Better go back."

    $ renpy.music.play("audio/sfx/scare_piano.ogg", channel=u'sound', loop=False)

    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Room_Void
    pause 0.15
    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Archgate
    pause 0.15
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Room_Void
    pause 0.15
    scene ep5_Cult_Chamber_Fosters_Exposed_A1_POV_Archgate
    pause 0.15
    scene ep5_Hospital_Hallway_Wonder_A1_POV_Hallway_Room_Carla
    pause 0.5
    "What the fuck!"
    "Am I hallucinating now?"
    scene ep5_Hospital_Room_Window_Night with fade
    "Need to find out what happened at the mansion."
    "There must be something that can explain it somehow..."
    scene ep5_Hospital_Room_Window_Night with eye_close
    pause 0.5

    $ renpy.music.play("audio/music/bathroom-chill-background-music-14977.ogg", channel=u'music', loop=True, fadein=9)

    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1 with fade
    Joan "Everything looks fine."
    X "So am I free to leave?"
    Joan "You're not under arrest, you can leave anytime."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_2
    Joan "Just be careful, the wound is not completely healed yet."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Listen
    X "Alright, I'll try to keep that in mind."
    scene ep5_Hospital_Room_Bed_Joan_A1_POV_Joan_Talk_1
    Joan "Here's a prescription for a few things..."

    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A2 with fade
    X "So who was that detective the other day?"
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A2
    Charlie "Officially, he's on [Emily]'s case with me."
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1 with ml
    Charlie "Practically, he's a careerist who dumped all the work of looking for her on me the moment he realized it would take some time."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "And now he's looking to score some credit."
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1
    Charlie "Maybe all of it if he can."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "So what comes next?"
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1

    Charlie "Well since we don't have any tapes, and both her parents and [John] are dead."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "Wait, they're all dead?!"
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1
    Charlie "Yes, they found [Radford] shot in the head next to [Odelia], looks like he killed himself when finding the wife."
    X "Shit!"
    Charlie "And [John] was in that dungeon they had, he bled out from a head wound."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "That was probably from me punching him."
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1
    Charlie "In self defense, because he attacked you right?"
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "Yeah... that's right."
    X "And what happened to [Carla]?"
    Charlie "It seems she was hit, knocked out and left on the street."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "Yeah it was [John] that called her and used my voice."
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1
    Charlie "What do you mean 'used your voice'?"
    "Shit, I can't really tell her exactly what happened!"
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "I don't know exactly how but it was convincing enough."
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1
    Charlie "Did he synthesize it?"
    X "Possibly, I'm not sure."
    Charlie "Well that explains why she was there at least."
    Charlie "Now about what they were doing in the dungeon there."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "After he knocked me out in the greenhouse, I woke up in the dungeon."
    X "They really couldn't tie a knot."
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1
    Charlie "That was fortunate."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "Then I looked for [D] and she was lying naked on the altar."
    X "I woke her up and heard them further away."
    X "Who knows what they would've done to her!"
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1
    Charlie "I understand."
    Charlie "And [Odelia] would've shot [D] if you hadn't intervened."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "True."
    X "What about the reason I was there with you?"
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A1
    Charlie "You went there as her real father and also a witness."
    Charlie "And about the journal, did you find it?"
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A1
    X "No, I think they might've found it and burned it or something."
    scene ep5_Road_City_Charlie_Day_A1_POV_Talk_A2
    Charlie "Too bad, it could've helped but the case is almost closed."
    Charlie "Unless somtheing comes up."
    Charlie "Now just stick to the story, if you remember anything else, call me."
    scene ep5_Road_City_Charlie_Day_A1_POV_Listen_A2
    X "Will do."
    $ renpy.music.play("audio/music/spring-vibes-198610.ogg", channel=u'music', loop=True, fadein=9)
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen with fade
    Eileen "...we can be flexible here."
    Eileen "Instead of chocolate chips, maybe add dried fruits or some seeds."
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_Close with ml
    D "What about mixing them together?"
    Eileen "Very good! We can get really creative with it."

    X "*mmm* something smells good here!"
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_Notice with ml

    D "Dad!"
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_Hug with ml
    D "Are you recovered? Does the wound still hurt?"
    X "Oh yeah, I completely forgot about it!"
    D "Can you stay home?"
    scene ep5_D_and_Eileen_cook_A1_FREE_Kitchen_Hug_Feet with dissolve
    X "I can stay for as long as you want."
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_Eileen_talk with dissolve
    Eileen "Just wait till you taste her cookies, you'll never want to leave."
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_Girls_Listen
    X "You're the one making them?"
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_D_talk with ml
    D "[Eileen] is preparing all the ingredients, I mostly watch."
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_Eileen_talk
    Eileen "She can handle the whole thing, wait and see."
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_Girls_Listen
    X "Alright, I'll stay out of your way."
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_D_talk
    D "You can help if you want!"
    scene ep5_D_and_Eileen_cook_A1_POV_Kitchen_Girls_Listen
    X "No I don't wanna ruin it. I'll be hands-off!"
    scene black with dissolve
    scene ep5_D_and_Eileen_cook_A2_POV_Kitchen_D_Cream_Face with ml
    D "*Ah*!."
    X "You okay?"
    D "Yes, I just made it too thin."
    scene ep5_D_and_Eileen_cook_A2_POV_Kitchen_D_Cream_Face_Wipe with ml
    X "Hey don't worry, it's part of the learning process."
    D "That's what [Eileen] said."
    scene ep5_D_and_Eileen_cook_A2_POV_Kitchen_Eileen_Stove with ml
    Eileen "And she also mentioned to move slowly so you can observe the motions better."
    D "Yes! I kinda forgot."
    scene ep5_D_and_Eileen_cook_A2_POV_Kitchen_D_Cream_MC_Hand with ml
    D "Oh and taste testing, that's also important!"
    D "Hold on a moment dad!"
    scene ep5_D_and_Eileen_cook_A2_POV_Kitchen_D_Suck_MC_Thumb with ml
    pause 0.5
    D "*mmh*!"
    X "I.. don't know if it tastes the same this way."
    scene ep5_D_and_Eileen_cook_A2_POV_Kitchen_D_Cream_MC_Hand with ml
    D "You're right, better use a spoon."
    scene ep5_D_and_Eileen_cook_A2_POV_Kitchen_D_Cream_MC_Hand
    $ renpy.music.play("audio/sfx/house-doorbell.ogg", channel=u'sound', loop=False)
    pause 1
    X "I'll get the door!"
    scene ep5_Khalil_Entrance_A1_POV_Khalil_Greeting with dissolve

    Khalil "Yo what' up dog!"
    X "Look who's here!"
    scene ep5_Khalil_Entrance_A1_POV_Khalil_Smile_Talk with ml

    Khalil "You don't answer the phone and then I hear you got fucking shot!"
    scene ep5_Khalil_Entrance_A1_POV_Khalil_Smile_Listen with ml
    X "Watch the language, my daughter's here."
    X "And it's a long story."

    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC with dissolve
    Khalil "You know there was that time when you got shot at."
    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen with ml
    X "By [Jerold]'s crew, I remember."
    D "What happened?"
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Eileen_Listen with ml
    X "It was nighttime, so they probably didn't recognize me."
    scene ep5_D_Eilleen_watch_TV_A1_POV_Eileen_Talk_MC with ml
    Eileen "And they were flat drunk too."
    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen with ml
    X "So were we, it was morning I think."
    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
    Khalil "Yeah we got kicked out since it was closing."
    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_Girls
    Khalil "So they thought we were easy prey, pulled a piece and wanted money."
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Eileen_Listen with ml
    X "I did like most people and just gave it up."
    X "We were drinking all night so we didn't have much left."
    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_Girls
    Khalil "So they got mad and just started blasting!"
    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
    Khalil "Then [X] and I separated and went to flank them."
    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen
    X "Yeah they didn't last long after."
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Eileen_Listen with ml
    X "Anyway, how about a movie?"
    X "[D] has a lot of catching up to do with the current culture."
    scene ep5_D_Eilleen_watch_TV_A1_POV_Eileen_Talk_MC with ml
    Eileen "Sure, just skip the horror ones for now. Okay?"
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Eileen_Listen with ml
    X "Of course, we're saving the best for last!"

    scene ep5_Livingroom_Couch_TV_SW_A1 with fade

    "Vader" "No, I am your father!"
    "Luke" "NOOOOOO!!"
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Talk_MC with dissolve

    D "Ooh, I get it now!"
    D "But what about the first three episodes?"
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Eileen_Listen with ml
    X "This is the order they aired, and you wouldn't get the same experience if you watched them chronologically."
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Yawn with ml
    D "Think I under-*yawn*."
    Eileen "It's about time we girls returned to the hangar."
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Talk_Eileen
    D "I can stay a little longer."
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Eileen_Listen
    X "It's OK, we can pick up from where we left off, tomorrow."
    scene ep5_D_Eilleen_watch_TV_A1_POV_D_Talk_MC
    D "Can we?"
    scene ep5_D_Eilleen_watch_TV_A1_POV_Eileen_Talk_D with ml
    Eileen "Of course dear!"
    Eileen "Now let's go get ready for a bath."
    scene ep5_Khalil_watch_TV_A1_POV_Khalil_Joint_Show with ml

    Khalil "Hey, you wanna hit this?"
    menu:
        "Light it":
            $ ep5_blunt = True
            X "Light that bitch up!"
            Khalil "Hell yeah!"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Joint_Light with ml
            X "So are you just walking around with this stuff on you?"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Joint_Offer with ml
            Khalil "Nah, [Eileen] mentioned you might be getting out soon."
            Khalil "So I got you something to take the edge off."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen with ml
            X "My man!"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC with ml
            Khalil "So can you tell me anything about what the fuck happened?"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen
            X "I really can't right now."
            X "Just know that things are calm for the time being."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
            Khalil "Calm? Did you kill everybody?"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen
            X "Well no."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
            Khalil "So they're not all dead."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen
            X "Look, people got hurt because I got them involved in this."
            X "So I just don't want that to happen."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Joint_Offer with ml
            Khalil "Whatever it is man, I got your back."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Joint_Light with ml
            X "Yeah I know."
            X "If you wanna crash here, there's plenty of room."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC with ml
            Khalil "Aww thanks man!"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_Point_Front with ml
            Khalil "But if I wake up looking at those fucking windows.."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC with ml
            Khalil "You're paying for the funeral."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_Point_Back with ml
            Khalil "So I'm gonna head off before I fall off the edge."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen with ml
            X "You really need to work on that fear of heights."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Leave with dissolve
            Khalil "Think I'll stick to the plains."
            Khalil "I'll see myself the fuck off!"
            X "Yeah get the fuck outta my house!"
            jump ep5_Bedroom_Eileen_ss
        "Pass":

            $ ep5_blunt = False
            X "Not today man."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC with ml
            Khalil "Alright, have it your way."
            Khalil "So can you tell me anything about what the fuck happened?"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen
            X "I really can't right now."
            X "Just know that things are calm right now."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
            Khalil "Calm? Did you kill everybody?"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen
            X "Well no."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
            Khalil "So they're not all dead."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
            X "Look, people got hurt because I got them involved in this."
            X "So I just don't want that to happen."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
            Khalil "Whatever it is man, I got your back."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC
            X "Yeah I know."
            X "If you wanna crash here, there's plenty of room."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC with ml
            Khalil "Aww thanks man!"
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_Point_Front with ml
            Khalil "But if I wake up looking at those fucking windows.."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_MC with ml
            Khalil "You're paying for the funeral."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Talk_Point_Back with ml
            Khalil "So I'm gonna head off before I fall off the edge."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Listen with ml
            X "You really need to work of that fear of heights."
            scene ep5_Khalil_watch_TV_A1_POV_Khalil_Leave with dissolve
            Khalil "Think I'll stick for the plains."
            Khalil "I'll see myself the fuck off!"
            X "Yeah get the fuck outta my house!"
            jump ep5_Eileen_morning_leave


label ep5_Bedroom_Eileen_ss:

    scene ep5_Eileen_night_Couch_A1_POV_Eillen_Approach with fade
    Eileen "*sniff* Is that weed?"
    X "It's not mine officer!"
    scene ep5_Eileen_night_Couch_A1_POV_Eileen_Foot_Up with dissolve
    Eileen "That's right, it's mine!"
    Eileen "Now pass it here."
    menu:
        "(need more points)" if Eileen_p < 2:
            pass
        "Answer her teasing" if ep3_eileen_buttjob == "accepted" or ep2_eileen_handy == True or Eileen_p >= 2:
            $ ep5_eileen_ss = "smashed"
            $ Eileen_p += 1
        "Pass the joint":
            X "Fine geez..."
            jump ep5_Eileen_morning_leave

    $ renpy.music.play("audio/music/get_it.ogg", channel=u'music', loop=True, fadein=8)
    scene ep5_Eileen_night_Couch_A1_POV_Eileen_Hold_Listen with dissolve
    X "I think you want something else."
    Eileen "What are you doing?"
    X "You're gonna act all innocent now?"
    scene ep5_Eileen_night_Couch_A1_FREE_Bulge_Pussy with ml
    X "After putting yourself on display like that."
    scene ep5_Eileen_night_Couch_A1_FREE_Eileen_Pussy with ml
    Eileen "Looks like you've recovered nicely."
    scene ep5_Eileen_night_Couch_A1_POV_Eileen_Hold_Listen with ml
    X "And you've also been a real help here."
    scene ep5_Eileen_night_Couch_A1_FREE_Bulge_Rub_Pussy with ml
    X "So you deserve a big reward."
    X "Don't you agree?"
    Eileen "Wait!"
    scene ep5_Eileen_night_Couch_A1_FREE_Eilleen_Face with ml
    Eileen "It's a little too breezy here."
    X "Let's go upstairs then."
    scene ep5_Eileen_Bedroom_SS_Foreplay_A_FREE_Eileen_Entrance with fade
    Eileen "You're not your usual restrained level-headed self."
    X "I have my breaking point too."
    scene ep5_Eileen_Bedroom_SS_Foreplay_A_FREE_Eileen_Touch_Dick with ml
    Eileen "It's already so hard!"
    Eileen "I better take care of it right away."
    X "You always do all the work."
    scene ep5_Eileen_Bedroom_SS_Foreplay_A_FREE_Eileen_Butt_Grab with ml
    X "How about I take charge this time?"
    Eileen "Oh!"
    scene ep5_Eileen_Bedroom_SS_Foreplay_A_POV_Bed_Before_Sex with ml
    Eileen "Let me just get it ready..."
    $ anim_speed_base = 0.045
    $ anim_curve = "linear"
    scene ep5_Eileen_BJ_anim_POV with fade
    pause
    X "Fuck that's good!"
    Eileen "*mmmgh*!"
    scene ep5_Eileen_BJ_anim_Close with dissolve
    pause
    X "Shit!"
    X "Get on the bed now!"
    scene ep5_Eileen_Missionary_anim_POVf_0 with fade
    X "Ready to get fucked?"
    Eileen "Yes!!"
    X "I'll go slow at first."
    scene ep5_Eileen_Missionary_anim_POVf
    pause
    Eileen "Oh fuck!"
    scene ep5_Eileen_Missionary_anim_POVp with ml
    X "You like that?"
    Eileen "Fuck yeah!"
    Eileen "Take me!"
    $ anim_name = "episode5_Eileen_Missionary_anim_POVp"
    scene black
    call screen Episode5_Eileen_Missionary_animations
    $ anim_speed_base = 0.02
    $ anim_curve = "linear"
    scene ep5_Eileen_Ride_anim_POV with fade
    pause
    Eileen "Im cumming!!"
    $ anim_speed_base = 0.045
    $ anim_curve = "ease_stop_2"
    scene ep5_Eileen_Ride_anim_Front with fade
    pause 2
    Eileen "Almost!"
    scene ep5_Eileen_Ride_anim_POV_50 with vpunch
    scene ep5_Eileen_Ride_anim_POV_50 with vpunch
    scene ep5_Eileen_Ride_anim_POV_50 with vpunch
    Eileen "FUUUUCK!!!" with vpunch
    Eileen "That was--"
    X "I'm not done!"
    scene ep5_Eileen_Missionary_anim_POVf_0 with fade
    X "How dare you come first!"
    Eileen "I'm so sorry!"
    scene ep5_Eileen_Missionary_anim_POVp_0 with ml
    X "Just for that, I'm gonna punish your little cunt!"
    Eileen "Please, it's not used to this much fucking!"
    scene ep5_Eileen_Missionary_anim_POVp
    X "Then I'll fucking train it!"
    Eileen "Oh god!"
    scene black
    call screen Episode5_Eileen_Missionary_animations
    $ anim_speed_base = 0.005
    $ anim_curve = "linear"
    scene ep5_Eileen_Missionary_anim_POVp with fade
    Eileen "So deeeep!"
    X "I'm almost there!!"
    Eileen "Wait!"
    Eileen "I'll take it in my mouth!"
    scene ep5_Eileen_BJ_anim_POV with fade
    pause 3
    X "I'm gonna--"
    scene ep5_Eileen_BJ_anim_POV_19 with fade
    scene ep5_Eileen_BJ_anim_POV_19 with vpunch
    scene ep5_Eileen_BJ_anim_POV_19 with vpunch
    scene ep5_Eileen_BJ_anim_POV_19 with vpunch
    X "CUUUM!!" with vpunch
    scene ep5_Eileen_Bedroom_SS_Cumshot_A1_POV_Eileen_Facial__Overflow with fade
    Eileen "*mmmh* *hmmm*!"
    scene ep5_Eileen_Bedroom_SS_Cumshot_A1_POV_Eileen_Swallow with ml
    Eileen "*gulp*"
    scene ep5_Eileen_Bedroom_SS_Cumshot_A1_POV_Eileen_Dick_Clean with ml
    Eileen "That was a lot of baby batter."
    scene ep5_Eileen_Bedroom_SS_Cumshot_A1_FREE_Eileen_Dick_Clean with ml
    X "That was awesome!"
    Eileen "Let me clean up properly..."

    $ renpy.music.play("audio/music/lofi-hippo-193550.ogg", channel=u'music', loop=True, fadein=3)

    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Eileen_Talk with fade
    Eileen "That was intense!"
    Eileen "You were really pent-up."
    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Eileen_Puff_Joint with ml
    X "It has been gathering for the past weeks."
    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Eileen_Listen with ml
    X "I almost came inside you."
    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Eileen_Talk
    Eileen "It's good you didn't, I'm not on anything."
    Eileen "Didn't really expect this."
    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Eileen_Puff_Joint with ml
    X "Hope this won't ruin our friendship or anything."
    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Eileen_Talk with ml
    Eileen "I don't think so."
    Eileen "We should do it a few more times just to see if we're solid."
    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Eileen_Listen
    X "Gotta wait a bit, I'm spent."
    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Eileen_Talk
    Eileen "Hey don't worry I'm not a succubus, despite appearances."
    scene ep5_Eileen_Bed_Pillowtalk_A1_POV_Sitting_Bedside with dissolve
    Eileen "I need to go to [D], she's had nightmares a few times."
    X "Oh I see."
    Eileen "And I might have to explain away if she heard anything."
    X "Yeah we were a little loud..."
    scene black with fade
    pause 1



label ep5_Eileen_morning_leave:
    $ renpy.music.play("audio/music/morning-routine-house.ogg", channel=u'music', loop=True, fadein=3)
    scene ep5_Entrance_Day_Eileen_B1_POV_Eileen_Talk_Hand with fade
    Eileen "I need to get going, got business to take care of."
    scene ep5_Entrance_Day_Eileen_B1_POV_Eileen_Talk
    Eileen "If there's anything you need, just call."
    scene ep5_Entrance_Day_Eileen_B1_POV_Eileen_Listen
    X "Yeah, we'll be in touch."
    D "[Eileen]?"
    scene ep5_Entrance_Day_Eileen_B1_POV_Stairs with dissolve
    X "[D], you're up!"
    D "Did [Eileen] leave?"
    scene ep5_Entrance_Day_Eileen_B1_POV_Eileen_D_Hug with dissolve
    Eileen "I'm sorry baby, didn't want to wake you."
    D "Do you have to go now?"
    Eileen "I'm afraid so."
    scene ep5_Entrance_Day_Eileen_B1_POV_Eileen_Talk_D with ml
    Eileen "So you take care of dad in my place! Okay?"
    D "I will!"
    Eileen "Alright, see you later!"
    D "Bye!"
    scene ep5_Entrance_Day_Eileen_B1_POV_D_Listen with fade
    X "You two have been getting along well."
    X "You like her huh?"
    scene ep5_Entrance_Day_Eileen_B1_POV_D_Talk
    D "She's been really nice!"
    scene ep5_Entrance_Day_Eileen_B1_POV_D_Listen
    X "We can meet up more often."
    X "Now I just gotta do some work."
    scene ep5_Entrance_Day_Eileen_B1_POV_D_Talk
    D "I'll go make breakfast!"
    X "You're the best!"
    scene ep5_Laptop_A3_POV_Laptop with fade
    "...spirit, psychic, demon possessions."
    "Can't make sense of this stuff."
    "Maybe mind control, but I wasn't doing it willingly."
    scene ep5_Laptop_A3_FREE_Side with ml
    "This is a mess, but I have to keep digging."
    "There has to be something to explain what he did back there."
    "Who could I talk to about this."
    "If there's some truth to this in some religion."
    "Could ask [Maya]..."
    $ renpy.music.play("audio/music/requiem in white.ogg", channel=u'music', loop=True, fadein=1)

    pause 2.0
    scene ep5_Laptop_A3_POV_Paintings with ml
    "I know that song!"
    "Am I hallucinating again?"
    scene ep5_Piano_D_Play_A1_POV_D_Play with ml
    "This is what [Emily] was playing."
    scene ep5_Dream_Emily_Theatre_Stage with fade
    "I remember now!"
    scene ep5_Dream_Emily_Stage_FREE_Keys_2 with dissolve
    "I dreamed of the first time we met."
    scene ep5_Piano_D_Play_A1_POV_D_Play with ml
    X "She's just like her..."
    $ renpy.music.stop(channel=u'music', fadeout=0)
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Talk with ml
    D "Dad!"
    D "Is something wrong?"
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Listen with ml
    X "Uh no! Everything's great."
    X "When did you learn that piece?"
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Talk with ml
    D "Oh I've known it for years, since I was little."
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Talk_Away
    D "She didn't like it..."
    "She's probably referring to [Odelia], I should change the subject for now."
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Listen
    X "Well if you like it, play as much as you want to."
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Talk
    D "Do you enjoy it?"
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Listen
    X "Of course! But I'm not much of a connoisseur."
    X "I'm afraid it doesn't say much if I like it or not."
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Talk_Away
    D "I could try something else."
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Listen
    X "Whatever you like."
    X "How about we go out for a trip."
    X "Was thinking [Eileen] could use a hand."
    scene ep5_Piano_D_Play_A1_POV_D_Sit_Talk
    D "Can we really go?"
    X "I don't see why not."

    $ renpy.music.play("audio/music/pastry-shop.ogg", channel=u'music', loop=True, fadein=3)

    scene ep4_City_Drive_FREE_D_Talk with fade
    X "I'll be away for a while so take your time."
    X "Okay dad."
    scene ep5_Eileen_D_shop_DAY_A1_POV_Eileen_Talk_D with ml
    Eileen "I knew you couldn't stay away for too long."
    Eileen "Come on see what's cooking."

    $ renpy.music.play("audio/music/ambient-classical-guitar.ogg", channel=u'music', loop=True, fadein=3)
    scene ep5_Maya_Pray_Day_A1_POV_Enter with fade
    "Good, looks like nobody else is here."
    scene ep5_Maya_Pray_Day_A1_POV_Approach with ml
    X "Hey, sorry to interrupt."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Notice with ml
    Maya "[X]!"
    Maya "You're out of the hospital?"
    X "I'm good enough to move around, so yeah."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_1 with ml
    Maya "Decided to visit the chapel?"
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen
    X "I was actually hoping to run into you here."
    X "And talk about some things."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_1
    Maya "Of course."
    scene ep5_Maya_Pray_Day_A1_POV_Altar_Empty with ml

    X "Yeah..."
    X "Not many people around at this hour."
    Maya "Most folks come on Sundays."
    Maya "It's tranquil, I find it soothing."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen with ml
    X "How are the girls?"
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_1
    Maya "[Sophie] has been really worried for [Carla]."
    Maya "So I take her to stay at the hospital for most of the day."
    Maya "[Alecia] doesn't show it but she's just as concerned."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen
    X "And how are you holding up?"
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_1
    Maya "I come here to pray, it helps."
    Maya "Has your wound been healing well?"
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen
    X "I barely remember it's there."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_1
    Maya "And what about [D]? I always saw her next to your bed when we visited."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen
    X "Yes, she slept like a log last night."
    X "[Eileen] made an effort to keep her busy so she doesn't have to think about what happened."
    X "But I have to pick up the slack now."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_2
    Maya "If you need to, you can come to the farm."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen
    X "That would be a good change of scenery."
    X "Listen, I actually wanted to talk about something."
    X "It's uh... a little hard to explain."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_1
    Maya "If there is something you want to get off your chest, I can promise to listen at least."
    scene ep5_Maya_Pray_Day_A1_POV_Altar_Empty with ml

    X "Do you know anything about.. possessions?"
    Maya "What do you mean?"
    X "Like someone's body being taken over by a thing or someone else even."
    Maya "Like a spirit or a demon?"
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen
    X "Yeah something of the sort."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_1

    Maya "I don't know much about it, beyond what I've read."
    Maya "Perhaps Father [Luigi] can help with answering those types of questions."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen
    X "Does he come around here?"
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_1
    Maya "He should be in next week."
    X "Thank you."
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Listen
    X "And you're sure it's OK if we visit the farm?"
    scene ep5_Maya_Pray_Day_A1_POV_Maya_Talk_2
    Maya "There's plenty of room and you're always welcome."
    scene ep5_Maya_Pray_Day_Stand_A1 with dissolve
    X "Alright, I'll see if [D] wants to come."

    $ renpy.music.play("audio/music/pastry-shop.ogg", channel=u'music', loop=True, fadein=3)
    scene ep5_Eileen_D_shop_DAY_A1_POV_Eileen_Talk_MC with ml
    Eileen "Oh you're back."
    scene ep5_Eileen_D_shop_DAY_A1_POV_D_Eileen_Listen
    X "So how was work?"
    scene ep5_Eileen_D_shop_DAY_A1_POV_Eileen_Talk_MC
    Eileen "I actually got things done way faster thanks to my new assistant."
    scene ep5_Eileen_D_shop_DAY_A1_POV_Eileen_Talk_D
    Eileen "She can come by and help anytime."
    scene ep5_Eileen_D_shop_DAY_A1_POV_D_Eileen_Listen
    X "We'll have to see about her wage."
    X "And none of that 'pay with experience' stuff!"
    scene ep5_Eileen_D_shop_DAY_A1_POV_Eileen_Talk_MC
    Eileen "You think I would pull something like that?"
    scene ep5_Eileen_D_shop_DAY_A1_POV_D_Eileen_Listen
    X "Maybe there's a little penny-sized demon somewhere whispering."
    X "Gotta stay on your toes."
    scene ep5_Eileen_D_shop_DAY_A1_POV_D_Talk_MC
    D "Is it time to go?"
    scene ep5_Eileen_D_shop_DAY_A1_POV_D_Eileen_Listen
    X "[Maya] invited us to her farm, if you feel like getting away for a while."
    scene ep5_Eileen_D_shop_DAY_A1_POV_Eileen_Talk_D
    Eileen "Oh you can get her some of those brownies we made."
    scene ep5_Eileen_D_shop_DAY_A1_POV_D_Talk_Eileen
    D "And some cinnamon rolls!"
    scene ep5_Eileen_D_shop_DAY_A1_POV_Eileen_Talk_D
    Eileen "We'll get those too."
    scene ep5_Eileen_D_shop_DAY_A1_POV_D_Hold_Package with fade
    Eileen "Now these are from the batches you made."
    Eileen "If anyone asks, that is what you tell them. Understood?"
    D "I will, thank you!"
    scene ep5_Eileen_D_shop_DAY_A1_POV_Eileen_GBye with dissolve
    Eileen "And you, behave!"
    X "Yes ma'am!"
    scene black with fade
    pause 0.5

    $ renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)

    scene ep2_225_D_bed_listen_1 with fade
    X "...and if you don't feel like it, you don't have to go."
    X "So it's up to you."
    scene ep2_224_D_bed_talk_hand with ml
    D "We'll take the books so we can study."
    scene ep2_222_D_bed_talk_smile with ml
    D "And we have to share the sweets, there are too many."
    scene ep2_225_D_bed_listen_1
    X "OK then, we have sufficient reasons."
    X "It's settled then!"
    scene ep2_226_D_bed_listen_2
    X "Now let's go to bed, we have to wake up early."
    X "And I'll stay here while you go to sleep."
    X "Okay?"
    scene ep2_222_D_bed_talk_smile
    D "Thanks dad!"
    scene black with fade
    pause 1
    scene ep3_Bedroom_MC_D_night_sleep_fap_face with fade

    menu:
        "Should I stay here or leave?"
        "Stay":
            $ ep5_D_joystick_home = "done"
            $ D_p + 1
            "She might have a nightmare."
            "I should stay."
            scene black with fade
            pause 1
            $ anim_speed_base = 0.050
            $ anim_curve = "linear"

            $ renpy.music.play("audio/music/tenderness.ogg", channel=u'music', loop=True, fadein=3)

            scene ep5_D_Joystick_anim_House with eye_open
            pause
            "What?"
            "Am I dreaming, what is she doing?"
            scene ep5_D_Joystick_anim_House
            pause
            "Shit! This is actually happening."
            "What do I do? If I wake-up-"
            "No!"
            "She must be thinking there's something wrong and trying to.. fix it."
            $ anim_speed_base = 0.045
            $ anim_curve = "linear"
            scene ep5_D_Joystick_anim_House
            "Gotta try to get soft!"
            scene black with eye_close
            "Think... math..."
            "Spreadsheets..."
            "Doing taxes... "
            "The vice-president...."
            "......."
            "It's working!"
            scene ep3_Bedroom_MC_D_night_sleep_fap_face with fade
            "That was close."
            scene ep1_303_room_d_sleeping with fade
            "Let's try to avoid that..."
        "Leave":

            $ ep5_D_joystick_home = "nope"
            "I could leave the doors open in case she has a nightmare."
            scene ep1_303_room_d_sleeping with fade
            X "Sweet dreams..."

    $ renpy.music.play("audio/music/playa-del-sol-latin-lofi-160149.ogg", channel=u'music', loop=True, fadein=3)

    scene ep5_D_bed_Packing_A1_POV_D_Bag with fade
    X "Already packed up?"
    scene ep5_D_bed_Packing_A1_POV_D_Talk with ml
    D "Almost, just need my toothbrush."
    scene ep5_D_bed_Packing_A1_POV_D_Listen
    X "Did you sleep well? Any bad dreams?"

    scene ep5_D_bed_Packing_A1_POV_D_Talk
    D "No, I had a nice dream in fact."
    D "Just can't recall what it was about."
    scene ep5_D_bed_Packing_A1_POV_D_Listen
    X "Yeah that's.. normal."
    X "I'll just go shower and we can head out."
    scene ep5_D_bed_Packing_A1_POV_D_Talk
    D "Okay."
    scene black with fade
    pause 1

label ep5_farm_Maya_arrive:
    scene ep5_Garage_Front_Maya_A1_POV_Arrive with fade
    X "There she is!"
    scene ep5_Garage_Front_Maya_A1_POV_Maya_Welcomes with ml

    Maya "Welcome!"
    D "Hello, Miss [Maya]!"
    scene ep5_Garage_Front_Maya_A1_POV_Maya_Talk_MC with ml

    Maya "We're getting ready to go harvest some early crops."
    scene ep5_Garage_Front_Maya_A1_POV_Maya_D_Talk with ml
    Maya "Do you have a change of clothes? It would be a shame to dirty this lovely dress."
    D "We did bring some clothes."
    X "She checked everything!"
    scene ep5_Garage_Front_Maya_A1_POV_Maya_Talk_MC
    Maya "Have you had breakfast?"
    X "Yeah, we're good."
    scene ep5_Garage_Front_Maya_A1_POV_MC_Leaves with ml

    Maya "Oh! [Alecia]'s feeding the animals, can you get her?."
    X "Sure."
    Maya "She should be around the barn."
    scene ep5_Garage_Front_Maya_A1_POV_Maya_D_Inside with dissolve
    Maya "I'll give you a tour of the house."
    Maya "Watch your step!"


    scene ep5_Farm_Barn_Front_DAY_A1 with fade
    X "[Alecia]!"
    X "You around?"
    scene ep5_Farm_Barn_Front_DAY_A1
    pause 0.3
    Alecia "[X]?"
    Alecia "What are you doing here?"
    X "Came with [D] for some fresh air."
    X "[Maya] sent me to get you, we're heading out."
    Alecia "Alright, I'll be there in a sec!"

    scene ep5_Cornfield_Maya_Car_Unload_Boxes_A1 with fade
    Maya "We'll pick some of the ripe ones."
    Maya "Then bring the boxes next to the road when they're filled."
    scene ep5_Cornfield_Maya_Pick_Boxes_Hands with ml
    X "I do need the exercise."
    Maya "Don't lift too much, there's no rush."

    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Field_Corncob_Maya_talk_D with fade
    Maya "...so after checking if the silks at the end are dry, you peel a little to peek at the kernels inside."
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Field_D_talk_Maya
    D "And when they turn yellow, that means they're ripe?"
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Field_Maya_talk_D
    Maya "Not right away."
    Maya "You also have to check the consistency of the sap inside, it needs to be a little milky."
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Field_D_Maya_Listen_MC
    X "What about the pumpkins, are they ripe yet?"
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Field_Maya_Talk_MC
    Maya "A few, [Alecia] can tell them apart."
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Field_D_Maya_Listen_MC
    X "Sweet! Let's get to work."

    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Listen with fade
    X "So how long have you been coming here?"
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Talk
    Alecia "[Maya] has been bringing everyone from the home on summer vacations for years."
    Alecia "She used to have help for the farm, but they moved from town."
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Listen
    X "So you stepped in to help out around here?"
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Talk
    Alecia "Yeah."
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Point_Away with fade


    Alecia "It looks like there are some over there."
    scene ep5_Cornfiel_Day_MC_Alecia_A1_FREE_Alecia_Pumpkin_Knock with ml
    Alecia "Looks good."
    X "How can you tell?"
    Alecia "If the stem's too green, it needs more time."
    Alecia "At least the type we have."
    Alecia "There's also the surface, glossy means it's not ready."
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Listen
    X "I saw that people plant beans too."
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Talk
    Alecia "Yes, but this corn type doesn't work well with it."
    Alecia "We're changing this year."
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Point_Away with fade
    Alecia "There's more there."
    scene ep5_Cornfiel_Day_MC_Alecia_A1_FREE_Alecia_Pumpkin_Knock with dissolve
    X "You've had some practice with this."
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Pumpkin_Pull with ml
    Alecia "It's not hard you know."
    Alecia "*hmmmpf*!"
    X "I can help with that."
    Alecia "No I got *hmmmpf th--"

    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Pumpkin_Falling
    Alecia "Wow!"
    scene ep5_Cornfiel_Day_MC_Alecia_A1_FREE_Alecia_Catch with ml
    X "Gotcha!"
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Catch with ml
    X "You need to be more careful."
    Alecia "Uh-- yeah sure!"
    scene ep5_Cornfiel_Day_MC_Alecia_A1_POV_Alecia_Pumpkin_Hold with dissolve
    Alecia "Take this to the road, I have to go use the.. toilet."
    X "Alright!"
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_Boxes_Full_Maya_D_Listen with fade
    X "That's all the squashes we got."
    X "How did you girls do?"
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_Boxes_Full_Maya_Talk with ml
    Maya "We actually fixed up a couple of scarecrows since we finished quickly."
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_Boxes_Full_D_Talk
    D "I got to pick about three crates."
    D "It's really easy, just keep twisting and be careful not to squeeze too hard."
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_Boxes_Full_Maya_D_Listen
    X "Sounds like it takes some finesse, think I'll stick to hauling things."
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_Alecia_Arrive with dissolve
    Alecia "I'm done, if no one needs to use the toilet--"
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_D_Talk_Alecia with ml
    D "Is there somewhere we can go pee here?"
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_Alecia_Talk_D with ml
    Alecia "Well there's the field, just pick a spot and go."
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_D_Alecia_Leave with ml
    Alecia "Come on, I'll show you how we do it here."
    scene ep5_Cornfiel_Day_Maya_D_Alecia_A1_POV_Car_Boxes_Full_Maya with fade
    X "I'll bring the car around to load the rest."
    Maya "It's good that you arrived, we can do it in one trip."
    X "It was nice timing!."
    scene ep5_Farm_Maya_cow_Milking_D_A1 with fade
    Maya "You grab the udders like this."
    Maya "And then squeeze as you pull."
    D "Oh! Some milk came out."
    D "Doesn't it hurt?"
    Maya "Oh not at all, the udder just keeps growing so it's a relief for her."
    Maya "Like going to pee after holding it in for some time."
    D "Think I understand."
    "Guess I'll look around here."

    $ renpy.music.stop(channel=u'music', fadeout=1.0)

    scene ep5_Farm_Barn_Front_DAY_A1 with fade
    "Gotta find some to do."
    scene ep5_Farm_Barn_Entrance_DAY_A1 with ml
    "Looks dark, my eyes need to adjust."
    $ renpy.music.play("audio/sfx/cat_lands.ogg", channel=u'sound', loop=False)
    scene ep5_Farm_Barn_Entrance_DAY_A1
    $ renpy.music.play("audio/sfx/cat_lands.ogg", channel=u'sound', loop=False)
    pause 0.5
    menu:
        "What was that noise."
        "Ignore it":
            $ ep5_Alecia_fap = "ignored"
            "Eh it's probably birds or something."
        "Go upstairs":
            $ ep5_Alecia_fap = "exposed"
            $ Alecia_p + 1
            scene ep5_Farm_Barn_Stairs_UP_DAY_A1 with ml
            "What could that be?"

            $ renpy.music.play("audio/music/ero movie TV.ogg", channel=u'music', loop=True, fadein=3)

            scene ep5_Alecia_FAP_anim_POV with fade
            "What the--"
            scene ep5_Alecia_FAP_anim_POV with ml
            pause
            "I have to move slowly."
            "Better to avoid a situation."
            scene black
            call screen Episode5_Alecia_FAP_animations with dissolve

            $ anim_speed_base = 0.053
            $ anim_curve = "linear"
            scene ep5_Alecia_FAP_anim_Side
            Alecia "{size=-8}I can't get him outta my head..."
            scene ep5_Alecia_FAP_anim_Full
            Alecia "{size=-8}Fuck..."
            Alecia "{size=-8}I might lose my virginity to a cucumber because of him..."
            scene black
            call screen Episode5_Alecia_FAP_animations with dissolve

            scene ep5_Alecia_FAP_anim_Close
            Alecia "{size=-8}I want his dick even more after cumming..."
            Alecia "{size=-8}What the fuck is wrong with me..."
            Alecia "{size=-8}If only I didn't grab his dick back then..."
            Alecia "{size=-8}Fuck..."
            scene ep5_Alecia_FAP_anim_POV with fade
            "Is she talking about.."

            scene ep5_Farm_Barn_Stairs_UP_DAY_A1 with fade
            "I better leave before she hears me."

    $ renpy.music.play("audio/music/lofi-hippo-193550.ogg", channel=u'music', loop=True, fadein=3)
    scene ep5_Barn_Outside_Alecia_A1_POV_Approach with fade
    pause 0.5
    X "It looks like your kitty's enjoying the rub."
    scene ep5_Barn_Outside_Alecia_A1_POV_MC_Talk_1 with ml
    X "I don't think [Maya] mentioned having a pet cat."
    scene ep5_Barn_Outside_Alecia_A1_POV_Alecia_Talk
    Alecia "He's not really a pet"
    Alecia "It just comes here for the food and attention."
    scene ep5_Barn_Outside_Alecia_A1_POV_MC_Talk_2
    X "So just a normal cat."
    X "Does he catch rats or mice at least?"
    scene ep5_Barn_Outside_Alecia_A1_POV_Alecia_Talk
    Alecia "He did bring a few last month."
    Alecia "Haven't seen any around since."
    scene ep5_Barn_Outside_Alecia_A1_POV_MC_Talk_2
    X "Got a name?"
    scene ep5_Barn_Outside_Alecia_A1_POV_Cat_Leave with ml
    Alecia "Blackadder the Turd."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_smile with ml
    X "Oh you kids know about the classics!"
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "[Sophie] came up with it, I just changed the last part."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "Really? Sounds like you didn't like him."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "He started playing with my earrings after meeting."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "Oh yeah, you took them down I see."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "Yeah, so I chased him away."
    Alecia "Then he started bringing dead rats."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "And then you kissed and made up?"
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "I tolerated him."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_smile
    X "Noted."
    X "Bring some rats if I get on your bad side."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "By the way, didn't you get shot and got into a coma?"
    Alecia "Should you even be driving?"
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "The wound's almost healed and I was lucky the damage wasn't too bad."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "What about who shot you, are they still around?"
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "There's no need to worry about that."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "Because you killed them?"
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "Look, you don't need to worry about this stuff, the police is on it."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "Wow, the cops are on the case! It's basically already solved!"
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "Look, I get where you're coming from, but I know the detective, so it's in good hands."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "If you say so."
    Alecia "Also [Carla]'s still in a coma. She fell while being mugged, they say."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "I know, [Sophie] insists on staying with her as much as possible."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Talk
    Alecia "And it's not like what happened to her is related to you."
    Alecia "It's just pure coincidence, right?"
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_MC_Talk
    X "Won't give you any bullshit here, just can't talk about it now."
    scene ep5_Barn_Outside_Alecia_A1_POV_Close_Alecia_Stand with dissolve
    Alecia "Fine, whatever."
    X "Now what's there to do around here?"
    Alecia "There's plenty..."
    scene black with fade
    pause 0.5

    $ renpy.music.play("audio/music/spring-vibes-198610.ogg", channel=u'music', loop=True, fadein=3)
    scene ep5_Kitchen_Dinner_A1_POV_Maya_Talk_MC with fade
    Maya "So [X], will you be staying with us tomorrow?"
    scene ep5_Kitchen_Dinner_A1_POV_MC_Talk
    X "If you're fine with that."
    X "We're not in a hurry to get anywhere."
    scene ep5_Kitchen_Dinner_A1_POV_Maya_Talk_Girls
    Maya "That's good, we can make the pumpkin pies together."
    Maya "And maybe do some sightseeing."
    scene ep5_Kitchen_Dinner_A1_POV_D_Talk_Maya
    D "Are there more animals here at the farm?"
    scene ep5_Kitchen_Dinner_A1_POV_Maya_Talk_Girls
    Maya "I don't keep many."
    Maya "But there are folks who keep other birds, they have pigs, horses and such."
    scene ep5_Kitchen_Dinner_A1_POV_MC_Talk
    X "I tried riding a horse in my school days."
    scene ep5_Kitchen_Dinner_A1_POV_D_Talk_MC
    D "What was it like?"
    scene ep5_Kitchen_Dinner_A1_POV_MC_Talk
    X "Didn't actually get to the riding part."
    X "It kept throwing me off and I gave up after dislocating my shoulder."
    scene ep5_Kitchen_Dinner_A1_POV_Alecia_Talk_MC
    Alecia "Sounds like the horse didn't like you very much."
    X "Yeah we parted on bad terms."
    scene ep5_Kitchen_Dinner_A1_POV_D_Talk_MC
    D "And the shoulder must've hurt."
    scene ep5_Kitchen_Dinner_A1_POV_MC_Talk
    X "It did, but I gave up mostly because I couldn't use my arm anymore."
    X "I did some really dumb stuff on a dare."
    scene ep5_Kitchen_Dinner_A1_POV_Maya_Talk_MC
    Maya "I can imagine."
    scene ep5_Kitchen_Dinner_A1_POV_Maya_Talk_Girls
    Maya "I think we'll resign ourselves to watching the animals."
    scene ep5_Kitchen_Dinner_A1_POV_Alecia_Talk_Maya
    Alecia "Any news on [Carla]?"
    scene ep5_Kitchen_Dinner_A1_POV_Maya_Talk_Girls
    Maya "Still no change."
    Maya "But [Sophie] agreed to come here tomorrow."
    scene ep5_Kitchen_Dinner_A1_POV_MC_Talk
    X "I could pick her up!"
    X "And run some errands if you have any."
    scene ep5_Kitchen_Dinner_A1_POV_Maya_Talk_MC
    Maya "That would be great [X]!"
    Maya "We'll have time to prepare all the food for the kids."
    scene ep5_Kitchen_Dinner_A1_POV_MC_Talk
    X "Alright, now let's see what we have here..."
    scene black with dissolve
    scene ep5_Kitchen_Sink_D_Alecia_A1_POV_Girls_Cleaning with fade
    Alecia "...so you slept at a train station on your way here?"
    D "It was only one night."
    Alecia "Wish I had run away from my folks."
    D "What happened?"
    Alecia "It's a long story..."
    scene ep5_Farm_House_Shower_A1 with fade
    "Plenty of stuff to keep busy around here."
    "It was a good call."
    scene ep5_House_Bedroom_Alecia_D_A1_POV_D_Listen with fade
    D "I pull like this?"
    Alecia "That's it!"
    Alecia "And we should get more pillows just in case."
    "They seem to be getting along."
    "I'll give them some space."
    $ renpy.music.stop(channel=u'music', fadeout=3.0)
    scene black with fade
    pause 2
    scene ep5_House_Bedroom_MC_Ceiling with eye_open
    pause 0.5
    X "Ugh.."
    "Can't sleep, gotta get some air."
    $ renpy.music.play("audio/music/free-night-134023.ogg", channel=u'music', loop=True, fadein=3)
    scene ep5_Kitchen_Counter_Maya_A1_POV_Maya_Encounter with fade
    X "Oh hello there!"
    scene ep5_Kitchen_Counter_Maya_A1_POV_Maya_Notice with ml
    Maya "[X]!"
    X "Sorry, didn't mean to scare you."
    Maya "You just startled me."
    scene ep5_Kitchen_Counter_Maya_A1_POV_Maya_Talk_1 with dissolve
    Maya "Are you having trouble sleeping? Is the bed fine?"
    scene ep5_Kitchen_Counter_Maya_A1_POV_Maya_Listen
    X "No, it's fine!"
    X "My mind just keeps wandering to [D] and all that's happened."
    scene ep5_Kitchen_Counter_Maya_A1_POV_Maya_Talk_1
    Maya "I can't imagine what you've been through."
    scene ep5_Kitchen_Counter_Maya_A1_POV_Maya_Talk_2
    Maya "Sometimes when I can't sleep, a glass of wine helps."
    Maya "If you want, we can have one."
    scene ep5_Kitchen_Counter_Maya_A1_POV_Maya_Listen
    X "I'll take you up on that."

    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_MC with fade
    X "Thanks again for taking us in."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_MC
    Maya "More than happy to help."
    Maya "It's great she can enjoy herself after that whole ordeal."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_MC
    X "I've avoided talking about it, but we'll have to discuss it eventually."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_MC
    Maya "Whenever you need it, I can always lend an ear."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_MC
    X "Appreciate it, but don't feel obligated."
    scene ep5_House_Porch_Back_A1_FREE_Maya_Listen_MC with ml
    X "Between managing the home and your own farm, you have your hands full."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Away with ml
    Maya "It does keep me busy, but it's very fulfilling."
    Maya "I believe it's what keeps me going."
    "Can't say much about what happened back there."
    "Maybe I can find a roundabout way to talk about it."
    scene ep5_House_Porch_Back_A1_POV_Maya_Drink with fade
    X "I was wondering how the kids are doing at the home."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Glass
    Maya "They are as good as can be under the circumstances."
    Maya "And looking forward to starting school."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_Glass
    X "Probably eager to make some friends."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Glass
    Maya "I'm sure. But they want to go back to their favorite teacher, Miss [Carla]."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_Glass
    X "Have you told them?"

    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_MC with dissolve
    Maya "Not yet, there's no reason to make them worry."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Away
    Maya "I only told [Sophie] because [Carla] promised to meet her."
    Maya "Don't want her to start developing trust issues."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_MC
    X "Yeah, I'm still working on mine even today."
    scene ep5_House_Porch_Back_A1_POV_Maya_Drink with fade
    X "Noticed the farm is kind of isolated."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_Glass
    X "And you have to take care of it yourself."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Glass
    Maya "I wouldn't have been this way if I had gotten married years ago."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_Glass
    X "You were engaged if I remember."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Glass
    Maya "Yes, with someone I've known since primary school."
    X "Sorry it didn't work out."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Away with dissolve
    Maya "I found him together with a woman, who I thought was my best friend."
    X "Wow, damn..."
    Maya "It's just that I can't consider myself blameless for all of it."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_MC
    X "He was the one who cheated, how are you to blame for it?"
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Away
    Maya "I was very insistent on waiting for after marriage before... consummating."
    Maya "Perhaps if I wasn't so--"
    scene ep5_House_Porch_Back_A1_FREE_Maya_Listen_MC
    X "Don't be ridiculous!"
    X "If that was a deal breaker, he really wouldn't have been worth it!"
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_MC
    X "You really shouldn't be worrying about that."
    scene ep5_House_Porch_Back_A1_POV_Maya_Drink with dissolve
    Maya "*sigh*"
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Glass
    Maya "It's that I know men have needs, maybe it was torturous for him."
    scene ep5_House_Porch_Back_A1_POV_Maya_Listen_Glass
    X "There are other ways to take care of it, that don't involve cheating."
    X "And it's not like women don't have needs too."
    scene ep5_House_Porch_Back_A1_POV_Maya_Talk_Away with dissolve
    Maya "Yes that's.. true."
    scene ep5_House_Porch_Back_A2_POV_Maya_Get_Up with fade
    Maya "We almost finished the bottle."
    Maya "I don't normally drink this mu--"
    scene ep5_House_Porch_Back_A2_POV_Maya_Catch with hpunch
    Maya "Uhh.."
    X "Woah!"
    scene ep5_House_Porch_Back_A2_POV_Maya_part_ways with dissolve
    X "Are you OK?"
    Maya "My feet went a bit numb."
    X "I'll help you upstairs."
    Maya "No no, it's alright!"
    X "If you're sure."
    Maya "Yes, thank you."
    Maya "We should get some rest."
    X "Alright, goodnight then..."

    scene ep5_House_Bedroom_MC_Ceiling with fade
    "..."
    menu:
        "It seems I got exited from earlier."
        "Relieve yourself":
            scene ep5_House_Bedroom_MC_JOff_A1 with dissolve
            "Better deal with this first."
            scene black with eye_close
            pause 1.5
            D "Dad is everything--"
            scene ep5_House_Bedroom_Night_D_Enter
            D "--alright?"
            X "[D]?!"
            X "W-what is it?"
            scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Talk with ml
            D "I was awake and heard some noises."
            D "So I came to check and..."
            scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Listen with ml
            X "Oh.. right, I went out for some air."
            scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Talk
            D "Are you in pain?"
            scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Listen
            X "What? No I'm fine."
            menu:
                D "If you need me, I can help with that."
                "(need more points)" if D_p < 3:
                    pass
                "Let her \"help\"" if D_p > 2:
                    $ ep5_D_joystick_farm = "done"
                    $ D_p + 1
                    $ renpy.music.play("audio/music/tenderness.ogg", channel=u'music', loop=True, fadein=3)

                    "Does she have that idea from what happened in the dungeon?"
                    "Shit! How do I handle this?"
                    scene ep5_House_Bedroom_MC_night_D_sit_A1_POV_D_sit_Talk with dissolve
                    D "Does it hurt right now?"
                    scene ep5_House_Bedroom_MC_night_D_sit_A1_POV_D_sit_Listen
                    X "It's not really.."
                    "How do I even approach this?"
                    X "It's not painful."
                    scene ep5_House_Bedroom_MC_night_D_sit_A1_POV_D_sit_Talk
                    D "But it will keep growing till it becomes painful right?"
                    D "I can help!"
                    scene ep5_House_Bedroom_MC_night_D_sit_A1_POV_D_sit_Listen
                    "Oh fuck, how do I even explain what happened."
                    "I don't even understand what happened."
                    "Maybe I can just play along and reassure her?"
                    X "I appreciate it, but it doesn't really take much to..."
                    $ anim_speed_base = 0.045
                    $ anim_curve = "linear"
                    scene ep5_D_Joystick_anim_Farm with fade
                    D "Is this where the pain is?"
                    X "It's around there.."
                    "What the fuck!"
                    "How did I get in this situation?"
                    "I can just let her do this for a bit..."
                    scene ep5_D_Joystick_anim_Farm with fade
                    pause
                    D "Am I doing it right?"
                    X "Yes... it's fine..."
                    $ anim_speed_base = 0.038
                    $ anim_curve = "linear"
                    scene ep5_D_Joystick_anim_Farm with fade
                    pause
                    "Fuck! I might actually cum!"
                    X "You can stop!"
                    X "It's all better."

                    $ renpy.music.play("audio/music/ambient-classical-guitar.ogg", channel=u'music', loop=True, fadein=3)

                    scene ep5_House_Bedroom_MC_night_D_sit_A1_POV_D_sit_Listen with fade
                    X "I'll be OK now."
                    scene ep5_House_Bedroom_MC_night_D_sit_A1_POV_D_sit_Talk
                    D "But it's still big."
                    scene ep5_House_Bedroom_MC_night_D_sit_A1_POV_D_sit_Listen
                    X "Yeah but it goes away."
                    X "You should go back to bed."
                    scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Listen with ml
                    X "Oh and [D]!"
                    scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Talk
                    D "Yes?"
                    scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Listen
                    X "Keep this just between us, OK?"
                    scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Talk
                    D "I will!"
                    scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Listen
                    X "That's a good girl."
                    scene ep5_House_Bedroom_Night_D_Enter with dissolve
                    D "Goodnight daddy!"
                    X "Goodnight baby!"
                    scene ep5_House_Bedroom_MC_Ceiling with fade
                    pause 0.5
                    "' the hell happened?"
                    "Why did I allow that?"
                    "I shouldn't be doing that with my own daughter..."
                "Assure her it's fine":
                    $ ep5_D_joystick_farm = "nope"
                    $ renpy.music.play("audio/music/ambient-classical-guitar.ogg", channel=u'music', loop=True, fadein=3)
                    X "You don't need to worry about it."
                    scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Talk
                    D "But are you going to be okay?"
                    scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Listen
                    X "Yeah it'll be fine, I'll.. take care of it."
                    X "You just go back to bed, OK?"
                    scene ep5_House_Bedroom_MC_night_Bed_A1_POV_D_Talk
                    D "If you say so."
                    scene ep5_House_Bedroom_Night_D_Enter with dissolve
                    D "Goodnight dad!"
                    X "Goodnight [D]!"
                    scene ep5_House_Bedroom_MC_Ceiling with fade
                    "Well, that was close..."
        "Sleep it off":

            "Maybe I'll count sheep or something."
            scene ep5_House_Bedroom_MC_Ceiling with eye_close
            "1.. 2.. 3.. 4.. 5..."
    $ renpy.music.play("audio/music/requiem in white.ogg", channel=u'music', loop=True, fadein=7)
    scene ep1_000_black with curtains_slow_r
    show screen episode_end
    menu:
        "To be continued...":
            pass
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
