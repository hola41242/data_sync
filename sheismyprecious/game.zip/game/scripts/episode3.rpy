

label ep3_01_bathroom:
    hide screen episode_end
    $ renpy.music.stop(channel=u'music', fadeout=1.0)
    $ renpy.music.stop(channel=u'ambience', fadeout=None)
    $ renpy.music.stop(channel=u'sound', fadeout=None)
    scene ep1_000_black with dissolve
    pause 0.5
    show screen episode_title("Episode 3","Back In The Game")
    pause 5.5
    hide screen episode_title

    scene ep1_033_room_mc_bed_sitting with curtains_slow
    "Of all the times, why did I get hard now?"
    "It can't be because of... her."
    scene ep3_Bedroom_MC_Look_Wall_A1 with ml
    "She does look so much like [Emily]."
    "Yeah, that's probably it!"
    "Still, what did she make of it?"
    "Maybe I should talk to her about this stuff tomorrow..."
    scene ep1_000_black with dissolve
    pause 1.5
    $ renpy.music.play("audio/music/Wet-dream-a1.ogg", channel=u'music', loop=True, fadein=3)
    pause 4


default load_rate = 0.049
default load_rate_level = 1
default fanum = 0





init python:
    def ep3_Emily_prone_bone_A1_ANIM_POV(load, a, b):
        load.set_child("ep3_Emily_prone_bone_A1_ANIM_POV{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 21 and store.load_rate_level == 4:
            store.load_rate = 0.0169
            store.load_rate *=2
        if store.fanum == 35 and load_rate_level == 4:
            store.load_rate /=2
        if store.fanum > 59:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value

init python:
    def ep3_Emily_prone_bone_A1_ANIM_SIDE(load, a, b):
        load.set_child("ep3_Emily_prone_bone_A1_ANIM_SIDE{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 21 and store.load_rate_level == 4:
            store.load_rate = 0.0169
            store.load_rate *=2
        if store.fanum == 35 and load_rate_level == 4:
            store.load_rate /=2
        if store.fanum > 59:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value


init python:
    def ep3_Emily_prone_bone_A1_ANIM_under(load, a, b):
        load.set_child("ep3_Emily_prone_bone_A1_ANIM_under{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 21 and store.load_rate_level == 4:
            store.load_rate = 0.0169
            store.load_rate *=2
        if store.fanum == 35 and load_rate_level == 4:
            store.load_rate /=2
        if store.fanum > 59:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value


image ep3_Emily_prone_bone_A1_ANIM_under:
    function ep3_Emily_prone_bone_A1_ANIM_under
image ep3_Emily_prone_bone_A1_ANIM_POV:
    function ep3_Emily_prone_bone_A1_ANIM_POV
image ep3_Emily_prone_bone_A1_ANIM_SIDE:
    function ep3_Emily_prone_bone_A1_ANIM_SIDE
$ fanum = 0

screen SHOW_ep3_Emily_prone_bone_A1_ANIM_POV():
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Gentle" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1) style "screen_button"
        textbutton "Rythmic" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2) style "screen_button"
        textbutton "Pounding" action SetVariable("load_rate", 0.015),SetVariable("load_rate_level", 3) style "screen_button"
        textbutton "Deep Thrusts" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" style "screen_button"
        textbutton "ACTION" action Jump("SHOW_ep3_Emily_prone_bone_A1_ANIM_under") style "screen_button"
        textbutton "SIDE" action Jump("SHOW_ep3_Emily_prone_bone_A1_ANIM_SIDE") style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 40
        textbutton "BJ" style "screen_button"
        textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV") style "screen_button"
        textbutton "Missionary" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV") style "screen_button"
        textbutton "END" action Jump("continue_after_animation") style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface() style "screen_button"

screen SHOW_ep3_Emily_prone_bone_A1_ANIM_SIDE():
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Gentle" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1) style "screen_button"
        textbutton "Rythmic" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2) style "screen_button"
        textbutton "Pounding" action SetVariable("load_rate", 0.015),SetVariable("load_rate_level", 3) style "screen_button"
        textbutton "Deep Thrusts" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" action Jump("SHOW_ep3_Emily_prone_bone_A1_ANIM_POV") style "screen_button"
        textbutton "ACTION" action Jump("SHOW_ep3_Emily_prone_bone_A1_ANIM_under") style "screen_button"
        textbutton "SIDE" style "screen_button"

    hbox:
        yalign 0.99
        xalign 0.02
        spacing 40
        textbutton "Prone" style "screen_button"
        textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV") style "screen_button"
        textbutton "END" action Jump("continue_after_animation") style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface() style "screen_button"

screen SHOW_ep3_Emily_prone_bone_A1_ANIM_under():
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Gentle" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1) style "screen_button"
        textbutton "Rythmic" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2) style "screen_button"
        textbutton "Pounding" action SetVariable("load_rate", 0.015),SetVariable("load_rate_level", 3) style "screen_button"
        textbutton "Deep Thrusts" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" action Jump("SHOW_ep3_Emily_prone_bone_A1_ANIM_POV") style "screen_button"
        textbutton "ACTION" style "screen_button"
        textbutton "SIDE" action Jump("SHOW_ep3_Emily_prone_bone_A1_ANIM_SIDE") style "screen_button"

    hbox:
        yalign 0.99
        xalign 0.02
        spacing 40
        textbutton "Prone" style "screen_button"
        textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV") style "screen_button"
        textbutton "END" action Jump("continue_after_animation") style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface() style "screen_button"












init python:
    def ep3_Emily_ride_A1_ANIM_POV(load, a, b):
        load.set_child("ep3_Emily_ride_A1{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 21 and store.load_rate_level == 4:
            store.load_rate = 0.0169
            store.load_rate *=2.5
        if store.fanum == 35 and load_rate_level == 4:
            store.load_rate /=2.5
        if store.fanum > 59:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value

init python:
    def ep3_Emily_ride_A1_ANIM_BACK(load, a, b):
        load.set_child("ep3_Emily_ride_A1_alt{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 21 and store.load_rate_level == 4:
            store.load_rate = 0.0169
            store.load_rate *=2.5
        if store.fanum == 35 and load_rate_level == 4:
            store.load_rate /=2.5
        if store.fanum > 59:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value



image ep3_Emily_ride_A1_ANIM_POV:
    function ep3_Emily_ride_A1_ANIM_POV
image ep3_Emily_ride_A1_ANIM_BACK:
    function ep3_Emily_ride_A1_ANIM_BACK
$ fanum = 0

screen SHOW_ep3_Emily_ride_A1_ANIM_POV():
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1) style "screen_button"
        textbutton "Rythmic" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2) style "screen_button"
        textbutton "Riding" action SetVariable("load_rate", 0.015),SetVariable("load_rate_level", 3) style "screen_button"
        textbutton "Deep" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" style "screen_button"
        textbutton "BUTT" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_BACK") style "screen_button"

    hbox:
        yalign 0.99
        xalign 0.02
        spacing 40
        textbutton "Prone" action Jump("SHOW_ep3_Emily_prone_bone_A1_ANIM_POV") style "screen_button"
        textbutton "Ride" style "screen_button"
        textbutton "END" action Jump("continue_after_animation") style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface() style "screen_button"

screen SHOW_ep3_Emily_ride_A1_ANIM_BACK():
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1) style "screen_button"
        textbutton "Rythmic" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2) style "screen_button"
        textbutton "Riding" action SetVariable("load_rate", 0.015),SetVariable("load_rate_level", 3) style "screen_button"
        textbutton "Deep" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV") style "screen_button"
        textbutton "BUTT" style "screen_button"

    hbox:
        yalign 0.99
        xalign 0.02
        spacing 40
        textbutton "Prone" action Jump("SHOW_ep3_Emily_prone_bone_A1_ANIM_POV") style "screen_button"
        textbutton "Ride" style "screen_button"
        textbutton "END" action Jump("continue_after_animation") style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface() style "screen_button"






label ep3_dream_scene:
    scene ep3_Emily_prone_bone_A1_ANIM_SIDE0 with dissolve
    X "...so this is the first time you're being penetrated?!"
    Emily "I told you, I've never put anything in there!"
    scene ep3_Emily_prone_bone_A1_ANIM_under0 with dissolve
    X "Not even one of those tiny cucumbers?"
    Emily "Don't tease me anymore!"
    scene ep3_Emily_prone_bone_A1_ANIM_POV0 with dissolve
    X "You really wanna start with such a big cucumber?"
    Emily "Please [X]--"
    $ load_rate = 0.015
    $ load_rate_level = 3
    $ fanum = 0
    scene ep3_Emily_prone_bone_A1_ANIM_POV
    pause 0.65
    scene ep3_Emily_prone_bone_A1_ANIM_POV29
    Emily "Aah!"
    pause 2.0
    Emily "It's passed, you can move now."
    Emily "Please go slow..."
    $ load_rate = 0.049
    $ load_rate_level = 1
    $ fanum = 29
    scene ep3_Emily_prone_bone_A1_ANIM_POV with ml
    pause
    X "Oh wow!"
    Emily "That's it!"
    Emily "Make love to me [X]!"
    $ load_rate = 0.0169
    $ load_rate_level = 4


label SHOW_ep3_Emily_prone_bone_A1_ANIM_POV:
    scene ep3_Emily_prone_bone_A1_ANIM_POV with ml
    call screen SHOW_ep3_Emily_prone_bone_A1_ANIM_POV
label SHOW_ep3_Emily_prone_bone_A1_ANIM_SIDE:
    scene ep3_Emily_prone_bone_A1_ANIM_SIDE with ml
    call screen SHOW_ep3_Emily_prone_bone_A1_ANIM_SIDE
label SHOW_ep3_Emily_prone_bone_A1_ANIM_under:
    scene ep3_Emily_prone_bone_A1_ANIM_under with ml
    call screen SHOW_ep3_Emily_prone_bone_A1_ANIM_under

label SHOW_ep3_Emily_ride_A1_ANIM_POV:
    scene ep3_Emily_ride_A1_ANIM_POV with ml
    call screen SHOW_ep3_Emily_ride_A1_ANIM_POV
label SHOW_ep3_Emily_ride_A1_ANIM_BACK:
    scene ep3_Emily_ride_A1_ANIM_BACK with ml
    call screen SHOW_ep3_Emily_ride_A1_ANIM_BACK



label continue_after_animation:
    $ load_rate = 0.0169
    $ load_rate_level = 4
    scene ep3_Emily_ride_A1_ANIM_POV with ml
    X "Ugh!"
    X "You feel so good [Emily]."
    X "I want to do this forever!"
    Emily "Yes!"
    Emily "Me too daddy!"
    X "What?"
    scene ep3_Dream_D_ride_Face_A1 with ml
    D "I want your love deep inside me!"
    X "[D]?!"
    X "No, this isn't right!"
    D "What's wrong dad?"
    scene ep1_000_black
    $ renpy.music.stop(channel=u'music', fadeout=0.1)
    scene ep3_Bedroom_MC_D_door__A1_POV_D_Door_Talk with fade
    D "Are you hurting?"
    scene ep3_Bedroom_MC_D_door__A1_POV_D_Door_Listen with ml
    X "[D], umm..."
    X "No I'm... I had a dream."
    X "What happened?"
    scene ep3_Bedroom_MC_D_door__A1_POV_D_Door_Talk with ml
    D "I heard you and thought you were in pain."
    D "Then went to the door and you called my name, so I came in."
    scene ep3_Bedroom_MC_D_door__A1_FREE_D_Door_Listen with ml
    X "Oh I see, thank you!"
    X "But I'm fine, nothing to worry about."
    X "You can go back to bed."
    scene ep3_Bedroom_MC_D_door__A1_POV_D_Door_Talk with ml
    D "Okay..."






    scene ep3_Bedroom_MC_Look_Wall_A1 with ml
    "Must've been one of those reality leaking in to the dream type of situations."
    "Yeah, that's probably it...."
    scene ep1_000_black with fade
    pause 1
    $ renpy.music.play("audio/music/morning-breakfast.ogg", channel=u'music', loop=True, fadein=4,fadeout=4)
    scene ep3_D_Eat_Breakfast_A2_POV_D_Listen with dissolve
    X "So about last night."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Talk
    D "I'm sorry for going in your room like that!"
    scene ep3_D_Eat_Breakfast_A2_POV_D_Listen
    X "You have nothing to be sorry about!"
    X "I was just dreaming of... something. And just talked in my sleep, that's all."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Talk
    D "Was it a scary dream?"
    X "Not exactly."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Talk_Hand_Table with ml
    D "You really were not in pain?"
    scene ep3_D_Eat_Breakfast_A2_POV_D_Listen_Hand_Table
    X "I really wasn't. Why do you ask?"
    scene ep3_D_Eat_Breakfast_A2_POV_D_Talk_Hand_Table
    D "Because of the swelling."
    X "Swelling?"
    D "Of your willy."
    X "You mean my penis!"
    scene ep3_D_Eat_Breakfast_A2_POV_D_Cereal_Spoon with ml
    D "Yes, your..."
    "She doesn't seem to know much about this stuff."
    "Better talk to her about it."
    X "It's okay to say 'penis', that's not a dirty word."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Listen_Hand_Table
    X "And the swelling is normal."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Talk
    D "Oh."
    D "So then is it okay if I talk to you about my... private parts?"
    scene ep3_D_Eat_Breakfast_A2_POV_D_Listen
    X "Perfectly fine. Whatever issues you have, you can tell me."
    X "Or talk to [Eileen] if you don't feel comfortable."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Talk_Hand_Table
    D "Well there's this thing..."
    D "I'm not sure if it's pee, but I found my panties were a little wet this morning."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Listen_Hand_Table
    X "Did you have any pains?"
    scene ep3_D_Eat_Breakfast_A2_POV_D_Talk
    D "No, but I also felt a little warm down there."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Listen
    "Maybe she's just developing."
    X "I see, in any case, if anything comes up don't be shy about talking about it."
    scene ep3_D_Eat_Breakfast_A2_POV_D_Talk
    D "Thanks dad!"


    $ renpy.music.play("audio/music/livingroom-study.ogg", channel=u'music', loop=True, fadein=3)
    scene ep1_236_piano_mc_smartphone_day with rightleft
    Maya "Goodmornig [X]."
    Maya "I'm calling to ask if you have time to do a session this afternoon."
    X "I can do that. We have to get preparing for the competition."
    scene ep1_000_black with fade
    pause 0.5

    scene ep1_236_piano_mc_smartphone_day with leftright
    X "Hey doc! What's new?"
    Joan "I spoke to the gynecologist about your dad."
    Joan "Her hormone levels are too low for her age."
    X "What does that mean?"
    Joan "One possibility she is a late bloomer, but she has already had a growth spurt."
    Joan "So it's likely she took puberty blockers."
    Joan "Do you know if she had any implants or injections."
    X "No, I can ask her."
    Joan "And if you could locate her medical file, that would really help."
    X "I'll try."


    scene ep3_D_watch_TV_A2_POV_D_watching_TV with downtop
    X "...so did you normally take any medication back home?"
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC with ml
    D "I took some when I had a cold."
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "That's normal."
    X "Did you take any pills when you weren't sick?"
    X "Or any other medication like injections?"
    D "No."
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC_look_down with ml
    D "Oh wait!"
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC_Hand_Raise
    D "I had a flu shot this year."
    D "It's that after a month, I still got sick."
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "That's not right?"
    scene ep1_236_piano_mc_smartphone_day with leftright
    X "I talked to her about it..."
    scene ep1_000_black with fade
    pause 0.5
    scene ep1_236_piano_mc_smartphone_day with ml
    Joan "She could've had an implant injected."
    Joan "You need to come in for more tests so I can say for certain."
    X "Will do, thanks doc!"

    scene ep3_D_watch_TV_A2_POV_D_watching_TV with downtop
    "Fucking hell, what other shit have they done to her..."
    "She may not even recognize things that happened to her."
    X "I know a lot of this is new to you."
    scene ep3_D_watch_TV_A2_POV_D_listen_MC with ml
    X "And it takes time to familiarize with things around here, so it's OK if you're not comfortable with anything."
    X "Like eating something you don't like or calling me 'dad', you don't have to force yourself to do any of that."
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC
    D "I'm comfortable with calling you 'dad'."
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "Even if you know me for only a few days?"
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC_Hand_Raise
    D "I knew about you from what mom wrote in the journal."
    D "I would imagine us all talking together."
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "And you never mentioned that stuff to your foster parents?"
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC_look_down
    D "No, [Radford] was never around. And he didn't want to talk when he was."
    D "And with [Odelia] I always had to act the way she wanted, or get punished."
    D "She never wanted to see {i}me{/i}"
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "Well screw them!"
    X "They don't deserve you anyway!"
    X "Hey, what do you think about mathematics?"
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC
    D "I think it's interesting."
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "So you don't hate it! That's good."
    X "I asked because a couple of girls are coming over for tutoring later."
    X "You've met [Alecia] the other day."
    D "Yes."
    X "Her friend is really good at math and I'm helping her get ready for a competition."
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC
    D "Wow really?"
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "If you want, you can study together."
    X "Maybe get to know each other and even become friends."
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC
    D "I would like that!"
    $ renpy.music.play("audio/sfx/house-doorbell.ogg", channel=u'sound', loop=False)
    pause 1.5
    X "Think that's them!"

    $ renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Floor_D_Sophie_Maya_Meet_A1_POV_Maya_intro_Sophie with leftright
    Maya "Why hello there!"
    Maya "I'm [Maya], this young girl is [Sophie]"
    X "This is [D], my dad."
    scene ep3_Floor_D_Sophie_Maya_Meet_A1_POV_Girls_Waving with ml
    D "Hello miss [Maya] and [Sophie]!"
    Sophie "Hi!"
    scene ep3_Floor_D_Sophie_Maya_Meet_A1_POV_D_Listen with ml
    X "[D], can you show [Sophie] to your room?"
    X "I don't really have a better place for you at the moment."
    scene ep3_Floor_D_Sophie_Maya_Meet_A1_POV_D_Talk
    D "Of course!"
    scene ep3_Floor_D_Sophie_Maya_Meet_A1_POV_D_Sophie_LEave with ml
    D "It's up the stairs over here."
    scene ep3_Floor_D_Sophie_Maya_Meet_A1_POV_Maya_Talk with ml
    Maya "Do you have a moment to talk?"

    scene ep3_Maya_talk_visit_A1_POV_Maya_Listen with topdown
    X "What about [Alecia], is she not coming?"
    scene ep3_Maya_talk_visit_A1_POV_Maya_Talk
    Maya "They called her in for work today."
    Maya "She did promise to come by later."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Listen
    X "Does she need a ride?"
    scene ep3_Maya_talk_visit_A1_POV_Maya_Talk
    Maya "No, a co-worked will bring her."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Listen
    X "And how are things going at The Home?"
    scene ep3_Maya_talk_visit_A1_POV_Maya_Talk_Look_Away
    Maya "We'll be alright, at least till the next fundraiser."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Listen
    X "When is it?"
    scene ep3_Maya_talk_visit_A1_POV_Maya_Talk
    Maya "Christmas, I've been told it's the best time to organize it."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Listen
    X "That makes sense."
    X "But it would be much better to just have enough funding from the city."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Talk_Hand
    Maya "We've tried that, but they keep saying there's no need because the orphanage is doing fine."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Listen
    X "So they're thinking of giving even less just like the previous year."
    scene ep3_Maya_talk_visit_A1_FREE_Maya_Listen_Face with ml
    X "Plus the reason you're doing fine is because of the community!"
    X "But what would they know, it's not like they're part of it!"
    scene ep3_Maya_talk_visit_A1_FREE_Maya_Talk_Side with ml
    Maya "Maybe there are bigger issues that ours."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Listen with ml
    X "Well yeah, but it's not like they're taking care of those either."
    X "Anyway, it's going to be some time till Christmas."
    X "And prices have shot up since last year."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Talk_Look_Away with ml
    Maya "I have managed to offset that by supplying food from the farm."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Listen
    X "Have you found someone to help, or maybe a husband?"
    scene ep3_Maya_talk_visit_A1_FREE_Maya_Talk_Smile_Front with ml
    Maya "A husband... not yet I'm afraid."
    Maya "But [Alecia] has been coming with me."
    X "She's keeping busy I see."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Talk_Look_Away_Smile
    Maya "It does seem like she enjoys the learning the process."
    X "I'll keep that in mind."
    scene ep3_Maya_talk_visit_A1_FREE_Maya_Talk_Face with ml
    Maya "Now I won't take more of your time."
    X "I'll see you out."
    scene ep3_Maya_talk_visit_A1_POV_Maya_Leave with ml
    Maya "No please, it's fine."
    Maya "I'll come pick up the girls later."
    X "Alright."
    scene ep3_Girls_Tutor_D_Sophie_bed_study with leftright
    Sophie "...and right now we're studying this."
    D "I don't know about that."
    D "But there was a question about this on the test, didn't figure it out."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Sophie_Point_Book with ml
    Sophie "If you know this much, maybe we'll be in the same grade."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_D_Talk_Sophie_1 with ml
    D "I would like that."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Sophie_Talk_D_1 with ml
    Sophie "And you can have mister [X] help you in any case."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Both_Listen with ml
    X "Who is this mister [X] you're refering to?"
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Sophie_Talk_MC with ml
    Sophie "Sorry, [X]."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Both_Listen
    X "So I did a review of the material and also looked at the previous tests."
    X "Let's start off by looking how you solved the previous problems at the competition."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_D_Talk_MC
    D "At the competition you mentioned?"
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Sophie_Talk_D_1
    Sophie "I participated in the Olympiad these past years."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_D_Talk_Sophie_1
    D "So that's why you know all this stuff!"
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Sophie_Talk_D_1
    Sophie "I go over most of the material beforehand."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Both_Listen
    X "So that it's all fresh in your mind."
    scene ep1_000_black with fade
    pause 1.6
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Sophie_Talk_MC
    Sophie "That problem took me a while, I lost time on it coming up with a more elegant solution."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Both_Listen
    X "I see, you went with the obvious approach, and it ended up being too long."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Sophie_Talk_MC
    Sophie "That's right."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Both_Listen
    X "They have more of these types of problems on later stages."
    X "So let's work on those now."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_D_Talk_MC
    D "Do they give less points if your solution is too long?"
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Both_Listen
    X "If they worked out a simpler one before the test, yes."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Sophie_Talk_D_1
    Sophie "You can also think up something new. That's worth extra."
    scene ep1_000_black with fade
    pause 1.0
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Both_Listen with ml
    X "We're nearing the end here. I'll go make prep some sandwitches."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_D_Talk_MC
    D "I can help."
    scene ep3_Girls_Tutor_D_Meet_A2_POV_Bed_End_Both_Listen
    X "No need for that. You girls just relax here."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Sandwich_prep with leftright
    "Better skip the onions again, play it safe."
    $ renpy.music.play("audio/sfx/house-doorbell.ogg", channel=u'sound', loop=False)
    pause 1.5
    X "It's open, come on in!"
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia_Arrive_Kitchen with ml
    X "Hey, you made it!"
    Alecia "I only got out now. And that was our deal."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Listen with ml
    X "I get it, but that was only half of it."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk
    Alecia "I know."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Listen
    X "And we're almost finished for today. So can you wash the salad?"
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk_Look_Away
    Alecia "Yeah, sure."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia_Salad_Strain with ml
    "If she likes agriculture, I can try to get a rise out of her and engage with something."
    X "I got some salad from a local farmer. But I don't know, it's probably the same from the store."
    Alecia "It's not the same."
    X "It's all green and tastes lke nothing, what's the difference?"
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk_Hand_Raise with ml
    Alecia "It's not even close!"
    Alecia "Have you even tried comparing anything else, other than lettuce?"
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Listen
    X "But that's the only salad, what else is there?"
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk
    Alecia "You can't be serious!"
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk_Point
    Alecia "Are sandwiches the only thing you make?"
    X "I can boil eggs too."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk_Hand_Raise
    Alecia "Try spinach, carrots, cucumbers, tomatoes, they're all better from local producers."
    scene ep3_Alecia_Kitchen_sandwitches_A1_FREE_Alecia__Listen with ml
    X "You sound really sure about all that."
    X "They might be just buying it from a chain store and marketing it like that."
    X "How would you even know?"
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk with ml
    Alecia "Because I've gone with them, and worked there."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Listen
    X "Oh really?"
    X "I'd like to go there too one day."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk
    Alecia "[Maya] often goes home to tend the crops and works most of the day."
    Alecia "Feel free to lend a hand."
    scene ep3_Alecia_Kitchen_sandwitches_A1_FREE_Alecia__Listen with ml
    X "I know she cares a lot about you guys, I'm worried that she's pushing herself too much."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk_Look_Away with ml
    Alecia "Yeah, wanted to help but she said no."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk_Hand_Raise
    Alecia "Then I told her I was interested in agriculture, so she wouldn't feel guilty for using me or something."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Listen_Look_Away
    X "That's considerate."
    X "It's not healthy to work that much. I can make some time to help."
    scene ep3_Alecia_Kitchen_sandwitches_A1_POV_Alecia__Talk_Hand_Raise
    Alecia "We're close to harvest, so I'll hold you to that."
    scene ep3_Alecia_Kitchen_sandwitches_A1_Free_Sandwich_Prep with ml
    X "I'll try some new stuff next time, don't want you girls to get bored of me."
    Alecia "How considerate."
    scene ep3_Floor_D_Girls_meet_A1_POV_Girls_D_Waving with downtop
    Sophie "Hope we will be in the same class!"
    D "Me too!"
    Alecia "Bye there."
    D "Bye bye!"

    $ renpy.music.play("audio/music/d-house.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_D_watch_TV_A2_POV_D_listen_MC with rightleft
    X "So did you enjoy it?"
    X "Not the math, hanging out with [Sophie] I mean."
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC
    D "I did, she's very nice!"
    D "And can we do more math?"
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "More!? Of course, we can do as much as you want!"
    X "But for today, let's just relax."
    X "Got a few movies over here, tell me if you want any of them"
    scene ep3_D_watch_TV_A2_FREE_DVD_Choice_Terminator with ml
    X "That's a classic action movie, lots of shooting and explosions."
    D "Oh..."
    X "Not interested I see."
    scene ep3_D_watch_TV_A2_FREE_DVD_Choice_Ghostbusters with ml

    D "What's this?"
    X "It's a comedy, with ghosts and stuff."
    D "Is it scary?"
    X "Maybe for little kids, but you're a big girl."
    scene ep3_D_watch_TV_A2_FREE_DVD_Choice_Alien with ml

    X "This is more of a science-fiction. And this one's actually scary."
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC_Hand_Raise with ml
    D "I read some science fiction books, they were fun!"
    X "We can talk about them."
    scene ep3_D_watch_TV_A2_FREE_DVD_Choice_Flick with ml

    X "I don't know how that got there."
    D "What is it about?"
    X "Don't know, I've never seen it."
    scene ep3_D_watch_TV_A2_POV_D_listen_MC with ml
    X "But watching movies like this on a TV isn't doing them justice."
    X "There are places in town where you can watch movies on a giant screen!"
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC
    D "You mean cinemas?"
    X "Ever been to one?"
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC_look_down
    D "No, but I read about them."
    X "Well that won't do!"
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    X "We can check one out tomorrow. How does that sound?"
    scene ep3_D_watch_TV_A2_POV_D_ltalk_MC
    D "Great!"
    scene ep3_D_watch_TV_A2_POV_D_listen_MC
    "Now which movie to watch?"
    menu:
        "Chick flick":
            $ ep3_d_movie = "flick"
            scene ep3_D_watch_TV_A2_FREE_DVD_Choice_Flick with ml
            "This is probably the safe option."
            X "Let's see what this one's about."
            scene ep1_000_black with fade
            pause 2
            scene ep3_Livingroom_Night_TV_Credit_Rolls with topdown
            X "Well that was... a movie."
            scene ep3_D_watch_TV_A2_POV_D_ltalk_MC with ml
            D "I enjoyed it."
            scene ep3_D_watch_TV_A2_POV_D_listen_MC
            X "Now time for bed, it's getting late."
        "Comedy":
            $ ep3_d_movie = "comedy"
            scene ep3_D_watch_TV_A2_FREE_DVD_Choice_Ghostbusters with ml
            X "Let's go with this one."
            scene ep1_000_black with fade
            pause 2
            scene ep3_Livingroom_Night_TV_Credit_Rolls with topdown
            X "And it's over."
            scene ep3_D_watch_TV_A2_POV_D_ltalk_MC with ml
            D "That was fun!"
            scene ep3_D_watch_TV_A2_POV_D_listen_MC
            X "Now time for bed, it's getting late."
        "Sci-Fi Horror":
            $ ep3_d_movie = "horror"
            $ D_p +=1
            scene ep3_D_watch_TV_A2_FREE_DVD_Choice_Alien with ml
            "Looked like she was interested in this one."
            X "If it gets too scary, we can always stop."
            D "Okay!"
            scene ep1_000_black with fade
            pause 2
            scene ep3_Livingroom_Night_TV_Credit_Rolls with topdown
            X "It's over."
            scene ep3_D_watch_TV_A2_POV_D_watching_TV with ml
            X "You got scared a few time, but you watched the entire thing."
            scene ep3_D_watch_TV_A2_POV_D_ltalk_MC_Hand_Raise
            D "I wanted to see the whole story."
            scene ep3_D_watch_TV_A2_POV_D_listen_MC
            X "It is captivating."
            X "Now time for bed, it's getting late."
        "Action":
            $ ep3_d_movie = "action"
            scene ep3_D_watch_TV_A2_FREE_DVD_Choice_Terminator with ml
            X "You just have to see the classics first."
            D "Okay..."
            scene ep1_000_black with fade
            pause 2
            scene ep3_Livingroom_Night_TV_Credit_Rolls with topdown
            X "That's it."
            scene ep3_D_watch_TV_A2_POV_D_ltalk_MC with ml
            D "That was exiting."
            scene ep3_D_watch_TV_A2_POV_D_listen_MC
            X "Now time for bed, it's getting late."
    $ D_p_t +=1
    $ renpy.music.stop(channel=u'music', fadeout=1.0)
    scene ep3_Bedroom_MC_Look_Wall_A1 with downtop
    "Still no news today."
    "Gotta get some shuteye..."
    scene ep1_000_black with fade
    pause 2
    if ep3_d_movie == "horror":
        $ renpy.music.play("audio/sfx/door-knock.ogg", channel=u'sound', loop=False)
        pause 2
        D "dad... Are you awake?"

        $ renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)
        scene ep3_Bedroom_MC_Look_Wall_A1 with dissolve
        X "Yes, is something wrong?"
        D "I'm scared!"
        D "Can I come in?"
        X "Of course."
        scene ep3_Bedroom_MC_D_door__A1_FREE_D_Door_Scared with leftright
        D "I'm scared of... aliens."
        scene ep3_Bedroom_MC_D_door__A1_POV_D_Door_Scared with ml
        X "That's normal, after watching that movie."
        X "You can sleep here if you want."
        D "Thank you!"
        scene ep3_Bedroom_MC_D_sleep_A1_POV_D_Talk with ml
        D "I know it's silly, but I can't help it."
        scene ep3_Bedroom_MC_D_sleep_A1_POV_D_Listen
        X "We all have that reaction."
        X "First time is when I was little. We had the bathroom on the other end on the hallway."
        scene ep3_Bedroom_MC_D_sleep_A1_POV_D_Talk with ml
        D "And what did you do?"
        scene ep3_Bedroom_MC_D_sleep_A1_POV_D_Listen
        X "I mentioned I was little. So I had the genius idea to just let it out the window."
        scene ep3_Bedroom_MC_D_sleep_A1_POV_D_Talk
        D "You peed out the window?"
        scene ep3_Bedroom_MC_D_sleep_A1_POV_D_Listen
        X "Yeah, but don't tell anyone!"
        X "I actually got away with that, unlike other things."
        scene ep3_Bedroom_MC_D_sleep_A1_POV_D_Talk with ml
        D "Like what?"
        scene ep3_Bedroom_MC_Look_Wall_A1 with ml
        X "There was this one time..."
        scene ep1_000_black with fade
        pause 1.5
        scene ep3_Bedroom_MC_Look_Wall_A1 with ml
        X "...so I ended peeling all the potatoes by myself for two weeks."
        scene ep3_Bedroom_MC_D_sleep_A1_POV_D_Sleep with ml
        X "But they went easy on me--"
        "She's asleep."
        scene ep3_Bedroom_MC_D_sleep_A1_FREE_D_Sleep with ml
        "Better turn up the heat a bit..."
        scene ep1_000_black with fade
        pause 2.0
        D "Mmmm."
        D "dad..."
        scene ep3_Bedroom_MC_D_night_sleep_fap with dissolve
        X "[D]?"
        X "Are you col--"
        "Is she touching herself?"
        scene ep3_Bedroom_MC_D_night_sleep_fap_face with ml
        pause 1.0
        "Looks like she's still sleeping."
        scene ep3_Bedroom_MC_Look_Wall_A1 with ml
        "Better leave her be..."
        scene ep1_000_black with fade
        pause 1.0
    else:
        pause 1.0

    $ renpy.music.stop(channel=u'music', fadeout=2.0)
    scene ep1_033_room_mc_bed_sitting with dissolve
    "She's up already."
    scene ep1_304_room_mc_washingmachine with fade
    "Clothes have pilled up."
    scene ep3_MC_panties_D_wet_POV_machine_empty with ml
    "Time to wash."
    scene ep3_MC_panties_D_wet_POV_placing_clothes with ml
    "Let's see, got my shirt, check, pants, check."
    scene ep3_MC_panties_D_wet_POV_panty_hold with ml
    "Her PJs are wet."
    "It's not sweat, it's only this area."
    "Wait!"
    scene ep2_238_Bedroom_MC_bulge with ml
    X "Damn it!"
    "It happened again. It has to be because of her."
    "I could... take care of this."
    menu:
        "Relieve yourself":
            $ ep3_panties = "release"
            "It's just because she reminds me of [Emily]."
            scene ep3_MC_panties_D_wet_POV_jackin with ml
            "Yeah, that's the reason."
            "Get this done quickly."
            scene ep1_000_black with fade
            pause 2.0
            scene ep3_MC_panties_D_wet_POV_jackin_cum with ml
            X "Ugghh!"
            X "Fuck!"
            scene ep3_MC_panties_D_wet_POV_Door_Closed with ml
            "That didn't feel as wrong as it should've..."
        "Just wash the clothes":
            $ ep3_panties = "abstain"
            scene ep3_MC_panties_D_wet_POV_Door_Closed with ml
            "She's my dad!"
            "What the hell am I thinking!"
    $ renpy.music.play("audio/music/morning-routine-house.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Laptop_TYpe_Day_A1 with leftright
    "Haven't checked my mail in a while."
    pause 1.0
    "What the hell, an offer to go back to the company?!"
    "Guess they couldn't figure out all my pipelines."
    "A few from my team are still there, I could give them some help."
    "Or not."
    menu:
        "Go back to work":
            $ ep3_job_return = "accept"
            "They're probably struggling like hell."
            "I could do it for the team..."
        "Tell them off":
            $ ep3_job_return = "refuse"
            "Nah fuck'em!"
            "But since they gave me an opportunity to respond..."


    scene ep1_000_black with dissolve
    pause 1.0
    scene ep3_Laptop_TYpe_Day_A1 with dissolve
    $ renpy.music.play("audio/sfx/house-doorbell.ogg", channel=u'sound', loop=False)
    pause 1.5
    "Who could that be."
    $ renpy.music.play("audio/music/positive way.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Eileen_Bags_A1_POV_Eileen_Door with leftright
    X "Hey [Eileen], what's all this?"
    Eileen "Just a few things for that cutie, got more downstairs."
    Eileen "Got a cake there, so be careful!"
    X "Alright."
    scene ep3_Entrance_Day_Eileen_A1_POV_Eileen_Talk_Point with ml
    Eileen "Where is the lady of the house?"
    scene ep3_Entrance_Day_Eileen_A1_POV_Eileen_Listen
    X "Upstairs. What did you get?"
    scene ep3_Entrance_Day_Eileen_A1_POV_Eileen_Talk
    Eileen "Girl stuff."
    Eileen "And I want to surprise her with the cake."
    scene ep3_Entrance_Day_Eileen_A1_POV_Eileen_Listen
    X "OK, I'll get on it."
    scene ep3_Dining_D_Eileen_cake_A1_POV_D_Hands with topdown
    Eileen "No peeking!"
    scene ep3_Dining_D_Eileen_cake_A1_FREE_D_Hands with ml
    D "I have my eyes closed too!"
    scene ep3_Dining_D_Eileen_cake_A1_FREE_D_Reveal with ml
    Eileen "Happy birthday!"
    D "Is that for me?"
    scene ep3_Dining_D_Eileen_cake_A1_POV_Eileen_Talk_D with ml
    Eileen "Sure is! It's strawberry, did I get that right?"
    scene ep3_Dining_D_Eileen_cake_A1_POV_D_Talk_Eileen with ml
    D "Yes!"
    D "But it's actually not my birthday."
    scene ep3_Dining_D_Eileen_cake_A1_POV_Eileen_Talk_D with ml
    Eileen "Oh shoot! We better find something to celebrate then."
    scene ep3_Dining_D_Eileen_cake_A1_POV_Eileen_Talk_MC with ml
    Eileen "Any ideas daddy?"
    scene ep3_Dining_D_Eileen_cake_A1_POV_Eileen_D_Listen with ml
    menu:
        "Celebrate BirthYear":
            $ ep3_celebration = "birthyear"
            X "It may not be your birthDAY but it is your birthYEAR."
            scene ep3_Dining_D_Eileen_cake_A1_POV_Eileen_Talk_MC
            Eileen "Oh I see! That's a little loophole you found there."
            scene ep3_Dining_D_Eileen_cake_A1_FREE_Eileen_touch_D with ml
            Eileen "So Happy Birthyear to you..."
        "Celebrate NameDay":
            $ ep3_celebration = "nameday"
            X "How about your name day?"
            scene ep3_Dining_D_Eileen_cake_A1_POV_Eileen_Talk_MC
            Eileen "That works I guess."

    scene ep1_000_black with dissolve
    pause 1.0
    scene ep3_Dining_D_Eileen_cake_A1_FREE_Eileen_touch_D with dissolve
    Eileen "And now make a wish, but don't tell anyone."
    Eileen "Then blow out the candle."
    scene ep3_Dining_D_Eileen_cake_A1_POV_D_bend with ml
    D "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🌬️{/font}"
    scene ep3_Dining_D_Eileen_Cake_A1_FREE_D_blow with ml
    "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}👏 👏 👏{/font}"
    X "Bravo!"
    Eileen "Now let's grab a slice!"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_Eat_Cake with ml
    Eileen "How is it [D]?"
    scene ep3_Dining_D_Eileen_cake_table_A1_FREE_Eileen_ltalk_D with ml
    Eileen "Be honest with me!"
    scene ep3_Dining_D_Eileen_cake_table_A1_FREE_D_Talk_Eileen with ml
    D "It's straight fire!"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_talk_MC with ml
    D "Did I use that right?"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_Eat_Cake with ml
    Eileen "Right on the money!"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_talk_MC with ml
    D "[Sophie] said that about the house."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_listen_MC
    X "Did she? Well I guess--"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_talk_D
    Eileen "I did most of the decorating in this place you know."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_talk_MC
    Eileen "And would've done it properly but [X] basically kicked me out."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_listen_MC
    X "I've seen your place, you would've just kept going if I let you."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_talk_MC
    Eileen "Damn right I would!"
    Eileen "There's just so much empty space here!"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_talk_D
    Eileen "I'm sure [D] agrees with me."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_talk_Eileen with ml
    D "The house is... spacious."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_listen_MC
    X "And that's a good thing!"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_talk_MC with ml
    Eileen "But it's not the same thing, so don't make it seem like she's agreeing with you!"
    Eileen "Now how about you both visit my place."
    Eileen "If I can convince [D] of my point of view, you must allow for more decorating."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_talk_D
    Eileen "And [D] will do all of it as she pleases."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_listen_MC
    X "I have no problem with that!"
    X "And if she agrees with me, you have to bake her a cake whenever she wants!"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_talk_MC
    Eileen "With pleasure, you're on!"
    X "But we'll have to do it another time."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_listen_MC with ml
    X "We already talked about checking out a movie at the cinema tonight."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_talk_Eileen
    D "Oh, you can come with us [Eileen]!"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_talk_D with ml
    Eileen "I'd love to dear, but I have to go later. Got some more baking to get done."
    D "Oh."
    Eileen "Hey don't worry! We'll go out another time."
    Eileen "Maybe even bake a cake together if you want."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_talk_Eileen with ml
    D "I would love that!"
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_listen_MC
    X "We better start getting ready before it gets too late."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_D_talk_MC
    D "I'll go clean up."
    scene ep3_Dining_D_Eileen_cake_table_A1_POV_Eileen_stand_talk_MC with ml
    Eileen "There's a few things I have to show you, so I'm coming with."
    X "I'll hit the shower then."
    scene ep1_000_black with fade
    pause 1
    $ renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Eileen_shower_A2_POV_Alone_1 with leftright
    Eileen "Hey [X]! You still in?"
    X "Yes."
    Eileen "Just gotta use the bathroom."
    X "Go ahead."
    Eileen "I ran a bath for her and talked about using pads and tampons."
    X "Thanks."
    X "You already finished?"
    Eileen "She's a smart girl, catches on fast."
    X "Takes after her mother."
    Eileen "Yeah."
    Eileen "So anything new come up?"
    X "There are a few things..."
    scene ep1_000_black with fade
    pause 2.0
    scene ep3_Eileen_shower_A2_POV_Alone_2 with topdown
    Eileen "They had her take puberty blockers?!"
    X "Seems like it. Still need to do some tests."
    Eileen "And still no news on [Emily]?"
    X "Waiting for [Charlie] to get the warrant and investigate [D]'s foster parents."
    Eileen "It's moving forward at least."
    X "Yeah."
    Eileen "I'm done, do you want me to wash your back?"
    menu:
        "Let her help":
            $ ep3_eileen_buttjob = "accepted"
            $ Eileen_p += 1
            scene ep3_Eileen_shower_A2_POV_Alone_1 with ml
            X "Sure, if you want to."
            $ renpy.music.play("audio/music/lofi sexy 1.ogg", channel=u'music', loop=True, fadein=3)
            scene ep3_Eileen_shower_A1_Join with dissolve
            X "Wait, why are you naked?"
            Eileen "Figured I'd get a free shower and save money."
            Eileen "Why, you got a problem with that?"
            scene ep3_Eileen_shower_A2_POV_Alone_2 with ml
            X "Not really, but I get the sense that I should."
            Eileen "So don't look then!"
            X "Oh right, problem solved."
            scene ep3_Eileen_shower_A2_Head_Back with fade
            X "Hey!"
            Eileen "What?"
            scene ep3_Eileen_shower_A2_POV_Wash_Back with ml
            Eileen "I washed your back, you wash my back now."
            X "I'm being too laissez-faire about this."
            scene ep3_Eileen_shower_A2_Boobs_Face with ml
            Eileen "So you wanna take charge big strongman?"
            X "Don't know about that."
            scene ep3_Eileen_shower_A1_Erecting with ml
            Eileen "But I sense some hard initiaitve from you."
            X "Oh that's... not right."
            Eileen "Yeah it's seems you're going for a more centrist position."
            scene ep3_Eileen_shower_A1_Side_ANIM_0 with ml
            Eileen "You wanna ride the fence for a bit longer?"





            $ load_rate = 0.049
            $ load_rate_level = 1
            $ fanum = 0

            init python:
                def ep3_Eileen_shower_A1_POV_ANIM(load, a, b):
                    load.set_child("ep3_Eileen_shower_A1_POV_ANIM_{}".format(store.fanum))
                    store.fanum += 1
                    if store.fanum == 21 and store.load_rate_level == 4:
                        store.load_rate = 0.0169
                        store.load_rate *=2.5
                    if store.fanum == 35 and load_rate_level == 4:
                        store.load_rate /=2.5
                    if store.fanum > 59:
                        store.fanum = 0
                    return store.load_rate
                def track_load_rate(value):
                    store.load_rate = value

            init python:
                def ep3_Eileen_shower_A1_Side_ANIM(load, a, b):
                    load.set_child("ep3_Eileen_shower_A1_Side_ANIM_{}".format(store.fanum))
                    store.fanum += 1
                    if store.fanum == 21 and store.load_rate_level == 4:
                        store.load_rate = 0.0169
                        store.load_rate *=2.5
                    if store.fanum == 35 and load_rate_level == 4:
                        store.load_rate /=2.5
                    if store.fanum > 59:
                        store.fanum = 0
                    return store.load_rate
                def track_load_rate(value):
                    store.load_rate = value


            image ep3_Eileen_shower_A1_Side_ANIM:
                function ep3_Eileen_shower_A1_Side_ANIM
            image ep3_Eileen_shower_A1_POV_ANIM:
                function ep3_Eileen_shower_A1_POV_ANIM

            $ fanum = 0

            screen SHOW_ep3_Eileen_shower_A1_POV_ANIM():
                vbox:
                    yalign 0.85
                    xalign 0.0
                    spacing -5
                    textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1) style "screen_button"
                    textbutton "Rythmic" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2) style "screen_button"
                    textbutton "Fast" action SetVariable("load_rate", 0.015),SetVariable("load_rate_level", 3) style "screen_button"
                    textbutton "Head Squeeze" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
                hbox:
                    yalign 0.93
                    xalign 0.01
                    spacing 5
                    textbutton "POV" style "screen_button"
                    textbutton "SIDE" action Jump("SHOW_ep3_Eileen_shower_A1_Side_ANIM") style "screen_button"
                hbox:
                    yalign 0.99
                    xalign 0.02
                    spacing 45
                    textbutton "END" action Jump("continue_after_animation_2") style "screen_button"
                vbox:
                    yalign 0.97
                    xalign 0.94
                    textbutton _("Hide (H)") action HideInterface() style "screen_button"

            screen SHOW_ep3_Eileen_shower_A1_Side_ANIM():
                vbox:
                    yalign 0.85
                    xalign 0.0
                    spacing -5
                    textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1) style "screen_button"
                    textbutton "Rythmic" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2) style "screen_button"
                    textbutton "Fast" action SetVariable("load_rate", 0.015),SetVariable("load_rate_level", 3) style "screen_button"
                    textbutton "Head Squeeze" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
                hbox:
                    yalign 0.93
                    xalign 0.01
                    spacing 5
                    textbutton "POV" action Jump("SHOW_ep3_Eileen_shower_A1_POV_ANIM") style "screen_button"
                    textbutton "SIDE" style "screen_button"

                hbox:
                    yalign 0.99
                    xalign 0.02
                    spacing 45
                    textbutton "END" action Jump("continue_after_animation_2") style "screen_button"
                vbox:
                    yalign 0.97
                    xalign 0.94
                    textbutton _("Hide (H)") action HideInterface() style "screen_button"

            scene ep3_Eileen_shower_A1_Side_ANIM
            pause 1.3
            scene ep3_Eileen_shower_A1_Side_ANIM_29
            X "Wait!"
            $ fanum = 29
            scene ep3_Eileen_shower_A1_Side_ANIM_29
            pause 1.0
            scene ep3_Eileen_shower_A1_Side_ANIM
            pause 2
            X "Oohh!"
            Eileen "Just relax, I'll take care of it."
            scene ep3_Eileen_shower_A1_POV_ANIM
            X "I can... do this myself."
            Eileen "You've been getting erect on you own?"
            X "Yes."
            Eileen "Without wet dreams?"
            X "Well..."
            scene ep3_Eileen_shower_A1_Side_ANIM with ml
            "Can't really tell her about those times."
            Eileen "Found someone who can do it?"
            X "No..."
            Eileen "Then you still need my help."
            scene ep3_Eileen_shower_A1_POV_ANIM with ml
            Eileen "So go ahead and enjoy it."

            label SHOW_ep3_Eileen_shower_A1_POV_ANIM:
                scene ep3_Eileen_shower_A1_POV_ANIM with ml
                call screen SHOW_ep3_Eileen_shower_A1_POV_ANIM
            label SHOW_ep3_Eileen_shower_A1_Side_ANIM:
                scene ep3_Eileen_shower_A1_Side_ANIM with ml
                call screen SHOW_ep3_Eileen_shower_A1_Side_ANIM

            label continue_after_animation_2:
                $ load_rate = 0.0169
                $ load_rate_level = 4
                scene ep3_Eileen_shower_A1_POV_ANIM with ml
                X "I'm gonna cum [Eileen]!"
                Eileen "Let it out!"
                scene ep3_Eileen_shower_A2_POV_Look_Down_Ejaculate
                X "Fuuck!"
                scene ep3_Eileen_shower_A2_Butt_Low with ml
                Eileen "That felt... like a lot."
                scene ep3_Eileen_shower_A2_Close_Pussy with ml
                Eileen "I can tell you needed this."
                scene ep3_Eileen_shower_A2_POV_Look_Down_Cum with ml
                X "That might be true."
                X "Thanks..."
                $ renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)
        "No need":




            $ ep3_eileen_buttjob = "refused"
            X "I'm good, thanks."
    $ Eileen_p_t += 1

    scene ep3_Entrance_Day_Eileen_A1_POV_Eileen_D_Hug with topdown
    D "You really can't come with us tonight?"
    Eileen "Sorry dear, I really have to go."
    Eileen "We can go out soon, you just be patient ok?"
    D "I will!"
    scene ep3_Entrance_Day_Eileen_A1_POV_Eileen_Talk_D with ml
    Eileen "You two have fun out there!"
    D "Bye [Eileen]!"
    Eileen "Bye cutie!"

    scene ep3_Entrance_Day_Eileen_A1_POV_D_Listen with ml
    X "Ready to head out?"
    scene ep3_Entrance_Day_Eileen_A1_POV_D_Talk with ml
    D "I'll go change."
    scene ep1_000_black with fade
    pause 1.0
    scene ep3_Cinema_D_Outside_Taken_A2_POV_D_arrive with leftright
    $ renpy.music.play("audio/music/cinema outside.ogg", channel=u'music', loop=True, fadein=2, fadeout=2)
    X "Here we are."
    D "Wow!"
    scene ep3_Cinema_D_Outside_Taken_A2_POV_D_talk with ml
    D "It looks just like in the movies!"
    scene ep3_Cinema_D_Outside_Taken_A2_POV_D_listen
    X "It's an old style place, it has that classic look."
    scene ep3_Cinema_D_first_POV_D_watch with leftright
    X "How are these seats?"
    scene ep3_Cinema_D_first_POV_D_listen with ml
    X "We can change them if you want to go closer."
    scene ep3_Cinema_D_first_POV_D_talk
    D "I don't mind."
    scene ep3_Cinema_D_Inside_Screen_1 with fade
    X "Figured you wanted something sci-fi, so I got this one."
    scene ep3_Cinema_D_first_POV_D_eat_popcorn with dissolve
    "She looks engrossed in the action."
    scene ep3_Cinema_D_first_FREE_D_eat_popcorn with ml
    "How can you not take a child to the cinema even once."
    "And just keep them in the house."
    scene ep3_Cinema_D_first_POV_D_watch with ml
    "I'll never let them take her away!"
    scene ep3_Cinema_D_first_POV_D_talk with ml
    D "dad."
    scene ep3_Cinema_D_first_POV_D_listen
    X "How's the movie?"
    scene ep3_Cinema_D_first_POV_D_talk
    D "It's straight fire!"
    D "Thank you for taking me out!"
    scene ep3_Cinema_D_first_POV_D_listen
    X "It's my pleasure, we can come as many times as you want."
    scene ep3_Cinema_D_Outside_Taken_A2_POV_D_leave with rightleft
    D "That was really fun!"
    D "But I feel a little dizzy now."
    X "That should pass."
    X "Just wait here I'll get rid of the trash."
    scene ep3_Cinema_D_Outside_Taken_A1_POV_Trash_Can with ml
    "Looks like I'm getting a hang of this parent--"

    $ renpy.music.play("audio/music/d-taken.ogg", channel=u'music', loop=True, fadein=3)
    D "Aaaahhh! Daddy!!"
    scene ep3_Cinema_D_Outside_Taken_A1_POV_Trash_Can_Van
    X "[D]!!!"
    scene ep3_Cinema_D_Outside_Taken_A1_Van_Close with ml
    X "Let her go you bastards!!!"
    scene ep3_City_Drive_D_taken_A1_FREE_Drive_Shift with ml
    $ renpy.music.play("audio/ambience/car-acceleration-inside-car.ogg", channel=u'ambience', loop=False)
    X "Damn it!"
    "What the fuck are these shitbags doing?"
    scene ep1_000_black with fade
    pause 2.0
    scene ep3_City_Drive_D_taken_A1_POV_Drive_Takeoff with ml
    "Did they go this way?"
    scene ep1_000_black with fade
    pause 2.0
    scene ep3_City_Drive_D_taken_A1_POV_Drive_Stop with ml
    $ renpy.music.stop(channel=u'ambience', fadeout=1)
    X "FUCK!!"
    X "Lost 'em!"
    scene ep3_Cinema_D_Outside_Taken_A1_Thug_Close_Back with ml
    "But I recognize those cocksuckers!"
    "[Khalil] has to know where that bastard's staying."
    scene ep3_City_Drive_D_taken_A1_POV_Drive_Phone with ml
    pause 1.0
    Khalil "Yo [X]! What's up?"
    X "[Khalil], you know where that fuckers's operating now?"
    Khalil "Shit! You in trouble with them?"
    Khalil "Where' you at?"
    X "I don't have time now, just give me his location."
    Khalil "He's near the old dock, at a warehouse there."
    Khalil "What happened?"
    X "They took my dad!"
    Khalil "Your dad?!"
    X "I gotta take care of this quickly, we'll talk after!"
    Khalil "Alright man, if you need help just say the word!"
    scene ep1_000_black with fade
    pause 2.0 
    scene ep3_Warehouse_MC_arrive_car with ml
    "This looks like the place."
    scene ep3_Warehouse_MC_arrive_gate with ml
    "These idiots didn't even lock the gates."
    scene ep3_Warehouse_Night_Thugs_approach with ml
    $ renpy.music.play("audio/music/going after her.ogg", channel=u'music', loop=True, fadeout=2, fadein=4)
    "Like they own the street."
    "Don't see the van anywhere."
    scene ep3_Warehouse_A1_Night_Thugs_meet with ml
    "Thug no.1" "You can't let that bitch talk to you like that!"
    "Thug no.1" "Next time she opens her mouth, take a f--"
    scene ep3_Warehouse_A1_Night_Thugs_listen with ml
    X "Is your boss in? I gotta talk to him."
    "Thug no.1" "'The fuck...'"
    scene ep3_Warehouse_A1_Night_Thugs_talk with ml
    "Thug no.1" "Get the fuck out before I skull fuck you to death!"

    $ renpy.music.play("audio/sfx/punch-140236.ogg", channel=u'sound', loop=False)
    scene ep3_Warehouse_A1_Night_Thugs_punch_T2 with punch_nrml
    pause 0.3
    X "You swear too much."
    scene ep3_Warehouse_A1_Night_Thugs_knife_T1 with ml
    "Thug no.2" "You motherfucker!!"
    $ renpy.music.play("audio/sfx/punch-140236.ogg", channel=u'sound', loop=False)
    scene ep3_Warehouse_A1_Night_Thugs_knife_T1_disarm with punch_weak
    pause 0.3
    X "Careful with that!"
    scene ep3_Warehouse_A1_Night_Thugs_knife_pickup with ml
    X "Didn't your parents teach you not to play with knives."
    X "I'll be keeping this."
    scene ep3_Warehous_office_outside with ml
    Jerold "...and here you are, all clean!"
    "I recognize that voice."
    scene ep3_Warehouse_Office_Jerold_entrance with ml
    pause 0.25
    Jerold "Feel free to count it."
    "???" "Your father assured me, there is no need."
    Jerold "Now we can also help with picking some real est--"
    X "Hey [Jerold]!"
    scene ep3_Warehouse_Office_Jerold_approach with ml
    X "Heard you got some girls."
    X "See, I'd like a young blonde with deep blue eyes."
    scene ep3_Warehouse_Office_A1_POV_Desk_Listen with ml
    X "You picked up one like that recently?"
    "???" "Hey!"
    scene ep3_Warehouse_Office_A1_POV_Desk_Talk_Sergio with ml
    "???" "Are you high or something?"
    "???" "We're in the middle of a meeting here!"
    scene ep3_Warehouse_Office_A1_POV_Desk_Listen_Sergio
    X "You can finish the meeting in the emergency ward or be quiet!"
    X "Your choice."
    Jerold "It's OK [Sergio]."
    scene ep3_Warehouse_Office_A1_POV_Desk_Talk with ml
    Jerold "Looks like there's a missunderstanding here."
    Jerold "I don't know what girls you're talking about [X]."
    scene ep3_Warehouse_Office_A1_POV_Desk_Listen
    X "Just one really, your boys took her earlier."
    X "You know that was my dad?"
    pause 0.5
    scene ep3_Warehouse_Office_A1_POV_Desk_Talk_Handsup
    Jerold "What?! She's your dad?!"
    Jerold "I-I had no idea!"
    X "Tell me where she is!"
    X "Or do you need some convincing?"
    Jerold "Easy, we don't need to go there."
    scene ep3_Warehouse_Office_A1_POV_Desk_Talk with ml
    Jerold "She's at a motel outside of town."
    Jerold "My guys are waiting for this guy to come 'rescue' her."
    scene ep3_Warehouse_Office_A1_POV_Desk_Listen
    X "'Rescue' her?"
    scene ep3_Warehouse_Office_A1_POV_Desk_Talk
    Jerold "They're supposed to pretend that they're fighting, and he comes in and takes her away."
    scene ep3_Warehouse_Office_A1_POV_Desk_Listen
    X "And this guy, who is he, what does he look like?"
    scene ep3_Warehouse_Office_A1_POV_Desk_Talk
    Jerold "No idea, my old man dealt with him."
    Jerold "That's pretty much all I know."
    scene ep3_Warehouse_Office_A1_POV_Desk_Listen
    X "Don't lie to me [Jerold]!"
    scene ep3_Warehouse_Office_A1_POV_Desk_Talk_Handsup
    Jerold "I swear, that's everything!"
    "This spineless turd is probably in the dark about most of this."
    scene ep3_Warehouse_Office_A1_POV_Desk_Listen with ml
    X "It better be!"
    scene ep3_Warehouse_Office_A1_POV_Desk_Listen_Sergio with ml
    X "Carry on."
    Sergio "Hmpf!"
    scene ep3_Warehouse_Office_Door_Leave with ml
    X "You know what will happen if I have to come back."
    Jerold "I know!"
    scene ep1_000_black with fade
    pause 2.0
    scene ep3_Motel_Outsid_Arrive with dissolve
    "That's the van."
    $ renpy.music.play("audio/sfx/pounding-on-door-44023.ogg", channel=u'sound', loop=False)
    scene ep3_Motel_Room_Door_Knock with ml
    pause 0.4
    "It's dark, maybe they won't recognize me."
    "Then I can play along with whatever they're doing here."
    scene ep3_Motel_Room_thugs_POV_Door_T1_answer with ml
    "Thug the 1st" "You're early!"
    scene ep3_Motel_Room_thugs_POV_Door_MC_talk
    X "Yeah?"
    X "You want me to wait, or are we getting this over with?"
    "Thug the 1st" "Guess not."
    scene ep3_Motel_Room_thugs_POV_Door_T1_answer_2
    "Thug the 1st" "Hey wake up, we got shit to do!"
    scene ep3_Motel_Room_thugs_POV_T1_room_talk with ml
    X "Is she here?"
    scene ep3_Motel_Room_thugs_POV_T1_room_listen
    "Thug the 1st" "In the bathroom."
    "Thug the 2nd" "Man, what a piece!"
    scene ep3_Motel_Room_thugs_POV_T2_room_ltalk with ml
    "Thug the 2nd" "That's a prime cut right there!"
    scene ep3_Motel_Room_thugs_POV_T2_room_listen
    "Thug the 2nd" "I'm talking real wagyu shit."
    "Thug the 2nd" "With those thighs and that rack, she's fine as hell!"
    scene ep3_Motel_Room_thugs_POV_T2_room_ltalk
    X "I'm going to assume you're just talking about some cow you want to fuck."
    X "Just so I won't bash your head in for real."
    scene ep3_Motel_Room_thugs_POV_T1_room_listen with ml
    "Thug the 1st" "Ignore him, he's had too much to drink!"
    scene ep3_Motel_Room_thugs_POV_T1_room_talk
    X "Yeah whatever. Let's get this moving!"
    scene ep3_Motel_Room_thugs_POV_T1_room_listen
    "Thug the 1st" "Yeah sure."
    scene ep3_Motel_Room_thugs_fight_POV_T1_feign_1 with ml
    "Thug the 1st" "Hey who the fuck are you??"
    "Thug the 2nd" "He's looking for a fight!"
    scene ep3_Motel_Room_thugs_fight_POV_T2_feign_1 with ml
    "Thug the 2nd" "Take this!"
    "Thug the 2nd" "Ow! Fuck, that hurt!"
    "Thug the 1st" "You're dead!"
    scene ep3_Motel_Room_thugs_fight_POV_T1_feign_1 with ml
    "Thug the 1st" "Shit! My face!"
    "Now's my chance!"
    "Thug the 1st" "How about th--"
    X "Aaaaand..."
    $ renpy.music.play("audio/sfx/punch-140236.ogg", channel=u'sound', loop=False)
    scene ep3_Motel_Room_thugs_fight_FREE_T1_punch with punch_nrml
    pause 0.5
    "Thug the 2nd" "What the fuck!?"
    scene ep3_Motel_Room_thugs_fight_FREE_T2_surprise with ml
    "Thug the 2nd" "You son of a bitch!"
    $ renpy.music.play("audio/sfx/table-smash-47690.ogg", channel=u'sound', loop=False)
    scene ep3_Motel_Room_thugs_POV_T2_room_smash_head with punch_weak
    X "...cut!"
    $ renpy.music.stop(channel=u'music', fadeout=1.0)
    scene ep3_Motel_POV_BathRoom_Entrance with dissolve
    X "[D]?"
    scene ep3_Motel_Bathroom_Door_open with ml
    X "Are you there?"
    $ renpy.music.play("audio/music/you-are-always-with-me-piano-version-15841.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Motel_D_Tied_Bathroom_door with ml
    X "[D]!"
    scene ep3_Motel_Bathroom_A1_POV_Tape_hand with dissolve
    X "Bear with it, this will hurt a little!"
    $ renpy.music.play("audio/sfx/tape_01-93499.ogg", channel=u'sound', loop=False)
    scene ep3_Motel_Bathroom_A1_POV_Tape_Off
    D "Ouch!"
    scene ep3_Motel_Bathroom_A1_POV_Rope_Cut with ml
    X "Stand still till I get this off!"
    scene ep3_Motel_Bathroom_A1_FREE_D_Hug_Back with ml
    D "dad! You came!"
    D "I was so scared!"
    scene ep3_Motel_Bathroom_A1_POV_D_Hug with ml
    X "Of course I did!"
    scene ep3_Motel_Bathroom_A1_FREE_D_Hug_Back with ml
    X "I'd never let them take you!"
    X "Are you hurt?"
    scene ep3_Motel_Bathroom_A1_FREE_D_Hug with ml
    D "No, but my legs are numb."
    scene ep3_Motel_Bathroom_A1_FREE_D_Carry with ml
    X "Hold on to me."
    scene ep3_Motel_Bathroom_A1_POV_D_Carry with ml
    D "Are those men gone?"
    X "You don't need to worry about them."
    X "Let's get to the car."
    scene ep3_Motel_Outside_D_Car_POV_Car_D_Listen with fade
    X "Did any of them touch your privates or anything?"
    scene ep3_Motel_Outside_D_Car_POV_Car_D_Talk
    D "No, they just shouted a lot."
    "Guess I won't break their legs then."
    D "Can we go home?"
    scene ep3_Motel_Outside_D_Car_POV_Car_D_Listen
    X "Listen [D], I need to take care of something first."
    X "I'll need you to wait in the car here and be quiet till I come back."
    scene ep3_Motel_Outside_D_Car_POV_Car_D_Talk
    D "I understand."
    scene ep3_Motel_Outside_D_Car_POV_Car_D_Listen
    X "Good girl!"
    X "I'll be back, promise!"
    $ renpy.music.stop(channel=u'music', fadeout=3.0)
    scene ep3_Motel_MC_phone_Call with fade
    pause 0.2
    "Better tell [Charlie] about all this."
    pause 0.5
    Charlie "[X]?"
    Charlie "What is it, something happen?"
    X "They took [D], but I got her back."
    Charlie "What, who took her?"
    X "There's a guy who's after her, you were right about that."
    X "I'll give you the location."
    X "If anything goes wrong, I need you to take care of [D]."
    Charlie "I'm on my way, but you need to give me more info here!"
    X "Sure..."
    scene ep1_000_black with fade
    pause 1.0
    scene ep3_Motel_Thugs_Coal_wear with dissolve
    "If he's been following her, chances are he knows me."
    "And he could get suspicious if I'm dressed like this."
    scene ep3_Motel_MC_Glasses_Find with dissolve
    "Nice, these'll come in handy."
    $ renpy.music.play("audio/sfx/door-knock-open-wooden_distant-75899.ogg", channel=u'sound', loop=False)
    pause 0.6
    scene ep3_Motel_POV_Room_Entrance with ml
    "That might be the guy."
    $ renpy.music.stop(channel=u'sound', fadeout=None)
    scene ep3_Motel_Door_John_answer with ml
    X "Yeah?"
    "???" "Open up, it's me."
    $ renpy.music.play("audio/music/free-night-134023.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Motel_POV_John_Talk with ml
    "???" "Since you are here, I assume you have her."
    scene ep3_Motel_POV_John_Listen
    X "Yeah yeah, she' right here."
    scene ep3_Motel_POV_John_Talk_Point
    "???" "There were supposed to be two of you."
    "???" "Where's the other one?"
    scene ep3_Motel_POV_John_Listen
    X "Oh he went out, had to take a dump."
    scene ep3_Motel_POV_John_Talk
    "???" "The bathroom is out of service or something?"
    scene ep3_Motel_POV_John_Listen
    X "Well the girl's in there."
    X "And you wanted her alive right?"
    scene ep3_Motel_POV_John_Talk
    "???" "Is she hurt in any way?"
    scene ep3_Motel_POV_John_Listen
    X "Nah, just mantally maybe."
    scene ep3_Motel_POV_John_Talk
    "???" "That's good, for your sake."
    "???" "Now you know what to do."
    "Oh I certainly do."
    scene ep3_Motel_POV_BathRoom_Entrance with ml
    X "Yo what are you doing here?!"
    X "Take this!"
    X "Owww! My face!"
    X "Ugh! No please, she's right there!"
    X "I give up!"
    "???" "Ok that's enough, now just lay down and play dead."
    scene ep3_Motel_Room_John_intro_FREE_John_Bathroom_Open with ml
    "???" "[Adalinda]?"
    John "It's [John], your father sent me!"
    scene ep3_Motel_Room_John_intro_POV_John_Bathroom_Open with ml
    John "Wait... where is she?"
    X "Oh wait! She's..."
    $ renpy.music.play("audio/sfx/doorhit-98828.ogg", channel=u'sound', loop=False)
    scene ep3_Motel_Room_John_intro_FREE_John_Bathroom_Smash with punch_weak
    pause 0.3
    X "Right..."
    $ renpy.music.play("audio/sfx/punch-140236.ogg", channel=u'sound', loop=False)
    scene ep3_Motel_Room_John_intro_POV_John_Bathroom_Punch with punch_nrml
    pause 0.3
    X "Here!"
    scene ep1_000_black with fade
    pause 1.0
    scene ep3_Motel_Room_John_Tied_POV_John_Knocked_out with fade
    "Let's see what I can get out of him before [Charlie] gets here."
    scene ep3_Motel_Room_John_Tied_FREE_John_Foot_Press with ml
    X "Wakey wakey!"
    scene ep3_Motel_Room_John_Tied_FREE_John_Pain
    John "AAAH!!"
    scene ep3_Motel_Room_John_Tied_POV_John_Wake_Up with ml
    John "What in the fuck do you think you're doing?!"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "Where's the girl?"
    X "Oh she's fine."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "But right now..."
    scene ep3_Motel_Room_John_Tied_POV_John_Glasses_takeoff with ml
    X "Your main concern should be about yourself."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen with ml
    pause 1.0
    scene ep3_Motel_Room_John_Tied_POV_John_Surpised
    John "You!!"
    John "How did you--"
    $ renpy.music.play("audio/sfx/punch-2-37333.ogg", channel=u'sound', loop=False)
    scene ep3_Motel_Room_John_Tied_FREE_John_Punch with punch_weak
    X "Shut it!"
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "I'm asking the questions!"
    "Now how should I approach this?"
    X "First, who do you work for?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "I think you've figured that out already."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "You need me to punch you again?"
    scene ep3_Motel_Room_John_Tied_POV_John_Wake_Up
    John "[Radford], he tasked me to get his dad back."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "Is anyone else after her?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "Not that I know of."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "How long have you been working for him?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "A couple of decades maybe."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "And what about this little act you had those idiots play?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "Deterrence, better than have her get in actual trouble."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "And make her too scared to run away again."
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "That was the idea."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "Nice plan, just one problem."
    X "She's actually my dad."
    pause 0.5
    scene ep3_Motel_Room_John_Tied_POV_John_Wake_Up
    John "What are you talking about?"
    "Seems like he doesn't know about [Emily]'s journal."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "Her mother, the girl they adopted. You know about her?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "What was her name... [Emily]."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "That's right. Where is she now?"
    pause 2.0
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "She... died."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    pause 1.0
    X "What?! When?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "It's been over ten years."
    John "She had an accident, fell down the stairs."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "I don't believe you!"
    scene ep3_Motel_Room_John_Tied_POV_John_Wake_Up
    John "I only know what [Radford] told me."
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "Said she tried to run away with her dad."
    John "They struggled and she fell, and when the ambulance came it was too late."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "Is that so?"
    X "He wouldn't trust you to come get her back if you weren't neck deep in this."
    scene ep3_Motel_Room_John_Tied_POV_John_Surpised
    John "Look, this is just business."
    John "We started working when he called me to private his family's history."
    X "Why?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "Afer they found out [Emily] was pregnant, they wanted to avoid a scandal."
    John "[Radford] told me it was his child, so I don't know why you think she's your dad."
    "Now I really need to get that journal."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "I just do."
    X "And why did she try to run away?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "He claimed she had mental issues."
    X "That's bullshit!"
    X "And you just fucking believe that?"
    scene ep3_Motel_Room_John_Tied_POV_John_Wake_Up
    John "I was paid for my discretion, so I didn't press the issue."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "I get the sense you're no telling me something."
    scene ep3_Motel_Room_John_Tied_POV_John_Surpised
    John "Hey look, everything's on the record!"
    John "Just look it up after that detective declassifies it."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    X "How do you know about that?"
    scene ep3_Motel_Room_John_Tied_POV_John_Talk
    John "That I can't answer."
    X "You sure about that?"
    John "Beat me all you want, but it won't do anything."
    scene ep3_Motel_Room_John_Tied_POV_John_Listen
    "Maybe he has someone on the inside, or some hacker maybe."
    X "Lucky you, I don't have time for that."


    scene ep3_Motel_MC_phone_Call with fade
    pause 0.2
    Charlie "I'm near the place. Where are you?"
    X "In the motel, meet you out front."
    scene ep1_000_black with fade
    pause 0.5
    scene ep3_Motel_Outside_Charlie_Car_FREE_Charlie_Car_Enter_Motel with fade
    X "I see you."
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Car_Arrive with dissolve
    Charlie "What are you wearing?"
    X "I needed a disguise."
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Approach with ml
    Charlie "Take me through what happened?"
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Listen with ml
    X "We just got out of the cinema after a movie."
    X "I turned my back and they just snatched her..."
    scene ep1_000_black with fade
    pause 0.5
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Talk with ml
    Charlie "How did you know where to find [Jerold]?"
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Listen
    X "Heard rumors on the street last week."
    "Don't need to involve [Khalil] in this one."
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Talk_Look_Away
    Charlie "Well I'll need to take them in."
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Talk_Point
    Charlie "And there could be others coming for [D]."
    X "Yeah."
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Talk
    Charlie "And since he knows about you, it's not safe to go back home."
    Charlie "You can come to my place."
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Listen
    X "He also knew about you, so they might also try there."
    X "I'll find a hotel, it's the best option."
    scene ep3_Motel_Outside_Charlie_Car_POV_Charlie_Talk
    Charlie "That's good, go get a room and we'll meet there."

    scene ep1_000_black with fade
    pause 1.2
    $ renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Hotel_Enter_D with fade
    X "...so we'll be staying here for a bit."
    X "Go rest for now."
    "It only has one bed?"
    "And what's with the bathroom here?"
    scene ep3_Hotel_Desk_MC_Phone with ml
    "Reception" "This is the front desk. How may I help you?"
    X "Do you have any other rooms, maybe with two beds?"
    "Reception" "We're sorry sir, but all rooms are fully booked for tonight."
    "Damn, already told [Charlie] about the place."
    "Just have to get by for tonight."
    X "Right, I see, we'll be fine here then."
    "Reception" "I apologize again sir. Would you like anything else?"
    X "That's OK."
    D "**Sniff**"
    $ renpy.music.play("audio/music/sentimental-guitar-and-piano-164254.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Hotel_D_Room_A2_POV_D_Crying_Approach with fade
    X "[D], what's the matter?"
    X "Are you in pain?"
    D "No..."
    scene ep3_Hotel_D_Room_A2_FREE_D_Crying with ml
    D "This all happened because of me."
    scene ep3_Hotel_D_Room_A2_POV_D_Crying_Talk with ml
    D "If I hadn't ran away..."
    scene ep3_Hotel_D_Room_A2_POV_D_Crying_Listen
    X "Don't say that!"
    X "You can't blame yourself for what they did!"
    scene ep3_Hotel_D_Room_A2_POV_D_Crying_Talk
    D "But you had to fight those mean people."
    D "You could've been hurt badly, all because of me."
    scene ep3_Hotel_D_Room_A2_POV_D_Crying_Listen
    X "Look [D]..."
    scene ep3_Hotel_D_Room_A2_POV_D_Crying_Tear_Wipe_1 with ml
    X "It's true that I might get a few bruises."
    X "But that's never going to stop me from protecting you."
    scene ep3_Hotel_D_Room_A2_FREE_D_Crying_Tear_Wipe_2 with ml
    X "No matter what happens, I won't give up on you!"
    scene ep3_Hotel_D_Room_A2_FREE_D_Hug_MC with ml
    D "I just don't want to see you hurt daddy!"
    X "Hey don't worry about that."
    scene ep3_Hotel_D_Room_A2_POV_D_Hug_MC_Listen with ml
    X "I'm tougher than I look, trust me!"
    X "Now go get ready for bed, it's really late."
    scene ep3_Hotel_D_Room_A2_POV_D_Hug_MC_Talk with ml
    D "Yes daddy."
    D "And I hope we find mom so we can all be together."
    X "Yeah, me too..."
    $ renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_bag with fade
    Charlie "I got you some supplies and a few clothes for [D]."
    X "Thanks."
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Listen with ml
    X "What will happened to that [John] guy?"
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Talk
    Charlie "I can detain him in relation to [Emily]'s case."
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Talk_Point
    Charlie "But we need to hold off on bringing you as [D]'s father."
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Talk
    Charlie "At least until we have some evidence for the court."
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Listen
    X "The paternity will get done soon."
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Talk
    Charlie "That, and whatever else we can bring."
    scene ep3_Hotel_Charlie_entrance_A1_FREE_Charlie_Listen with ml
    X "I'll see what I can do."
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Talk_Point with ml
    Charlie "Don't leave the hotel, hang tight for now."
    X "Sure."
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Talk
    Charlie "Also, that was a traumatic experience for [D]."
    Charlie "She needs all of your support now."
    scene ep3_Hotel_Charlie_entrance_A1_POV_Charlie_Listen
    X "I know."
    scene ep3_Hotel_Charlie_entrance_A1_FREE_Charlie_Leave with ml
    Charlie "And if you need anything, leave a message at the front desk, I'll come and check."
    X "Got it."
    X "And thank you!"
    scene ep3_Hotel_MC_Bed_Sitting with fade
    pause 1.0
    D "Ummm, dad?"
    scene ep3_Hotel_D_shower with ml
    X "Yes [D]!"
    D "I don't have any soap here, can you bring some?"
    scene ep3_Hotel_D_giving_Soap_A1 with fade
    X "Got some shampoo here too."
    D "Thanks."
    scene ep3_Hotel_D_shower_close with ml
    pause 0.5
    X "[Charlie] brought you some clothes, I'll leave them here."
    D "Okay."
    scene ep3_Hotel_MC_Bed_Sitting with fade
    pause 0.25
    "Those bastards aren't giving up easily."
    "It looks like I'm in for a fight."
    D "Are they here?"
    scene ep3_Hotel_D_shower_finish_puss with ml
    X "What?"
    D "Nevermind, found them!"
    scene ep3_Hotel_MC_Bed_Sitting with dissolve
    "Man, what did they design this room for?"
    D "I'm ready."
    scene ep3_Hotel_D_bed_A1_POV_Bed_Side with ml
    X "How's the temperature?"
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Talk with ml
    D "I feel warm."
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Listen
    X "Well we got some blankets here, throw one on if it gets chilly."
    X "Now try to get some rest."
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Talk
    D "Will you sleep here with me?"
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Listen
    X "There is just this bed."
    X "But I can always make the floor work too."
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Talk
    D "No, please don't go!"
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Listen
    X "Oh well, if you insist."
    menu:
        "Kiss her cheek":
            $ ep3_d_kiss = "cheek"
            scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Cheek with ml
            X "Goodnight [D]."
            D "Goodnight daddy."
        "Kiss her forehead":
            $ ep3_d_kiss = "forehead"
            scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Forehead with ml
            X "Goodnight [D]."
            D "Goodnight daddy."
    $ renpy.music.stop(channel=u'music', fadeout=3.0)
    scene ep1_000_black with eye_close
    pause 1.5
    D "Mmmm..."
    scene ep3_Hotel_D_Sleep_NIght_A1 with eye_open
    X "[D], are you--"
    X "Wait, what's this sensation?"
    $ renpy.music.play("audio/music/sentimental-piano-162200.ogg", channel=u'music', loop=True, fadein=3)






$ load_rate = 0.04
$ load_rate_level = 2
$ fanum = 0
init python:
    def ep3_Hotel_D_bed_sleep_A1_POV_ANIM(load, a, b):
        load.set_child("ep3_Hotel_D_bed_sleep_A1_POV_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 10 and store.load_rate_level == 4:
            store.load_rate = 0.0169
            store.load_rate *=2
        if store.fanum == 19 and load_rate_level == 4:
            store.load_rate /=2
        if store.fanum > 29:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value

init python:
    def ep3_Hotel_D_bed_sleep_A1_pussy_ANIM(load, a, b):
        load.set_child("ep3_Hotel_D_bed_sleep_A1_pussy_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 10 and store.load_rate_level == 4:
            store.load_rate = 0.0169
            store.load_rate *=2
        if store.fanum == 19 and load_rate_level == 4:
            store.load_rate /=2
        if store.fanum > 29:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value


init python:
    def ep3_Hotel_D_bed_sleep_A1_butt_ANIM(load, a, b):
        load.set_child("ep3_Hotel_D_bed_sleep_A1_butt_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 10 and store.load_rate_level == 4:
            store.load_rate = 0.0169
            store.load_rate *=2
        if store.fanum == 19 and load_rate_level == 4:
            store.load_rate /=2
        if store.fanum > 29:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value


image ep3_Hotel_D_bed_sleep_A1_POV_ANIM:
    function ep3_Hotel_D_bed_sleep_A1_POV_ANIM
image ep3_Hotel_D_bed_sleep_A1_pussy_ANIM:
    function ep3_Hotel_D_bed_sleep_A1_pussy_ANIM
image ep3_Hotel_D_bed_sleep_A1_butt_ANIM:
    function ep3_Hotel_D_bed_sleep_A1_butt_ANIM
$ fanum = 0

screen SHOW_ep3_Hotel_D_bed_sleep_A1_POV_ANIM():
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Hold Still" action SetVariable("load_rate", 0.0666),SetVariable("load_rate_level", 1) style "screen_button"
        textbutton "Move a little" action SetVariable("load_rate", 0.04),SetVariable("load_rate_level", 2) style "screen_button"
        textbutton "Shift Position" action SetVariable("load_rate", 0.025),SetVariable("load_rate_level", 3) style "screen_button"
        textbutton "Try pulling back" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" style "screen_button"
        textbutton "KITTY" action Jump("SHOW_ep3_Hotel_D_bed_sleep_A1_pussy_ANIM") style "screen_button"
        textbutton "BUTT" action Jump("SHOW_ep3_Hotel_D_bed_sleep_A1_butt_ANIM") style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "END" action Jump("continue_after_animation_3") style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface() style "screen_button"

screen SHOW_ep3_Hotel_D_bed_sleep_A1_pussy_ANIM():
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Hold Still" action SetVariable("load_rate", 0.0666),SetVariable("load_rate_level", 1) style "screen_button"
        textbutton "Move a little" action SetVariable("load_rate", 0.04),SetVariable("load_rate_level", 2) style "screen_button"
        textbutton "Shift Position" action SetVariable("load_rate", 0.025),SetVariable("load_rate_level", 3) style "screen_button"
        textbutton "Try pulling back" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" action Jump("SHOW_ep3_Hotel_D_bed_sleep_A1_POV_ANIM") style "screen_button"
        textbutton "KITTY" style "screen_button"
        textbutton "BUTT" action Jump("SHOW_ep3_Hotel_D_bed_sleep_A1_butt_ANIM") style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "END" action Jump("continue_after_animation_3") style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface() style "screen_button"

screen SHOW_ep3_Hotel_D_bed_sleep_A1_butt_ANIM():
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Hold Still" action SetVariable("load_rate", 0.0666),SetVariable("load_rate_level", 1) style "screen_button"
        textbutton "Move a little" action SetVariable("load_rate", 0.04),SetVariable("load_rate_level", 2) style "screen_button"
        textbutton "Shift Position" action SetVariable("load_rate", 0.025),SetVariable("load_rate_level", 3) style "screen_button"
        textbutton "Try pulling back" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4) style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" action Jump("SHOW_ep3_Hotel_D_bed_sleep_A1_POV_ANIM") style "screen_button"
        textbutton "KITTY" action Jump("SHOW_ep3_Hotel_D_bed_sleep_A1_pussy_ANIM") style "screen_button"
        textbutton "BUTT" style "screen_button"

    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "END" action Jump("continue_after_animation_3") style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface() style "screen_button"


label ep3_hotel_grind_intro:
    scene ep3_Hotel_D_bed_sleep_A1_POV_ANIM_15 with dissolve
    X "Huh?!"
    "Shit, am I dreaming?"
    "Even if it's a dream, I should stop this."
    "What to do..."
    menu:
        "Stay still":
            $ D_p += 1
            $ ep3_d_grind = "still"
            "I won't risk waking her up and seeing this."
            "I'll try to slowly get--"
            $ fanum = 15
            $ load_rate = 0.0666
            $ load_rate_level = 1
            scene ep3_Hotel_D_bed_sleep_A1_POV_ANIM with ml
            pause 1
            X "Oh!"
            "This isn't good!"
            "Gotta do something about this."
        "Quicky turn around":
            $ ep3_d_grind = "turn"
            jump ep3_turn_around

label SHOW_ep3_Hotel_D_bed_sleep_A1_POV_ANIM:
    scene ep3_Hotel_D_bed_sleep_A1_POV_ANIM with ml
    call screen SHOW_ep3_Hotel_D_bed_sleep_A1_POV_ANIM
label SHOW_ep3_Hotel_D_bed_sleep_A1_pussy_ANIM:
    scene ep3_Hotel_D_bed_sleep_A1_pussy_ANIM with ml
    call screen SHOW_ep3_Hotel_D_bed_sleep_A1_pussy_ANIM
label SHOW_ep3_Hotel_D_bed_sleep_A1_butt_ANIM:
    scene ep3_Hotel_D_bed_sleep_A1_butt_ANIM with ml
    call screen SHOW_ep3_Hotel_D_bed_sleep_A1_butt_ANIM


label continue_after_animation_3:
    $ load_rate = 0.0169
    $ load_rate_level = 4
    scene ep3_Hotel_D_bed_sleep_A1_pussy_ANIM with ml
    "Shit, I can't stop it!"
    "I have to--"
    scene ep3_Hotel_D_Sleep_Ejaculate
    pause 1
    X "Ugghh!"
    scene ep3_Hotel_D_Sleep_Cum_after with fade
    pause 1.5
    "What have I done..."
    jump ep3_conclusion

label ep3_turn_around:
    scene ep3_Hotel_Night_Bed_Look_Window with ml
    "That was close."
    "I could've made a mistake there..."

label ep3_conclusion:
    $ D_p_t += 1

scene ep1_000_black with curtains_slow_r




menu:
    "Continue":
        jump ep4_bed_wake
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
