
screen Episode5_D_Altar_animations():

    tag ss_anim_screen
    timer 0.0001 action [
        SetVariable("anim_episode",5),
        SetVariable("anim_name", "episode5_D_Altar_anim_Full"),
        SetVariable("anim_frame", 0),
        SetVariable("anim_t", 0.0),
        SetVariable("anim_speed_base", 0.05),
        SetVariable("anim_curve", "linear"),
    ]
    frame:
        xalign 0.5
        yalign 0.5
        add DynamicDisplayable(animation_player)

    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5

        textbutton "Slow":
            action [
                SetVariable("anim_speed_base", 0.05),
                SetVariable("anim_curve", "linear"),
            ]   style "screen_button"
        textbutton "Push":
            action [
                SetVariable("anim_speed_base", 0.045),
                SetVariable("anim_curve", "ease_out"),
            ]  style "screen_button"
        textbutton "Fast": 
            action [
                SetVariable("anim_speed_base", 0.043),
                SetVariable("anim_curve", "ease_in"),
            ]  style "screen_button"


    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5

        textbutton "Close-up":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_D_Altar_anim_Close"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
                #Show("episode5_D_Altar_anim_Close")
            ]  style "screen_button"

        textbutton "3rd person":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_D_Altar_anim_Full"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "Face":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_D_Altar_anim_POVf"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "Pussy":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_D_Altar_anim_POVp"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Return()  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"


screen Episode5_Eileen_BJ_animations():

    tag ss_anim_screen
    timer 0.0001 action [
        SetVariable("anim_episode",5),
        SetVariable("anim_name", "episode5_Eileen_BJ_anim_POV"),
        #SetVariable("anim_frame", 0),
        #SetVariable("anim_t", 0.0),
        #SetVariable("anim_speed_base", 0.045),
        #SetVariable("anim_curve", "linear"),
    ]
    frame:
        xalign 0.5
        yalign 0.5
        add DynamicDisplayable(animation_player)

    vbox:
        yalign 0.85
        xalign 0.01
        spacing -5

        textbutton "Slow":
            action [
                SetVariable("anim_speed_base", 0.045),
                SetVariable("anim_curve", "linear"),
            ]   style "screen_button"
        textbutton "Push":
            action [
                SetVariable("anim_speed_base", 0.03),
                SetVariable("anim_curve", "linear"),
            ]  style "screen_button"
        textbutton "Fast": 
            action [
                SetVariable("anim_speed_base", 0.032),
                SetVariable("anim_curve", "ease_in"),
            ]  style "screen_button"
        textbutton "Deep":
            action [
                SetVariable("anim_speed_base", 0.04),
                SetVariable("anim_curve", "ease_stop"),
            ]   style "screen_button"


    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5

        textbutton "Close-up":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_BJ_anim_Close"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

        textbutton "Right":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_BJ_anim_Right"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "Left":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_BJ_anim_Left"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "POV":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_BJ_anim_POV"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

    vbox:
            yalign 0.57
            xalign 0.01
            spacing 5
            textbutton "BJ" style  "screen_button"
            textbutton "Ride" action Show("Episode5_Eileen_Ride_animations")  style "screen_button"
            textbutton "Missionary" action Show("Episode5_Eileen_Missionary_animations")  style "screen_button"


    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Return()  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"

screen Episode5_Eileen_Ride_animations():

    tag ss_anim_screen
    timer 0.0001 action [
        SetVariable("anim_episode",5),
        SetVariable("anim_name", "episode5_Eileen_Ride_anim_POV"),
        #SetVariable("anim_frame", 0),
        #SetVariable("anim_t", 0.0),
        #SetVariable("anim_speed_base", 0.045),
        #SetVariable("anim_curve", "linear"),
    ]
    frame:
        xalign 0.5
        yalign 0.5
        add DynamicDisplayable(animation_player)

    vbox:
        yalign 0.85
        xalign 0.01
        spacing -5

        textbutton "Slow":
            action [
                SetVariable("anim_speed_base", 0.045),
                SetVariable("anim_curve", "linear"),
            ]   style "screen_button"
        textbutton "Push":
            action [
                SetVariable("anim_speed_base", 0.03),
                SetVariable("anim_curve", "linear"),
            ]  style "screen_button"

        textbutton "Bounce":
            action [
                SetVariable("anim_speed_base", 0.022),
                SetVariable("anim_curve", "ease_stop_2"),
            ]   style "screen_button"


    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5

        textbutton "Close-up":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_Ride_anim_Close"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

        textbutton "Side":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_Ride_anim_Side"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "Front":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_Ride_anim_Front"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "POV":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_Ride_anim_POV"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

    vbox:
            yalign 0.57
            xalign 0.01
            spacing 5
            textbutton "BJ" action Show("Episode5_Eileen_BJ_animations")  style "screen_button"
            textbutton "Ride" style  "screen_button"
            textbutton "Missionary" action Show("Episode5_Eileen_Missionary_animations")  style "screen_button"


    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Return()  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"

screen Episode5_Eileen_Missionary_animations():

    tag ss_anim_screen
    timer 0.0001 action [
        SetVariable("anim_episode",5),
        SetVariable("anim_name", "episode5_Eileen_Missionary_anim_POVp"),
        #SetVariable("anim_frame", 0),
        #SetVariable("anim_t", 0.0),
        #SetVariable("anim_speed_base", 0.045),
        #SetVariable("anim_curve", "linear"),
    ]
    frame:
        xalign 0.5
        yalign 0.5
        add DynamicDisplayable(animation_player)

    vbox:
        yalign 0.85
        xalign 0.01
        spacing -5

        textbutton "Slow":
            action [
                SetVariable("anim_speed_base", 0.045),
                SetVariable("anim_curve", "linear"),
            ]   style "screen_button"
        textbutton "Push":
            action [
                SetVariable("anim_speed_base", 0.03),
                SetVariable("anim_curve", "linear"),
            ]  style "screen_button"

        textbutton "Pound":
            action [
                SetVariable("anim_speed_base", 0.01),
                SetVariable("anim_curve", "ease_stop_2"),
            ]   style "screen_button"


    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5

        textbutton "Close-up":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_Missionary_anim_Close"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

        textbutton "Full":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_Missionary_anim_Full"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "Action":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_Missionary_anim_POVp"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "Face":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Eileen_Missionary_anim_POVf"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

    vbox:
            yalign 0.57
            xalign 0.01
            spacing 5
            textbutton "BJ" action Show("Episode5_Eileen_BJ_animations")  style "screen_button"
            textbutton "Ride" action Show("Episode5_Eileen_Ride_animations")  style "screen_button"
            textbutton "Missionary" style  "screen_button"


    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Return()  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"


screen Episode5_Alecia_FAP_animations():

    tag ss_anim_screen
    timer 0.0001 action [
        SetVariable("anim_episode",5),
        SetVariable("anim_name", "episode5_Alecia_FAP_anim_POV"),
        #SetVariable("anim_frame", 0),
        #SetVariable("anim_t", 0.0),
        #SetVariable("anim_speed_base", 0.045),
        #SetVariable("anim_curve", "linear"),
    ]
    frame:
        xalign 0.5
        yalign 0.5
        add DynamicDisplayable(animation_player)

    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5

        textbutton "Slow":
            action [
                SetVariable("anim_speed_base", 0.058),
                SetVariable("anim_curve", "linear"),
            ]   style "screen_button"
        textbutton "Push":
            action [
                SetVariable("anim_speed_base", 0.05),
                SetVariable("anim_curve", "linear"),
            ]  style "screen_button"
        textbutton "Fast": 
            action [
                SetVariable("anim_speed_base", 0.03),
                SetVariable("anim_curve", "ease_slow"),
            ]  style "screen_button"


    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5

        textbutton "Close-up":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Alecia_FAP_anim_Close"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

        textbutton "Full":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Alecia_FAP_anim_Full"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "Side":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Alecia_FAP_anim_Side"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"
        textbutton "POV":
            action [
                SetVariable("anim_episode",5),
                SetVariable("anim_name", "episode5_Alecia_FAP_anim_POV"),
                #SetVariable("anim_frame", 0),
                #SetVariable("anim_t", 0.0),
            ]  style "screen_button"

    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Return()  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"





########## ALL ANIMATIONS ################
screen animation_screen():

    tag ss_anim_screen
    
    frame:
        xalign 0.5
        yalign 0.5
        add DynamicDisplayable(animation_player)

    # SPEED CONTROLS (PERSISTENT)
    #vbox:
    #    xalign 0.02
    #    yalign 0.2
    #    spacing 8
    #    text "Speed"
    #    textbutton "Slow" action SetVariable("anim_speed_base", 0.06)
    #    textbutton "Normal" action SetVariable("anim_speed_base", 0.03)
    #    textbutton "Fast" action SetVariable("anim_speed_base", 0.015)

    # CURVE CONTROLS (PERSISTENT)
    #vbox:
    #    xalign 0.02
    #    yalign 0.5
    #    spacing 8
    #    text "Acceleration"
    #    textbutton "Linear" action SetVariable("anim_curve", "linear")
    #    textbutton "Ease In" action SetVariable("anim_curve", "ease_in")
    #    textbutton "Ease Out" action SetVariable("anim_curve", "ease_out")
    #    textbutton "Ease In/Out" action SetVariable("anim_curve", "ease_in_out")

    # EPISODES
    vbox:
        xalign 0.85
        yalign 0.1
        spacing 2
        text "Episodes"
        for ep in ANIMATIONS.keys():
            textbutton "Episode [ep]":
                action [
                    SetVariable("anim_episode", ep),
                    SetVariable("anim_name", None),
                    SetVariable("anim_frame", 0),
                    SetVariable("anim_t", 0.0),
                ]

    # ANIMATIONS
    vbox:
        xalign -0.5
        yalign 0.3
        spacing 1
        text "{size=-20}Animations"
        if anim_episode in ANIMATIONS:
            for anim in ANIMATIONS[anim_episode].keys():
                textbutton "{size=5}[anim]":
                    action [
                        SetVariable("anim_name", anim),
                        SetVariable("anim_frame", 0),
                        SetVariable("anim_t", 0.0),
                    ]

    textbutton "Continue":
        xalign 0.5
        yalign 0.92
        action Return()


screen all_animations():

    tag ss_anim_screen

    frame:
        xalign 0.5
        yalign 0.5
        add DynamicDisplayable(animation_player)

    # SPEED (GLOBAL / PERSISTENT)
    vbox:
        xalign 0.02
        yalign 0.2
        spacing 8

        text "Speed"
        textbutton "Slow" action SetVariable("anim_speed_base", 0.06)
        textbutton "Normal" action SetVariable("anim_speed_base", 0.03)
        textbutton "Fast" action SetVariable("anim_speed_base", 0.015)

    # CURVE (GLOBAL / PERSISTENT)
    vbox:
        xalign 0.02
        yalign 0.5
        spacing 8

        text "Acceleration"
        textbutton "Linear" action SetVariable("anim_curve", "linear")
        textbutton "Ease In" action SetVariable("anim_curve", "ease_in")
        textbutton "Ease Out" action SetVariable("anim_curve", "ease_out")
        textbutton "Ease In/Out" action SetVariable("anim_curve", "ease_in_out")

    # EPISODES
    vbox:
        xalign 0.85
        yalign 0.2
        spacing 8

        text "Episodes"

        for ep in ANIMATIONS.keys():
            textbutton "Episode [ep]":
                action [
                    SetVariable("anim_episode", ep),
                    SetVariable("anim_frame", 0),
                    SetVariable("anim_t", 0.0),
                ]

    # ANIMATIONS (MANUALLY CURATED)
    vbox:
        xalign 0.85
        yalign 0.5
        spacing 8

        text "Animations"

        if anim_episode in ANIMATION_UI_LIST:
            for label, anim_key in ANIMATION_UI_LIST[anim_episode]:

                if anim_key in ANIMATIONS.get(anim_episode, {}):

                    textbutton label:
                        action [
                            SetVariable("anim_name", anim_key),
                            SetVariable("anim_frame", 0),
                            SetVariable("anim_t", 0.0),
                        ]
                else:
                    text "[label] (missing)" color "#888"
        else:
            text "No animations configured"

    # RESET TO METADATA DEFAULTS
    textbutton "Reset to Defaults":
        xalign 0.5
        yalign 0.82
        action [
            SetVariable("anim_speed_base",
                ANIMATIONS[anim_episode][anim_name]["default_speed"]),
            SetVariable("anim_curve",
                ANIMATIONS[anim_episode][anim_name]["default_curve"]),
        ]

    textbutton "Continue":
        xalign 0.5
        yalign 0.92
        action Return()


















########## ALL ANIMATIONS ################
screen animation_screen():

    tag ss_anim_screen

    frame:
        xalign 0.5
        yalign 0.5
        add DynamicDisplayable(animation_player)

    # SPEED CONTROLS (PERSISTENT)
    vbox:
        xalign 0.02
        yalign 0.2
        spacing 8
        text "Speed"
        textbutton "Slow" action SetVariable("anim_speed_base", 0.06)
        textbutton "Normal" action SetVariable("anim_speed_base", 0.03)
        textbutton "Fast" action SetVariable("anim_speed_base", 0.015)

    # CURVE CONTROLS (PERSISTENT)
    vbox:
        xalign 0.02
        yalign 0.5
        spacing 8
        text "Acceleration"
        textbutton "Linear" action SetVariable("anim_curve", "linear")
        textbutton "Ease In" action SetVariable("anim_curve", "ease_in")
        textbutton "Ease Out" action SetVariable("anim_curve", "ease_out")
        textbutton "Ease In/Out" action SetVariable("anim_curve", "ease_in_out")

    # EPISODES
    vbox:
        xalign 0.85
        yalign 0.2
        spacing 8
        text "Episodes"
        for ep in ANIMATIONS.keys():
            textbutton "Episode [ep]":
                action [
                    SetVariable("anim_episode", ep),
                    SetVariable("anim_name", None),
                    SetVariable("anim_frame", 0),
                    SetVariable("anim_t", 0.0),
                ]

    # ANIMATIONS
    vbox:
        xalign 0.85
        yalign 0.5
        spacing 8
        text "Animations"
        if anim_episode in ANIMATIONS:
            for anim in ANIMATIONS[anim_episode].keys():
                textbutton anim:
                    action [
                        SetVariable("anim_name", anim),
                        SetVariable("anim_frame", 0),
                        SetVariable("anim_t", 0.0),
                    ]

    textbutton "Continue":
        xalign 0.5
        yalign 0.92
        action Return()
