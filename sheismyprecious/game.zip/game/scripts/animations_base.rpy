init -100 python:
    ANIMATIONS = {}
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
