init -100 python:
    ANIMATIONS = {}

