default anim_episode = 5
default anim_name = None
default anim_frame = 0
default anim_t = 0.0

# User-persistent preferences
default anim_speed_base = 0.05
default anim_speed = 0.03
default anim_curve = "linear"

init python:

    def apply_curve(t, curve):

        if curve == "ease_stop":
            if t >= 0.2 and t < 0.34:
                return t*2
            elif t >= 0.34 and t <= 0.5:
                return t
            elif t > 0.5 and t <= 0.99:
                return t/10
            else:
                return t*3
        elif curve == "ease_stop_2":
            if t >= 0.77 and t < 0.81:
                return t*2
            elif t > 0.6 and t < 0.77:
                return t/3
            else:
                return t
        elif curve == "ease_slow":
            if t >= 0.0 and t < 0.29:
                return t*7
            elif t > 0.3 and t <= .9:
                return t*2.5
            elif t > .9 and t <= .95:
                return t*2
            else:
                return t/2
        elif curve == "ease_in":
            return t * t
        elif curve == "ease_out":
            return 1.0 - (1.0 - t) ** 2
        elif curve == "ease_in_out":
            if t < 0.5:
                return 2 * t * t
            else:
                return 1 - pow(-2 * t + 2, 2) / 2
        return 1.0

    def animation_player(st, at):
        global anim_frame, anim_t, anim_speed

        if anim_name is None:
            return Null(), 0.1

        anim_data = ANIMATIONS[anim_episode][anim_name]
        frame_count = anim_data["frames"]

        anim_t += 1.0 / frame_count
        if anim_t > 1.0:
            anim_t = 0.0

        curve_multiplier = apply_curve(anim_t, anim_curve)
        anim_speed = anim_speed_base * max(0.1, curve_multiplier)

        image_path = "animations/episode{}/{}/frame{}.jpg".format(
            anim_episode,
            anim_data["folder"],
            anim_frame
        )

        anim_frame = (anim_frame + 1) % frame_count

        return Image(image_path), anim_speed


init python:

    def VNAnimation(episode, anim_key):
        """
        Returns a DynamicDisplayable that plays an animation
        like a normal VN image.
        """

        def _player(st, at):
            global anim_frame, anim_t, anim_speed

            anim_data = ANIMATIONS[episode][anim_key]
            frame_count = anim_data["frames"]

            anim_t += 1.0 / frame_count
            if anim_t > 1.0:
                anim_t = 0.0

            curve_multiplier = apply_curve(anim_t, anim_curve)
            anim_speed = anim_speed_base * max(0.1, curve_multiplier)

            image_path = "animations/episode{}/{}/frame{}.jpg".format(
                episode,
                anim_data["folder"],
                anim_frame
            )

            anim_frame = (anim_frame + 1) % frame_count

            return Image(image_path), anim_speed

        return DynamicDisplayable(_player)
