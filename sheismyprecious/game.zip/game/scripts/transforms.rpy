transform mm_slide_fade:
    alpha 0.0
    linear 0.75 alpha 1.0

transform mm_slide_pan:
    alpha 0.0 xalign 0.45
    parallel:
        linear 0.75 alpha 1.0
    parallel:
        linear 6.0 xalign 0.55



transform mm_fade_in(t=0.75):
    alpha 0.0
    linear t alpha 1.0

transform mm_fade_out(t=0.75):
    alpha 1.0
    linear t alpha 0.0


screen main_menu_slideshow():
    add DynamicDisplayable(mm_slideshow)

init python:

    def mm_slideshow(st, at):
        slides = [
        "gui/mm_slide/0.jpg",
        "gui/mm_slide/1.jpg",
        "gui/mm_slide/2.jpg",
        "gui/mm_slide/3.jpg",
        "gui/mm_slide/4.jpg",
        "gui/mm_slide/5.jpg",
        "gui/mm_slide/6.jpg",
        "gui/mm_slide/7.jpg",
        "gui/mm_slide/8.jpg",
        "gui/mm_slide/9.jpg",
        "gui/mm_slide/10.jpg",
        "gui/mm_slide/11.jpg",
        "gui/mm_slide/12.jpg",
        "gui/mm_slide/13.jpg",
        "gui/mm_slide/14.jpg",
        "gui/mm_slide/15.jpg",
        "gui/mm_slide/16.jpg",
        "gui/mm_slide/17.jpg",
        "gui/mm_slide/18.jpg",
        "images/ep1/000_black.png"
    ]


        slide_time = 9
        fade_time = 4

        cycle = slide_time
        count = len(slides)

        # Determine current and previous slide
        index = int(st // cycle) % count
        prev_index = (index - 1) % count

        t = st % cycle

        # Always show the current slide
        current = slides[index]

        if t < fade_time:
            # Crossfade from previous -> current
            prev = Transform(
                slides[prev_index],
                alpha=1.0 - (t / fade_time)
            )
            curr = Transform(
                current,
                alpha=(t / fade_time)
            )
            return Fixed(prev, curr), 0
        else:
            return current, 0







