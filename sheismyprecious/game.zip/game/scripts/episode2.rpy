label ep2_01_bedroom:
    hide screen episode_end
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    $renpy.music.stop(channel=u'ambience', fadeout=None)
    $renpy.music.stop(channel=u'sound', fadeout=None)
    scene ep1_000_black with dissolve
    pause 0.5
    show screen episode_title("Episode 2","Rise to the Occasion")
    pause 5.5
    hide screen episode_title
    scene ep2_000_Belt_Undo_Talk_D_legs with rightleft
    $renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)
    X "Does it hurt?"
    scene ep2_002_Belt_Undo_Talk_D_talk_away with ml
    D "Not really, it's just uncomfortable."
    scene ep2_004_Belt_Undo_Talk_D_listen_MC
    X "How long have you had it on?"
    scene ep2_001_Belt_Undo_Talk_D_talk_MC
    D "I had to put it on before going outside the house."
    D "I tried pulling down but it's too tight."
    scene ep2_004_Belt_Undo_Talk_D_listen_MC
    X "Have you tried other ways to get rid of it?"
    scene ep2_002_Belt_Undo_Talk_D_talk_away
    D "Tried breaking it, but it did nothing."
    scene ep2_003_Belt_Undo_Talk_D_talk_close with ml
    D "I saw [Odelia] use a card to lock it."
    scene ep2_004_Belt_Undo_Talk_D_listen_MC with ml
    X "In that case, it should have some kind of safety mechanism in case it gets stuck or something."
    X "I just need to look up the model."
    scene ep2_001_Belt_Undo_Talk_D_talk_MC
    D "Okay."
    scene ep2_004_Belt_Undo_Talk_D_listen_MC
    X "Can I... take a look at it?"
    scene ep2_002_Belt_Undo_Talk_D_talk_away
    D "Of course!"
    scene ep2_006_Belt_Undo_Check_front with ml
    X "Hmmm."
    X "Nothing."
    scene ep2_007_Belt_Undo_Check_side with ml

    X "Don't see anything, maybe in the back."
    scene ep2_008_Belt_Undo_Check_back with ml

    X "I don't see any markings anywhere."
    D "Maybe it's under it."
    X "It's possible. Can you lie down for me?"
    scene ep2_010_Belt_Undo_Check_under_close with downtop
    X "I see something, but can't make out what it is."
    X "OK I need you to get on your back, then lift up your hips a bit."
    D "Okay..."
    scene ep2_009_Belt_Undo_Check_under with ml
    "No fap strap..."
    X "This must be it!"
    X "You can stand back up now."
    scene ep2_004_Belt_Undo_Talk_D_listen_MC with ml
    X "I'll look it up, just wait a little longer here."
    scene ep2_236_MC_laptop_type_night with rightleft
    "Who the fuck are these people, forcing her to wear this!"
    "Sick fucks..."
    scene ep1_000_black with dissolve
    pause 2.0
    scene ep2_236_MC_laptop_type_night with dissolve
    "They don't even sell this online."
    "I could keep searching or maybe try another way..."
    menu:
        "Keep searching":
            "I'll give it another shot."
            pause 4.0
            "Well what do you know! Somebody with the same problem."
            "Says there's supposed to be a small pinhole on the lock."
            $ep2_belt_method = "lockpick"
            jump ep2_01_bedroom_lockpick
        "Try something else":
            "This could take some time."
            "Maybe I can find another way..."
            scene ep2_234_Bathroom_MC_get_lube with downtop
            "I could use this."
            "Otherwise, it'll sit here and expire."
            $ep2_belt_method = "lube"
            jump ep2_01_bedroom_lube
    label ep2_01_bedroom_lockpick:
        scene ep2_004_Belt_Undo_Talk_D_listen_MC with rightleft
        X "I found out the model. I have something to go with."
        scene ep2_011_Belt_Undo_Lockpick_back_pov with downtop
        X "Okay I found the hole, now for the hard part."
        scene ep2_012_Belt_Undo_Lockpick_back_close with ml
        "It said to poke around till it goes deeper."
        scene ep2_013_Belt_Undo_Lockpick_close_2 with ml
        "Easy does it..."
        scene ep2_014_Belt_Undo_Lockpick_back_side with ml
        "Maybe I gotta push harder."
        scene ep2_015_Belt_Undo_Lockpick_back_low with ml
        "Come on..."
        scene ep2_016_Belt_Undo_Lockpick_back_lower with ml
        "There's a hole, so this has to work!"
        pause 1.0
        X "Think I heard a click."
        scene ep2_019_Belt_Undo_Lockpick_face_talk with ml
        D "Is it done?"
        scene ep2_018_Belt_Undo_Lockpick_face_listen with ml
        X "I have to press the button to see."
        scene ep2_017_Belt_Undo_Lockpick_side with ml
        menu:
            "Turn away first":
                $ep2_belt_look = False
                "I should look away first."
                "This is awkward enough..."
                scene ep2_021_belt_unlock_look_away with ml
                X "Here it goes!"
                X "One, two."
                pause 0.5
                X"Three..."
                pause 1.5
                D "It's off!"
                X "I'll leave to get ready. We still have to go to the hospital in the morning."
            "Push the button":
                $ep2_belt_look = True
                $D_p += 1
                scene ep2_020_Belt_Undo_Lockpick_button_press with ml
                X "Here it goes!"
                X "One, two."
                pause 0.5
                scene ep2_lockpick_belt
                pause 2.0
                X"Three..."
                D "It's off!"
                X "Yeah I can.. see that."
                scene ep2_021_belt_unlock_look_away with ml
                X "I'll leave to get ready. We still have to go to the hospital in the morning."
        $D_p_t += 1
        jump ep2_02_drive_clinic






    label ep2_01_bedroom_lube:
        scene ep2_004_Belt_Undo_Talk_D_listen_MC with rightleft
        X "Didn't find much about it, so we'll try pulling it off."
        scene ep2_024_Belt_Undo_Lube_pour with downtop
        X "First I'll make it as slippery as possible."
        scene ep2_025_Belt_Undo_Lube_hand_back with ml
        X "Then see if it'll come down."
        D "Ah!"
        X "Something wrong?"
        scene ep2_032_Belt_Undo_Lube_face_talk with ml
        D "It's cold."
        scene ep2_031_Belt_Undo_Lube_face_listen
        X "I know, but it'll pass. Just bear with it."
        scene ep2_026_Belt_Undo_Lube_hand_back_low with ml
        X "It needs to really get in there."
        scene ep2_027_Belt_Undo_Lube_hand_side with ml
        X "Are you getting any pain or irritation?"
        scene ep2_028_Belt_Undo_Lube_hand_side_2 with ml
        D "No, but it feels a little strange."
        scene ep2_029_Belt_Undo_Lube_hand_front with ml
        X "That's normal, nothing to worry about."
        scene ep2_030_Belt_Undo_Lube_hand_front_2 with ml
        X "OK that should be plenty, let's give it a try."
        scene ep2_033_D_belt_undo_front_ANIM_start with ml
        X "I can feel it's a bit loose. I'm going to be a little forceful now."
        X "Tell me if anything hurts!"
        scene ep2_032_Belt_Undo_Lube_face_talk with ml
        D "I'm fine."
        scene ep2_033_D_belt_undo_front_ANIM_start with ml
        D "Good, here I go!"
        scene ep2_033_D_belt_undo_front_ANIM_start 
        menu:
            "Turn away first":
                $ep2_belt_look = False
                "I should look away first."
                "This is awkward enough..."
                scene ep2_021_belt_unlock_look_away with ml
                X "One, two."
                pause 0.5
                X"Three..."
                pause 1.5
                D "It's off!"
                X "I'll leave to get ready. We still have to go to the hospital in the morning."
            "Pull it down":
                $ep2_belt_look = True
                $D_p += 1
                X "One, two."
                pause 0.5
                scene ep2_pull_down_belt
                pause 2.0
                X"Three..."
                D "It's off!"
                X "Yeah I can.. see that."
                scene ep2_021_belt_unlock_look_away with ml
                X "I'll leave to get ready. We still have to go to the hospital in the morning."
        $D_p_t += 1
        jump ep2_02_drive_clinic

label ep2_02_drive_clinic:
    $renpy.music.play("audio/music/morning-routine-outside.ogg", channel=u'music', loop=True, fadein=3)
    scene ep2_035_Drive_day_city_road_empty with rightleft
    "Should I tell her what to do about last night?"
    menu:
        "Keep this a secret":
            scene ep2_038_Drive_day_city_D_look with ml
            X "Hey so about the belt situation."
            scene ep2_036_Drive_day_city_D_talk
            D "Yes?"
            scene ep2_037_Drive_day_city_D_listen
            X "People could get the wrong idea about it. Looking at our situation, it's already complicated."
            X "So, for now, we should just not mention it all. OK?"
            scene ep2_036_Drive_day_city_D_talk 
            D "Of course, I won't tell anyone."
            X "Good."

        "Trust her":
            $D_p += 1
            "I probably don't need to say anything about it."
            "She kept it from me till now. So she probably understands not to say anything."
    $D_p_t += 1

label ep2_03_clinic:
    scene ep2_040_Clinic_receptionist_A1 with rightleft
    X "Excuse me!"
    X "We're here for the 9 o'clock appointment."
    scene ep2_041Clinic_receptionist_A2
    "Nurse""Just a moment."
    scene ep2_040_Clinic_receptionist_A1 
    pause 1.0
    scene ep2_041Clinic_receptionist_A2
    "Nurse" "Ah yes, mister [X]!"
    "Nurse" "You have a check-up for your dad."
    scene ep2_042_Clinic_reception_D_A1 with ml
    X "Correct."
    scene ep2_043_Clinic_reception_D_A2 with ml
    X "And she's right here!."
    scene ep2_041Clinic_receptionist_A2
    "Nurse" "Great! Doctor [Joan] is in now."
    "Nurse" "So head right in."
    
    scene ep2_047_Intro_clinic_doc_face_talk
    scene ep2_048_Intro_clinic_doc_face_talk_hands
    scene ep2_049_Intro_clinic_doc_face_listen

    scene ep2_044_clinic_office_entrance with rightleft
    X "Good morning!"
    Joan"Good morning, have a seat right here."
    scene ep2_045_Intro_clinic_doc_type_talk with ml
    Joan "Mister [X], long time no see."
    scene ep2_046_Intro_clinic_doc_type_listen
    X "Sorry doc, been busy traveling."
    scene ep2_047_Intro_clinic_doc_face_talk with ml
    Joan "And I wasn't aware you had a dad."
    scene ep2_049_Intro_clinic_doc_face_listen
    X "About that..."
    X "I don't actually have any documents to prove it."
    X "So I'll need something to back that up in court."
    scene ep2_047_Intro_clinic_doc_face_talk
    Joan "We can do that."
    Joan "Do you have a court-order?"
    X "Not yet."
    scene ep2_048_Intro_clinic_doc_face_talk_hands
    Joan "And the mother. Can she come in for a test?"
    X "Not at the moment."
    scene ep2_047_Intro_clinic_doc_face_talk
    Joan "I see."
    Joan "We can certainly do it."
    scene ep2_045_Intro_clinic_doc_type_talk with ml
    Joan "But since the mother isn't available."
    Joan "And it also needs to be admissible in court."
    Joan "It will take more time."
    scene ep2_046_Intro_clinic_doc_type_listen
    X "That's fine, as long as it's solid proof."
    scene ep2_048_Intro_clinic_doc_face_talk_hands with ml
    Joan "We'll do the most rigorous test."
    Joan"However, since it's not court-ordered, I can't guarantee a judge will accept it."
    scene ep2_049_Intro_clinic_doc_face_listen
    X "We can just do it again then."
    scene ep2_048_Intro_clinic_doc_face_talk_hands
    Joan "That'll work. Now let's begin the check-up!"

    scene ep2_050_Table_clinic_begin with leftright
    Joan "Sit up on the table for me [D]."
    scene ep2_051_Table_clinic_throat_exam_pov with ml
    Joan "This will be a little uncomfortable, but bear with me."
    Joan "Say \"Aaaa\"."
    scene ep2_052_Table_clinic_throat_exam_close with ml
    D "Aaaa!"
    scene ep2_053_Table_clinic_blood_prep with ml
    Joan "Do you have a problem with needles?"
    D "I... I don't really like them."
    Joan "Having a little fear is very healthy actually."
    X "I used to hate them when I was young."
    X "They were a pain the butt!"
    scene ep2_054_Table_clinic_blood_vein_prep with ml
    Joan "And to the nurses, so were you from what I've heard."
    X "Hey come on!"
    X "What happened to doctor-patient confidentiality?"
    scene ep2_055_Table_clinic_blood_draw_low_angle with ml
    Joan "Those fights you used to have weren't really a secret."
    X "OK, fair enough."
    scene ep2_056_Table_clinic_blood_draw with ml
    X "Say doc, have you tried using a marker to draw blood?"
    scene ep2_057_Table_clinic_blood_draw_smile with ml
    Joan "Not really, but if I attempted with my art skills it would be... in vein."
    scene ep2_058_Table_clinic_Exam_Finished with ml
    X "That wasn't so bad now [D]?"
    D "No."
    scene ep2_045_Intro_clinic_doc_type_talk with ml
    Joan "Normally there are no issues."
    scene ep2_048_Intro_clinic_doc_face_talk_hands with ml
    Joan "But I did hear about a man who lost his entire left half from drawing blood."
    X "Really?!"
    scene ep2_047_Intro_clinic_doc_face_talk with ml
    Joan "Yeah, but he's all right now."
    scene ep2_046_Intro_clinic_doc_type_listen
    X "That's good."
    X "I bet his other side still feels left out though.............."

    scene ep2_059_Clinic_doors_D_listen with rightleft
    X "The next doctor will look down there."
    X "She's a professional, so there's nothing to worry about."
    scene ep2_060_Clinic_doors_D_talk 
    D "Okay."
    scene ep2_062_Waiting_Room_Carla_meet_POV_looking_down_Carla with downtop
    "???" "Is she your dad?"
    scene ep2_066_Waiting_Room_Carla_meet_POV_Carla_listen with ml
    X "Yes! She is indeed my dad."
    scene ep2_068_Waiting_Room_Carla_meet_POV_Carla_ask_about_D with ml
    "???" "I don't believe I've seen her around school."
    "???" "What grade is she in?"
    scene ep2_067_Waiting_Room_Carla_meet_FREE_listening with ml
    X "Hasn't ever been there yet."
    X "She has been home-schooled till now."
    scene ep2_064_Waiting_Room_Carla_meet_POV_Carla_talk_brow with ml
    "???" "Sounds like you might want to enroll."
    scene ep2_066_Waiting_Room_Carla_meet_POV_Carla_listen
    X "Yes, that's in the works."
    X "Do you teach at school?"
    scene ep2_065_Waiting_Room_Carla_meet_FREE_talk with ml
    "???" "I teach history, although these days I'm too busy as principal."
    scene ep2_066_Waiting_Room_Carla_meet_POV_Carla_listen with ml
    "She's a principal and teaches history. She must be the one the girls mentioned."
    "What was her name again? C....."
    $t_flag.reset
    menu:
        "[Carla]":
            $Carla_p += 1
            $t_flag.x1=True
            X"Is your name [Carla]?"
            scene ep2_063_Waiting_Room_Carla_meet_POV_Carla_talk 
            Carla "That's right! Have we met?"
        "Carol":
            X"Is your name Carol?"
            scene ep2_063_Waiting_Room_Carla_meet_POV_Carla_talk 
            Carla "Close, it's [Carla]."
            Carla "Have we met?"
        "Carma":
            X"Is your name Carma?"
            scene ep2_063_Waiting_Room_Carla_meet_POV_Carla_talk 
            Carla "Close, it's [Carla]."
            Carla "Have we met?"
        "Clara":
            X"Is your name Clara?"
            scene ep2_063_Waiting_Room_Carla_meet_POV_Carla_talk 
            Carla "Close, it's [Carla]."
            Carla "Have we met?"
    $Carla_p_t += 1
    scene ep2_066_Waiting_Room_Carla_meet_POV_Carla_listen 
    X "I've met with Alecia and Sophie for tutoring, they mentioned you once."
    if  t_flag.x1==True:
        scene ep2_063_Waiting_Room_Carla_meet_POV_Carla_talk 
        Carla "And you recalled my name, that's a little impressive."
    $t_flag.reset
    scene ep2_063_Waiting_Room_Carla_meet_POV_Carla_talk 
    Carla "Are you helping Sophie with mathematics?"
    scene ep2_066_Waiting_Room_Carla_meet_POV_Carla_listen 
    X "That's the main reason."
    scene ep2_064_Waiting_Room_Carla_meet_POV_Carla_talk_brow
    Carla "Well that is great to hear!"
    Carla "I've been searching for a tutor for some time."
    scene ep2_070_Waiting_Room_Carla_meet_POV_Carla_listen_nurse with ml
    "Nurse" "Miss [Carla], the doctor will see you now."
    scene ep2_063_Waiting_Room_Carla_meet_POV_Carla_talk 
    Carla "I have to get in."
    scene ep2_069_Waiting_Room_Carla_meet_POV_Carla_show_elbow with ml
    Carla "It probably won't be long, just pushed my elbow a bit too far."
    scene ep2_071_Waiting_Room_Carla_meet_POV_Carla_walk_butt with ml
    Carla "If you can wait, I'd like to continue our conversation."
    X "Sure."
    scene ep2_061_Waiting_Room_Carla_meet_POV_looking_down_alone with ml
    pause 0.5
    D "I'm back!"
    scene ep2_059_Clinic_doors_D_listen with downtop
    X "All done?" 
    scene ep2_060_Clinic_doors_D_talk
    D "Yes. She said I was a... late bloomer?"
    X "That checks out."
    D "But that everything looks good."
    D "And she has to wait for the other test results."
    scene ep2_059_Clinic_doors_D_listen
    X "That's reassuring."
    scene ep2_072_D_meets_Carla_wave with rightleft
    Carla "Hello, my name's [Carla]!"
    D "I'm... [D]!"
    scene ep2_073_D_meets_Carla_C_talk 
    Carla "You must be hungry."
    scene ep2_074_D_meets_Carla_D_talk
    D "A little."
    scene ep2_073_D_meets_Carla_C_talk 
    Carla "Well I know of a place where they make some amazing waffles."
    Carla "Does sound good to you?"
    scene ep2_074_D_meets_Carla_D_talk
    D "Yes!"
    scene ep2_075_D_meets_Carla_C_talk_MC with ml
    Carla "If your father approves, we can head there now."
    X "Hey I'm curious about this place too!"

label ep2_04_cafe:
    $renpy.music.play("audio/music/cafe_1.ogg", channel=u'music', loop=True, fadein=3)
    scene ep2_076_Cafe_Alecia_Day_Intro_POV_TALK_eachother_clear_table with rightleft
    Carla "So [D], have you even been to school?"
    D "No, I only had lessons at home."
    scene ep2_081_Cafe_Alecia_Day_Intro_POV_Carla_talk_D_clear_table
    Carla "Are there other kids you play with?"
    scene ep2_079_Cafe_Alecia_Day_Intro_POV_D_talk_Carla_clear_table 
    D "I remember that a relative used to visit."
    scene ep2_076_Cafe_Alecia_Day_Intro_POV_TALK_eachother_clear_table 
    D "But I have been by myself most days."
    Carla "I see."
    Carla "In that case I advise you ease in first before the start of the year."
    scene ep2_081_Cafe_Alecia_Day_Intro_POV_Carla_talk_D_clear_table 
    Carla "There are smaller summer classes going on now."
    Carla "You can join those to get used to the school."
    scene ep2_077_Cafe_Alecia_Day_Intro_POV_Listening_both_clear_table
    X "Are those for every grade?"
    scene ep2_080_Cafe_Alecia_Day_Intro_POV_Carla_talk_MC_clear_table
    Carla "They're mixed from every grade."
    scene ep2_077_Cafe_Alecia_Day_Intro_POV_Listening_both_clear_table
    X "Aren't those mainly for students with problems?"
    scene ep2_080_Cafe_Alecia_Day_Intro_POV_Carla_talk_MC_clear_table
    Carla "Sadly that's the perception, but there are also those who excel among them."
    scene ep2_077_Cafe_Alecia_Day_Intro_POV_Listening_both_clear_table
    X "You think it might rub off on the underachievers?"
    scene ep2_080_Cafe_Alecia_Day_Intro_POV_Carla_talk_MC_clear_table
    Carla "That's one reason I organized them that way."
    scene ep2_082_Cafe_Alecia_Day_Intro_POV_Alecia_talk_table with ml
    Alecia "G'morning principal! What can I get you today?"
    X "And speaking of underachievers!"
    scene ep2_083_Cafe_Alecia_Day_Intro_POV_Alecia_talk_MC_surpise
    pause 0.4
    Alecia "[X]?!"
    X "Hey [Alecia], you got a job for the summer?"
    scene ep2_084_Cafe_Alecia_Day_Intro_POV_Alecia_talk_MC
    Alecia "Yeah, just preparing for my future as an underachiever."
    scene ep2_082_Cafe_Alecia_Day_Intro_POV_Alecia_talk_table
    Alecia "We can't all be straight A students like you."
    X "That's funny, seeing how I almost got expelled and ended up supended for a year."
    scene ep2_083_Cafe_Alecia_Day_Intro_POV_Alecia_talk_MC_surpise
    Alecia "What?"
    X "Never got an A till my last year of school."
    X "Then I did get straight As in maths. So you're not too far off."
    scene ep2_085_Cafe_Alecia_Day_Intro_POV_Alecia_Carla_talk_MC
    Carla "Oh now I remember!"
    Carla "You got in to that fight and got suspended for hospitalizing that kid."
    Carla "Then came back and started going to competitions."
    X "Pretty much yeah."
    scene ep2_084_Cafe_Alecia_Day_Intro_POV_Alecia_talk_MC
    Alecia "How did you not get kicked out?"
    X "Well they started it."
    Alecia "They?"
    X "I was on bad terms with a gang, long story."
    scene ep2_086_Cafe_Alecia_Day_Intro_POV_Alecia_D_Carla_listen with ml
    X"By the way, this is [D], my dad."
    X"[D], [Alecia]."
    scene ep2_087_Cafe_Alecia_Day_Intro_FREE_D_face with ml
    D "Hello! Nice to meet you."
    scene ep2_088_Cafe_Alecia_Day_Intro_FREE_Alice_face with ml
    Alecia "Hi there!"
    scene ep2_085_Cafe_Alecia_Day_Intro_POV_Alecia_Carla_talk_MC with ml
    Carla "We were talking about [D] going to summer classes."
    Carla "Maybe you could show her around, she's not from here."
    Alecia "Sure."
    scene ep2_083_Cafe_Alecia_Day_Intro_POV_Alecia_talk_MC_surpise
    Alecia "Wait, you said she was your dad?"
    X "That's... another long story."
    scene ep2_082_Cafe_Alecia_Day_Intro_POV_Alecia_talk_table
    Alecia "Right. So what can I get you?"
    scene ep2_085_Cafe_Alecia_Day_Intro_POV_Alecia_Carla_talk_MC
    Carla "We came here for those famous honey waffles."
    Carla "A coffee and for [X]..."
    X "Another coffee, that's all."
    scene ep2_082_Cafe_Alecia_Day_Intro_POV_Alecia_talk_table
    Alecia "Alright, coming right up."
    X "And don't forget about our deal."
    Alecia "Sure sure!"
    scene ep2_092_Cafe_Alecia_Day_Intro_POV_Carla_talk_MC with downtop
    Carla "What was that about a deal?"
    scene ep2_089_Cafe_Alecia_Day_Intro_POV_Listening_both 
    X "We have an understanding. About her trying to get in to at least a subject."
    scene ep2_092_Cafe_Alecia_Day_Intro_POV_Carla_talk_MC
    Carla "It couldn't have been easy to convince her."
    X "You could say the opportunity fell in to my lap."
    scene ep2_093_Cafe_Alecia_Day_Intro_POV_Carla_talk_D
    Carla "In any case, [D] could start making friends."
    Carla "That's a very important part of school life."
    scene ep2_091_Cafe_Alecia_Day_Intro_POV_D_talk_Carla
    D "I don't know, maybe I could."
    scene ep2_093_Cafe_Alecia_Day_Intro_POV_Carla_talk_D
    Carla "Of course you can. You seem like a nice and sweet girl."
    Carla "Who wouldn't want to be friends?"
    scene ep2_089_Cafe_Alecia_Day_Intro_POV_Listening_both 
    X "Yeah it's been a short while, but we hit it off really well."
    X "On top of that, she's an amazing cook."
    scene ep2_090_Cafe_Alecia_Day_Intro_POV_D_talk_MC
    D "I just follow the recipe, it's not that impressive."
    scene ep2_089_Cafe_Alecia_Day_Intro_POV_Listening_both 
    X "Don't sell yourself short now. It takes skill."
    scene ep2_093_Cafe_Alecia_Day_Intro_POV_Carla_talk_D 
    Carla "Do you enjoy cooking [D]?"
    scene ep2_091_Cafe_Alecia_Day_Intro_POV_D_talk_Carla 
    D "I have fun with it."
    scene ep2_093_Cafe_Alecia_Day_Intro_POV_Carla_talk_D 
    Carla "You said you were by yourself most of the time."
    Carla "What other stuff did you do?"
    scene ep2_091_Cafe_Alecia_Day_Intro_POV_D_talk_Carla 
    D "I used to stay in the garden, and take care of the plants."
    D "And I would also stay there to read."
    scene ep2_093_Cafe_Alecia_Day_Intro_POV_Carla_talk_D 
    Carla "What did you read?"
    scene ep2_091_Cafe_Alecia_Day_Intro_POV_D_talk_Carla 
    D "I liked to read novels, books about other places, other times."
    scene ep2_093_Cafe_Alecia_Day_Intro_POV_Carla_talk_D
    Carla "Like history books?"
    scene ep2_091_Cafe_Alecia_Day_Intro_POV_D_talk_Carla 
    D "Yes, there were some really interesting ones."
    scene ep2_093_Cafe_Alecia_Day_Intro_POV_Carla_talk_D
    Carla "I've read a few interesting ones myself."
    Carla "And would love to share and discuss some of them with you."
    scene ep2_092_Cafe_Alecia_Day_Intro_POV_Carla_talk_MC
    Carla "And if you need help with math, your father can help."
    scene ep2_089_Cafe_Alecia_Day_Intro_POV_Listening_both
    X "Yeah I have a good grasp. It's that I have to review the current material."
    X "It's been a second since my school days."
    scene ep2_092_Cafe_Alecia_Day_Intro_POV_Carla_talk_MC 
    Carla "Oh I can help with that."
    Carla "If you can come by tomorrow morning, I'll have some books ready."
    scene ep2_093_Cafe_Alecia_Day_Intro_POV_Carla_talk_D
    Carla "And [D] can take the placement tests."
    Carla "What do you say? Would you like to come to school this year?"
    scene ep2_091_Cafe_Alecia_Day_Intro_POV_D_talk_Carla 
    D "I would like that, yes!"
    scene ep2_094_Cafe_Alecia_Day_Intro_POV_Carla_stand_up with ml
    Carla "Excellent! Then I'll expect you tomorrow."
    X "Do you need a ride?"
    Carla "No, it's fine."
    scene ep2_095_Cafe_Alecia_Day_Intro_POV_Carla_leave with ml
    Carla "It was a pleasure meeting you [D]. Hope to see you in school."
    D "Thank you miss [Carla]."
    Carla "Please, just [Carla]."
    scene ep2_096_Cafe_MC_phone with topdown
    
    Eileen "[X]! I'm almost done at the store."
    Eileen "You free later for that catching up we talked about?"
    X "We got some catching up to do [Eileen]."
    X "Found out that I have a dad."
    Eileen "Eh? What was that about someone's dad?"
    X "It's about my dad, [Emily]'s dad."
    Eileen "What?!"
    X"Can we meet now?"
    Eileen "Come to the shop!"

label ep2_05_eileen:
    $renpy.music.play("audio/music/pastry-shop.ogg", channel=u'music', loop=True, fadein=3)
    scene ep2_097_Day_Eileen_meet_D_introduce_pov with rightleft
    Eileen "Why hello there!"
    Eileen "I'm [Eileen]."
    scene ep2_098_Day_Eileen_meet_D_introduce_angle with ml
    Eileen"Your dad and I are old friends."
    D "Hello, I'm [D]."
    scene ep2_100_Day_Eileen_meet_D_invite_shop_angle with ml
    Eileen "Do you like sweets [D]?"
    D "Yes."
    scene ep2_099_Day_Eileen_meet_D_invite_shop_pov with ml
    Eileen "Tell you what, you go in the shop."
    Eileen "And pick out any cake you want from the menu."
    Eileen "Sound good?"
    D "Okay..."
    Eileen "Me and your dad will have a little chat in the mean time."
    scene ep2_101_Day_Eileen_meet_D_smile with topdown
    Eileen "Well congratulations I guess!"
    Eileen "Since when did you find out about her?"
    X "A few days--"
    scene ep2_102_Day_Eileen_meet_D_hand_up
    Eileen "A FEW DAYS?!"
    scene ep2_103_Day_Eileen_meet_D_question
    Eileen "And you didn't call me?!"
    scene ep2_104_Day_Eileen_meet_D_listen
    X "It was a lot to process, it just didn't cross my mind."
    scene ep2_103_Day_Eileen_meet_D_question
    Eileen "I bet. So can you fill me in on everything then?"
    X "Well it all started on the beach..."
    scene ep1_000_black with dissolve
    pause 1.5
    scene ep2_104_Day_Eileen_meet_D_listen with dissolve
    X "...so that's pretty much it."
    scene ep2_103_Day_Eileen_meet_D_question
    Eileen "So you made her wear your stinky clothes?"
    scene ep2_104_Day_Eileen_meet_D_listen
    X "They were clean. I wouldn't do that!"
    scene ep2_105_Day_Eileen_meet_D_look_away with ml
    Eileen"In any case, she needs clothes."
    scene ep2_106_Day_Eileen_meet_D_end_pov with topdown
    Eileen "Hey, did you pick a cake?"
    D "I have."
    Eileen "Great! Now what do you say about getting some new clothes for yourself?"
    D "New clothes?"
    Eileen "That's right."
    scene ep2_107_Day_Eileen_meet_D_end_close with ml
    Eileen "And don't worry, I have excellent fashion sense."
    X "It's true!"
    Eileen "Nobody asked you!"
    X "Sorry..."
    $renpy.music.play("audio/music/positive way.ogg", channel=u'music', loop=True, fadein=3)
    scene ep2_108_Shop_Clothes_Outside with rightleft
    Eileen "Something simple, casual and comfortable for normal wear."
    scene ep2_109_Shop_Clothes_Entrance with ml
    Eileen "Head in to the booth, I'll bring them and you pick what you like."
    D "Okay."
    scene ep2_110_Shop_clothes_D_changing_enter with ml
    Eileen "Your job is to smile, nod and swipe. Got it?"
    X "Yes, ma'am!"
    scene ep2_111_Shop_clothes_change_room_idle with downtop
    pause 2.0
    D "I like this one!"
    Eileen "Good, show it to your father."
    scene ep2_113_Changing_room_A1_FREE_Dress with ml
    D "What do you think dad?"
    scene ep2_112_Changing_room_A1_POV_Dress with ml
    menu:
        "Looks great":
            X "Looks great on you!"
        "Very cute":
            X "It's very cute!"
        "Lovely":
            X "Really lovely!"
        "I don't like it":
            "Haha! I'm not saying that..."
            X "I like it!"
    scene ep2_114_Changing_room_A1_FREE_Dress_2 with ml
    D "Really?"
    X "I mean it!"
    D "Can I keep it?"
    scene ep2_112_Changing_room_A1_POV_Dress with ml
    X "Of course you can!"
    scene ep2_111_Shop_clothes_change_room_idle with downtop
    pause 2.0
    D "These are really comfortable!"
    Eileen "I know right! I have a few at home."
    Eileen "Let's see what the fashion critic thinks."
    scene ep2_116_Changing_room_A1_FREECasual with ml
    D "dad, what do you think?"
    scene ep2_115_Changing_room_A1_POV_Casual with ml
    menu:
        "I":
            pass
        "love":
            pass
        "it":
            pass
        "!":
            pass
    X "Very nice, looks good, seems comfy!"
    scene ep2_117_Changing_room_A1_FREECasual_2 with ml
    D "It's a little strange, feel like I'm not wearing anything at all."
    scene ep2_115_Changing_room_A1_POV_Casual with ml
    X "Yes... they should advertise it like that!"
    scene ep2_123_Shop_lingerie_Front with rightleft
    X "And we're here for..."
    Eileen "Underwear, obviously."
    scene ep2_120_D_lingerie_A1_POV_talk with ml
    Eileen "They have quality stuff here."
    scene ep2_118_D_lingerie_A1_POV_talk_D with ml
    Eileen "Do you know your bra size?"
    D "Not really."
    Eileen "I'll have to eyeball it then."
    scene ep2_124_Shop_Lingerie_MC_bench with downtop
    pause 1.5
    D "[Eileen]?"
    scene ep2_125_Shop_Lingerie_MC_bench_door with ml
    X "She's not here, is there a problem?"
    D "This bra is a bit small and I can't undo it in the back."
    menu:
        "Get [Eileen]":
            $ep2_bra_fall = False
            X "Hold on a second! I'll go get her."
            D "Thank you!"
        "Help her":
            $D_p += 1
            $ep2_bra_fall = True
            X "I can help you with that."
            scene ep2_126_D_change_bra_A1_POV_reveal_back with ml
            D "I'm not sure how it detaches. And I don't want to force it."
            scene ep2_127_D_change_bra_A1_POV_hands_on with ml
            X "You'll have to be patient with me."
            scene ep2_128_D_change_bra_A1_FREE_Front with ml
            X "I'm not used to doing this."
            scene ep2_130_D_change_bra_A1_FREE_Face with ml
            D "I'm not used to wearing bras."
            scene ep2_129_D_change_bra_A1_FREE_Back with ml
            X "Hey! We have another thing in common."
            scene ep2_127_D_change_bra_A1_POV_hands_on with ml
            pause 1.0
            X "Think I got it."
            scene ep2_131_D_change_bra_A1_POV_unlocked
            X "There!"
            scene ep2_132_D_change_bra_A1_FREE_bra_flyoff
            D "Oh!"
            scene ep2_133_D_lingerie_tits_ANIM_start with ml
            X "..."
            scene ep2_bra_slip 
            pause 2.0
            scene ep2_134_D_lingerie_tits_ANIM_finish
            X "I should..."
            scene ep2_135_Shop_Lingerie_changing_room_door with ml
            X "...go tell [Eileen] to get another size."
    $D_p_t += 1
    scene ep2_119_D_lingerie_A1_POV_FIXED_sleepwear with ml
    Eileen "See any design you like?"
    D "Ummm..."
    scene ep2_120_D_lingerie_A1_POV_talk with leftright
    Eileen "That should do for now."
    X "If you say so."
    scene ep2_121_D_lingerie_A1_FREE_D__look_lingerie with ml
    Eileen "[D] dear, we can go now!"
    scene ep2_122_D_lingerie_A1_FREE_D__look_lingerie_respond
    D "Yes, coming!"
    $renpy.music.play("audio/music/dinner-prep.ogg", channel=u'music', loop=True, fadein=3)
    scene ep2_141_Dinner_D_Eileen_A1_FREE_Eileen_talk_D with rightleft
    Eileen "...that was the first time I saw [Emily] and [X] hanging out."
    scene ep2_136_Dinner_D_Eileen_A1_POV_Eileen_talk_MC with ml
    Eileen "I was like \"Who's this delinquent? Did [Emily] fall for him?\""
    scene ep2_139_Dinner_D_Eileen_A1_POV_Eileen_listen_MC_hold_glass with ml
    X "And I remember you kept trying to get a rise out of me."
    X "Seeing if I'd get violent."
    scene ep2_147_Dinner_D_Eileen_A1_POV_D_talk_Eileen with ml
    D "But what if he were someone that did get violent?"
    scene ep2_140_Dinner_D_Eileen_A1_POV_Eileen_talk_D with ml
    Eileen "I was ready for that."
    scene ep2_136_Dinner_D_Eileen_A1_POV_Eileen_talk_MC
    Eileen "At the first sign I would've kicked him right in the crotch."
    D "Ouch!"
    scene ep2_141_Dinner_D_Eileen_A1_FREE_Eileen_talk_D with ml
    Eileen "That's a solid move. If a guy is threatening you."
    scene ep2_149_Dinner_D_Eileen_A1_FREE_D_listen_Eileen with ml
    Eileen "Give 'em all you got, don't hold back."
    scene ep2_139_Dinner_D_Eileen_A1_POV_Eileen_listen_MC_hold_glass with ml
    X "I was lucky that she came around to seeing the light."
    scene ep2_137_Dinner_D_Eileen_A1_POV_Eileen_talk_MC_hold_glass
    Eileen "I figured that out when I saw you two studying."
    Eileen "A meat head wouldn't be able to hold out that long."
    scene ep2_139_Dinner_D_Eileen_A1_POV_Eileen_listen_MC_hold_glass
    X "Yeah, also [Emily] didn't go easy on me."
    scene ep2_146_Dinner_D_Eileen_A1_POV_D_listen_MC with ml
    X "She has this ability to just peer in to your soul."
    X "It's hard to explain."
    scene ep2_145_D_inner_D_Eileen_A1_POV_D_talk_MC
    D "Is that what made you fall in love?"
    scene ep2_146_Dinner_D_Eileen_A1_POV_D_listen_MC
    X "Not just that, but it's one big part of it."
    scene ep2_138_Dinner_D_Eileen_A1_POV_Eileen_listen_MC with ml
    X "She saw that I had a talent for maths, and didn't give up on me."
    X "And there were plenty of reasons for her to just leave me be."
    scene ep2_146_Dinner_D_Eileen_A1_POV_D_listen_MC with ml
    X "So I owe her a lot."
    X "Who knows where I would've ended up if not for your mother."
    scene ep2_143_Dinner_D_Eileen_A1_POV_Eileen_talk_D_Finish with leftright
    Eileen "[D], The sauce was just delicious! You have to give me the recipe."
    scene ep2_150_Dinner_D_Eileen_A1_POV_D_talk_Eileen_Finish with ml
    D"I'm happy you enjoyed it."
    scene ep2_144_Dinner_D_Eileen_A1_POV_Eileen_stand_talk_MC with ml
    Eileen "Hey, [D] and I are going upstairs for some girl talk. So we need some privacy."
    Eileen "You got the dishes!"
    scene ep2_151_Dinner_D_Eileen__dish_washer_counter with downtop
    "I could listen in..."
    $renpy.music.play("audio/music/lofi sexy 1.ogg", channel=u'music', loop=True, fadein=3)
    menu:
        "Check on the conversation":
            $ep2_listen_talk = True
            "It couldn't hurt."
            scene ep2_153_Dinner_D_Eileen_door_listen with ml
            pause 0.3
            Eileen"...these ways of touching."
            Eileen "Has anyone in or outside the family done that to you?"
            D "Not that I remember."
            Eileen "You know, girls when they develop, their bodies start do eliminate blood every month or so."
            Eileen "Has that happened to you?"
            D "No."
            Eileen "Okay."
            Eileen "One more thing, at some point you will feel the need to touch youself down there."
            D"Why?"
            Eileen "You'll know! But regardless of what anyone may have told you, that is perfectly natural and healthy."
            D "I understand."
            Eileen "It'll be fine, you're a smart girl."
            Eileen "Oh and this is the last thing. About that sauce..."
        "Do the dishes":
            $Eileen_p += 1
            $ep2_listen_talk = False
            "I should respect their privacy."
    $Eileen_p_t += 1
    scene ep2_152_Dinner_D_Eileen__dish_washer with ml    
    Eileen "Hey how about opening another bottle?"
    X "I'm game."
    scene ep2_154_Eileen_night_drink_A1_POV_Eileen_talk_MC with rightleft
    Eileen "Did you listen in to our little talk?"
    if ep2_listen_talk == False:
        scene ep2_156_Eileen_night_drink_A1_POV_Eileen_listen_MC
        X "Nope, honest!"
        scene ep2_155_Eileen_night_drink_A1_POV_Eileen_talk_look_away
        Eileen "Then I'll give you the rundown."
        Eileen "As far as she knows, there hasn't been any abuse."
        Eileen "Her period hasn't started."
        Eileen "And her body is still developing."
    else:
        scene ep2_156_Eileen_night_drink_A1_POV_Eileen_listen_MC
        X "Sorry, couldn't help myself."
        scene ep2_155_Eileen_night_drink_A1_POV_Eileen_talk_look_away
        Eileen "In that case, I don't need to get you up to date."
    scene ep2_154_Eileen_night_drink_A1_POV_Eileen_talk_MC
    Eileen "But she has more growing up to do."
    scene ep2_160_Eileen_night_drink_A1_FREE_Eileen_drink with ml
    X "She has me now, so it'll be fine."
    Eileen "Yeah, but what about [Emily]?"
    scene ep2_159_Eileen_night_drink_A1_POV_Eileen_drink_grass with ml
    X "I don't believe for a second that she ran away."
    scene ep2_155_Eileen_night_drink_A1_POV_Eileen_talk_look_away with ml
    Eileen "Yeah, she would never just leave her own dad like that."
    scene ep2_157_Eileen_night_drink_A1_POV_Eileen_listen_look_away
    X "And I'm just worried that she might..."
    X "I just fear the worst."
    scene ep2_154_Eileen_night_drink_A1_POV_Eileen_talk_MC
    Eileen "You can't think like that [X]!"
    Eileen "You have to keep it together, for [D]!"
    scene ep2_158_Eileen_night_drink_A1_POV_MC_look_down with ml
    X "I know."
    X "And [Charlie] is on the case."
    X "But this fucking wait is just killing me."
    scene ep2_157_Eileen_night_drink_A1_POV_Eileen_listen_look_away
    X "If there wasn't anyone else involved, I would've gone there and kicked the front door open by now."
    scene ep2_160_Eileen_night_drink_A1_FREE_Eileen_drink with ml
    Eileen "Yeah, and done something really stupid after."
    X "Obviously."
    scene ep2_161_Eileen_night_drink_A1_FREE_Eileen_drunk with rightleft
    Eileen "Damn! We finished two bottles."
    Eileen "I got orders tomorrow, so I should get going."
    X "Where are you going like that?"
    X "Just crash here for tonight."
    Eileen "Nah, I got this."
    scene ep2_162_Eileen_drunk_put_bed_A1_Bed_Eillen_carry with ml
    Eileen "Nice room you got here!"
    scene ep2_163_Eileen_drunk_put_bed_A1_Bed_Eillen_Lying with ml
    Eileen "Oh and the bed's so soft, yeahhh..."
    X "Hey come on, at least take the dress off."
    scene ep2_164_Eileen_drunk_put_bed_A1_Cam_bow_undo with ml
    X "You'll be shouting at me tomorrow because I let you sleep in it."
    scene ep2_165_Eileen_drunk_put_bed_A1_Entrance_undress with ml
    Eileen "Well ok, you did buy me dinner. Guess you can strip me now."
    scene ep2_166_Eileen_drunk_put_bed_A1_Bed_Eillen_Lying_underwear with ml
    Eileen "Oh hey there bed! Still soft as ever."
    X "Bathroom's down the hall. Goodnight [Eileen]."
    Eileen "Huh? Where you goin'?"
    X "I'll crash on the couch."
    Eileen "Whaaa..."
    scene ep2_167_Livingroom_couch_sleeping_on with ml
    "Maybe had a bit too much tonight."
    scene ep1_000_black with dissolve
    pause 2.0
    "Thirsty..."
    scene ep2_168_Kitchen_night_Eileen_approach with dissolve
    "[Eileen]'s up, she's probably feeling better."
    scene ep2_169_Eileen_night_encounter_ANIM_start with ml
    scene ep2_topless_bend
    pause 1.5
    X "Hey can you grab some--"
    scene ep2_topless_jump
    pause 2.0
    Eileen "Aaaaah!"
    Eileen "You startled me [X]!"
    scene ep2_172_Kitchen_night_Eileen_turn_away
    X "Yeah sorry. Just came for some water."
    X "Also you're not wearing anything on top."
    Eileen "I know. You want me to sleep in a bra?"
    Eileen "Have you seen my boobs?"
    X "Very recently."
    Eileen "Also what are you doing on the couch?"
    Eileen "Come to bed!"
    scene ep2_173_Kitchen_night_Eileen_leave_choice with ml
    X "The couch is fine."
    Eileen "Don't be silly, there's plenty of space. And you'll get back pain from that."
    menu:
        "Go to bed":
            X "You may be right."
            $ep2_eileen_handy = True
            $Eileen_p += 1
            jump ep2_05_eileen_handy
        "Insist on the couch":
            X "It's really no problem. Plus I can get restless sometimes."
            Eileen "Fine, go ahead!"
            $ep2_eileen_handy = False
            jump ep2_06_school
    label ep2_05_eileen_handy:
        scene ep2_174_Eileen_drunk_lying_in_bed_backside with rightleft
        X "Seems a little chilly in here. Do you want a blanket?"
        Eileen "I'm good."
        X "You sure?"
        scene ep2_175_Eileen_drunk_lying_in_bed_talk with ml
        Eileen "Are you still hung up on me being topless?"
        scene ep2_177_Eileen_drunk_lying_in_bed_listen
        X "I'm mean we're both half naked in the same bed!"
        scene ep2_176_Eileen_drunk_lying_in_bed_talk_point
        Eileen "Wait! Are you having trouble sleeping because of me?"
        X "It's... no!"
        scene ep2_178_Eileen_drunk_lying_in_bed_crotch_grab
        Eileen "Oh my!"
        X "Hey come on!"
        scene ep2_175_Eileen_drunk_lying_in_bed_talk with ml
        Eileen "Has it been working like normal or is it because of me again?"
        scene ep2_177_Eileen_drunk_lying_in_bed_listen
        X "Well... haven't really been able to get it up on my own."
        scene ep2_175_Eileen_drunk_lying_in_bed_talk 
        Eileen "Really?"
        Eileen "Have you tried with others, maybe some coworkers?"
        scene ep2_177_Eileen_drunk_lying_in_bed_listen
        X "Are you kidding me?!"
        X "If word had gone around that I have erectile dysfunction."
        X "I wouldn't hear the end of it."
        scene ep2_176_Eileen_drunk_lying_in_bed_talk_point
        Eileen "So you haven't gotten off since I took care of it last time?"
        scene ep2_177_Eileen_drunk_lying_in_bed_listen
        X "Well I did have wet dreams, got some release then."
        scene ep2_175_Eileen_drunk_lying_in_bed_talk 
        Eileen "And when was the last time that happened?"
        scene ep2_177_Eileen_drunk_lying_in_bed_listen
        X "I don't know, maybe two, three months ago..."
        scene ep2_175_Eileen_drunk_lying_in_bed_talk 
        Eileen "That's not healthy!"
        scene ep2_178_Eileen_drunk_lying_in_bed_crotch_grab
        Eileen "Come on get it out, I'll take care of it!"
        X "[Eileen], you don't have to!"
        scene ep2_183_Eileen_drunk_handy_A1_end_alt2 with ml
        Eileen "Just look at it! Looks ready to blow."
        X "It's fine, I'll deal with it somehow."
        scene ep2_180_Eileen_drunk_handy_A1_talk2 with ml
        Eileen "Like going to the doctor, and getting prescribed a bunch of pills?"
        scene ep2_179_Eileen_drunk_handy_A1_talk with ml
        Eileen "When you can have your friend apply a simple natural treatment."
        Eileen "I don't think so!"
        scene ep2_184_Eileen_drunk_handy_ANIM_top with ml
        X "[Eileen]..."
        scene ep2_handy_drunk_normal
        pause 2.0
        X "Fuck!"
        scene ep2_180_Eileen_drunk_handy_A1_talk2 with ml
        Eileen "Does it feel good?"
        X"Well yeah..."
        scene ep2_184_Eileen_drunk_handy_ANIM_top with ml
        pause 0.5
        scene ep2_handy_drunk_normal
        pause 2.0
        X"Oh!"
        scene ep2_handy_drunk_normal with animf
        pause
        scene ep2_183_Eileen_drunk_handy_A1_end_alt2 with ml
        X"I won't last much longer."
        scene ep2_179_Eileen_drunk_handy_A1_talk with ml
        Eileen "You don't have to, just let it out."
        scene ep2_184_Eileen_drunk_handy_ANIM_top with ml
        pause 0.5
        scene ep2_handy_drunk_normal
        pause
        X "Shit! I'm getting close!"
        scene ep2_handy_drunk_fast with animf
        pause
        menu:
            "Cum!":
                pass
        X "Oh shit I'm gonna--"
        scene ep2_186_Eileen_drunk_handy_ropes
        X "CUM!"
        scene ep2_186_Eileen_drunk_handy_ropes
        pause 1.0
        scene ep2_187_Eileen_drunk_handy_cum_on_chest with ml
        Eileen "Look at all that pent up energy..."
        X "Sorry about that."
        scene ep2_188_Eileen_drunk_handy_sit_on_bed with ml
        Eileen "Don't worry about it."
        scene ep2_189_Eileen_drunk_handy_panty_drop_1 with ml
        Eileen "I'm just glad I could help you."
        scene ep2_190_Eileen_drunk_handy_panty_drop_2 with ml
        X "Well... thanks!"
        scene ep2_191_Eileen_handjob_cum_lick with ml
        Eileen "My pleasure..."
        jump ep2_06_school







label ep2_06_school:
    $Eileen_p_t += 1
    $renpy.music.play("audio/music/morning-routine-house.ogg", channel=u'music', loop=True, fadein=3)
    scene ep1_000_black with ml
    pause 0.4
    scene ep1_129_floor_overview_day with ml
    "Better get to school early, [Carla] might be busy later."
    scene ep2_194_Carla_meet_1_POV_Carla_talk_MC with rightleft
    Carla "You came! Excellent!"
    Carla "We can set you up in the study room."
    scene ep2_202_D_library_talk with leftright
    X "Just write whatever you know there."
    X "No reason to be nervous."
    D"I understand."
    scene ep2_201_D_library_study_test_A1 with ml
    X "And I'll be right outside."
    scene ep2_192_Carla_meet_1_POV_Carla_hand_books with ml
    Carla "Got you all the material you need to study with [Sophie] here."
    Carla "It's not exhaustive, but if you get through these, it would be great."
    scene ep2_193_Carla_meet_1_FREE_Books_listen with ml
    X "That's a big help there! Thank you!"
    scene ep2_197_Carla_meet_1_POV_Carla_listen_MC with ml
    X "And is the placement test going to take some time?"
    scene ep2_195_Carla_meet_1_POV_Carla_talk_MC_normal
    Carla "Shouldn't take more than two hours."
    Carla "It's mostly about basic knowledge."
    scene ep2_197_Carla_meet_1_POV_Carla_listen_MC with ml
    X "Alright."
    X "And thank you for going out of your way to help [D]!"
    scene ep2_195_Carla_meet_1_POV_Carla_talk_MC_normal
    Carla "That's my job."
    scene ep2_197_Carla_meet_1_POV_Carla_listen_MC 
    X "And how's the elbow?"
    scene ep2_194_Carla_meet_1_POV_Carla_talk_MC
    Carla "Nothing major, just need to not strain too much."
    scene ep2_200_Carla_meet_1_POV_Carla_leave_talk with ml
    Carla "I have to go now. When [D] finishes, just leave the papers on the table."
    Carla "I'll pick them up when I get back."
    X "Take care!"
    scene ep2_202_D_library_talk with ml
    X "How's it going [D]?"
    Carla "Nearly done."
    X "Already? That was faster than expected."
    scene ep2_035_Drive_day_city_road_empty with rightleft
    X "[Charlie]! How are things going?"
    Charlie "I've dug some more info on these people."
    Charlie "Can we meet to talk later at the park?"
    X "Of course."
    Charlie "And can you bring your dad along?"
    X "Ok..."
    X "Don't see any problem with that."
    X "Are you okay if we vist the park [D]?"
    scene ep2_039_Drive_day_city_D_talk_DRESS with ml
    D "It's fine."
    scene ep2_035_Drive_day_city_road_empty with ml
    X "We can get ice cream on the way."
    X "Got any flavor preferences?"
    D "Not really, just as long as it's not mint!"
    X "OK. We can start off with the basic ones."
    X "Is vanilla okay?"
    D "Yes."
    $renpy.music.play("audio/music/ambient-classical-guitar.ogg", channel=u'music', loop=True, fadein=3)
    scene ep2_203_Park_Simple_overview_day with rightleft
    X "Nobody around, it's quiet."
    D "You want the cherry?"
    scene ep2_204_Park_simple_Charlie_meet_POV_D_cherry_give with ml
    X "What?"
    D "Do you want my cherry?"
    menu:
        "Take her cherry":
            X "Sure, I'll take your cherry..."
        "Let her have it":
            X "No, you can have it."
            scene ep2_205_Park_simple_Charlie_meet_FREE_D_cherry_eat with ml
            pause
    scene ep2_206_Park_simple_Charlie_meet_POV_D_licky with ml
    X "Do you like it?"
    scene ep2_207_Park_simple_Charlie_meet_FREE_D_licky with ml
    D "Aha!"
    scene ep2_208_Park_simple_Charlie_meet_POV_D_talk with ml
    D "It's my favorite now!"
    scene ep2_209_Park_simple_Charlie_meet_POV_D_listen
    X "What was your favorite before?"
    scene ep2_208_Park_simple_Charlie_meet_POV_D_talk
    D "Had one once that wasn't mint. I don't know what it was called."
    scene ep2_209_Park_simple_Charlie_meet_POV_D_listen
    X "Well there are loads to try. You're in for an adventure!"
    scene ep2_207_Park_simple_Charlie_meet_FREE_D_licky with ml
    D"Yay!"
    scene ep2_210_Park_simple_Charlie_meet_POV_Kitty with ml
    "Kitty" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🐱{/font}"
    X "Wow look at that."
    D "Kitty!"
    "Kitty" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🐱{/font}"
    scene ep2_211_Park_simple_Charlie_meet_POV_Kitty_Pet with ml
    D "Hey little guy! You lost?"
    "Kitty" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}😺{/font}"
    D "Are you hungry?"
    scene ep2_212_Park_simple_Charlie_meet_POV_Kitty_Charlie_meet with ml
    Charlie "Is that your kitty?"
    D "We just met."
    Charlie "And you're friends already? Extraordinary!"
    Charlie "I'm [Charlie] by the way, and you must be..."
    D "[D]"
    Charlie "Nice to meet you."
    Charlie "I just need to talk to your dad for a bit."
    Charlie "Can you stay here and play with your kitty?"
    D"Okay..."
    scene ep2_215_Park_simple_Charlie_meet_POV_Charlie_talk_away with leftright
    Charlie "Cute kid."
    scene ep2_216_Park_simple_Charlie_meet_POV_Charlie_listen_away with ml
    X "So, what have you found so far?"
    scene ep2_213_Park_simple_Charlie_meet_POV_Charlie_talk_MC
    Charlie "Been digging around for info on the family."
    scene ep2_214_Park_simple_Charlie_meet_POV_Charlie_talk_MC_hand
    Charlie "But their records have been privated from around the time [Emily] was adopted."
    Charlie "And there aren't many digital traces from before."
    scene ep2_213_Park_simple_Charlie_meet_POV_Charlie_talk_MC
    Charlie "So I had whatever was in the archive faxed."
    scene ep2_216_Park_simple_Charlie_meet_POV_Charlie_listen_away with ml
    X "Did something come up?"
    scene ep2_213_Park_simple_Charlie_meet_POV_Charlie_talk_MC
    Charlie "They were running some business back then, and there aren't many details about it."
    Charlie "But the thing is, the name Adalinda."
    scene ep2_215_Park_simple_Charlie_meet_POV_Charlie_talk_away
    Charlie "It was their dad, she died at about the same age as [Emily]."
    scene ep2_217_Park_simple_Charlie_meet_FREE_Charlie_listen_away with ml
    X "So they adopted [Emily], who was around the same age as her and called her by her name..."
    scene ep2_214_Park_simple_Charlie_meet_POV_Charlie_talk_MC_hand
    Charlie "So they can pretend she never died, then after [D] was born, they switched to her."
    scene ep2_216_Park_simple_Charlie_meet_POV_Charlie_listen_away
    X "That's fucked up!"
    scene ep2_213_Park_simple_Charlie_meet_POV_Charlie_talk_MC
    Charlie "That's what it looks like."
    Charlie "So I'll need a warrant to look in to all the records."
    scene ep2_217_Park_simple_Charlie_meet_FREE_Charlie_listen_away 
    X "They also used fake names in the adoption process!"
    X "That has to count against them."
    scene ep2_213_Park_simple_Charlie_meet_POV_Charlie_talk_MC
    Charlie "Definitely!"
    scene ep2_214_Park_simple_Charlie_meet_POV_Charlie_talk_MC_hand 
    Charlie "But I have to clear up a few things first."
    X "What's that?"
    scene ep2_215_Park_simple_Charlie_meet_POV_Charlie_talk_away
    Charlie "Your dad said she was on the road for about a week before reaching the beach."
    X "Yes"
    Charlie "But until now, there hasn't been any missing person report filled."
    X "Considering all the shit they've done to her, I doubt they will."
    scene ep2_214_Park_simple_Charlie_meet_POV_Charlie_talk_MC_hand 
    Charlie "Maybe so."
    Charlie "She also mentioned a journal [Emily] wrote, that she doesn't have."
    X "She also didn't have anything else on her."
    scene ep2_213_Park_simple_Charlie_meet_POV_Charlie_talk_MC
    Charlie "And she was homeschooled, grew up isolated, and somehow managed to get all the way here."
    X "Yeah public transport is a hell of a thing!"
    scene ep2_217_Park_simple_Charlie_meet_FREE_Charlie_listen_away with ml
    X "And I also had a DNA test taken, so we'll have solid proof."
    scene ep2_213_Park_simple_Charlie_meet_POV_Charlie_talk_MC
    Charlie "That's good, but it will take some time."
    Charlie "Right now if her whole story is true and there's no missing person's report."
    scene ep2_214_Park_simple_Charlie_meet_POV_Charlie_talk_MC_hand 
    Charlie "Means they have their own people looking for her."
    Charlie "Which means the longer we wait, the more likely it is they'll find her."
    scene ep2_215_Park_simple_Charlie_meet_POV_Charlie_talk_away
    Charlie "So [X], I need you to be absolutely sure about her."
    Charlie "I have a lot on the line for this."
    X "I haven't doubted it for a second!"
    scene ep2_211_Park_simple_Charlie_meet_POV_Kitty_Pet with ml
    X"She. Is. My. Daughter!"
    scene ep2_213_Park_simple_Charlie_meet_POV_Charlie_talk_MC with ml
    Charlie "OK then, we're going all in!"
    scene ep2_218_Park_simple_Charlie_meet_POV_Kitty_Charlie_leave with ml
    Charlie "Never seen anyone be so good with animals."
    scene ep2_219_Park_simple_Charlie_meet_FREE_Kitty_Charlie_leave with ml
    D "I would always try to make friends with them."
    Charlie "That's just adorable."
    scene ep2_220_Park_simple_Charlie_meet_POV_Charlie_stand_leave with ml
    Charlie "Wait for my call. And take care of her."
    X "I will."
    X "And thank you!"
    Charlie "Don't mention it." 
    scene ep2_209_Park_simple_Charlie_meet_POV_D_listen with ml
    X "Ready to leave?"
    scene ep2_208_Park_simple_Charlie_meet_POV_D_talk with ml
    D "I am."
    X"Are you sure?"
    D"Yes!"
    X"OK..."
    $renpy.music.play("audio/music/inside-you.ogg", channel=u'music', loop=True, fadein=3)
    scene ep2_153_Dinner_D_Eileen_door_listen with rightleft
    X "Hey [D], are you done changing?"
    D "Come in!"
    scene ep2_225_D_bed_listen_1 with ml
    X "How are you feeling?"
    scene ep2_221_D_bed_talk_normal
    D "I'm fine."
    scene ep2_225_D_bed_listen_1
    X "And about the school situation. What do you think of that?"
    scene ep2_221_D_bed_talk_normal
    D "I don't know, it would be nice to make friends."
    scene ep2_226_D_bed_listen_2
    X "Indeed, but it can be hard for you in the beginning."
    X "Could get overwhelming. So I want you to know that you can count on my support."
    scene ep2_223_D_bed_talk_smile_close with ml
    D "Thanks dad!"
    scene ep2_225_D_bed_listen_1 with ml
    X "And about that kitty earlier, you seem to like it."
    scene ep2_227_D_bed_listen_shirt with ml
    X "Maybe you wanted to take it home, you could have asked."
    X "Even if I say no, don't be afraid to ask."
    scene ep2_221_D_bed_talk_normal with ml
    D "It's true, I did want to keep him."
    scene ep2_224_D_bed_talk_hand
    D "But he was so small."
    D "He probably had a mommy and a daddy nearby."
    D "And I couldn't just take him away from them."
    scene ep2_221_D_bed_talk_normal 
    X "That's... true, you can't just do that!"
    X "Anyway, you're probably tired..."
    scene ep2_228_D_bed_talk_kiss_ANIM_start with ml
    D "Wait!"
    X "What?"
    scene ep2_kiss_on_knees
    pause 2.0
    D "You have something over here."
    X "Where?"
    scene ep2_kiss_cheeck
    pause 2.0
    D "Here!"
    scene ep2_228_D_bed_talk_kiss_ANIM_start with ml
    X"What was that for?"
    D"For everything!"
    menu:
        "Kiss on the cheek":
            $ep2_d_kiss = "cheek"
            scene ep2_231_D_bed_cheek with ml
            D"Thank you!"
        "Kiss on the forehead":
            $ep2_d_kiss = "forehead"
            scene ep2_232_D_bed_forehead with ml
            D"Thank you!"
    scene ep2_221_D_bed_talk_normal with ml
    X "And I forgot to tell you about the ice cream flavors."
    scene ep2_233_D_bed_look_down with ml
    X "There are a lot of them, but there are so many combinations too."
    X "You can even enjoy mint in certain mixture."
    X "But we have enough time for those."
    pause 0.6
    X "[D], is something wrong?"
    scene ep2_228_D_bed_talk_kiss_ANIM_start
    D "I don't think so."
    X "OK, let's get some sleep."
    scene ep2_237_Bedroom_MC_Entrance_lights with leftright
    "She seemed to space out a bit there."
    "Maybe she's just tired."
    scene ep2_238_Bedroom_MC_bulge with ml
    "Guess I'm also... erect?!"
    "When did that happen?"
    "Is that what she was looking at?!"
    "Shit..."
    scene ep1_000_black with curtains_slow_r
    menu:
        "Continue":
            jump ep3_01_bathroom






































    

























menu:
    "Script break":
        pass