init -100 python:
    class Choice_Flags:
        def __init__(self,x1=False,x2=False,x3=False,x4=False,x5=False,x6=False,x7=False,x8=False,x9=False):
            self.x1 = False
            self.x2 = False
            self.x3 = False
            self.x4 = False
            self.x5 = False
            self.x6 = False
            self.x7 = False
            self.x8 = False
            self.x9 = False
        @property
        def reset(self,*args):
            self.x1 = False
            self.x2 = False
            self.x3 = False
            self.x4 = False
            self.x5 = False
            self.x6 = False
            self.x7 = False
            self.x8 = False
            self.x9 = False
        @property
        def all(self,*args):
            self.x1 = True
            self.x2 = True
            self.x3 = True
            self.x4 = True
            self.x5 = True
            self.x6 = True
            self.x7 = True
            self.x8 = True
            self.x9 = True