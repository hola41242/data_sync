init python:
    latest_episode_file= "ep5"
    renpy.music.register_channel("ambience", "ambience", loop=True, stop_on_mute=True, tight=True, file_prefix="", file_suffix="", buffer_queue=True, movie=False, framedrop=True)
init -100:
    define mm = "gui/main_menu.png"

    define main_menu_img_composite = Composite(
        (0,0),
        
        (0,0),"gui/Title SIMP.png",
        (0,0),"gui/CA Logo.png")
$ Preference("mixer <ambience> volume", 0.5)
default punch_nrml = Move((20, -10), (-20, 10), .07, bounce=True, repeat=True, delay=.18)
default punch_weak = Move((10, -5), (-10, 5), .15, bounce=True, repeat=True, delay=.22)

default latest_episode = 5
default game_version = "0.5"

$ renpy.music.play("audio/sfx/door-knock.ogg", channel=u'sound', loop=False)
pause 1.5
$ renpy.music.play("audio/music/Wet-dream-a1.ogg", channel=u'music', loop=True, fadein=3)
pause 4


$ renpy.music.stop(channel=u'music', fadeout=1.0)
$ renpy.music.stop(channel=u'ambience', fadeout=None)
$ renpy.music.stop(channel=u'sound', fadeout=None)


label start:

    define pov_mc = "MC"
    define pov_d = "Emily's daughter"
    define Emily = Character("Emily")
    define Alecia = Character("Alecia")
    define Sophie = Character("Sophie")
    define Eileen = Character("Eileen")
    define Maya = Character("Maya")
    define Carla = Character("Carla")
    define Khalil = Character("Khalil")
    define D = Character("[pov_d]")
    define John = Character("John")
    define Jimmy = Character("Jimmy")
    define Charlie = Character("Charlie")
    define Radford = Character("Radford")
    define Odelia_str = "Odelia"
    define Odelia = Character(Odelia_str)
    define Ode = Character(Odelia_str[0:3])
    define Adalinda = Character("Adalinda")


    define Joan = Character("Joan")
    define Jerold = Character("Jerold")
    define Sergio = Character("Sergio")
    define Brad = Character("Brad")
    define John = Character("John")
    define John_p = Character("{i}[pov_mc] (John){/i}")
    define Emil = Character("Emil")
    define Mira = Character("Mira")
    define Maeve = Character("Maeve")
    define Luigi = Character("Luigi")
    define Bailey = Character("Bailey")

    define D_p = 0
    define Alecia_p = 0
    define Sophie_p = 0
    define Eileen_p = 0
    define Maya_p = 0
    define Carla_p = 0
    define Charlie_p = 0

    define D_p_t = 0
    define Alecia_p_t = 0
    define Sophie_p_t = 0
    define Eileen_p_t = 0
    define Maya_p_t = 0
    define Carla_p_t = 0
    define Charlie_p_t = 0

    define t_flag = Choice_Flags()
    define t_flag_extra = Choice_Flags()



    default ep1_confess = False
    default ep1_eileen_fav = False
    default ep1_alecia_grab = False
    default ep1_door_peek = False


    default ep2_belt_method = False
    default ep2_belt_look = False
    default ep2_bra_fall = False
    default ep2_listen_talk = False
    default ep2_eileen_handy = False
    default ep2_d_kiss = False

    default ep3_d_movie = False
    default ep3_panties = False
    default ep3_celebration = False
    default ep3_eileen_buttjob = False
    default ep3_job_return = False
    default ep3_d_kiss = False
    default ep3_d_grind = "still"

    default ep4_guilt = False

    default ep4_hotel_FAP = False
    default ep4_d_kiss = False
    default ep4_d_breasts = False
    default ep4_d_sauna_fall = False
    default ep4_stairs_prior = False
    default ep4_d_movie_fap = False
    default ep4_d_shower_look = False
    default ep4_d_bed_hump = False
    default ep4_carla_nude = False

    default ep5_blunt = False
    default ep5_eileen_ss = False
    default ep5_D_joystick_home = False
    default ep5_Alecia_fap = False
    default ep5_D_joystick_farm = False




    jump game_start
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
