init python:
    import os

    def generate_episode_animation_metadata(episode_number):
        base_path = renpy.config.gamedir

        episode_dir = os.path.join(
            base_path,
            "animations",
            f"episode{episode_number}"
        )

        if not os.path.isdir(episode_dir):
            raise Exception(f"Episode folder not found: {episode_dir}")

        episode_data = {}

        for folder_name in os.listdir(episode_dir):
            anim_path = os.path.join(episode_dir, folder_name)
            if not os.path.isdir(anim_path):
                continue

            frames = [
                f for f in os.listdir(anim_path)
                if f.startswith("frame") and f.endswith(".jpg")
            ]

            if not frames:
                continue

            frame_numbers = sorted(
                int(f.replace("frame", "").replace(".jpg", ""))
                for f in frames
                if f.replace("frame", "").replace(".jpg", "").isdigit()
            )

            if not frame_numbers:
                continue

            anim_key = f"episode{episode_number}_{folder_name}"

            episode_data[anim_key] = {
                "frames": max(frame_numbers) + 1,
                "default_speed": 0.03,
                "default_curve": "linear",
                "folder": folder_name,
            }

        if not episode_data:
            raise Exception("No animations found.")

        output = [
            "init python:",
            "",
            f"    ANIMATIONS.setdefault({episode_number}, {{}})",
            ""
        ]

        for anim_key, data in episode_data.items():
            output.extend([
                f"    ANIMATIONS[{episode_number}]['{anim_key}'] = {{",
                f"        'frames': {data['frames']},",
                f"        'default_speed': {data['default_speed']},",
                f"        'default_curve': '{data['default_curve']}',",
                f"        'folder': '{data['folder']}',",
                "    }",
                ""
            ])

        output_path = os.path.join(
            base_path,
            "generated",
            f"animations_episode{episode_number}.rpy"
        )

        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(output))

        renpy.notify(
            f"Generated animations_episode{episode_number}.rpy — restart required."
        )
