label ep4_bed_wake:
    hide screen episode_end
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    $renpy.music.stop(channel=u'ambience', fadeout=None)
    $renpy.music.stop(channel=u'sound', fadeout=None)
    scene ep1_000_black with dissolve
    pause 0.5
    show screen episode_title("Episode 4","Unwritten rules")
    pause 5.5
    hide screen episode_title
    if ep3_d_grind == "still":
        scene ep4_Hotel_D_Sleep_Cum_Aftermath with ml
        "...need to take care of this."
        #wipe off butt with towel
        D "**Mmmhn**"
        scene ep3_Hotel_D_Sleep_NIght_A1 with ml
        pause 1.0
        "She's still asleep."
        scene ep4_Hotel_D_Sleep_Cum_Aftermath with ml
        if ep3_panties == "release":
            $ ep4_guilt = True
            "What the fuck is wrong with me!"
            "First I rub one off while smelling her panties and now this!"
            "Maybe I'm not fit to be a father."
            pause 1.5
            "But I also can't just give up, when she needs help the most."
            "These damn urgers, need to be kept in check!"
        else:
            "I need to keep these urges in check!"
        
    else:
        pass
    scene ep1_000_black with fade
    pause 1.0
    $renpy.music.play("audio/music/peaceful room.ogg", channel=u'music', loop=True, fadein=3)
    D "Good morning dad!"
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen with eye_open
    X "'morning [D]!"
    X "Sleep well?"
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Talk
    D "It was good."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen
    X "Have you had any dreams?"
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Talk
    D "Think so, I can't recall it but it was a nice dream."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen
    X "Oh..."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Talk
    D "Did I move around and wake you?"
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen
    X "You turned around a few times."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Talk
    D "Sorry, I'm used to sleeping alone."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen
    X "Same here, but don't need much space anyway."
    X "I'm still used to those bunk beds we had at the orphanage."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Talk
    D "How did you end up there?"
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen
    X "I was left at the front door when I was still a baby, and got no clue about my parents."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Talk
    D "It must've been hard for you."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen
    X "It wasn't all that bad. There were some kids I got along with."
    X "But I did make it harder on myself by constantly getting into trouble."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Talk
    D "Why?"
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen
    X "Well usually if I had a problem with someone, I would let them know it."
    X "And that included everyone, no exceptions."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Talk
    D "Wow! I don't know if I can be that brave."
    scene ep4_Hotel_D_Bed_Morning_A1_POV_Bed_Wake_Listen
    X "More like stupid, and you're way smarter than I was at that age."
    $renpy.music.play("audio/sfx/telephone-ring-129620.ogg", channel=u'sound', loop=True)
    X "That's probably the reception."
    $renpy.music.stop(channel=u'sound', fadeout=None)
    scene ep4_Hotel_Day_MC_Phone_Talk_Reception with rightleft
    X "Yes?"
    "Reception" "Hello sir, we're sorry but we are still fully occupied for today."
    "Reception" "And as a token of apology, we have reserved a SPA session for tonight."
    X "At the hotel here?"
    "Reception" "Yes sir, and you're free to reschedule for another time if you would like."
    X "I'll think about it."
    "Reception" "We wish to make your stay as comfortable as possible, so if there is anything you need just ask."
    "Reception" "Oh, there's a message for you asking for a meeting later this evening."
    X "OK got it, thanks."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen with ml
    X "Looks like we're staying here for the day."
    X "And you're probably hungry too, let's get some breakfast."
    scene ep4_Hotel_Day_MC_Phone_Talk_Reception with ml
    "Room Service" "Good morning, what can I help you with?"
    X "I would like some breakfast, for two."
    "Room Service" "Of course, what would you like sir?"
    X "Hold on."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen with ml
    X "Want anything in particular?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk
    D "Do they have cereal?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen
    X "Yes, but you can get other stuff you know. Eating cereal every day gets boring."
    X "How about we mix it up?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk
    D "What will you have?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen
    X "Usually, I ask them for recommendations. Just to avoid the potentially awful stuff."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk
    D "Do you mean bad food?"
    "Room Service" "{size=-6}Sir?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen
    X "Not as in rotten, more like just badly made. Something like bananas and fish."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk_Hand
    D "That sounds awful!"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen
    X "It is, I would know."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk_Hand
    D "Have you tried eating that?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen
    X "I did this one time--"
    "Room Service" "Sir?"
    scene ep4_Hotel_Day_MC_Phone_Talk_Reception with ml
    X "Oh sorry!"
    X "Can you recommend anything with strawberries?"
    "Room Service" "We have a strawberry shortcake. One of our chef's specialties."
    X "Sounds great!"
    X "And some simple cereal with a side of strawberries."
    $renpy.music.play("audio/music/spring-vibes-198610.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Talk_1 with leftright
    D "Are you only having cereal?"
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Listen_1
    X "Yeah, figured that if you don't like yours, we can switch."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Spoon_Bowl with ml
    pause 1
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Spoon_Mouth with ml
    pause 1
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Talk_1 with ml
    D "It's good!"
    D "But why did you eat bananas and fish?"
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Listen_1
    X "I {i}tried{/i} to eat it but threw up the next second."
    X "This happened when I was in school, we were playing truth or dare."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Talk_1
    D "What is that?"
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Listen_1
    X "Of course you don't know it."
    X "It's a game you play in a group, and take turns either answering honestly or doing a dare."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Talk_1
    D "That sounds interesting."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Listen_1
    X "So it was at [Eileen]'s place. We talked about doing a study group." 
    X "At the time, [Emily] was helping me catch up since I got suspended for a year."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Talk_1
    D "So you were dared to eat fish and banana?"
    X "Yeah, that was [Eileen]. And the fish was raw too."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Hand_mouth with ml
    D "Ugh!!"
    D "Why did she do that?"
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Listen_1
    X "Well, I wasn't exactly an honor student, only had passing grades for the most part."
    X "And I'd get in trouble almost every week. Still, I have no clue how they didn't expel me."
    X "So I can't blame her for wanting to keep me away from [Emily]."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Talk_1
    D "But you became friends after all."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Listen_1
    X "It was all thanks to your mother. I was already set on how my life would turn out."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Spoon_Bowl with ml
    X "Meeting her was the best thing that ever happened to me."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Spoon_Mouth with ml
    X "Right next to having you here."
    scene ep4_Hotel_D_Table_Eat_A1_POV_D_Talk_1
    D "Thanks dad!"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen with rightleft
    X "It'll get really boring if we just wait around all day."
    X "Let's see if we can find something to pass the time..."
    $renpy.music.play("audio/music/cinema outside.ogg", channel=u'music', loop=True, fadein=5)
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Shuffle with leftright
    X "You know, I had a knack for handling cards when I was young."
    X "Normally kids didn't have much time on their hands, except during the summer."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Deck_Pull_Card with ml
    X "But I had plenty of it to practice!"
    D "Because you were suspended from school?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen with ml
    X "Well... yeah. But in my defense, I was fighting {i}back{/i}!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 
    D "Why were you attacked?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "Because they were trying to get back at me for beating them before."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 
    D "And why did you fight them before?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "Because they were trying to get back at me for beating them before."
    pause 1.0
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Point_MC 
    D "So... how did it all start?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Shuffle with ml
    X "It's a long story, and [Khalil] can tell it better than me."
    D "[Khalil]?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Deck_Pull_Card with ml
    X "He's been my best friend since we were little."
    X "We can hang out once we're over this mess."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Take_Card with ml
    D "So how was school back then, compared to now?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Hold_Cards_5_LOOK with downtop
    X "Well, I don't know much about today. But what's for sure, we used to go outside a lot more."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 with ml
    D "Why?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "A big factor was that we had some spaces, instead of endless highways and parking lots everywhere."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Point_MC 
    D "I did see many cars when traveling here, and they probably need all that space."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "They sure do. And there were way fewer back then."
    X "And there's also the internet now."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Point_MC 
    D "I heard about that from [Sophie]."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1
    D "You can look at pictures on it!"
    "Jesus Christ! I keep forgetting how sheltered she is."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "You can do much more. But let's take it slow with it. OK?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1
    D "Umm, okay."
    D "So was there more violence when people stayed outside more?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "Not necessarily, it had more to do with the fact that I was very angry at that time."
    X "Didn't really get along with people."
    X "So I was looking to take it out on something... or someone."
    X "After a fight, I used to tell myself that it was the right thing to do."
    X "Sometimes maybe it was true, some people don't understand anything else."
    X "But other times, things could've worked out differently, but instead, I chose violence."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Point_MC 
    D "When I found out the truth about mom, I got angry too."
    D "One time during piano practice--"
    X "Wait! You play the piano?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 
    D "Yes... since I was little, I had to practice every day."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "You know the first time I met [Emily] was when she was playing the piano at school, she was pretty good at it."
    X "But given that you haven't mentioned it till now, maybe you don't really enjoy it."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 
    D "No, I do! It's just about the pieces that I wanted to play."
    D "[Odelia] didn't approve of what I wanted."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "To hell with that!"
    X "When we get back home, I'll dust off that piano in the living room and you can go to town on it."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 
    D "Really? I'll go very far into town then!"
    X "Can't wait!"

    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Hold_Cards_5_PICK with downtop
    X "You're doing good! Did you practice by yourself?"
    D "I would sometimes play with [John]."
    X "I see--"
    "Wait a minute!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Hold_Cards_5_PICK with ml
    X "Who was [John]?"
    D "He visited sometimes, and we played games and talked."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Hold_Cards_5_LOOK with ml
    X "Was he old?"
    D "He had grey and black hair. He was older than you I think."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Hold_Cards_5_PICK
    X "Did he have a short ponytail?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 with ml
    D "Yes! How did you know?"
    "It checks out, that's probably him."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen 
    X "Think I've met him."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1
    D "When, where?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen 
    X "He came to the motel looking for you."
    X "Mentioned that your foster father sent him."
    X "He was the one who sent those two guys to kidnap you."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Point_MC 
    D "H-he did that?!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "Yes, and you need to know this because you might need to appear in court."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1
    D "To talk about my..."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "Your old home, yes. But only if it's really really necessary."
    X "Think you can do that?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Point_MC 
    D "I don't know... but I'll do my best."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "OK, good girl!"
    X "What about the people who looked after you all day, could you recognize them?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1
    D "They changed too frequently, I don't think so." 
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "And they watched over you all the time right?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1
    D "Except in the bathroom, and when I was sleeping."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "And about [Emily]'s journal, where did you hide it?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Point_MC 
    D "It's in the bathroom, behind the furniture under the sink."
    X "Alright, got it."

    scene ep1_000_black with dissolve
    pause 1.0
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Shuffle with downtop
    X "Let me try something."
    X "Not sure if I can still do this."
    D "Another game?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Fan with ml
    X "Not exactly."
    X "I'll try guessing your card, go ahead and pick one."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_D_Card_Think with ml
    D "**Hmm**"
    X "Try from the middle, it will be easier for me."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_D_Card_Choice  with ml
    X "Oh really? Going right for the edge there."
    D "You did say {i}any{/i} card!"
    X "Fair enough."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_D_Card_Pick with ml
    X "Now memorize it and place it back in the deck."
    pause 1.0
    D "I got it!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Shuffle with ml
    X "So as you can see, I'm shuffling all the cards."
    D "Okay."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Deck_Pull_Card with ml
    X "I'm just gonna take it without even looking!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_D_Card_Guess_1 with ml
    X "And here it is!"
    pause 1.0
    D "That's... not it."
    X "Really?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Shuffle with ml
    X "Hold on, let me shuffle them a bit more."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_D_Card_Guess_1 with ml
    X "Now I have it!"
    D "Umm, not this one."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Shuffle with ml
    X "Guess I'm a little rusty."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Deck_Pull_Card with ml
    X "Ok third time's the charm!"
    D "The charm?"
    X "Just a saying, means you get lucky on the third try."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_D_Card_Guess_1 with ml
    X "Aaand..."
    pause 1.0
    D "It's still..."
    X "Oh dang it!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Point_MC with ml
    D "Don't worry, maybe you missed something."
    X "No it's not it, I remember all the step--"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Card_Floating 
    X "Oh, there it is!"
    D "Where?"
    X "Right there in mid-air, it gets stuck there sometimes."
    D "I don't see anything."
    X "Oh that's right I forgot."
    X "I made it invisible!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Card_Hidden with ml
    X "It's right over here."
    X "I'll make it visible again, watch closely."
    D "**Mhmm**"
    X "Aaand..."
    pause 1.0
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Card_Reveal
    X "There!"
    D "What?!"
    X "Is that it?"
    D "Yes!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_MC_Card_Surprised with ml
    D "How did you do that?"
    X "Magic!"
    D "Truth!"
    X "What?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 with ml
    D "You have to say the truth, like in truth or dare!"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "It's not how that works, there are a few more steps to the game."
    X "Tell you what, try figuring it out on your own."
    X "You up for the challenge?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 
    D "Can I get a clue?"
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Listen
    X "Here's one, I didn't do a real shuffle."
    X "If you can figure out or get close, I'll get you a nice large ice cream."
    scene ep4_Hotel_D_Bed_Sit_A1_POV_D_Talk_MC_1 
    D "Agreed!"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen with leftright
    X "So we can visit the SPA now, if you want to go."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk
    D "What do you do there?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen
    X "They normally have a sauna, you can relax and sweat in there."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk_Hand
    D "Oh I heard about something like that! Always wanted to try it out."

    $renpy.music.play("audio/music/sunrise-serenade-213616.ogg", channel=u'music', loop=True, fadein=3)

    scene ep4_Hotel_SPA_Enter_POV_Mira_Back with rightleft
    X "Hey there! Is the spa open?"
    scene ep4_Hotel_SPA_Enter_POV_Mira_Talk with ml
    "???" "Oh yes of course!"
    "???" "Just head over to the desk."
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Talk with ml
    Mira "Welcome! My name is [Mira]"
    D "Hello!"
    Mira "Do you have a reservation?"
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Listen with ml
    X "We have a free session."
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Computer_Listen with ml
    X "It should be under our room number."
    pause 1.0
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Computer_Talk
    Mira "Yes, I have it here."
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Point with ml
    Mira "Just leave your clothes in the lockers, towels and soaps are at your disposal."
    Mira "You will have exclusive access, so please take your time."
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Talk with ml
    Mira "I just need to briefly go over the rules..."
    scene ep1_000_black with dissolve
    pause 1.0
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Listen with ml
    X "Ok got it! Not my first time anyway."
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Talk
    Mira "Excellent! And if there are any issues, I'll be right here."
    scene ep4_Desk_SPA_Mira_A1_POV_Mita_Listen 
    X "Thanks."
    scene ep4_Desk_SPA_D_A1_POV_D_Listen with ml
    X "I'll head in first so you take your time getting ready."
    scene ep4_Desk_SPA_D_A1_POV_D_Talk
    D "Sure dad."

    scene ep4_SPA_Sauna_D_Sitting_A2_BG_POV_Sauna_Room_2 with topdown
    "It's still warm in here."
    scene ep4_SPA_Sauna_D_Sitting_A2_BG_POV_Sauna_Room_1 with ml
    "Better be careful not to stay too long."
    D "Is this the sauna?"
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Enter with ml
    X "Yeah."
    D "Do we pour water on the stones?"
    scene ep4_SPA_Sauna_D_Sitting_A2_BG_POV_Sauna_Room_1 with ml
    X "Yes, but not too much. This is a dry sauna."
    X "It's not supposed to fill up with steam."
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Talk with ml
    D "I was wondering about something."
    X "What?"
    D "Why do men not have to cover their chests?"
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Listen 
    X "That's a good question."
    X "The truth is that you don't really have to, not in this country at least."
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Talk
    D "So girls can go outside without covering?"
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Listen
    X "Technically yes, but it's not a good idea."
    X "Some guys just can't help themselves and end up harassing women."
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Talk
    D "Why?"
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Listen
    X "It's how they are I guess."
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Talk
    D "But you wouldn't do that."
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Listen
    X "Of course not!"
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Talk
    D "So is it okay if I don't wear a shirt around you?"
    scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Listen
    X "Umm..."
    "What do I say here?"
    menu:
        "The right to bare chests!":
            $D_p += 1
            $ep4_d_breasts = "release"
            "I don't want her to develop some complex about it."
            X "If it makes you comfortable, then go for it!"
            X "You don't have to worry about me."
            scene ep4_SPA_Sauna_D_Sitting_A1_POV_D_Dry_Talk
            D "Thanks dad!"
        "Keep it covered.":
            $ep4_d_breasts = "hide"
            "Maybe it's better to just avoid all that."
            X "I think it's for the best to try and just keep it covered for now."
            D "Okay dad."
    $D_p_t += 1
    scene ep1_000_black with dissolve
    pause 1.0


    scene ep4_SPA_Sauna_D_Sitting_A2_POV_D_Wet_Sit with leftright
    X "How is it?"
    scene ep4_SPA_Sauna_D_Sitting_A2_POV_D_Wet_Talk with ml
    D "It's like being in a bath, very relaxing."
    scene ep4_SPA_Sauna_D_Sitting_A2_POV_D_Wet_Listen
    X "Since it is your first time, we don't want to hang around too long."
    scene ep4_SPA_Sauna_D_Sitting_A2_POV_D_Wet_Talk
    D "I can stay a little longer."
    scene ep4_SPA_Sauna_D_Sitting_A2_POV_D_Wet_Listen
    menu:
        "Wait a few more minutes":
            $ep4_d_sauna_fall = "yes"
            $D_p += 1
            $D_p_t += 1
            X "Alright, we can do a few more minutes."
            scene ep1_000_black with dissolve
            pause 0.7
            scene ep4_SPA_Sauna_D_Sitting_A2_POV_D_Wipe_Sweat with dissolve
            X "Are you OK?"
            D "It feels hotter than before."
            X "That's enough then, let's get out!"
            scene ep4_SPA_Sauna_D_Sitting_A2_POV_D_Wet_Talk with ml
            D "Okay."
            scene ep4_SPA_Sauna_D_Sitting_A2_POV_D_Fall with ml
            D "I'll go ch--"
            X "[D]!"
        "Get out of the sauna":
            $D_p_t += 1
            $ep4_d_sauna_fall = "no"
            X "Even so, just to be safe let's call it a day."
            jump continue_after_ep4_sauna_early


$ t_flag.reset
$ t_flag.x1 = 0
$ load_rate = 0.017
$ load_rate_level = 2
$ fanum = 60  
############################################################################################
############################### Sauna Grind ################################################
#########################################################################################


init python:
    def ep4_D_Grind_ANIM_POV(load, a, b):
        load.set_child("ep4_SPA_Sauna_D_Grind_A_POV_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 71 and store.load_rate_level == 4:
            store.load_rate = 0.011
        if store.fanum == 115 and load_rate_level == 4:
            store.load_rate = 0.0369
        if store.fanum > 119:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value

init python:
    def ep4_D_Grind_ANIM_ACTION(load, a, b):
        load.set_child("ep4_SPA_Sauna_D_Grind_A_Close_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 71 and store.load_rate_level == 4:
            store.load_rate = 0.011
        if store.fanum == 115 and load_rate_level == 4:
            store.load_rate = 0.0369
        if store.fanum > 119:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value


init python:
    def ep4_D_Grind_ANIM_FRONT(load, a, b):
        load.set_child("ep4_SPA_Sauna_D_Grind_A_Full_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 71 and store.load_rate_level == 4:
            store.load_rate = 0.011
        if store.fanum == 115 and load_rate_level == 4:
            store.load_rate = 0.0369
        if store.fanum > 119:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value


image ep4_D_Grind_ANIM_POV:
    function ep4_D_Grind_ANIM_POV
image ep4_D_Grind_ANIM_ACTION:
    function ep4_D_Grind_ANIM_ACTION
image ep4_D_Grind_ANIM_FRONT:
    function ep4_D_Grind_ANIM_FRONT
#$ fanum = 0


screen SHOW_ep4_D_Grind_ANIM_POV():
    tag ss_anim_screen
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Stand still" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1)  style "screen_button"
        textbutton "Move slow" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2)  style "screen_button"
        textbutton "Grip harder" action SetVariable("load_rate", 0.011),SetVariable("load_rate_level", 3)  style "screen_button"
        textbutton "Get up" action SetVariable("load_rate", 0.0269),SetVariable("load_rate_level", 4)  style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" style  "screen_button"
        textbutton "ACTION" action Jump("SHOW_ep4_D_Grind_ANIM_ACTION")  style "screen_button"
        textbutton "FRONT" action Jump("SHOW_ep4_D_Grind_ANIM_FRONT")  style "screen_button"
    #hbox:
        #yalign 0.99
        #xalign 0.02
        #spacing 40
        #textbutton "Prone" style  "screen_button"
        #textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV")  style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Jump("continue_after_ep4_sauna_grind")  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"


screen SHOW_ep4_D_Grind_ANIM_ACTION():
    tag ss_anim_screen
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Stand still" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1)  style "screen_button"
        textbutton "Move slow" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2)  style "screen_button"
        textbutton "Grip harder" action SetVariable("load_rate", 0.011),SetVariable("load_rate_level", 3)  style "screen_button"
        textbutton "Get up" action SetVariable("load_rate", 0.0269),SetVariable("load_rate_level", 4)  style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" action Jump("SHOW_ep4_D_Grind_ANIM_POV")  style "screen_button"
        textbutton "ACTION"  style  "screen_button"
        textbutton "FRONT" action Jump("SHOW_ep4_D_Grind_ANIM_FRONT")  style "screen_button"
    #hbox:
        #yalign 0.99
        #xalign 0.02
        #spacing 40
        #textbutton "Prone" style  "screen_button"
        #textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV")  style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Jump("continue_after_ep4_sauna_grind")  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"

screen SHOW_ep4_D_Grind_ANIM_FRONT():
    tag ss_anim_screen
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Stand still" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1)  style "screen_button"
        textbutton "Move slow" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2)  style "screen_button"
        textbutton "Grip harder" action SetVariable("load_rate", 0.011),SetVariable("load_rate_level", 3)  style "screen_button"
        textbutton "Get up" action SetVariable("load_rate", 0.0269),SetVariable("load_rate_level", 4)  style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" action Jump("SHOW_ep4_D_Grind_ANIM_POV")  style "screen_button"
        textbutton "ACTION" action Jump("SHOW_ep4_D_Grind_ANIM_ACTION")  style "screen_button"
        textbutton "FRONT"   style  "screen_button"
    #hbox:
        #yalign 0.99
        #xalign 0.02
        #spacing 40
        #textbutton "Prone" style  "screen_button"
        #textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV")  style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Jump("continue_after_ep4_sauna_grind")  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"



label ep4_sauna_accident:
    $renpy.music.stop(channel=u'music', fadeout=0.2)
    scene ep1_000_black with dissolve
    pause 1.0
    "What the..."
    "I feel lightheaded."
    $renpy.music.play("audio/music/melody-of-life-198606.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_SPA_Sauna_D_Grind_A_POV_ANIM_60 with dissolve
    X "Are you okay?"
    X "[D]?"
    "We have to get out!"
    scene ep4_D_Grind_ANIM_POV with ml
    pause 1.0
    X"Fuck!"
    "Why is she grinding on me?"
    scene ep4_D_Grind_ANIM_ACTION with ml
    "When did I get a boner?"



label SHOW_ep4_D_Grind_ANIM_POV:
    scene ep4_D_Grind_ANIM_POV with ml
    call screen SHOW_ep4_D_Grind_ANIM_POV

label SHOW_ep4_D_Grind_ANIM_ACTION:
    scene ep4_D_Grind_ANIM_ACTION with ml
    call screen SHOW_ep4_D_Grind_ANIM_ACTION

label SHOW_ep4_D_Grind_ANIM_FRONT: 
    scene ep4_D_Grind_ANIM_FRONT with ml
    call screen SHOW_ep4_D_Grind_ANIM_FRONT


label continue_after_ep4_sauna_grind:
    if t_flag.x1 == 0:
        $ t_flag.x1 += 1
        hide ss_anim_screen
        scene ep1_000_black with dissolve
        $ load_rate = 0.049
        $ load_rate_level = 1
        pause 1.0
        scene ep4_D_Grind_ANIM_POV with eye_open
        "Damn it!"
        "I can't black out now, gotta be careful..."
        jump SHOW_ep4_D_Grind_ANIM_POV

    elif t_flag.x1 == 1:
        $ t_flag.x1 += 1
        hide ss_anim_screen
        pause 1
        scene ep4_D_Grind_ANIM_POV with dissolve
        pause 1.0
        X "[D], you need to... stop!"
        $ load_rate = 0.011
        $ load_rate_level = 3
        scene ep4_D_Grind_ANIM_POV 
        pause 5.0
        "She's going faster!"
        "If this goes on..."
        jump SHOW_ep4_D_Grind_ANIM_POV

    else:
        $ load_rate = 0.00011
        $ load_rate_level = 3
        scene ep4_D_Grind_ANIM_FRONT with dissolve
        pause 3.5
        "I'm close to--"
        scene ep4_SPA_Sauna_D_Grind_A_Pose_FREE_Bellow_Cum
        pause 1.0
        X "Aaah!!"
        D "**Oooh**!"
        scene ep4_SPA_Sauna_D_Grind_A_Pose_FREE_Bellow_Aftermath with fade
        pause 2.0
        X "Shit..."
        "Have I fucking lost it??"


    $renpy.music.stop(channel=u'music', fadeout=1.0)
    scene ep4_SPA_Sauna_D_B1_POV_After_Talk_Away with rightleft
    D "What happened?"
    X "You fainted."
    X "How are you feeling?"
    scene ep4_SPA_Sauna_D_B1_POV_After_Talk with ml
    D "Think I'm okay."
    D "The last thing I recall is getting up to leave and then--"
    scene ep4_SPA_Sauna_D_B1_POV_After_Listen 
    X "You collapsed! Fortunately I... caught you on time."
    scene ep4_SPA_Sauna_D_B1_POV_After_Talk
    D "Oh, did I hurt you?"
    scene ep4_SPA_Sauna_D_B1_POV_After_Listen 
    X "Not at all!"
    X "Just go take a quick shower to cool off before we leave."
    scene ep4_SPA_Sauna_D_B1_POV_After_Talk
    D "What about you? Your face is all red."
    scene ep4_SPA_Sauna_D_B1_POV_After_Listen 
    X "That's just from... the heat, don't worry about it!"

    jump ep4_after_sauna
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen with ml
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk_Hand with ml
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk with ml


label continue_after_ep4_sauna_early:
    jump ep4_after_sauna

label ep4_after_sauna:
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    scene ep1_000_black with dissolve
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen with ml
    X "I have to go out for a bit."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk
    D "Where to?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen
    X "Here at the hotel. I have to meet [Charlie], won't go far."
    X "Can you hang tight here for me?"
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Talk
    D "I can do that."
    scene ep4_Hotel_D_Room_Center_A2_POV_D_Listen
    X "Great! You can watch some TV while I'm out."


label ep4_hoetel_stairs:
    scene ep1_000_black with dissolve
    $renpy.music.play("audio/music/lofi-hippo-193550.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Enter with leftright
    X "Is someone following you?"
    Charlie "Not sure, I just have a strange feeling."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_1 with ml
    X "So what's the news?"
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_1
    Charlie "I questioned those thugs who took your dad."
    Charlie "Not admitting to anything, but they're talking."
    Charlie "I'll keep trying, maybe catch them slipping."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_1 
    X "Right. What about the other guy?"
    X "He knew we were on the case when I questioned him."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_Handrail with ml
    Charlie "He's not talking and I haven't mentioned [D] yet."
    Charlie "Still need to sort all the files I got."
    menu:
        "Ask about [D]":
            $ep4_stairs_prior = "D"
            scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_Handrail
            X "So about [D]?"
            scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_1 with ml
            Charlie "No mention of her actual name, everything is under [Adalinda]."
            Charlie "Just like with [Emily]."
            scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_1 
            X "So it's true what he said about her?"
            scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_1
            Charlie "It says she had an accident, was found dead at the scene."
            Charlie "Then three days later she was cremated."
        "Ask about [Emily]":
            $ep4_stairs_prior = "M"
            scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_Handrail
            X "And about [Emily]?"
            scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_1 with ml
            Charlie "No mention of her actual name, everything is under [Adalinda]."
            Charlie "Just like with [D]."
            scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_1 
            X "So it's true what he said about [Emily]?"
            scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_1
            Charlie "It says she had an accident, was found dead at the scene."
            Charlie "Then three days later she was cremated."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_1 
    X "It could all be bullshit!"
    X "Who knows what they might have done with her!"
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_1
    Charlie "We'll get to the truth [X]. Just have to keep gathering evidence for now."
    X "OK..."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_1 
    X "What about this [John] guy, what did you find about him?"
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_Handrail with ml
    Charlie "He apparently works for a bank."
    Charlie "And they're even more secretive with their dealings."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_Handrail
    X "What about the foster parets, can you call them in?"
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_Handrail
    Charlie "That's one idea, thing is they might not be aware of the arrest."
    X "So..."
    Charlie "I'll hold off on that till we get more info."
    X "I see."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_1 with ml
    Charlie "I got photos, maybe [D] will recognize them."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_1 
    X "I would prefer to not involve her too much in this."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_1 
    Charlie "I get that, but this will eventually get to court."
    Charlie "And she'll have to be present to settle this."
    Charlie "Unless, maybe the foster parents just don't show or give up."
    Charlie "But given the lengths they went to to get her back, I'm not counting on it."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Listen_1 
    X "You're probably right."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Talk_Handrail with ml
    Charlie "I need to get back now."
    scene ep4_Stairs_Charlie_A1_POV_Charlie_Leave with ml
    Charlie "We'll meet here tomorrow, same time."
    X "Alright."
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    scene ep4_Hotel_D_bed_FAP_Enter_D_bed_Fap_Enter with leftright
    X "Hey I'm ba--"
    "**oohhh**"
    scene ep4_Hotel_D_bed_FAP_Enter_TV_Porn with ml
    "What the fuck?!"
    "Don't they keep this shit locked?"
    scene ep4_Hotel_D_bed_FAP_Enter_D_bed_Fap_Enter with ml
    "Is she touching herself?!"


    menu:
        "Wait":
            $ep4_d_movie_fap = "looked"
            $D_p += 1
            $D_p_t += 1
            $renpy.music.play("audio/music/ero movie TV.ogg", channel=u'music', loop=True, fadein=3)
            "Maybe if I get closer she'll notice."
            $ ep4_hotel_FAP = "seen" 

            jump ep4_bed_D_FAP
        "Turn on the lights":
            $ep4_d_movie_fap = "avoided"
            $D_p_t += 1
            $ ep4_hotel_FAP = "interrupt"
            jump ep4_bed_D_FAP_after


label ep4_bed_D_FAP:
    pass

$ t_flag.reset
$ t_flag.x1 = 0
$ load_rate = 0.049
$ load_rate_level = 1
$ fanum = 0  
############################################################################################
############################### Bed FAP ################################################
#########################################################################################


init python:
    def ep4_D_FAP_ANIM_SIDE(load, a, b):
        load.set_child("ep4_Hotel_D_bed_FAP_A2_Side_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 22 and store.load_rate_level == 4:
            store.load_rate = 0.04
        if store.fanum == 99 and load_rate_level == 4:
            store.load_rate = 0.0035
        if store.fanum > 119:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value

init python:
    def ep4_D_FAP_ANIM_FOOT(load, a, b):
        load.set_child("ep4_Hotel_D_bed_FAP_A3_Foot_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 22 and store.load_rate_level == 4:
            store.load_rate = 0.04
        if store.fanum == 99 and load_rate_level == 4:
            store.load_rate = 0.0035
        if store.fanum > 119:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value


init python:
    def ep4_D_FAP_ANIM_CLOSE(load, a, b):
        load.set_child("ep4_Hotel_D_bed_FAP_A1_Close_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 22 and store.load_rate_level == 4:
            store.load_rate = 0.04
        if store.fanum == 99 and load_rate_level == 4:
            store.load_rate = 0.0035
        if store.fanum > 119:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value


image ep4_D_FAP_ANIM_SIDE:
    function ep4_D_FAP_ANIM_SIDE
image ep4_D_FAP_ANIM_FOOT:
    function ep4_D_FAP_ANIM_FOOT
image ep4_D_FAP_ANIM_CLOSE:
    function ep4_D_FAP_ANIM_CLOSE
#$ fanum = 0


screen SHOW_ep4_D_FAP_ANIM_SIDE():
    tag ss_anim_screen
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1)  style "screen_button"
        textbutton "Normal" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2)  style "screen_button"
        textbutton "Fast" action SetVariable("load_rate", 0.011),SetVariable("load_rate_level", 3)  style "screen_button"
        textbutton "Squeeze" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4)  style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "SIDE" style  "screen_button"
        textbutton "FEET" action Jump("SHOW_ep4_D_FAP_ANIM_FOOT")  style "screen_button"
        textbutton "CLOSE-UP" action Jump("SHOW_ep4_D_FAP_ANIM_CLOSE")  style "screen_button"
    #hbox:
        #yalign 0.99
        #xalign 0.02
        #spacing 40
        #textbutton "Prone" style  "screen_button"
        #textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV")  style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Jump("ep4_bed_D_FAP_finish")  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"


screen SHOW_ep4_D_FAP_ANIM_FOOT():
    tag ss_anim_screen
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1)  style "screen_button"
        textbutton "Normal" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2)  style "screen_button"
        textbutton "Fast" action SetVariable("load_rate", 0.011),SetVariable("load_rate_level", 3)  style "screen_button"
        textbutton "Squeeze" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4)  style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "SIDE" action Jump("SHOW_ep4_D_FAP_ANIM_SIDE")  style "screen_button"
        textbutton "FEET"  style  "screen_button"
        textbutton "CLOSE-UP" action Jump("SHOW_ep4_D_FAP_ANIM_CLOSE")  style "screen_button"
    #hbox:
        #yalign 0.99
        #xalign 0.02
        #spacing 40
        #textbutton "Prone" style  "screen_button"
        #textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV")  style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Jump("ep4_bed_D_FAP_finish")  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"

screen SHOW_ep4_D_FAP_ANIM_CLOSE():
    tag ss_anim_screen
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1)  style "screen_button"
        textbutton "Normal" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2)  style "screen_button"
        textbutton "Fast" action SetVariable("load_rate", 0.011),SetVariable("load_rate_level", 3)  style "screen_button"
        textbutton "Squeeze" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4)  style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "SIDE" action Jump("SHOW_ep4_D_FAP_ANIM_SIDE")  style "screen_button"
        textbutton "FEET" action Jump("SHOW_ep4_D_FAP_ANIM_FOOT")  style "screen_button"
        textbutton "CLOSE-UP"   style  "screen_button"
    #hbox:
        #yalign 0.99
        #xalign 0.02
        #spacing 40
        #textbutton "Prone" style  "screen_button"
        #textbutton "Ride" action Jump("SHOW_ep3_Emily_ride_A1_ANIM_POV")  style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Jump("ep4_bed_D_FAP_finish")  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"

scene ep4_D_FAP_ANIM_SIDE with dissolve

label SHOW_ep4_D_FAP_ANIM_SIDE:
    scene ep4_D_FAP_ANIM_SIDE with ml
    call screen SHOW_ep4_D_FAP_ANIM_SIDE

label SHOW_ep4_D_FAP_ANIM_FOOT:
    scene ep4_D_FAP_ANIM_FOOT with ml
    call screen SHOW_ep4_D_FAP_ANIM_FOOT

label SHOW_ep4_D_FAP_ANIM_CLOSE: 
    scene ep4_D_FAP_ANIM_CLOSE with ml
    call screen SHOW_ep4_D_FAP_ANIM_CLOSE

label ep4_bed_D_FAP_finish:
    "She's clearly too focused on the movie."
    "This needs to stop!"


label ep4_bed_D_FAP_after:
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    X "Ahem!"
    $renpy.music.play("audio/music/ambient-classical-guitar.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Hotel_D_bed_FAP_B1_FREE_D_Talk_MC with ml
    D "dad!"
    scene ep4_Hotel_D_bed_FAP_B1_POV_D_Talk_MC with fade
    D "...when I turned on the TV there was a movie playing."
    D "Then I just kept watching it."
    "Should've just checked the TV beforehand."
    scene ep4_Hotel_D_bed_FAP_B1_POV_D_Listen_MC
    X "Now it's normal for you to be curious about that stuff."
    X "But you need to try doing it somewhere in private."
    if ep4_hotel_FAP == "seen":
        scene ep4_Hotel_D_bed_FAP_B1_Under_Drip_2 with ml
        X "Or if there's someone you're comfortable with."
        "Wait, should I talk to her about that?"
        "Oh well, she'll need to learn anyway."
        scene ep4_Hotel_D_bed_FAP_B1_POV_D_Talk_MC with ml
    else:
        scene ep4_Hotel_D_bed_FAP_B1_POV_D_Talk_MC
    D "Yes, [Eileen] told me about it, but I felt strange and a little hot down there."
    scene ep4_Hotel_D_bed_FAP_B1_POV_D_Talk_Away with ml
    D "And then I felt like it itched, but not like a normal itch..."
    scene ep4_Hotel_D_bed_FAP_B1_POV_D_Listen_MC
    X "I get it, it's fine!"
    if ep4_hotel_FAP == "seen":
        scene ep4_Hotel_D_bed_FAP_B1_Under_Drip with fade
        "Her hormones must be going wild."
        "Can't just tell her not to do it."
        scene ep4_Hotel_D_bed_FAP_B1_POV_D_Listen_MC with ml
    else:
        pass
    X "Look, whenever you feel the need, try doing it..."
    X "Well, I guess there's not much privacy here."
    X "And doing it in the same room as me would make you feel weird anyway."
    scene ep4_Hotel_D_bed_FAP_B1_POV_D_Talk_Away 
    D "I'm sorry dad."
    scene ep4_Hotel_D_bed_FAP_B1_POV_D_Talk_MC 
    D "I'll be careful from now on."
    scene ep4_Hotel_D_bed_FAP_B1_POV_D_Listen_MC 
    X "Good to hear!"
    X "Now we should get washed up."
    $renpy.music.play("audio/sfx/shower-running-and-stopping-then-water-drain-28981.ogg", channel=u'sound', loop=False)
    scene ep3_Hotel_MC_Bed_Sitting with rightleft
    "Starting to see why this room was vacant."
    "People don't book it unless they plan to do stuff here."
    menu:
        "Check on [D]":
            $ep4_d_shower_look = "yes"
            $D_p += 1
            $D_p_t += 1
            scene ep3_Hotel_D_shower with ml
            pause 1.5
            "Why am I looking?"
            scene ep3_Hotel_MC_Bed_Sitting with ml
            "Not like she would touch herself right now!"
            "I should put some pillows as a precaution."
        "Divide the bed with pillows":
            $ep4_d_shower_look = "no"
            $D_p_t += 1
            "I should put some pillows as a precaution."
    $renpy.music.stop(channel=u'sound', fadeout=None)
    scene ep3_Hotel_D_bed_A1_POV_Bed_Side with fade
    D "What are you doing?"
    X "Yeah about our sleeping situation."
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Listen with topdown
    X "It'll be better with a few pillows between us."
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Talk
    D "I apologize in advance if I hit you."
    scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Listen
    X "And you can wake me up if I snore."
    menu:
        "Kiss her cheek":
            $ep4_d_kiss = "cheek"
            scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Cheek with ml
            X "Goodnight [D]."
            D "Goodnight daddy."
        "Kiss her forehead":
            $ep4_d_kiss = "forehead"
            scene ep3_Hotel_D_bed_A1_POV_Bed_Laying_Forehead with ml
            X "Goodnight [D]."
            D "Goodnight daddy."


    $renpy.music.stop(channel=u'music', fadeout=3.0)
    scene ep1_000_black with fade
    pause 1.5
    "???" "{cps=12}[X]....."
    scene ep3_Hotel_Night_Bed_Look_Window with eye_open
    X "Huh?"
    "Oh right, we're at the hotel."
    "It's a little hot tonight."


$ t_flag.reset
$ t_flag.x1 = 0
$ load_rate = 0.049
$ load_rate_level = 1
$ fanum = 0  
############################################################################################
############################### Bed Grind ################################################
#########################################################################################


init python:
    def ep4_D_bed_Grind_ANIM_POV(load, a, b):
        load.set_child("ep4_Hotel_D_bed_sleep_B1_POV_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 15 and store.load_rate_level == 4:
            store.load_rate = 0.011
        if store.fanum == 75 and load_rate_level == 4:
            store.load_rate = 0.03
        if store.fanum > 119:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value

init python:
    def ep4_D_bed_Grind_ANIM_ACTION(load, a, b):
        load.set_child("ep4_Hotel_D_bed_sleep_B1_Action_ANIM_{}".format(store.fanum))
        store.fanum += 1
        if store.fanum == 15 and store.load_rate_level == 4:
            store.load_rate = 0.011
        if store.fanum == 75 and load_rate_level == 4:
            store.load_rate = 0.03
        if store.fanum > 119:
            store.fanum = 0
        return store.load_rate
    def track_load_rate(value):
        store.load_rate = value



image ep4_D_bed_Grind_ANIM_POV:
    function ep4_D_bed_Grind_ANIM_POV
image ep4_D_bed_Grind_ANIM_ACTION:
    function ep4_D_bed_Grind_ANIM_ACTION
#$ fanum = 0


screen SHOW_ep4_D_bed_Grind_ANIM_POV():
    tag ss_anim_screen
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1)  style "screen_button"
        textbutton "Normal" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2)  style "screen_button"
        textbutton "Fast" action SetVariable("load_rate", 0.011),SetVariable("load_rate_level", 3)  style "screen_button"
        textbutton "Thrust" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4)  style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" style  "screen_button"
        textbutton "CLOSE-UP" action Jump("SHOW_ep4_D_bed_Grind_ANIM_ACTION")  style "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Jump("ep4_bed_D_Grind_finish")  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"


screen SHOW_ep4_D_bed_Grind_ANIM_ACTION():
    tag ss_anim_screen
    vbox:
        yalign 0.85
        xalign 0.0
        spacing -5
        textbutton "Slow" action SetVariable("load_rate", 0.049),SetVariable("load_rate_level", 1)  style "screen_button"
        textbutton "Normal" action SetVariable("load_rate", 0.017),SetVariable("load_rate_level", 2)  style "screen_button"
        textbutton "Fast" action SetVariable("load_rate", 0.011),SetVariable("load_rate_level", 3)  style "screen_button"
        textbutton "Thrust" action SetVariable("load_rate", 0.0169),SetVariable("load_rate_level", 4)  style "screen_button"
    hbox:
        yalign 0.93
        xalign 0.01
        spacing 5
        textbutton "POV" action Jump("SHOW_ep4_D_bed_Grind_ANIM_POV")  style "screen_button"
        textbutton "CLOSE-UP"  style  "screen_button"
    hbox:
        yalign 0.99
        xalign 0.02
        spacing 45
        textbutton "CONTINUE" action Jump("ep4_bed_D_Grind_finish")  style "screen_button"
    vbox:
        yalign 0.97
        xalign 0.94
        textbutton _("Hide (H)") action HideInterface()  style "screen_button"
$renpy.music.play("audio/music/for-a-dream-lofi-vibes-216038.ogg", channel=u'music', loop=True, fadein=3)
scene ep4_D_bed_Grind_ANIM_POV with dissolve    
"..."
"Is she humping the pillow?!"
"And why is she naked?"
menu:
    "Stand still":
        $ep4_d_bed_hump = "yes"
        $D_p += 1
        $D_p_t += 1
        "I really should try not to wake her like this."
        jump ep4_bed_grind
    "Turn away":
        $ep4_d_bed_hump = "no"
        $D_p_t += 1
        $renpy.music.stop(channel=u'music', fadeout=1.0)
        scene ep3_Hotel_Night_Bed_Look_Window with ml
        "She's having a wet dream again."
        "I'll just pretend to be sleeping in case she wakes up."
        jump ep4_bed_grind_skip

label ep4_bed_grind:
    pass

label SHOW_ep4_D_bed_Grind_ANIM_POV:
    scene ep4_D_bed_Grind_ANIM_POV with ml
    call screen SHOW_ep4_D_bed_Grind_ANIM_POV

label SHOW_ep4_D_bed_Grind_ANIM_ACTION:
    scene ep4_D_bed_Grind_ANIM_ACTION with ml
    call screen SHOW_ep4_D_bed_Grind_ANIM_ACTION


label ep4_bed_D_Grind_finish:
    hide ss_anim_screen
    $ load_rate = 0.011
    $ load_rate_level = 3
    pause 1.0
    scene ep4_D_bed_Grind_ANIM_ACTION with ml
    D "**mmmm**"
    "Think she's gonna--"
    scene ep4_Hotel_Bed_Night_D_Squirt_A1
    D "**aaaaaah**"
    "...cum."
    scene ep3_Hotel_Night_Bed_Look_Window with ml
    "Well I didn't need to be a part of that..."
    jump ep4_room_morning_last


label ep4_bed_grind_skip:
    jump ep4_room_morning_last

label ep4_room_morning_last:
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    scene ep1_000_black with dissolve
    $renpy.music.play("audio/sfx/door-knock-open-wooden_distant-75899.ogg", channel=u'sound', loop=False)
    pause 1.0
    "Who could that be?"
    $renpy.music.stop(channel=u'sound', fadeout=None)
    $renpy.music.play("audio/music/bathroom-chill-background-music-14977.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Hotel_Room_Mira_POV_Hello with fade
    Mira "Good morning sir."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Listen_1 with ml
    X "Hello!"
    X "Wait... aren't you the girl from the SPA?"
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Package with ml
    Mira "That's right. I have a package for you here."
    scene ep4_Hotel_Mira_Hallway_A1_FREE_Mira_Package with ml
    X "A package?"
    Mira "It was left on the desk with this room number."
    "That's weird."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Listen_2 with ml
    X "Do you know who left it?"
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Talk_1
    Mira "I'm sorry, but I haven't seen the person."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Listen_2 
    X "What time did you find it?"
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Talk_Point with ml
    Mira "When I arrived at my desk, it was there. So during the night, I assume."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Listen_2 
    X "Right."
    X "And does this normally happen?"
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Talk_1
    Mira "No, it is unusual."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Talk_Point 
    Mira "Normally packages are dropped off at the reception."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Talk_1
    Mira "But I assumed it was for the discretion."
    Mira "Given the room you're staying at."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Listen_2 
    X "The room?"
    scene ep4_Hotel_Mira_Hallway_A1_FREE_Mira_Talk_1 with ml
    Mira "This room is usually booked by couples for well..."
    X "Oh right, I get it!"
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Listen_2 with ml
    "Good to have confirmation."
    X "We just had to take it because the hotel was full."
    X "I'm not really in a relationship at the moment."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Talk_1
    Mira "Oh, I see."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Listen_2
    X "Thanks for bringing it then."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Talk_1
    Mira "My pleasure sir."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Talk_Point
    Mira "If there's anything I can help with, you will find me at the SPA."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Listen_2
    X "Got it."
    scene ep4_Hotel_Mira_Hallway_A1_POV_Mira_Leave with ml
    Mira "Enjoy your stay!"
    scene ep4_Hotel_Day_MC_Phone_POV_Package_Open with ml
    "Did [Charlie] drop this?"
    "I didn't even tell her about the SPA."
    scene ep4_Hotel_Day_MC_Phone_POV_Phone_Hold with ml
    "This looks like the hotel phone--"
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    $renpy.music.play("audio/sfx/telephone-ring-129620.ogg", channel=u'sound', loop=False)
    "..."
    scene ep4_Hotel_Day_MC_Phone_POV_Phone_Talk_1 with ml
    $renpy.music.stop(channel=u'sound', fadeout=None)
    X "Hello?"
    "???" "Good morning [X]."
    X "Who is this?"
    "???" "You don't recognize me?"
    "???" "Well, it has been some time."
    "???" "You really scared my brother the other day."
    pause 1.0
    $renpy.music.play("audio/music/time-138174.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Hotel_Day_MC_Phone_POV_Phone_Talk_2 
    X  "[Maeve]!"
    Maeve "That was quite an impression you made."
    X "How did you find me?"
    Maeve "It's a small town."
    Maeve "How about you join me for a coffee?"
    scene ep4_Hotel_Day_MC_Phone_POV_Phone_Talk_1 with ml
    X "And why would I do that?"
    Maeve "You would be doing it for your dad."
    pause 1.5
    X "Is that so?"
    Maeve "I'll be at the old bar. You know it?"
    X "I remember."
    Maeve "Good, now a gentleman such as yourself wouldn't keep a lady waiting."
    "Can't run away from this one..."
    scene ep4_Hotel_Day_MC_Phone_POV_Phone_Talk_2 
    pause 0.4
    X "Fine, I'll be there."
    "That girl from the SPA."
    "Did she tell her?"
    "Maybe they followed my car or [Charlie]'s."
    scene ep4_Hotel_D_Room_Center_A1_POV_D_Listen with fade
    X "We have to move out today."
    scene ep4_Hotel_D_Room_Center_A1_POV_D_Talk
    D "What happened?"
    scene ep4_Hotel_D_Room_Center_A1_POV_D_Listen
    X "Nothing to worry about, everything's going to be OK."
    X "Now let's pack up."
    scene ep4_City_Drive_FREE_D_Talk with ml
    D "Where are we going?"
    X "A boxing gym that I used to frequent."
    scene ep4_Boxing_Club_Entrance_Khalil_Emil_A1 with ml
    X "Alright, he's here!"
    $renpy.music.stop(channel=u'music', fadeout=3.0)
    scene ep4_Boxing_Club_D_side_ring_A1_POV_Ring_Side_Spar_A1 with ml
    pause 2
    $renpy.music.play("audio/music/upbeat-energetic-rock-186788.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Boxing_Club_D_side_ring_A1_POV_Ring_Side_Spar_A2 with ml
    pause 2
    scene ep4_Boxing_Club_D_side_ring_A1_POV_Ring_Side_Spar_A3 with ml
    pause 1
    X "Hey!"
    scene ep4_Boxing_Club_D_side_ring_A1_POV_Ring_Side_Meet_A1 with ml
    X "You lovebirds got a minute?"
    scene ep4_Boxing_Club_D_side_ring_A1_POV_Ring_Side_Meet_A2
    Khalil "[X]!"
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Talk_1 with ml
    Khalil "Where've you been man?"
    Khalil "Called you, but your phone was dead."
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Listen with ml
    X "I switched it off as a precaution."
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Talk_2 with ml
    Khalil "You said those fucks took your dad?"
    X "Yes, but I got her--"
    scene ep4_Boxing_Club_D_POV_Ring_Side_D_scared_1 with ml
    X "--back."
    X "What's wrong [D]?"
    scene ep4_Boxing_Club_D_FREE_Ring_Side_D_scared with ml
    D "You were fighting."
    X "You mean in the ring?"
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Talk_D with ml
    Khalil "No no, that was just training!"
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Point_Emil with ml
    Khalil "You can tell because [Emil] here was still standing after I landed a hit."
    scene ep4_Boxing_Club_D_POV_Ring_Side_Emil_Reply_Khamil with ml
    Emil "You know it's important to be optimistic here."
    Emil "Even if you won't get a chance to hit in a real fight."
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Listen with ml
    X "Fortunately, there aren't any {i}real{/i} fights in the ring."
    scene ep4_Boxing_Club_D_POV_Ring_Side_Emil_Talk_1
    Emil "Hey come on man!"
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Talk_3
    Khalil "Yeah, that was a low blow!"
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Listen
    X "And we can't have those in boxing now."
    scene ep4_Boxing_Club_D_POV_Ring_Side_Emil_Reply_Khamil
    Emil "Aah! You just walked into that one!"
    scene ep4_Boxing_Club_D_POV_Ring_Side_D_scared_2 with ml
    X "There are a lot of regulations for boxing."
    X "So it takes discipline to do it well."
    scene ep4_Boxing_Club_D_POV_Ring_Side_Khalil_Talk_D with ml
    Khalil "That's right [D]!"
    Khalil "You need self-control to not just punch every punk who makes fun of boxing{w=1}, for example."
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Listen with leftright
    X "...I figured [Eileen] would tell you."
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Talk_2 
    Khalil "Yeah, haven't dropped by the shop lately."
    Khalil "So she just ran away from home?" 
    X "Yeah."
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Talk_1
    Khalil "And the parents sent a guy to get her back."
    Khalil "So he hired [Jerold] to kidnap her and then pretend to rescue her from them?"
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Listen
    X "That's the gist of it."
    X "[Charlie]'s trying to get the guy to talk."
    X "But we don't know if he's the only one after her."
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Talk_1
    Khalil "Wait! Aren't the cops also looking for her?"
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Listen
    X "No, they haven't even filled a missing persons report."
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Talk_3
    Khalil "A rich couple has their kid missing and they DON'T call the police?!"
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Talk_Away
    Khalil "Now that's some real shady shit there!"
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Listen
    X "On top of that, [Maeve] found out where we were at the hotel."
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Talk_1
    Khalil "[Jerold]'s sister?"
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Listen
    X "I'm meeting her at the old bar."
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Talk_2 
    Khalil "Need backup?"
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Listen
    X "No, I need you to look after [D] for me, in case someone comes for her."
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Talk_2 
    Khalil "Alright, but watch out with her, she's a snake!"
    scene ep4_Boxing_Club_Khalil_Bench_A1_POV_Khalil_Listen
    X "I know."
    X "And if something happens and I don't come back, call [Charlie]."
    scene ep4_Boxing_Club_D_side_ring_B1_POV_Listen with rightleft
    X "Hey [D]."
    X "Look, I'll have to be away for a bit."
    scene ep4_Boxing_Club_D_side_ring_B1_POV_Talk 
    D "Where are you going?"
    scene ep4_Boxing_Club_D_side_ring_B1_POV_Listen
    X "Just have to sort something out, nothing to worry about."
    X "I'll need you to wait with the guys here."
    scene ep4_Boxing_Club_D_side_ring_B1_POV_Talk 
    D "How long will you be gone for?"
    scene ep4_Boxing_Club_D_side_ring_B1_POV_Listen 
    X "A few hours probably."
    X "Can you hang around here till then for me?"
    scene ep4_Boxing_Club_D_side_ring_B1_POV_Talk 
    D "I'll wait for you dad."
    scene ep1_000_black with fade
    $renpy.music.play("audio/music/time-138174.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Bar_Mafia_Katerina_Entrance with downtop
    "Is she by herself?"
    scene ep4_Bar_Mafia_Katerina_Table_Approach with dissolve
    "Better be careful."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Drink with ml
    X "What's with the dress, you have a meeting somewhere?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Intro with ml
    Maeve "Only here with you."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1 with ml
    X "Are your goons preparing an ambush?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_1 with ml
    Maeve "Now why would I want to do that?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_Away with ml
    Maeve "We're all alone here."
    Maeve "I've sent the staff away for the day."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2 with ml
    Maeve "So what have you been up to?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1 with ml
    X "Minding my own business, unlike you."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_1
    Maeve "Oh but I am."
    X "Oh, you mean kidnapping my dad! Is that what you're referring to?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2
    Maeve "That was not my idea."
    Maeve "We were told she ran away from home, the task was to bring her back."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_Away with ml
    Maeve "However, my father insisted that [Jerold] resolve it."
    Maeve "And as you probably know, he's not really cut out for this kind of life."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "And you are?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_1
    Maeve "I'd like to think so."
    Maeve "But men just have to be in charge I suppose."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "Are you a feminist now?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2
    Maeve "You don't agree with the cause?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "I doubt your sincerity."
    X "Now how about you get to the point?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_Away with ml
    Maeve "You may recall that, at the warehouse, there was another person with my brother."
    X "Yeah, so?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_1
    Maeve "That was my fiancé."
    X "Oh wow, sorry! Did I ruin something?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2
    Maeve "It was a bad impression for my brother and consequently for the whole family."
    X "So what of it?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_3
    Maeve "I need you to help with something and in doing so, resolve the issue."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "Want me to move some furniture?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2
    Maeve "Something even easier, for you at least."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_Away with ml
    Maeve "You know we organize boxing matches sometimes?"
    X "All legal and fair I'm sure."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_1
    Maeve "Of course."
    Maeve "And normally they just happen to be very profitable."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_3
    Maeve "But there's this one fighter who hasn't been very cooperative."
    Maeve "He's very good, has won every single match till now."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "Wow! What are the odds of that happening?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2
    Maeve "That's the magic word!"
    Maeve "The odds against him aren't very good."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "Yeah, you would need to be pretty stupid to bet against him."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2
    Maeve "And that's where you come in."
    Maeve "I want you to have a match with him, and win of course."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "You want me to fight for you?!"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_1
    Maeve "Now before you make up your mind, this isn't just for my benefit."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_Away with ml
    Maeve "The issue of your dad will have to go to court."
    Maeve "And the judge will decide who she'll be staying with during the trial."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "Yeah, that's true."
    X "Now is that a threat, or am I just not getting the message?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2
    Maeve "Now why would I threaten my ex-boyfriend?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "That was for a few weeks in high school."
    X "You still mad about me leaving you?"
    scene ep4_Bar_Katerina_Meet_A1_FREE_Katarina_Touch_2 with ml
    Maeve "I'll always cherish that time."
    scene ep4_Bar_Katerina_Meet_A1_FREE_Katarina_Touch with ml
    Maeve "You were very... intense back then."
    Maeve "No one has even come close to what you gave me."
    X "How about we catch up some other time?"
    X "Now back to my dad."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_Away with dissolve
    Maeve "Yes, I can make sure she stays with you during the trial."
    X "And if I don't play your game?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_2
    Maeve "Then you'll need to deal with your dad's foster parents on your own."
    Maeve "And with all their funds and connections, I don't see it going very well."
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Listen_1
    X "And all I have to do is win against this guy?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_Away 
    Maeve "Yes, but you'll need to have a few matches beforehand."
    X "Right. Is that all?"
    scene ep4_Bar_Katerina_Meet_A1_POV_Katarina_Talk_1
    Maeve "That's it and give [Charlie] my regards."
    scene ep4_Bar_Mafia_Katerina_Entrance with fade
    pause .5
    $renpy.music.play("audio/music/beach-theme.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_POV_D_Run with leftright
    D "dad!"
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_POV_D_Embrace_Hug with ml
    X "Hey [D]!"
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_POV_D_Embrace_Hug_2 with ml
    X "What's going on, did something happen?"
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_FREE_Hug_1 with ml
    D "No, it's just that I--"
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_Meet with ml
    Carla "I believe she was anxious about being left here."
    X "Oh hello there!"
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_POV_D_Embrace_Talk with ml
    D "You said it's safe but I couldn't help it."
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_POV_D_Embrace_Listen with ml
    X "Did the guys scare you?"
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_POV_D_Embrace_Talk 
    D "No, they were really nice!"
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_POV_D_Embrace_Listen with ml
    X "Good, now I'll really have to be away sometimes."
    X "But you know I made a promise to never abandon you."
    scene ep4_Boxing_Club_D_Carla_side_ring_A1_POV_D_Embrace_Talk 
    D "I know dad."
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_D_Listen with ml
    X "Are you a regular here [Carla]?"
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_Talk_D with ml
    Carla "Yes, and when I walked in today, the boys were goofing around."
    Carla "Then I heard [D] laughing."
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_D_Talk_Carla
    D "They said it was a sketch I think."
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_Talk_D 
    Carla "That's correct."
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_Talk_MC with ml
    Carla "[D] mentioned that there were two men who kidnapped her."
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_D_Listen with ml
    X "That's right."
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_Talk_MC 
    Carla "And they're under arrest now?"
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_D_Listen 
    X "I have a friend in the force, she took them in."
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_D_Listen
    X "Hey [D], what do you think about boxing now, are you still afraid?"
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_D_Talk_MC with ml
    D "No, not anymore! [Khalil] explained the rules to me."
    D "And he said you used to fight too."
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_Carla_D_Listen 
    X "Yeah, it's been a few years though."
    X "You can ask him to show you a few moves. How does that sound?"
    scene ep4_Boxing_Club_D_Carla_side_ring_A2_POV_D_Talk_MC 
    D "Okay!"


    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen with fade
    X "So do you box?"
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_1 with ml
    Carla "Yes, I've been doing it for the past few years."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_Away with ml
    Carla "[D] told me those men took her into a room, tied and gagged her."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen_Away
    X "That's right."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_1 with ml
    Carla "Why did they do that?"
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen
    X "It has to do with her foster parents."
    X "They want her back since she ran away."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_1 
    Carla "And are you sure she hasn't been reported missing?"
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen
    X "I am, we've verified it."
    X "And as far as I'm concerned this proves that she can't go back with them."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_1
    Carla "You mentioned the friend you had in the force."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen
    X "[Charlie], she's the detective investigating [D]'s situation."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_1
    Carla "If they're doing this, you need to confront them directly."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen
    X "I agree, but what worries me is what will happen to [D] if we can't show that they're unfit to raise her."
    X "Can't even prove that she's my dad, for now at least."
    X "And now we can't even go back to the hotel, since they may be tracking my car."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_1
    Carla "What about staying at a friend's?"
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen
    X "They'll probably check all the people I know, so that's also a risk."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_Away with ml
    Carla "That's a problem."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen_Away
    X "Yes, it is."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_2
    Carla "Wait! I have an idea."
    Carla "We've only met recently."
    X "Yeah."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_1
    Carla "If you stayed at my apartment, it's unlikely that they would suspect it."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen
    X "That's asking a lot, I can't have you involved in this!"
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_Away 
    Carla "Well, it does involve a prospective student."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_2
    Carla "And I have the space, so it's not really an issue."
    "Changing hotels isn't a good idea, [Maeve] might have people there."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen
    X "Hate to admit it but that might be the best choice."
    X "Can we stay for a few days till we have a case at least?"
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Talk_2
    Carla "You can stay as long as you need."
    scene ep4_Boxing_Club_Carla_Bench_A1_POV_Carla_Listen
    X "Alright, we'll get ready and come when it gets darker."

    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Hit_Bag with fade
    Khalil "Take it slow like that."
    Khalil "Get used to the motion before putting force in the punch."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Retract with ml
    X "That's good to learn."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Khalil_Listen 
    X "But what about the basic moves to end a fight quickly?"
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Talk_Khalil with ml
    D "It's between the legs, or on the right side of the body."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Khalil_Listen
    X "That's right, if you can't hit the crotch, go for the liver."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_Khalil_Talk_D
    Khalil "And if that doesn't work, you can try attacking the eyes."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Khalil_Listen
    X "Yeah, just throw some dirt in their face."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_Khalil_Talk_D
    Khalil "But always remember to run away if you can."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Khalil_Listen
    X "OK, we can continue this next time. We need to head out."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Talk_Khalil
    D "Thank you for the lessons mister [Khalil]!"
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_Khalil_Talk_D
    Khalil "You are most welcome miss [D]!"
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_Khalil_Talk_MC
    Khalil "And please do take care of your father."
    Khalil "He can sometimes be rather disagreeable."
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_D_Retract
    X "Perhaps you would like a gentlemanly duel next time?"
    scene ep4_Boxing_Club_D_Punching_Bags_A1_POV_Khalil_Talk_MC
    Khalil "I am looking forward to one, yes."
    scene ep1_000_black with dissolve
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    pause 0.5
    scene ep4_Taxi_D_Listen with fade
    X "We're going to [Carla]'s place."
    scene ep4_Taxi_D_Talk 
    D "Did something happen?"
    scene ep4_Taxi_D_Listen
    X "No, it's just a precaution."
    X "Making sure you're safe."
    $renpy.music.play("audio/music/d-house.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Apartment_Carla_Intro_Door with leftright
    Carla "Hello, welcome!"
    scene ep4_Apartment_Carla_Night_Enter with fade
    Carla "This is it, make yourselves at home." 
    Carla "Hope you're hungry, pizza is on the way!"
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_D_Pizza with dissolve
    Carla "A few of the teachers finished reviewing your placement tests."
    Carla "The only issue for now is with math."
    Carla "It's not a big gap, so I spoke with the teacher to let you take another one before the year starts."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Carla_Listen_Pizza with ml
    X "That's convenient, I can help her catch up."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_MC_Pizza with ml
    Carla "It's what I was thinking."
    Carla "But I'm sure you know, not many kids are fond of the subject."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Talk_Carla_Pizza with ml
    D "But I like it!"
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_D_Pizza
    Carla "Really?"
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Carla_Listen_Pizza
    X "I think we can make it, [D]'s a smart girl you know."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_MC_Pizza
    Carla "She did well on all the other tests, including history."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_D_Pizza
    Carla "Did you read about it at home?"
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Talk_Carla_Pizza
    D "There were a few encyclopedias in the library there."
    D "I had fun reading them."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_D_Pizza
    Carla "That's good."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Carla_Listen_Pizza with ml
    X "You can also learn about stuff on TV you know."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Talk_MC_Pizza
    D "Can we do that next time dad?"
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Carla_Listen_Pizza
    X "Whatever you like [D]!"
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_D_Finish with topdown
    Carla "Did you enjoy it?"
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Talk_Carla_Finish 
    D "It was very tasty!"
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_D_Finish 
    Carla "I didn't know your favorite, so I went with a classic Margherita."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Talk_Carla_Finish 
    D "I haven't had any before now."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_D_Finish 
    Carla "Oh, I see."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Carla_Listen_Finish with ml
    X "That's just one more thing we need to {i}ketchup{/i} with."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_Carla_Talk_MC_Finish
    Carla "Just be careful not to get some bad habits along the way."
    scene ep4_Apartment_Carla_Table_Night_A1_POV_D_Carla_Listen_Finish 
    X "We'll be careful."

    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Talk_Hand_MC with rightleft
    Carla "I apologize for the messy room."
    Carla "Haven't had any visitors lately."
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Listen_MC with ml
    X "No worries!"
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Point_Bed with ml
    Carla "You take the bed, I'll use a couch."
    X "We don't want to impose too much, I can take the couch."
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Talk_Hand_MC
    Carla "Nonsense! You aren't imposing on anything!"
    Carla "And there are two couches, so [D] can sleep by herself comfortably."
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Listen_MC 
    D "Thank you miss [Carla]!"
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Talk_MC 
    Carla "Do you need a change of clothes?"
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Listen_MC
    X "That's OK, I brought some for her."
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Talk_MC 
    Carla "Great! I'll go run a bath for [D] then."
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Listen_MC
    X "Thank you!"
    X "Can I use for phone to make a call"
    scene ep4_Apartment_Carla_Bedroom_Night_A1_POV_Charlie_Talk_MC 
    Carla "Of course."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Stand with downtop
    Carla "I put some extra towels, just go in after [D]."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen with ml
    menu:
        "Go in first":
            $ep4_carla_nude = "no"
            $Carla_p_t += 1
            X "Alright."
            
            scene ep4_Apartment_Carla_Night_Look_3 with ml
            "This can't last, we need at least the test to come in."
            scene ep4_Apartment_Carla_MC_Phone with leftright
            Joan "Yes?"
            X "Hey doc, how are the tests coming along?"
            Joan "I was told it should be done in one or two days at most."
            X "Whenever it's ready, just give me a call, no matter the time."
            Joan "Very well."
            jump ep4_Carla_couch_sleep

        "Let [Carla] go first":
            $ep4_carla_nude = "yes"
            $Carla_p += 1
            $Carla_p_t += 1
            X "No, you go in first."
            X "It might end up a little gross since I'm a guy."
            X "Don't want to subject you to that."
            scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_1 with ml
            Carla "Trust me, I can be messier than most men!"
            scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen
            X "In that case, I'll play the 'ladies first' card."
            scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_2 
            Carla "As an exemplary principal, suppose I have to conform now."
            scene ep4_Apartment_Carla_Night_Look_3 with ml
            "This can't last, we need at least the test to come in."
            scene ep4_Apartment_Carla_MC_Phone with leftright
            Joan "Yes?"
            X "Hey doc, how are the tests coming along?"
            Joan "I was told it should be done in one or two days at most."
            X "Whenever it's ready, just give me a call, no matter the time."
            Joan "Very well."
            Carla "**phew**"
            scene ep4_Apartment_Carla_Shower_Towel_Butt with ml
            Carla "Now where did I leave those clean sheets..."
            scene ep4_Apartment_Carla_Shower_Towel_Drop with ml
            Carla "Can't let her sleep in those..."
            "Did she not notice me?"
            pause 0.3
            scene ep4_Apartment_Carla_Shower_Nude_Butt with ml
            Carla "There you are!"
            X "Uhh..."
            scene ep4_Apartment_Carla_Shower_Nude_Surprise
            Carla "[X]!"
            scene ep4_Apartment_Carla_Shower_Nude_Look_Away
            X "Sorry! I was on the phone and--"
            Carla "No, it's my fault!"
            Carla "It just slipped my mind that you were here!"
            Carla "I was looking for clean sheets for [D]."
            X "Ah OK, that's considerate!"
            Carla "You can... go wash up now!"

            jump ep4_Carla_couch_sleep



label ep4_Carla_couch_sleep:
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_2 with rightleft
    Carla "Don't have an extra mattress around."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen
    X "Ah it's nothing, I've even slept on the floor at the office when we had to meet deadlines."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_2
    Carla "Stuck the key in the lock, so if anybody tries to break in they'll need to.. well break in!"
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen
    X "Look [Carla], if there were someone to break in, please don't put yourself in danger or anything."
    X "Although we're probably safe now."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_1 
    Carla "You used to do boxing right?"
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen
    X "Trained when I was in school, and since then I would do the occasional sparring match."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_2
    Carla "[Khalil] did mention he had an old friend who trained with him sometimes."
    X "Yeah that's me."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_1 
    Carla "He emphasized 'old' so I got the impression it was his uncle or something."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen
    X "Really? I'll have to punch him about it next time."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_2
    Carla "And about the incident with [D], any news?"
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen
    X "For now, we're waiting for the paternity test before bringing the case to court."
    X "And interrogating a few people."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_2
    Carla "I was wondering about something."
    Carla "Since they resorted to taking her away by force, isn't that sufficient to win the case?"
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen
    X "It might be, but there's no guarantee she'll be left with me."
    X "And it's likely they have someone in the police, money can buy you anything these days."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_1
    Carla "I have to agree, have my own challenges at school."
    X "With the parents?"
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_2
    Carla "Yes, since they provide most of the school budget, they expect special treatment."
    X "In what way?"
    Carla "They want the teachers to give second chances when students score low on tests."
    Carla "Or to give hints on what will be on the next exam and so on."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_1 
    Carla "They also pay a premium to have exclusive tutoring for their kids."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Listen
    X "All very legal I assume."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Sit_Talk_2
    Carla "Every teacher has a right to select their students. So I can't force them."
    scene ep4_Apartment_Carla_Couch_Night_A1_POV_Stretch with ml
    Carla "You can stay up, I can sleep with the lights on no problem."
    X "No, I'll turn in, it's been a long day."
    $renpy.music.stop(channel=u'music', fadeout=3.0)
    scene ep4_Apartment_Carla_Couch_POV_Carla_Sleep_A1 with fade
    "I need to get some rest..."
    scene ep4_Apartment_Carla_Couch_POV_Carla_Sleep_A1 with dissolve
    scene ep1_000_black with eye_close
    scene ep4_Apartment_Carla_Couch_POV_Empty with fade
    "Where is she?"
    "Could just be using the bathroom."
    "Maybe I'm being too paranoid."
    pause 0.5
    "Better be on the safe side..."
    scene ep4_Apartment_Carla_Balcony_Night_A1_FREE_Door with downtop
    "Oh, there she is."
    $renpy.music.play("audio/music/order-99518.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away with ml
    X "Trouble sleeping?"
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "It's a bad habit of mine."
    Carla "Staying up late to contemplate."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away 
    X "I understand, but can't really relate."
    X "I become a night owl only if I have to code non-stop."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "If you have to work from home, you're always on the clock."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away 
    X "Yeah, free time is just an illusion."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "That's the sad conclusion."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away 
    X "I once read creativity is heightened at night."
    X "The mind probably keeps making up dreams, but we're just receiving them while awake."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "Sounds plausible."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Listen_MC with ml
    X "So what do you usually contemplate?"
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC with ml
    Carla "Mostly about work, and how to help those kids, some deserve much better."
    Carla "Here I thought being a principal I could do a lot more."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC_Hand
    Carla "Turns out it's way harder than it looks."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Listen_MC 
    X "[Alecia] said you were the only who gave a shit about the kids at school."
    X "She probably wouldn't like me telling you that."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "That's a little too harsh."
    Carla "A teacher's salary isn't that good, some are just trying to get a decent living."
    Carla "Maybe even buy a house, but most have to rent."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away 
    X "Yeah, I get that."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC_Hand
    Carla "But don't hold that against her, she has a right to be angry given her situation."
    X "Her situation?"
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "When she was little, her family joined a cult."
    Carla "She had a twin sister and they were both raised in it."
    scene ep4_Apartment_Carla_Balcony_Night_A1_FREE_Face_Talk with ml
    Carla "At some point, the cult leader called everyone to move at a compound in another country."
    Carla "Her parents decided to stay behind, that however didn't really weaken their faith."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Listen_MC with ml
    X "Think I know what cult you might be referring to."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC_Hand
    Carla "Most died by drinking grape juice laced with cyanide."
    X "Yeah I remember."
    Carla "All the family drank, but she spat it out so the poison didn't kill her."
    Carla "She woke up with everyone dead around her."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Listen_MC
    X "That's traumatizing."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC with ml
    Carla "So it impressed me when I heard she agreed to come do more tutoring sessions with you."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Listen_MC 
    X "Well there are a few reasons for that."
    X "But I think a big one is her attachment to [Sophie]."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "Yes, they're very close."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away 
    X "What about [Sophie]'s parents?"
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "Her mother died of cancer several years ago."
    Carla "And her father is in jail."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away 
    X "What is he in for?"
    Carla "Assault, drunk driving and child abuse."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away 
    X "What the hell did he do?"
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC 
    Carla "This was before I became principal."
    Carla "Was keeping [Sophie] after class so she could study in peace and I could also help her out."
    scene ep4_Apartment_Carla_Balcony_Night_A1_FREE_Face_Talk with ml
    Carla "Her father would make her cook, clean and also do errands, so she would stay up late to study."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Look_Away with ml
    Carla "She would fall asleep at school, so one day I pressed her to tell me about it."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC 
    Carla "When she did I thought about calling child services."
    Carla "But he never hit her, not hard enough to cause marks at least."
    Carla "So I just gave her 'detention' instead."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Listen_MC 
    X "Bet he got mad his slave wasn't around."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC 
    Carla "That's right! He came to school one day, drunk as a skunk and started making a scene."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC_Hand 
    Carla "I got worried and stood in front of [Sophie], that's when I got hit."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Listen_MC 
    X "Damn, that's something!"
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC 
    Carla "He got arrested and tried, it was quick since there were many witnesses."
    Carla "I wanted to adopt her after that, but I'm single and busy most of the day, not fit to raise a child."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_Away
    Carla "And [Maya] is an excellent matron."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Talk_MC
    Carla "Then I just started boxing so I wouldn't be so defenseless next time around."
    X "I get it."
    scene ep4_Apartment_Carla_Balcony_Night_A1_POV_Leave with dissolve
    Carla "Going to get some sleep now."
    X "Well you certainly deserve to be in charge!"
    Carla "Thanks."
    X "Oh! Mind if I borrow your phone in the morning?"
    X "Need to make a call."
    Carla "Of course."
    $renpy.music.stop(channel=u'music', fadeout=2.0)
    scene ep1_000_black with dissolve
    pause 1.0
    scene ep4_Apartment_Carla_MC_Phone with fade
    X "Hey [Charlie], it's me!"
    Charlie "Why are you calling from this number?"
    X "Someone found out about me, had to leave."
    Charlie "Shit!"
    Charlie "Are you in a safe place?"
    X "Yes."
    Charlie "OK, we have to meet anyway."
    Charlie "That guy agreed to talk, I need you here to help."
    X "Like now?"
    Charlie "Yes! And it could take some time."
    X "Alright."
    $renpy.music.play("audio/music/sentimental-guitar-and-piano-164254.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Listen with fade
    X "...I need to go alone, and it could take some time."
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Talk
    D "How long?"
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Listen 
    X "A few hours, maybe a day or two. I'm not really sure."
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Hug_Talk with ml
    D "Can I come with you? I won't bother with anything!"
    "Maybe...{w=1} NO!"
    "She needs to stay."
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Hug_Listen
    X "You need to remain here [D]."
    X "You'll be safe, [Carla] will look after you."
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Talk with ml
    D "I-I understand."
    D "I'll be good."
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Listen
    X "If there are any issues, we can contact each other!"
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Talk
    D "Okay dad." 
    scene ep4_Apartment_Carla_Center_Night_B1_POV_D_Hug_Talk with ml
    D "I... I'll wait for you!"
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    scene ep4_Hallway_Charlie_A1_POV_Talk_2 with leftright
    Charlie "...so he agreed to talk."
    scene ep4_Hallway_Charlie_A1_POV_Listen_2
    X "That's fortunate!"
    scene ep4_Hallway_Charlie_A1_POV_Talk_Away
    Charlie "Apparently he's a smoker, so I offered him some cigarettes."
    scene ep4_Hallway_Charlie_A1_POV_Talk_1 with ml
    Charlie "Just pay attention to what he says."
    Charlie "If we catch him with something, I can extend his vacation here."
    scene ep4_Hallway_Charlie_A1_POV_Listen_1
    X "Got it!"
    $renpy.music.play("audio/music/tense-detective-looped-drone-10054.ogg", channel=u'music', loop=True, fadein=5)
    scene ep4_Interrogation_John_A1_FREE_Enter_A1 with fade
    Charlie "I'm sorry, our air conditioning isn't working today."
    scene ep4_Interrogation_John_A1_POV_Enter_A1 with ml
    John "I'm sure you're all doing your best."
    scene ep4_Interrogation_John_A1_POV_Sitting_A1 with ml
    Charlie "How are the smokes?"
    scene ep4_Interrogation_John_Table_A1_FREE_Table_John_Talk_1 with ml
    John "They're on the light side."
    John "I prefer mine with some kick."
    scene ep4_Interrogation_John_Table_A1_FREE_Table_Charlie_Sit with ml
    Charlie "On the subject of kicking..."
    scene ep4_Interrogation_John_Table_A1_FREE_Table_Charlie_Point_Docs with ml
    Charlie "I've noticed you don't have a good track record of stable employment."
    scene ep4_Interrogation_John_Table_A1_FREE_Table_John_Talk_3 with ml
    John "I've always been more of a dilettante."
    John "Blame it on my personality."
    scene ep4_Interrogation_John_Table_A1_FREE_Table_Charlie_Talk_1 with ml
    Charlie "It's not my intention to blame anyone, I'm just looking for answers."
    John "Of course, I'll help with whatever I can."
    scene ep4_Interrogation_John_POV_Questioning_A1 with dissolve
    "This fucking guy..."
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_Charlie_Talk_2 with ml
    Charlie "There are, however, a few people in this industry you seem to have more long-lasting relationships with."
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_John_Talk_3 with ml
    John "I believe you call them... friends?"
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_Charlie_Talk_1 with ml
    Charlie "That's one way to put it, another word could be... business partner."
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_John_Talk_3 with ml
    John "That's two words."
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_Charlie_Talk_2 with ml
    Charlie "Oh my mistake! We struggle with numbers here at the station."
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_John_Talk_2 with ml
    John "Is that why you can't tell me how long I have to remain here?"
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_Charlie_Talk_2 with ml
    Charlie "I just really need you to help me understand what happened at the motel."
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_John_Talk_1 with ml
    John "To repeat myself, I was assaulted and kidnapped, then someone probably called the police and you came to the rescue."
    scene ep4_Interrogation_John_Table_Low_A1_FREE_Table_Low_John_Talk_2
    John "For which I thank you once more."
    scene ep4_Interrogation_John_A1_POV_Answer_A2 with dissolve
    "What a conniving lying bastard!"
    "Should've properly beaten him..."
    scene ep4_Interrogation_John_POV_Questioning_A1 
    Charlie "...and why were you in town?"
    scene ep4_Interrogation_John_A1_POV_Answer_A1 
    John "As I've said, I'm here on business."
    scene ep4_Interrogation_John_POV_Questioning_A1 
    Charlie "What can you tell me about these jobs you've had over the years?"
    scene ep4_Interrogation_John_A1_POV_Answer_A2 
    John "I'm tired detective, but I could use some harder smokes, it could clear my head a bit."
    scene ep4_Interrogation_John_POV_Questioning_A2
    Charlie "I'll see what I can do about that."
    $renpy.music.stop(channel=u'music', fadeout=1.0)
    scene ep4_Hallway_Charlie_A1_POV_Talk_2 with fade
    Charlie "What do you think?"
    scene ep4_Hallway_Charlie_A1_POV_Listen_2
    X "He's just making up shit."
    scene ep4_Hallway_Charlie_A1_POV_Talk_2 
    Charlie "And he's just talking about what's already in the documents."
    scene ep4_Hallway_Charlie_A1_POV_Listen_2
    X "You want me to try getting something from him?"
    scene ep4_Hallway_Charlie_A1_POV_Talk_Away with ml
    Charlie "We have cameras!"
    scene ep4_Hallway_Charlie_A1_POV_Talk_2
    Charlie "And also rules."
    Charlie "He's just stalling now, and I don't have much against him."
    scene ep4_Hallway_Charlie_A1_POV_Talk_1
    Charlie "He also didn't call a lawyer, I imagine he doesn't want this to blow up."
    Charlie "But unless I get something on him, he'll walk free."
    Charlie "Right now I can't do much without involving you and [D]."
    scene ep4_Hallway_Charlie_A1_POV_Listen_2
    X "I want to wait on that."
    X "What about the parents?"
    X "You got a warrant, can't you question them?"
    scene ep4_Hallway_Charlie_A1_POV_Talk_2
    Charlie "I don't have a warrant to enter."
    Charlie "But I could always try questioning them even without one."
    scene ep4_Hallway_Charlie_A1_POV_Listen_2
    X "So why not try it?"
    scene ep4_Hallway_Charlie_A1_POV_Talk_3 with ml
    Charlie "Could be worth it, they might not even know their guy was arrested."
    scene ep4_Hallway_Charlie_A1_POV_Talk_1
    Charlie "We should pay them a visit."
    scene ep4_Hallway_Charlie_A1_POV_Listen_1
    X "We?"
    scene ep4_Hallway_Charlie_A1_POV_Talk_2
    Charlie "Yes, as in you and me."
    scene ep4_Hallway_Charlie_A1_POV_Listen_1
    X "OK then, I'm ready anytime."

    $renpy.music.play("audio/ambience/car-driving-ambience-6365.ogg", channel=u'ambience', loop=True)
    scene ep4_Road_Hill_Charlie_Drive_A1_POV_Talk_Away with fade
    Charlie "...can't trust anyone in the force now."
    Charlie "So you'll have to play deputy."
    scene ep4_Road_Hill_Charlie_Drive_A1_POV_Driving with ml
    X "Sure, I can do that."
    scene ep4_Road_Hill_Charlie_Drive_A1_POV_Talk with ml
    Charlie "Here's the plan."
    Charlie "You're new to the force, and you're here just to observe."
    Charlie "We go in and you pull out a recorder to tape everything."
    scene ep4_Road_Hill_Charlie_Drive_A1_POV_Talk_Away with ml
    Charlie "Now I'll drop hints that I'm looking to be paid off to close this case."
    Charlie "If they take the bait, you stop the recorder and excuse yourself to use the bathroom."
    scene ep4_Road_Hill_Charlie_Drive_A1_POV_Talk with ml
    Charlie "You know where the journal is right?"
    scene ep4_Road_Hill_Charlie_Drive_A1_POV_Driving with ml
    X "Yes, [D] described it very well."
    scene ep4_Road_Hill_Charlie_Drive_A1_POV_Talk_Away with ml
    Charlie "Good! Now once you find it, return and we leave."
    Charlie "Hopefully, we'll have enough to bring a solid case to court."
    scene ep4_Road_Hill_Charlie_Drive_A1_POV_Driving with ml
    X "Got it! "
    $renpy.music.stop(channel=u'ambience', fadeout=None)
    scene ep1_000_black with dissolve
    pause 0.5   
    $renpy.music.play("audio/music/ominous-tension-157906.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_Foster_House_Gate_NIght_POV_Intro with fade
    X "Damn! The place looks bigger than in the photos."
    Charlie "The lights are on, let's see if they're home."
    scene ep4_Foster_House_Gate_NIght_POV_Ring with ml
    pause 0.2
    Charlie "Stick to the plan, don't do anything rash!"
    X "I'll do my best!"
    scene ep4_Foster_House_Gate_NIght_POV_Listen with ml
    pause 0.4
    "???" "Yes?"
    scene ep4_Foster_House_Gate_NIght_POV_Talk
    Charlie "Good evening!"
    Charlie "Is mister [Radford] home?"
    scene ep4_Foster_House_Gate_NIght_POV_Listen
    Radford "You are speaking to him."
    Radford "Who are you?"
    scene ep4_Foster_House_Gate_NIght_POV_Talk
    Charlie "Detective [Charlie], I am here with my partner."
    Charlie "We are on a case about a girl who was reported missing several years ago."
    Charlie "I have looked into your family's files and I believe the girl you adopted is her."
    scene ep4_Foster_House_Gate_NIght_POV_Listen
    Radford "Oh! I was informed about someone looking at our records. So that was you."
    scene ep4_Foster_House_Gate_NIght_POV_Talk
    Charlie "That's right."
    scene ep4_Foster_House_Gate_NIght_POV_Listen
    Radford "And why have you come here?"
    scene ep4_Foster_House_Gate_NIght_POV_Talk
    Charlie "I only need you to confirm the statements in the files."
    Charlie "More of a formality."
    Charlie "It won't take too long. May we come inside?"
    scene ep4_Foster_House_Gate_NIght_POV_Listen
    pause 1.0
    Radford "Uh, yes you may."
    scene ep4_Foster_House_Foyer_Entrance with dissolve
    "Finally get to see who these people are."
    scene ep4_Foyer_Meet_Parents_ALT_FREE_Radford_Intro with fade
    Radford "Good evening, have a seat over there."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "Thank you for allowing us here."
    Charlie "I realize it is late, so I'll try to make this as short as possible."
    scene ep4_Foyer_Meet_Parents_ALT_FREE_Odelia_Intro with ml
    "???" "That would be appreciated!"
    Radford "This is [Odelia], my wife."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "So, how may we help you?"
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Point with ml
    Charlie "Before we begin."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_MC
    Charlie "Would you mind if my partner records our conversation?"
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Smile_MC with ml
    Odelia "We have no issues, go right ahead."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "Thank you."
    Charlie "Several years ago, you adopted a young teen girl named [Emily]. Is that correct?"

    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "After we had lost [Adalinda], our first dad, to illness I had difficulty conceiving."
    Odelia "So we decided to adopt and that's how we found [Emily]."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "Normally people adopt young children, it's uncommon to take in teenagers."
    scene ep4_Foyer_Meet_Parents_ALT_FREE_Odelia_Smile with ml
    Odelia "We felt she was special, and so we took a chance."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_Radford with ml
    Odelia "Then a few months later, we had a surprise."
    scene ep4_Foyer_Meet_Parents_ALT_FREE_Radford_Talk with ml
    Radford "I had a moment of weakness."
    Radford "One night we were outside, I had a little too much to drink and th--"
    scene ep4_Foyer_Meet_Parents_ALT_FREE_Odelia_Smile with ml
    Odelia "She was pregnant!"
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_Radford with ml
    Odelia "Not even half a year after we took her in, we had a baby on the way."
    scene ep4_Foyer_Meet_Parents_POV_Radford_Talk_MC with ml
    Radford "In my defense, she came on to me!"
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Radford_Listen 
    X "Bullshit!"
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_MC with ml
    Carla "[X], calm down!"
    X "Yeah... sorry."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "That's a normal reaction, it's hard to believe he was the victim."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Smile_MC with ml
    Odelia "But once you understand how much of a spineless worm my husband can be. It'll make more sense."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "And what about the incident where she died?"
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "It was terrible!"
    Odelia "Turns out she wanted to run away with the child."
    scene ep4_Foyer_Meet_Parents_POV_Radford_Talk_MC with ml
    Radford "I woke up one night after hearing some noise and saw her."
    scene ep4_Foyer_Meet_Parents_ALT_FREE_Radford_Talk with ml
    Radford "I tried talking but she wouldn't stop, so I went to take my dad away from her."
    "MY dad!"
    Radford "But she struggled and--"
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "She fell down the stairs and hit her head."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "That must've been horrible."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "But you already know from the autopsy report."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "I do. Just curious why you chose to cremate her."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "Our family cemetery is reserved for the actual blood relatives."
    Odelia "And we didn't want to bury her in some faraway place."
    Odelia "This way we can keep her close. In fact, her ashes are on the mantle behind me."
    Charlie "I see."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "And where is [Emily]'s dad, may I speak with her?"
    scene ep4_Foyer_Meet_Parents_ALT_FREE_Odelia_Smile with ml
    Odelia "She is away at my cousin's at the moment, on vacation."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Point with ml
    Charlie "I see, is she staying for the whole summer? It would be nice if I could talk to her."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "Do we really have to?"
    Odelia "She was very little then, she doesn't remember anything."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "I do have enough to close the case."
    Charlie "It would just be more thorough."
    scene ep4_Foyer_Meet_Parents_ALT_FREE_Odelia_Smile with ml
    Odelia "Is that why you also tape the whole conversation?"
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_Fosters with ml
    Charlie "Standard practice, but if you wish we could stop recording."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Talk_MC with ml
    Odelia "Then maybe we can speak off the record for a few minutes."
    Charlie "Of course."
    scene ep4_Foyer_Meet_Parents_Carla_POV_Talk_MC with ml
    Charlie "[X]."
    X "Right."
    scene ep4_Foyer_Meet_Parents_POV_Odelia_Radford_Listen with ml
    X "May I use the bathroom?"
    scene ep4_Foyer_Meet_Parents_POV_Radford_Talk_MC
    Radford "Upstairs, second hallway to the right, last door."
    scene ep1_000_black with dissolve
    pause 0.5
    $renpy.music.play("audio/music/old-dream-198608.ogg", channel=u'music', loop=True, fadein=3)
    scene ep4_House_Foster_Bathroom_ENtrance_A1 with fade
    "Think this is the right one, better work fast."
    scene ep4_House_Foster_Bathroom_ENtrance_A3 with ml
    "She said under the sink."
    scene ep4_House_Foster_Bathroom_A1_FREE_Journal_Hidden with dissolve
    pause 0.3
    "I see something."
    scene ep4_House_Foster_Bathroom_A1_FREE_Journal_Reveal with ml
    "This is it!"
    scene ep4_House_Foster_Bathroom_A2_POV_Journal_Open with ml
    pause 0.5
    X "..."
    "Wait..."   
    scene ep4_House_Foster_Bathroom_A2_POV_Journal_Page_Turn with ml
    pause 0.3
    scene ep4_House_Foster_Bathroom_A2_POV_Journal_Open with ml
    pause 0.7
    scene ep4_House_Foster_Bathroom_A2_POV_Journal_Page_Turn with ml
    pause 0.3
    scene ep4_House_Foster_Bathroom_A2_POV_Journal_Open with ml
    pause 0.3
    "What the hell!?"
    "It's all... empty!"
    "This can't be right!"
    $renpy.music.stop(channel=u'music', fadeout=0.3)
    scene ep4_Foster_House_Bathroom_Door_Open with ml
    "It... maybe it's in another room!"
    scene ep4_House_Foster_Bathroom_Odelia_A1_POV_Odelia_Tazer 
    $renpy.music.play("audio/sfx/electric-sparker-33181.ogg", channel=u'sound', loop=False)
    pause 1.3
    $renpy.music.stop(channel=u'sound', fadeout=None)
    X "**Aaghhhhhh**"
    scene ep4_House_Foster_Bathroom_Odelia_A1_POV_Floor_Ceiling
    X "Fuuuuck..."
    scene ep4_House_Foster_Bathroom_Odelia_A1_POV_Floor_Odelia with ml
    Odelia "Thought you could just come into my home and treat me this way?! The nerve!"
    Odelia "I'll teach you ingrates a lesson..."
    X "{size=-7}[D]{w=0.7}.{w=0.7}.{w=0.7}.{w=1.0} {nw}"
    scene ep1_000_black with curtains_slow_r
    #show screen episode_end
    #menu:
        #"To be continued...":
            #pass
    menu:
        "Continue":
            jump ep5_greenhouse
    ############################################################################################
    ############################################################################################
    #########################################################################################