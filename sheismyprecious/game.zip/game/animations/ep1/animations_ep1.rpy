image ep1_dream_sex = Movie(play="animations/ep1/ep1_dream_emily_sexscene.webm", loop=True,start_image="images/ep1/025_Emily_missionary_LOOP.png", image="images/ep1/025_Emily_missionary_LOOP.png")
image ep1_dream_sex_slow = Movie(play="animations/ep1/ep1_dream_emily_sexscene_slow.webm", loop=True,start_image="images/ep1/025_Emily_missionary_LOOP.png", image="images/ep1/025_Emily_missionary_LOOP.png")
image ep1_dream_sex_finish = Movie(play="animations/ep1/ep1_dream_emily_sexscene_finish.webm",loop=False,start_image="images/ep1/025_Emily_missionary_LOOP.png", image="images/ep1/026_Emily_missionary_inside.png")
image ep1_dream_bird = Movie(play="animations/ep1/ep1_dream_bird.webm",start_image="images/ep1/001_sky.png",loop=False, image="images/ep1/001_sky.png")
image ep1_dream_emily_raise_hand = Movie(play="animations/ep1_dream_emily_raise_hand.webm",loop=False,start_image="images/ep1/007_Emily_side_anim_START.png", image="images/ep1/008_Emily_side_anim_END.png")
image ep1_dream_emily_lower_strap = Movie(play="animations/ep1_dream_emily_lower_strap.webm",loop=False,start_image="images/ep1/013_Emily_strap_anim_START.png", image="images/ep1/014_Emily_strap_anim_END.png")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
