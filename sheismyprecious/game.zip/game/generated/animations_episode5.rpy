init python:

    ANIMATIONS.setdefault(5, {})

    ANIMATIONS[5]['episode5_Alecia_FAP_anim_Close'] = {
        'frames': 80,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Alecia_FAP_anim_Close',
    }

    ANIMATIONS[5]['episode5_Alecia_FAP_anim_Full'] = {
        'frames': 80,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Alecia_FAP_anim_Full',
    }

    ANIMATIONS[5]['episode5_Alecia_FAP_anim_POV'] = {
        'frames': 80,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Alecia_FAP_anim_POV',
    }

    ANIMATIONS[5]['episode5_Alecia_FAP_anim_Side'] = {
        'frames': 80,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Alecia_FAP_anim_Side',
    }

    ANIMATIONS[5]['episode5_D_Altar_anim_Close'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'D_Altar_anim_Close',
    }

    ANIMATIONS[5]['episode5_D_Altar_anim_Full'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'D_Altar_anim_Full',
    }

    ANIMATIONS[5]['episode5_D_Altar_anim_POVf'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'D_Altar_anim_POVf',
    }

    ANIMATIONS[5]['episode5_D_Altar_anim_POVp'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'D_Altar_anim_POVp',
    }

    ANIMATIONS[5]['episode5_D_Joystick_anim_Farm'] = {
        'frames': 61,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'D_Joystick_anim_Farm',
    }

    ANIMATIONS[5]['episode5_D_Joystick_anim_House'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'D_Joystick_anim_House',
    }

    ANIMATIONS[5]['episode5_Eileen_BJ_anim_Close'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_BJ_anim_Close',
    }

    ANIMATIONS[5]['episode5_Eileen_BJ_anim_Left'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_BJ_anim_Left',
    }

    ANIMATIONS[5]['episode5_Eileen_BJ_anim_POV'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_BJ_anim_POV',
    }

    ANIMATIONS[5]['episode5_Eileen_BJ_anim_Right'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_BJ_anim_Right',
    }

    ANIMATIONS[5]['episode5_Eileen_Missionary_anim_Close'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_Missionary_anim_Close',
    }

    ANIMATIONS[5]['episode5_Eileen_Missionary_anim_Full'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_Missionary_anim_Full',
    }

    ANIMATIONS[5]['episode5_Eileen_Missionary_anim_POVf'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_Missionary_anim_POVf',
    }

    ANIMATIONS[5]['episode5_Eileen_Missionary_anim_POVp'] = {
        'frames': 60,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_Missionary_anim_POVp',
    }

    ANIMATIONS[5]['episode5_Eileen_Ride_anim_Close'] = {
        'frames': 61,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_Ride_anim_Close',
    }

    ANIMATIONS[5]['episode5_Eileen_Ride_anim_Front'] = {
        'frames': 61,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_Ride_anim_Front',
    }

    ANIMATIONS[5]['episode5_Eileen_Ride_anim_POV'] = {
        'frames': 61,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_Ride_anim_POV',
    }

    ANIMATIONS[5]['episode5_Eileen_Ride_anim_Side'] = {
        'frames': 61,
        'default_speed': 0.03,
        'default_curve': 'linear',
        'folder': 'Eileen_Ride_anim_Side',
    }
