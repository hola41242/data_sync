

translate russian strings:


    old "Self-voicing disabled."
    new "Самоозвучивание отключено."


    old "Clipboard voicing enabled. "
    new "Озвучивание буфера обмена включено."


    old "Self-voicing enabled. "
    new "Самоозвучивание включено. "


    old "bar"
    new "bar"


    old "selected"
    new "selected"


    old "viewport"
    new "viewport"


    old "horizontal scroll"
    new "horizontal scroll"


    old "vertical scroll"
    new "vertical scroll"


    old "activate"
    new "activate"


    old "deactivate"
    new "deactivate"


    old "increase"
    new "increase"


    old "decrease"
    new "decrease"


    old "Font Override"
    new "Переопределение шрифта"


    old "Default"
    new "По умолчанию"


    old "DejaVu Sans"
    new "DejaVu Sans"


    old "Opendyslexic"
    new "Opendyslexic"


    old "Text Size Scaling"
    new "Масштабирование размера текста"


    old "Reset"
    new "Сбросить"


    old "Line Spacing Scaling"
    new "Масштабирование межстрочного интервала"


    old "High Contrast Text"
    new "Высококонтрастный текст"


    old "Enable"
    new "Включено"


    old "Disable"
    new "Выключено"


    old "Self-Voicing"
    new "Самоозвучивание"


    old "Off"
    new "Выкл"


    old "Text-to-speech"
    new "Текст в речь"


    old "Clipboard"
    new "Буфер обмена"


    old "Debug"
    new "Отладка"


    old "Voice Volume"
    new "Громкость голоса"


    old "Self-Voicing Volume Drop"
    new "Снижение громкости самоозвучивания"


    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Опции в этом меню предназначены для улучшения доступности. Они могут работать не со всеми играми, а некоторые комбинации опций могут сделать игру неиграбельной. Это не проблема игры или движка. Для достижения наилучших результатов при смене шрифтов старайтесь сохранить размер текста таким же, каким он был изначально."


    old "Return"
    new "Назад"


    old "{#weekday}Monday"
    new "{#weekday}Понедельник"


    old "{#weekday}Tuesday"
    new "{#weekday}Вторник"


    old "{#weekday}Wednesday"
    new "{#weekday}Среда"


    old "{#weekday}Thursday"
    new "{#weekday}Четверг"


    old "{#weekday}Friday"
    new "{#weekday}Пятница"


    old "{#weekday}Saturday"
    new "{#weekday}Суббота"


    old "{#weekday}Sunday"
    new "{#weekday}Воскресенье"


    old "{#weekday_short}Mon"
    new "{#weekday_short}Пн"


    old "{#weekday_short}Tue"
    new "{#weekday_short}Вт"


    old "{#weekday_short}Wed"
    new "{#weekday_short}Ср"


    old "{#weekday_short}Thu"
    new "{#weekday_short}Чт"


    old "{#weekday_short}Fri"
    new "{#weekday_short}Пт"


    old "{#weekday_short}Sat"
    new "{#weekday_short}Суб"


    old "{#weekday_short}Sun"
    new "{#weekday_short}Вс"


    old "{#month}January"
    new "{#month}Январь"


    old "{#month}February"
    new "{#month}Февраль"


    old "{#month}March"
    new "{#month}Март"


    old "{#month}April"
    new "{#month}Апрель"


    old "{#month}May"
    new "{#month}Май"


    old "{#month}June"
    new "{#month}Июнь"


    old "{#month}July"
    new "{#month}Июль"


    old "{#month}August"
    new "{#month}Август"


    old "{#month}September"
    new "{#month}Сентябрь"


    old "{#month}October"
    new "{#month}Октябрь"


    old "{#month}November"
    new "{#month}Ноябрь"


    old "{#month}December"
    new "{#month}Декабрь"


    old "{#month_short}Jan"
    new "{#month_short}Янв"


    old "{#month_short}Feb"
    new "{#month_short}Фев"


    old "{#month_short}Mar"
    new "{#month_short}Мар"


    old "{#month_short}Apr"
    new "{#month_short}Апр"


    old "{#month_short}May"
    new "{#month_short}Май"


    old "{#month_short}Jun"
    new "{#month_short}Июн"


    old "{#month_short}Jul"
    new "{#month_short}Июл"


    old "{#month_short}Aug"
    new "{#month_short}Авг"


    old "{#month_short}Sep"
    new "{#month_short}Сен"


    old "{#month_short}Oct"
    new "{#month_short}Окт"


    old "{#month_short}Nov"
    new "{#month_short}Ноя"


    old "{#month_short}Dec"
    new "{#month_short}Дек"


    old "%b %d, %H:%M"
    new "%b %d, %H:%M"


    old "Save slot %s: [text]"
    new "Сохранить слот %s: [text]"


    old "Load slot %s: [text]"
    new "Загрузить слот %s: [text]"


    old "Delete slot [text]"
    new "Удалить слот [text]"


    old "File page auto"
    new "Страница файлов авто"


    old "File page quick"
    new "Страница файлов быстрых"


    old "File page [text]"
    new "Страница файлов [text]"


    old "Page {}"
    new "Страница {}"


    old "Automatic saves"
    new "Автоматические сохранения"


    old "Quick saves"
    new "Быстрые сохранения"


    old "Next file page."
    new "Следующая страница файлов"


    old "Previous file page."
    new "Предыдущая страница файлов"


    old "Quick save complete."
    new "Быстрое сохранение завершено."


    old "Quick save."
    new "Быстрое сохранение"


    old "Quick load."
    new "Быстрая загрузка"


    old "Language [text]"
    new "Язык [text]"


    old "Open [text] directory."
    new "Открыть каталог [text]"


    old "The interactive director is not enabled here."
    new "Интерактивный режиссер здесь не включен."


    old "⬆"
    new "⬆"


    old "⬇"
    new "⬇"


    old "Done"
    new "Готово"


    old "(statement)"
    new "(statement)"


    old "(tag)"
    new "(tag)"


    old "(attributes)"
    new "(attributes)"


    old "(transform)"
    new "(transform)"


    old "(transition)"
    new "(transition)"


    old "(channel)"
    new "(channel)"


    old "(filename)"
    new "(filename)"


    old "Change"
    new "Change"


    old "Add"
    new "Добавить"


    old "Cancel"
    new "Отмена"


    old "Remove"
    new "Удалить"


    old "Statement:"
    new "Statement:"


    old "Tag:"
    new "Tag:"


    old "Attributes:"
    new "Attributes:"


    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Щелкните левой кнопкой, чтобы переключить атрибут, правой кнопкой, чтобы переключить отрицательный атрибут."


    old "Transforms:"
    new "Transforms:"


    old "Click to set transform, right click to add to transform list."
    new "Щелкните левой кнопкой, чтобы установить преобразование, правой кнопкой, чтобы добавить в список преобразований."


    old "Behind:"
    new "Behind:"


    old "Click to set, right click to add to behind list."
    new "Click to set, right click to add to behind list."


    old "Transition:"
    new "Transition:"


    old "Channel:"
    new "Channel:"


    old "Audio Filename:"
    new "Audio Filename:"


    old "Are you sure?"
    new "Вы уверены?"


    old "Are you sure you want to delete this save?"
    new "Вы уверены, что хотите удалить это сохранение?"


    old "Are you sure you want to overwrite your save?"
    new "Вы уверены, что хотите перезаписать это сохранение?"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "При загрузке будет потерян несохранённый прогресс.\nВы уверены, что хотите это сделать?"


    old "Are you sure you want to quit?"
    new "Вы уверены, что хотите выйти?"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Вы уверены, что хотите вернуться в главное меню?\nЭто приведёт к потере несохраненного прогресса."


    old "Are you sure you want to end the replay?"
    new "Вы уверены, что хотите закончить повтор?"


    old "Are you sure you want to begin skipping?"
    new "Вы уверены, что хотите начать пропускать?"


    old "Are you sure you want to skip to the next choice?"
    new "Вы уверены, что хотите перейти к следующему выбору?"


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Вы уверены, что хотите пропустить непрочитанный текст и перейти к следующему выбору?"


    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Это сохранение было создано на другом устройстве. Вредоносные файлы сохранения могут нанести вред вашему компьютеру. Доверяете ли вы создателю этого сохранения и всем, кто мог изменить файл?"


    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "Доверяете ли вы устройству, на котором было создано сохранение? Выбирайте \"Да\" только в том случае, если вы являетесь единственным пользователем устройства."


    old "Failed to save screenshot as %s."
    new "Не удалось сохранить скриншот как %s."


    old "Saved screenshot as %s."
    new "Cкриншот сохранён как %s."


    old "Skip Mode"
    new "Режим пропуска"


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Эта программа содержит свободное программное обеспечение под несколькими лицензиями, включая MIT License и GNU Lesser General Public License. Полный список программ, включая ссылки на полные исходные тексты, можно найти {a=https://www.renpy.org/l/license}здесь{/a}."


    old "display"
    new "display"


    old "transitions"
    new "transitions"


    old "skip transitions"
    new "skip transitions"


    old "video sprites"
    new "video sprites"


    old "show empty window"
    new "show empty window"


    old "text speed"
    new "text speed"


    old "joystick"
    new "joystick"


    old "joystick..."
    new "joystick..."


    old "skip"
    new "skip"


    old "skip unseen [text]"
    new "skip unseen [text]"


    old "skip unseen text"
    new "skip unseen text"


    old "begin skipping"
    new "begin skipping"


    old "after choices"
    new "after choices"


    old "skip after choices"
    new "skip after choices"


    old "auto-forward time"
    new "auto-forward time"


    old "auto-forward"
    new "auto-forward"


    old "Auto forward"
    new "Auto forward"


    old "auto-forward after click"
    new "auto-forward after click"


    old "automatic move"
    new "automatic move"


    old "wait for voice"
    new "wait for voice"


    old "voice sustain"
    new "voice sustain"


    old "self voicing"
    new "self voicing"


    old "self voicing volume drop"
    new "self voicing volume drop"


    old "clipboard voicing"
    new "clipboard voicing"


    old "debug voicing"
    new "debug voicing"


    old "emphasize audio"
    new "emphasize audio"


    old "rollback side"
    new "rollback side"


    old "gl powersave"
    new "gl powersave"


    old "gl framerate"
    new "gl framerate"


    old "gl tearing"
    new "gl tearing"


    old "font transform"
    new "font transform"


    old "font size"
    new "font size"


    old "font line spacing"
    new "font line spacing"


    old "system cursor"
    new "system cursor"


    old "renderer menu"
    new "renderer menu"


    old "accessibility menu"
    new "accessibility menu"


    old "high contrast text"
    new "high contrast text"


    old "audio when minimized"
    new "audio when minimized"


    old "audio when unfocused"
    new "audio when unfocused"


    old "web cache preload"
    new "web cache preload"


    old "voice after game menu"
    new "voice after game menu"


    old "main volume"
    new "main volume"


    old "music volume"
    new "music volume"


    old "sound volume"
    new "sound volume"


    old "voice volume"
    new "voice volume"


    old "mute main"
    new "mute main"


    old "mute music"
    new "mute music"


    old "mute sound"
    new "mute sound"


    old "mute voice"
    new "mute voice"


    old "mute all"
    new "mute all"


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Clipboard voicing enabled. Press 'shift+C' to disable."


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."


    old "Self-voicing enabled. Press 'v' to disable."
    new "Self-voicing enabled. Press 'v' to disable."


    old "Speech Bubble Editor"
    new "Speech Bubble Editor"


    old "(hide)"
    new "(hide)"


    old "Sync downloaded."
    new "Sync downloaded."


    old "Could not connect to the Ren'Py Sync server."
    new "Could not connect to the Ren'Py Sync server."


    old "The Ren'Py Sync server timed out."
    new "The Ren'Py Sync server timed out."


    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "An unknown error occurred while connecting to the Ren'Py Sync server."


    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."


    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."


    old "The sync ID is not in the correct format."
    new "The sync ID is not in the correct format."


    old "The sync could not be decrypted."
    new "The sync could not be decrypted."


    old "The sync belongs to a different game."
    new "The sync belongs to a different game."


    old "The sync contains a file with an invalid name."
    new "The sync contains a file with an invalid name."


    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"


    old "Yes"
    new "Да"


    old "No"
    new "Нет"


    old "Enter Sync ID"
    new "Enter Sync ID"


    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."


    old "Sync Success"
    new "Sync Success"


    old "The Sync ID is:"
    new "The Sync ID is:"


    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."


    old "Sync Error"
    new "Sync Error"


    old "Contacting App Store\nPlease Wait..."
    new "Contacting App Store\nPlease Wait..."


    old "The Ren'Py Updater is not supported on mobile devices."
    new "The Ren'Py Updater is not supported on mobile devices."


    old "An error is being simulated."
    new "An error is being simulated."


    old "Either this project does not support updating, or the update status file was deleted."
    new "Either this project does not support updating, or the update status file was deleted."


    old "This account does not have permission to perform an update."
    new "This account does not have permission to perform an update."


    old "This account does not have permission to write the update log."
    new "This account does not have permission to write the update log."


    old "Could not verify update signature."
    new "Could not verify update signature."


    old "The update file was not downloaded."
    new "The update file was not downloaded."


    old "The update file does not have the correct digest - it may have been corrupted."
    new "The update file does not have the correct digest - it may have been corrupted."


    old "While unpacking {}, unknown type {}."
    new "While unpacking {}, unknown type {}."


    old "Updater"
    new "Updater"


    old "An error has occured:"
    new "An error has occured:"


    old "Checking for updates."
    new "Checking for updates."


    old "This program is up to date."
    new "This program is up to date."


    old "[u.version] is available. Do you want to install it?"
    new "[u.version] is available. Do you want to install it?"


    old "Preparing to download the updates."
    new "Preparing to download the updates."


    old "Downloading the updates."
    new "Downloading the updates."


    old "Unpacking the updates."
    new "Unpacking the updates."


    old "Finishing up."
    new "Finishing up."


    old "The updates have been installed. The program will restart."
    new "The updates have been installed. The program will restart."


    old "The updates have been installed."
    new "The updates have been installed."


    old "The updates were cancelled."
    new "The updates were cancelled."


    old "Proceed"
    new "Proceed"


    old "Image [index] of [count] locked."
    new "Image [index] of [count] locked."


    old "prev"
    new "prev"


    old "next"
    new "next"


    old "slideshow"
    new "slideshow"


    old "return"
    new "return"


    old "Renderer"
    new "Renderer"


    old "Automatically Choose"
    new "Automatically Choose"


    old "Force GL Renderer"
    new "Force GL Renderer"


    old "Force ANGLE Renderer"
    new "Force ANGLE Renderer"


    old "Force GLES Renderer"
    new "Force GLES Renderer"


    old "Force GL2 Renderer"
    new "Force GL2 Renderer"


    old "Force ANGLE2 Renderer"
    new "Force ANGLE2 Renderer"


    old "Force GLES2 Renderer"
    new "Force GLES2 Renderer"


    old "Enable (No Blocklist)"
    new "Enable (No Blocklist)"


    old "Powersave"
    new "Powersave"


    old "Framerate"
    new "Framerate"


    old "Screen"
    new "Screen"


    old "60"
    new "60"


    old "30"
    new "30"


    old "Tearing"
    new "Tearing"


    old "Changes will take effect the next time this program is run."
    new "Changes will take effect the next time this program is run."


    old "Performance Warning"
    new "Performance Warning"


    old "This computer is using software rendering."
    new "This computer is using software rendering."


    old "This game requires use of GL2 that can't be initialised."
    new "This game requires use of GL2 that can't be initialised."


    old "This computer has a problem displaying graphics: [problem]."
    new "This computer has a problem displaying graphics: [problem]."


    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."


    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."


    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "More details on how to fix this can be found in the {a=[url]}documentation{/a}."


    old "Continue, Show this warning again"
    new "Continue, Show this warning again"


    old "Continue, Don't show warning again"
    new "Continue, Don't show warning again"


    old "Change render options"
    new "Изменить параметры рендеринга"


    old "Select Gamepad to Calibrate"
    new "Выбрать геймпад для калибровки"


    old "No Gamepads Available"
    new "Нет доступных геймпадов"


    old "Calibrating [name] ([i]/[total])"
    new "Калибруем [name] ([i]/[total])"


    old "Press or move the '[control!s]' [kind]."
    new "Нажмите или наведитесь на '[control!s]' [kind]."


    old "Skip (A)"
    new "Пропуск (A)"


    old "Back (B)"
    new "Назад (B)"


    old "Open"
    new "Открыть"


    old "Opens the traceback.txt file in a text editor."
    new "Открывает файл traceback.txt в текстовом редакторе."


    old "Copy BBCode"
    new "Скопировать BBCode"


    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Копирует файл traceback.txt в буфер обмена в формате BBcode для форумов, таких как https://lemmasoft.renai.us/."


    old "Copy Markdown"
    new "Скопировать Markdown"


    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Копирует файл traceback.txt в буфер обмена в формате Markdown для Discord."


    old "An exception has occurred."
    new "Произошло исключение."


    old "Rollback"
    new "Откат"


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Попытка отката к предыдущему диалогу, позволяющая сохраниться или сделать другой выбор."


    old "Ignore"
    new "Игнорировать"


    old "Ignores the exception, allowing you to continue."
    new "Игнорирует исключение, позволяя продолжить."


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Игнорирует исключение, позволяя продолжить. Это часто приводит к дополнительным ошибкам."


    old "Reload"
    new "Перезапустить"


    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Перезапускает игру, сохраняя и восстанавливая состояние, если это возможно."


    old "Console"
    new "Консоль"


    old "Opens a console to allow debugging the problem."
    new "Открывает консоль для отладки проблемы."


    old "Quits the game."
    new "Закрывает игру."


    old "Parsing the script failed."
    new "Не удалось выполнить синтаксический анализ скрипта."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
