﻿# TODO: Translation updated at 2024-02-11 21:34

translate russian strings:

    # game/scripts/options.rpy:15
    old "She Is My Precious"
    new "Она - моя драгоценность"

