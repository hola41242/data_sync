

translate russian strings:


    old "She Is My Precious"
    new "Она - моя драгоценность"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
