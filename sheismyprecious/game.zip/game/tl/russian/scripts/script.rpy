translate russian strings:

    old "MC"
    new "ГГ"

    old "Emily's dad"
    new "дочь Эмили"

    old "Emily"
    new "Эмили"

    old "Alecia"
    new "Алесия"

    old "Sophie"
    new "Софи"

    old "Eileen"
    new "Эйлин"

    old "Maya"
    new "Майя"

    old "Carla"
    new "Карла"

    old "Khalil"
    new "Халил"

    old "John"
    new "Джон"

    old "Jimmy"
    new "Джимми"

    old "Charlie"
    new "Шарлотта"

    old "Radford"
    new "Рэдфорд"

    old "Odelia"
    new "Оделия"

    old "Adalinda"
    new "Адалинда"

    old "Joan"
    new "Джоанна"

    old "Jerold"
    new "Джерольд"

    old "Sergio"
    new "Серджио"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
