
translate russian strings:

    old "Episode 2"
    new "Эпизод 2"

    old "Rise to the Occasion"
    new "Оправдать доверие"


translate russian ep2_01_bedroom_cb936564:


    X "Больно?"


translate russian ep2_01_bedroom_2b173986:


    D "Не совсем, просто неудобно."


translate russian ep2_01_bedroom_710d795b:


    X "Как давно он на тебе?"


translate russian ep2_01_bedroom_055c7ef8:


    D "Меня заставили надеть его перед выходом из дома."


translate russian ep2_01_bedroom_63b86955:


    D "Я пылась снять его, потянув вниз, но он слишком плотно сидит."


translate russian ep2_01_bedroom_e6dbab9f:


    X "Пробовала другие способы?"


translate russian ep2_01_bedroom_4f56fd28:


    D "Пыталась сломать, но это ничего не дало."


translate russian ep2_01_bedroom_adaffc5b:


    D "Я видела, как [Odelia] использовала карту, чтобы заблокировать его."


translate russian ep2_01_bedroom_9be4d7c1:


    X "В таком случае у него должен быть какой-то защитный механизм на случай, если он застрянет или что-то в этом роде."


translate russian ep2_01_bedroom_b120c291:


    X "Мне просто нужно найти модель."


translate russian ep2_01_bedroom_beec3fc5:


    D "Хорошо."


translate russian ep2_01_bedroom_8c1245e1:


    X "Могу я... взглянуть на него?"


translate russian ep2_01_bedroom_a7d6fca3:


    D "Конечно!"


translate russian ep2_01_bedroom_37efbc95:


    X "Хммм."


translate russian ep2_01_bedroom_6ab17eab:


    X "Ничего."


translate russian ep2_01_bedroom_422878ad:


    X "Ничего не вижу, может сзади."


translate russian ep2_01_bedroom_5d4d7b46:


    X "Нигде не вижу никаких отметин."


translate russian ep2_01_bedroom_88a0e66f:


    D "Может, они внизу?"


translate russian ep2_01_bedroom_fea5b189:


    X "Возможно. Можешь прилечь?"


translate russian ep2_01_bedroom_75981fe0:


    X "Я что-то вижу, но не могу разобрать, что это."


translate russian ep2_01_bedroom_833150c5:


    X "Хорошо, мне нужно, чтобы ты легла на спину, а затем немного приподняла бедра."


translate russian ep2_01_bedroom_071b3e20:


    D "Ладно..."


translate russian ep2_01_bedroom_ef2381a2:


    "Пояс \"Нет мастурбации\"..."


translate russian ep2_01_bedroom_b40003d5:


    X "Должно быть, это оно!"


translate russian ep2_01_bedroom_fc8ea898:


    X "Теперь можешь встать."


translate russian ep2_01_bedroom_de645035:


    X "Я поищу, просто подожди здесь ещё немного."


translate russian ep2_01_bedroom_f7a451db:


    "Кто, чёрт возьми, эти люди, заставляющие её носить это!"


translate russian ep2_01_bedroom_253845d2:


    "Больные ублюдки..."


translate russian ep2_01_bedroom_1648914e:


    "Он даже не продаётся."


translate russian ep2_01_bedroom_7caa2df8:


    "Я могу продолжить поиски или попробовать другой способ..."


translate russian ep2_01_bedroom_74c9da14:


    "Я попробую ещё раз."


translate russian ep2_01_bedroom_61cc45f3:


    "О, у кого-то такая же проблема!"


translate russian ep2_01_bedroom_313dc1cf:


    "Говорит, что на замке должно быть небольшое отверстие."


translate russian ep2_01_bedroom_53513316:


    "Поиски могут занять слишком много времени."


translate russian ep2_01_bedroom_ee9a7909:


    "Возможно, я смогу найти другой способ..."


translate russian ep2_01_bedroom_f1ac8a61:


    "Я могу использовать смазку."


translate russian ep2_01_bedroom_c7410682:


    "Она всё равно скоро уже просрочится."


translate russian ep2_01_bedroom_lockpick_442c334d:


    X "Я нашел модель. У меня кое-что есть."


translate russian ep2_01_bedroom_lockpick_4301b262:


    X "Ладно, я нашел отверстие, теперь самое сложное."


translate russian ep2_01_bedroom_lockpick_0f69bd49:


    "Там говорилось, что нужно тыкаться, пока не попадёте."


translate russian ep2_01_bedroom_lockpick_302cbfff:


    "Легко..."


translate russian ep2_01_bedroom_lockpick_18975bf8:


    "Может, мне стоит надавить сильнее."


translate russian ep2_01_bedroom_lockpick_ff216961:


    "Давай же..."


translate russian ep2_01_bedroom_lockpick_bf9ab159:


    "Здесь есть отверстие, так что это должно сработать!"


translate russian ep2_01_bedroom_lockpick_253b66ec:


    X "Кажется, я услышал щелчок."


translate russian ep2_01_bedroom_lockpick_ca73fdf1:


    D "Готово?"


translate russian ep2_01_bedroom_lockpick_f87fc419:


    X "Я нажму на кнопку, и мы узнаем это."


translate russian ep2_01_bedroom_lockpick_8cff8fa7:


    "Сначала мне следует отвернуться."


translate russian ep2_01_bedroom_lockpick_c3c8d02e:


    "Это достаточно неловко..."


translate russian ep2_01_bedroom_lockpick_477d41fa:


    X "Вот так!"


translate russian ep2_01_bedroom_lockpick_da41ad8c:


    X "Раз, два."


translate russian ep2_01_bedroom_lockpick_ee36c5c1:


    X "Три..."


translate russian ep2_01_bedroom_lockpick_290b4047:


    D "Он снят!"


translate russian ep2_01_bedroom_lockpick_d85b5b02:


    X "Я пойду собираться. Утром нам всё равно нужно ехать в больницу."


translate russian ep2_01_bedroom_lockpick_477d41fa_1:


    X "Вот так!"


translate russian ep2_01_bedroom_lockpick_da41ad8c_1:


    X "Раз, два."


translate russian ep2_01_bedroom_lockpick_ee36c5c1_1:


    X "Три..."


translate russian ep2_01_bedroom_lockpick_290b4047_1:


    D "Он снят!"


translate russian ep2_01_bedroom_lockpick_d1136a33:


    X "Да, я... вижу это."


translate russian ep2_01_bedroom_lockpick_d85b5b02_1:


    X "Я пойду собираться. Утром нам всё равно нужно ехать в больницу."


translate russian ep2_01_bedroom_lube_e4c92d47:


    X "Я мало что нашёл о нём, так что попробуем провернуть кое-что."


translate russian ep2_01_bedroom_lube_79a76211:


    X "Сначала я сделаю тебя максимально скользкой."


translate russian ep2_01_bedroom_lube_a377fad0:


    X "А затем посмотрим, снимется ли он."


translate russian ep2_01_bedroom_lube_c54d47a3:


    D "Ах!"


translate russian ep2_01_bedroom_lube_b0003076:


    X "Что-то не так?"


translate russian ep2_01_bedroom_lube_0ce24347:


    D "Холодно."


translate russian ep2_01_bedroom_lube_4b114959:


    X "Я знаю, но это пройдет. Просто потерпи."


translate russian ep2_01_bedroom_lube_b01ab803:


    X "Маслу действительно нужно проникнуть внутрь."


translate russian ep2_01_bedroom_lube_0bf661cc:


    X "Испытываешь боль или раздражение?"


translate russian ep2_01_bedroom_lube_c3409cbf:


    D "Нет, но ощущение немного странное."


translate russian ep2_01_bedroom_lube_420fdbe9:


    X "Это нормально, беспокоиться не о чем."


translate russian ep2_01_bedroom_lube_2aff92d3:


    X "Ладно, этого должно быть достаточно, давай попробуем."


translate russian ep2_01_bedroom_lube_2ddcd8d3:


    X "Я чувствую, что он немного ослаблен. Сейчас я буду действовать с небольшим усилием."


translate russian ep2_01_bedroom_lube_871900a5:


    X "Скажи мне, если будет больно!"


translate russian ep2_01_bedroom_lube_8bbc4b12:


    D "Я в порядке."


translate russian ep2_01_bedroom_lube_3cb57faa:


    D "Хорошо, я начинаю!"


translate russian ep2_01_bedroom_lube_8cff8fa7:


    "Сначала мне следует отвернуться."


translate russian ep2_01_bedroom_lube_c3c8d02e:


    "Это достаточно неловко..."


translate russian ep2_01_bedroom_lube_da41ad8c:


    X "Раз, два."


translate russian ep2_01_bedroom_lube_ee36c5c1:


    X "Три..."


translate russian ep2_01_bedroom_lube_290b4047:


    D "Он снят!"


translate russian ep2_01_bedroom_lube_d85b5b02:


    X "Я пойду собираться. Утром нам всё равно нужно ехать в больницу."


translate russian ep2_01_bedroom_lube_da41ad8c_1:


    X "Раз, два."


translate russian ep2_01_bedroom_lube_ee36c5c1_1:


    X "Три..."


translate russian ep2_01_bedroom_lube_290b4047_1:


    D "Он снят!"


translate russian ep2_01_bedroom_lube_d1136a33:


    X "Да, я... вижу это."


translate russian ep2_01_bedroom_lube_d85b5b02_1:


    X "Я пойду собираться. Утром нам всё равно нужно ехать в больницу."


translate russian ep2_02_drive_clinic_9ea0d797:


    "Должен ли я поговить с ней о прошлой ночи?"


translate russian ep2_02_drive_clinic_10d4ae2a:


    X "Эй, насчет ситуации с поясом."


translate russian ep2_02_drive_clinic_6584dbf5:


    D "Да?"


translate russian ep2_02_drive_clinic_94e92af5:


    X "У людей может сложиться неверное представление об этом. Если посмотреть на нашу ситуацию, то она и так непростая."


translate russian ep2_02_drive_clinic_ed61b1e6:


    X "Так что пока нам не следует обо всём этом упоминать. Договорились?"


translate russian ep2_02_drive_clinic_7707b213:


    D "Конечно, я никому не скажу."


translate russian ep2_02_drive_clinic_3c331ca3:


    X "Отлично."


translate russian ep2_02_drive_clinic_493c17b5:


    "Мне, наверное, не нужно ничего говорить по этому поводу."


translate russian ep2_02_drive_clinic_627ec3fd:


    "Она до сих пор скрывала это от меня. Так что она, наверное, понимает, что лучше ничего не говорить."


translate russian ep2_03_clinic_21280427:


    X "Извините!"


translate russian ep2_03_clinic_a91e2d18:


    X "Мы пришли на приём в 9 часов."


translate russian ep2_03_clinic_f3f28ef8:


    "Медсестра" "Момент."


translate russian ep2_03_clinic_d2e6c48b:


    "Медсестра" "Ах да, мистер [X]!"


translate russian ep2_03_clinic_f2d5f183:


    "Медсестра" "У вас назначено обследование вашей дочери."


translate russian ep2_03_clinic_eb7cf3f8:


    X "Верно."


translate russian ep2_03_clinic_e7274394:


    X "Вот она!"


translate russian ep2_03_clinic_bbdb0905:


    "Медсестра" "Отлично! Доктор Джоан уже ждёт вас."


translate russian ep2_03_clinic_d7e5ca87:


    "Медсестра" "Так что можете заходить."


translate russian ep2_03_clinic_844e8ecd:


    X "Доброе утро!"


translate russian ep2_03_clinic_71695033:


    Joan "Доброе утро, присаживайтесь."


translate russian ep2_03_clinic_66311406:


    Joan "Мистер [X], давно не виделись."


translate russian ep2_03_clinic_27bc281a:


    X "Извините, док, был занят путешествиями."


translate russian ep2_03_clinic_d4c02fa6:


    Joan "Я и не знала, что у вас есть дочь."


translate russian ep2_03_clinic_7f5f17a2:


    X "Об этом..."


translate russian ep2_03_clinic_d839bc73:


    X "На самом деле у меня нет никаких документов, подтверждающих это."


translate russian ep2_03_clinic_2d1c431b:


    X "Так что мне нужно что-то, чтобы подтвердить это в суде."


translate russian ep2_03_clinic_4feb4517:


    Joan "Мы можем это сделать."


translate russian ep2_03_clinic_5e79631f:


    Joan "У вас есть постановление суда?"


translate russian ep2_03_clinic_1bc6b4b9:


    X "Пока нет."


translate russian ep2_03_clinic_7e1af614:


    Joan "А мама может прийти на обследование?"


translate russian ep2_03_clinic_978935dd:


    X "В данный момент нет."


translate russian ep2_03_clinic_f9f2504a:


    Joan "Понятно."


translate russian ep2_03_clinic_33b422eb:


    Joan "Мы, конечно, можем это сделать,"


translate russian ep2_03_clinic_d8ace49c:


    Joan "Но поскольку матери рядом нет,"


translate russian ep2_03_clinic_4d7db0b4:


    Joan "А это должно быть приемлемо в суде,"


translate russian ep2_03_clinic_273ae2a3:


    Joan "Это займёт больше времени."


translate russian ep2_03_clinic_ea60b552:


    X "Всё в порядке, если это веское доказательство."


translate russian ep2_03_clinic_79ff1111:


    Joan "Мы проведём самый строгий тест."


translate russian ep2_03_clinic_cea3ea34:


    Joan "Однако, поскольку нет ордера от суда, я не могу гарантировать, что судья примет его."


translate russian ep2_03_clinic_b51bfe2d:


    X "Тогда мы можем просто сделать его снова."


translate russian ep2_03_clinic_4a701d4a:


    Joan "Это сработает. Приступим к осмотру!"


translate russian ep2_03_clinic_b4b930f4:


    Joan "Садись на кушетку, [D]."


translate russian ep2_03_clinic_e4766cc2:


    Joan "Будет немного неприятно, но потерпи."


translate russian ep2_03_clinic_6fbcc7c0:


    Joan "Скажи \"Аааа\"."


translate russian ep2_03_clinic_ce492ff7:


    D "Аааа!"


translate russian ep2_03_clinic_a6db40f0:


    Joan "Боишься уколов?"


translate russian ep2_03_clinic_cbf0aa8f:


    D "Я... я не особо их люблю."


translate russian ep2_03_clinic_7955f839:


    Joan "Испытывать небольшой страх на самом деле очень полезно."


translate russian ep2_03_clinic_914d8a5c:


    X "Я ненавидел их в молодости."


translate russian ep2_03_clinic_f1202a93:


    X "Они были настоящей занозой в заднице!"


translate russian ep2_03_clinic_7507dab0:


    Joan "И судя по тому, что я слышала, вы тоже были медбратом."


translate russian ep2_03_clinic_ed34ba61:


    X "Да ладно!"


translate russian ep2_03_clinic_9f0d159f:


    X "Забыли клятву Гиппократа?"


translate russian ep2_03_clinic_776de564:


    Joan "Те ссоры, которые вы устраивали, на самом деле не были секретом."


translate russian ep2_03_clinic_5d3e3525:


    X "Ладно, справедливо."


translate russian ep2_03_clinic_39437295:


    X "Скажите, док, вы не пробовали брать кровь маркером?"


translate russian ep2_03_clinic_e6424637:


    Joan "Не совсем, но если бы я попыталась применить свои художественные навыки, это было бы... в вену."


translate russian ep2_03_clinic_e95b6b89:


    X "Было ведь не больно, да, [D]?"


translate russian ep2_03_clinic_42d87d05:


    D "Не больно."


translate russian ep2_03_clinic_916442e8:


    Joan "Обычно проблем не возникает."


translate russian ep2_03_clinic_feede064:


    Joan "Но я слышала о человеке, который потерял всю левую половину тела из-за потери крови."


translate russian ep2_03_clinic_39c3cadf:


    X "Серьёзно?!"


translate russian ep2_03_clinic_cfbe773d:


    Joan "Да, но сейчас с ним всё в порядке."


translate russian ep2_03_clinic_9ac6a703:


    X "Это хорошо."


translate russian ep2_03_clinic_3d6c8fb8:


    X "Держу пари, его вторая половина всё ещё чувствует себя ущемлённой, хотя.............."


translate russian ep2_03_clinic_b4307a01:


    X "Следующий врач будет смотреть там, внизу."


translate russian ep2_03_clinic_74f4808c:


    X "Она профессионал, так что беспокоиться не о чем."


translate russian ep2_03_clinic_beec3fc5:


    D "Хорошо."


translate russian ep2_03_clinic_19aa122e:


    "???" "Она ваша дочь?"


translate russian ep2_03_clinic_aa0c3faf:


    X "Да! Она действительно моя дочь."


translate russian ep2_03_clinic_aecbc0f8:


    "???" "Кажется, я ни разу не видела её в школе."


translate russian ep2_03_clinic_b8c7a25d:


    "???" "В каком она классе?"


translate russian ep2_03_clinic_e35ee1eb:


    X "Ещё ни разу там не была."


translate russian ep2_03_clinic_71d6ac94:


    X "Она находится на домашнем обучении."


translate russian ep2_03_clinic_1627f48d:


    "???" "Похоже, вы хотите её зачислить."


translate russian ep2_03_clinic_1b2f5c97:


    X "Да, в процессе."


translate russian ep2_03_clinic_4b687df3:


    X "Вы преподаете в школе?"


translate russian ep2_03_clinic_b8fb4514:


    "???" "Я преподаю историю, хотя сейчас слишком занята как директор."


translate russian ep2_03_clinic_645859b1:


    "Она директор школы и преподает историю. Должно быть, это та самая, о которой говорили девушки."


translate russian ep2_03_clinic_e3f4ae53:


    "Как её звали ещё раз? К....."


translate russian ep2_03_clinic_8a024cb9:


    X "Вас зовут [Carla]?"


translate russian ep2_03_clinic_ce7bdf3a:


    Carla "Именно! Мы знакомы?"


translate russian ep2_03_clinic_d55014f0:


    X "Вас зовут Кэрол?"


translate russian ep2_03_clinic_cc7869da:


    Carla "Близко, меня зовут [Carla]."


translate russian ep2_03_clinic_8747347a:


    Carla "Мы знакомы?"


translate russian ep2_03_clinic_eacbe791:


    X "Вас зовут Карма?"


translate russian ep2_03_clinic_cc7869da_1:


    Carla "Близко, меня зовут [Carla]."


translate russian ep2_03_clinic_8747347a_1:


    Carla "Мы знакомы?"


translate russian ep2_03_clinic_06b7bf01:


    X "Вас зовут Клара?"


translate russian ep2_03_clinic_cc7869da_2:


    Carla "Близко, меня зовут [Carla]."


translate russian ep2_03_clinic_8747347a_2:


    Carla "Мы знакомы?"


translate russian ep2_03_clinic_be919b47:


    X "Я занимался с Алесией и Софи репетиторством, они однажды упомянули вас."


translate russian ep2_03_clinic_8df6b5cb:


    Carla "И вы вспомнили моё имя, это немного впечатляет."


translate russian ep2_03_clinic_181a314d:


    Carla "Вы помогаете Софи с математикой?"


translate russian ep2_03_clinic_da9693c8:


    X "В основном, да."


translate russian ep2_03_clinic_02eec75d:


    Carla "Что ж, приятно это слышать!"


translate russian ep2_03_clinic_b0caeceb:


    Carla "Я давно искала репетитора."


translate russian ep2_03_clinic_b6441ba4:


    "Медсестра" "Мисс [Carla], доктор сейчас вас примет."


translate russian ep2_03_clinic_9c5039b6:


    Carla "Я должна идти."


translate russian ep2_03_clinic_d5e3c5b6:


    Carla "Вероятно, ненадолго. Я слишком сильно ударилась локтём."


translate russian ep2_03_clinic_4e20d1f3:


    Carla "Если вы можете подождать, я бы хотела продолжить наш разговор."


translate russian ep2_03_clinic_4d63f0d3:


    X "Конечно."


translate russian ep2_03_clinic_8337e9b7:


    D "Я вернулась!"


translate russian ep2_03_clinic_1ea360b0:


    X "Всё готово?"


translate russian ep2_03_clinic_9980af74:


    D "Да. Она сказала, что я... поздно расцвела?"


translate russian ep2_03_clinic_7368fc86:


    X "Это проверяется."


translate russian ep2_03_clinic_fbf2a9a0:


    D "Но вроде выглядит всё хорошо."


translate russian ep2_03_clinic_10a1fd3c:


    D "И она должна дождаться результатов других анализов."


translate russian ep2_03_clinic_8be85f50:


    X "Это обнадёживает."


translate russian ep2_03_clinic_09ea29a8:


    Carla "Привет, меня зовут [Carla]!"


translate russian ep2_03_clinic_51e2b053:


    D "Я... [D]!"


translate russian ep2_03_clinic_1485e5ee:


    Carla "Ты, должно быть, голодна."


translate russian ep2_03_clinic_6f52fab1:


    D "Немного."


translate russian ep2_03_clinic_327eae7c:


    Carla "Я знаю одно место, где готовят потрясающие вафли."


translate russian ep2_03_clinic_7e4287d2:


    Carla "Ты любишь их?"


translate russian ep2_03_clinic_dea0849b:


    D "Да!"


translate russian ep2_03_clinic_a952daf6:


    Carla "Если твой папа одобрит, мы можем отправиться туда прямо сейчас."


translate russian ep2_03_clinic_b636acc5:


    X "Эй, я тоже туда хочу!"


translate russian ep2_04_cafe_0f1722ec:


    Carla "Итак, [D], ты вообще ходила в школу?"


translate russian ep2_04_cafe_d6ca01d7:


    D "Нет, у меня были уроки только дома."


translate russian ep2_04_cafe_e416c3fe:


    Carla "Ты играешь с какими-нибудь другими детьми?"


translate russian ep2_04_cafe_6f1d9911:


    D "Помню, к нам приходил родственник."


translate russian ep2_04_cafe_650bfe4a:


    D "Но большую часть дней я была одна."


translate russian ep2_04_cafe_047ee543:


    Carla "Понятно."


translate russian ep2_04_cafe_c3dd3283:


    Carla "В этом случае я советую тебе расслабиться перед началом учебного года."


translate russian ep2_04_cafe_e21f4848:


    Carla "Сейчас проводятся небольшие летние занятия."


translate russian ep2_04_cafe_62933660:


    Carla "Ты можешь ходить на них, чтобы привыкнуть к школе."


translate russian ep2_04_cafe_69163eae:


    X "Они для каждого класса?"


translate russian ep2_04_cafe_05d42c05:


    Carla "Они смешаны из всех классов."


translate russian ep2_04_cafe_7639e2c5:


    X "Разве они не предназначены в основном для проблемных учеников?"


translate russian ep2_04_cafe_227180af:


    Carla "К сожалению, так оно и есть, но есть и те, кто преуспевает среди них."


translate russian ep2_04_cafe_875011d8:


    X "Думаете, это может повлиять на неуспевающих?"


translate russian ep2_04_cafe_f21d4db3:


    Carla "Это одна из причин, по которой я организовала их таким образом."


translate russian ep2_04_cafe_fdbf1d85:


    Alecia "Доброе утро, директор! Что я могу вам сегодня предложить?"


translate russian ep2_04_cafe_b6d5e50e:


    X "И кстати, о неуспевающих!"


translate russian ep2_04_cafe_0e9e9d52:


    Alecia "[X]?!"


translate russian ep2_04_cafe_d051a085:


    X "Привет, [Alecia]. Похоже, ты нашла работу на лето?"


translate russian ep2_04_cafe_e7d46e34:


    Alecia "Да, просто готовлюсь к своему будущему как неуспевающая."


translate russian ep2_04_cafe_65212634:


    Alecia "Мы не можем все быть такими отличницами, как вы."


translate russian ep2_04_cafe_1187bd37:


    X "Звучит забавно, учитывая, что меня чуть не исключили, а в итоге оставили на второй год."


translate russian ep2_04_cafe_7f546aa3:


    Alecia "Что?"


translate russian ep2_04_cafe_21c599f0:


    X "Я никогда не получал пятёрок до последнего года обучения в школе."


translate russian ep2_04_cafe_1a0f2532:


    X "Затем я начал получать отличные оценки по математике. Так что ты не слишком далеко ушла."


translate russian ep2_04_cafe_e8dc435e:


    Carla "О, теперь я вспомнила!"


translate russian ep2_04_cafe_66579a78:


    Carla "Вы ввязались в драку и были отстранены за то, что вырубили того парня."


translate russian ep2_04_cafe_08df1604:


    Carla "Потом вернулись и начали ездить на олимпиады."


translate russian ep2_04_cafe_957a4984:


    X "В основном да."


translate russian ep2_04_cafe_db47096d:


    Alecia "Как только вас не выгнали?"


translate russian ep2_04_cafe_0866143d:


    X "Что ж, они сами напросились."


translate russian ep2_04_cafe_6cef5e33:


    Alecia "Они?"


translate russian ep2_04_cafe_dfc691cc:


    X "Я поссорился с бандой, это долгая история."


translate russian ep2_04_cafe_9f323c84:


    X "Кстати, это [D], моя дочь."


translate russian ep2_04_cafe_0cc66a26:


    X "[D], это [Alecia]."


translate russian ep2_04_cafe_97c76620:


    D "Привет! Приятно познакомиться."


translate russian ep2_04_cafe_0bc1fb9f:


    Alecia "Привет!"


translate russian ep2_04_cafe_80b233ff:


    Carla "Мы говорили о том, что [D] начнёт ходить на летние занятия."


translate russian ep2_04_cafe_68d70b18:


    Carla "Ты могла бы показать ей окрестности, она ведь не местная."


translate russian ep2_04_cafe_9a0d4713:


    Alecia "Конечно."


translate russian ep2_04_cafe_a0b4d373:


    Alecia "Подождите, вы сказали, что она ваша дочь?"


translate russian ep2_04_cafe_7df12b8b:


    X "Это... ещё одна долгая история."


translate russian ep2_04_cafe_9fc393be:


    Alecia "Ладно. Так что я могу вам предложить?"


translate russian ep2_04_cafe_631f3b27:


    Carla "Мы пришли сюда за знаменитыми медовыми вафлями."


translate russian ep2_04_cafe_d2d3a8cb:


    Carla "Ещё кофе для [X]..."


translate russian ep2_04_cafe_3c906ec3:


    X "Ещё один кофе, вот."


translate russian ep2_04_cafe_53767074:


    Alecia "Хорошо, сейчас будет."


translate russian ep2_04_cafe_9d6125e1:


    X "И не забывай о нашей сделке."


translate russian ep2_04_cafe_f8725da9:


    Alecia "Конечно, конечно!"


translate russian ep2_04_cafe_9d6c8f93:


    Carla "Что за сделка?"


translate russian ep2_04_cafe_f16aaae4:


    X "У нас есть договорённость, что она хотя бы будет пытаться вникнуть в тему."


translate russian ep2_04_cafe_4c2c53bd:


    Carla "Наверное, убедить её было нелегко."


translate russian ep2_04_cafe_56ec8ded:


    X "Можно сказать, что эта возможность сама представилась мне."


translate russian ep2_04_cafe_9721dda1:


    Carla "В любом случае, [D] может начать заводить друзей."


translate russian ep2_04_cafe_3d45e1ee:


    Carla "Это очень важная часть школьной жизни."


translate russian ep2_04_cafe_3c993e4d:


    D "Не знаю, может, и могу."


translate russian ep2_04_cafe_cb5d0d3c:


    Carla "Конечно, можешь. Ты милая и приятная девушка."


translate russian ep2_04_cafe_3e25731a:


    Carla "Кто не захочет подружиться с тобой?"


translate russian ep2_04_cafe_25cb3fbd:


    X "Да, прошло совсем немного времени, но мы отлично поладили."


translate russian ep2_04_cafe_caed97fe:


    X "Вдобавок ко всему, она потрясающий повар."


translate russian ep2_04_cafe_9dea84f3:


    D "Я просто следую рецепту, это не так уж впечатляет."


translate russian ep2_04_cafe_56b0558f:


    X "Не стоит себя обманывать. Это требует мастерства."


translate russian ep2_04_cafe_9c60b4b9:


    Carla "Тебе нравится готовить, [D]?"


translate russian ep2_04_cafe_6ddfaa90:


    D "Я получаю от этого удовольствие."


translate russian ep2_04_cafe_0c83e52f:


    Carla "Ты сказала, что большую часть времени была одна."


translate russian ep2_04_cafe_d94e7f55:


    Carla "Чем ещё ты занималась?"


translate russian ep2_04_cafe_12f0cd55:


    D "Обычно находилась в саду и ухаживала за растениями."


translate russian ep2_04_cafe_887252e8:


    D "А ещё я там читала."


translate russian ep2_04_cafe_7d3bf2bd:


    Carla "Что читала?"


translate russian ep2_04_cafe_6cbce347:


    D "Мне нравилось читать романы, книги о других местах, других временах."


translate russian ep2_04_cafe_358a5cbb:


    Carla "Любишь исторические книги?"


translate russian ep2_04_cafe_d4e385b3:


    D "Да, встречались действительно интересные."


translate russian ep2_04_cafe_8309eb29:


    Carla "Я сама прочитала несколько интересных книг."


translate russian ep2_04_cafe_bb0047f1:


    Carla "И мне бы хотелось поделиться и обсудить некоторые из них с тобой."


translate russian ep2_04_cafe_41519ebd:


    Carla "А если тебе понадобится помощь с математикой, твой отец может помочь."


translate russian ep2_04_cafe_a6f6aead:


    X "Да, я хорошо разбираюсь в ней. Мне лишь нужно просмотреть текущий материал."


translate russian ep2_04_cafe_e23b58d4:


    X "Прошло мгновение с тех пор, как я учился в школе."


translate russian ep2_04_cafe_5691d03d:


    Carla "О, я могу помочь с этим."


translate russian ep2_04_cafe_b114df1c:


    Carla "Если вы сможете прийти завтра утром, я подготовлю несколько книг."


translate russian ep2_04_cafe_d3c21933:


    Carla "И [D] может сдать вступительные тесты."


translate russian ep2_04_cafe_f802bf37:


    Carla "Что скажешь? Хочешь пойти в школу в этом году?"


translate russian ep2_04_cafe_3a68c8a3:


    D "Да, хочу!"


translate russian ep2_04_cafe_da56585e:


    Carla "Превосходно! Тогда жду вас завтра."


translate russian ep2_04_cafe_20ad0623:


    X "Вас подвезти?"


translate russian ep2_04_cafe_e20cb95a:


    Carla "Нет, мы сами."


translate russian ep2_04_cafe_2d323ef0:


    Carla "Было приятно познакомиться, [D]. Надеюсь увидеть тебя в школе."


translate russian ep2_04_cafe_5d24c3f9:


    D "Спасибо, мисс [Carla]."


translate russian ep2_04_cafe_a3a8f138:


    Carla "Пожалуйста, просто [Carla]."


translate russian ep2_04_cafe_d0bd0b6f:


    Eileen "[X]! Я почти закончила в магазине."


translate russian ep2_04_cafe_d1b3ce20:


    Eileen "Ты свободен позже, чтобы наверстать упущенное, о котором мы говорили?"


translate russian ep2_04_cafe_d71f3e91:


    X "Нам нужно кое-что наверстать, [Eileen]."


translate russian ep2_04_cafe_e43e7de5:


    X "Узнал, что у меня есть дочь."


translate russian ep2_04_cafe_2b91a929:


    Eileen "А? Ты что-то сказал про чью-то дочь?"


translate russian ep2_04_cafe_dc133a03:


    X "Речь идет о моей дочери, дочери [Emily]."


translate russian ep2_04_cafe_b5bd2382:


    Eileen "Что?!"


translate russian ep2_04_cafe_e511b416:


    X "Мы можем сейчас встретиться?"


translate russian ep2_04_cafe_06f97dec:


    Eileen "Приходи в магазин!"


translate russian ep2_05_eileen_d03be6b8:


    Eileen "Привет!"


translate russian ep2_05_eileen_de1d984c:


    Eileen "Я [Eileen]."


translate russian ep2_05_eileen_2a22e409:


    Eileen "Мы с твоим папой старые друзья."


translate russian ep2_05_eileen_5e058de0:


    D "Привет, я [D]."


translate russian ep2_05_eileen_97d23c80:


    Eileen "Ты любишь сладости, [D]?"


translate russian ep2_05_eileen_7f50e911:


    D "Да."


translate russian ep2_05_eileen_ffec5342:


    Eileen "Вот что я тебе скажу: сходи-ка ты в магазин."


translate russian ep2_05_eileen_8028a4eb:


    Eileen "И выбери из меню любой торт, который захочешь."


translate russian ep2_05_eileen_abe65be9:


    Eileen "Что думаешь?"


translate russian ep2_05_eileen_071b3e20:


    D "Окей..."


translate russian ep2_05_eileen_8e1277bc:


    Eileen "А мы с твоим папой пока поболтаем."


translate russian ep2_05_eileen_b94b9e2a:


    Eileen "Что ж, полагаю, мои поздравления!"


translate russian ep2_05_eileen_9deb7ef6:


    Eileen "Как давно ты узнал о ней?"


translate russian ep2_05_eileen_1134accb:


    X "Несколько дней--"


translate russian ep2_05_eileen_93bf9d60:


    Eileen "НЕСКОЛЬКО ДНЕЙ?!"


translate russian ep2_05_eileen_aeaeb51c:


    Eileen "И ты мне не позвонил?!"


translate russian ep2_05_eileen_6cf02450:


    X "Это было сложно переварить, оно просто не укладывалось в моей голове."


translate russian ep2_05_eileen_f8dcbdf8:


    Eileen "Не сомневаюсь. Так не мог бы ты тогда посвятить меня во все подробности?"


translate russian ep2_05_eileen_38682ec0:


    X "Ну, всё началось на пляже..."


translate russian ep2_05_eileen_1da8f462:


    X "...вот такие пироги."


translate russian ep2_05_eileen_98ebcd20:


    Eileen "Значит, ты заставил её надеть твою вонючую одежду?"


translate russian ep2_05_eileen_3dcffe51:


    X "Я бы не допустил этого! Она чистая."


translate russian ep2_05_eileen_1d5a40c5:


    Eileen "В любом случае, ей нужна одежда."


translate russian ep2_05_eileen_16142f50:


    Eileen "Эй, ты выбрала торт?"


translate russian ep2_05_eileen_055e2981:


    D "Да."


translate russian ep2_05_eileen_ffe8071b:


    Eileen "Отлично! А теперь, что скажешь, если мы купим тебе новую одежду?"


translate russian ep2_05_eileen_8fe85446:


    D "Новую одежду?"


translate russian ep2_05_eileen_4eb94e6e:


    Eileen "Именно так."


translate russian ep2_05_eileen_e5291fe0:


    Eileen "И не волнуйся, у меня отличное чувство стиля."


translate russian ep2_05_eileen_863c0b83:


    X "Это правда!"


translate russian ep2_05_eileen_b355fff6:


    Eileen "Тебя никто не спрашивал!"


translate russian ep2_05_eileen_daafaf1f:


    X "Прости..."


translate russian ep2_05_eileen_6961d6e6:


    Eileen "Что-то простое, повседневное и удобное."


translate russian ep2_05_eileen_f803cd92:


    Eileen "Заходи в примерочную, я всё принесу, и ты выберешь то, что тебе понравится."


translate russian ep2_05_eileen_beec3fc5:


    D "Хорошо."


translate russian ep2_05_eileen_16141ff6:


    Eileen "Твоя задача - улыбаться и кивать. Понятно?"


translate russian ep2_05_eileen_7b6a798d:


    X "Да, мэм!"


translate russian ep2_05_eileen_d428182f:


    D "Мне нравится вот это!"


translate russian ep2_05_eileen_7fc54e6c:


    Eileen "Окей, покажись своему отцу."


translate russian ep2_05_eileen_680d95f0:


    D "Что скажешь, пап?"


translate russian ep2_05_eileen_d22c4d07:


    X "Тебе идет!"


translate russian ep2_05_eileen_43b4aa23:


    X "Она очень милая!"


translate russian ep2_05_eileen_9b5bb665:


    X "Просто очаровательна!"


translate russian ep2_05_eileen_754942be:


    "Хаха! Я не должен говорить, что..."


translate russian ep2_05_eileen_cd92f83e:


    X "Мне нравится!"


translate russian ep2_05_eileen_eb6875dd:


    D "Правда?"


translate russian ep2_05_eileen_11bedccc:


    X "Я серьёзно!"


translate russian ep2_05_eileen_29fcd724:


    D "Могу я оставить его себе?"


translate russian ep2_05_eileen_80483223:


    X "Конечно, можешь!"


translate russian ep2_05_eileen_9961e3b2:


    D "Они очень удобные!"


translate russian ep2_05_eileen_a533c61e:


    Eileen "Подтверждаю! У меня дома таких несколько."


translate russian ep2_05_eileen_16da9bd6:


    Eileen "Посмотрим, что думает модный критик."


translate russian ep2_05_eileen_c0f38a7b:


    D "Пап, что думаешь?"


translate russian ep2_05_eileen_fac0a0f7:


    X "Очень красиво, хорошо смотрится, кажется удобным!"


translate russian ep2_05_eileen_9cdd7a0d:


    D "Это немного странно. Ощущение, что на мне вообще ничего нет."


translate russian ep2_05_eileen_2a70c304:


    X "Да... они так себя преподносят!"


translate russian ep2_05_eileen_d1decd10:


    X "И мы здесь для..."


translate russian ep2_05_eileen_6e60d32e:


    Eileen "Нижнего белья, очевидно."


translate russian ep2_05_eileen_be421e3c:


    Eileen "У них здесь качественные вещи."


translate russian ep2_05_eileen_693c241b:


    Eileen "Ты знаешь свой размер бюстгальтера?"


translate russian ep2_05_eileen_cfe60be9:


    D "Не совсем."


translate russian ep2_05_eileen_7d383209:


    Eileen "Тогда мне придется выбирать на глаз."


translate russian ep2_05_eileen_62bd2d2f:


    D "[Eileen]?"


translate russian ep2_05_eileen_3be9a715:


    X "Её здесь нет, у тебя проблема?"


translate russian ep2_05_eileen_8c2836f8:


    D "Бюстгальтер немного маловат, и я не могу расстегнуть его."


translate russian ep2_05_eileen_754ac7c2:


    X "Подожди секунду! Я схожу за ней."


translate russian ep2_05_eileen_7c55a997:


    D "Спасибо!"


translate russian ep2_05_eileen_5104ff94:


    X "Я могу помочь тебе с этим."


translate russian ep2_05_eileen_b3838f4d:


    D "Не знаю, как его расстегнуть. И я не хочу порвать его."


translate russian ep2_05_eileen_9f561ed8:


    X "Тебе придётся потерпеть."


translate russian ep2_05_eileen_789a0f4f:


    X "Я не привык это делать."


translate russian ep2_05_eileen_4f8cbf41:


    D "Я не привыкла носить бюстгальтеры."


translate russian ep2_05_eileen_344dc863:


    X "Эй! У нас есть ещё одна общая черта."


translate russian ep2_05_eileen_701f1ffd:


    X "Кажется, я понял."


translate russian ep2_05_eileen_051a58f7:


    X "Вот так!"


translate russian ep2_05_eileen_8d94f4dd:


    D "Ох!"


translate russian ep2_05_eileen_d8f843dc:


    X "..."


translate russian ep2_05_eileen_1b965aa0:


    X "Я должен..."


translate russian ep2_05_eileen_f175dca5:


    X "...сказать [Eileen], чтобы взяла другой размер."


translate russian ep2_05_eileen_308b91be:


    Eileen "Нравится что-нибудь?"


translate russian ep2_05_eileen_e0c1dd64:


    D "Эммм..."


translate russian ep2_05_eileen_5b239601:


    Eileen "Этого пока хватит."


translate russian ep2_05_eileen_fe43eed3:


    X "Если ты так считаешь, то окей."


translate russian ep2_05_eileen_442d24ce:


    Eileen "[D], дорогая, мы можем идти!"


translate russian ep2_05_eileen_ac7c6ff9:


    D "Да, иду!"


translate russian ep2_05_eileen_b60acb78:


    Eileen "...это был первый раз, когда я увидела, как [Emily] и [X] тусуются."


translate russian ep2_05_eileen_b3b649a9:


    Eileen "Я такая: \"Кто этот преступник? Неужели [Emily] влюбилась в него?\""


translate russian ep2_05_eileen_7ae659fb:


    X "Я помню, как ты всё время пыталась вывести меня из себя."


translate russian ep2_05_eileen_c0946903:


    X "Посмотреть, не вспылю ли я."


translate russian ep2_05_eileen_499d64cb:


    D "Но что, если бы он действительно был вспыльчивым?"


translate russian ep2_05_eileen_10450faa:


    Eileen "Я была готова к этому."


translate russian ep2_05_eileen_126c96fe:


    Eileen "При первом признаке я бы пнула его прямо в промежность."


translate russian ep2_05_eileen_7e82fc62:


    D "Оу!"


translate russian ep2_05_eileen_542ac5e1:


    Eileen "Это хороший ход, если парень угрожает тебе."


translate russian ep2_05_eileen_06ccc799:


    Eileen "Со всей силы, что у тебя есть. Не сдерживайся."


translate russian ep2_05_eileen_fd170487:


    X "Мне повезло, что она одумалась."


translate russian ep2_05_eileen_f2cf52ba:


    Eileen "Я поняла это, когда увидела, как вы двое занимались учёбой."


translate russian ep2_05_eileen_f3d60f5e:


    Eileen "Дурак не смог бы продержаться так долго."


translate russian ep2_05_eileen_0287ef54:


    X "Да, и с [Emily] было непросто."


translate russian ep2_05_eileen_da429f89:


    X "Она обладает способностью заглядывать прямо в душу."


translate russian ep2_05_eileen_50fc6814:


    X "Это трудно объяснить."


translate russian ep2_05_eileen_39e01aaf:


    D "Это то, что заставило тебя влюбиться?"


translate russian ep2_05_eileen_a39732ca:


    X "И не только это, но это одна из главных составляющих."


translate russian ep2_05_eileen_b4f0972d:


    X "Она увидела, что у меня талант к математике, и не рассталась со мной."


translate russian ep2_05_eileen_61916fb7:


    X "У неё было множество причин бросить меня."


translate russian ep2_05_eileen_cc837e04:


    X "Так что я многим ей обязан."


translate russian ep2_05_eileen_5588aaf6:


    X "Кто знает, где бы я сейчас был, если бы не твоя мама."


translate russian ep2_05_eileen_87216ee3:


    Eileen "[D], соус просто восхитительный! Ты должна дать мне рецепт."


translate russian ep2_05_eileen_89dbdfbe:


    D "Рада, что тебе понравилось."


translate russian ep2_05_eileen_74070b80:


    Eileen "Эй, мы с [D] поднимемся наверх и уединимся, чтобы немного поговорить о девичьем."


translate russian ep2_05_eileen_c6347fa4:


    Eileen "А ты вымой посуду!"


translate russian ep2_05_eileen_3eb04490:


    "Я мог бы подслушать..."


translate russian ep2_05_eileen_9996992e:


    "Это не повредит."


translate russian ep2_05_eileen_99046b30:


    Eileen "...эти способы прикосновения."


translate russian ep2_05_eileen_ff37689d:


    Eileen "Кто-нибудь в семье или за её пределами делал это с тобой?"


translate russian ep2_05_eileen_9c8f41aa:


    D "Насколько я помню, нет."


translate russian ep2_05_eileen_d076ad74:


    Eileen "Знаешь, когда девочки растут, их организм начинает выводить кровь каждый месяц или около того."


translate russian ep2_05_eileen_78db3c80:


    Eileen "С тобой такое уже случалось?"


translate russian ep2_05_eileen_42d87d05:


    D "Нет."


translate russian ep2_05_eileen_2d49e6fc:


    Eileen "Хорошо."


translate russian ep2_05_eileen_f6098323:


    Eileen "И ещё: в какой-то момент ты почувствуешь желание прикоснуться к себе там, внизу."


translate russian ep2_05_eileen_686c14d1:


    D "Зачем?"


translate russian ep2_05_eileen_96a7681a:


    Eileen "Узнаешь! Но что бы тебе ни говорили, это совершенно естественно и полезно для здоровья."


translate russian ep2_05_eileen_d871e7dc:


    D "Поняла."


translate russian ep2_05_eileen_e238610f:


    Eileen "Всё будет хорошо, ты же умная девочка."


translate russian ep2_05_eileen_ca23e12d:


    Eileen "О, и последнее. Насчёт соуса..."


translate russian ep2_05_eileen_8bccc2dc:


    "Я должен уважать их частную жизнь."


translate russian ep2_05_eileen_2f357ff0:


    Eileen "Эй, как насчёт того, чтобы открыть ещё одну бутылку?"


translate russian ep2_05_eileen_d39cdc39:


    X "Я в деле."


translate russian ep2_05_eileen_0663459f:


    Eileen "Ты подслушивал наш разговор?"


translate russian ep2_05_eileen_32800284:


    X "Нет, честно!"


translate russian ep2_05_eileen_8302062e:


    Eileen "Тогда расскажу тебе вкратце."


translate russian ep2_05_eileen_18f0d420:


    Eileen "Насколько я поняла, никакого насилия над ней не было."


translate russian ep2_05_eileen_380a30ec:


    Eileen "Месячные ещё не начались."


translate russian ep2_05_eileen_2c8c2114:


    Eileen "А её тело всё ещё растёт."


translate russian ep2_05_eileen_af5d465b:


    X "Прости, не смог удержаться."


translate russian ep2_05_eileen_93bac6b5:


    Eileen "В таком случае, мне не нужно вводить тебя в курс дела."


translate russian ep2_05_eileen_045d104b:


    Eileen "Но ей ещё предстоит повзрослеть."


translate russian ep2_05_eileen_4a26ca2e:


    X "Теперь у неё есть я, так что всё будет хорошо."


translate russian ep2_05_eileen_1024bc32:


    Eileen "Да, но как же [Emily]?"


translate russian ep2_05_eileen_f0690486:


    X "Я никогда не поверю, что она сбежала."


translate russian ep2_05_eileen_8d3f041c:


    Eileen "Да, она бы никогда вот так просто не бросила свою собственную дочь."


translate russian ep2_05_eileen_a1f744f7:


    X "И я беспокоюсь, что она может..."


translate russian ep2_05_eileen_c77d0ec6:


    X "Я просто боюсь худшего."


translate russian ep2_05_eileen_0ca69114:


    Eileen "Ты не можешь так думать, [X]!"


translate russian ep2_05_eileen_78269039:


    Eileen "Ты должен держать себя в руках ради [D]!"


translate russian ep2_05_eileen_dc751bfd:


    X "Знаю."


translate russian ep2_05_eileen_c2e0b5eb:


    X "И [Charlie] занимается этим делом."


translate russian ep2_05_eileen_1f5be62d:


    X "Но это гребаное ожидание просто убивает меня."


translate russian ep2_05_eileen_73987363:


    X "Если бы в этом не был замешан кто-то ещё, я бы уже пошёл туда и вышиб ногой входную дверь."


translate russian ep2_05_eileen_bd11dd65:


    Eileen "Да, и после этого сделал что-то действительно глупое."


translate russian ep2_05_eileen_92e18b53:


    X "Очевидно."


translate russian ep2_05_eileen_a78549b6:


    Eileen "Проклятие! Мы закончили две бутылки."


translate russian ep2_05_eileen_79988d46:


    Eileen "У меня завтра заказы, так что мне пора идти."


translate russian ep2_05_eileen_e0acaa94:


    X "Куда ты так собралась в таком виде?"


translate russian ep2_05_eileen_988984b9:


    X "Переночуй ночь у меня."


translate russian ep2_05_eileen_39362670:


    Eileen "Не надо, я сама."


translate russian ep2_05_eileen_36bdf05e:


    Eileen "Милая у тебя комнатка!"


translate russian ep2_05_eileen_119ac611:


    Eileen "Ох, и кровать такая мягкая, дааа..."


translate russian ep2_05_eileen_8a5f80b4:


    X "Эй, давай, сними хотя бы платье."


translate russian ep2_05_eileen_4bcf86a5:


    X "Завтра ты будешь кричать на меня за то, что я позволил тебе спать в нём."


translate russian ep2_05_eileen_4e834cbd:


    Eileen "Ну ладно, ты угостил меня ужином. Думаю, теперь ты можешь меня раздеть."


translate russian ep2_05_eileen_a66419ba:


    Eileen "О, привет, кровать! Такая же мягкая, как всегда."


translate russian ep2_05_eileen_27750529:


    X "Туалет дальше по коридору. Спокойной ночи, [Eileen]."


translate russian ep2_05_eileen_898c05d2:


    Eileen "Хм? Куда ты уходишь?"


translate russian ep2_05_eileen_138e8888:


    X "Я лягу на диване."


translate russian ep2_05_eileen_be55096b:


    Eileen "Чт..."


translate russian ep2_05_eileen_556d4569:


    "Возможно, сегодня вечером я перебрал."


translate russian ep2_05_eileen_c9d690d4:


    "Жаждущий..."


translate russian ep2_05_eileen_166d7aeb:


    "[Eileen] проснулась. Ей, наверное, лучше."


translate russian ep2_05_eileen_27b40951:


    X "Эй, можешь взять немного--"


translate russian ep2_05_eileen_7b0c7dd5:


    Eileen "Аааа!"


translate russian ep2_05_eileen_066ddd4b:


    Eileen "Ты напугал меня, [X]!"


translate russian ep2_05_eileen_e086f599:


    X "Ага, извини. Просто пришёл за водой."


translate russian ep2_05_eileen_4ddca305:


    X "А ещё на тебе ничего нет."


translate russian ep2_05_eileen_a554c9e9:


    Eileen "Я знаю. Ты хочешь, чтобы я спала в лифчике?"


translate russian ep2_05_eileen_648d52e4:


    Eileen "Видел мои сиськи?"


translate russian ep2_05_eileen_9a3e99bd:


    X "Совсем недавно."


translate russian ep2_05_eileen_9d55efbc:


    Eileen "И что ты делаешь на диване?"


translate russian ep2_05_eileen_3e8cccb1:


    Eileen "Иди в кровать!"


translate russian ep2_05_eileen_33091dcf:


    X "На диване нормально."


translate russian ep2_05_eileen_7bd4ad51:


    Eileen "Не глупи, на кровати много места. А от дивана у тебя будет болеть спина."


translate russian ep2_05_eileen_fdb8e556:


    X "Возможно, ты права."


translate russian ep2_05_eileen_7ceb0c28:


    X "На самом деле никаких проблем. К тому же иногда я становлюсь беспокойным."


translate russian ep2_05_eileen_73747f5d:


    Eileen "Отлично, иди!"


translate russian ep2_05_eileen_handy_6c55b5a4:


    X "Кажется, здесь немного прохладно. Нужно одеяло?"


translate russian ep2_05_eileen_handy_0a6c543c:


    Eileen "Мне нормально."


translate russian ep2_05_eileen_handy_8cf9a6d6:


    X "Уверена?"


translate russian ep2_05_eileen_handy_9644b967:


    Eileen "Ты всё ещё зациклен на том, что я с голой грудью?"


translate russian ep2_05_eileen_handy_7eb94fa0:


    X "Я имею в виду, что мы оба полуголые в одной постели!"


translate russian ep2_05_eileen_handy_eca8d7a4:


    Eileen "Постой! У тебя проблемы со сном из-за меня?"


translate russian ep2_05_eileen_handy_2480e0d2:


    X "Эээ... нет!"


translate russian ep2_05_eileen_handy_3b662cf2:


    Eileen "О, Боже!"


translate russian ep2_05_eileen_handy_ed34ba61:


    X "Эй, да ладно!"


translate russian ep2_05_eileen_handy_b91e1c05:


    Eileen "Работает как обычно или это снова из-за меня?"


translate russian ep2_05_eileen_handy_3c21bc6d:


    X "Ну... я не могу самостоятельно поднять его."


translate russian ep2_05_eileen_handy_6f7cf4b6:


    Eileen "Правда?"


translate russian ep2_05_eileen_handy_0257ac27:


    Eileen "Пробовал ли ты с другими коллегами?"


translate russian ep2_05_eileen_handy_790a8ace:


    X "Ты что, издеваешься надо мной?!"


translate russian ep2_05_eileen_handy_8c6e3c5f:


    X "Если бы прошёл слух, что у меня эректильная дисфункция..."


translate russian ep2_05_eileen_handy_214b9540:


    X "Вся компания бы знала."


translate russian ep2_05_eileen_handy_02fb9716:


    Eileen "Значит, ты не кончал с тех пор, как я позаботилась об этом в прошлый раз?"


translate russian ep2_05_eileen_handy_caa62506:


    X "Ну, у меня были влажные сны, тогда я получил некоторую разрядку."


translate russian ep2_05_eileen_handy_2e3cb297:


    Eileen "И когда они были в последний раз?"


translate russian ep2_05_eileen_handy_c8c46c45:


    X "Не знаю, может быть, два-три месяца назад..."


translate russian ep2_05_eileen_handy_39a6baf9:


    Eileen "Это вредно для здоровья!"


translate russian ep2_05_eileen_handy_daf7317b:


    Eileen "Давай, вытаскивай, я позабочусь о нём!"


translate russian ep2_05_eileen_handy_46771c89:


    X "[Eileen], ты не обязана!"


translate russian ep2_05_eileen_handy_3ad57d3b:


    Eileen "Только посмотри на него! Выглядит готовым взорваться."


translate russian ep2_05_eileen_handy_054bf636:


    X "Ничего, я как-нибудь справлюсь с этим."


translate russian ep2_05_eileen_handy_893e3bde:


    Eileen "Например, пойдёшь к врачу и получишь кучу таблеток?"


translate russian ep2_05_eileen_handy_b0b83ae1:


    Eileen "Когда ты можешь попросить свою подругу применить простое натуральное лечение."


translate russian ep2_05_eileen_handy_a0cbec74:


    Eileen "Я так не думаю!"


translate russian ep2_05_eileen_handy_381e8285:


    X "[Eileen]..."


translate russian ep2_05_eileen_handy_6fa9f974:


    X "Блять!"


translate russian ep2_05_eileen_handy_46d4dcda:


    Eileen "Приятно?"


translate russian ep2_05_eileen_handy_fc680d03:


    X "Ну да..."


translate russian ep2_05_eileen_handy_172f3cca:


    X "Ох!"


translate russian ep2_05_eileen_handy_fff30d06:


    X "Я долго не продержусь."


translate russian ep2_05_eileen_handy_42dd5cad:


    Eileen "И не нужно. Просто выплесни всё, что накопилось."


translate russian ep2_05_eileen_handy_24ec9530:


    X "Черт! Я уже близко!"


translate russian ep2_05_eileen_handy_3b514d51:


    X "О чёрт, я--"


translate russian ep2_05_eileen_handy_acd91df8:


    X "КОНЧАЮ!"


translate russian ep2_05_eileen_handy_acb05c25:


    Eileen "Посмотри на всю эту накопившуюся энергию..."


translate russian ep2_05_eileen_handy_cce5e3c1:


    X "Прости за это."


translate russian ep2_05_eileen_handy_6faa494e:


    Eileen "Не беспокойся."


translate russian ep2_05_eileen_handy_a2365faa:


    Eileen "Я рада, что смогла тебе помочь."


translate russian ep2_05_eileen_handy_60cc21af:


    X "Что ж... спасибо!"


translate russian ep2_05_eileen_handy_7b45579e:


    Eileen "Не за что..."


translate russian ep2_06_school_91f741ee:


    "Лучше прийти в школу пораньше, позже [Carla] может быть занята."


translate russian ep2_06_school_8414f156:


    Carla "Вы пришли! Превосходно!"


translate russian ep2_06_school_cfcc86c9:


    Carla "Пройдёмте в класс."


translate russian ep2_06_school_b00c40a1:


    X "Напиши всё, что знаешь."


translate russian ep2_06_school_325a1585:


    X "И не нервничай."


translate russian ep2_06_school_d871e7dc:


    D "Окей."


translate russian ep2_06_school_2c930b6c:


    X "А я буду снаружи."


translate russian ep2_06_school_32eed147:


    Carla "Здесь вы найдете все необходимые материалы для занятий с [Sophie]."


translate russian ep2_06_school_0fabb72f:


    Carla "Список не полный, но если вы справитесь с ними, будет здорово."


translate russian ep2_06_school_269ba127:


    X "Спасибо за столь большую помощь!"


translate russian ep2_06_school_fff23de0:


    X "А сколько займёт по времени вступительный тест?"


translate russian ep2_06_school_eac061ae:


    Carla "Не более двух часов."


translate russian ep2_06_school_8ff78c1a:


    Carla "В основном проверяем именно базовые знания."


translate russian ep2_06_school_03d5ef53:


    X "Понятно."


translate russian ep2_06_school_49cfcf3f:


    X "И спасибо вам за то, что прилагаете все усилия, чтобы помочь [D]!"


translate russian ep2_06_school_3e1826a0:


    Carla "Это моя работа."


translate russian ep2_06_school_c240fc99:


    X "А как ваш локоть?"


translate russian ep2_06_school_bfcd1f11:


    Carla "Ничего серьёзного, просто нельзя напрягаться."


translate russian ep2_06_school_8e4a7ebf:


    Carla "Мне пора идти. Когда [D] закончит, пусть оставит бумаги на столе."


translate russian ep2_06_school_5560d353:


    Carla "Я заберу их, когда вернусь."


translate russian ep2_06_school_820a4a7c:


    X "Берегите себя!"


translate russian ep2_06_school_ab9046a3:


    X "Ну как ты, [D]?"


translate russian ep2_06_school_155fd725:


    Carla "Почти закончила."


translate russian ep2_06_school_6d6c441b:


    X "Уже? Ты быстрее, чем я думал."


translate russian ep2_06_school_1d1d485f:


    X "[Charlie]! Как ваши дела?"


translate russian ep2_06_school_ab7f6f78:


    Charlie "Я раскопал ещё кое-какую информацию об этих людях."


translate russian ep2_06_school_fc75500b:


    Charlie "Можем позже встретиться и поговорить в парке?"


translate russian ep2_06_school_a034287c:


    X "Конечно."


translate russian ep2_06_school_8534bf96:


    Charlie "И не могли бы вы взять с собой свою дочь?"


translate russian ep2_06_school_e52bbf9d:


    X "Окей..."


translate russian ep2_06_school_fe08658d:


    X "Не проблема."


translate russian ep2_06_school_6b464da5:


    X "Ты не против, если мы сходим в парк, [D]?"


translate russian ep2_06_school_64fb8d0b:


    D "Конечно."


translate russian ep2_06_school_048b8602:


    X "По дороге можем купить мороженое."


translate russian ep2_06_school_0dd4a437:


    X "Есть вкусовые предпочтения?"


translate russian ep2_06_school_a3498d59:


    D "Не особо, но главное, чтобы не мятное!"


translate russian ep2_06_school_8a071e3c:


    X "Хорошо. Мы можем начать с основных вкусов."


translate russian ep2_06_school_68dbdf5e:


    X "Ванильное подойдет?"


translate russian ep2_06_school_7f50e911:


    D "Да."


translate russian ep2_06_school_c7907c40:


    X "Вокруг никого, тихо."


translate russian ep2_06_school_26d7c55d:


    D "Хочешь вишенку?"


translate russian ep2_06_school_e0bf2cd8:


    X "Что?"


translate russian ep2_06_school_d293690c:


    D "Хочешь мою вишенку?"


translate russian ep2_06_school_6bea7fc3:


    X "Конечно, я возьму твою вишенку..."


translate russian ep2_06_school_6f866193:


    X "Нет, можешь оставить себе."


translate russian ep2_06_school_9a964e73:


    X "Тебе нравится?"


translate russian ep2_06_school_c8d2f9ed:


    D "Ага!"


translate russian ep2_06_school_897b5bcf:


    D "Теперь ванильное моё любимое!"


translate russian ep2_06_school_94c4eed6:


    X "Какое было твоим любимым раньше?"


translate russian ep2_06_school_96d4b8ec:


    D "Однажды я пробовала одно, не мятное. Не знаю, как оно называлось."


translate russian ep2_06_school_a14a013a:


    X "Что ж, есть что попробовать. Это будут настоящие приключения!"


translate russian ep2_06_school_e990fb6a:


    D "Ура!"


translate russian ep2_06_school_9fc2c940:


    "Котёнок" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🐱{/font}"


translate russian ep2_06_school_ff18a95b:


    X "Вау, ты только посмотри на него."


translate russian ep2_06_school_be2356f9:


    D "Котёнок!"


translate russian ep2_06_school_9fc2c940_1:


    "Котёнок" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🐱{/font}"


translate russian ep2_06_school_5c838aac:


    D "Привет, малыш! Ты потерялся?"


translate russian ep2_06_school_6b7f912b:


    "Котёнок" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}😺{/font}"


translate russian ep2_06_school_6d8493a6:


    D "Ты голоден?"


translate russian ep2_06_school_9ac28b82:


    Charlie "Это твой котёнок?"


translate russian ep2_06_school_8599d76e:


    D "Мы только что познакомились."


translate russian ep2_06_school_9269a5a0:


    Charlie "И вы уже друзья? Необыкновенно!"


translate russian ep2_06_school_e75390ab:


    Charlie "Кстати, я [Charlie], а ты, должно быть..."


translate russian ep2_06_school_559ea7fb:


    D "[D]"


translate russian ep2_06_school_040875c8:


    Charlie "Приятно познакомиться."


translate russian ep2_06_school_fd495f0b:


    Charlie "Мне нужно немного поговорить с твоим отцом."


translate russian ep2_06_school_68fe6ea1:


    Charlie "Ты можешь остаться здесь и поиграть со своим котёнком?"


translate russian ep2_06_school_071b3e20:


    D "Ладно..."


translate russian ep2_06_school_89e4d8f8:


    Charlie "Красавица."


translate russian ep2_06_school_6a383ecf:


    X "Итак, что вы уже накопали?"


translate russian ep2_06_school_932469e4:


    Charlie "Стал искать информацию о семье."


translate russian ep2_06_school_936b89ec:


    Charlie "Но их записи были засекречены примерно с того времени, когда [Emily] была удочерена."


translate russian ep2_06_school_46f5cd3b:


    Charlie "Да и цифровых следов с тех времён не так уж и много."


translate russian ep2_06_school_be4c40cd:


    Charlie "Всё, что было в архиве, я отправила по факсу."


translate russian ep2_06_school_192008a1:


    X "Что-то выяснилось?"


translate russian ep2_06_school_da2ad726:


    Charlie "Тогда у них был какой-то бизнес, и подробностей о нём не так много."


translate russian ep2_06_school_c2a0843f:


    Charlie "Но я наткнулась на имя - Адалинда."


translate russian ep2_06_school_772be887:


    Charlie "Это была их дочь, она умерла примерно в том же возрасте, что и [Emily]."


translate russian ep2_06_school_a16c2120:


    X "Поэтому они удочерили [Emily], которая была примерно одного с ней возраста, и назвали её именем..."


translate russian ep2_06_school_9babe808:


    Charlie "Чтобы они могли притвориться, что она никогда не умирала. А потом, после рождения [D], переключились на неё."


translate russian ep2_06_school_e90d14f7:


    X "Это просто пиздец!"


translate russian ep2_06_school_19406ce5:


    Charlie "Вот как-то так."


translate russian ep2_06_school_854086ad:


    Charlie "Так что мне нужен ордер, чтобы просмотреть все записи."


translate russian ep2_06_school_d9fe11ec:


    X "В процессе удочерения они также использовали вымышленные имена!"


translate russian ep2_06_school_5306a750:


    X "Это должно сыграть против них."


translate russian ep2_06_school_4d6159fb:


    Charlie "Определённо!"


translate russian ep2_06_school_ec9070db:


    Charlie "Но сначала я должна прояснить несколько моментов."


translate russian ep2_06_school_9f2e8296:


    X "Каких?"


translate russian ep2_06_school_7d1dcb70:


    Charlie "Ваша дочь сказала, что была в пути около недели, прежде чем добралась до пляжа."


translate russian ep2_06_school_168b6d93:


    X "Да."


translate russian ep2_06_school_0dcc6187:


    Charlie "Но до сих пор не было ни одного заявления о пропаже человека."


translate russian ep2_06_school_a6878d17:


    X "Учитывая всё то дерьмо, которое они с ней сделали, я сомневаюсь, что они его подадут."


translate russian ep2_06_school_5ad79f51:


    Charlie "Может быть и так."


translate russian ep2_06_school_b3a2b997:


    Charlie "Она также упомянула о дневнике [Emily], которого у неё нет."


translate russian ep2_06_school_bb5a05e8:


    X "Больше при ней ничего не было."


translate russian ep2_06_school_d153a72e:


    Charlie "Она училась на дому, росла в изоляции и каким-то образом смогла добраться сюда."


translate russian ep2_06_school_85e6a731:


    X "Да, общественный транспорт - тот ещё ад!"


translate russian ep2_06_school_28f91a0e:


    X "А ещё я сдал тест на ДНК, так что у нас будут веские доказательства."


translate russian ep2_06_school_c10d958b:


    Charlie "Это хорошо, но это займёт некоторое время."


translate russian ep2_06_school_813e0a40:


    Charlie "Если вся её история правдива и нет заявления о пропаже человека..."


translate russian ep2_06_school_9312972e:


    Charlie "Значит, у них есть свои люди, которые ищут её."


translate russian ep2_06_school_fd8544dd:


    Charlie "А значит, чем дольше мы будем ждать, тем больше вероятность, что они найдут её."


translate russian ep2_06_school_d2a7b328:


    Charlie "Итак, [X], мне нужно, чтобы вы были абсолютно уверены в ней."


translate russian ep2_06_school_af524752:


    Charlie "Я многое поставила на карту ради этого дела."


translate russian ep2_06_school_a77ed4b4:


    X "Я не сомневаюсь в ней ни на секунду!"


translate russian ep2_06_school_79f4160b:


    X "Она. Моя. Дочь!"


translate russian ep2_06_school_7f0916db:


    Charlie "Ладно, тогда мы идём ва-банк!"


translate russian ep2_06_school_5edafc3b:


    Charlie "Никогда не видела, чтобы кто-то так хорошо обращался с животными."


translate russian ep2_06_school_0327dfaf:


    D "Я всегда стараюсь подружиться с ними."


translate russian ep2_06_school_f254c400:


    Charlie "Это просто очаровательно."


translate russian ep2_06_school_79f66fd3:


    Charlie "Ждите моего звонка. И позаботьтесь о ней."


translate russian ep2_06_school_8e84d7b9:


    X "Конечно."


translate russian ep2_06_school_da9d8f4f:


    X "И спасибо вам!"


translate russian ep2_06_school_7f3eb8b2:


    Charlie "Не стоит благодарности."


translate russian ep2_06_school_324948c9:


    X "Пойдём?"


translate russian ep2_06_school_06fd8134:


    D "Ага."


translate russian ep2_06_school_2f0800b2:


    X "Уверена?"


translate russian ep2_06_school_dea0849b:


    D "Да!"


translate russian ep2_06_school_ece5a994:


    X "Хорошо..."


translate russian ep2_06_school_cd09bc91:


    X "Эй, [D], ты закончила переодеваться?"


translate russian ep2_06_school_51534d8b:


    D "Заходи!"


translate russian ep2_06_school_84ab04fa:


    X "Как себя чувствуешь?"


translate russian ep2_06_school_8bbc4b12:


    D "Нормально."


translate russian ep2_06_school_80bc9214:


    X "И о школе. Что ты об этом думаешь?"


translate russian ep2_06_school_f912e564:


    D "Не знаю, было бы здорово завести друзей."


translate russian ep2_06_school_6ccf4697:


    X "Да, но поначалу может быть трудно."


translate russian ep2_06_school_f907c2ee:


    X "Итак, я хочу, чтобы ты знала, что можешь рассчитывать на мою поддержку."


translate russian ep2_06_school_a058c9c0:


    D "Спасибо, пап!"


translate russian ep2_06_school_50336b8b:


    X "И насчёт того котёнка - похоже, он тебе понравился."


translate russian ep2_06_school_344e4caa:


    X "Возможно, ты хотела забрать его домой. Могла спросить меня."


translate russian ep2_06_school_93cc9632:


    X "Даже если я откажу, не бойся спрашивать."


translate russian ep2_06_school_270ac63e:


    D "Да, я действительно хотела оставить его себе."


translate russian ep2_06_school_0067376a:


    D "Но он был таким маленьким."


translate russian ep2_06_school_81eec6f3:


    D "Наверное, у него есть мама и папа."


translate russian ep2_06_school_27bd17c9:


    D "И я не могла просто так забрать его у них."


translate russian ep2_06_school_c4c9b2c7:


    X "Это... правильно, так просто это делать нельзя!"


translate russian ep2_06_school_6cfa782c:


    X "В любом случае, ты, наверное, устала..."


translate russian ep2_06_school_e68f6a69:


    D "Постой!"


translate russian ep2_06_school_e0bf2cd8_1:


    X "Что?"


translate russian ep2_06_school_814d4885:


    D "У тебя здесь что-то есть."


translate russian ep2_06_school_0348bb6f:


    X "Где?"


translate russian ep2_06_school_f4fcc38a:


    D "Здесь!"


translate russian ep2_06_school_86d32a3b:


    X "Но за что?"


translate russian ep2_06_school_3dede8be:


    D "За всё!"


translate russian ep2_06_school_7c55a997:


    D "Спасибо тебе!"


translate russian ep2_06_school_7c55a997_1:


    D "Спасибо!"


translate russian ep2_06_school_b0ec9160:


    X "И я забыл рассказать тебе о вкусах мороженого."


translate russian ep2_06_school_c68ef306:


    X "Их много, но и комбинаций тоже много."


translate russian ep2_06_school_df830036:


    X "Ты даже можешь наслаждаться мятой в определенной комбинации."


translate russian ep2_06_school_25c20c30:


    X "Но у нас достаточно времени для этого."


translate russian ep2_06_school_48d24478:


    X "[D], что-то не так?"


translate russian ep2_06_school_8e73b8c1:


    D "Я так не думаю."


translate russian ep2_06_school_6cb00031:


    X "Ладно, давай спать."


translate russian ep2_06_school_811528fc:


    "Казалось, она немного отстранилась от происходящего."


translate russian ep2_06_school_d74a60fc:


    "Может, она просто устала."


translate russian ep2_06_school_9e9cf63e:


    "Полагаю, я тоже... эрекция?!"


translate russian ep2_06_school_6af599c5:


    "Когда это произошло?"


translate russian ep2_06_school_0378c35f:


    "Так вот на что она смотрела?!"


translate russian ep2_06_school_8cca26b6:


    "Чёрт..."

translate russian strings:


    old "Keep searching"
    new "Продолжать искать"


    old "Try something else"
    new "Попробовать что-нибудь другое"


    old "Turn away first"
    new "Сначала отвернуться"


    old "Push the button"
    new "Нажать кнопку"


    old "Pull it down"
    new "Потянуть его вниз"


    old "Keep this a secret"
    new "Пусть держит это в секрете"


    old "Trust her"
    new "Довериться ей"


    old "[Carla]"
    new "[Carla]"


    old "Carol"
    new "Кэрол"


    old "Carma"
    new "Карма"


    old "Clara"
    new "Клара"


    old "Looks great"
    new "Выглядишь великолепно"


    old "Very cute"
    new "Очень мило"


    old "Lovely"
    new "Красотка"


    old "I don't like it"
    new "Мне такое не нравится"


    old "I"
    new "Мне"


    old "love"
    new "это"


    old "it"
    new "нравится"


    old "!"
    new "!"


    old "Get [Eileen]"
    new "Сходить за [Eileen]"


    old "Help her"
    new "Помочь самому"


    old "Check on the conversation"
    new "Подслушать разговор"


    old "Do the dishes"
    new "Мыть посуду"


    old "Go to bed"
    new "Пойти на кровать"


    old "Insist on the couch"
    new "Настаивать на диване"


    old "Cum!"
    new "Кончить!"


    old "Take her cherry"
    new "Взять её вишенку"


    old "Let her have it"
    new "Пусть оставит её себе"


    old "Kiss on the cheek"
    new "Поцеловать в щёку"


    old "Kiss on the forehead"
    new "Поцеловать в лоб"


    old "Script break"
    new "Разрыв сценария"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
