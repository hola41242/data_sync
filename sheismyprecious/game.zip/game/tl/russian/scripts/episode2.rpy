﻿# TODO: Translation updated at 2024-02-11 21:34
translate russian strings:

    old "Episode 2"
    new "Эпизод 2"

    old "Rise to the Occasion"
    new "Оправдать доверие"

# game/scripts/episode2.rpy:13
translate russian ep2_01_bedroom_cb936564:

    # X "Does it hurt?"
    X "Больно?"

# game/scripts/episode2.rpy:15
translate russian ep2_01_bedroom_2b173986:

    # D "Not really, it's just uncomfortable."
    D "Не совсем, просто неудобно."

# game/scripts/episode2.rpy:17
translate russian ep2_01_bedroom_710d795b:

    # X "How long have you had it on?"
    X "Как давно он на тебе?"

# game/scripts/episode2.rpy:19
translate russian ep2_01_bedroom_055c7ef8:

    # D "I had to put it on before going outside the house."
    D "Меня заставили надеть его перед выходом из дома."

# game/scripts/episode2.rpy:20
translate russian ep2_01_bedroom_63b86955:

    # D "I tried pulling down but it's too tight."
    D "Я пылась снять его, потянув вниз, но он слишком плотно сидит."

# game/scripts/episode2.rpy:22
translate russian ep2_01_bedroom_e6dbab9f:

    # X "Have you tried other ways to get rid of it?"
    X "Пробовала другие способы?"

# game/scripts/episode2.rpy:24
translate russian ep2_01_bedroom_4f56fd28:

    # D "Tried breaking it, but it did nothing."
    D "Пыталась сломать, но это ничего не дало."

# game/scripts/episode2.rpy:26
translate russian ep2_01_bedroom_adaffc5b:

    # D "I saw [Odelia] use a card to lock it."
    D "Я видела, как [Odelia] использовала карту, чтобы заблокировать его."

# game/scripts/episode2.rpy:28
translate russian ep2_01_bedroom_9be4d7c1:

    # X "In that case, it should have some kind of safety mechanism in case it gets stuck or something."
    X "В таком случае у него должен быть какой-то защитный механизм на случай, если он застрянет или что-то в этом роде."

# game/scripts/episode2.rpy:29
translate russian ep2_01_bedroom_b120c291:

    # X "I just need to look up the model."
    X "Мне просто нужно найти модель."

# game/scripts/episode2.rpy:31
translate russian ep2_01_bedroom_beec3fc5:

    # D "Okay."
    D "Хорошо."

# game/scripts/episode2.rpy:33
translate russian ep2_01_bedroom_8c1245e1:

    # X "Can I... take a look at it?"
    X "Могу я... взглянуть на него?"

# game/scripts/episode2.rpy:35
translate russian ep2_01_bedroom_a7d6fca3:

    # D "Of course!"
    D "Конечно!"

# game/scripts/episode2.rpy:37
translate russian ep2_01_bedroom_37efbc95:

    # X "Hmmm."
    X "Хммм."

# game/scripts/episode2.rpy:38
translate russian ep2_01_bedroom_6ab17eab:

    # X "Nothing."
    X "Ничего."

# game/scripts/episode2.rpy:41
translate russian ep2_01_bedroom_422878ad:

    # X "Don't see anything, maybe in the back."
    X "Ничего не вижу, может сзади."

# game/scripts/episode2.rpy:44
translate russian ep2_01_bedroom_5d4d7b46:

    # X "I don't see any markings anywhere."
    X "Нигде не вижу никаких отметин."

# game/scripts/episode2.rpy:45
translate russian ep2_01_bedroom_88a0e66f:

    # D "Maybe it's under it."
    D "Может, они внизу?"

# game/scripts/episode2.rpy:46
translate russian ep2_01_bedroom_fea5b189:

    # X "It's possible. Can you lie down for me?"
    X "Возможно. Можешь прилечь?"

# game/scripts/episode2.rpy:48
translate russian ep2_01_bedroom_75981fe0:

    # X "I see something, but can't make out what it is."
    X "Я что-то вижу, но не могу разобрать, что это."

# game/scripts/episode2.rpy:49
translate russian ep2_01_bedroom_833150c5:

    # X "OK I need you to get on your back, then lift up your hips a bit."
    X "Хорошо, мне нужно, чтобы ты легла на спину, а затем немного приподняла бедра."

# game/scripts/episode2.rpy:50
translate russian ep2_01_bedroom_071b3e20:

    # D "Okay..."
    D "Ладно..."

# game/scripts/episode2.rpy:52
translate russian ep2_01_bedroom_ef2381a2:

    # "No fap strap..."
    "Пояс \"Нет мастурбации\"..."

# game/scripts/episode2.rpy:53
translate russian ep2_01_bedroom_b40003d5:

    # X "This must be it!"
    X "Должно быть, это оно!"

# game/scripts/episode2.rpy:54
translate russian ep2_01_bedroom_fc8ea898:

    # X "You can stand back up now."
    X "Теперь можешь встать."

# game/scripts/episode2.rpy:56
translate russian ep2_01_bedroom_de645035:

    # X "I'll look it up, just wait a little longer here."
    X "Я поищу, просто подожди здесь ещё немного."

# game/scripts/episode2.rpy:58
translate russian ep2_01_bedroom_f7a451db:

    # "Who the fuck are these people, forcing her to wear this!"
    "Кто, чёрт возьми, эти люди, заставляющие её носить это!"

# game/scripts/episode2.rpy:59
translate russian ep2_01_bedroom_253845d2:

    # "Sick fucks..."
    "Больные ублюдки..."

# game/scripts/episode2.rpy:63
translate russian ep2_01_bedroom_1648914e:

    # "They don't even sell this online."
    "Он даже не продаётся."

# game/scripts/episode2.rpy:64
translate russian ep2_01_bedroom_7caa2df8:

    # "I could keep searching or maybe try another way..."
    "Я могу продолжить поиски или попробовать другой способ..."

# game/scripts/episode2.rpy:67
translate russian ep2_01_bedroom_74c9da14:

    # "I'll give it another shot."
    "Я попробую ещё раз."

# game/scripts/episode2.rpy:69
translate russian ep2_01_bedroom_61cc45f3:

    # "Well what do you know! Somebody with the same problem."
    "О, у кого-то такая же проблема!"

# game/scripts/episode2.rpy:70
translate russian ep2_01_bedroom_313dc1cf:

    # "Says there's supposed to be a small pinhole on the lock."
    "Говорит, что на замке должно быть небольшое отверстие."

# game/scripts/episode2.rpy:74
translate russian ep2_01_bedroom_53513316:

    # "This could take some time."
    "Поиски могут занять слишком много времени."

# game/scripts/episode2.rpy:75
translate russian ep2_01_bedroom_ee9a7909:

    # "Maybe I can find another way..."
    "Возможно, я смогу найти другой способ..."

# game/scripts/episode2.rpy:77
translate russian ep2_01_bedroom_f1ac8a61:

    # "I could use this."
    "Я могу использовать смазку."

# game/scripts/episode2.rpy:78
translate russian ep2_01_bedroom_c7410682:

    # "Otherwise, it'll sit here and expire."
    "Она всё равно скоро уже просрочится."

# game/scripts/episode2.rpy:83
translate russian ep2_01_bedroom_lockpick_442c334d:

    # X "I found out the model. I have something to go with."
    X "Я нашел модель. У меня кое-что есть."

# game/scripts/episode2.rpy:85
translate russian ep2_01_bedroom_lockpick_4301b262:

    # X "Okay I found the hole, now for the hard part."
    X "Ладно, я нашел отверстие, теперь самое сложное."

# game/scripts/episode2.rpy:87
translate russian ep2_01_bedroom_lockpick_0f69bd49:

    # "It said to poke around till it goes deeper."
    "Там говорилось, что нужно тыкаться, пока не попадёте."

# game/scripts/episode2.rpy:89
translate russian ep2_01_bedroom_lockpick_302cbfff:

    # "Easy does it..."
    "Легко..."

# game/scripts/episode2.rpy:91
translate russian ep2_01_bedroom_lockpick_18975bf8:

    # "Maybe I gotta push harder."
    "Может, мне стоит надавить сильнее."

# game/scripts/episode2.rpy:93
translate russian ep2_01_bedroom_lockpick_ff216961:

    # "Come on..."
    "Давай же..."

# game/scripts/episode2.rpy:95
translate russian ep2_01_bedroom_lockpick_bf9ab159:

    # "There's a hole, so this has to work!"
    "Здесь есть отверстие, так что это должно сработать!"

# game/scripts/episode2.rpy:97
translate russian ep2_01_bedroom_lockpick_253b66ec:

    # X "Think I heard a click."
    X "Кажется, я услышал щелчок."

# game/scripts/episode2.rpy:99
translate russian ep2_01_bedroom_lockpick_ca73fdf1:

    # D "Is it done?"
    D "Готово?"

# game/scripts/episode2.rpy:101
translate russian ep2_01_bedroom_lockpick_f87fc419:

    # X "I have to press the button to see."
    X "Я нажму на кнопку, и мы узнаем это."

# game/scripts/episode2.rpy:106
translate russian ep2_01_bedroom_lockpick_8cff8fa7:

    # "I should look away first."
    "Сначала мне следует отвернуться."

# game/scripts/episode2.rpy:107
translate russian ep2_01_bedroom_lockpick_c3c8d02e:

    # "This is awkward enough..."
    "Это достаточно неловко..."

# game/scripts/episode2.rpy:109
translate russian ep2_01_bedroom_lockpick_477d41fa:

    # X "Here it goes!"
    X "Вот так!"

# game/scripts/episode2.rpy:110
translate russian ep2_01_bedroom_lockpick_da41ad8c:

    # X "One, two."
    X "Раз, два."

# game/scripts/episode2.rpy:112
translate russian ep2_01_bedroom_lockpick_ee36c5c1:

    # X "Three..."
    X "Три..."

# game/scripts/episode2.rpy:114
translate russian ep2_01_bedroom_lockpick_290b4047:

    # D "It's off!"
    D "Он снят!"

# game/scripts/episode2.rpy:115
translate russian ep2_01_bedroom_lockpick_d85b5b02:

    # X "I'll leave to get ready. We still have to go to the hospital in the morning."
    X "Я пойду собираться. Утром нам всё равно нужно ехать в больницу."

# game/scripts/episode2.rpy:120
translate russian ep2_01_bedroom_lockpick_477d41fa_1:

    # X "Here it goes!"
    X "Вот так!"

# game/scripts/episode2.rpy:121
translate russian ep2_01_bedroom_lockpick_da41ad8c_1:

    # X "One, two."
    X "Раз, два."

# game/scripts/episode2.rpy:125
translate russian ep2_01_bedroom_lockpick_ee36c5c1_1:

    # X "Three..."
    X "Три..."

# game/scripts/episode2.rpy:126
translate russian ep2_01_bedroom_lockpick_290b4047_1:

    # D "It's off!"
    D "Он снят!"

# game/scripts/episode2.rpy:127
translate russian ep2_01_bedroom_lockpick_d1136a33:

    # X "Yeah I can.. see that."
    X "Да, я... вижу это."

# game/scripts/episode2.rpy:129
translate russian ep2_01_bedroom_lockpick_d85b5b02_1:

    # X "I'll leave to get ready. We still have to go to the hospital in the morning."
    X "Я пойду собираться. Утром нам всё равно нужно ехать в больницу."

# game/scripts/episode2.rpy:140
translate russian ep2_01_bedroom_lube_e4c92d47:

    # X "Didn't find much about it, so we'll try pulling it off."
    X "Я мало что нашёл о нём, так что попробуем провернуть кое-что."

# game/scripts/episode2.rpy:142
translate russian ep2_01_bedroom_lube_79a76211:

    # X "First I'll make it as slippery as possible."
    X "Сначала я сделаю тебя максимально скользкой."

# game/scripts/episode2.rpy:144
translate russian ep2_01_bedroom_lube_a377fad0:

    # X "Then see if it'll come down."
    X "А затем посмотрим, снимется ли он."

# game/scripts/episode2.rpy:145
translate russian ep2_01_bedroom_lube_c54d47a3:

    # D "Ah!"
    D "Ах!"

# game/scripts/episode2.rpy:146
translate russian ep2_01_bedroom_lube_b0003076:

    # X "Something wrong?"
    X "Что-то не так?"

# game/scripts/episode2.rpy:148
translate russian ep2_01_bedroom_lube_0ce24347:

    # D "It's cold."
    D "Холодно."

# game/scripts/episode2.rpy:150
translate russian ep2_01_bedroom_lube_4b114959:

    # X "I know, but it'll pass. Just bear with it."
    X "Я знаю, но это пройдет. Просто потерпи."

# game/scripts/episode2.rpy:152
translate russian ep2_01_bedroom_lube_b01ab803:

    # X "It needs to really get in there."
    X "Маслу действительно нужно проникнуть внутрь."

# game/scripts/episode2.rpy:154
translate russian ep2_01_bedroom_lube_0bf661cc:

    # X "Are you getting any pain or irritation?"
    X "Испытываешь боль или раздражение?"

# game/scripts/episode2.rpy:156
translate russian ep2_01_bedroom_lube_c3409cbf:

    # D "No, but it feels a little strange."
    D "Нет, но ощущение немного странное."

# game/scripts/episode2.rpy:158
translate russian ep2_01_bedroom_lube_420fdbe9:

    # X "That's normal, nothing to worry about."
    X "Это нормально, беспокоиться не о чем."

# game/scripts/episode2.rpy:160
translate russian ep2_01_bedroom_lube_2aff92d3:

    # X "OK that should be plenty, let's give it a try."
    X "Ладно, этого должно быть достаточно, давай попробуем."

# game/scripts/episode2.rpy:162
translate russian ep2_01_bedroom_lube_2ddcd8d3:

    # X "I can feel it's a bit loose. I'm going to be a little forceful now."
    X "Я чувствую, что он немного ослаблен. Сейчас я буду действовать с небольшим усилием."

# game/scripts/episode2.rpy:163
translate russian ep2_01_bedroom_lube_871900a5:

    # X "Tell me if anything hurts!"
    X "Скажи мне, если будет больно!"

# game/scripts/episode2.rpy:165
translate russian ep2_01_bedroom_lube_8bbc4b12:

    # D "I'm fine."
    D "Я в порядке."

# game/scripts/episode2.rpy:167
translate russian ep2_01_bedroom_lube_3cb57faa:

    # D "Good, here I go!"
    D "Хорошо, я начинаю!"

# game/scripts/episode2.rpy:172
translate russian ep2_01_bedroom_lube_8cff8fa7:

    # "I should look away first."
    "Сначала мне следует отвернуться."

# game/scripts/episode2.rpy:173
translate russian ep2_01_bedroom_lube_c3c8d02e:

    # "This is awkward enough..."
    "Это достаточно неловко..."

# game/scripts/episode2.rpy:175
translate russian ep2_01_bedroom_lube_da41ad8c:

    # X "One, two."
    X "Раз, два."

# game/scripts/episode2.rpy:177
translate russian ep2_01_bedroom_lube_ee36c5c1:

    # X "Three..."
    X "Три..."

# game/scripts/episode2.rpy:179
translate russian ep2_01_bedroom_lube_290b4047:

    # D "It's off!"
    D "Он снят!"

# game/scripts/episode2.rpy:180
translate russian ep2_01_bedroom_lube_d85b5b02:

    # X "I'll leave to get ready. We still have to go to the hospital in the morning."
    X "Я пойду собираться. Утром нам всё равно нужно ехать в больницу."

# game/scripts/episode2.rpy:184
translate russian ep2_01_bedroom_lube_da41ad8c_1:

    # X "One, two."
    X "Раз, два."

# game/scripts/episode2.rpy:188
translate russian ep2_01_bedroom_lube_ee36c5c1_1:

    # X "Three..."
    X "Три..."

# game/scripts/episode2.rpy:189
translate russian ep2_01_bedroom_lube_290b4047_1:

    # D "It's off!"
    D "Он снят!"

# game/scripts/episode2.rpy:190
translate russian ep2_01_bedroom_lube_d1136a33:

    # X "Yeah I can.. see that."
    X "Да, я... вижу это."

# game/scripts/episode2.rpy:192
translate russian ep2_01_bedroom_lube_d85b5b02_1:

    # X "I'll leave to get ready. We still have to go to the hospital in the morning."
    X "Я пойду собираться. Утром нам всё равно нужно ехать в больницу."

# game/scripts/episode2.rpy:199
translate russian ep2_02_drive_clinic_9ea0d797:

    # "Should I tell her what to do about last night?"
    "Должен ли я поговить с ней о прошлой ночи?"

# game/scripts/episode2.rpy:203
translate russian ep2_02_drive_clinic_10d4ae2a:

    # X "Hey so about the belt situation."
    X "Эй, насчет ситуации с поясом."

# game/scripts/episode2.rpy:205
translate russian ep2_02_drive_clinic_6584dbf5:

    # D "Yes?"
    D "Да?"

# game/scripts/episode2.rpy:207
translate russian ep2_02_drive_clinic_94e92af5:

    # X "People could get the wrong idea about it. Looking at our situation, it's already complicated."
    X "У людей может сложиться неверное представление об этом. Если посмотреть на нашу ситуацию, то она и так непростая."

# game/scripts/episode2.rpy:208
translate russian ep2_02_drive_clinic_ed61b1e6:

    # X "So, for now, we should just not mention it all. OK?"
    X "Так что пока нам не следует обо всём этом упоминать. Договорились?"

# game/scripts/episode2.rpy:210
translate russian ep2_02_drive_clinic_7707b213:

    # D "Of course, I won't tell anyone."
    D "Конечно, я никому не скажу."

# game/scripts/episode2.rpy:211
translate russian ep2_02_drive_clinic_3c331ca3:

    # X "Good."
    X "Отлично."

# game/scripts/episode2.rpy:215
translate russian ep2_02_drive_clinic_493c17b5:

    # "I probably don't need to say anything about it."
    "Мне, наверное, не нужно ничего говорить по этому поводу."

# game/scripts/episode2.rpy:216
translate russian ep2_02_drive_clinic_627ec3fd:

    # "She kept it from me till now. So she probably understands not to say anything."
    "Она до сих пор скрывала это от меня. Так что она, наверное, понимает, что лучше ничего не говорить."

# game/scripts/episode2.rpy:221
translate russian ep2_03_clinic_21280427:

    # X "Excuse me!"
    X "Извините!"

# game/scripts/episode2.rpy:222
translate russian ep2_03_clinic_a91e2d18:

    # X "We're here for the 9 o'clock appointment."
    X "Мы пришли на приём в 9 часов."

# game/scripts/episode2.rpy:224
translate russian ep2_03_clinic_f3f28ef8:

    # "Nurse" "Just a moment."
    "Медсестра" "Момент."

# game/scripts/episode2.rpy:228
translate russian ep2_03_clinic_d2e6c48b:

    # "Nurse" "Ah yes, mister [X]!"
    "Медсестра" "Ах да, мистер [X]!"

# game/scripts/episode2.rpy:229
translate russian ep2_03_clinic_f2d5f183:

    # "Nurse" "You have a check-up for your dad."
    "Медсестра" "У вас назначено обследование вашей дочери."

# game/scripts/episode2.rpy:231
translate russian ep2_03_clinic_eb7cf3f8:

    # X "Correct."
    X "Верно."

# game/scripts/episode2.rpy:233
translate russian ep2_03_clinic_e7274394:

    # X "And she's right here!."
    X "Вот она!"

# game/scripts/episode2.rpy:235
translate russian ep2_03_clinic_bbdb0905:

    # "Nurse" "Great! Doctor Joan is in now."
    "Медсестра" "Отлично! Доктор Джоан уже ждёт вас."

# game/scripts/episode2.rpy:236
translate russian ep2_03_clinic_d7e5ca87:

    # "Nurse" "So head right in."
    "Медсестра" "Так что можете заходить."

# game/scripts/episode2.rpy:243
translate russian ep2_03_clinic_844e8ecd:

    # X "Good morning!"
    X "Доброе утро!"

# game/scripts/episode2.rpy:244
translate russian ep2_03_clinic_71695033:

    # Joan "Good morning, have a seat right here."
    Joan "Доброе утро, присаживайтесь."

# game/scripts/episode2.rpy:246
translate russian ep2_03_clinic_66311406:

    # Joan "Mister [X], long time no see."
    Joan "Мистер [X], давно не виделись."

# game/scripts/episode2.rpy:248
translate russian ep2_03_clinic_27bc281a:

    # X "Sorry doc, been busy traveling."
    X "Извините, док, был занят путешествиями."

# game/scripts/episode2.rpy:250
translate russian ep2_03_clinic_d4c02fa6:

    # Joan "And I wasn't aware you had a dad."
    Joan "Я и не знала, что у вас есть дочь."

# game/scripts/episode2.rpy:252
translate russian ep2_03_clinic_7f5f17a2:

    # X "About that..."
    X "Об этом..."

# game/scripts/episode2.rpy:253
translate russian ep2_03_clinic_d839bc73:

    # X "I don't actually have any documents to prove it."
    X "На самом деле у меня нет никаких документов, подтверждающих это."

# game/scripts/episode2.rpy:254
translate russian ep2_03_clinic_2d1c431b:

    # X "So I'll need something to back that up in court."
    X "Так что мне нужно что-то, чтобы подтвердить это в суде."

# game/scripts/episode2.rpy:256
translate russian ep2_03_clinic_4feb4517:

    # Joan "We can do that."
    Joan "Мы можем это сделать."

# game/scripts/episode2.rpy:257
translate russian ep2_03_clinic_5e79631f:

    # Joan "Do you have a court-order?"
    Joan "У вас есть постановление суда?"

# game/scripts/episode2.rpy:258
translate russian ep2_03_clinic_1bc6b4b9:

    # X "Not yet."
    X "Пока нет."

# game/scripts/episode2.rpy:260
translate russian ep2_03_clinic_7e1af614:

    # Joan "And the mother. Can she come in for a test?"
    Joan "А мама может прийти на обследование?"

# game/scripts/episode2.rpy:261
translate russian ep2_03_clinic_978935dd:

    # X "Not at the moment."
    X "В данный момент нет."

# game/scripts/episode2.rpy:263
translate russian ep2_03_clinic_f9f2504a:

    # Joan "I see."
    Joan "Понятно."

# game/scripts/episode2.rpy:264
translate russian ep2_03_clinic_33b422eb:

    # Joan "We can certainly do it."
    Joan "Мы, конечно, можем это сделать,"

# game/scripts/episode2.rpy:266
translate russian ep2_03_clinic_d8ace49c:

    # Joan "But since the mother isn't available."
    Joan "Но поскольку матери рядом нет,"

# game/scripts/episode2.rpy:267
translate russian ep2_03_clinic_4d7db0b4:

    # Joan "And it also needs to be admissible in court."
    Joan "А это должно быть приемлемо в суде,"

# game/scripts/episode2.rpy:268
translate russian ep2_03_clinic_273ae2a3:

    # Joan "It will take more time."
    Joan "Это займёт больше времени."

# game/scripts/episode2.rpy:270
translate russian ep2_03_clinic_ea60b552:

    # X "That's fine, as long as it's solid proof."
    X "Всё в порядке, если это веское доказательство."

# game/scripts/episode2.rpy:272
translate russian ep2_03_clinic_79ff1111:

    # Joan "We'll do the most rigorous test."
    Joan "Мы проведём самый строгий тест."

# game/scripts/episode2.rpy:273
translate russian ep2_03_clinic_cea3ea34:

    # Joan "However, since it's not court-ordered, I can't guarantee a judge will accept it."
    Joan "Однако, поскольку нет ордера от суда, я не могу гарантировать, что судья примет его."

# game/scripts/episode2.rpy:275
translate russian ep2_03_clinic_b51bfe2d:

    # X "We can just do it again then."
    X "Тогда мы можем просто сделать его снова."

# game/scripts/episode2.rpy:277
translate russian ep2_03_clinic_4a701d4a:

    # Joan "That'll work. Now let's begin the check-up!"
    Joan "Это сработает. Приступим к осмотру!"

# game/scripts/episode2.rpy:280
translate russian ep2_03_clinic_b4b930f4:

    # Joan "Sit up on the table for me [D]."
    Joan "Садись на кушетку, [D]."

# game/scripts/episode2.rpy:282
translate russian ep2_03_clinic_e4766cc2:

    # Joan "This will be a little uncomfortable, but bear with me."
    Joan "Будет немного неприятно, но потерпи."

# game/scripts/episode2.rpy:283
translate russian ep2_03_clinic_6fbcc7c0:

    # Joan "Say \"Aaaa\"."
    Joan "Скажи \"Аааа\"."

# game/scripts/episode2.rpy:285
translate russian ep2_03_clinic_ce492ff7:

    # D "Aaaa!"
    D "Аааа!"

# game/scripts/episode2.rpy:287
translate russian ep2_03_clinic_a6db40f0:

    # Joan "Do you have a problem with needles?"
    Joan "Боишься уколов?"

# game/scripts/episode2.rpy:288
translate russian ep2_03_clinic_cbf0aa8f:

    # D "I... I don't really like them."
    D "Я... я не особо их люблю."

# game/scripts/episode2.rpy:289
translate russian ep2_03_clinic_7955f839:

    # Joan "Having a little fear is very healthy actually."
    Joan "Испытывать небольшой страх на самом деле очень полезно."

# game/scripts/episode2.rpy:290
translate russian ep2_03_clinic_914d8a5c:

    # X "I used to hate them when I was young."
    X "Я ненавидел их в молодости."

# game/scripts/episode2.rpy:291
translate russian ep2_03_clinic_f1202a93:

    # X "They were a pain the butt!"
    X "Они были настоящей занозой в заднице!"

# game/scripts/episode2.rpy:293
translate russian ep2_03_clinic_7507dab0:

    # Joan "And to the nurses, so were you from what I've heard."
    Joan "И судя по тому, что я слышала, вы тоже были медбратом."

# game/scripts/episode2.rpy:294
translate russian ep2_03_clinic_ed34ba61:

    # X "Hey come on!"
    X "Да ладно!"

# game/scripts/episode2.rpy:295
translate russian ep2_03_clinic_9f0d159f:

    # X "What happened to doctor-patient confidentiality?"
    X "Забыли клятву Гиппократа?"

# game/scripts/episode2.rpy:297
translate russian ep2_03_clinic_776de564:

    # Joan "Those fights you used to have weren't really a secret."
    Joan "Те ссоры, которые вы устраивали, на самом деле не были секретом."

# game/scripts/episode2.rpy:298
translate russian ep2_03_clinic_5d3e3525:

    # X "OK, fair enough."
    X "Ладно, справедливо."

# game/scripts/episode2.rpy:300
translate russian ep2_03_clinic_39437295:

    # X "Say doc, have you tried using a marker to draw blood?"
    X "Скажите, док, вы не пробовали брать кровь маркером?"

# game/scripts/episode2.rpy:302
translate russian ep2_03_clinic_e6424637:

    # Joan "Not really, but if I attempted with my art skills it would be... in vein."
    Joan "Не совсем, но если бы я попыталась применить свои художественные навыки, это было бы... в вену."

# game/scripts/episode2.rpy:304
translate russian ep2_03_clinic_e95b6b89:

    # X "That wasn't so bad now [D]?"
    X "Было ведь не больно, да, [D]?"

# game/scripts/episode2.rpy:305
translate russian ep2_03_clinic_42d87d05:

    # D "No."
    D "Не больно."

# game/scripts/episode2.rpy:307
translate russian ep2_03_clinic_916442e8:

    # Joan "Normally there are no issues."
    Joan "Обычно проблем не возникает."

# game/scripts/episode2.rpy:309
translate russian ep2_03_clinic_feede064:

    # Joan "But I did hear about a man who lost his entire left half from drawing blood."
    Joan "Но я слышала о человеке, который потерял всю левую половину тела из-за потери крови."

# game/scripts/episode2.rpy:310
translate russian ep2_03_clinic_39c3cadf:

    # X "Really?!"
    X "Серьёзно?!"

# game/scripts/episode2.rpy:312
translate russian ep2_03_clinic_cfbe773d:

    # Joan "Yeah, but he's all right now."
    Joan "Да, но сейчас с ним всё в порядке."

# game/scripts/episode2.rpy:314
translate russian ep2_03_clinic_9ac6a703:

    # X "That's good."
    X "Это хорошо."

# game/scripts/episode2.rpy:315
translate russian ep2_03_clinic_3d6c8fb8:

    # X "I bet his other side still feels left out though.............."
    X "Держу пари, его вторая половина всё ещё чувствует себя ущемлённой, хотя.............."

# game/scripts/episode2.rpy:318
translate russian ep2_03_clinic_b4307a01:

    # X "The next doctor will look down there."
    X "Следующий врач будет смотреть там, внизу."

# game/scripts/episode2.rpy:319
translate russian ep2_03_clinic_74f4808c:

    # X "She's a professional, so there's nothing to worry about."
    X "Она профессионал, так что беспокоиться не о чем."

# game/scripts/episode2.rpy:321
translate russian ep2_03_clinic_beec3fc5:

    # D "Okay."
    D "Хорошо."

# game/scripts/episode2.rpy:323
translate russian ep2_03_clinic_19aa122e:

    # "???" "Is she your dad?"
    "???" "Она ваша дочь?"

# game/scripts/episode2.rpy:325
translate russian ep2_03_clinic_aa0c3faf:

    # X "Yes! She is indeed my dad."
    X "Да! Она действительно моя дочь."

# game/scripts/episode2.rpy:327
translate russian ep2_03_clinic_aecbc0f8:

    # "???" "I don't believe I've seen her around school."
    "???" "Кажется, я ни разу не видела её в школе."

# game/scripts/episode2.rpy:328
translate russian ep2_03_clinic_b8c7a25d:

    # "???" "What grade is she in?"
    "???" "В каком она классе?"

# game/scripts/episode2.rpy:330
translate russian ep2_03_clinic_e35ee1eb:

    # X "Hasn't ever been there yet."
    X "Ещё ни разу там не была."

# game/scripts/episode2.rpy:331
translate russian ep2_03_clinic_71d6ac94:

    # X "She has been home-schooled till now."
    X "Она находится на домашнем обучении."

# game/scripts/episode2.rpy:333
translate russian ep2_03_clinic_1627f48d:

    # "???" "Sounds like you might want to enroll."
    "???" "Похоже, вы хотите её зачислить."

# game/scripts/episode2.rpy:335
translate russian ep2_03_clinic_1b2f5c97:

    # X "Yes, that's in the works."
    X "Да, в процессе."

# game/scripts/episode2.rpy:336
translate russian ep2_03_clinic_4b687df3:

    # X "Do you teach at school?"
    X "Вы преподаете в школе?"

# game/scripts/episode2.rpy:338
translate russian ep2_03_clinic_b8fb4514:

    # "???" "I teach history, although these days I'm too busy as principal."
    "???" "Я преподаю историю, хотя сейчас слишком занята как директор."

# game/scripts/episode2.rpy:340
translate russian ep2_03_clinic_645859b1:

    # "She's a principal and teaches history. She must be the one the girls mentioned."
    "Она директор школы и преподает историю. Должно быть, это та самая, о которой говорили девушки."

# game/scripts/episode2.rpy:341
translate russian ep2_03_clinic_e3f4ae53:

    # "What was her name again? C....."
    "Как её звали ещё раз? К....."

# game/scripts/episode2.rpy:347
translate russian ep2_03_clinic_8a024cb9:

    # X "Is your name [Carla]?"
    X "Вас зовут [Carla]?"

# game/scripts/episode2.rpy:349
translate russian ep2_03_clinic_ce7bdf3a:

    # Carla "That's right! Have we met?"
    Carla "Именно! Мы знакомы?"

# game/scripts/episode2.rpy:351
translate russian ep2_03_clinic_d55014f0:

    # X "Is your name Carol?"
    X "Вас зовут Кэрол?"

# game/scripts/episode2.rpy:353
translate russian ep2_03_clinic_cc7869da:

    # Carla "Close, it's [Carla]."
    Carla "Близко, меня зовут [Carla]."

# game/scripts/episode2.rpy:354
translate russian ep2_03_clinic_8747347a:

    # Carla "Have we met?"
    Carla "Мы знакомы?"

# game/scripts/episode2.rpy:356
translate russian ep2_03_clinic_eacbe791:

    # X "Is your name Carma?"
    X "Вас зовут Карма?"

# game/scripts/episode2.rpy:358
translate russian ep2_03_clinic_cc7869da_1:

    # Carla "Close, it's [Carla]."
    Carla "Близко, меня зовут [Carla]."

# game/scripts/episode2.rpy:359
translate russian ep2_03_clinic_8747347a_1:

    # Carla "Have we met?"
    Carla "Мы знакомы?"

# game/scripts/episode2.rpy:361
translate russian ep2_03_clinic_06b7bf01:

    # X "Is your name Clara?"
    X "Вас зовут Клара?"

# game/scripts/episode2.rpy:363
translate russian ep2_03_clinic_cc7869da_2:

    # Carla "Close, it's [Carla]."
    Carla "Близко, меня зовут [Carla]."

# game/scripts/episode2.rpy:364
translate russian ep2_03_clinic_8747347a_2:

    # Carla "Have we met?"
    Carla "Мы знакомы?"

# game/scripts/episode2.rpy:367
translate russian ep2_03_clinic_be919b47:

    # X "I've met with Alecia and Sophie for tutoring, they mentioned you once."
    X "Я занимался с Алесией и Софи репетиторством, они однажды упомянули вас."

# game/scripts/episode2.rpy:370
translate russian ep2_03_clinic_8df6b5cb:

    # Carla "And you recalled my name, that's a little impressive."
    Carla "И вы вспомнили моё имя, это немного впечатляет."

# game/scripts/episode2.rpy:373
translate russian ep2_03_clinic_181a314d:

    # Carla "Are you helping Sophie with mathematics?"
    Carla "Вы помогаете Софи с математикой?"

# game/scripts/episode2.rpy:375
translate russian ep2_03_clinic_da9693c8:

    # X "That's the main reason."
    X "В основном, да."

# game/scripts/episode2.rpy:377
translate russian ep2_03_clinic_02eec75d:

    # Carla "Well that is great to hear!"
    Carla "Что ж, приятно это слышать!"

# game/scripts/episode2.rpy:378
translate russian ep2_03_clinic_b0caeceb:

    # Carla "I've been searching for a tutor for some time."
    Carla "Я давно искала репетитора."

# game/scripts/episode2.rpy:380
translate russian ep2_03_clinic_b6441ba4:

    # "Nurse" "Miss [Carla], the doctor will see you now."
    "Медсестра" "Мисс [Carla], доктор сейчас вас примет."

# game/scripts/episode2.rpy:382
translate russian ep2_03_clinic_9c5039b6:

    # Carla "I have to get in."
    Carla "Я должна идти."

# game/scripts/episode2.rpy:384
translate russian ep2_03_clinic_d5e3c5b6:

    # Carla "It probably won't be long, just pushed my elbow a bit too far."
    Carla "Вероятно, ненадолго. Я слишком сильно ударилась локтём."

# game/scripts/episode2.rpy:386
translate russian ep2_03_clinic_4e20d1f3:

    # Carla "If you can wait, I'd like to continue our conversation."
    Carla "Если вы можете подождать, я бы хотела продолжить наш разговор."

# game/scripts/episode2.rpy:387
translate russian ep2_03_clinic_4d63f0d3:

    # X "Sure."
    X "Конечно."

# game/scripts/episode2.rpy:390
translate russian ep2_03_clinic_8337e9b7:

    # D "I'm back!"
    D "Я вернулась!"

# game/scripts/episode2.rpy:392
translate russian ep2_03_clinic_1ea360b0:

    # X "All done?"
    X "Всё готово?"

# game/scripts/episode2.rpy:394
translate russian ep2_03_clinic_9980af74:

    # D "Yes. She said I was a... late bloomer?"
    D "Да. Она сказала, что я... поздно расцвела?"

# game/scripts/episode2.rpy:395
translate russian ep2_03_clinic_7368fc86:

    # X "That checks out."
    X "Это проверяется."

# game/scripts/episode2.rpy:396
translate russian ep2_03_clinic_fbf2a9a0:

    # D "But that everything looks good."
    D "Но вроде выглядит всё хорошо."

# game/scripts/episode2.rpy:397
translate russian ep2_03_clinic_10a1fd3c:

    # D "And she has to wait for the other test results."
    D "И она должна дождаться результатов других анализов."

# game/scripts/episode2.rpy:399
translate russian ep2_03_clinic_8be85f50:

    # X "That's reassuring."
    X "Это обнадёживает."

# game/scripts/episode2.rpy:401
translate russian ep2_03_clinic_09ea29a8:

    # Carla "Hello, my name's [Carla]!"
    Carla "Привет, меня зовут [Carla]!"

# game/scripts/episode2.rpy:402
translate russian ep2_03_clinic_51e2b053:

    # D "I'm... [D]!"
    D "Я... [D]!"

# game/scripts/episode2.rpy:404
translate russian ep2_03_clinic_1485e5ee:

    # Carla "You must be hungry."
    Carla "Ты, должно быть, голодна."

# game/scripts/episode2.rpy:406
translate russian ep2_03_clinic_6f52fab1:

    # D "A little."
    D "Немного."

# game/scripts/episode2.rpy:408
translate russian ep2_03_clinic_327eae7c:

    # Carla "Well I know of a place where they make some amazing waffles."
    Carla "Я знаю одно место, где готовят потрясающие вафли."

# game/scripts/episode2.rpy:409
translate russian ep2_03_clinic_7e4287d2:

    # Carla "Does sound good to you?"
    Carla "Ты любишь их?"

# game/scripts/episode2.rpy:411
translate russian ep2_03_clinic_dea0849b:

    # D "Yes!"
    D "Да!"

# game/scripts/episode2.rpy:413
translate russian ep2_03_clinic_a952daf6:

    # Carla "If your father approves, we can head there now."
    Carla "Если твой папа одобрит, мы можем отправиться туда прямо сейчас."

# game/scripts/episode2.rpy:414
translate russian ep2_03_clinic_b636acc5:

    # X "Hey I'm curious about this place too!"
    X "Эй, я тоже туда хочу!"

# game/scripts/episode2.rpy:419
translate russian ep2_04_cafe_0f1722ec:

    # Carla "So [D], have you even been to school?"
    Carla "Итак, [D], ты вообще ходила в школу?"

# game/scripts/episode2.rpy:420
translate russian ep2_04_cafe_d6ca01d7:

    # D "No, I only had lessons at home."
    D "Нет, у меня были уроки только дома."

# game/scripts/episode2.rpy:422
translate russian ep2_04_cafe_e416c3fe:

    # Carla "Are there other kids you play with?"
    Carla "Ты играешь с какими-нибудь другими детьми?"

# game/scripts/episode2.rpy:424
translate russian ep2_04_cafe_6f1d9911:

    # D "I remember that a relative used to visit."
    D "Помню, к нам приходил родственник."

# game/scripts/episode2.rpy:426
translate russian ep2_04_cafe_650bfe4a:

    # D "But I have been by myself most days."
    D "Но большую часть дней я была одна."

# game/scripts/episode2.rpy:427
translate russian ep2_04_cafe_047ee543:

    # Carla "I see."
    Carla "Понятно."

# game/scripts/episode2.rpy:428
translate russian ep2_04_cafe_c3dd3283:

    # Carla "In that case I advise you ease in first before the start of the year."
    Carla "В этом случае я советую тебе расслабиться перед началом учебного года."

# game/scripts/episode2.rpy:430
translate russian ep2_04_cafe_e21f4848:

    # Carla "There are smaller summer classes going on now."
    Carla "Сейчас проводятся небольшие летние занятия."

# game/scripts/episode2.rpy:431
translate russian ep2_04_cafe_62933660:

    # Carla "You can join those to get used to the school."
    Carla "Ты можешь ходить на них, чтобы привыкнуть к школе."

# game/scripts/episode2.rpy:433
translate russian ep2_04_cafe_69163eae:

    # X "Are those for every grade?"
    X "Они для каждого класса?"

# game/scripts/episode2.rpy:435
translate russian ep2_04_cafe_05d42c05:

    # Carla "They're mixed from every grade."
    Carla "Они смешаны из всех классов."

# game/scripts/episode2.rpy:437
translate russian ep2_04_cafe_7639e2c5:

    # X "Aren't those mainly for students with problems?"
    X "Разве они не предназначены в основном для проблемных учеников?"

# game/scripts/episode2.rpy:439
translate russian ep2_04_cafe_227180af:

    # Carla "Sadly that's the perception, but there are also those who excel among them."
    Carla "К сожалению, так оно и есть, но есть и те, кто преуспевает среди них."

# game/scripts/episode2.rpy:441
translate russian ep2_04_cafe_875011d8:

    # X "You think it might rub off on the underachievers?"
    X "Думаете, это может повлиять на неуспевающих?"

# game/scripts/episode2.rpy:443
translate russian ep2_04_cafe_f21d4db3:

    # Carla "That's one reason I organized them that way."
    Carla "Это одна из причин, по которой я организовала их таким образом."

# game/scripts/episode2.rpy:445
translate russian ep2_04_cafe_fdbf1d85:

    # Alecia "G'morning principal! What can I get you today?"
    Alecia "Доброе утро, директор! Что я могу вам сегодня предложить?"

# game/scripts/episode2.rpy:446
translate russian ep2_04_cafe_b6d5e50e:

    # X "And speaking of underachievers!"
    X "И кстати, о неуспевающих!"

# game/scripts/episode2.rpy:449
translate russian ep2_04_cafe_0e9e9d52:

    # Alecia "[X]?!"
    Alecia "[X]?!"

# game/scripts/episode2.rpy:450
translate russian ep2_04_cafe_d051a085:

    # X "Hey [Alecia], you got a job for the summer?"
    X "Привет, [Alecia]. Похоже, ты нашла работу на лето?"

# game/scripts/episode2.rpy:452
translate russian ep2_04_cafe_e7d46e34:

    # Alecia "Yeah, just preparing for my future as an underachiever."
    Alecia "Да, просто готовлюсь к своему будущему как неуспевающая."

# game/scripts/episode2.rpy:454
translate russian ep2_04_cafe_65212634:

    # Alecia "We can't all be straight A students like you."
    Alecia "Мы не можем все быть такими отличницами, как вы."

# game/scripts/episode2.rpy:455
translate russian ep2_04_cafe_1187bd37:

    # X "That's funny, seeing how I almost got expelled and ended up supended for a year."
    X "Звучит забавно, учитывая, что меня чуть не исключили, а в итоге оставили на второй год."

# game/scripts/episode2.rpy:457
translate russian ep2_04_cafe_7f546aa3:

    # Alecia "What?"
    Alecia "Что?"

# game/scripts/episode2.rpy:458
translate russian ep2_04_cafe_21c599f0:

    # X "Never got an A till my last year of school."
    X "Я никогда не получал пятёрок до последнего года обучения в школе."

# game/scripts/episode2.rpy:459
translate russian ep2_04_cafe_1a0f2532:

    # X "Then I did get straight As in maths. So you're not too far off."
    X "Затем я начал получать отличные оценки по математике. Так что ты не слишком далеко ушла."

# game/scripts/episode2.rpy:461
translate russian ep2_04_cafe_e8dc435e:

    # Carla "Oh now I remember!"
    Carla "О, теперь я вспомнила!"

# game/scripts/episode2.rpy:462
translate russian ep2_04_cafe_66579a78:

    # Carla "You got in to that fight and got suspended for hospitalizing that kid."
    Carla "Вы ввязались в драку и были отстранены за то, что вырубили того парня."

# game/scripts/episode2.rpy:463
translate russian ep2_04_cafe_08df1604:

    # Carla "Then came back and started going to competitions."
    Carla "Потом вернулись и начали ездить на олимпиады."

# game/scripts/episode2.rpy:464
translate russian ep2_04_cafe_957a4984:

    # X "Pretty much yeah."
    X "В основном да."

# game/scripts/episode2.rpy:466
translate russian ep2_04_cafe_db47096d:

    # Alecia "How did you not get kicked out?"
    Alecia "Как только вас не выгнали?"

# game/scripts/episode2.rpy:467
translate russian ep2_04_cafe_0866143d:

    # X "Well they started it."
    X "Что ж, они сами напросились."

# game/scripts/episode2.rpy:468
translate russian ep2_04_cafe_6cef5e33:

    # Alecia "They?"
    Alecia "Они?"

# game/scripts/episode2.rpy:469
translate russian ep2_04_cafe_dfc691cc:

    # X "I was on bad terms with a gang, long story."
    X "Я поссорился с бандой, это долгая история."

# game/scripts/episode2.rpy:471
translate russian ep2_04_cafe_9f323c84:

    # X "By the way, this is [D], my dad."
    X "Кстати, это [D], моя дочь."

# game/scripts/episode2.rpy:472
translate russian ep2_04_cafe_0cc66a26:

    # X "[D], [Alecia]."
    X "[D], это [Alecia]."

# game/scripts/episode2.rpy:474
translate russian ep2_04_cafe_97c76620:

    # D "Hello! Nice to meet you."
    D "Привет! Приятно познакомиться."

# game/scripts/episode2.rpy:476
translate russian ep2_04_cafe_0bc1fb9f:

    # Alecia "Hi there!"
    Alecia "Привет!"

# game/scripts/episode2.rpy:478
translate russian ep2_04_cafe_80b233ff:

    # Carla "We were talking about [D] going to summer classes."
    Carla "Мы говорили о том, что [D] начнёт ходить на летние занятия."

# game/scripts/episode2.rpy:479
translate russian ep2_04_cafe_68d70b18:

    # Carla "Maybe you could show her around, she's not from here."
    Carla "Ты могла бы показать ей окрестности, она ведь не местная."

# game/scripts/episode2.rpy:480
translate russian ep2_04_cafe_9a0d4713:

    # Alecia "Sure."
    Alecia "Конечно."

# game/scripts/episode2.rpy:482
translate russian ep2_04_cafe_a0b4d373:

    # Alecia "Wait, you said she was your dad?"
    Alecia "Подождите, вы сказали, что она ваша дочь?"

# game/scripts/episode2.rpy:483
translate russian ep2_04_cafe_7df12b8b:

    # X "That's... another long story."
    X "Это... ещё одна долгая история."

# game/scripts/episode2.rpy:485
translate russian ep2_04_cafe_9fc393be:

    # Alecia "Right. So what can I get you?"
    Alecia "Ладно. Так что я могу вам предложить?"

# game/scripts/episode2.rpy:487
translate russian ep2_04_cafe_631f3b27:

    # Carla "We came here for those famous honey waffles."
    Carla "Мы пришли сюда за знаменитыми медовыми вафлями."

# game/scripts/episode2.rpy:488
translate russian ep2_04_cafe_d2d3a8cb:

    # Carla "A coffee and for [X]..."
    Carla "Ещё кофе для [X]..."

# game/scripts/episode2.rpy:489
translate russian ep2_04_cafe_3c906ec3:

    # X "Another coffee, that's all."
    X "Ещё один кофе, вот."

# game/scripts/episode2.rpy:491
translate russian ep2_04_cafe_53767074:

    # Alecia "Alright, coming right up."
    Alecia "Хорошо, сейчас будет."

# game/scripts/episode2.rpy:492
translate russian ep2_04_cafe_9d6125e1:

    # X "And don't forget about our deal."
    X "И не забывай о нашей сделке."

# game/scripts/episode2.rpy:493
translate russian ep2_04_cafe_f8725da9:

    # Alecia "Sure sure!"
    Alecia "Конечно, конечно!"

# game/scripts/episode2.rpy:495
translate russian ep2_04_cafe_9d6c8f93:

    # Carla "What was that about a deal?"
    Carla "Что за сделка?"

# game/scripts/episode2.rpy:497
translate russian ep2_04_cafe_f16aaae4:

    # X "We have an understanding. About her trying to get in to at least a subject."
    X "У нас есть договорённость, что она хотя бы будет пытаться вникнуть в тему."

# game/scripts/episode2.rpy:499
translate russian ep2_04_cafe_4c2c53bd:

    # Carla "It couldn't have been easy to convince her."
    Carla "Наверное, убедить её было нелегко."

# game/scripts/episode2.rpy:500
translate russian ep2_04_cafe_56ec8ded:

    # X "You could say the opportunity fell in to my lap."
    X "Можно сказать, что эта возможность сама представилась мне."

# game/scripts/episode2.rpy:502
translate russian ep2_04_cafe_9721dda1:

    # Carla "In any case, [D] could start making friends."
    Carla "В любом случае, [D] может начать заводить друзей."

# game/scripts/episode2.rpy:503
translate russian ep2_04_cafe_3d45e1ee:

    # Carla "That's a very important part of school life."
    Carla "Это очень важная часть школьной жизни."

# game/scripts/episode2.rpy:505
translate russian ep2_04_cafe_3c993e4d:

    # D "I don't know, maybe I could."
    D "Не знаю, может, и могу."

# game/scripts/episode2.rpy:507
translate russian ep2_04_cafe_cb5d0d3c:

    # Carla "Of course you can. You seem like a nice and sweet girl."
    Carla "Конечно, можешь. Ты милая и приятная девушка."

# game/scripts/episode2.rpy:508
translate russian ep2_04_cafe_3e25731a:

    # Carla "Who wouldn't want to be friends?"
    Carla "Кто не захочет подружиться с тобой?"

# game/scripts/episode2.rpy:510
translate russian ep2_04_cafe_25cb3fbd:

    # X "Yeah it's been a short while, but we hit it off really well."
    X "Да, прошло совсем немного времени, но мы отлично поладили."

# game/scripts/episode2.rpy:511
translate russian ep2_04_cafe_caed97fe:

    # X "On top of that, she's an amazing cook."
    X "Вдобавок ко всему, она потрясающий повар."

# game/scripts/episode2.rpy:513
translate russian ep2_04_cafe_9dea84f3:

    # D "I just follow the recipe, it's not that impressive."
    D "Я просто следую рецепту, это не так уж впечатляет."

# game/scripts/episode2.rpy:515
translate russian ep2_04_cafe_56b0558f:

    # X "Don't sell yourself short now. It takes skill."
    X "Не стоит себя обманывать. Это требует мастерства."

# game/scripts/episode2.rpy:517
translate russian ep2_04_cafe_9c60b4b9:

    # Carla "Do you enjoy cooking [D]?"
    Carla "Тебе нравится готовить, [D]?"

# game/scripts/episode2.rpy:519
translate russian ep2_04_cafe_6ddfaa90:

    # D "I have fun with it."
    D "Я получаю от этого удовольствие."

# game/scripts/episode2.rpy:521
translate russian ep2_04_cafe_0c83e52f:

    # Carla "You said you were by yourself most of the time."
    Carla "Ты сказала, что большую часть времени была одна."

# game/scripts/episode2.rpy:522
translate russian ep2_04_cafe_d94e7f55:

    # Carla "What other stuff did you do?"
    Carla "Чем ещё ты занималась?"

# game/scripts/episode2.rpy:524
translate russian ep2_04_cafe_12f0cd55:

    # D "I used to stay in the garden, and take care of the plants."
    D "Обычно находилась в саду и ухаживала за растениями."

# game/scripts/episode2.rpy:525
translate russian ep2_04_cafe_887252e8:

    # D "And I would also stay there to read."
    D "А ещё я там читала."

# game/scripts/episode2.rpy:527
translate russian ep2_04_cafe_7d3bf2bd:

    # Carla "What did you read?"
    Carla "Что читала?"

# game/scripts/episode2.rpy:529
translate russian ep2_04_cafe_6cbce347:

    # D "I liked to read novels, books about other places, other times."
    D "Мне нравилось читать романы, книги о других местах, других временах."

# game/scripts/episode2.rpy:531
translate russian ep2_04_cafe_358a5cbb:

    # Carla "Like history books?"
    Carla "Любишь исторические книги?"

# game/scripts/episode2.rpy:533
translate russian ep2_04_cafe_d4e385b3:

    # D "Yes, there were some really interesting ones."
    D "Да, встречались действительно интересные."

# game/scripts/episode2.rpy:535
translate russian ep2_04_cafe_8309eb29:

    # Carla "I've read a few interesting ones myself."
    Carla "Я сама прочитала несколько интересных книг."

# game/scripts/episode2.rpy:536
translate russian ep2_04_cafe_bb0047f1:

    # Carla "And would love to share and discuss some of them with you."
    Carla "И мне бы хотелось поделиться и обсудить некоторые из них с тобой."

# game/scripts/episode2.rpy:538
translate russian ep2_04_cafe_41519ebd:

    # Carla "And if you need help with math, your father can help."
    Carla "А если тебе понадобится помощь с математикой, твой отец может помочь."

# game/scripts/episode2.rpy:540
translate russian ep2_04_cafe_a6f6aead:

    # X "Yeah I have a good grasp. It's that I have to review the current material."
    X "Да, я хорошо разбираюсь в ней. Мне лишь нужно просмотреть текущий материал."

# game/scripts/episode2.rpy:541
translate russian ep2_04_cafe_e23b58d4:

    # X "It's been a second since my school days."
    X "Прошло мгновение с тех пор, как я учился в школе."

# game/scripts/episode2.rpy:543
translate russian ep2_04_cafe_5691d03d:

    # Carla "Oh I can help with that."
    Carla "О, я могу помочь с этим."

# game/scripts/episode2.rpy:544
translate russian ep2_04_cafe_b114df1c:

    # Carla "If you can come by tomorrow morning, I'll have some books ready."
    Carla "Если вы сможете прийти завтра утром, я подготовлю несколько книг."

# game/scripts/episode2.rpy:546
translate russian ep2_04_cafe_d3c21933:

    # Carla "And [D] can take the placement tests."
    Carla "И [D] может сдать вступительные тесты."

# game/scripts/episode2.rpy:547
translate russian ep2_04_cafe_f802bf37:

    # Carla "What do you say? Would you like to come to school this year?"
    Carla "Что скажешь? Хочешь пойти в школу в этом году?"

# game/scripts/episode2.rpy:549
translate russian ep2_04_cafe_3a68c8a3:

    # D "I would like that, yes!"
    D "Да, хочу!"

# game/scripts/episode2.rpy:551
translate russian ep2_04_cafe_da56585e:

    # Carla "Excellent! Then I'll expect you tomorrow."
    Carla "Превосходно! Тогда жду вас завтра."

# game/scripts/episode2.rpy:552
translate russian ep2_04_cafe_20ad0623:

    # X "Do you need a ride?"
    X "Вас подвезти?"

# game/scripts/episode2.rpy:553
translate russian ep2_04_cafe_e20cb95a:

    # Carla "No, it's fine."
    Carla "Нет, мы сами."

# game/scripts/episode2.rpy:555
translate russian ep2_04_cafe_2d323ef0:

    # Carla "It was a pleasure meeting you [D]. Hope to see you in school."
    Carla "Было приятно познакомиться, [D]. Надеюсь увидеть тебя в школе."

# game/scripts/episode2.rpy:556
translate russian ep2_04_cafe_5d24c3f9:

    # D "Thank you miss [Carla]."
    D "Спасибо, мисс [Carla]."

# game/scripts/episode2.rpy:557
translate russian ep2_04_cafe_a3a8f138:

    # Carla "Please, just [Carla]."
    Carla "Пожалуйста, просто [Carla]."

# game/scripts/episode2.rpy:560
translate russian ep2_04_cafe_d0bd0b6f:

    # Eileen "[X]! I'm almost done at the store."
    Eileen "[X]! Я почти закончила в магазине."

# game/scripts/episode2.rpy:561
translate russian ep2_04_cafe_d1b3ce20:

    # Eileen "You free later for that catching up we talked about?"
    Eileen "Ты свободен позже, чтобы наверстать упущенное, о котором мы говорили?"

# game/scripts/episode2.rpy:562
translate russian ep2_04_cafe_d71f3e91:

    # X "We got some catching up to do [Eileen]."
    X "Нам нужно кое-что наверстать, [Eileen]."

# game/scripts/episode2.rpy:563
translate russian ep2_04_cafe_e43e7de5:

    # X "Found out that I have a dad."
    X "Узнал, что у меня есть дочь."

# game/scripts/episode2.rpy:564
translate russian ep2_04_cafe_2b91a929:

    # Eileen "Eh? What was that about someone's dad?"
    Eileen "А? Ты что-то сказал про чью-то дочь?"

# game/scripts/episode2.rpy:565
translate russian ep2_04_cafe_dc133a03:

    # X "It's about my dad, [Emily]'s dad."
    X "Речь идет о моей дочери, дочери [Emily]."

# game/scripts/episode2.rpy:566
translate russian ep2_04_cafe_b5bd2382:

    # Eileen "What?!"
    Eileen "Что?!"

# game/scripts/episode2.rpy:567
translate russian ep2_04_cafe_e511b416:

    # X "Can we meet now?"
    X "Мы можем сейчас встретиться?"

# game/scripts/episode2.rpy:568
translate russian ep2_04_cafe_06f97dec:

    # Eileen "Come to the shop!"
    Eileen "Приходи в магазин!"

# game/scripts/episode2.rpy:573
translate russian ep2_05_eileen_d03be6b8:

    # Eileen "Why hello there!"
    Eileen "Привет!"

# game/scripts/episode2.rpy:574
translate russian ep2_05_eileen_de1d984c:

    # Eileen "I'm [Eileen]."
    Eileen "Я [Eileen]."

# game/scripts/episode2.rpy:576
translate russian ep2_05_eileen_2a22e409:

    # Eileen "Your dad and I are old friends."
    Eileen "Мы с твоим папой старые друзья."

# game/scripts/episode2.rpy:577
translate russian ep2_05_eileen_5e058de0:

    # D "Hello, I'm [D]."
    D "Привет, я [D]."

# game/scripts/episode2.rpy:579
translate russian ep2_05_eileen_97d23c80:

    # Eileen "Do you like sweets [D]?"
    Eileen "Ты любишь сладости, [D]?"

# game/scripts/episode2.rpy:580
translate russian ep2_05_eileen_7f50e911:

    # D "Yes."
    D "Да."

# game/scripts/episode2.rpy:582
translate russian ep2_05_eileen_ffec5342:

    # Eileen "Tell you what, you go in the shop."
    Eileen "Вот что я тебе скажу: сходи-ка ты в магазин."

# game/scripts/episode2.rpy:583
translate russian ep2_05_eileen_8028a4eb:

    # Eileen "And pick out any cake you want from the menu."
    Eileen "И выбери из меню любой торт, который захочешь."

# game/scripts/episode2.rpy:584
translate russian ep2_05_eileen_abe65be9:

    # Eileen "Sound good?"
    Eileen "Что думаешь?"

# game/scripts/episode2.rpy:585
translate russian ep2_05_eileen_071b3e20:

    # D "Okay..."
    D "Окей..."

# game/scripts/episode2.rpy:586
translate russian ep2_05_eileen_8e1277bc:

    # Eileen "Me and your dad will have a little chat in the mean time."
    Eileen "А мы с твоим папой пока поболтаем."

# game/scripts/episode2.rpy:588
translate russian ep2_05_eileen_b94b9e2a:

    # Eileen "Well congratulations I guess!"
    Eileen "Что ж, полагаю, мои поздравления!"

# game/scripts/episode2.rpy:589
translate russian ep2_05_eileen_9deb7ef6:

    # Eileen "Since when did you find out about her?"
    Eileen "Как давно ты узнал о ней?"

# game/scripts/episode2.rpy:590
translate russian ep2_05_eileen_1134accb:

    # X "A few days--"
    X "Несколько дней--"

# game/scripts/episode2.rpy:592
translate russian ep2_05_eileen_93bf9d60:

    # Eileen "A FEW DAYS?!"
    Eileen "НЕСКОЛЬКО ДНЕЙ?!"

# game/scripts/episode2.rpy:594
translate russian ep2_05_eileen_aeaeb51c:

    # Eileen "And you didn't call me?!"
    Eileen "И ты мне не позвонил?!"

# game/scripts/episode2.rpy:596
translate russian ep2_05_eileen_6cf02450:

    # X "It was a lot to process, it just didn't cross my mind."
    X "Это было сложно переварить, оно просто не укладывалось в моей голове."

# game/scripts/episode2.rpy:598
translate russian ep2_05_eileen_f8dcbdf8:

    # Eileen "I bet. So can you fill me in on everything then?"
    Eileen "Не сомневаюсь. Так не мог бы ты тогда посвятить меня во все подробности?"

# game/scripts/episode2.rpy:599
translate russian ep2_05_eileen_38682ec0:

    # X "Well it all started on the beach..."
    X "Ну, всё началось на пляже..."

# game/scripts/episode2.rpy:603
translate russian ep2_05_eileen_1da8f462:

    # X "...so that's pretty much it."
    X "...вот такие пироги."

# game/scripts/episode2.rpy:605
translate russian ep2_05_eileen_98ebcd20:

    # Eileen "So you made her wear your stinky clothes?"
    Eileen "Значит, ты заставил её надеть твою вонючую одежду?"

# game/scripts/episode2.rpy:607
translate russian ep2_05_eileen_3dcffe51:

    # X "They were clean. I wouldn't do that!"
    X "Я бы не допустил этого! Она чистая."

# game/scripts/episode2.rpy:609
translate russian ep2_05_eileen_1d5a40c5:

    # Eileen "In any case, she needs clothes."
    Eileen "В любом случае, ей нужна одежда."

# game/scripts/episode2.rpy:611
translate russian ep2_05_eileen_16142f50:

    # Eileen "Hey, did you pick a cake?"
    Eileen "Эй, ты выбрала торт?"

# game/scripts/episode2.rpy:612
translate russian ep2_05_eileen_055e2981:

    # D "I have."
    D "Да."

# game/scripts/episode2.rpy:613
translate russian ep2_05_eileen_ffe8071b:

    # Eileen "Great! Now what do you say about getting some new clothes for yourself?"
    Eileen "Отлично! А теперь, что скажешь, если мы купим тебе новую одежду?"

# game/scripts/episode2.rpy:614
translate russian ep2_05_eileen_8fe85446:

    # D "New clothes?"
    D "Новую одежду?"

# game/scripts/episode2.rpy:615
translate russian ep2_05_eileen_4eb94e6e:

    # Eileen "That's right."
    Eileen "Именно так."

# game/scripts/episode2.rpy:617
translate russian ep2_05_eileen_e5291fe0:

    # Eileen "And don't worry, I have excellent fashion sense."
    Eileen "И не волнуйся, у меня отличное чувство стиля."

# game/scripts/episode2.rpy:618
translate russian ep2_05_eileen_863c0b83:

    # X "It's true!"
    X "Это правда!"

# game/scripts/episode2.rpy:619
translate russian ep2_05_eileen_b355fff6:

    # Eileen "Nobody asked you!"
    Eileen "Тебя никто не спрашивал!"

# game/scripts/episode2.rpy:620
translate russian ep2_05_eileen_daafaf1f:

    # X "Sorry..."
    X "Прости..."

# game/scripts/episode2.rpy:623
translate russian ep2_05_eileen_6961d6e6:

    # Eileen "Something simple, casual and comfortable for normal wear."
    Eileen "Что-то простое, повседневное и удобное."

# game/scripts/episode2.rpy:625
translate russian ep2_05_eileen_f803cd92:

    # Eileen "Head in to the booth, I'll bring them and you pick what you like."
    Eileen "Заходи в примерочную, я всё принесу, и ты выберешь то, что тебе понравится."

# game/scripts/episode2.rpy:626
translate russian ep2_05_eileen_beec3fc5:

    # D "Okay."
    D "Хорошо."

# game/scripts/episode2.rpy:628
translate russian ep2_05_eileen_16141ff6:

    # Eileen "Your job is to smile, nod and swipe. Got it?"
    Eileen "Твоя задача - улыбаться и кивать. Понятно?"

# game/scripts/episode2.rpy:629
translate russian ep2_05_eileen_7b6a798d:

    # X "Yes, ma'am!"
    X "Да, мэм!"

# game/scripts/episode2.rpy:632
translate russian ep2_05_eileen_d428182f:

    # D "I like this one!"
    D "Мне нравится вот это!"

# game/scripts/episode2.rpy:633
translate russian ep2_05_eileen_7fc54e6c:

    # Eileen "Good, show it to your father."
    Eileen "Окей, покажись своему отцу."

# game/scripts/episode2.rpy:635
translate russian ep2_05_eileen_680d95f0:

    # D "What do you think dad?"
    D "Что скажешь, пап?"

# game/scripts/episode2.rpy:639
translate russian ep2_05_eileen_d22c4d07:

    # X "Looks great on you!"
    X "Тебе идет!"

# game/scripts/episode2.rpy:641
translate russian ep2_05_eileen_43b4aa23:

    # X "It's very cute!"
    X "Она очень милая!"

# game/scripts/episode2.rpy:643
translate russian ep2_05_eileen_9b5bb665:

    # X "Really lovely!"
    X "Просто очаровательна!"

# game/scripts/episode2.rpy:645
translate russian ep2_05_eileen_754942be:

    # "Haha! I'm not saying that..."
    "Хаха! Я не должен говорить, что..."

# game/scripts/episode2.rpy:646
translate russian ep2_05_eileen_cd92f83e:

    # X "I like it!"
    X "Мне нравится!"

# game/scripts/episode2.rpy:648
translate russian ep2_05_eileen_eb6875dd:

    # D "Really?"
    D "Правда?"

# game/scripts/episode2.rpy:649
translate russian ep2_05_eileen_11bedccc:

    # X "I mean it!"
    X "Я серьёзно!"

# game/scripts/episode2.rpy:650
translate russian ep2_05_eileen_29fcd724:

    # D "Can I keep it?"
    D "Могу я оставить его себе?"

# game/scripts/episode2.rpy:652
translate russian ep2_05_eileen_80483223:

    # X "Of course you can!"
    X "Конечно, можешь!"

# game/scripts/episode2.rpy:655
translate russian ep2_05_eileen_9961e3b2:

    # D "These are really comfortable!"
    D "Они очень удобные!"

# game/scripts/episode2.rpy:656
translate russian ep2_05_eileen_a533c61e:

    # Eileen "I know right! I have a few at home."
    Eileen "Подтверждаю! У меня дома таких несколько."

# game/scripts/episode2.rpy:657
translate russian ep2_05_eileen_16da9bd6:

    # Eileen "Let's see what the fashion critic thinks."
    Eileen "Посмотрим, что думает модный критик."

# game/scripts/episode2.rpy:659
translate russian ep2_05_eileen_c0f38a7b:

    # D "dad, what do you think?"
    D "Пап, что думаешь?"

# game/scripts/episode2.rpy:670
translate russian ep2_05_eileen_fac0a0f7:

    # X "Very nice, looks good, seems comfy!"
    X "Очень красиво, хорошо смотрится, кажется удобным!"

# game/scripts/episode2.rpy:672
translate russian ep2_05_eileen_9cdd7a0d:

    # D "It's a little strange, feel like I'm not wearing anything at all."
    D "Это немного странно. Ощущение, что на мне вообще ничего нет."

# game/scripts/episode2.rpy:674
translate russian ep2_05_eileen_2a70c304:

    # X "Yes... they should advertise it like that!"
    X "Да... они так себя преподносят!"

# game/scripts/episode2.rpy:676
translate russian ep2_05_eileen_d1decd10:

    # X "And we're here for..."
    X "И мы здесь для..."

# game/scripts/episode2.rpy:677
translate russian ep2_05_eileen_6e60d32e:

    # Eileen "Underwear, obviously."
    Eileen "Нижнего белья, очевидно."

# game/scripts/episode2.rpy:679
translate russian ep2_05_eileen_be421e3c:

    # Eileen "They have quality stuff here."
    Eileen "У них здесь качественные вещи."

# game/scripts/episode2.rpy:681
translate russian ep2_05_eileen_693c241b:

    # Eileen "Do you know your bra size?"
    Eileen "Ты знаешь свой размер бюстгальтера?"

# game/scripts/episode2.rpy:682
translate russian ep2_05_eileen_cfe60be9:

    # D "Not really."
    D "Не совсем."

# game/scripts/episode2.rpy:683
translate russian ep2_05_eileen_7d383209:

    # Eileen "I'll have to eyeball it then."
    Eileen "Тогда мне придется выбирать на глаз."

# game/scripts/episode2.rpy:686
translate russian ep2_05_eileen_62bd2d2f:

    # D "[Eileen]?"
    D "[Eileen]?"

# game/scripts/episode2.rpy:688
translate russian ep2_05_eileen_3be9a715:

    # X "She's not here, is there a problem?"
    X "Её здесь нет, у тебя проблема?"

# game/scripts/episode2.rpy:689
translate russian ep2_05_eileen_8c2836f8:

    # D "This bra is a bit small and I can't undo it in the back."
    D "Бюстгальтер немного маловат, и я не могу расстегнуть его."

# game/scripts/episode2.rpy:693
translate russian ep2_05_eileen_754ac7c2:

    # X "Hold on a second! I'll go get her."
    X "Подожди секунду! Я схожу за ней."

# game/scripts/episode2.rpy:694
translate russian ep2_05_eileen_7c55a997:

    # D "Thank you!"
    D "Спасибо!"

# game/scripts/episode2.rpy:698
translate russian ep2_05_eileen_5104ff94:

    # X "I can help you with that."
    X "Я могу помочь тебе с этим."

# game/scripts/episode2.rpy:700
translate russian ep2_05_eileen_b3838f4d:

    # D "I'm not sure how it detaches. And I don't want to force it."
    D "Не знаю, как его расстегнуть. И я не хочу порвать его."

# game/scripts/episode2.rpy:702
translate russian ep2_05_eileen_9f561ed8:

    # X "You'll have to be patient with me."
    X "Тебе придётся потерпеть."

# game/scripts/episode2.rpy:704
translate russian ep2_05_eileen_789a0f4f:

    # X "I'm not used to doing this."
    X "Я не привык это делать."

# game/scripts/episode2.rpy:706
translate russian ep2_05_eileen_4f8cbf41:

    # D "I'm not used to wearing bras."
    D "Я не привыкла носить бюстгальтеры."

# game/scripts/episode2.rpy:708
translate russian ep2_05_eileen_344dc863:

    # X "Hey! We have another thing in common."
    X "Эй! У нас есть ещё одна общая черта."

# game/scripts/episode2.rpy:711
translate russian ep2_05_eileen_701f1ffd:

    # X "Think I got it."
    X "Кажется, я понял."

# game/scripts/episode2.rpy:713
translate russian ep2_05_eileen_051a58f7:

    # X "There!"
    X "Вот так!"

# game/scripts/episode2.rpy:715
translate russian ep2_05_eileen_8d94f4dd:

    # D "Oh!"
    D "Ох!"

# game/scripts/episode2.rpy:717
translate russian ep2_05_eileen_d8f843dc:

    # X "..."
    X "..."

# game/scripts/episode2.rpy:721
translate russian ep2_05_eileen_1b965aa0:

    # X "I should..."
    X "Я должен..."

# game/scripts/episode2.rpy:723
translate russian ep2_05_eileen_f175dca5:

    # X "...go tell [Eileen] to get another size."
    X "...сказать [Eileen], чтобы взяла другой размер."

# game/scripts/episode2.rpy:726
translate russian ep2_05_eileen_308b91be:

    # Eileen "See any design you like?"
    Eileen "Нравится что-нибудь?"

# game/scripts/episode2.rpy:727
translate russian ep2_05_eileen_e0c1dd64:

    # D "Ummm..."
    D "Эммм..."

# game/scripts/episode2.rpy:729
translate russian ep2_05_eileen_5b239601:

    # Eileen "That should do for now."
    Eileen "Этого пока хватит."

# game/scripts/episode2.rpy:730
translate russian ep2_05_eileen_fe43eed3:

    # X "If you say so."
    X "Если ты так считаешь, то окей."

# game/scripts/episode2.rpy:732
translate russian ep2_05_eileen_442d24ce:

    # Eileen "[D] dear, we can go now!"
    Eileen "[D], дорогая, мы можем идти!"

# game/scripts/episode2.rpy:734
translate russian ep2_05_eileen_ac7c6ff9:

    # D "Yes, coming!"
    D "Да, иду!"

# game/scripts/episode2.rpy:737
translate russian ep2_05_eileen_b60acb78:

    # Eileen "...that was the first time I saw [Emily] and [X] hanging out."
    Eileen "...это был первый раз, когда я увидела, как [Emily] и [X] тусуются."

# game/scripts/episode2.rpy:739
translate russian ep2_05_eileen_b3b649a9:

    # Eileen "I was like \"Who's this delinquent? Did [Emily] fall for him?\""
    Eileen "Я такая: \"Кто этот преступник? Неужели [Emily] влюбилась в него?\""

# game/scripts/episode2.rpy:741
translate russian ep2_05_eileen_7ae659fb:

    # X "And I remember you kept trying to get a rise out of me."
    X "Я помню, как ты всё время пыталась вывести меня из себя."

# game/scripts/episode2.rpy:742
translate russian ep2_05_eileen_c0946903:

    # X "Seeing if I'd get violent."
    X "Посмотреть, не вспылю ли я."

# game/scripts/episode2.rpy:744
translate russian ep2_05_eileen_499d64cb:

    # D "But what if he were someone that did get violent?"
    D "Но что, если бы он действительно был вспыльчивым?"

# game/scripts/episode2.rpy:746
translate russian ep2_05_eileen_10450faa:

    # Eileen "I was ready for that."
    Eileen "Я была готова к этому."

# game/scripts/episode2.rpy:748
translate russian ep2_05_eileen_126c96fe:

    # Eileen "At the first sign I would've kicked him right in the crotch."
    Eileen "При первом признаке я бы пнула его прямо в промежность."

# game/scripts/episode2.rpy:749
translate russian ep2_05_eileen_7e82fc62:

    # D "Ouch!"
    D "Оу!"

# game/scripts/episode2.rpy:751
translate russian ep2_05_eileen_542ac5e1:

    # Eileen "That's a solid move. If a guy is threatening you."
    Eileen "Это хороший ход, если парень угрожает тебе."

# game/scripts/episode2.rpy:753
translate russian ep2_05_eileen_06ccc799:

    # Eileen "Give 'em all you got, don't hold back."
    Eileen "Со всей силы, что у тебя есть. Не сдерживайся."

# game/scripts/episode2.rpy:755
translate russian ep2_05_eileen_fd170487:

    # X "I was lucky that she came around to seeing the light."
    X "Мне повезло, что она одумалась."

# game/scripts/episode2.rpy:757
translate russian ep2_05_eileen_f2cf52ba:

    # Eileen "I figured that out when I saw you two studying."
    Eileen "Я поняла это, когда увидела, как вы двое занимались учёбой."

# game/scripts/episode2.rpy:758
translate russian ep2_05_eileen_f3d60f5e:

    # Eileen "A meat head wouldn't be able to hold out that long."
    Eileen "Дурак не смог бы продержаться так долго."

# game/scripts/episode2.rpy:760
translate russian ep2_05_eileen_0287ef54:

    # X "Yeah, also [Emily] didn't go easy on me."
    X "Да, и с [Emily] было непросто."

# game/scripts/episode2.rpy:762
translate russian ep2_05_eileen_da429f89:

    # X "She has this ability to just peer in to your soul."
    X "Она обладает способностью заглядывать прямо в душу."

# game/scripts/episode2.rpy:763
translate russian ep2_05_eileen_50fc6814:

    # X "It's hard to explain."
    X "Это трудно объяснить."

# game/scripts/episode2.rpy:765
translate russian ep2_05_eileen_39e01aaf:

    # D "Is that what made you fall in love?"
    D "Это то, что заставило тебя влюбиться?"

# game/scripts/episode2.rpy:767
translate russian ep2_05_eileen_a39732ca:

    # X "Not just that, but it's one big part of it."
    X "И не только это, но это одна из главных составляющих."

# game/scripts/episode2.rpy:769
translate russian ep2_05_eileen_b4f0972d:

    # X "She saw that I had a talent for maths, and didn't give up on me."
    X "Она увидела, что у меня талант к математике, и не рассталась со мной."

# game/scripts/episode2.rpy:770
translate russian ep2_05_eileen_61916fb7:

    # X "And there were plenty of reasons for her to just leave me be."
    X "У неё было множество причин бросить меня."

# game/scripts/episode2.rpy:772
translate russian ep2_05_eileen_cc837e04:

    # X "So I owe her a lot."
    X "Так что я многим ей обязан."

# game/scripts/episode2.rpy:773
translate russian ep2_05_eileen_5588aaf6:

    # X "Who knows where I would've ended up if not for your mother."
    X "Кто знает, где бы я сейчас был, если бы не твоя мама."

# game/scripts/episode2.rpy:775
translate russian ep2_05_eileen_87216ee3:

    # Eileen "[D], The sauce was just delicious! You have to give me the recipe."
    Eileen "[D], соус просто восхитительный! Ты должна дать мне рецепт."

# game/scripts/episode2.rpy:777
translate russian ep2_05_eileen_89dbdfbe:

    # D "I'm happy you enjoyed it."
    D "Рада, что тебе понравилось."

# game/scripts/episode2.rpy:779
translate russian ep2_05_eileen_74070b80:

    # Eileen "Hey, [D] and I are going upstairs for some girl talk. So we need some privacy."
    Eileen "Эй, мы с [D] поднимемся наверх и уединимся, чтобы немного поговорить о девичьем."

# game/scripts/episode2.rpy:780
translate russian ep2_05_eileen_c6347fa4:

    # Eileen "You got the dishes!"
    Eileen "А ты вымой посуду!"

# game/scripts/episode2.rpy:782
translate russian ep2_05_eileen_3eb04490:

    # "I could listen in..."
    "Я мог бы подслушать..."

# game/scripts/episode2.rpy:787
translate russian ep2_05_eileen_9996992e:

    # "It couldn't hurt."
    "Это не повредит."

# game/scripts/episode2.rpy:790
translate russian ep2_05_eileen_99046b30:

    # Eileen "...these ways of touching."
    Eileen "...эти способы прикосновения."

# game/scripts/episode2.rpy:791
translate russian ep2_05_eileen_ff37689d:

    # Eileen "Has anyone in or outside the family done that to you?"
    Eileen "Кто-нибудь в семье или за её пределами делал это с тобой?"

# game/scripts/episode2.rpy:792
translate russian ep2_05_eileen_9c8f41aa:

    # D "Not that I remember."
    D "Насколько я помню, нет."

# game/scripts/episode2.rpy:793
translate russian ep2_05_eileen_d076ad74:

    # Eileen "You know, girls when they develop, their bodies start do eliminate blood every month or so."
    Eileen "Знаешь, когда девочки растут, их организм начинает выводить кровь каждый месяц или около того."

# game/scripts/episode2.rpy:794
translate russian ep2_05_eileen_78db3c80:

    # Eileen "Has that happened to you?"
    Eileen "С тобой такое уже случалось?"

# game/scripts/episode2.rpy:795
translate russian ep2_05_eileen_42d87d05:

    # D "No."
    D "Нет."

# game/scripts/episode2.rpy:796
translate russian ep2_05_eileen_2d49e6fc:

    # Eileen "Okay."
    Eileen "Хорошо."

# game/scripts/episode2.rpy:797
translate russian ep2_05_eileen_f6098323:

    # Eileen "One more thing, at some point you will feel the need to touch youself down there."
    Eileen "И ещё: в какой-то момент ты почувствуешь желание прикоснуться к себе там, внизу."

# game/scripts/episode2.rpy:798
translate russian ep2_05_eileen_686c14d1:

    # D "Why?"
    D "Зачем?"

# game/scripts/episode2.rpy:799
translate russian ep2_05_eileen_96a7681a:

    # Eileen "You'll know! But regardless of what anyone may have told you, that is perfectly natural and healthy."
    Eileen "Узнаешь! Но что бы тебе ни говорили, это совершенно естественно и полезно для здоровья."

# game/scripts/episode2.rpy:800
translate russian ep2_05_eileen_d871e7dc:

    # D "I understand."
    D "Поняла."

# game/scripts/episode2.rpy:801
translate russian ep2_05_eileen_e238610f:

    # Eileen "It'll be fine, you're a smart girl."
    Eileen "Всё будет хорошо, ты же умная девочка."

# game/scripts/episode2.rpy:802
translate russian ep2_05_eileen_ca23e12d:

    # Eileen "Oh and this is the last thing. About that sauce..."
    Eileen "О, и последнее. Насчёт соуса..."

# game/scripts/episode2.rpy:806
translate russian ep2_05_eileen_8bccc2dc:

    # "I should respect their privacy."
    "Я должен уважать их частную жизнь."

# game/scripts/episode2.rpy:809
translate russian ep2_05_eileen_2f357ff0:

    # Eileen "Hey how about opening another bottle?"
    Eileen "Эй, как насчёт того, чтобы открыть ещё одну бутылку?"

# game/scripts/episode2.rpy:810
translate russian ep2_05_eileen_d39cdc39:

    # X "I'm game."
    X "Я в деле."

# game/scripts/episode2.rpy:812
translate russian ep2_05_eileen_0663459f:

    # Eileen "Did you listen in to our little talk?"
    Eileen "Ты подслушивал наш разговор?"

# game/scripts/episode2.rpy:815
translate russian ep2_05_eileen_32800284:

    # X "Nope, honest!"
    X "Нет, честно!"

# game/scripts/episode2.rpy:817
translate russian ep2_05_eileen_8302062e:

    # Eileen "Then I'll give you the rundown."
    Eileen "Тогда расскажу тебе вкратце."

# game/scripts/episode2.rpy:818
translate russian ep2_05_eileen_18f0d420:

    # Eileen "As far as she knows, there hasn't been any abuse."
    Eileen "Насколько я поняла, никакого насилия над ней не было."

# game/scripts/episode2.rpy:819
translate russian ep2_05_eileen_380a30ec:

    # Eileen "Her period hasn't started."
    Eileen "Месячные ещё не начались."

# game/scripts/episode2.rpy:820
translate russian ep2_05_eileen_2c8c2114:

    # Eileen "And her body is still developing."
    Eileen "А её тело всё ещё растёт."

# game/scripts/episode2.rpy:823
translate russian ep2_05_eileen_af5d465b:

    # X "Sorry, couldn't help myself."
    X "Прости, не смог удержаться."

# game/scripts/episode2.rpy:825
translate russian ep2_05_eileen_93bac6b5:

    # Eileen "In that case, I don't need to get you up to date."
    Eileen "В таком случае, мне не нужно вводить тебя в курс дела."

# game/scripts/episode2.rpy:827
translate russian ep2_05_eileen_045d104b:

    # Eileen "But she has more growing up to do."
    Eileen "Но ей ещё предстоит повзрослеть."

# game/scripts/episode2.rpy:829
translate russian ep2_05_eileen_4a26ca2e:

    # X "She has me now, so it'll be fine."
    X "Теперь у неё есть я, так что всё будет хорошо."

# game/scripts/episode2.rpy:830
translate russian ep2_05_eileen_1024bc32:

    # Eileen "Yeah, but what about [Emily]?"
    Eileen "Да, но как же [Emily]?"

# game/scripts/episode2.rpy:832
translate russian ep2_05_eileen_f0690486:

    # X "I don't believe for a second that she ran away."
    X "Я никогда не поверю, что она сбежала."

# game/scripts/episode2.rpy:834
translate russian ep2_05_eileen_8d3f041c:

    # Eileen "Yeah, she would never just leave her own dad like that."
    Eileen "Да, она бы никогда вот так просто не бросила свою собственную дочь."

# game/scripts/episode2.rpy:836
translate russian ep2_05_eileen_a1f744f7:

    # X "And I'm just worried that she might..."
    X "И я беспокоюсь, что она может..."

# game/scripts/episode2.rpy:837
translate russian ep2_05_eileen_c77d0ec6:

    # X "I just fear the worst."
    X "Я просто боюсь худшего."

# game/scripts/episode2.rpy:839
translate russian ep2_05_eileen_0ca69114:

    # Eileen "You can't think like that [X]!"
    Eileen "Ты не можешь так думать, [X]!"

# game/scripts/episode2.rpy:840
translate russian ep2_05_eileen_78269039:

    # Eileen "You have to keep it together, for [D]!"
    Eileen "Ты должен держать себя в руках ради [D]!"

# game/scripts/episode2.rpy:842
translate russian ep2_05_eileen_dc751bfd:

    # X "I know."
    X "Знаю."

# game/scripts/episode2.rpy:843
translate russian ep2_05_eileen_c2e0b5eb:

    # X "And [Charlie] is on the case."
    X "И [Charlie] занимается этим делом."

# game/scripts/episode2.rpy:844
translate russian ep2_05_eileen_1f5be62d:

    # X "But this fucking wait is just killing me."
    X "Но это гребаное ожидание просто убивает меня."

# game/scripts/episode2.rpy:846
translate russian ep2_05_eileen_73987363:

    # X "If there wasn't anyone else involved, I would've gone there and kicked the front door open by now."
    X "Если бы в этом не был замешан кто-то ещё, я бы уже пошёл туда и вышиб ногой входную дверь."

# game/scripts/episode2.rpy:848
translate russian ep2_05_eileen_bd11dd65:

    # Eileen "Yeah, and done something really stupid after."
    Eileen "Да, и после этого сделал что-то действительно глупое."

# game/scripts/episode2.rpy:849
translate russian ep2_05_eileen_92e18b53:

    # X "Obviously."
    X "Очевидно."

# game/scripts/episode2.rpy:851
translate russian ep2_05_eileen_a78549b6:

    # Eileen "Damn! We finished two bottles."
    Eileen "Проклятие! Мы закончили две бутылки."

# game/scripts/episode2.rpy:852
translate russian ep2_05_eileen_79988d46:

    # Eileen "I got orders tomorrow, so I should get going."
    Eileen "У меня завтра заказы, так что мне пора идти."

# game/scripts/episode2.rpy:853
translate russian ep2_05_eileen_e0acaa94:

    # X "Where are you going like that?"
    X "Куда ты так собралась в таком виде?"

# game/scripts/episode2.rpy:854
translate russian ep2_05_eileen_988984b9:

    # X "Just crash here for tonight."
    X "Переночуй ночь у меня."

# game/scripts/episode2.rpy:855
translate russian ep2_05_eileen_39362670:

    # Eileen "Nah, I got this."
    Eileen "Не надо, я сама."

# game/scripts/episode2.rpy:857
translate russian ep2_05_eileen_36bdf05e:

    # Eileen "Nice room you got here!"
    Eileen "Милая у тебя комнатка!"

# game/scripts/episode2.rpy:859
translate russian ep2_05_eileen_119ac611:

    # Eileen "Oh and the bed's so soft, yeahhh..."
    Eileen "Ох, и кровать такая мягкая, дааа..."

# game/scripts/episode2.rpy:860
translate russian ep2_05_eileen_8a5f80b4:

    # X "Hey come on, at least take the dress off."
    X "Эй, давай, сними хотя бы платье."

# game/scripts/episode2.rpy:862
translate russian ep2_05_eileen_4bcf86a5:

    # X "You'll be shouting at me tomorrow because I let you sleep in it."
    X "Завтра ты будешь кричать на меня за то, что я позволил тебе спать в нём."

# game/scripts/episode2.rpy:864
translate russian ep2_05_eileen_4e834cbd:

    # Eileen "Well ok, you did buy me dinner. Guess you can strip me now."
    Eileen "Ну ладно, ты угостил меня ужином. Думаю, теперь ты можешь меня раздеть."

# game/scripts/episode2.rpy:866
translate russian ep2_05_eileen_a66419ba:

    # Eileen "Oh hey there bed! Still soft as ever."
    Eileen "О, привет, кровать! Такая же мягкая, как всегда."

# game/scripts/episode2.rpy:867
translate russian ep2_05_eileen_27750529:

    # X "Bathroom's down the hall. Goodnight [Eileen]."
    X "Туалет дальше по коридору. Спокойной ночи, [Eileen]."

# game/scripts/episode2.rpy:868
translate russian ep2_05_eileen_898c05d2:

    # Eileen "Huh? Where you goin'?"
    Eileen "Хм? Куда ты уходишь?"

# game/scripts/episode2.rpy:869
translate russian ep2_05_eileen_138e8888:

    # X "I'll crash on the couch."
    X "Я лягу на диване."

# game/scripts/episode2.rpy:870
translate russian ep2_05_eileen_be55096b:

    # Eileen "Whaaa..."
    Eileen "Чт..."

# game/scripts/episode2.rpy:872
translate russian ep2_05_eileen_556d4569:

    # "Maybe had a bit too much tonight."
    "Возможно, сегодня вечером я перебрал."

# game/scripts/episode2.rpy:875
translate russian ep2_05_eileen_c9d690d4:

    # "Thirsty..."
    "Жаждущий..."

# game/scripts/episode2.rpy:877
translate russian ep2_05_eileen_166d7aeb:

    # "[Eileen]'s up, she's probably feeling better."
    "[Eileen] проснулась. Ей, наверное, лучше."

# game/scripts/episode2.rpy:881
translate russian ep2_05_eileen_27b40951:

    # X "Hey can you grab some--"
    X "Эй, можешь взять немного--"

# game/scripts/episode2.rpy:884
translate russian ep2_05_eileen_7b0c7dd5:

    # Eileen "Aaaaah!"
    Eileen "Аааа!"

# game/scripts/episode2.rpy:885
translate russian ep2_05_eileen_066ddd4b:

    # Eileen "You startled me [X]!"
    Eileen "Ты напугал меня, [X]!"

# game/scripts/episode2.rpy:887
translate russian ep2_05_eileen_e086f599:

    # X "Yeah sorry. Just came for some water."
    X "Ага, извини. Просто пришёл за водой."

# game/scripts/episode2.rpy:888
translate russian ep2_05_eileen_4ddca305:

    # X "Also you're not wearing anything on top."
    X "А ещё на тебе ничего нет."

# game/scripts/episode2.rpy:889
translate russian ep2_05_eileen_a554c9e9:

    # Eileen "I know. You want me to sleep in a bra?"
    Eileen "Я знаю. Ты хочешь, чтобы я спала в лифчике?"

# game/scripts/episode2.rpy:890
translate russian ep2_05_eileen_648d52e4:

    # Eileen "Have you seen my boobs?"
    Eileen "Видел мои сиськи?"

# game/scripts/episode2.rpy:891
translate russian ep2_05_eileen_9a3e99bd:

    # X "Very recently."
    X "Совсем недавно."

# game/scripts/episode2.rpy:892
translate russian ep2_05_eileen_9d55efbc:

    # Eileen "Also what are you doing on the couch?"
    Eileen "И что ты делаешь на диване?"

# game/scripts/episode2.rpy:893
translate russian ep2_05_eileen_3e8cccb1:

    # Eileen "Come to bed!"
    Eileen "Иди в кровать!"

# game/scripts/episode2.rpy:895
translate russian ep2_05_eileen_33091dcf:

    # X "The couch is fine."
    X "На диване нормально."

# game/scripts/episode2.rpy:896
translate russian ep2_05_eileen_7bd4ad51:

    # Eileen "Don't be silly, there's plenty of space. And you'll get back pain from that."
    Eileen "Не глупи, на кровати много места. А от дивана у тебя будет болеть спина."

# game/scripts/episode2.rpy:899
translate russian ep2_05_eileen_fdb8e556:

    # X "You may be right."
    X "Возможно, ты права."

# game/scripts/episode2.rpy:904
translate russian ep2_05_eileen_7ceb0c28:

    # X "It's really no problem. Plus I can get restless sometimes."
    X "На самом деле никаких проблем. К тому же иногда я становлюсь беспокойным."

# game/scripts/episode2.rpy:905
translate russian ep2_05_eileen_73747f5d:

    # Eileen "Fine, go ahead!"
    Eileen "Отлично, иди!"

# game/scripts/episode2.rpy:910
translate russian ep2_05_eileen_handy_6c55b5a4:

    # X "Seems a little chilly in here. Do you want a blanket?"
    X "Кажется, здесь немного прохладно. Нужно одеяло?"

# game/scripts/episode2.rpy:911
translate russian ep2_05_eileen_handy_0a6c543c:

    # Eileen "I'm good."
    Eileen "Мне нормально."

# game/scripts/episode2.rpy:912
translate russian ep2_05_eileen_handy_8cf9a6d6:

    # X "You sure?"
    X "Уверена?"

# game/scripts/episode2.rpy:914
translate russian ep2_05_eileen_handy_9644b967:

    # Eileen "Are you still hung up on me being topless?"
    Eileen "Ты всё ещё зациклен на том, что я с голой грудью?"

# game/scripts/episode2.rpy:916
translate russian ep2_05_eileen_handy_7eb94fa0:

    # X "I'm mean we're both half naked in the same bed!"
    X "Я имею в виду, что мы оба полуголые в одной постели!"

# game/scripts/episode2.rpy:918
translate russian ep2_05_eileen_handy_eca8d7a4:

    # Eileen "Wait! Are you having trouble sleeping because of me?"
    Eileen "Постой! У тебя проблемы со сном из-за меня?"

# game/scripts/episode2.rpy:919
translate russian ep2_05_eileen_handy_2480e0d2:

    # X "It's... no!"
    X "Эээ... нет!"

# game/scripts/episode2.rpy:921
translate russian ep2_05_eileen_handy_3b662cf2:

    # Eileen "Oh my!"
    Eileen "О, Боже!"

# game/scripts/episode2.rpy:922
translate russian ep2_05_eileen_handy_ed34ba61:

    # X "Hey come on!"
    X "Эй, да ладно!"

# game/scripts/episode2.rpy:924
translate russian ep2_05_eileen_handy_b91e1c05:

    # Eileen "Has it been working like normal or is it because of me again?"
    Eileen "Работает как обычно или это снова из-за меня?"

# game/scripts/episode2.rpy:926
translate russian ep2_05_eileen_handy_3c21bc6d:

    # X "Well... haven't really been able to get it up on my own."
    X "Ну... я не могу самостоятельно поднять его."

# game/scripts/episode2.rpy:928
translate russian ep2_05_eileen_handy_6f7cf4b6:

    # Eileen "Really?"
    Eileen "Правда?"

# game/scripts/episode2.rpy:929
translate russian ep2_05_eileen_handy_0257ac27:

    # Eileen "Have you tried with others, maybe some coworkers?"
    Eileen "Пробовал ли ты с другими коллегами?"

# game/scripts/episode2.rpy:931
translate russian ep2_05_eileen_handy_790a8ace:

    # X "Are you kidding me?!"
    X "Ты что, издеваешься надо мной?!"

# game/scripts/episode2.rpy:932
translate russian ep2_05_eileen_handy_8c6e3c5f:

    # X "If word had gone around that I have erectile dysfunction."
    X "Если бы прошёл слух, что у меня эректильная дисфункция..."

# game/scripts/episode2.rpy:933
translate russian ep2_05_eileen_handy_214b9540:

    # X "I wouldn't hear the end of it."
    X "Вся компания бы знала."

# game/scripts/episode2.rpy:935
translate russian ep2_05_eileen_handy_02fb9716:

    # Eileen "So you haven't gotten off since I took care of it last time?"
    Eileen "Значит, ты не кончал с тех пор, как я позаботилась об этом в прошлый раз?"

# game/scripts/episode2.rpy:937
translate russian ep2_05_eileen_handy_caa62506:

    # X "Well I did have wet dreams, got some release then."
    X "Ну, у меня были влажные сны, тогда я получил некоторую разрядку."

# game/scripts/episode2.rpy:939
translate russian ep2_05_eileen_handy_2e3cb297:

    # Eileen "And when was the last time that happened?"
    Eileen "И когда они были в последний раз?"

# game/scripts/episode2.rpy:941
translate russian ep2_05_eileen_handy_c8c46c45:

    # X "I don't know, maybe two, three months ago..."
    X "Не знаю, может быть, два-три месяца назад..."

# game/scripts/episode2.rpy:943
translate russian ep2_05_eileen_handy_39a6baf9:

    # Eileen "That's not healthy!"
    Eileen "Это вредно для здоровья!"

# game/scripts/episode2.rpy:945
translate russian ep2_05_eileen_handy_daf7317b:

    # Eileen "Come on get it out, I'll take care of it!"
    Eileen "Давай, вытаскивай, я позабочусь о нём!"

# game/scripts/episode2.rpy:946
translate russian ep2_05_eileen_handy_46771c89:

    # X "[Eileen], you don't have to!"
    X "[Eileen], ты не обязана!"

# game/scripts/episode2.rpy:948
translate russian ep2_05_eileen_handy_3ad57d3b:

    # Eileen "Just look at it! Looks ready to blow."
    Eileen "Только посмотри на него! Выглядит готовым взорваться."

# game/scripts/episode2.rpy:949
translate russian ep2_05_eileen_handy_054bf636:

    # X "It's fine, I'll deal with it somehow."
    X "Ничего, я как-нибудь справлюсь с этим."

# game/scripts/episode2.rpy:951
translate russian ep2_05_eileen_handy_893e3bde:

    # Eileen "Like going to the doctor, and getting prescribed a bunch of pills?"
    Eileen "Например, пойдёшь к врачу и получишь кучу таблеток?"

# game/scripts/episode2.rpy:953
translate russian ep2_05_eileen_handy_b0b83ae1:

    # Eileen "When you can have your friend apply a simple natural treatment."
    Eileen "Когда ты можешь попросить свою подругу применить простое натуральное лечение."

# game/scripts/episode2.rpy:954
translate russian ep2_05_eileen_handy_a0cbec74:

    # Eileen "I don't think so!"
    Eileen "Я так не думаю!"

# game/scripts/episode2.rpy:956
translate russian ep2_05_eileen_handy_381e8285:

    # X "[Eileen]..."
    X "[Eileen]..."

# game/scripts/episode2.rpy:959
translate russian ep2_05_eileen_handy_6fa9f974:

    # X "Fuck!"
    X "Блять!"

# game/scripts/episode2.rpy:961
translate russian ep2_05_eileen_handy_46d4dcda:

    # Eileen "Does it feel good?"
    Eileen "Приятно?"

# game/scripts/episode2.rpy:962
translate russian ep2_05_eileen_handy_fc680d03:

    # X "Well yeah..."
    X "Ну да..."

# game/scripts/episode2.rpy:967
translate russian ep2_05_eileen_handy_172f3cca:

    # X "Oh!"
    X "Ох!"

# game/scripts/episode2.rpy:971
translate russian ep2_05_eileen_handy_fff30d06:

    # X "I won't last much longer."
    X "Я долго не продержусь."

# game/scripts/episode2.rpy:973
translate russian ep2_05_eileen_handy_42dd5cad:

    # Eileen "You don't have to, just let it out."
    Eileen "И не нужно. Просто выплесни всё, что накопилось."

# game/scripts/episode2.rpy:978
translate russian ep2_05_eileen_handy_24ec9530:

    # X "Shit! I'm getting close!"
    X "Черт! Я уже близко!"

# game/scripts/episode2.rpy:984
translate russian ep2_05_eileen_handy_3b514d51:

    # X "Oh shit I'm gonna--"
    X "О чёрт, я--"

# game/scripts/episode2.rpy:986
translate russian ep2_05_eileen_handy_acd91df8:

    # X "CUM!"
    X "КОНЧАЮ!"

# game/scripts/episode2.rpy:990
translate russian ep2_05_eileen_handy_acb05c25:

    # Eileen "Look at all that pent up energy..."
    Eileen "Посмотри на всю эту накопившуюся энергию..."

# game/scripts/episode2.rpy:991
translate russian ep2_05_eileen_handy_cce5e3c1:

    # X "Sorry about that."
    X "Прости за это."

# game/scripts/episode2.rpy:993
translate russian ep2_05_eileen_handy_6faa494e:

    # Eileen "Don't worry about it."
    Eileen "Не беспокойся."

# game/scripts/episode2.rpy:995
translate russian ep2_05_eileen_handy_a2365faa:

    # Eileen "I'm just glad I could help you."
    Eileen "Я рада, что смогла тебе помочь."

# game/scripts/episode2.rpy:997
translate russian ep2_05_eileen_handy_60cc21af:

    # X "Well... thanks!"
    X "Что ж... спасибо!"

# game/scripts/episode2.rpy:999
translate russian ep2_05_eileen_handy_7b45579e:

    # Eileen "My pleasure..."
    Eileen "Не за что..."

# game/scripts/episode2.rpy:1014
translate russian ep2_06_school_91f741ee:

    # "Better get to school early, [Carla] might be busy later."
    "Лучше прийти в школу пораньше, позже [Carla] может быть занята."

# game/scripts/episode2.rpy:1016
translate russian ep2_06_school_8414f156:

    # Carla "You came! Excellent!"
    Carla "Вы пришли! Превосходно!"

# game/scripts/episode2.rpy:1017
translate russian ep2_06_school_cfcc86c9:

    # Carla "We can set you up in the study room."
    Carla "Пройдёмте в класс."

# game/scripts/episode2.rpy:1019
translate russian ep2_06_school_b00c40a1:

    # X "Just write whatever you know there."
    X "Напиши всё, что знаешь."

# game/scripts/episode2.rpy:1020
translate russian ep2_06_school_325a1585:

    # X "No reason to be nervous."
    X "И не нервничай."

# game/scripts/episode2.rpy:1021
translate russian ep2_06_school_d871e7dc:

    # D "I understand."
    D "Окей."

# game/scripts/episode2.rpy:1023
translate russian ep2_06_school_2c930b6c:

    # X "And I'll be right outside."
    X "А я буду снаружи."

# game/scripts/episode2.rpy:1025
translate russian ep2_06_school_32eed147:

    # Carla "Got you all the material you need to study with [Sophie] here."
    Carla "Здесь вы найдете все необходимые материалы для занятий с [Sophie]."

# game/scripts/episode2.rpy:1026
translate russian ep2_06_school_0fabb72f:

    # Carla "It's not exhaustive, but if you get through these, it would be great."
    Carla "Список не полный, но если вы справитесь с ними, будет здорово."

# game/scripts/episode2.rpy:1028
translate russian ep2_06_school_269ba127:

    # X "That's a big help there! Thank you!"
    X "Спасибо за столь большую помощь!"

# game/scripts/episode2.rpy:1030
translate russian ep2_06_school_fff23de0:

    # X "And is the placement test going to take some time?"
    X "А сколько займёт по времени вступительный тест?"

# game/scripts/episode2.rpy:1032
translate russian ep2_06_school_eac061ae:

    # Carla "Shouldn't take more than two hours."
    Carla "Не более двух часов."

# game/scripts/episode2.rpy:1033
translate russian ep2_06_school_8ff78c1a:

    # Carla "It's mostly about basic knowledge."
    Carla "В основном проверяем именно базовые знания."

# game/scripts/episode2.rpy:1035
translate russian ep2_06_school_03d5ef53:

    # X "Alright."
    X "Понятно."

# game/scripts/episode2.rpy:1036
translate russian ep2_06_school_49cfcf3f:

    # X "And thank you for going out of your way to help [D]!"
    X "И спасибо вам за то, что прилагаете все усилия, чтобы помочь [D]!"

# game/scripts/episode2.rpy:1038
translate russian ep2_06_school_3e1826a0:

    # Carla "That's my job."
    Carla "Это моя работа."

# game/scripts/episode2.rpy:1040
translate russian ep2_06_school_c240fc99:

    # X "And how's the elbow?"
    X "А как ваш локоть?"

# game/scripts/episode2.rpy:1042
translate russian ep2_06_school_bfcd1f11:

    # Carla "Nothing major, just need to not strain too much."
    Carla "Ничего серьёзного, просто нельзя напрягаться."

# game/scripts/episode2.rpy:1044
translate russian ep2_06_school_8e4a7ebf:

    # Carla "I have to go now. When [D] finishes, just leave the papers on the table."
    Carla "Мне пора идти. Когда [D] закончит, пусть оставит бумаги на столе."

# game/scripts/episode2.rpy:1045
translate russian ep2_06_school_5560d353:

    # Carla "I'll pick them up when I get back."
    Carla "Я заберу их, когда вернусь."

# game/scripts/episode2.rpy:1046
translate russian ep2_06_school_820a4a7c:

    # X "Take care!"
    X "Берегите себя!"

# game/scripts/episode2.rpy:1048
translate russian ep2_06_school_ab9046a3:

    # X "How's it going [D]?"
    X "Ну как ты, [D]?"

# game/scripts/episode2.rpy:1049
translate russian ep2_06_school_155fd725:

    # Carla "Nearly done."
    Carla "Почти закончила."

# game/scripts/episode2.rpy:1050
translate russian ep2_06_school_6d6c441b:

    # X "Already? That was faster than expected."
    X "Уже? Ты быстрее, чем я думал."

# game/scripts/episode2.rpy:1052
translate russian ep2_06_school_1d1d485f:

    # X "[Charlie]! How are things going?"
    X "[Charlie]! Как ваши дела?"

# game/scripts/episode2.rpy:1053
translate russian ep2_06_school_ab7f6f78:

    # Charlie "I've dug some more info on these people."
    Charlie "Я раскопал ещё кое-какую информацию об этих людях."

# game/scripts/episode2.rpy:1054
translate russian ep2_06_school_fc75500b:

    # Charlie "Can we meet to talk later at the park?"
    Charlie "Можем позже встретиться и поговорить в парке?"

# game/scripts/episode2.rpy:1055
translate russian ep2_06_school_a034287c:

    # X "Of course."
    X "Конечно."

# game/scripts/episode2.rpy:1056
translate russian ep2_06_school_8534bf96:

    # Charlie "And can you bring your dad along?"
    Charlie "И не могли бы вы взять с собой свою дочь?"

# game/scripts/episode2.rpy:1057
translate russian ep2_06_school_e52bbf9d:

    # X "Ok..."
    X "Окей..."

# game/scripts/episode2.rpy:1058
translate russian ep2_06_school_fe08658d:

    # X "Don't see any problem with that."
    X "Не проблема."

# game/scripts/episode2.rpy:1059
translate russian ep2_06_school_6b464da5:

    # X "Are you okay if we vist the park [D]?"
    X "Ты не против, если мы сходим в парк, [D]?"

# game/scripts/episode2.rpy:1061
translate russian ep2_06_school_64fb8d0b:

    # D "It's fine."
    D "Конечно."

# game/scripts/episode2.rpy:1063
translate russian ep2_06_school_048b8602:

    # X "We can get ice cream on the way."
    X "По дороге можем купить мороженое."

# game/scripts/episode2.rpy:1064
translate russian ep2_06_school_0dd4a437:

    # X "Got any flavor preferences?"
    X "Есть вкусовые предпочтения?"

# game/scripts/episode2.rpy:1065
translate russian ep2_06_school_a3498d59:

    # D "Not really, just as long as it's not mint!"
    D "Не особо, но главное, чтобы не мятное!"

# game/scripts/episode2.rpy:1066
translate russian ep2_06_school_8a071e3c:

    # X "OK. We can start off with the basic ones."
    X "Хорошо. Мы можем начать с основных вкусов."

# game/scripts/episode2.rpy:1067
translate russian ep2_06_school_68dbdf5e:

    # X "Is vanilla okay?"
    X "Ванильное подойдет?"

# game/scripts/episode2.rpy:1068
translate russian ep2_06_school_7f50e911:

    # D "Yes."
    D "Да."

# game/scripts/episode2.rpy:1071
translate russian ep2_06_school_c7907c40:

    # X "Nobody around, it's quiet."
    X "Вокруг никого, тихо."

# game/scripts/episode2.rpy:1072
translate russian ep2_06_school_26d7c55d:

    # D "You want the cherry?"
    D "Хочешь вишенку?"

# game/scripts/episode2.rpy:1074
translate russian ep2_06_school_e0bf2cd8:

    # X "What?"
    X "Что?"

# game/scripts/episode2.rpy:1075
translate russian ep2_06_school_d293690c:

    # D "Do you want my cherry?"
    D "Хочешь мою вишенку?"

# game/scripts/episode2.rpy:1078
translate russian ep2_06_school_6bea7fc3:

    # X "Sure, I'll take your cherry..."
    X "Конечно, я возьму твою вишенку..."

# game/scripts/episode2.rpy:1080
translate russian ep2_06_school_6f866193:

    # X "No, you can have it."
    X "Нет, можешь оставить себе."

# game/scripts/episode2.rpy:1084
translate russian ep2_06_school_9a964e73:

    # X "Do you like it?"
    X "Тебе нравится?"

# game/scripts/episode2.rpy:1086
translate russian ep2_06_school_c8d2f9ed:

    # D "Aha!"
    D "Ага!"

# game/scripts/episode2.rpy:1088
translate russian ep2_06_school_897b5bcf:

    # D "It's my favorite now!"
    D "Теперь ванильное моё любимое!"

# game/scripts/episode2.rpy:1090
translate russian ep2_06_school_94c4eed6:

    # X "What was your favorite before?"
    X "Какое было твоим любимым раньше?"

# game/scripts/episode2.rpy:1092
translate russian ep2_06_school_96d4b8ec:

    # D "Had one once that wasn't mint. I don't know what it was called."
    D "Однажды я пробовала одно, не мятное. Не знаю, как оно называлось."

# game/scripts/episode2.rpy:1094
translate russian ep2_06_school_a14a013a:

    # X "Well there are loads to try. You're in for an adventure!"
    X "Что ж, есть что попробовать. Это будут настоящие приключения!"

# game/scripts/episode2.rpy:1096
translate russian ep2_06_school_e990fb6a:

    # D "Yay!"
    D "Ура!"

# game/scripts/episode2.rpy:1098
translate russian ep2_06_school_9fc2c940:

    # "Kitty" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🐱{/font}"
    "Котёнок" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🐱{/font}"

# game/scripts/episode2.rpy:1099
translate russian ep2_06_school_ff18a95b:

    # X "Wow look at that."
    X "Вау, ты только посмотри на него."

# game/scripts/episode2.rpy:1100
translate russian ep2_06_school_be2356f9:

    # D "Kitty!"
    D "Котёнок!"

# game/scripts/episode2.rpy:1101
translate russian ep2_06_school_9fc2c940_1:

    # "Kitty" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🐱{/font}"
    "Котёнок" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🐱{/font}"

# game/scripts/episode2.rpy:1103
translate russian ep2_06_school_5c838aac:

    # D "Hey little guy! You lost?"
    D "Привет, малыш! Ты потерялся?"

# game/scripts/episode2.rpy:1104
translate russian ep2_06_school_6b7f912b:

    # "Kitty" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}😺{/font}"
    "Котёнок" "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}😺{/font}"

# game/scripts/episode2.rpy:1105
translate russian ep2_06_school_6d8493a6:

    # D "Are you hungry?"
    D "Ты голоден?"

# game/scripts/episode2.rpy:1107
translate russian ep2_06_school_9ac28b82:

    # Charlie "Is that your kitty?"
    Charlie "Это твой котёнок?"

# game/scripts/episode2.rpy:1108
translate russian ep2_06_school_8599d76e:

    # D "We just met."
    D "Мы только что познакомились."

# game/scripts/episode2.rpy:1109
translate russian ep2_06_school_9269a5a0:

    # Charlie "And you're friends already? Extraordinary!"
    Charlie "И вы уже друзья? Необыкновенно!"

# game/scripts/episode2.rpy:1110
translate russian ep2_06_school_e75390ab:

    # Charlie "I'm [Charlie] by the way, and you must be..."
    Charlie "Кстати, я [Charlie], а ты, должно быть..."

# game/scripts/episode2.rpy:1111
translate russian ep2_06_school_559ea7fb:

    # D "[D]"
    D "[D]"

# game/scripts/episode2.rpy:1112
translate russian ep2_06_school_040875c8:

    # Charlie "Nice to meet you."
    Charlie "Приятно познакомиться."

# game/scripts/episode2.rpy:1113
translate russian ep2_06_school_fd495f0b:

    # Charlie "I just need to talk to your dad for a bit."
    Charlie "Мне нужно немного поговорить с твоим отцом."

# game/scripts/episode2.rpy:1114
translate russian ep2_06_school_68fe6ea1:

    # Charlie "Can you stay here and play with your kitty?"
    Charlie "Ты можешь остаться здесь и поиграть со своим котёнком?"

# game/scripts/episode2.rpy:1115
translate russian ep2_06_school_071b3e20:

    # D "Okay..."
    D "Ладно..."

# game/scripts/episode2.rpy:1117
translate russian ep2_06_school_89e4d8f8:

    # Charlie "Cute kid."
    Charlie "Красавица."

# game/scripts/episode2.rpy:1119
translate russian ep2_06_school_6a383ecf:

    # X "So, what have you found so far?"
    X "Итак, что вы уже накопали?"

# game/scripts/episode2.rpy:1121
translate russian ep2_06_school_932469e4:

    # Charlie "Been digging around for info on the family."
    Charlie "Стал искать информацию о семье."

# game/scripts/episode2.rpy:1123
translate russian ep2_06_school_936b89ec:

    # Charlie "But their records have been privated from around the time [Emily] was adopted."
    Charlie "Но их записи были засекречены примерно с того времени, когда [Emily] была удочерена."

# game/scripts/episode2.rpy:1124
translate russian ep2_06_school_46f5cd3b:

    # Charlie "And there aren't many digital traces from before."
    Charlie "Да и цифровых следов с тех времён не так уж и много."

# game/scripts/episode2.rpy:1126
translate russian ep2_06_school_be4c40cd:

    # Charlie "So I had whatever was in the archive faxed."
    Charlie "Всё, что было в архиве, я отправила по факсу."

# game/scripts/episode2.rpy:1128
translate russian ep2_06_school_192008a1:

    # X "Did something come up?"
    X "Что-то выяснилось?"

# game/scripts/episode2.rpy:1130
translate russian ep2_06_school_da2ad726:

    # Charlie "They were running some business back then, and there aren't many details about it."
    Charlie "Тогда у них был какой-то бизнес, и подробностей о нём не так много."

# game/scripts/episode2.rpy:1131
translate russian ep2_06_school_c2a0843f:

    # Charlie "But the thing is, the name Adalinda."
    Charlie "Но я наткнулась на имя - Адалинда."

# game/scripts/episode2.rpy:1133
translate russian ep2_06_school_772be887:

    # Charlie "It was their dad, she died at about the same age as [Emily]."
    Charlie "Это была их дочь, она умерла примерно в том же возрасте, что и [Emily]."

# game/scripts/episode2.rpy:1135
translate russian ep2_06_school_a16c2120:

    # X "So they adopted [Emily], who was around the same age as her and called her by her name..."
    X "Поэтому они удочерили [Emily], которая была примерно одного с ней возраста, и назвали её именем..."

# game/scripts/episode2.rpy:1137
translate russian ep2_06_school_9babe808:

    # Charlie "So they can pretend she never died, then after [D] was born, they switched to her."
    Charlie "Чтобы они могли притвориться, что она никогда не умирала. А потом, после рождения [D], переключились на неё."

# game/scripts/episode2.rpy:1139
translate russian ep2_06_school_e90d14f7:

    # X "That's fucked up!"
    X "Это просто пиздец!"

# game/scripts/episode2.rpy:1141
translate russian ep2_06_school_19406ce5:

    # Charlie "That's what it looks like."
    Charlie "Вот как-то так."

# game/scripts/episode2.rpy:1142
translate russian ep2_06_school_854086ad:

    # Charlie "So I'll need a warrant to look in to all the records."
    Charlie "Так что мне нужен ордер, чтобы просмотреть все записи."

# game/scripts/episode2.rpy:1144
translate russian ep2_06_school_d9fe11ec:

    # X "They also used fake names in the adoption process!"
    X "В процессе удочерения они также использовали вымышленные имена!"

# game/scripts/episode2.rpy:1145
translate russian ep2_06_school_5306a750:

    # X "That has to count against them."
    X "Это должно сыграть против них."

# game/scripts/episode2.rpy:1147
translate russian ep2_06_school_4d6159fb:

    # Charlie "Definitely!"
    Charlie "Определённо!"

# game/scripts/episode2.rpy:1149
translate russian ep2_06_school_ec9070db:

    # Charlie "But I have to clear up a few things first."
    Charlie "Но сначала я должна прояснить несколько моментов."

# game/scripts/episode2.rpy:1150
translate russian ep2_06_school_9f2e8296:

    # X "What's that?"
    X "Каких?"

# game/scripts/episode2.rpy:1152
translate russian ep2_06_school_7d1dcb70:

    # Charlie "Your dad said she was on the road for about a week before reaching the beach."
    Charlie "Ваша дочь сказала, что была в пути около недели, прежде чем добралась до пляжа."

# game/scripts/episode2.rpy:1153
translate russian ep2_06_school_168b6d93:

    # X "Yes"
    X "Да."

# game/scripts/episode2.rpy:1154
translate russian ep2_06_school_0dcc6187:

    # Charlie "But until now, there hasn't been any missing person report filled."
    Charlie "Но до сих пор не было ни одного заявления о пропаже человека."

# game/scripts/episode2.rpy:1155
translate russian ep2_06_school_a6878d17:

    # X "Considering all the shit they've done to her, I doubt they will."
    X "Учитывая всё то дерьмо, которое они с ней сделали, я сомневаюсь, что они его подадут."

# game/scripts/episode2.rpy:1157
translate russian ep2_06_school_5ad79f51:

    # Charlie "Maybe so."
    Charlie "Может быть и так."

# game/scripts/episode2.rpy:1158
translate russian ep2_06_school_b3a2b997:

    # Charlie "She also mentioned a journal [Emily] wrote, that she doesn't have."
    Charlie "Она также упомянула о дневнике [Emily], которого у неё нет."

# game/scripts/episode2.rpy:1159
translate russian ep2_06_school_bb5a05e8:

    # X "She also didn't have anything else on her."
    X "Больше при ней ничего не было."

# game/scripts/episode2.rpy:1161
translate russian ep2_06_school_d153a72e:

    # Charlie "And she was homeschooled, grew up isolated, and somehow managed to get all the way here."
    Charlie "Она училась на дому, росла в изоляции и каким-то образом смогла добраться сюда."

# game/scripts/episode2.rpy:1162
translate russian ep2_06_school_85e6a731:

    # X "Yeah public transport is a hell of a thing!"
    X "Да, общественный транспорт - тот ещё ад!"

# game/scripts/episode2.rpy:1164
translate russian ep2_06_school_28f91a0e:

    # X "And I also had a DNA test taken, so we'll have solid proof."
    X "А ещё я сдал тест на ДНК, так что у нас будут веские доказательства."

# game/scripts/episode2.rpy:1166
translate russian ep2_06_school_c10d958b:

    # Charlie "That's good, but it will take some time."
    Charlie "Это хорошо, но это займёт некоторое время."

# game/scripts/episode2.rpy:1167
translate russian ep2_06_school_813e0a40:

    # Charlie "Right now if her whole story is true and there's no missing person's report."
    Charlie "Если вся её история правдива и нет заявления о пропаже человека..."

# game/scripts/episode2.rpy:1169
translate russian ep2_06_school_9312972e:

    # Charlie "Means they have their own people looking for her."
    Charlie "Значит, у них есть свои люди, которые ищут её."

# game/scripts/episode2.rpy:1170
translate russian ep2_06_school_fd8544dd:

    # Charlie "Which means the longer we wait, the more likely it is they'll find her."
    Charlie "А значит, чем дольше мы будем ждать, тем больше вероятность, что они найдут её."

# game/scripts/episode2.rpy:1172
translate russian ep2_06_school_d2a7b328:

    # Charlie "So [X], I need you to be absolutely sure about her."
    Charlie "Итак, [X], мне нужно, чтобы вы были абсолютно уверены в ней."

# game/scripts/episode2.rpy:1173
translate russian ep2_06_school_af524752:

    # Charlie "I have a lot on the line for this."
    Charlie "Я многое поставила на карту ради этого дела."

# game/scripts/episode2.rpy:1174
translate russian ep2_06_school_a77ed4b4:

    # X "I haven't doubted it for a second!"
    X "Я не сомневаюсь в ней ни на секунду!"

# game/scripts/episode2.rpy:1176
translate russian ep2_06_school_79f4160b:

    # X "She. Is. My. Daughter!"
    X "Она. Моя. Дочь!"

# game/scripts/episode2.rpy:1178
translate russian ep2_06_school_7f0916db:

    # Charlie "OK then, we're going all in!"
    Charlie "Ладно, тогда мы идём ва-банк!"

# game/scripts/episode2.rpy:1180
translate russian ep2_06_school_5edafc3b:

    # Charlie "Never seen anyone be so good with animals."
    Charlie "Никогда не видела, чтобы кто-то так хорошо обращался с животными."

# game/scripts/episode2.rpy:1182
translate russian ep2_06_school_0327dfaf:

    # D "I would always try to make friends with them."
    D "Я всегда стараюсь подружиться с ними."

# game/scripts/episode2.rpy:1183
translate russian ep2_06_school_f254c400:

    # Charlie "That's just adorable."
    Charlie "Это просто очаровательно."

# game/scripts/episode2.rpy:1185
translate russian ep2_06_school_79f66fd3:

    # Charlie "Wait for my call. And take care of her."
    Charlie "Ждите моего звонка. И позаботьтесь о ней."

# game/scripts/episode2.rpy:1186
translate russian ep2_06_school_8e84d7b9:

    # X "I will."
    X "Конечно."

# game/scripts/episode2.rpy:1187
translate russian ep2_06_school_da9d8f4f:

    # X "And thank you!"
    X "И спасибо вам!"

# game/scripts/episode2.rpy:1188
translate russian ep2_06_school_7f3eb8b2:

    # Charlie "Don't mention it."
    Charlie "Не стоит благодарности."

# game/scripts/episode2.rpy:1190
translate russian ep2_06_school_324948c9:

    # X "Ready to leave?"
    X "Пойдём?"

# game/scripts/episode2.rpy:1192
translate russian ep2_06_school_06fd8134:

    # D "I am."
    D "Ага."

# game/scripts/episode2.rpy:1193
translate russian ep2_06_school_2f0800b2:

    # X "Are you sure?"
    X "Уверена?"

# game/scripts/episode2.rpy:1194
translate russian ep2_06_school_dea0849b:

    # D "Yes!"
    D "Да!"

# game/scripts/episode2.rpy:1195
translate russian ep2_06_school_ece5a994:

    # X "OK..."
    X "Хорошо..."

# game/scripts/episode2.rpy:1198
translate russian ep2_06_school_cd09bc91:

    # X "Hey [D], are you done changing?"
    X "Эй, [D], ты закончила переодеваться?"

# game/scripts/episode2.rpy:1199
translate russian ep2_06_school_51534d8b:

    # D "Come in!"
    D "Заходи!"

# game/scripts/episode2.rpy:1201
translate russian ep2_06_school_84ab04fa:

    # X "How are you feeling?"
    X "Как себя чувствуешь?"

# game/scripts/episode2.rpy:1203
translate russian ep2_06_school_8bbc4b12:

    # D "I'm fine."
    D "Нормально."

# game/scripts/episode2.rpy:1205
translate russian ep2_06_school_80bc9214:

    # X "And about the school situation. What do you think of that?"
    X "И о школе. Что ты об этом думаешь?"

# game/scripts/episode2.rpy:1207
translate russian ep2_06_school_f912e564:

    # D "I don't know, it would be nice to make friends."
    D "Не знаю, было бы здорово завести друзей."

# game/scripts/episode2.rpy:1209
translate russian ep2_06_school_6ccf4697:

    # X "Indeed, but it can be hard for you in the beginning."
    X "Да, но поначалу может быть трудно."

# game/scripts/episode2.rpy:1210
translate russian ep2_06_school_f907c2ee:

    # X "Could get overwhelming. So I want you to know that you can count on my support."
    X "Итак, я хочу, чтобы ты знала, что можешь рассчитывать на мою поддержку."

# game/scripts/episode2.rpy:1212
translate russian ep2_06_school_a058c9c0:

    # D "Thanks dad!"
    D "Спасибо, пап!"

# game/scripts/episode2.rpy:1214
translate russian ep2_06_school_50336b8b:

    # X "And about that kitty earlier, you seem to like it."
    X "И насчёт того котёнка - похоже, он тебе понравился."

# game/scripts/episode2.rpy:1216
translate russian ep2_06_school_344e4caa:

    # X "Maybe you wanted to take it home, you could have asked."
    X "Возможно, ты хотела забрать его домой. Могла спросить меня."

# game/scripts/episode2.rpy:1217
translate russian ep2_06_school_93cc9632:

    # X "Even if I say no, don't be afraid to ask."
    X "Даже если я откажу, не бойся спрашивать."

# game/scripts/episode2.rpy:1219
translate russian ep2_06_school_270ac63e:

    # D "It's true, I did want to keep him."
    D "Да, я действительно хотела оставить его себе."

# game/scripts/episode2.rpy:1221
translate russian ep2_06_school_0067376a:

    # D "But he was so small."
    D "Но он был таким маленьким."

# game/scripts/episode2.rpy:1222
translate russian ep2_06_school_81eec6f3:

    # D "He probably had a mommy and a daddy nearby."
    D "Наверное, у него есть мама и папа."

# game/scripts/episode2.rpy:1223
translate russian ep2_06_school_27bd17c9:

    # D "And I couldn't just take him away from them."
    D "И я не могла просто так забрать его у них."

# game/scripts/episode2.rpy:1225
translate russian ep2_06_school_c4c9b2c7:

    # X "That's... true, you can't just do that!"
    X "Это... правильно, так просто это делать нельзя!"

# game/scripts/episode2.rpy:1226
translate russian ep2_06_school_6cfa782c:

    # X "Anyway, you're probably tired..."
    X "В любом случае, ты, наверное, устала..."

# game/scripts/episode2.rpy:1228
translate russian ep2_06_school_e68f6a69:

    # D "Wait!"
    D "Постой!"

# game/scripts/episode2.rpy:1229
translate russian ep2_06_school_e0bf2cd8_1:

    # X "What?"
    X "Что?"

# game/scripts/episode2.rpy:1232
translate russian ep2_06_school_814d4885:

    # D "You have something over here."
    D "У тебя здесь что-то есть."

# game/scripts/episode2.rpy:1233
translate russian ep2_06_school_0348bb6f:

    # X "Where?"
    X "Где?"

# game/scripts/episode2.rpy:1236
translate russian ep2_06_school_f4fcc38a:

    # D "Here!"
    D "Здесь!"

# game/scripts/episode2.rpy:1238
translate russian ep2_06_school_86d32a3b:

    # X "What was that for?"
    X "Но за что?"

# game/scripts/episode2.rpy:1239
translate russian ep2_06_school_3dede8be:

    # D "For everything!"
    D "За всё!"

# game/scripts/episode2.rpy:1244
translate russian ep2_06_school_7c55a997:

    # D "Thank you!"
    D "Спасибо тебе!"

# game/scripts/episode2.rpy:1248
translate russian ep2_06_school_7c55a997_1:

    # D "Thank you!"
    D "Спасибо!"

# game/scripts/episode2.rpy:1250
translate russian ep2_06_school_b0ec9160:

    # X "And I forgot to tell you about the ice cream flavors."
    X "И я забыл рассказать тебе о вкусах мороженого."

# game/scripts/episode2.rpy:1252
translate russian ep2_06_school_c68ef306:

    # X "There are a lot of them, but there are so many combinations too."
    X "Их много, но и комбинаций тоже много."

# game/scripts/episode2.rpy:1253
translate russian ep2_06_school_df830036:

    # X "You can even enjoy mint in certain mixture."
    X "Ты даже можешь наслаждаться мятой в определенной комбинации."

# game/scripts/episode2.rpy:1254
translate russian ep2_06_school_25c20c30:

    # X "But we have enough time for those."
    X "Но у нас достаточно времени для этого."

# game/scripts/episode2.rpy:1256
translate russian ep2_06_school_48d24478:

    # X "[D], is something wrong?"
    X "[D], что-то не так?"

# game/scripts/episode2.rpy:1258
translate russian ep2_06_school_8e73b8c1:

    # D "I don't think so."
    D "Я так не думаю."

# game/scripts/episode2.rpy:1259
translate russian ep2_06_school_6cb00031:

    # X "OK, let's get some sleep."
    X "Ладно, давай спать."

# game/scripts/episode2.rpy:1261
translate russian ep2_06_school_811528fc:

    # "She seemed to space out a bit there."
    "Казалось, она немного отстранилась от происходящего."

# game/scripts/episode2.rpy:1262
translate russian ep2_06_school_d74a60fc:

    # "Maybe she's just tired."
    "Может, она просто устала."

# game/scripts/episode2.rpy:1264
translate russian ep2_06_school_9e9cf63e:

    # "Guess I'm also... erect?!"
    "Полагаю, я тоже... эрекция?!"

# game/scripts/episode2.rpy:1265
translate russian ep2_06_school_6af599c5:

    # "When did that happen?"
    "Когда это произошло?"

# game/scripts/episode2.rpy:1266
translate russian ep2_06_school_0378c35f:

    # "Is that what she was looking at?!"
    "Так вот на что она смотрела?!"

# game/scripts/episode2.rpy:1267
translate russian ep2_06_school_8cca26b6:

    # "Shit..."
    "Чёрт..."

translate russian strings:

    # game/scripts/episode2.rpy:65
    old "Keep searching"
    new "Продолжать искать"

    # game/scripts/episode2.rpy:65
    old "Try something else"
    new "Попробовать что-нибудь другое"

    # game/scripts/episode2.rpy:103
    old "Turn away first"
    new "Сначала отвернуться"

    # game/scripts/episode2.rpy:103
    old "Push the button"
    new "Нажать кнопку"

    # game/scripts/episode2.rpy:169
    old "Pull it down"
    new "Потянуть его вниз"

    # game/scripts/episode2.rpy:200
    old "Keep this a secret"
    new "Пусть держит это в секрете"

    # game/scripts/episode2.rpy:200
    old "Trust her"
    new "Довериться ей"

    # game/scripts/episode2.rpy:343
    old "[Carla]"
    new "[Carla]"

    # game/scripts/episode2.rpy:343
    old "Carol"
    new "Кэрол"

    # game/scripts/episode2.rpy:343
    old "Carma"
    new "Карма"

    # game/scripts/episode2.rpy:343
    old "Clara"
    new "Клара"

    # game/scripts/episode2.rpy:637
    old "Looks great"
    new "Выглядишь великолепно"

    # game/scripts/episode2.rpy:637
    old "Very cute"
    new "Очень мило"

    # game/scripts/episode2.rpy:637
    old "Lovely"
    new "Красотка"

    # game/scripts/episode2.rpy:637
    old "I don't like it"
    new "Мне такое не нравится"

    # game/scripts/episode2.rpy:661
    old "I"
    new "Мне"

    # game/scripts/episode2.rpy:661
    old "love"
    new "это"

    # game/scripts/episode2.rpy:661
    old "it"
    new "нравится"

    # game/scripts/episode2.rpy:661
    old "!"
    new "!"

    # game/scripts/episode2.rpy:690
    old "Get [Eileen]"
    new "Сходить за [Eileen]"

    # game/scripts/episode2.rpy:690
    old "Help her"
    new "Помочь самому"

    # game/scripts/episode2.rpy:784
    old "Check on the conversation"
    new "Подслушать разговор"

    # game/scripts/episode2.rpy:784
    old "Do the dishes"
    new "Мыть посуду"

    # game/scripts/episode2.rpy:897
    old "Go to bed"
    new "Пойти на кровать"

    # game/scripts/episode2.rpy:897
    old "Insist on the couch"
    new "Настаивать на диване"

    # game/scripts/episode2.rpy:981
    old "Cum!"
    new "Кончить!"

    # game/scripts/episode2.rpy:1076
    old "Take her cherry"
    new "Взять её вишенку"

    # game/scripts/episode2.rpy:1076
    old "Let her have it"
    new "Пусть оставит её себе"

    # game/scripts/episode2.rpy:1240
    old "Kiss on the cheek"
    new "Поцеловать в щёку"

    # game/scripts/episode2.rpy:1240
    old "Kiss on the forehead"
    new "Поцеловать в лоб"

    # game/scripts/episode2.rpy:1336
    old "Script break"
    new "Разрыв сценария"

