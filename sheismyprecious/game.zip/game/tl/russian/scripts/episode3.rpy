﻿# TODO: Translation updated at 2024-02-11 21:34
translate russian strings:

    old "Episode 3"
    new "Эпизод 3"

    old "Back In The Game"
    new "Снова в игре"

    old "Gentle"
    new "Нежно"

    old "Rythmic"
    new "Ритмично"

    old "Pounding"
    new "Толчки"

    old "Deep Thrusts"
    new "Глубокие толчки"

    old "POV"
    new "От 1-го лица"

    old "ACTION"
    new "БЛИЗКО"

    old "SIDE"
    new "СБОКУ"

    old "Prone"
    new "Лёжа"

    old "Ride"
    new "Наездница"

    old "END"
    new "ЗАКОНЧИТЬ"

    old "Slow"
    new "Медленно"

    old "Riding"
    new "Скачуще"

    old "Deep"
    new "Глубоко"

    old "BUTT"
    new "ПОПА"

    old "Fast"
    new "Быстро"

    old "Head Squeeze"
    new "Внимание головке"

    old "Hold Still"
    new "Не двигаться"

    old "Move a little"
    new "Немного двигаться"

    old "Shift Position"
    new "Сдвинуться"

    old "Try pulling back"
    new "Попробовать потянуться"

    old "KITTY"
    new "КИСКА"

# game/scripts/episode3.rpy:15
translate russian ep3_01_bathroom_fde30f4c:

    # "Of all the times, why did I get hard now?"
    "Почему у меня встал именно сейчас?"

# game/scripts/episode3.rpy:16
translate russian ep3_01_bathroom_fe3455c8:

    # "It can't be because of... her."
    "Это не может быть из-за... неё."

# game/scripts/episode3.rpy:18
translate russian ep3_01_bathroom_5eb9c25a:

    # "She does look so much like [Emily]."
    "Она так похожа на [Emily]."

# game/scripts/episode3.rpy:19
translate russian ep3_01_bathroom_5f479130:

    # "Yeah, that's probably it!"
    "Да, скорее всего, так и есть!"

# game/scripts/episode3.rpy:20
translate russian ep3_01_bathroom_16076183:

    # "Still, what did she make of it?"
    "И всё же, что она об этом подумала?"

# game/scripts/episode3.rpy:21
translate russian ep3_01_bathroom_535dd2b3:

    # "Maybe I should talk to her about this stuff tomorrow..."
    "Может, мне стоит поговорить с ней об этом завтра..."

# game/scripts/episode3.rpy:274
translate russian ep3_dream_scene_49c3d96c:

    # X "...so this is the first time you're being penetrated?!"
    X "...значит, это первый раз, когда в тебя проникают?!"

# game/scripts/episode3.rpy:275
translate russian ep3_dream_scene_28f6c382:

    # Emily "I told you, I've never put anything in there!"
    Emily "Я же говорила тебе, я никогда ничего туда не совала!"

# game/scripts/episode3.rpy:277
translate russian ep3_dream_scene_06df75e8:

    # X "Not even one of those tiny cucumbers?"
    X "Даже ни одного крошечного огурчика?"

# game/scripts/episode3.rpy:278
translate russian ep3_dream_scene_cbcb6954:

    # Emily "Don't tease me anymore!"
    Emily "Перестань дразнить меня!"

# game/scripts/episode3.rpy:280
translate russian ep3_dream_scene_ea26c359:

    # X "You really wanna start with such a big cucumber?"
    X "Ты правда хочешь начать с такого большого огурца?"

# game/scripts/episode3.rpy:281
translate russian ep3_dream_scene_59dc35c8:

    # Emily "Please [X]--"
    Emily "Пожалуйста, [X]--"

# game/scripts/episode3.rpy:288
translate russian ep3_dream_scene_7bdae608:

    # Emily "Aah!"
    Emily "Аах!"

# game/scripts/episode3.rpy:290
translate russian ep3_dream_scene_02098835:

    # Emily "It's passed, you can move now."
    Emily "Всё прошло, можешь продолжать."

# game/scripts/episode3.rpy:291
translate russian ep3_dream_scene_66dc1efd:

    # Emily "Please go slow..."
    Emily "Пожалуйста, не торопись..."

# game/scripts/episode3.rpy:297
translate russian ep3_dream_scene_46f9af13:

    # X "Oh wow!"
    X "Ух, вау!"

# game/scripts/episode3.rpy:298
translate russian ep3_dream_scene_1df2673d:

    # Emily "That's it!"
    Emily "Вот оно!"

# game/scripts/episode3.rpy:299
translate russian ep3_dream_scene_c1640518:

    # Emily "Make love to me [X]!"
    Emily "Займись со мной любовью, [X]!"

# game/scripts/episode3.rpy:327
translate russian continue_after_animation_25280b91:

    # X "Ugh!"
    X "Угх!"

# game/scripts/episode3.rpy:328
translate russian continue_after_animation_683424d6:

    # X "You feel so good [Emily]."
    X "Мне так хорошо, [Emily]."

# game/scripts/episode3.rpy:329
translate russian continue_after_animation_a661932e:

    # X "I want to do this forever!"
    X "Я хочу делать это вечно!"

# game/scripts/episode3.rpy:330
translate russian continue_after_animation_d41db32f:

    # Emily "Yes!"
    Emily "Да!"

# game/scripts/episode3.rpy:331
translate russian continue_after_animation_67c94966:

    # Emily "Me too daddy!"
    Emily "Я тоже, папочка!"

# game/scripts/episode3.rpy:332
translate russian continue_after_animation_e0bf2cd8:

    # X "What?"
    X "Что?"

# game/scripts/episode3.rpy:334
translate russian continue_after_animation_dd38644a:

    # D "I want your love deep inside me!"
    D "Я хочу, чтобы твоя любовь оказалась глубоко внутри меня!"

# game/scripts/episode3.rpy:335
translate russian continue_after_animation_6c74e990:

    # X "[D]?!"
    X "[D]?!"

# game/scripts/episode3.rpy:336
translate russian continue_after_animation_85bb3922:

    # X "No, this isn't right!"
    X "Нет, это неправильно!"

# game/scripts/episode3.rpy:337
translate russian continue_after_animation_3e193b93:

    # D "What's wrong dad?"
    D "Что случилось, пап?"

# game/scripts/episode3.rpy:341
translate russian continue_after_animation_d772d49d:

    # D "Are you hurting?"
    D "Тебе больно?"

# game/scripts/episode3.rpy:343
translate russian continue_after_animation_c8158f5e:

    # X "[D], umm..."
    X "[D], эмм..."

# game/scripts/episode3.rpy:344
translate russian continue_after_animation_5e252b90:

    # X "No I'm... I had a dream."
    X "Нет, я... мне приснился сон."

# game/scripts/episode3.rpy:345
translate russian continue_after_animation_3e793ae2:

    # X "What happened?"
    X "А что такое?"

# game/scripts/episode3.rpy:347
translate russian continue_after_animation_a3aedbc2:

    # D "I heard you and thought you were in pain."
    D "Я услышала стоны и подумала, что тебе больно."

# game/scripts/episode3.rpy:348
translate russian continue_after_animation_e91f1c3a:

    # D "Then went to the door and you called my name, so I came in."
    D "Потом подошла к двери, ты позвал меня, и я вошла."

# game/scripts/episode3.rpy:350
translate russian continue_after_animation_48237631:

    # X "Oh I see, thank you!"
    X "Ох, понятно, спасибо!"

# game/scripts/episode3.rpy:351
translate russian continue_after_animation_cc9afd6b:

    # X "But I'm fine, nothing to worry about."
    X "Но я в порядке, беспокоиться не о чем."

# game/scripts/episode3.rpy:352
translate russian continue_after_animation_00469b1a:

    # X "You can go back to bed."
    X "Можешь возвращаться в кровать."

# game/scripts/episode3.rpy:354
translate russian continue_after_animation_071b3e20:

    # D "Okay..."
    D "Хорошо..."

# game/scripts/episode3.rpy:362
translate russian continue_after_animation_1b9f3990:

    # "Must've been one of those reality leaking in to the dream type of situations."
    "Должно быть, это была одна из тех ситуаций, когда реальность просачивается в сон."

# game/scripts/episode3.rpy:363
translate russian continue_after_animation_7ff347c0:

    # "Yeah, that's probably it...."
    "Да, наверное, так оно и есть...."

# game/scripts/episode3.rpy:368
translate russian continue_after_animation_c3cca0df:

    # X "So about last night."
    X "Итак, о прошлой ночи."

# game/scripts/episode3.rpy:370
translate russian continue_after_animation_3dabebf1:

    # D "I'm sorry for going in your room like that!"
    D "Прости, что без спроса вошла в твою комнату!"

# game/scripts/episode3.rpy:372
translate russian continue_after_animation_0ba47707:

    # X "You have nothing to be sorry about!"
    X "Тебе не за что извиняться!"

# game/scripts/episode3.rpy:373
translate russian continue_after_animation_81e3e410:

    # X "I was just dreaming of... something. And just talked in my sleep, that's all."
    X "Мне просто снилось... кое-что. И я разговаривал во сне, вот и всё."

# game/scripts/episode3.rpy:375
translate russian continue_after_animation_da178122:

    # D "Was it a scary dream?"
    D "Снилось что-то страшное?"

# game/scripts/episode3.rpy:376
translate russian continue_after_animation_1c43a5c9:

    # X "Not exactly."
    X "Не совсем."

# game/scripts/episode3.rpy:378
translate russian continue_after_animation_42fd9d7e:

    # D "You really were not in pain?"
    D "У тебя правда ничего не болело в тот момент?"

# game/scripts/episode3.rpy:380
translate russian continue_after_animation_76250478:

    # X "I really wasn't. Why do you ask?"
    X "Да, правда. Почему ты спрашиваешь?"

# game/scripts/episode3.rpy:382
translate russian continue_after_animation_bff52151:

    # D "Because of the swelling."
    D "Из-за выпуклости."

# game/scripts/episode3.rpy:383
translate russian continue_after_animation_d8dd56b5:

    # X "Swelling?"
    X "Выпуклости?"

# game/scripts/episode3.rpy:384
translate russian continue_after_animation_5367c33d:

    # D "Of your willy."
    D "Твоего слоника."

# game/scripts/episode3.rpy:385
translate russian continue_after_animation_5557e740:

    # X "You mean my penis!"
    X "Ты имеешь в виду мой пенис!"

# game/scripts/episode3.rpy:387
translate russian continue_after_animation_e322ca39:

    # D "Yes, your..."
    D "Да, твой..."

# game/scripts/episode3.rpy:388
translate russian continue_after_animation_c7abf037:

    # "She doesn't seem to know much about this stuff."
    "Кажется, она мало что знает об этом."

# game/scripts/episode3.rpy:389
translate russian continue_after_animation_ca07d257:

    # "Better talk to her about it."
    "Лучше поговорить с ней."

# game/scripts/episode3.rpy:390
translate russian continue_after_animation_e001c662:

    # X "It's okay to say 'penis', that's not a dirty word."
    X "Говорить \"пенис\" - это нормально, это не ругательство."

# game/scripts/episode3.rpy:392
translate russian continue_after_animation_7b9eeb69:

    # X "And the swelling is normal."
    X "И выпуклость тоже нормально."

# game/scripts/episode3.rpy:394
translate russian continue_after_animation_ab77e852:

    # D "Oh."
    D "Ох."

# game/scripts/episode3.rpy:395
translate russian continue_after_animation_21f53673:

    # D "So then is it okay if I talk to you about my... private parts?"
    D "Тогда ничего, если я расскажу тебе о своих... интимных местах?"

# game/scripts/episode3.rpy:397
translate russian continue_after_animation_d515b7e1:

    # X "Perfectly fine. Whatever issues you have, you can tell me."
    X "Совершенно нормально. Какие бы проблемы у тебя ни возникли, ты можешь рассказать о них мне."

# game/scripts/episode3.rpy:398
translate russian continue_after_animation_50f65977:

    # X "Or talk to [Eileen] if you don't feel comfortable."
    X "Или поговори с [Eileen], если некомфортно."

# game/scripts/episode3.rpy:400
translate russian continue_after_animation_fbd4c581:

    # D "Well there's this thing..."
    D "Ну, есть одна вещь..."

# game/scripts/episode3.rpy:401
translate russian continue_after_animation_0ad44c85:

    # D "I'm not sure if it's pee, but I found my panties were a little wet this morning."
    D "Не уверена, что это моча, но сегодня утром я обнаружила, что мои трусики немного влажные."

# game/scripts/episode3.rpy:403
translate russian continue_after_animation_5f8aff33:

    # X "Did you have any pains?"
    X "Были ли у тебя какие-либо боли?"

# game/scripts/episode3.rpy:405
translate russian continue_after_animation_7eeecafc:

    # D "No, but I also felt a little warm down there."
    D "Нет, но я также почувствовала, что там, внизу, немного тепло."

# game/scripts/episode3.rpy:407
translate russian continue_after_animation_64651d32:

    # "Maybe she's just developing."
    "Может быть, она просто растёт."

# game/scripts/episode3.rpy:408
translate russian continue_after_animation_fbb5ba36:

    # X "I see, in any case, if anything comes up don't be shy about talking about it."
    X "Понимаю, в любом случае, если что-то ещё произойдёт, не стесняйся говорить об этом."

# game/scripts/episode3.rpy:410
translate russian continue_after_animation_a058c9c0:

    # D "Thanks dad!"
    D "Спасибо, папа!"

# game/scripts/episode3.rpy:415
translate russian continue_after_animation_632178fa:

    # Maya "Goodmornig [X]."
    Maya "Доброе утро, [X]."

# game/scripts/episode3.rpy:416
translate russian continue_after_animation_892eac09:

    # Maya "I'm calling to ask if you have time to do a session this afternoon."
    Maya "Я звоню, чтобы спросить, есть ли у вас время провести сеанс сегодня днём."

# game/scripts/episode3.rpy:417
translate russian continue_after_animation_78be0355:

    # X "I can do that. We have to get preparing for the competition."
    X "Конечно. Нам нужно готовиться к олимпиаде."

# game/scripts/episode3.rpy:422
translate russian continue_after_animation_cd5a36b1:

    # X "Hey doc! What's new?"
    X "Привет, док! Что нового?"

# game/scripts/episode3.rpy:423
translate russian continue_after_animation_a0d6f651:

    # Joan "I spoke to the gynecologist about your dad."
    Joan "Я поговорила с гинекологом о вашей дочери."

# game/scripts/episode3.rpy:424
translate russian continue_after_animation_eba56e8b:

    # Joan "Her hormone levels are too low for her age."
    Joan "У неё слишком низкий уровень гормонов для её возраста."

# game/scripts/episode3.rpy:425
translate russian continue_after_animation_a4f4713f:

    # X "What does that mean?"
    X "Что это значит?"

# game/scripts/episode3.rpy:426
translate russian continue_after_animation_57c93d14:

    # Joan "One possibility she is a late bloomer, but she has already had a growth spurt."
    Joan "Возможно, она поздно расцвела, но у неё уже произошёл скачок роста."

# game/scripts/episode3.rpy:427
translate russian continue_after_animation_90c641b2:

    # Joan "So it's likely she took puberty blockers."
    Joan "Так что, скорее всего, она принимала блокаторы полового созревания."

# game/scripts/episode3.rpy:428
translate russian continue_after_animation_a4f396d5:

    # Joan "Do you know if she had any implants or injections."
    Joan "Вы не знаете, были ли у неё какие-либо имплантаты или инъекции?"

# game/scripts/episode3.rpy:429
translate russian continue_after_animation_35286392:

    # X "No, I can ask her."
    X "Нет, но я могу спросить её."

# game/scripts/episode3.rpy:430
translate russian continue_after_animation_d1304ed9:

    # Joan "And if you could locate her medical file, that would really help."
    Joan "И если вы сможете найти её медицинскую карту, это действительно поможет."

# game/scripts/episode3.rpy:431
translate russian continue_after_animation_ac38eab9:

    # X "I'll try."
    X "Я попробую."

# game/scripts/episode3.rpy:435
translate russian continue_after_animation_7d99cf66:

    # X "...so did you normally take any medication back home?"
    X "...а дома ты обычно принимала какие-нибудь лекарства?"

# game/scripts/episode3.rpy:437
translate russian continue_after_animation_5725ee05:

    # D "I took some when I had a cold."
    D "Принимала какие-то во время простуды."

# game/scripts/episode3.rpy:439
translate russian continue_after_animation_705c1ad4:

    # X "That's normal."
    X "Это нормально."

# game/scripts/episode3.rpy:440
translate russian continue_after_animation_fb514824:

    # X "Did you take any pills when you weren't sick?"
    X "Ты принимала какие-нибудь таблетки, когда не болела?"

# game/scripts/episode3.rpy:441
translate russian continue_after_animation_a49a69eb:

    # X "Or any other medication like injections?"
    X "Или какие-либо другие лекарства, например, инъекции?"

# game/scripts/episode3.rpy:442
translate russian continue_after_animation_42d87d05:

    # D "No."
    D "Нет."

# game/scripts/episode3.rpy:444
translate russian continue_after_animation_5a43404d:

    # D "Oh wait!"
    D "Ой, подожди!"

# game/scripts/episode3.rpy:446
translate russian continue_after_animation_4cd2799b:

    # D "I had a flu shot this year."
    D "В этом году мне сделали прививку от гриппа."

# game/scripts/episode3.rpy:447
translate russian continue_after_animation_cb5fee5a:

    # D "It's that after a month, I still got sick."
    D "Дело в том, что через месяц я всё равно заболела."

# game/scripts/episode3.rpy:449
translate russian continue_after_animation_0b436681:

    # X "That's not right?"
    X "Она была не от гриппа, да?"

# game/scripts/episode3.rpy:451
translate russian continue_after_animation_66005784:

    # X "I talked to her about it..."
    X "Я говорил с ней об этом..."

# game/scripts/episode3.rpy:455
translate russian continue_after_animation_4c5ec2dc:

    # Joan "She could've had an implant injected."
    Joan "Ей могли ввести имплантат."

# game/scripts/episode3.rpy:456
translate russian continue_after_animation_94dc54fc:

    # Joan "You need to come in for more tests so I can say for certain."
    Joan "Вам нужно сдать ещё несколько анализов, чтобы я могла сказать наверняка."

# game/scripts/episode3.rpy:457
translate russian continue_after_animation_813c9822:

    # X "Will do, thanks doc!"
    X "Сделаем, спасибо, док!"

# game/scripts/episode3.rpy:460
translate russian continue_after_animation_eb30fcee:

    # "Fucking hell, what other shit have they done to her..."
    "Чёрт возьми, что ещё они с ней делали..."

# game/scripts/episode3.rpy:461
translate russian continue_after_animation_7f88a6ae:

    # "She may not even recognize things that happened to her."
    "Она может даже не осознавать того, что с ней произошло."

# game/scripts/episode3.rpy:462
translate russian continue_after_animation_8c1f3fef:

    # X "I know a lot of this is new to you."
    X "Я знаю, многое из этого для тебя в новинку."

# game/scripts/episode3.rpy:464
translate russian continue_after_animation_502ac425:

    # X "And it takes time to familiarize with things around here, so it's OK if you're not comfortable with anything."
    X "И требуется время, чтобы ознакомиться со здешними вещами, так что ничего страшного, если тебя что-то не устраивает."

# game/scripts/episode3.rpy:465
translate russian continue_after_animation_a2f1b7ef:

    # X "Like eating something you don't like or calling me 'dad', you don't have to force yourself to do any of that."
    X "Например, есть что-то, что тебе не нравится, или называть меня папой, тебе не нужно заставлять себя делать что-либо из этого."

# game/scripts/episode3.rpy:467
translate russian continue_after_animation_6ba497b1:

    # D "I'm comfortable with calling you 'dad'."
    D "Мне нравится называть тебя папой."

# game/scripts/episode3.rpy:469
translate russian continue_after_animation_fb96fe7c:

    # X "Even if you know me for only a few days?"
    X "Даже если ты знаешь меня всего несколько дней?"

# game/scripts/episode3.rpy:471
translate russian continue_after_animation_aa63e215:

    # D "I knew about you from what mom wrote in the journal."
    D "Я знала о тебе из того, что мама написала в дневнике."

# game/scripts/episode3.rpy:472
translate russian continue_after_animation_aa2e9753:

    # D "I would imagine us all talking together."
    D "Я представляла, как мы все вместе разговариваем."

# game/scripts/episode3.rpy:474
translate russian continue_after_animation_b226f779:

    # X "And you never mentioned that stuff to your foster parents?"
    X "И ты никогда не упоминала об этом своим приёмным родителям?"

# game/scripts/episode3.rpy:476
translate russian continue_after_animation_21a9391d:

    # D "No, [Radford] was never around. And he didn't want to talk when he was."
    D "Нет, [Radford]а никогда не было рядом. А если был, то не хотел разговаривать."

# game/scripts/episode3.rpy:477
translate russian continue_after_animation_47d96f66:

    # D "And with [Odelia] I always had to act the way she wanted, or get punished."
    D "А с [Odelia] мне всегда приходилось вести себя так, как она хотела, или быть наказанной."

# game/scripts/episode3.rpy:478
translate russian continue_after_animation_4750333a:

    # D "She never wanted to see {i}me{/i}"
    D "Она никогда не хотела видеть {i}меня{/i}."

# game/scripts/episode3.rpy:480
translate russian continue_after_animation_a7b17e06:

    # X "Well screw them!"
    X "Ну и чёрт с ними!"

# game/scripts/episode3.rpy:481
translate russian continue_after_animation_77cec20a:

    # X "They don't deserve you anyway!"
    X "Они всё равно тебя не заслуживают!"

# game/scripts/episode3.rpy:482
translate russian continue_after_animation_a3fb1ef8:

    # X "Hey, what do you think about mathematics?"
    X "Эй, что ты думаешь о математике?"

# game/scripts/episode3.rpy:484
translate russian continue_after_animation_406f0fa6:

    # D "I think it's interesting."
    D "Я думаю, она интересная."

# game/scripts/episode3.rpy:486
translate russian continue_after_animation_da43c7a1:

    # X "So you don't hate it! That's good."
    X "Значит, ты не ненавидишь её! Это хорошо."

# game/scripts/episode3.rpy:487
translate russian continue_after_animation_4b09de16:

    # X "I asked because a couple of girls are coming over for tutoring later."
    X "Я спросил это, потому что позже к нам придут две девушки для занятий."

# game/scripts/episode3.rpy:488
translate russian continue_after_animation_7285d0c0:

    # X "You've met [Alecia] the other day."
    X "На днях ты познакомилась с [Alecia]."

# game/scripts/episode3.rpy:489
translate russian continue_after_animation_7f50e911:

    # D "Yes."
    D "Да."

# game/scripts/episode3.rpy:490
translate russian continue_after_animation_b3f51836:

    # X "Her friend is really good at math and I'm helping her get ready for a competition."
    X "Её подруга действительно хороша в математике, и я помогаю ей подготовиться к олимпиаде."

# game/scripts/episode3.rpy:492
translate russian continue_after_animation_df6b9d47:

    # D "Wow really?"
    D "Вау, правда?"

# game/scripts/episode3.rpy:494
translate russian continue_after_animation_d9f23df4:

    # X "If you want, you can study together."
    X "Если хочешь, вы можете заниматься вместе."

# game/scripts/episode3.rpy:495
translate russian continue_after_animation_f03647a3:

    # X "Maybe get to know each other and even become friends."
    X "Возможно, узнаете друг друга получше и даже подружитесь."

# game/scripts/episode3.rpy:497
translate russian continue_after_animation_03180807:

    # D "I would like that!"
    D "Я бы хотела этого!"

# game/scripts/episode3.rpy:500
translate russian continue_after_animation_53f4cfe2:

    # X "Think that's them!"
    X "Думаю, это они!"

# game/scripts/episode3.rpy:504
translate russian continue_after_animation_011b7b83:

    # Maya "Why hello there!"
    Maya "Привет!"

# game/scripts/episode3.rpy:505
translate russian continue_after_animation_352ffe31:

    # Maya "I'm [Maya], this young girl is [Sophie]"
    Maya "Я - [Maya], а эта девушка - [Sophie]."

# game/scripts/episode3.rpy:506
translate russian continue_after_animation_999410a2:

    # X "This is [D], my dad."
    X "Это [D], моя дочь."

# game/scripts/episode3.rpy:508
translate russian continue_after_animation_a1b05dd3:

    # D "Hello miss [Maya] and [Sophie]!"
    D "Здравствуйте, мисс [Maya] и [Sophie]!"

# game/scripts/episode3.rpy:509
translate russian continue_after_animation_711a142b:

    # Sophie "Hi!"
    Sophie "Привет!"

# game/scripts/episode3.rpy:511
translate russian continue_after_animation_38a935d6:

    # X "[D], can you show [Sophie] to your room?"
    X "[D], можешь показать [Sophie] свою комнату?"

# game/scripts/episode3.rpy:512
translate russian continue_after_animation_3d7314d6:

    # X "I don't really have a better place for you at the moment."
    X "На данный момент у меня нет лучшего места для вас."

# game/scripts/episode3.rpy:514
translate russian continue_after_animation_a7d6fca3:

    # D "Of course!"
    D "Конечно!"

# game/scripts/episode3.rpy:516
translate russian continue_after_animation_aa64c4b6:

    # D "It's up the stairs over here."
    D "Она там, наверх по лестнице."

# game/scripts/episode3.rpy:518
translate russian continue_after_animation_5a52ec5b:

    # Maya "Do you have a moment to talk?"
    Maya "У вас есть минутка для разговора?"

# game/scripts/episode3.rpy:521
translate russian continue_after_animation_895373f0:

    # X "What about [Alecia], is she not coming?"
    X "А как же [Alecia], она не придёт?"

# game/scripts/episode3.rpy:523
translate russian continue_after_animation_d827be39:

    # Maya "They called her in for work today."
    Maya "Сегодня её вызвали на работу."

# game/scripts/episode3.rpy:524
translate russian continue_after_animation_8bfdd958:

    # Maya "She did promise to come by later."
    Maya "Она обещала прийти позже."

# game/scripts/episode3.rpy:526
translate russian continue_after_animation_0db3ac33:

    # X "Does she need a ride?"
    X "Её нужно подвезти?"

# game/scripts/episode3.rpy:528
translate russian continue_after_animation_56db0fc5:

    # Maya "No, a co-worked will bring her."
    Maya "Нет, её привезёт коллега."

# game/scripts/episode3.rpy:530
translate russian continue_after_animation_9896730e:

    # X "And how are things going at The Home?"
    X "Как там в детском доме?"

# game/scripts/episode3.rpy:532
translate russian continue_after_animation_3ddcef56:

    # Maya "We'll be alright, at least till the next fundraiser."
    Maya "Всё нормально, по крайней мере, до следующего сбора денег."

# game/scripts/episode3.rpy:534
translate russian continue_after_animation_91bc6d43:

    # X "When is it?"
    X "Когда он будет?"

# game/scripts/episode3.rpy:536
translate russian continue_after_animation_1409290c:

    # Maya "Christmas, I've been told it's the best time to organize it."
    Maya "Мне сказали, что Рождество - лучшее время для его организации."

# game/scripts/episode3.rpy:538
translate russian continue_after_animation_101563ed:

    # X "That makes sense."
    X "В этом есть смысл."

# game/scripts/episode3.rpy:539
translate russian continue_after_animation_b04c8c28:

    # X "But it would be much better to just have enough funding from the city."
    X "Но было бы гораздо лучше просто получить достаточное финансирование от города."

# game/scripts/episode3.rpy:541
translate russian continue_after_animation_2bffaf4c:

    # Maya "We've tried that, but they keep saying there's no need because the orphanage is doing fine."
    Maya "Мы попробовали, но они продолжают говорить, что в этом нет необходимости, потому что с детским домом всё хорошо."

# game/scripts/episode3.rpy:543
translate russian continue_after_animation_b9877a22:

    # X "So they're thinking of giving even less just like the previous year."
    X "Поэтому они думают дать ещё меньше, как и в прошлом году."

# game/scripts/episode3.rpy:545
translate russian continue_after_animation_7d2a624d:

    # X "Plus the reason you're doing fine is because of the community!"
    X "К тому же, причина, по которой у вас все хорошо, кроется в сообществе!"

# game/scripts/episode3.rpy:546
translate russian continue_after_animation_92243b63:

    # X "But what would they know, it's not like they're part of it!"
    X "Да и откуда им это знать, ведь они же не часть этого!"

# game/scripts/episode3.rpy:548
translate russian continue_after_animation_4c073dd9:

    # Maya "Maybe there are bigger issues that ours."
    Maya "Может быть, есть проблемы посерьёзнее наших."

# game/scripts/episode3.rpy:550
translate russian continue_after_animation_333aa2ab:

    # X "Well yeah, but it's not like they're taking care of those either."
    X "Да, но и о них они тоже не заботятся."

# game/scripts/episode3.rpy:551
translate russian continue_after_animation_bedbe7ca:

    # X "Anyway, it's going to be some time till Christmas."
    X "В любом случае, до Рождества ещё далеко."

# game/scripts/episode3.rpy:552
translate russian continue_after_animation_1fb94f1d:

    # X "And prices have shot up since last year."
    X "И цены взлетели с прошлого года."

# game/scripts/episode3.rpy:554
translate russian continue_after_animation_e4075d47:

    # Maya "I have managed to offset that by supplying food from the farm."
    Maya "Мне удалось компенсировать это, поставляя продукты с фермы."

# game/scripts/episode3.rpy:556
translate russian continue_after_animation_32f135ec:

    # X "Have you found someone to help, or maybe a husband?"
    X "Вы нашли кого-то, кто может помочь? Может быть, муж?"

# game/scripts/episode3.rpy:558
translate russian continue_after_animation_ca90bfea:

    # Maya "A husband... not yet I'm afraid."
    Maya "Муж... боюсь, пока нет."

# game/scripts/episode3.rpy:559
translate russian continue_after_animation_7f1816fd:

    # Maya "But [Alecia] has been coming with me."
    Maya "Но [Alecia] ездила со мной."

# game/scripts/episode3.rpy:560
translate russian continue_after_animation_9a580958:

    # X "She's keeping busy I see."
    X "Вижу, она очень занята."

# game/scripts/episode3.rpy:562
translate russian continue_after_animation_8ed6c1bf:

    # Maya "It does seem like she enjoys the learning the process."
    Maya "Похоже, ей нравится процесс обучения."

# game/scripts/episode3.rpy:563
translate russian continue_after_animation_332a60f0:

    # X "I'll keep that in mind."
    X "Буду иметь это в виду."

# game/scripts/episode3.rpy:565
translate russian continue_after_animation_692e0f1d:

    # Maya "Now I won't take more of your time."
    Maya "Не буду больше отнимать у вас время."

# game/scripts/episode3.rpy:566
translate russian continue_after_animation_612218b6:

    # X "I'll see you out."
    X "Я провожу вас."

# game/scripts/episode3.rpy:568
translate russian continue_after_animation_2034ca70:

    # Maya "No please, it's fine."
    Maya "Нет, пожалуйста, не нужно."

# game/scripts/episode3.rpy:569
translate russian continue_after_animation_b1e865d7:

    # Maya "I'll come pick up the girls later."
    Maya "Я заеду за девочками позже."

# game/scripts/episode3.rpy:570
translate russian continue_after_animation_03d5ef53:

    # X "Alright."
    X "Окей."

# game/scripts/episode3.rpy:572
translate russian continue_after_animation_96274ca7:

    # Sophie "...and right now we're studying this."
    Sophie "...и прямо сейчас мы изучаем это."

# game/scripts/episode3.rpy:573
translate russian continue_after_animation_8fee8770:

    # D "I don't know about that."
    D "Я ничего об этом не знаю."

# game/scripts/episode3.rpy:574
translate russian continue_after_animation_cec6bf03:

    # D "But there was a question about this on the test, didn't figure it out."
    D "В тесте было задание с этим, я его не поняла."

# game/scripts/episode3.rpy:576
translate russian continue_after_animation_c3467cc1:

    # Sophie "If you know this much, maybe we'll be in the same grade."
    Sophie "Если ты так много знаешь, может быть, мы будем в одном классе."

# game/scripts/episode3.rpy:578
translate russian continue_after_animation_b5e7c7ac:

    # D "I would like that."
    D "Мне бы этого хотелось."

# game/scripts/episode3.rpy:580
translate russian continue_after_animation_8eee2926:

    # Sophie "And you can have mister [X] help you in any case."
    Sophie "И в любом случае ты можешь попросить мистера [X] помочь тебе."

# game/scripts/episode3.rpy:582
translate russian continue_after_animation_43ab6c21:

    # X "Who is this mister [X] you're refering to?"
    X "Кто этот мистер [X], о котором ты говоришь?"

# game/scripts/episode3.rpy:584
translate russian continue_after_animation_1c40b665:

    # Sophie "Sorry, [X]."
    Sophie "Простите, [X]."

# game/scripts/episode3.rpy:586
translate russian continue_after_animation_9a5af023:

    # X "So I did a review of the material and also looked at the previous tests."
    X "Итак, я посмотрел материал, а также изучил предыдущие тесты."

# game/scripts/episode3.rpy:587
translate russian continue_after_animation_8ce14445:

    # X "Let's start off by looking how you solved the previous problems at the competition."
    X "Начнём с того, что посмотрим, как ты решала предыдущие задачи на соревнованиях."

# game/scripts/episode3.rpy:589
translate russian continue_after_animation_064406f0:

    # D "At the competition you mentioned?"
    D "Что за соревнования?"

# game/scripts/episode3.rpy:591
translate russian continue_after_animation_6fa166db:

    # Sophie "I participated in the Olympiad these past years."
    Sophie "В последние годы я участвовала в олимпиадах."

# game/scripts/episode3.rpy:593
translate russian continue_after_animation_2d685471:

    # D "So that's why you know all this stuff!"
    D "Так вот почему ты всё это знаешь!"

# game/scripts/episode3.rpy:595
translate russian continue_after_animation_6c28902d:

    # Sophie "I go over most of the material beforehand."
    Sophie "Большую часть материала я просматриваю заранее."

# game/scripts/episode3.rpy:597
translate russian continue_after_animation_fa48be36:

    # X "So that it's all fresh in your mind."
    X "Чтобы всё это было свежо в памяти."

# game/scripts/episode3.rpy:601
translate russian continue_after_animation_345034eb:

    # Sophie "That problem took me a while, I lost time on it coming up with a more elegant solution."
    Sophie "Эта задача заняла меня надолго. Я потеряла много времени, придумывая более элегантное решение."

# game/scripts/episode3.rpy:603
translate russian continue_after_animation_9af51742:

    # X "I see, you went with the obvious approach, and it ended up being too long."
    X "Вижу, ты выбрала очевидное решение, и в итоге оно оказалось слишком длинным."

# game/scripts/episode3.rpy:605
translate russian continue_after_animation_02222d70:

    # Sophie "That's right."
    Sophie "Именно так."

# game/scripts/episode3.rpy:607
translate russian continue_after_animation_c5b8316e:

    # X "They have more of these types of problems on later stages."
    X "На более поздних этапах олимпиад возникает больше подобных задач."

# game/scripts/episode3.rpy:608
translate russian continue_after_animation_398f56f6:

    # X "So let's work on those now."
    X "Так что давайте поработаем над ними сейчас."

# game/scripts/episode3.rpy:610
translate russian continue_after_animation_46ce5dc8:

    # D "Do they give less points if your solution is too long?"
    D "Ставят ли они меньше баллов, если твоё решение слишком длинное?"

# game/scripts/episode3.rpy:612
translate russian continue_after_animation_f06edf56:

    # X "If they worked out a simpler one before the test, yes."
    X "Если они предполагали более простой вариант решения задачи, то да."

# game/scripts/episode3.rpy:614
translate russian continue_after_animation_e6570b9d:

    # Sophie "You can also think up something new. That's worth extra."
    Sophie "Также можно придумать что-то новое. За это ставят дополнительные баллы."

# game/scripts/episode3.rpy:618
translate russian continue_after_animation_4b14c483:

    # X "We're nearing the end here. I'll go make prep some sandwitches."
    X "Что ж, почти закончили. Пойду приготовлю сэндвичи."

# game/scripts/episode3.rpy:620
translate russian continue_after_animation_084d299d:

    # D "I can help."
    D "Я могу помочь."

# game/scripts/episode3.rpy:622
translate russian continue_after_animation_6cf55077:

    # X "No need for that. You girls just relax here."
    X "В этом нет необходимости. Вы, девочки, просто отдыхайте."

# game/scripts/episode3.rpy:624
translate russian continue_after_animation_46a4c3c2:

    # "Better skip the onions again, play it safe."
    "Лучше снова не класть лук, на всякий случай."

# game/scripts/episode3.rpy:627
translate russian continue_after_animation_b316f870:

    # X "It's open, come on in!"
    X "Открыто, входите!"

# game/scripts/episode3.rpy:629
translate russian continue_after_animation_c85c810e:

    # X "Hey, you made it!"
    X "Эй, ты пришла!"

# game/scripts/episode3.rpy:630
translate russian continue_after_animation_a4327726:

    # Alecia "I only got out now. And that was our deal."
    Alecia "Меня отпустили только сейчас. Как мы и договаривались."

# game/scripts/episode3.rpy:632
translate russian continue_after_animation_9baf736a:

    # X "I get it, but that was only half of it."
    X "Я понимаю, но это только половина договора."

# game/scripts/episode3.rpy:634
translate russian continue_after_animation_182946a5:

    # Alecia "I know."
    Alecia "Я знаю."

# game/scripts/episode3.rpy:636
translate russian continue_after_animation_99fc4a3a:

    # X "And we're almost finished for today. So can you wash the salad?"
    X "И на сегодня мы почти закончили. Можешь помыть салат?"

# game/scripts/episode3.rpy:638
translate russian continue_after_animation_45236dbe:

    # Alecia "Yeah, sure."
    Alecia "Да, конечно."

# game/scripts/episode3.rpy:640
translate russian continue_after_animation_35628c10:

    # "If she likes agriculture, I can try to get a rise out of her and engage with something."
    "Если ей нравится агрономия, я могу попытаться вызвать у неё интерес и увлечь чем-нибудь."

# game/scripts/episode3.rpy:641
translate russian continue_after_animation_c1446b59:

    # X "I got some salad from a local farmer. But I don't know, it's probably the same from the store."
    X "Я купил его у местного фермера. Наверное, это такой же салат, что и в магазине."

# game/scripts/episode3.rpy:642
translate russian continue_after_animation_5e2502f5:

    # Alecia "It's not the same."
    Alecia "Не такой же."

# game/scripts/episode3.rpy:643
translate russian continue_after_animation_67aeeb90:

    # X "It's all green and tastes lke nothing, what's the difference?"
    X "Они оба зеленые, а вкус не чувствуется, какая разница?"

# game/scripts/episode3.rpy:645
translate russian continue_after_animation_d290230e:

    # Alecia "It's not even close!"
    Alecia "Даже близко не один и то же!"

# game/scripts/episode3.rpy:646
translate russian continue_after_animation_89f52cea:

    # Alecia "Have you even tried comparing anything else, other than lettuce?"
    Alecia "Вы хотя бы пробовали сравнивать что-нибудь ещё, кроме салата?"

# game/scripts/episode3.rpy:648
translate russian continue_after_animation_fc79abaf:

    # X "But that's the only salad, what else is there?"
    X "Но у меня есть только салат, что ещё нужно?"

# game/scripts/episode3.rpy:650
translate russian continue_after_animation_b3b85c48:

    # Alecia "You can't be serious!"
    Alecia "Да вы шутите!"

# game/scripts/episode3.rpy:652
translate russian continue_after_animation_476e4f84:

    # Alecia "Are sandwiches the only thing you make?"
    Alecia "Вы готовите только сэндвичи?"

# game/scripts/episode3.rpy:653
translate russian continue_after_animation_0783e249:

    # X "I can boil eggs too."
    X "Я также умею варить яйца."

# game/scripts/episode3.rpy:655
translate russian continue_after_animation_926fcfc1:

    # Alecia "Try spinach, carrots, cucumbers, tomatoes, they're all better from local producers."
    Alecia "Попробуйте шпинат, морковь, огурцы, помидоры - все они лучше от местных производителей."

# game/scripts/episode3.rpy:657
translate russian continue_after_animation_1cda2ba5:

    # X "You sound really sure about all that."
    X "Ты, кажется, действительно уверена в этом."

# game/scripts/episode3.rpy:658
translate russian continue_after_animation_b5c262c3:

    # X "They might be just buying it from a chain store and marketing it like that."
    X "Возможно, они просто покупают всё в магазине и продают якобы своё."

# game/scripts/episode3.rpy:659
translate russian continue_after_animation_203ce8f5:

    # X "How would you even know?"
    X "Откуда тебе знать?"

# game/scripts/episode3.rpy:661
translate russian continue_after_animation_9123a84b:

    # Alecia "Because I've gone with them, and worked there."
    Alecia "Потому что я работала с ними."

# game/scripts/episode3.rpy:663
translate russian continue_after_animation_134e3165:

    # X "Oh really?"
    X "Правда?"

# game/scripts/episode3.rpy:664
translate russian continue_after_animation_ae689cd7:

    # X "I'd like to go there too one day."
    X "Я бы тоже хотел когда-нибудь съездить туда."

# game/scripts/episode3.rpy:666
translate russian continue_after_animation_3d9d922c:

    # Alecia "[Maya] often goes home to tend the crops and works most of the day."
    Alecia "[Maya] часто уходит домой, чтобы ухаживать за посевами, и большую часть дня работает."

# game/scripts/episode3.rpy:667
translate russian continue_after_animation_20c64e9a:

    # Alecia "Feel free to lend a hand."
    Alecia "Не стесняйтесь протянуть руку помощи."

# game/scripts/episode3.rpy:669
translate russian continue_after_animation_0223bce6:

    # X "I know she cares a lot about you guys, I'm worried that she's pushing herself too much."
    X "Я знаю, что она очень заботится о вас, ребята, но беспокоюсь, что она слишком сильно себя нагружает."

# game/scripts/episode3.rpy:671
translate russian continue_after_animation_efbeff36:

    # Alecia "Yeah, wanted to help but she said no."
    Alecia "Да, я хотела помочь, но она отказала мне."

# game/scripts/episode3.rpy:673
translate russian continue_after_animation_0283f4d1:

    # Alecia "Then I told her I was interested in agriculture, so she wouldn't feel guilty for using me or something."
    Alecia "Тогда я сказала ей, что интересуюсь агрономией, чтобы она не чувствовала себя виноватой за то, что якобы использовала меня."

# game/scripts/episode3.rpy:675
translate russian continue_after_animation_1b7a0bcc:

    # X "That's considerate."
    X "Тактично."

# game/scripts/episode3.rpy:676
translate russian continue_after_animation_0759fc73:

    # X "It's not healthy to work that much. I can make some time to help."
    X "Так много работать вредно для здоровья. Я могу найти немного времени, чтобы помочь."

# game/scripts/episode3.rpy:678
translate russian continue_after_animation_39f02934:

    # Alecia "We're close to harvest, so I'll hold you to that."
    Alecia "Уже скоро сбор урожая, так что дам вам знать, как придёт время."

# game/scripts/episode3.rpy:680
translate russian continue_after_animation_f6e926c7:

    # X "I'll try some new stuff next time, don't want you girls to get bored of me."
    X "В следующий раз я попробую что-нибудь новенькое. Не хочу, чтобы я вам, девочки, надоел."

# game/scripts/episode3.rpy:681
translate russian continue_after_animation_348a8c45:

    # Alecia "How considerate."
    Alecia "Как предусмотрительно."

# game/scripts/episode3.rpy:683
translate russian continue_after_animation_fce3291b:

    # Sophie "Hope we will be in the same class!"
    Sophie "Надеюсь, мы будем учиться в одном классе!"

# game/scripts/episode3.rpy:684
translate russian continue_after_animation_08c29bdb:

    # D "Me too!"
    D "Я тоже!"

# game/scripts/episode3.rpy:685
translate russian continue_after_animation_ca31b912:

    # Alecia "Bye there."
    Alecia "До свидания."

# game/scripts/episode3.rpy:686
translate russian continue_after_animation_6c529624:

    # D "Bye bye!"
    D "Пока, пока!"

# game/scripts/episode3.rpy:690
translate russian continue_after_animation_a80a1dc6:

    # X "So did you enjoy it?"
    X "Тебе понравилось?"

# game/scripts/episode3.rpy:691
translate russian continue_after_animation_186afa30:

    # X "Not the math, hanging out with [Sophie] I mean."
    X "Имею в виду не математику, а общение с [Sophie]."

# game/scripts/episode3.rpy:693
translate russian continue_after_animation_75baada3:

    # D "I did, she's very nice!"
    D "Да, она очень милая!"

# game/scripts/episode3.rpy:694
translate russian continue_after_animation_0dbcd1b8:

    # D "And can we do more math?"
    D "И можем ли мы ещё позаниматься математикой?"

# game/scripts/episode3.rpy:696
translate russian continue_after_animation_af0e8133:

    # X "More!? Of course, we can do as much as you want!"
    X "Ещё!? Конечно, мы можем заниматься сколько захочешь!"

# game/scripts/episode3.rpy:697
translate russian continue_after_animation_f8e4845e:

    # X "But for today, let's just relax."
    X "Но на сегодня хватит, давай просто отдохнём."

# game/scripts/episode3.rpy:698
translate russian continue_after_animation_778ca776:

    # X "Got a few movies over here, tell me if you want any of them"
    X "У меня есть несколько фильмов. Какой хочешь посмотреть?"

# game/scripts/episode3.rpy:700
translate russian continue_after_animation_b72bc322:

    # X "That's a classic action movie, lots of shooting and explosions."
    X "Это классический боевик, много перестрелок и взрывов."

# game/scripts/episode3.rpy:701
translate russian continue_after_animation_a926909c:

    # D "Oh..."
    D "Ээ..."

# game/scripts/episode3.rpy:702
translate russian continue_after_animation_7b2920cb:

    # X "Not interested I see."
    X "Не заинтересовал, я вижу."

# game/scripts/episode3.rpy:705
translate russian continue_after_animation_18c21575:

    # D "What's this?"
    D "Что это?"

# game/scripts/episode3.rpy:706
translate russian continue_after_animation_7ca6f4fb:

    # X "It's a comedy, with ghosts and stuff."
    X "Это комедия, с призраками и прочим."

# game/scripts/episode3.rpy:707
translate russian continue_after_animation_fcedf5ca:

    # D "Is it scary?"
    D "Он страшный?"

# game/scripts/episode3.rpy:708
translate russian continue_after_animation_aa2fd6f9:

    # X "Maybe for little kids, but you're a big girl."
    X "Может, для малышей да, но ты уже большая девочка."

# game/scripts/episode3.rpy:711
translate russian continue_after_animation_2c115594:

    # X "This is more of a science-fiction. And this one's actually scary."
    X "Это скорее научная фантастика. И он действительно страшный."

# game/scripts/episode3.rpy:713
translate russian continue_after_animation_51b76fec:

    # D "I read some science fiction books, they were fun!"
    D "Я прочитала несколько научно-фантастических книг, они были забавными!"

# game/scripts/episode3.rpy:714
translate russian continue_after_animation_e9ff8d30:

    # X "We can talk about them."
    X "Мы можем поговорить о них."

# game/scripts/episode3.rpy:717
translate russian continue_after_animation_54c4ad44:

    # X "I don't know how that got there."
    X "Не знаю, как он ко мне попал."

# game/scripts/episode3.rpy:718
translate russian continue_after_animation_cedb3c3d:

    # D "What is it about?"
    D "О чём он?"

# game/scripts/episode3.rpy:719
translate russian continue_after_animation_1d2fa072:

    # X "Don't know, I've never seen it."
    X "Не знаю, я ещё его не смотрел."

# game/scripts/episode3.rpy:721
translate russian continue_after_animation_d9863342:

    # X "But watching movies like this on a TV isn't doing them justice."
    X "Но просмотр подобных фильмов по телевизору не отдаёт им должного."

# game/scripts/episode3.rpy:722
translate russian continue_after_animation_cc2b97d3:

    # X "There are places in town where you can watch movies on a giant screen!"
    X "В городе есть места, где можно посмотреть фильмы на гигантском экране!"

# game/scripts/episode3.rpy:724
translate russian continue_after_animation_822b2daa:

    # D "You mean cinemas?"
    D "Ты имеешь в виду кинотеатры?"

# game/scripts/episode3.rpy:725
translate russian continue_after_animation_ddffe675:

    # X "Ever been to one?"
    X "Когда-нибудь была там?"

# game/scripts/episode3.rpy:727
translate russian continue_after_animation_040c564a:

    # D "No, but I read about them."
    D "Нет, но я читала о них."

# game/scripts/episode3.rpy:728
translate russian continue_after_animation_6aed2803:

    # X "Well that won't do!"
    X "Ну, так дело не пойдёт!"

# game/scripts/episode3.rpy:730
translate russian continue_after_animation_42911239:

    # X "We can check one out tomorrow. How does that sound?"
    X "Мы можем сходить в один из них завтра. Как тебе идея?"

# game/scripts/episode3.rpy:732
translate russian continue_after_animation_69478917:

    # D "Great!"
    D "Отлично!"

# game/scripts/episode3.rpy:734
translate russian continue_after_animation_eaaa34b8:

    # "Now which movie to watch?"
    "А какой фильм посмотреть сейчас?"

# game/scripts/episode3.rpy:739
translate russian continue_after_animation_175f1e00:

    # "This is probably the safe option."
    "Этот, пожалуй, самый безопасный вариант."

# game/scripts/episode3.rpy:740
translate russian continue_after_animation_5b4e0324:

    # X "Let's see what this one's about."
    X "Давай посмотрим, о чём он."

# game/scripts/episode3.rpy:744
translate russian continue_after_animation_a7a0eccd:

    # X "Well that was... a movie."
    X "Ну, это был... фильм."

# game/scripts/episode3.rpy:746
translate russian continue_after_animation_650fcc42:

    # D "I enjoyed it."
    D "Мне понравилось."

# game/scripts/episode3.rpy:748
translate russian continue_after_animation_7c01a20c:

    # X "Now time for bed, it's getting late."
    X "А теперь пора спать, уже поздно."

# game/scripts/episode3.rpy:752
translate russian continue_after_animation_d35ef31c:

    # X "Let's go with this one."
    X "Давай посмотрим этот."

# game/scripts/episode3.rpy:756
translate russian continue_after_animation_56f607db:

    # X "And it's over."
    X "И конец."

# game/scripts/episode3.rpy:758
translate russian continue_after_animation_4da88a25:

    # D "That was fun!"
    D "Это было весело!"

# game/scripts/episode3.rpy:760
translate russian continue_after_animation_7c01a20c_1:

    # X "Now time for bed, it's getting late."
    X "А теперь пора спать, уже поздно."

# game/scripts/episode3.rpy:765
translate russian continue_after_animation_db1355fc:

    # "Looked like she was interested in this one."
    "Похоже, этот её заинтересовал."

# game/scripts/episode3.rpy:766
translate russian continue_after_animation_7e7a2435:

    # X "If it gets too scary, we can always stop."
    X "Если тебе станет слишком страшно, мы всегда можем остановиться."

# game/scripts/episode3.rpy:767
translate russian continue_after_animation_b5e21b9f:

    # D "Okay!"
    D "Хорошо!"

# game/scripts/episode3.rpy:771
translate russian continue_after_animation_68637d9c:

    # X "It's over."
    X "Конец."

# game/scripts/episode3.rpy:773
translate russian continue_after_animation_163e929b:

    # X "You got scared a few time, but you watched the entire thing."
    X "Несколько раз испугалась, но всё же посмотрела до конца."

# game/scripts/episode3.rpy:775
translate russian continue_after_animation_dddcb969:

    # D "I wanted to see the whole story."
    D "Я хотела увидеть всю историю."

# game/scripts/episode3.rpy:777
translate russian continue_after_animation_4f8d4969:

    # X "It is captivating."
    X "Она завораживает."

# game/scripts/episode3.rpy:778
translate russian continue_after_animation_7c01a20c_2:

    # X "Now time for bed, it's getting late."
    X "А теперь пора спать, уже поздно."

# game/scripts/episode3.rpy:782
translate russian continue_after_animation_21845ff2:

    # X "You just have to see the classics first."
    X "Начнём с классики."

# game/scripts/episode3.rpy:783
translate russian continue_after_animation_071b3e20_1:

    # D "Okay..."
    D "Ладно..."

# game/scripts/episode3.rpy:787
translate russian continue_after_animation_55aebe0d:

    # X "That's it."
    X "Конец."

# game/scripts/episode3.rpy:789
translate russian continue_after_animation_b9487200:

    # D "That was exiting."
    D "Это было потрясающе."

# game/scripts/episode3.rpy:791
translate russian continue_after_animation_7c01a20c_3:

    # X "Now time for bed, it's getting late."
    X "А теперь пора спать, уже поздно."

# game/scripts/episode3.rpy:795
translate russian continue_after_animation_71b84993:

    # "Still no news today."
    "Сегодня по-прежнему никаких новостей."

# game/scripts/episode3.rpy:796
translate russian continue_after_animation_e4a3bbd3:

    # "Gotta get some shuteye..."
    "Надо немного поспать..."

# game/scripts/episode3.rpy:802
translate russian continue_after_animation_9f8720a5:

    # D "dad... Are you awake?"
    D "Пап... Ты не спишь?"

# game/scripts/episode3.rpy:806
translate russian continue_after_animation_9ab3b940:

    # X "Yes, is something wrong?"
    X "Да, что-то случилось?"

# game/scripts/episode3.rpy:807
translate russian continue_after_animation_17f69cd9:

    # D "I'm scared!"
    D "Мне страшно!"

# game/scripts/episode3.rpy:808
translate russian continue_after_animation_f0d9fc6b:

    # D "Can I come in?"
    D "Можно войти?"

# game/scripts/episode3.rpy:809
translate russian continue_after_animation_a034287c:

    # X "Of course."
    X "Конечно."

# game/scripts/episode3.rpy:811
translate russian continue_after_animation_10315a8c:

    # D "I'm scared of... aliens."
    D "Я боюсь... инопланетян."

# game/scripts/episode3.rpy:813
translate russian continue_after_animation_4fc491dd:

    # X "That's normal, after watching that movie."
    X "Это нормально, после просмотра того фильма."

# game/scripts/episode3.rpy:814
translate russian continue_after_animation_fab02c56:

    # X "You can sleep here if you want."
    X "Если хочешь, можешь переночевать со мной."

# game/scripts/episode3.rpy:815
translate russian continue_after_animation_7c55a997:

    # D "Thank you!"
    D "Спасибо!"

# game/scripts/episode3.rpy:817
translate russian continue_after_animation_61d84536:

    # D "I know it's silly, but I can't help it."
    D "Я знаю, что это глупо, но ничего не могу с собой поделать."

# game/scripts/episode3.rpy:819
translate russian continue_after_animation_15c2355c:

    # X "We all have that reaction."
    X "У всех нас была такая реакция."

# game/scripts/episode3.rpy:820
translate russian continue_after_animation_303d6103:

    # X "First time is when I was little. We had the bathroom on the other end on the hallway."
    X "Первый раз - когда я был маленьким. Туалет находился в другом конце коридора."

# game/scripts/episode3.rpy:822
translate russian continue_after_animation_6e293880:

    # D "And what did you do?"
    D "И что ты сделал?"

# game/scripts/episode3.rpy:824
translate russian continue_after_animation_cec359d3:

    # X "I mentioned I was little. So I had the genius idea to just let it out the window."
    X "Я упомянул, что был маленьким. И мне пришла в голову гениальная идея просто сделать это в окно."

# game/scripts/episode3.rpy:826
translate russian continue_after_animation_fdd2c6d5:

    # D "You peed out the window?"
    D "Ты пописал в окно?"

# game/scripts/episode3.rpy:828
translate russian continue_after_animation_c8875320:

    # X "Yeah, but don't tell anyone!"
    X "Да, но никому не рассказывай!"

# game/scripts/episode3.rpy:829
translate russian continue_after_animation_afe30f95:

    # X "I actually got away with that, unlike other things."
    X "Мне это сошло с рук, в отличие от других проделок."

# game/scripts/episode3.rpy:831
translate russian continue_after_animation_0f6a87c4:

    # D "Like what?"
    D "Например, каких?"

# game/scripts/episode3.rpy:833
translate russian continue_after_animation_a250a877:

    # X "There was this one time..."
    X "Был один случай..."

# game/scripts/episode3.rpy:837
translate russian continue_after_animation_073885b5:

    # X "...so I ended peeling all the potatoes by myself for two weeks."
    X "...в итоге я две недели чистил картошку в одиночку."

# game/scripts/episode3.rpy:839
translate russian continue_after_animation_279b807d:

    # X "But they went easy on me--"
    X "Но они обошлись со мной справедливо--"

# game/scripts/episode3.rpy:840
translate russian continue_after_animation_d42b1a74:

    # "She's asleep."
    "Она уснула."

# game/scripts/episode3.rpy:842
translate russian continue_after_animation_a96b60c0:

    # "Better turn up the heat a bit..."
    "Лучше немного прибавить температуру..."

# game/scripts/episode3.rpy:845
translate russian continue_after_animation_e8077c6f:

    # D "Mmmm."
    D "Мммм."

# game/scripts/episode3.rpy:846
translate russian continue_after_animation_9ff8a76e:

    # D "dad..."
    D "Папа..."

# game/scripts/episode3.rpy:848
translate russian continue_after_animation_e680a7ee:

    # X "[D]?"
    X "[D]?"

# game/scripts/episode3.rpy:849
translate russian continue_after_animation_c8caa825:

    # X "Are you col--"
    X "Ты--"

# game/scripts/episode3.rpy:850
translate russian continue_after_animation_c769d247:

    # "Is she touching herself?"
    "Она трогает себя?"

# game/scripts/episode3.rpy:853
translate russian continue_after_animation_803dd1a4:

    # "Looks like she's still sleeping."
    "Похоже, она всё ещё спит."

# game/scripts/episode3.rpy:855
translate russian continue_after_animation_b80463dc:

    # "Better leave her be..."
    "Лучше уйти..."

# game/scripts/episode3.rpy:863
translate russian continue_after_animation_c79144ba:

    # "She's up already."
    "Она уже встала."

# game/scripts/episode3.rpy:865
translate russian continue_after_animation_003a8989:

    # "Clothes have pilled up."
    "Одежды уже целая куча."

# game/scripts/episode3.rpy:867
translate russian continue_after_animation_e804e301:

    # "Time to wash."
    "Время стирки."

# game/scripts/episode3.rpy:869
translate russian continue_after_animation_b73d4cde:

    # "Let's see, got my shirt, check, pants, check."
    "Посмотрим, рубашка, брюки."

# game/scripts/episode3.rpy:871
translate russian continue_after_animation_8b57161f:

    # "Her PJs are wet."
    "Её пижама мокрая."

# game/scripts/episode3.rpy:872
translate russian continue_after_animation_a01bbd01:

    # "It's not sweat, it's only this area."
    "Не из-за пота, только в этой области мокро."

# game/scripts/episode3.rpy:873
translate russian continue_after_animation_8e9b38a6:

    # "Wait!"
    "Стоп!"

# game/scripts/episode3.rpy:875
translate russian continue_after_animation_2fe60750:

    # X "Damn it!"
    X "Ебена мать!"

# game/scripts/episode3.rpy:876
translate russian continue_after_animation_28276cc7:

    # "It happened again. It has to be because of her."
    "Это случилось снова. Должно быть, это из-за неё."

# game/scripts/episode3.rpy:877
translate russian continue_after_animation_5117fd36:

    # "I could... take care of this."
    "Я мог бы... позаботиться об этом."

# game/scripts/episode3.rpy:881
translate russian continue_after_animation_3e911982:

    # "It's just because she reminds me of [Emily]."
    "Просто потому, что она напоминает мне [Emily]."

# game/scripts/episode3.rpy:883
translate russian continue_after_animation_fb6c8e33:

    # "Yeah, that's the reason."
    "Да, в этом вся причина."

# game/scripts/episode3.rpy:884
translate russian continue_after_animation_9920dd41:

    # "Get this done quickly."
    "Сделаю это быстро."

# game/scripts/episode3.rpy:888
translate russian continue_after_animation_47e7e2ab:

    # X "Ugghh!"
    X "Уггхх!"

# game/scripts/episode3.rpy:889
translate russian continue_after_animation_6fa9f974:

    # X "Fuck!"
    X "Бля!"

# game/scripts/episode3.rpy:891
translate russian continue_after_animation_4ec611da:

    # "That didn't feel as wrong as it should've..."
    "Это не казалось таким уж неправильным, как должно было..."

# game/scripts/episode3.rpy:895
translate russian continue_after_animation_fcb734bd:

    # "She's my dad!"
    "Она моя дочь!"

# game/scripts/episode3.rpy:896
translate russian continue_after_animation_f552ce75:

    # "What the hell am I thinking!"
    "О чём, чёрт возьми, я думаю!"

# game/scripts/episode3.rpy:899
translate russian continue_after_animation_ab942fc8:

    # "Haven't checked my mail in a while."
    "Давненько я не проверял свою почту."

# game/scripts/episode3.rpy:901
translate russian continue_after_animation_3d2e8a3e:

    # "What the hell, an offer to go back to the company?!"
    "Что за чёрт, предложение вернуться в компанию?!"

# game/scripts/episode3.rpy:902
translate russian continue_after_animation_762084a6:

    # "Guess they couldn't figure out all my pipelines."
    "Видимо, они не смогли разобраться в моём говнокоде."

# game/scripts/episode3.rpy:903
translate russian continue_after_animation_304dc1f1:

    # "A few from my team are still there, I could give them some help."
    "Некоторые из моей команды всё ещё там, я мог бы им помочь."

# game/scripts/episode3.rpy:904
translate russian continue_after_animation_9ce875e9:

    # "Or not."
    "Или нет."

# game/scripts/episode3.rpy:908
translate russian continue_after_animation_83262c29:

    # "They're probably struggling like hell."
    "Они, наверное, чертовски стараются."

# game/scripts/episode3.rpy:909
translate russian continue_after_animation_8448155b:

    # "I could do it for the team..."
    "Я мог бы сделать это ради команды..."

# game/scripts/episode3.rpy:912
translate russian continue_after_animation_b316be8a:

    # "Nah fuck'em!"
    "Да пошли они!"

# game/scripts/episode3.rpy:913
translate russian continue_after_animation_f9333da7:

    # "But since they gave me an opportunity to respond..."
    "Но раз уж они дали мне возможность ответить..."

# game/scripts/episode3.rpy:921
translate russian continue_after_animation_f4acfa56:

    # "Who could that be."
    "Кто бы это мог быть?"

# game/scripts/episode3.rpy:924
translate russian continue_after_animation_3485efb1:

    # X "Hey [Eileen], what's all this?"
    X "Привет, [Eileen], что всё это значит?"

# game/scripts/episode3.rpy:925
translate russian continue_after_animation_2e3a1180:

    # Eileen "Just a few things for that cutie, got more downstairs."
    Eileen "Всего несколько вещей для этой милашки, внизу есть ещё."

# game/scripts/episode3.rpy:926
translate russian continue_after_animation_7a804aeb:

    # Eileen "Got a cake there, so be careful!"
    Eileen "Там торт, так что будь осторожен!"

# game/scripts/episode3.rpy:927
translate russian continue_after_animation_03d5ef53_1:

    # X "Alright."
    X "Окей."

# game/scripts/episode3.rpy:929
translate russian continue_after_animation_5a7a712e:

    # Eileen "Where is the lady of the house?"
    Eileen "Где хозяйка дома?"

# game/scripts/episode3.rpy:931
translate russian continue_after_animation_c8de816c:

    # X "Upstairs. What did you get?"
    X "Наверху. Что ты принесла?"

# game/scripts/episode3.rpy:933
translate russian continue_after_animation_89ff813d:

    # Eileen "Girl stuff."
    Eileen "Девичьи штучки."

# game/scripts/episode3.rpy:934
translate russian continue_after_animation_9ae218d9:

    # Eileen "And I want to surprise her with the cake."
    Eileen "И я хочу удивить её тортом."

# game/scripts/episode3.rpy:936
translate russian continue_after_animation_0a28f6ea:

    # X "OK, I'll get on it."
    X "Хорошо, я займусь этим."

# game/scripts/episode3.rpy:938
translate russian continue_after_animation_c3fece90:

    # Eileen "No peeking!"
    Eileen "Не подглядывать!"

# game/scripts/episode3.rpy:940
translate russian continue_after_animation_47f6a295:

    # D "I have my eyes closed too!"
    D "У меня тоже глаза закрыты!"

# game/scripts/episode3.rpy:942
translate russian continue_after_animation_7c078612:

    # Eileen "Happy birthday!"
    Eileen "С днём рождения!"

# game/scripts/episode3.rpy:943
translate russian continue_after_animation_b481cf62:

    # D "Is that for me?"
    D "Это мне?"

# game/scripts/episode3.rpy:945
translate russian continue_after_animation_e9c7bb39:

    # Eileen "Sure is! It's strawberry, did I get that right?"
    Eileen "Конечно! Это клубника, я правильно поняла?"

# game/scripts/episode3.rpy:947
translate russian continue_after_animation_dea0849b:

    # D "Yes!"
    D "Да!"

# game/scripts/episode3.rpy:948
translate russian continue_after_animation_8d374151:

    # D "But it's actually not my birthday."
    D "Но на самом деле мой день рождения не сегодня."

# game/scripts/episode3.rpy:950
translate russian continue_after_animation_c6268753:

    # Eileen "Oh shoot! We better find something to celebrate then."
    Eileen "Ой, чёрт! Тогда нам лучше найти, что отпраздновать."

# game/scripts/episode3.rpy:952
translate russian continue_after_animation_35beac40:

    # Eileen "Any ideas daddy?"
    Eileen "Есть идеи, папочка?"

# game/scripts/episode3.rpy:957
translate russian continue_after_animation_ecb071d7:

    # X "It may not be your birthDAY but it is your birthYEAR."
    X "Возможно, сегодня не ДЕНЬ твоего рождения, но сейчас ГОД твоего рождения."

# game/scripts/episode3.rpy:959
translate russian continue_after_animation_95ef8ce8:

    # Eileen "Oh I see! That's a little loophole you found there."
    Eileen "Ага, я поняла! Ты придумал небольшую лазейку."

# game/scripts/episode3.rpy:961
translate russian continue_after_animation_cb6957c9:

    # Eileen "So Happy Birthyear to you..."
    Eileen "Так что с годом рождения тебя..."

# game/scripts/episode3.rpy:964
translate russian continue_after_animation_edbcd4ab:

    # X "How about your name day?"
    X "Как насчет дня именин?"

# game/scripts/episode3.rpy:966
translate russian continue_after_animation_eb04dbf8:

    # Eileen "That works I guess."
    Eileen "Думаю, подходит."

# game/scripts/episode3.rpy:971
translate russian continue_after_animation_c2b59c31:

    # Eileen "And now make a wish, but don't tell anyone."
    Eileen "А теперь загадай желание, но никому не говори."

# game/scripts/episode3.rpy:972
translate russian continue_after_animation_24a93824:

    # Eileen "Then blow out the candle."
    Eileen "Затем задуй свечу."

# game/scripts/episode3.rpy:974
translate russian continue_after_animation_0caf9fe7:

    # D "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🌬️{/font}"
    D "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🌬️{/font}"

# game/scripts/episode3.rpy:976
translate russian continue_after_animation_76c9fb76:

    # "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}👏 👏 👏{/font}"
    "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}👏 👏 👏{/font}"

# game/scripts/episode3.rpy:977
translate russian continue_after_animation_2e32624f:

    # X "Bravo!"
    X "Ура!"

# game/scripts/episode3.rpy:978
translate russian continue_after_animation_1732bc8e:

    # Eileen "Now let's grab a slice!"
    Eileen "А теперь давайте возьмём по кусочку!"

# game/scripts/episode3.rpy:980
translate russian continue_after_animation_79945813:

    # Eileen "How is it [D]?"
    Eileen "Как это было, [D]?"

# game/scripts/episode3.rpy:982
translate russian continue_after_animation_9a8d11e3:

    # Eileen "Be honest with me!"
    Eileen "Отвечай честно!"

# game/scripts/episode3.rpy:984
translate russian continue_after_animation_37b2f259:

    # D "It's straight fire!"
    D "Просто огонь!"

# game/scripts/episode3.rpy:986
translate russian continue_after_animation_d61dc6bf:

    # D "Did I use that right?"
    D "Я правильно это использовала?"

# game/scripts/episode3.rpy:988
translate russian continue_after_animation_1ce1f6df:

    # Eileen "Right on the money!"
    Eileen "Прямо в точку!"

# game/scripts/episode3.rpy:990
translate russian continue_after_animation_e650f26b:

    # D "[Sophie] said that about the house."
    D "[Sophie] сказала это о доме."

# game/scripts/episode3.rpy:992
translate russian continue_after_animation_6988079d:

    # X "Did she? Well I guess--"
    X "Правда? Ну, я думаю..."

# game/scripts/episode3.rpy:994
translate russian continue_after_animation_961235a5:

    # Eileen "I did most of the decorating in this place you know."
    Eileen "Знаете, я сделала большую часть украшения в этом месте."

# game/scripts/episode3.rpy:996
translate russian continue_after_animation_1a10d0a9:

    # Eileen "And would've done it properly but [X] basically kicked me out."
    Eileen "И сделала бы правильно, но [X] практически выгнал меня."

# game/scripts/episode3.rpy:998
translate russian continue_after_animation_8d0e7fcd:

    # X "I've seen your place, you would've just kept going if I let you."
    X "Я видел твою квартиру, ты бы просто продолжила, если бы я тебе позволил."

# game/scripts/episode3.rpy:1000
translate russian continue_after_animation_2fd97107:

    # Eileen "Damn right I would!"
    Eileen "Чертовски верно!"

# game/scripts/episode3.rpy:1001
translate russian continue_after_animation_86268987:

    # Eileen "There's just so much empty space here!"
    Eileen "Здесь просто так много пустого пространства!"

# game/scripts/episode3.rpy:1003
translate russian continue_after_animation_862f2b62:

    # Eileen "I'm sure [D] agrees with me."
    Eileen "Уверена, что [D] со мной согласна."

# game/scripts/episode3.rpy:1005
translate russian continue_after_animation_63667c39:

    # D "The house is... spacious."
    D "Дом... просторный."

# game/scripts/episode3.rpy:1007
translate russian continue_after_animation_9cfe6f43:

    # X "And that's a good thing!"
    X "И это хорошо!"

# game/scripts/episode3.rpy:1009
translate russian continue_after_animation_bbb14c18:

    # Eileen "But it's not the same thing, so don't make it seem like she's agreeing with you!"
    Eileen "Но это не одно и то же, так что не создавай впечатление, что она со мной не согласна!"

# game/scripts/episode3.rpy:1010
translate russian continue_after_animation_c912c29e:

    # Eileen "Now how about you both visit my place."
    Eileen "А теперь, как насчёт того, чтобы вы оба зашли ко мне?"

# game/scripts/episode3.rpy:1011
translate russian continue_after_animation_28eb372e:

    # Eileen "If I can convince [D] of my point of view, you must allow for more decorating."
    Eileen "Если мне удастся убедить [D] в своей точке зрения, ты должен разрешить больше украшений."

# game/scripts/episode3.rpy:1013
translate russian continue_after_animation_0fb8d540:

    # Eileen "And [D] will do all of it as she pleases."
    Eileen "И [D] будет делать всё по своему усмотрению."

# game/scripts/episode3.rpy:1015
translate russian continue_after_animation_cfe1bfb4:

    # X "I have no problem with that!"
    X "Без проблем!"

# game/scripts/episode3.rpy:1016
translate russian continue_after_animation_6c5d53b3:

    # X "And if she agrees with me, you have to bake her a cake whenever she wants!"
    X "А если она согласится со мной, ты должна будешь испечь ей торт, когда она захочет!"

# game/scripts/episode3.rpy:1018
translate russian continue_after_animation_3f89bf71:

    # Eileen "With pleasure, you're on!"
    Eileen "С удовольствием, я в деле!"

# game/scripts/episode3.rpy:1019
translate russian continue_after_animation_66a483f9:

    # X "But we'll have to do it another time."
    X "Но нам придётся сделать это в другой раз."

# game/scripts/episode3.rpy:1021
translate russian continue_after_animation_05d4bc05:

    # X "We already talked about checking out a movie at the cinema tonight."
    X "Мы уже договорились сходить вечером в кинотеатр."

# game/scripts/episode3.rpy:1023
translate russian continue_after_animation_401afbb7:

    # D "Oh, you can come with us [Eileen]!"
    D "О, ты можешь пойти с нами, [Eileen]!"

# game/scripts/episode3.rpy:1025
translate russian continue_after_animation_e825d52c:

    # Eileen "I'd love to dear, but I have to go later. Got some more baking to get done."
    Eileen "Я бы с радостью, дорогая, но мне нужно идти. Осталось испечь ещё немного выпечки."

# game/scripts/episode3.rpy:1026
translate russian continue_after_animation_ab77e852_1:

    # D "Oh."
    D "Ох."

# game/scripts/episode3.rpy:1027
translate russian continue_after_animation_cb134357:

    # Eileen "Hey don't worry! We'll go out another time."
    Eileen "Эй, не волнуйся! Я присоединюсь в другой раз."

# game/scripts/episode3.rpy:1028
translate russian continue_after_animation_05fa0064:

    # Eileen "Maybe even bake a cake together if you want."
    Eileen "Может, даже испечём вместе торт, если захочешь."

# game/scripts/episode3.rpy:1030
translate russian continue_after_animation_a32fd5b5:

    # D "I would love that!"
    D "Я бы с удовольствием!"

# game/scripts/episode3.rpy:1032
translate russian continue_after_animation_c2dbffc4:

    # X "We better start getting ready before it gets too late."
    X "Нам лучше начать готовиться, пока не стало слишком поздно."

# game/scripts/episode3.rpy:1034
translate russian continue_after_animation_1b55994b:

    # D "I'll go clean up."
    D "Я пойду приберусь."

# game/scripts/episode3.rpy:1036
translate russian continue_after_animation_9f168eee:

    # Eileen "There's a few things I have to show you, so I'm coming with."
    Eileen "Мне нужно показать тебе кое-что, поэтому я пойду."

# game/scripts/episode3.rpy:1037
translate russian continue_after_animation_ced26554:

    # X "I'll hit the shower then."
    X "Тогда я пойду в душ."

# game/scripts/episode3.rpy:1042
translate russian continue_after_animation_76e081db:

    # Eileen "Hey [X]! You still in?"
    Eileen "Эй, [X]! Ты ещё моешься?"

# game/scripts/episode3.rpy:1043
translate russian continue_after_animation_36f85856:

    # X "Yes."
    X "Да."

# game/scripts/episode3.rpy:1044
translate russian continue_after_animation_516597e0:

    # Eileen "Just gotta use the bathroom."
    Eileen "Просто мне нужно в туалет."

# game/scripts/episode3.rpy:1045
translate russian continue_after_animation_a76fdc6c:

    # X "Go ahead."
    X "Заходи."

# game/scripts/episode3.rpy:1046
translate russian continue_after_animation_6d698f69:

    # Eileen "I ran a bath for her and talked about using pads and tampons."
    Eileen "Я набрала ей ванну и рассказала об использовании прокладок и тампонов."

# game/scripts/episode3.rpy:1047
translate russian continue_after_animation_50ac8e30:

    # X "Thanks."
    X "Спасибо."

# game/scripts/episode3.rpy:1048
translate russian continue_after_animation_37a24bb8:

    # X "You already finished?"
    X "Ты уже закончила?"

# game/scripts/episode3.rpy:1049
translate russian continue_after_animation_d887eb02:

    # Eileen "She's a smart girl, catches on fast."
    Eileen "Она умная девочка, быстро схватывает."

# game/scripts/episode3.rpy:1050
translate russian continue_after_animation_7d4803e5:

    # X "Takes after her mother."
    X "Вся в мать."

# game/scripts/episode3.rpy:1051
translate russian continue_after_animation_6070a4d9:

    # Eileen "Yeah."
    Eileen "Ага."

# game/scripts/episode3.rpy:1052
translate russian continue_after_animation_c5de5843:

    # Eileen "So anything new come up?"
    Eileen "Всплыло что-нибудь новое?"

# game/scripts/episode3.rpy:1053
translate russian continue_after_animation_80d39d09:

    # X "There are a few things..."
    X "Есть несколько вещей..."

# game/scripts/episode3.rpy:1057
translate russian continue_after_animation_1dc11827:

    # Eileen "They had her take puberty blockers?!"
    Eileen "Они заставляли её принимать блокаторы половых гормонов?!"

# game/scripts/episode3.rpy:1058
translate russian continue_after_animation_3ccdc38d:

    # X "Seems like it. Still need to do some tests."
    X "Похоже на то. Всё ещё нужно сделать несколько тестов."

# game/scripts/episode3.rpy:1059
translate russian continue_after_animation_8c0a6c21:

    # Eileen "And still no news on [Emily]?"
    Eileen "И по-прежнему никаких новостей об [Emily]?"

# game/scripts/episode3.rpy:1060
translate russian continue_after_animation_e9adbce0:

    # X "Waiting for [Charlie] to get the warrant and investigate [D]'s foster parents."
    X "Жду, пока [Charlie] получит ордер и начнёт расследование в отношении приемных родителей [D]."

# game/scripts/episode3.rpy:1061
translate russian continue_after_animation_fc1b141e:

    # Eileen "It's moving forward at least."
    Eileen "По крайней мере, дело продвигается."

# game/scripts/episode3.rpy:1062
translate russian continue_after_animation_887494a6:

    # X "Yeah."
    X "Ага."

# game/scripts/episode3.rpy:1063
translate russian continue_after_animation_b6b73106:

    # Eileen "I'm done, do you want me to wash your back?"
    Eileen "Я закончила, хочешь, я помою тебе спину?"

# game/scripts/episode3.rpy:1069
translate russian continue_after_animation_91f08f1e:

    # X "Sure, if you want to."
    X "Конечно, если хочешь."

# game/scripts/episode3.rpy:1072
translate russian continue_after_animation_1e478844:

    # X "Wait, why are you naked?"
    X "Подожди, а почему ты голая?"

# game/scripts/episode3.rpy:1073
translate russian continue_after_animation_ef32b422:

    # Eileen "Figured I'd get a free shower and save money."
    Eileen "Решила, что получу бесплатный душ и сэкономлю деньги."

# game/scripts/episode3.rpy:1074
translate russian continue_after_animation_334bdb2e:

    # Eileen "Why, you got a problem with that?"
    Eileen "А что, какие-то проблемы?"

# game/scripts/episode3.rpy:1076
translate russian continue_after_animation_5b03ddc0:

    # X "Not really, but I get the sense that I should."
    X "Не совсем, но мне кажется, что не стоит."

# game/scripts/episode3.rpy:1077
translate russian continue_after_animation_a9c687ae:

    # Eileen "So don't look then!"
    Eileen "Просто не смотри!"

# game/scripts/episode3.rpy:1078
translate russian continue_after_animation_0d76db19:

    # X "Oh right, problem solved."
    X "О, ты права, проблема решена."

# game/scripts/episode3.rpy:1080
translate russian continue_after_animation_01f3466e:

    # X "Hey!"
    X "Эй!"

# game/scripts/episode3.rpy:1081
translate russian continue_after_animation_771fc588:

    # Eileen "What?"
    Eileen "Что?"

# game/scripts/episode3.rpy:1083
translate russian continue_after_animation_9dedf279:

    # Eileen "I washed your back, you wash my back now."
    Eileen "Я вымыла твою спину, теперь ты вымой мою."

# game/scripts/episode3.rpy:1084
translate russian continue_after_animation_bc25fa5b:

    # X "I'm being too laissez-faire about this."
    X "Я слишком легкомысленно отношусь к этому."

# game/scripts/episode3.rpy:1086
translate russian continue_after_animation_3c1c930b:

    # Eileen "So you wanna take charge big strongman?"
    Eileen "Так ты хочешь взять на себя ответственность, большой силач?"

# game/scripts/episode3.rpy:1087
translate russian continue_after_animation_10c52cd8:

    # X "Don't know about that."
    X "Не знаю."

# game/scripts/episode3.rpy:1089
translate russian continue_after_animation_63a06471:

    # Eileen "But I sense some hard initiaitve from you."
    Eileen "Но я чувствую от тебя твёрдую инициативу."

# game/scripts/episode3.rpy:1090
translate russian continue_after_animation_247626d3:

    # X "Oh that's... not right."
    X "О, это... неправильно."

# game/scripts/episode3.rpy:1091
translate russian continue_after_animation_b2cbe444:

    # Eileen "Yeah it's seems you're going for a more centrist position."
    Eileen "Да, похоже, ты придерживаешься более пофигистической позиции."

# game/scripts/episode3.rpy:1093
translate russian continue_after_animation_0e898710:

    # Eileen "You wanna ride the fence for a bit longer?"
    Eileen "Хочешь ещё немного посидеть на заборе?"

# game/scripts/episode3.rpy:1189
translate russian continue_after_animation_6044d30b:

    # X "Wait!"
    X "Стой!"

# game/scripts/episode3.rpy:1195
translate russian continue_after_animation_79a703e1:

    # X "Oohh!"
    X "Оохх!"

# game/scripts/episode3.rpy:1196
translate russian continue_after_animation_855623a9:

    # Eileen "Just relax, I'll take care of it."
    Eileen "Расслабься, я обо всём позабочусь."

# game/scripts/episode3.rpy:1198
translate russian continue_after_animation_6ea30c82:

    # X "I can... do this myself."
    X "Я могу... сделать это сам."

# game/scripts/episode3.rpy:1199
translate russian continue_after_animation_035420c9:

    # Eileen "You've been getting erect on you own?"
    Eileen "У тебя эрекция возникала сама по себе?"

# game/scripts/episode3.rpy:1200
translate russian continue_after_animation_36f85856_1:

    # X "Yes."
    X "Да."

# game/scripts/episode3.rpy:1201
translate russian continue_after_animation_d78cab4b:

    # Eileen "Without wet dreams?"
    Eileen "Без эротических снов?"

# game/scripts/episode3.rpy:1202
translate russian continue_after_animation_94957a9e:

    # X "Well..."
    X "Ну..."

# game/scripts/episode3.rpy:1204
translate russian continue_after_animation_753c879c:

    # "Can't really tell her about those times."
    "Не могу рассказать ей о тех временах."

# game/scripts/episode3.rpy:1205
translate russian continue_after_animation_aa50d3b8:

    # Eileen "Found someone who can do it?"
    Eileen "Нашёл кого-то, кто может это делать?"

# game/scripts/episode3.rpy:1206
translate russian continue_after_animation_75bf4b10:

    # X "No..."
    X "Нет..."

# game/scripts/episode3.rpy:1207
translate russian continue_after_animation_0452ce6b:

    # Eileen "Then you still need my help."
    Eileen "Тогда тебе всё ещё нужна моя помощь."

# game/scripts/episode3.rpy:1209
translate russian continue_after_animation_f53baa80:

    # Eileen "So go ahead and enjoy it."
    Eileen "Так что стой и наслаждайся."

# game/scripts/episode3.rpy:1222
translate russian continue_after_animation_2_2726fc24:

    # X "I'm gonna cum [Eileen]!"
    X "Я сейчас кончу, [Eileen]!"

# game/scripts/episode3.rpy:1223
translate russian continue_after_animation_2_866b46fa:

    # Eileen "Let it out!"
    Eileen "Выплесни всё!"

# game/scripts/episode3.rpy:1225
translate russian continue_after_animation_2_03fdf9cb:

    # X "Fuuck!"
    X "Бляяя!"

# game/scripts/episode3.rpy:1227
translate russian continue_after_animation_2_d18bb5f1:

    # Eileen "That felt... like a lot."
    Eileen "Её было... очень много."

# game/scripts/episode3.rpy:1229
translate russian continue_after_animation_2_6806fd4c:

    # Eileen "I can tell you needed this."
    Eileen "Я могу сказать, что тебе это было нужно."

# game/scripts/episode3.rpy:1231
translate russian continue_after_animation_2_96eba18f:

    # X "That might be true."
    X "Возможно, это правда."

# game/scripts/episode3.rpy:1232
translate russian continue_after_animation_2_22e16407:

    # X "Thanks..."
    X "Спасибо..."

# game/scripts/episode3.rpy:1240
translate russian continue_after_animation_2_1604b723:

    # X "I'm good, thanks."
    X "Я в порядке, спасибо."

# game/scripts/episode3.rpy:1244
translate russian continue_after_animation_2_bbd964a1:

    # D "You really can't come with us tonight?"
    D "Ты правда не можешь пойти с нами сегодня вечером?"

# game/scripts/episode3.rpy:1245
translate russian continue_after_animation_2_2e7bb70c:

    # Eileen "Sorry dear, I really have to go."
    Eileen "Прости, дорогая, мне правда пора идти."

# game/scripts/episode3.rpy:1246
translate russian continue_after_animation_2_94f1bce6:

    # Eileen "We can go out soon, you just be patient ok?"
    Eileen "Скоро куда-нибудь сходим, просто потерпи, хорошо?"

# game/scripts/episode3.rpy:1247
translate russian continue_after_animation_2_c6e11dd4:

    # D "I will!"
    D "Угу!"

# game/scripts/episode3.rpy:1249
translate russian continue_after_animation_2_8046b76f:

    # Eileen "You two have fun out there!"
    Eileen "Повеселитесь там!"

# game/scripts/episode3.rpy:1250
translate russian continue_after_animation_2_59164ff6:

    # D "Bye [Eileen]!"
    D "Пока, [Eileen]!"

# game/scripts/episode3.rpy:1251
translate russian continue_after_animation_2_651a7b67:

    # Eileen "Bye cutie!"
    Eileen "Пока, милашка!"

# game/scripts/episode3.rpy:1254
translate russian continue_after_animation_2_8236fe3d:

    # X "Ready to head out?"
    X "Готова выходить?"

# game/scripts/episode3.rpy:1256
translate russian continue_after_animation_2_33d7bb86:

    # D "I'll go change."
    D "Я пойду переоденусь."

# game/scripts/episode3.rpy:1261
translate russian continue_after_animation_2_41a158ff:

    # X "Here we are."
    X "Мы на месте."

# game/scripts/episode3.rpy:1262
translate russian continue_after_animation_2_a5be9227:

    # D "Wow!"
    D "Вау!"

# game/scripts/episode3.rpy:1264
translate russian continue_after_animation_2_f28fd22d:

    # D "It looks just like in the movies!"
    D "Выглядит совсем как в фильмах!"

# game/scripts/episode3.rpy:1266
translate russian continue_after_animation_2_18ce440c:

    # X "It's an old style place, it has that classic look."
    X "Это старый классический стиль."

# game/scripts/episode3.rpy:1268
translate russian continue_after_animation_2_962efbdf:

    # X "How are these seats?"
    X "Как тебе эти сиденья?"

# game/scripts/episode3.rpy:1270
translate russian continue_after_animation_2_a225b3af:

    # X "We can change them if you want to go closer."
    X "Мы можем пересесть на другие, если хочешь быть поближе к экрану."

# game/scripts/episode3.rpy:1272
translate russian continue_after_animation_2_899b1c9a:

    # D "I don't mind."
    D "Меня всё устраивает."

# game/scripts/episode3.rpy:1274
translate russian continue_after_animation_2_60e6f914:

    # X "Figured you wanted something sci-fi, so I got this one."
    X "Я подумал, что ты хочешь что-нибудь научно-фантастическое."

# game/scripts/episode3.rpy:1276
translate russian continue_after_animation_2_bf9eae15:

    # "She looks engrossed in the action."
    "Она, кажется, поглощена происходящим."

# game/scripts/episode3.rpy:1278
translate russian continue_after_animation_2_321f1d5f:

    # "How can you not take a child to the cinema even once."
    "Как можно ни разу не сводить ребёнка в кино?"

# game/scripts/episode3.rpy:1279
translate russian continue_after_animation_2_9108ad88:

    # "And just keep them in the house."
    "И просто держить её дома."

# game/scripts/episode3.rpy:1281
translate russian continue_after_animation_2_e3074562:

    # "I'll never let them take her away!"
    "Я никогда не позволю им забрать её!"

# game/scripts/episode3.rpy:1283
translate russian continue_after_animation_2_6f825c05:

    # D "dad."
    D "Пап."

# game/scripts/episode3.rpy:1285
translate russian continue_after_animation_2_3808f82c:

    # X "How's the movie?"
    X "Как тебе фильм?"

# game/scripts/episode3.rpy:1287
translate russian continue_after_animation_2_37b2f259:

    # D "It's straight fire!"
    D "Супер!"

# game/scripts/episode3.rpy:1288
translate russian continue_after_animation_2_03d81513:

    # D "Thank you for taking me out!"
    D "Спасибо, что взял меня с собой!"

# game/scripts/episode3.rpy:1290
translate russian continue_after_animation_2_d8e62696:

    # X "It's my pleasure, we can come as many times as you want."
    X "С удовольствием, мы можем ходить сюда столько, сколько захочешь."

# game/scripts/episode3.rpy:1292
translate russian continue_after_animation_2_07ea23c9:

    # D "That was really fun!"
    D "Это было очень весело!"

# game/scripts/episode3.rpy:1293
translate russian continue_after_animation_2_42725aec:

    # D "But I feel a little dizzy now."
    D "Но у меня немного кружится голова."

# game/scripts/episode3.rpy:1294
translate russian continue_after_animation_2_3847e6c9:

    # X "That should pass."
    X "Должна скоро пройти."

# game/scripts/episode3.rpy:1295
translate russian continue_after_animation_2_da5278cd:

    # X "Just wait here I'll get rid of the trash."
    X "Подожди здесь, я выброшу мусор."

# game/scripts/episode3.rpy:1297
translate russian continue_after_animation_2_7c3b4d90:

    # "Looks like I'm getting a hang of this parent--"
    "Похоже, я начинаю понимать, какого быть родите--"

# game/scripts/episode3.rpy:1300
translate russian continue_after_animation_2_4adef392:

    # D "Aaaahhh! Daddy!!"
    D "Ааааххх! Папочка!!"

# game/scripts/episode3.rpy:1302
translate russian continue_after_animation_2_a935fc86:

    # X "[D]!!!"
    X "[D]!!!"

# game/scripts/episode3.rpy:1304
translate russian continue_after_animation_2_6f9d58cc:

    # X "Let her go you bastards!!!"
    X "Отпустите её, ублюдки!!!"

# game/scripts/episode3.rpy:1307
translate russian continue_after_animation_2_2fe60750:

    # X "Damn it!"
    X "Проклятье!"

# game/scripts/episode3.rpy:1308
translate russian continue_after_animation_2_789d3f2b:

    # "What the fuck are these shitbags doing?"
    "Какого хуя эти пидоры делают?"

# game/scripts/episode3.rpy:1312
translate russian continue_after_animation_2_06bd0b8f:

    # "Did they go this way?"
    "Они поехали этой дорогой?"

# game/scripts/episode3.rpy:1317
translate russian continue_after_animation_2_94cd69d6:

    # X "FUCK!!"
    X "СУКА!!"

# game/scripts/episode3.rpy:1318
translate russian continue_after_animation_2_ae5adc07:

    # X "Lost 'em!"
    X "Потерял их!"

# game/scripts/episode3.rpy:1320
translate russian continue_after_animation_2_a5769621:

    # "But I recognize those cocksuckers!"
    "Но я знаю этих хуесосов!"

# game/scripts/episode3.rpy:1321
translate russian continue_after_animation_2_c3e65f95:

    # "[Khalil] has to know where that bastard's staying."
    "[Khalil] должен знать, куда они поехали."

# game/scripts/episode3.rpy:1324
translate russian continue_after_animation_2_5a48feb7:

    # Khalil "Yo [X]! What's up?"
    Khalil "Йоу, [X]! Как дела?"

# game/scripts/episode3.rpy:1325
translate russian continue_after_animation_2_c0b96a15:

    # X "[Khalil], you know where that fuckers's operating now?"
    X "[Khalil], ты знаешь, где сейчас орудуют ублюдки?"

# game/scripts/episode3.rpy:1326
translate russian continue_after_animation_2_2275822b:

    # Khalil "Shit! You in trouble with them?"
    Khalil "Дерьмо! У тебя с ними проблемы?"

# game/scripts/episode3.rpy:1327
translate russian continue_after_animation_2_395a0142:

    # Khalil "Where' you at?"
    Khalil "Где ты?"

# game/scripts/episode3.rpy:1328
translate russian continue_after_animation_2_500d115e:

    # X "I don't have time now, just give me his location."
    X "У меня сейчас нет времени, просто скажи мне, где они."

# game/scripts/episode3.rpy:1329
translate russian continue_after_animation_2_31f461e5:

    # Khalil "He's near the old dock, at a warehouse there."
    Khalil "Они возле старого дока, на складе."

# game/scripts/episode3.rpy:1330
translate russian continue_after_animation_2_02b64f6b:

    # Khalil "What happened?"
    Khalil "Что случилось то?"

# game/scripts/episode3.rpy:1331
translate russian continue_after_animation_2_72b5f660:

    # X "They took my dad!"
    X "Они забрали мою дочь!"

# game/scripts/episode3.rpy:1332
translate russian continue_after_animation_2_ce7e5dbb:

    # Khalil "Your dad?!"
    Khalil "Твою дочь?!"

# game/scripts/episode3.rpy:1333
translate russian continue_after_animation_2_d7bd6d80:

    # X "I gotta take care of this quickly, we'll talk after!"
    X "Я должен побыстрее с этим разобраться, поговорим после!"

# game/scripts/episode3.rpy:1334
translate russian continue_after_animation_2_1ae12f45:

    # Khalil "Alright man, if you need help just say the word!"
    Khalil "Ладно, парень, если тебе нужна помощь, только скажи!"

# game/scripts/episode3.rpy:1338
translate russian continue_after_animation_2_92da22e7:

    # "This looks like the place."
    "Похоже, это то самое место."

# game/scripts/episode3.rpy:1340
translate russian continue_after_animation_2_b0a53a6b:

    # "These idiots didn't even lock the gates."
    "Эти идиоты даже ворота не заперли."

# game/scripts/episode3.rpy:1343
translate russian continue_after_animation_2_fd9a16e2:

    # "Like they own the street."
    "Как будто они хозяева улицы."

# game/scripts/episode3.rpy:1344
translate russian continue_after_animation_2_a98d9e00:

    # "Don't see the van anywhere."
    "Нигде не вижу фургона."

# game/scripts/episode3.rpy:1346
translate russian continue_after_animation_2_0a48513a:

    # "Thug no.1" "You can't let that bitch talk to you like that!"
    "Бандит №1" "Ты не можешь позволить этой сучке так с тобой разговаривать!"

# game/scripts/episode3.rpy:1347
translate russian continue_after_animation_2_2aa99d28:

    # "Thug no.1" "Next time she opens her mouth, take a f--"
    "Бандит №1" "В следующий раз, когда она откроет рот, уда--"

# game/scripts/episode3.rpy:1349
translate russian continue_after_animation_2_0e91f280:

    # X "Is your boss in? I gotta talk to him."
    X "Твой босс здесь? Мне нужно с ним поговорить."

# game/scripts/episode3.rpy:1350
translate russian continue_after_animation_2_2fc29893:

    # "Thug no.1" "'The fuck...'"
    "Бандит №1" "'Вот чёрт...'"

# game/scripts/episode3.rpy:1352
translate russian continue_after_animation_2_e6990407:

    # "Thug no.1" "Get the fuck out before I skull fuck you to death!"
    "Бандит №1" "Убирайся на хрен, пока я не разбил твой череп об землю!"

# game/scripts/episode3.rpy:1357
translate russian continue_after_animation_2_c65dc125:

    # X "You swear too much."
    X "Ты слишком много ругаешься."

# game/scripts/episode3.rpy:1359
translate russian continue_after_animation_2_ad7213d6:

    # "Thug no.2" "You motherfucker!!"
    "Бандит №1" "Ты ублюдок!!"

# game/scripts/episode3.rpy:1363
translate russian continue_after_animation_2_848c6028:

    # X "Careful with that!"
    X "Осторожнее!"

# game/scripts/episode3.rpy:1365
translate russian continue_after_animation_2_51061233:

    # X "Didn't your parents teach you not to play with knives."
    X "Разве твои родители не учили тебя не играть с ножами?"

# game/scripts/episode3.rpy:1366
translate russian continue_after_animation_2_d14b437f:

    # X "I'll be keeping this."
    X "Я оставлю его себе."

# game/scripts/episode3.rpy:1368
translate russian continue_after_animation_2_62f2fd8e:

    # Jerold "...and here you are, all clean!"
    Jerold "...и вот ты здесь, весь чистый!"

# game/scripts/episode3.rpy:1369
translate russian continue_after_animation_2_bd6d1481:

    # "I recognize that voice."
    "Я узнаю этот голос."

# game/scripts/episode3.rpy:1372
translate russian continue_after_animation_2_b72ad97d:

    # Jerold "Feel free to count it."
    Jerold "Не стесняйся всё посчитать."

# game/scripts/episode3.rpy:1373
translate russian continue_after_animation_2_17493949:

    # "???" "Your father assured me, there is no need."
    "???" "Твой отец заверил меня, что в этом нет необходимости."

# game/scripts/episode3.rpy:1374
translate russian continue_after_animation_2_728ac186:

    # Jerold "Now we can also help with picking some real est--"
    Jerold "Теперь мы также можем помочь с выбором недвижимо--"

# game/scripts/episode3.rpy:1375
translate russian continue_after_animation_2_d0e4a5e3:

    # X "Hey [Jerold]!"
    X "Эй, [Jerold]!"

# game/scripts/episode3.rpy:1377
translate russian continue_after_animation_2_d6ea7756:

    # X "Heard you got some girls."
    X "Слышал, у тебя есть девушки."

# game/scripts/episode3.rpy:1378
translate russian continue_after_animation_2_0b63ba68:

    # X "See, I'd like a young blonde with deep blue eyes."
    X "Мне бы хотелось молодую блондинку с глубокими голубыми глазами."

# game/scripts/episode3.rpy:1380
translate russian continue_after_animation_2_dfb3439a:

    # X "You picked up one like that recently?"
    X "Ты недавно обзавёлся такой?"

# game/scripts/episode3.rpy:1381
translate russian continue_after_animation_2_efde5941:

    # "???" "Hey!"
    "???" "Эй!"

# game/scripts/episode3.rpy:1383
translate russian continue_after_animation_2_e7d96504:

    # "???" "Are you high or something?"
    "???" "Ты под кайфом, что ли?"

# game/scripts/episode3.rpy:1384
translate russian continue_after_animation_2_c9b7ad26:

    # "???" "We're in the middle of a meeting here!"
    "???" "У нас тут совещание в самом разгаре!"

# game/scripts/episode3.rpy:1386
translate russian continue_after_animation_2_db7f421a:

    # X "You can finish the meeting in the emergency ward or be quiet!"
    X "Ты можешь отправиться в отделение неотложной помощи или замолчать!"

# game/scripts/episode3.rpy:1387
translate russian continue_after_animation_2_e3bfc7aa:

    # X "Your choice."
    X "Твой выбор."

# game/scripts/episode3.rpy:1388
translate russian continue_after_animation_2_2499868a:

    # Jerold "It's OK [Sergio]."
    Jerold "Всё в порядке, [Sergio]."

# game/scripts/episode3.rpy:1390
translate russian continue_after_animation_2_6622069e:

    # Jerold "Looks like there's a missunderstanding here."
    Jerold "Похоже, произошло недопонимание."

# game/scripts/episode3.rpy:1391
translate russian continue_after_animation_2_cf5dbe3c:

    # Jerold "I don't know what girls you're talking about [X]."
    Jerold "Я не знаю, о каких девушках ты говоришь, [X]."

# game/scripts/episode3.rpy:1393
translate russian continue_after_animation_2_e25e10d2:

    # X "Just one really, your boys took her earlier."
    X "Только про одну, твои ребята забрали её ранее."

# game/scripts/episode3.rpy:1394
translate russian continue_after_animation_2_da758b72:

    # X "You know that was my dad?"
    X "Ты знаешь, что она моя дочь?"

# game/scripts/episode3.rpy:1397
translate russian continue_after_animation_2_4ef5b19c:

    # Jerold "What?! She's your dad?!"
    Jerold "Что?! Она твоя дочь?!"

# game/scripts/episode3.rpy:1398
translate russian continue_after_animation_2_5d8d8d1d:

    # Jerold "I-I had no idea!"
    Jerold "Я-я понятия не имел!"

# game/scripts/episode3.rpy:1399
translate russian continue_after_animation_2_059da465:

    # X "Tell me where she is!"
    X "Скажи мне, где она!"

# game/scripts/episode3.rpy:1400
translate russian continue_after_animation_2_404827a4:

    # X "Or do you need some convincing?"
    X "Или тебя нужно как-то убедить?"

# game/scripts/episode3.rpy:1401
translate russian continue_after_animation_2_53283dc9:

    # Jerold "Easy, we don't need to go there."
    Jerold "Спокойно, нам не нужно туда идти."

# game/scripts/episode3.rpy:1403
translate russian continue_after_animation_2_f6978aa4:

    # Jerold "She's at a motel outside of town."
    Jerold "Она в мотеле за городом."

# game/scripts/episode3.rpy:1404
translate russian continue_after_animation_2_ecfe6d8a:

    # Jerold "My guys are waiting for this guy to come 'rescue' her."
    Jerold "Мои ребята ждут, когда парень придёт \"спасать\" её."

# game/scripts/episode3.rpy:1406
translate russian continue_after_animation_2_ccb21e7d:

    # X "'Rescue' her?"
    X "\"Спасать\" её?"

# game/scripts/episode3.rpy:1408
translate russian continue_after_animation_2_bd5f85a7:

    # Jerold "They're supposed to pretend that they're fighting, and he comes in and takes her away."
    Jerold "Они должны притвориться, что ссорятся, а он приходит и уводит её."

# game/scripts/episode3.rpy:1410
translate russian continue_after_animation_2_a71aaad1:

    # X "And this guy, who is he, what does he look like?"
    X "А этот парень, кто он, как он выглядит?"

# game/scripts/episode3.rpy:1412
translate russian continue_after_animation_2_af40e094:

    # Jerold "No idea, my old man dealt with him."
    Jerold "Понятия не имею, с ним договаривался мой старик."

# game/scripts/episode3.rpy:1413
translate russian continue_after_animation_2_0ce82736:

    # Jerold "That's pretty much all I know."
    Jerold "Это практически всё, что я знаю."

# game/scripts/episode3.rpy:1415
translate russian continue_after_animation_2_6531d3ad:

    # X "Don't lie to me [Jerold]!"
    X "Не лги мне, [Jerold]!"

# game/scripts/episode3.rpy:1417
translate russian continue_after_animation_2_2c37990b:

    # Jerold "I swear, that's everything!"
    Jerold "Клянусь, это всё!"

# game/scripts/episode3.rpy:1418
translate russian continue_after_animation_2_a3f7658c:

    # "This spineless turd is probably in the dark about most of this."
    "Этот бесхребетный придурок, вероятно, ничего не знает обо всём этом."

# game/scripts/episode3.rpy:1420
translate russian continue_after_animation_2_bcd0430f:

    # X "It better be!"
    X "Лучше бы это было так!"

# game/scripts/episode3.rpy:1422
translate russian continue_after_animation_2_d91b2df8:

    # X "Carry on."
    X "Можете продолжать."

# game/scripts/episode3.rpy:1423
translate russian continue_after_animation_2_397fb063:

    # Sergio "Hmpf!"
    Sergio "Хмпф!"

# game/scripts/episode3.rpy:1425
translate russian continue_after_animation_2_02a4f71f:

    # X "You know what will happen if I have to come back."
    X "Ты знаешь, что произойдёт, если мне придется вернуться."

# game/scripts/episode3.rpy:1426
translate russian continue_after_animation_2_80be734a:

    # Jerold "I know!"
    Jerold "Знаю!"

# game/scripts/episode3.rpy:1430
translate russian continue_after_animation_2_68c241e0:

    # "That's the van."
    "Это тот самый фургон."

# game/scripts/episode3.rpy:1434
translate russian continue_after_animation_2_4322f12c:

    # "It's dark, maybe they won't recognize me."
    "Сейчас темно, может быть, они меня не узнают."

# game/scripts/episode3.rpy:1435
translate russian continue_after_animation_2_7d74c547:

    # "Then I can play along with whatever they're doing here."
    "Тогда я смогу подыгрывать им во всём, что они здесь делают."

# game/scripts/episode3.rpy:1437
translate russian continue_after_animation_2_36f5d5f7:

    # "Thug the 1st" "You're early!"
    "1-й бандит" "Ты рано!"

# game/scripts/episode3.rpy:1439
translate russian continue_after_animation_2_657a6596:

    # X "Yeah?"
    X "Да?"

# game/scripts/episode3.rpy:1440
translate russian continue_after_animation_2_3cd6013b:

    # X "You want me to wait, or are we getting this over with?"
    X "Ты хочешь, чтобы я подождал, или мы покончим с этим поскорее?"

# game/scripts/episode3.rpy:1441
translate russian continue_after_animation_2_a5c9a4c3:

    # "Thug the 1st" "Guess not."
    "1-й бандит" "Думаю, нет."

# game/scripts/episode3.rpy:1443
translate russian continue_after_animation_2_96bbd1cc:

    # "Thug the 1st" "Hey wake up, we got shit to do!"
    "1-й бандит" "Эй, просыпайся, нам есть чем заняться!"

# game/scripts/episode3.rpy:1445
translate russian continue_after_animation_2_7c531f8e:

    # X "Is she here?"
    X "Она здесь?"

# game/scripts/episode3.rpy:1447
translate russian continue_after_animation_2_723ff350:

    # "Thug the 1st" "In the bathroom."
    "1-й бандит" "В туалете."

# game/scripts/episode3.rpy:1448
translate russian continue_after_animation_2_f36fd613:

    # "Thug the 2nd" "Man, what a piece!"
    "2-й бандит" "Боже, что за штучка!"

# game/scripts/episode3.rpy:1450
translate russian continue_after_animation_2_addd6e45:

    # "Thug the 2nd" "That's a prime cut right there!"
    "2-й бандит" "Какие великолепные изгибы!"

# game/scripts/episode3.rpy:1452
translate russian continue_after_animation_2_fe01ae4c:

    # "Thug the 2nd" "I'm talking real wagyu shit."
    "2-й бандит" "Настоящее мясо вагю."

# game/scripts/episode3.rpy:1453
translate russian continue_after_animation_2_d8ad2e08:

    # "Thug the 2nd" "With those thighs and that rack, she's fine as hell!"
    "2-й бандит" "С такими бёдрами и фигурой она чертовски хороша!"

# game/scripts/episode3.rpy:1455
translate russian continue_after_animation_2_87e57f7b:

    # X "I'm going to assume you're just talking about some cow you want to fuck."
    X "Я предположу, что ты просто говоришь о какой-то корове, которую хочешь трахнуть."

# game/scripts/episode3.rpy:1456
translate russian continue_after_animation_2_1915d3b5:

    # X "Just so I won't bash your head in for real."
    X "Просто чтобы я не проломил тебе голову."

# game/scripts/episode3.rpy:1458
translate russian continue_after_animation_2_53cf569d:

    # "Thug the 1st" "Ignore him, he's had too much to drink!"
    "1-й бандит" "Не обращай на него внимания, он слишком много выпил!"

# game/scripts/episode3.rpy:1460
translate russian continue_after_animation_2_a6539927:

    # X "Yeah whatever. Let's get this moving!"
    X "Как скажешь. Давайте начнём!"

# game/scripts/episode3.rpy:1462
translate russian continue_after_animation_2_56fcd7ba:

    # "Thug the 1st" "Yeah sure."
    "1-й бандит" "Да, конечно."

# game/scripts/episode3.rpy:1464
translate russian continue_after_animation_2_119d39f8:

    # "Thug the 1st" "Hey who the fuck are you??"
    "1-й бандит" "Эй, кто ты, блядь, такой?"

# game/scripts/episode3.rpy:1465
translate russian continue_after_animation_2_09083cdf:

    # "Thug the 2nd" "He's looking for a fight!"
    "2-й бандит" "Он нарывается на драку!"

# game/scripts/episode3.rpy:1467
translate russian continue_after_animation_2_a0ff6cbd:

    # "Thug the 2nd" "Take this!"
    "2-й бандит" "Получай!"

# game/scripts/episode3.rpy:1468
translate russian continue_after_animation_2_b6d09e58:

    # "Thug the 2nd" "Ow! Fuck, that hurt!"
    "2-й бандит" "Ай! Чёрт, как больно!"

# game/scripts/episode3.rpy:1469
translate russian continue_after_animation_2_63ac841d:

    # "Thug the 1st" "You're dead!"
    "1-й бандит" "Тебе не жить!"

# game/scripts/episode3.rpy:1471
translate russian continue_after_animation_2_0b72b6e2:

    # "Thug the 1st" "Shit! My face!"
    "1-й бандит" "Дерьмо! Моё лицо!"

# game/scripts/episode3.rpy:1472
translate russian continue_after_animation_2_12a39223:

    # "Now's my chance!"
    "Теперь у меня есть шанс!"

# game/scripts/episode3.rpy:1473
translate russian continue_after_animation_2_53fdeebf:

    # "Thug the 1st" "How about th--"
    "1-й бандит" "Как насчёт эт--"

# game/scripts/episode3.rpy:1474
translate russian continue_after_animation_2_ffa79278:

    # X "Aaaaand..."
    X "Ииии..."

# game/scripts/episode3.rpy:1478
translate russian continue_after_animation_2_75ab5c36:

    # "Thug the 2nd" "What the fuck!?"
    "2-й бандит" "Какого хрена?!"

# game/scripts/episode3.rpy:1480
translate russian continue_after_animation_2_cce80fc1:

    # "Thug the 2nd" "You son of a bitch!"
    "2-й бандит" "Ах ты, сукин сын!"

# game/scripts/episode3.rpy:1483
translate russian continue_after_animation_2_2fe2cb39:

    # X "...cut!"
    X "...снято!"

# game/scripts/episode3.rpy:1486
translate russian continue_after_animation_2_e680a7ee:

    # X "[D]?"
    X "[D]?"

# game/scripts/episode3.rpy:1488
translate russian continue_after_animation_2_8cced104:

    # X "Are you there?"
    X "Ты там?"

# game/scripts/episode3.rpy:1491
translate russian continue_after_animation_2_e10b9c0d:

    # X "[D]!"
    X "[D]!"

# game/scripts/episode3.rpy:1493
translate russian continue_after_animation_2_4537aea9:

    # X "Bear with it, this will hurt a little!"
    X "Потерпи, будет немного больно!"

# game/scripts/episode3.rpy:1496
translate russian continue_after_animation_2_7e82fc62:

    # D "Ouch!"
    D "Ай!"

# game/scripts/episode3.rpy:1498
translate russian continue_after_animation_2_68288753:

    # X "Stand still till I get this off!"
    X "Сиди спокойно, пока я не разрежу!"

# game/scripts/episode3.rpy:1500
translate russian continue_after_animation_2_022f0ee5:

    # D "dad! You came!"
    D "Папа! Ты пришёл!"

# game/scripts/episode3.rpy:1501
translate russian continue_after_animation_2_73622e71:

    # D "I was so scared!"
    D "Я была так напугана!"

# game/scripts/episode3.rpy:1503
translate russian continue_after_animation_2_db3939fa:

    # X "Of course I did!"
    X "Конечно!"

# game/scripts/episode3.rpy:1505
translate russian continue_after_animation_2_fe68dee5:

    # X "I'd never let them take you!"
    X "Я никогда не позволю им отнять тебя у меня!"

# game/scripts/episode3.rpy:1506
translate russian continue_after_animation_2_4c462c9a:

    # X "Are you hurt?"
    X "Ты ранена?"

# game/scripts/episode3.rpy:1508
translate russian continue_after_animation_2_73b307e7:

    # D "No, but my legs are numb."
    D "Нет, но у меня затекли ноги."

# game/scripts/episode3.rpy:1510
translate russian continue_after_animation_2_763218ee:

    # X "Hold on to me."
    X "Держись за меня."

# game/scripts/episode3.rpy:1512
translate russian continue_after_animation_2_e105d102:

    # D "Are those men gone?"
    D "Эти люди ушли?"

# game/scripts/episode3.rpy:1513
translate russian continue_after_animation_2_f5015348:

    # X "You don't need to worry about them."
    X "Тебе не нужно беспокоиться о них."

# game/scripts/episode3.rpy:1514
translate russian continue_after_animation_2_2524a698:

    # X "Let's get to the car."
    X "Пойдём к машине."

# game/scripts/episode3.rpy:1516
translate russian continue_after_animation_2_6bddd200:

    # X "Did any of them touch your privates or anything?"
    X "Кто-нибудь из них прикасался к твоим интимным местам?"

# game/scripts/episode3.rpy:1518
translate russian continue_after_animation_2_cdc1913a:

    # D "No, they just shouted a lot."
    D "Нет, они просто много кричали."

# game/scripts/episode3.rpy:1519
translate russian continue_after_animation_2_ff9cce7b:

    # "Guess I won't break their legs then."
    "Думаю, тогда я не буду ломать им ноги."

# game/scripts/episode3.rpy:1520
translate russian continue_after_animation_2_7311b82a:

    # D "Can we go home?"
    D "Мы можем поехать домой?"

# game/scripts/episode3.rpy:1522
translate russian continue_after_animation_2_5bd79876:

    # X "Listen [D], I need to take care of something first."
    X "Послушай, [D], сначала мне нужно кое о чём позаботиться."

# game/scripts/episode3.rpy:1523
translate russian continue_after_animation_2_2f574316:

    # X "I'll need you to wait in the car here and be quiet till I come back."
    X "Мне нужно, чтобы ты посидела в машине и вела себя тихо, пока я не вернусь."

# game/scripts/episode3.rpy:1525
translate russian continue_after_animation_2_d871e7dc:

    # D "I understand."
    D "Я поняла."

# game/scripts/episode3.rpy:1527
translate russian continue_after_animation_2_ffe46b61:

    # X "Good girl!"
    X "Хорошая девочка!"

# game/scripts/episode3.rpy:1528
translate russian continue_after_animation_2_ed7eb800:

    # X "I'll be back, promise!"
    X "Я вернусь, обещаю!"

# game/scripts/episode3.rpy:1532
translate russian continue_after_animation_2_051fd2ad:

    # "Better tell [Charlie] about all this."
    "[Charlie] должна знать обо всё случившемся."

# game/scripts/episode3.rpy:1534
translate russian continue_after_animation_2_2aa675d1:

    # Charlie "[X]?"
    Charlie "[X]?"

# game/scripts/episode3.rpy:1535
translate russian continue_after_animation_2_2ecad973:

    # Charlie "What is it, something happen?"
    Charlie "Что такое, что-то случилось?"

# game/scripts/episode3.rpy:1536
translate russian continue_after_animation_2_49371592:

    # X "They took [D], but I got her back."
    X "Они похитили [D], но я вернул её."

# game/scripts/episode3.rpy:1537
translate russian continue_after_animation_2_2ef5fb53:

    # Charlie "What, who took her?"
    Charlie "Что, кто её похитил?"

# game/scripts/episode3.rpy:1538
translate russian continue_after_animation_2_63e5ef91:

    # X "There's a guy who's after her, you were right about that."
    X "За ней охотился парень, вы были правы."

# game/scripts/episode3.rpy:1539
translate russian continue_after_animation_2_e5e8b8e5:

    # X "I'll give you the location."
    X "Я сообщу вам местоположение."

# game/scripts/episode3.rpy:1540
translate russian continue_after_animation_2_bedb4112:

    # X "If anything goes wrong, I need you to take care of [D]."
    X "Если что-то пойдет не так, мне нужно, чтобы вы позаботились о [D]."

# game/scripts/episode3.rpy:1541
translate russian continue_after_animation_2_d2b57b9a:

    # Charlie "I'm on my way, but you need to give me more info here!"
    Charlie "Я уже в пути, но вы должны дать мне больше информации!"

# game/scripts/episode3.rpy:1542
translate russian continue_after_animation_2_1fa6e783:

    # X "Sure..."
    X "Конечно..."

# game/scripts/episode3.rpy:1546
translate russian continue_after_animation_2_9642fb05:

    # "If he's been following her, chances are he knows me."
    "Если он следил за ней, то, скорее всего, знает меня."

# game/scripts/episode3.rpy:1547
translate russian continue_after_animation_2_3f575468:

    # "And he could get suspicious if I'm dressed like this."
    "И у него могут возникнуть подозрения, если я буду так одет."

# game/scripts/episode3.rpy:1549
translate russian continue_after_animation_2_e27498e5:

    # "Nice, these'll come in handy."
    "Отлично, сгодится."

# game/scripts/episode3.rpy:1553
translate russian continue_after_animation_2_b6c0a155:

    # "That might be the guy."
    "Возможно, это тот самый парень."

# game/scripts/episode3.rpy:1556
translate russian continue_after_animation_2_657a6596_1:

    # X "Yeah?"
    X "Да?"

# game/scripts/episode3.rpy:1557
translate russian continue_after_animation_2_baab866d:

    # "???" "Open up, it's me."
    "???" "Открывай, это я."

# game/scripts/episode3.rpy:1560
translate russian continue_after_animation_2_4fa0f187:

    # "???" "Since you are here, I assume you have her."
    "???" "Раз уж ты здесь, полагаю, она у тебя."

# game/scripts/episode3.rpy:1562
translate russian continue_after_animation_2_07b005e7:

    # X "Yeah yeah, she' right here."
    X "Да-да, она прямо здесь."

# game/scripts/episode3.rpy:1564
translate russian continue_after_animation_2_326f2d3e:

    # "???" "There were supposed to be two of you."
    "???" "Вас должно было быть двое."

# game/scripts/episode3.rpy:1565
translate russian continue_after_animation_2_983dbda3:

    # "???" "Where's the other one?"
    "???" "Где ещё один?"

# game/scripts/episode3.rpy:1567
translate russian continue_after_animation_2_d992ef38:

    # X "Oh he went out, had to take a dump."
    X "О, он вышел отлить."

# game/scripts/episode3.rpy:1569
translate russian continue_after_animation_2_f58b2d81:

    # "???" "The bathroom is out of service or something?"
    "???" "Туалет не работает или что?"

# game/scripts/episode3.rpy:1571
translate russian continue_after_animation_2_b46af19e:

    # X "Well the girl's in there."
    X "Девушка там."

# game/scripts/episode3.rpy:1572
translate russian continue_after_animation_2_92ba222e:

    # X "And you wanted her alive right?"
    X "И ты хотел, чтобы она была жива, верно?"

# game/scripts/episode3.rpy:1574
translate russian continue_after_animation_2_d12a57f1:

    # "???" "Is she hurt in any way?"
    "???" "Она как-то ранена?"

# game/scripts/episode3.rpy:1576
translate russian continue_after_animation_2_9b00dd5e:

    # X "Nah, just mantally maybe."
    X "Нет, может быть, просто морально."

# game/scripts/episode3.rpy:1578
translate russian continue_after_animation_2_90abc142:

    # "???" "That's good, for your sake."
    "???" "Это хорошо, ради твоего же блага."

# game/scripts/episode3.rpy:1579
translate russian continue_after_animation_2_39d40bc8:

    # "???" "Now you know what to do."
    "???" "Ты знаешь, что теперь делать."

# game/scripts/episode3.rpy:1580
translate russian continue_after_animation_2_6d412a9f:

    # "Oh I certainly do."
    "О, конечно, знаю."

# game/scripts/episode3.rpy:1582
translate russian continue_after_animation_2_34e7975d:

    # X "Yo what are you doing here?!"
    X "Эй, что ты здесь делаешь?!"

# game/scripts/episode3.rpy:1583
translate russian continue_after_animation_2_7fc08fc1:

    # X "Take this!"
    X "Получай!"

# game/scripts/episode3.rpy:1584
translate russian continue_after_animation_2_60d64305:

    # X "Owww! My face!"
    X "Аййй! Моё лицо!"

# game/scripts/episode3.rpy:1585
translate russian continue_after_animation_2_51b50ed3:

    # X "Ugh! No please, she's right there!"
    X "Ух! Нет, пожалуйста, она там!"

# game/scripts/episode3.rpy:1586
translate russian continue_after_animation_2_d1698074:

    # X "I give up!"
    X "Я сдаюсь!"

# game/scripts/episode3.rpy:1587
translate russian continue_after_animation_2_9823348a:

    # "???" "Ok that's enough, now just lay down and play dead."
    "???" "Ну всё, хватит, теперь ложись и прикинься мёртвым."

# game/scripts/episode3.rpy:1589
translate russian continue_after_animation_2_3360d3ee:

    # "???" "[Adalinda]?"
    "???" "[Adalinda]?"

# game/scripts/episode3.rpy:1590
translate russian continue_after_animation_2_ecee6057:

    # John "It's [John], your father sent me!"
    John "Это [John], меня прислал твой отец!"

# game/scripts/episode3.rpy:1592
translate russian continue_after_animation_2_316a97da:

    # John "Wait... where is she?"
    John "Постой... где она?"

# game/scripts/episode3.rpy:1593
translate russian continue_after_animation_2_175a4085:

    # X "Oh wait! She's..."
    X "Ой, подожди! Она..."

# game/scripts/episode3.rpy:1597
translate russian continue_after_animation_2_7b1a1be2:

    # X "Right..."
    X "Прямо..."

# game/scripts/episode3.rpy:1601
translate russian continue_after_animation_2_bb7da504:

    # X "Here!"
    X "Здесь!"

# game/scripts/episode3.rpy:1605
translate russian continue_after_animation_2_2ff66a17:

    # "Let's see what I can get out of him before [Charlie] gets here."
    "Посмотрим, что я смогу вытянуть из него до приезда [Charlie]."

# game/scripts/episode3.rpy:1607
translate russian continue_after_animation_2_a313e7aa:

    # X "Wakey wakey!"
    X "Встаньки-встаньки!"

# game/scripts/episode3.rpy:1609
translate russian continue_after_animation_2_c100f958:

    # John "AAAH!!"
    John "АААХ!!"

# game/scripts/episode3.rpy:1611
translate russian continue_after_animation_2_91b71573:

    # John "What in the fuck do you think you're doing?!"
    John "Что, блять, ты себе позволяешь?!"

# game/scripts/episode3.rpy:1613
translate russian continue_after_animation_2_ff8da1be:

    # John "Where's the girl?"
    John "Где девочка?"

# game/scripts/episode3.rpy:1614
translate russian continue_after_animation_2_a8ee9ae8:

    # X "Oh she's fine."
    X "О, с ней всё в порядке."

# game/scripts/episode3.rpy:1616
translate russian continue_after_animation_2_4ff0f955:

    # X "But right now..."
    X "Но сейчас..."

# game/scripts/episode3.rpy:1618
translate russian continue_after_animation_2_f9726758:

    # X "Your main concern should be about yourself."
    X "В первую очередь ты должен беспокоиться о себе."

# game/scripts/episode3.rpy:1622
translate russian continue_after_animation_2_110f2f8b:

    # John "You!!"
    John "Ты!!"

# game/scripts/episode3.rpy:1623
translate russian continue_after_animation_2_2d03ccdf:

    # John "How did you--"
    John "Как ты--"

# game/scripts/episode3.rpy:1626
translate russian continue_after_animation_2_e0f626be:

    # X "Shut it!"
    X "Заткнись!"

# game/scripts/episode3.rpy:1628
translate russian continue_after_animation_2_c0a5ef11:

    # X "I'm asking the questions!"
    X "Вопросы задаю я!"

# game/scripts/episode3.rpy:1629
translate russian continue_after_animation_2_75c30b20:

    # "Now how should I approach this?"
    "С чего бы начать?"

# game/scripts/episode3.rpy:1630
translate russian continue_after_animation_2_bee00a1c:

    # X "First, who do you work for?"
    X "Во-первых, на кого ты работаешь?"

# game/scripts/episode3.rpy:1632
translate russian continue_after_animation_2_d3045aea:

    # John "I think you've figured that out already."
    John "Думаю, ты уже догадался на кого."

# game/scripts/episode3.rpy:1634
translate russian continue_after_animation_2_f2642345:

    # X "You need me to punch you again?"
    X "Тебе нужно, чтобы я снова тебя ударил?"

# game/scripts/episode3.rpy:1636
translate russian continue_after_animation_2_6dfdf4af:

    # John "[Radford], he tasked me to get his dad back."
    John "На [Radford], он поручил мне вернуть его дочь."

# game/scripts/episode3.rpy:1638
translate russian continue_after_animation_2_7668ce26:

    # X "Is anyone else after her?"
    X "Кто-нибудь ещё ищет её?"

# game/scripts/episode3.rpy:1640
translate russian continue_after_animation_2_aee3b980:

    # John "Not that I know of."
    John "Насколько я знаю, нет."

# game/scripts/episode3.rpy:1642
translate russian continue_after_animation_2_7c01d15d:

    # X "How long have you been working for him?"
    X "Как давно ты на него работаешь?"

# game/scripts/episode3.rpy:1644
translate russian continue_after_animation_2_68bd074c:

    # John "A couple of decades maybe."
    John "Может, пару десятков лет."

# game/scripts/episode3.rpy:1646
translate russian continue_after_animation_2_eb707b48:

    # X "And what about this little act you had those idiots play?"
    X "А как насчёт этого маленького спектакля, который ты заставил разыграть этих идиотов?"

# game/scripts/episode3.rpy:1648
translate russian continue_after_animation_2_2e20c1c1:

    # John "Deterrence, better than have her get in actual trouble."
    John "Устрашение лучше, чем если бы у неё были реальные неприятности."

# game/scripts/episode3.rpy:1650
translate russian continue_after_animation_2_172918bd:

    # X "And make her too scared to run away again."
    X "И слишком напугать её, чтобы она снова сбежала."

# game/scripts/episode3.rpy:1652
translate russian continue_after_animation_2_9a8dde80:

    # John "That was the idea."
    John "Такова была моя идея."

# game/scripts/episode3.rpy:1654
translate russian continue_after_animation_2_eda0e74d:

    # X "Nice plan, just one problem."
    X "Отличный план, но есть одна проблема."

# game/scripts/episode3.rpy:1655
translate russian continue_after_animation_2_2b270f76:

    # X "She's actually my dad."
    X "На самом деле она моя дочь."

# game/scripts/episode3.rpy:1658
translate russian continue_after_animation_2_3e9aaa28:

    # John "What are you talking about?"
    John "О чём ты говоришь?"

# game/scripts/episode3.rpy:1659
translate russian continue_after_animation_2_dd8e738a:

    # "Seems like he doesn't know about [Emily]'s journal."
    "Похоже, он не знает о дневнике [Emily]."

# game/scripts/episode3.rpy:1661
translate russian continue_after_animation_2_ec307201:

    # X "Her mother, the girl they adopted. You know about her?"
    X "Её мать, девушка, которую они удочерили. Ты знаешь о ней?"

# game/scripts/episode3.rpy:1663
translate russian continue_after_animation_2_d96d6f9e:

    # John "What was her name... [Emily]."
    John "Как там её звали... [Emily]."

# game/scripts/episode3.rpy:1665
translate russian continue_after_animation_2_cfb0f3fa:

    # X "That's right. Where is she now?"
    X "Именно так. Где она сейчас?"

# game/scripts/episode3.rpy:1668
translate russian continue_after_animation_2_0e1aa622:

    # John "She... died."
    John "Она... умерла."

# game/scripts/episode3.rpy:1671
translate russian continue_after_animation_2_a3a7ef9d:

    # X "What?! When?"
    X "Что?! Когда?"

# game/scripts/episode3.rpy:1673
translate russian continue_after_animation_2_339b74d0:

    # John "It's been over ten years."
    John "Прошло уже более десяти лет."

# game/scripts/episode3.rpy:1674
translate russian continue_after_animation_2_15192e4e:

    # John "She had an accident, fell down the stairs."
    John "С ней произошёл несчастный случай, она упала с лестницы."

# game/scripts/episode3.rpy:1676
translate russian continue_after_animation_2_3240dd8f:

    # X "I don't believe you!"
    X "Я тебе не верю!"

# game/scripts/episode3.rpy:1678
translate russian continue_after_animation_2_e796c00b:

    # John "I only know what [Radford] told me."
    John "Я знаю только то, что [Radford] сказал мне."

# game/scripts/episode3.rpy:1680
translate russian continue_after_animation_2_e62abf8a:

    # John "Said she tried to run away with her dad."
    John "Сказал, что пыталась сбежать вместе с дочерью."

# game/scripts/episode3.rpy:1681
translate russian continue_after_animation_2_910dc5c8:

    # John "They struggled and she fell, and when the ambulance came it was too late."
    John "Они боролись и она упала, а когда приехала скорая, было уже слишком поздно."

# game/scripts/episode3.rpy:1683
translate russian continue_after_animation_2_42a2a19a:

    # X "Is that so?"
    X "Разве?"

# game/scripts/episode3.rpy:1684
translate russian continue_after_animation_2_750322a0:

    # X "He wouldn't trust you to come get her back if you weren't neck deep in this."
    X "Он бы не доверил тебе вернуть её, если бы ты не был по уши в этом деле."

# game/scripts/episode3.rpy:1686
translate russian continue_after_animation_2_0e92df92:

    # John "Look, this is just business."
    John "Слушай, это просто бизнес."

# game/scripts/episode3.rpy:1687
translate russian continue_after_animation_2_a1a6b654:

    # John "We started working when he called me to private his family's history."
    John "Мы начали работать, когда он позвонил мне, чтобы рассказать историю своей семьи."

# game/scripts/episode3.rpy:1688
translate russian continue_after_animation_2_3c7bacfa:

    # X "Why?"
    X "Зачем?"

# game/scripts/episode3.rpy:1690
translate russian continue_after_animation_2_460c7c15:

    # John "Afer they found out [Emily] was pregnant, they wanted to avoid a scandal."
    John "После того, как они узнали, что [Emily] беременна, они хотели избежать скандала."

# game/scripts/episode3.rpy:1691
translate russian continue_after_animation_2_7cf2b43e:

    # John "[Radford] told me it was his child, so I don't know why you think she's your dad."
    John "[Radford] сказал мне, что это его ребенок, так что я не понимаю, почему ты думаешь, что она твоя дочь."

# game/scripts/episode3.rpy:1692
translate russian continue_after_animation_2_c5681071:

    # "Now I really need to get that journal."
    "Теперь мне действительно нужно достать этот дневник."

# game/scripts/episode3.rpy:1694
translate russian continue_after_animation_2_b30cf5f5:

    # X "I just do."
    X "Просто так."

# game/scripts/episode3.rpy:1695
translate russian continue_after_animation_2_29b58ae5:

    # X "And why did she try to run away?"
    X "И почему она попыталась сбежать?"

# game/scripts/episode3.rpy:1697
translate russian continue_after_animation_2_6ade8e2b:

    # John "He claimed she had mental issues."
    John "Он утверждал, что у неё проблемы с психикой."

# game/scripts/episode3.rpy:1698
translate russian continue_after_animation_2_61854727:

    # X "That's bullshit!"
    X "Полная чушь!"

# game/scripts/episode3.rpy:1699
translate russian continue_after_animation_2_eec0257b:

    # X "And you just fucking believe that?"
    X "И ты, блять, просто веришь в это?"

# game/scripts/episode3.rpy:1701
translate russian continue_after_animation_2_537a3c9a:

    # John "I was paid for my discretion, so I didn't press the issue."
    John "Мне заплатили за моё благоразумие, поэтому я не стал настаивать на этом вопросе."

# game/scripts/episode3.rpy:1703
translate russian continue_after_animation_2_4eec1ae2:

    # X "I get the sense you're no telling me something."
    X "У меня такое чувство, что ты чего-то недоговариваешь."

# game/scripts/episode3.rpy:1705
translate russian continue_after_animation_2_19a27200:

    # John "Hey look, everything's on the record!"
    John "Эй, смотри, всё записано!"

# game/scripts/episode3.rpy:1706
translate russian continue_after_animation_2_20cef9cf:

    # John "Just look it up after that detective declassifies it."
    John "Просто посмотри после того, как детектив это рассекретит."

# game/scripts/episode3.rpy:1708
translate russian continue_after_animation_2_5ae23476:

    # X "How do you know about that?"
    X "Откуда ты об этом знаешь?"

# game/scripts/episode3.rpy:1710
translate russian continue_after_animation_2_5ad614f9:

    # John "That I can't answer."
    John "Не могу сказать."

# game/scripts/episode3.rpy:1711
translate russian continue_after_animation_2_ba3f2e54:

    # X "You sure about that?"
    X "Ты уверен в этом?"

# game/scripts/episode3.rpy:1712
translate russian continue_after_animation_2_ef607fa0:

    # John "Beat me all you want, but it won't do anything."
    John "Бей меня, сколько хочешь, но это ничего не даст."

# game/scripts/episode3.rpy:1714
translate russian continue_after_animation_2_20a330f7:

    # "Maybe he has someone on the inside, or some hacker maybe."
    "Может быть, у него есть кто-то внутри или, может быть, какой-нибудь хакер."

# game/scripts/episode3.rpy:1715
translate russian continue_after_animation_2_6262975d:

    # X "Lucky you, I don't have time for that."
    X "Тебе повезло, что у меня нет на это времени."

# game/scripts/episode3.rpy:1720
translate russian continue_after_animation_2_c80f5405:

    # Charlie "I'm near the place. Where are you?"
    Charlie "Я рядом с этим местом. Где вы?"

# game/scripts/episode3.rpy:1721
translate russian continue_after_animation_2_8374e10f:

    # X "In the motel, meet you out front."
    X "В мотеле, встретимся у входа."

# game/scripts/episode3.rpy:1725
translate russian continue_after_animation_2_59fd3f92:

    # X "I see you."
    X "Я вас вижу."

# game/scripts/episode3.rpy:1727
translate russian continue_after_animation_2_d9131e7b:

    # Charlie "What are you wearing?"
    Charlie "Что это на вас?"

# game/scripts/episode3.rpy:1728
translate russian continue_after_animation_2_e4bf8673:

    # X "I needed a disguise."
    X "Мне нужна была маскировка."

# game/scripts/episode3.rpy:1730
translate russian continue_after_animation_2_4ee1bd64:

    # Charlie "Take me through what happened?"
    Charlie "Расскажите мне, что произошло."

# game/scripts/episode3.rpy:1732
translate russian continue_after_animation_2_36ff0116:

    # X "We just got out of the cinema after a movie."
    X "Мы вышли из кинотеатра после просмотра фильма."

# game/scripts/episode3.rpy:1733
translate russian continue_after_animation_2_506cdd96:

    # X "I turned my back and they just snatched her..."
    X "Я отвернулся и они просто схватили её..."

# game/scripts/episode3.rpy:1737
translate russian continue_after_animation_2_505c5335:

    # Charlie "How did you know where to find [Jerold]?"
    Charlie "Откуда вы знали, где найти [Jerold]?"

# game/scripts/episode3.rpy:1739
translate russian continue_after_animation_2_ba802829:

    # X "Heard rumors on the street last week."
    X "На прошлой неделе до меня дошли слухи."

# game/scripts/episode3.rpy:1740
translate russian continue_after_animation_2_8b3091a0:

    # "Don't need to involve [Khalil] in this one."
    "Не нужно втягивать [Khalil] в это."

# game/scripts/episode3.rpy:1742
translate russian continue_after_animation_2_2a6abde1:

    # Charlie "Well I'll need to take them in."
    Charlie "Ну, мне придётся их забрать."

# game/scripts/episode3.rpy:1744
translate russian continue_after_animation_2_a0901d6f:

    # Charlie "And there could be others coming for [D]."
    Charlie "И за [D] могут прийти другие."

# game/scripts/episode3.rpy:1745
translate russian continue_after_animation_2_887494a6:

    # X "Yeah."
    X "Да."

# game/scripts/episode3.rpy:1747
translate russian continue_after_animation_2_e5a706fe:

    # Charlie "And since he knows about you, it's not safe to go back home."
    Charlie "А раз он знает о вас, возвращаться домой небезопасно."

# game/scripts/episode3.rpy:1748
translate russian continue_after_animation_2_3939264c:

    # Charlie "You can come to my place."
    Charlie "Вы можете пойти ко мне."

# game/scripts/episode3.rpy:1750
translate russian continue_after_animation_2_3d91ef79:

    # X "He also knew about you, so they might also try there."
    X "Он также знал о вас, так что они могут попробовать и там."

# game/scripts/episode3.rpy:1751
translate russian continue_after_animation_2_4485b956:

    # X "I'll find a hotel, it's the best option."
    X "Я найду отель, это лучший вариант."

# game/scripts/episode3.rpy:1753
translate russian continue_after_animation_2_04cc205a:

    # Charlie "That's good, go get a room and we'll meet there."
    Charlie "Хорошо, снимите комнату и мы встретимся там."

# game/scripts/episode3.rpy:1758
translate russian continue_after_animation_2_3a98d18c:

    # X "...so we'll be staying here for a bit."
    X "...так что мы остановимся здесь на некоторое время."

# game/scripts/episode3.rpy:1759
translate russian continue_after_animation_2_be3a059b:

    # X "Go rest for now."
    X "Иди пока отдохни."

# game/scripts/episode3.rpy:1760
translate russian continue_after_animation_2_f9243d7d:

    # "It only has one bed?"
    "Только одна кровать?"

# game/scripts/episode3.rpy:1761
translate russian continue_after_animation_2_b8267645:

    # "And what's with the bathroom here?"
    "И что это за ванная комната такая?"

# game/scripts/episode3.rpy:1763
translate russian continue_after_animation_2_298226ee:

    # "Reception" "This is the front desk. How may I help you?"
    "Ресепшен" "Стойка регистрации. Чем я могу вам помочь?"

# game/scripts/episode3.rpy:1764
translate russian continue_after_animation_2_6b9abff0:

    # X "Do you have any other rooms, maybe with two beds?"
    X "У вас есть другие комнаты, может быть, с двумя кроватями?"

# game/scripts/episode3.rpy:1765
translate russian continue_after_animation_2_112250fe:

    # "Reception" "We're sorry sir, but all rooms are fully booked for tonight."
    "Ресепшен" "Нам очень жаль, сэр, но все номера на сегодня полностью заняты."

# game/scripts/episode3.rpy:1766
translate russian continue_after_animation_2_d854006c:

    # "Damn, already told [Charlie] about the place."
    "Чёрт, я уже сказал [Charlie] об этом месте."

# game/scripts/episode3.rpy:1767
translate russian continue_after_animation_2_f121cfac:

    # "Just have to get by for tonight."
    "Нужно просто пережить сегодняшний вечер."

# game/scripts/episode3.rpy:1768
translate russian continue_after_animation_2_2cb6c30d:

    # X "Right, I see, we'll be fine here then."
    X "Понятно, ничего страшного."

# game/scripts/episode3.rpy:1769
translate russian continue_after_animation_2_72c74c5c:

    # "Reception" "I apologize again sir. Would you like anything else?"
    "Ресепшен" "Я ещё раз прошу прощения, сэр. Хотите что-нибудь ещё?"

# game/scripts/episode3.rpy:1770
translate russian continue_after_animation_2_454bd57e:

    # X "That's OK."
    X "Всё в порядке."

# game/scripts/episode3.rpy:1771
translate russian continue_after_animation_2_e7b8540c:

    # D "**Sniff**"
    D "**Сопит**"

# game/scripts/episode3.rpy:1774
translate russian continue_after_animation_2_14710424:

    # X "[D], what's the matter?"
    X "[D], в чём дело?"

# game/scripts/episode3.rpy:1775
translate russian continue_after_animation_2_5b2ebd17:

    # X "Are you in pain?"
    X "Что-то болит?"

# game/scripts/episode3.rpy:1776
translate russian continue_after_animation_2_7d6dcdca:

    # D "No..."
    D "Нет..."

# game/scripts/episode3.rpy:1778
translate russian continue_after_animation_2_e3bc979b:

    # D "This all happened because of me."
    D "Всё это произошло из-за меня."

# game/scripts/episode3.rpy:1780
translate russian continue_after_animation_2_d3dbb61e:

    # D "If I hadn't ran away..."
    D "Если бы я не сбежала..."

# game/scripts/episode3.rpy:1782
translate russian continue_after_animation_2_e6f35156:

    # X "Don't say that!"
    X "Не говори так!"

# game/scripts/episode3.rpy:1783
translate russian continue_after_animation_2_475c92c8:

    # X "You can't blame yourself for what they did!"
    X "Ты не можешь винить себя за то, что они сделали!"

# game/scripts/episode3.rpy:1785
translate russian continue_after_animation_2_de65ce56:

    # D "But you had to fight those mean people."
    D "Но тебе пришлось драться с этими подлыми людьми."

# game/scripts/episode3.rpy:1786
translate russian continue_after_animation_2_8fd85053:

    # D "You could've been hurt badly, all because of me."
    D "Ты мог сильно пострадать, и всё из-за меня."

# game/scripts/episode3.rpy:1788
translate russian continue_after_animation_2_82b3225c:

    # X "Look [D]..."
    X "Послушай, [D]..."

# game/scripts/episode3.rpy:1790
translate russian continue_after_animation_2_6033756d:

    # X "It's true that I might get a few bruises."
    X "Да, я мог заработать несколько синяков."

# game/scripts/episode3.rpy:1791
translate russian continue_after_animation_2_a7fa9d76:

    # X "But that's never going to stop me from protecting you."
    X "Но это никогда не помешает мне защищать тебя."

# game/scripts/episode3.rpy:1793
translate russian continue_after_animation_2_41731df7:

    # X "No matter what happens, I won't give up on you!"
    X "Что бы ни случилось, я не откажусь от тебя!"

# game/scripts/episode3.rpy:1795
translate russian continue_after_animation_2_8ad10eac:

    # D "I just don't want to see you hurt daddy!"
    D "Я просто не хочу, чтобы тебе было больно, папочка!"

# game/scripts/episode3.rpy:1796
translate russian continue_after_animation_2_f6a20328:

    # X "Hey don't worry about that."
    X "Эй, не волнуйся об этом."

# game/scripts/episode3.rpy:1798
translate russian continue_after_animation_2_39e937e8:

    # X "I'm tougher than I look, trust me!"
    X "Я крепче, чем кажусь, поверь мне!"

# game/scripts/episode3.rpy:1799
translate russian continue_after_animation_2_23ba7b9b:

    # X "Now go get ready for bed, it's really late."
    X "А теперь иди, готовься ко сну, уже действительно поздно."

# game/scripts/episode3.rpy:1801
translate russian continue_after_animation_2_1ddb325e:

    # D "Yes daddy."
    D "Да, папочка."

# game/scripts/episode3.rpy:1802
translate russian continue_after_animation_2_ed602bd3:

    # D "And I hope we find mom so we can all be together."
    D "И я надеюсь, что мы найдем маму и сможем жить все вместе."

# game/scripts/episode3.rpy:1803
translate russian continue_after_animation_2_29e8b645:

    # X "Yeah, me too..."
    X "Да, я тоже..."

# game/scripts/episode3.rpy:1806
translate russian continue_after_animation_2_f80695bb:

    # Charlie "I got you some supplies and a few clothes for [D]."
    Charlie "Я принесла вам кое-какие припасы и одежду для [D]."

# game/scripts/episode3.rpy:1807
translate russian continue_after_animation_2_50ac8e30:

    # X "Thanks."
    X "Спасибо."

# game/scripts/episode3.rpy:1809
translate russian continue_after_animation_2_ac680254:

    # X "What will happened to that [John] guy?"
    X "Что будет с тем парнем, [John]?"

# game/scripts/episode3.rpy:1811
translate russian continue_after_animation_2_0f730574:

    # Charlie "I can detain him in relation to [Emily]'s case."
    Charlie "Я могу задержать его в связи с делом [Emily]."

# game/scripts/episode3.rpy:1813
translate russian continue_after_animation_2_2a9ac959:

    # Charlie "But we need to hold off on bringing you as [D]'s father."
    Charlie "Но нам нужно повременить с тем, чтобы считать вас отцом [D]."

# game/scripts/episode3.rpy:1815
translate russian continue_after_animation_2_d3e70bba:

    # Charlie "At least until we have some evidence for the court."
    Charlie "По крайней мере, пока у нас не будет доказательств для суда."

# game/scripts/episode3.rpy:1817
translate russian continue_after_animation_2_173d7a8c:

    # X "The paternity will get done soon."
    X "Отцовство скоро будет установлено."

# game/scripts/episode3.rpy:1819
translate russian continue_after_animation_2_3b97f7cb:

    # Charlie "That, and whatever else we can bring."
    Charlie "Это и всё остальное, что мы сможем доказать."

# game/scripts/episode3.rpy:1821
translate russian continue_after_animation_2_f0a443da:

    # X "I'll see what I can do."
    X "Я посмотрю, что можно сделать."

# game/scripts/episode3.rpy:1823
translate russian continue_after_animation_2_686147a2:

    # Charlie "Don't leave the hotel, hang tight for now."
    Charlie "Не выходите из отеля, держитесь здесь."

# game/scripts/episode3.rpy:1824
translate russian continue_after_animation_2_4d63f0d3:

    # X "Sure."
    X "Конечно."

# game/scripts/episode3.rpy:1826
translate russian continue_after_animation_2_59486bb1:

    # Charlie "Also, that was a traumatic experience for [D]."
    Charlie "Кроме того, это был травмирующий опыт для [D]."

# game/scripts/episode3.rpy:1827
translate russian continue_after_animation_2_ba570c30:

    # Charlie "She needs all of your support now."
    Charlie "Сейчас ей нужна вся ваша поддержка."

# game/scripts/episode3.rpy:1829
translate russian continue_after_animation_2_dc751bfd:

    # X "I know."
    X "Я знаю."

# game/scripts/episode3.rpy:1831
translate russian continue_after_animation_2_3364cc42:

    # Charlie "And if you need anything, leave a message at the front desk, I'll come and check."
    Charlie "А если вам что-то понадобится, оставьте сообщение на стойке регистрации, я приду и прочитаю."

# game/scripts/episode3.rpy:1832
translate russian continue_after_animation_2_099b3efb:

    # X "Got it."
    X "Понял."

# game/scripts/episode3.rpy:1833
translate russian continue_after_animation_2_da9d8f4f:

    # X "And thank you!"
    X "И благодарю вас!"

# game/scripts/episode3.rpy:1836
translate russian continue_after_animation_2_92338fab:

    # D "Ummm, dad?"
    D "Эммм, папа?"

# game/scripts/episode3.rpy:1838
translate russian continue_after_animation_2_3dd6d314:

    # X "Yes [D]!"
    X "Да, [D]!"

# game/scripts/episode3.rpy:1839
translate russian continue_after_animation_2_fca2b294:

    # D "I don't have any soap here, can you bring some?"
    D "У меня здесь нет мыла, можешь принести?"

# game/scripts/episode3.rpy:1841
translate russian continue_after_animation_2_8811a474:

    # X "Got some shampoo here too."
    X "Здесь есть и шампунь."

# game/scripts/episode3.rpy:1842
translate russian continue_after_animation_2_d2b48823:

    # D "Thanks."
    D "Спасибо."

# game/scripts/episode3.rpy:1845
translate russian continue_after_animation_2_064fec63:

    # X "[Charlie] brought you some clothes, I'll leave them here."
    X "[Charlie] принесла тебе кое-какую одежду, я оставлю её здесь."

# game/scripts/episode3.rpy:1846
translate russian continue_after_animation_2_beec3fc5:

    # D "Okay."
    D "Хорошо."

# game/scripts/episode3.rpy:1849
translate russian continue_after_animation_2_ab8aeefe:

    # "Those bastards aren't giving up easily."
    "Эти ублюдки так просто не сдадутся."

# game/scripts/episode3.rpy:1850
translate russian continue_after_animation_2_fdc67ecb:

    # "It looks like I'm in for a fight."
    "Похоже, мне предстоит драка."

# game/scripts/episode3.rpy:1851
translate russian continue_after_animation_2_ec29b3f0:

    # D "Are they here?"
    D "Они здесь?"

# game/scripts/episode3.rpy:1853
translate russian continue_after_animation_2_e0bf2cd8:

    # X "What?"
    X "Что?"

# game/scripts/episode3.rpy:1854
translate russian continue_after_animation_2_5f550c6b:

    # D "Nevermind, found them!"
    D "Ничего, нашла их!"

# game/scripts/episode3.rpy:1856
translate russian continue_after_animation_2_4c5fb734:

    # "Man, what did they design this room for?"
    "Господи, для чего они проектировали эту комнату?"

# game/scripts/episode3.rpy:1857
translate russian continue_after_animation_2_9891ee33:

    # D "I'm ready."
    D "Я всё."

# game/scripts/episode3.rpy:1859
translate russian continue_after_animation_2_19ec8b31:

    # X "How's the temperature?"
    X "Как температура?"

# game/scripts/episode3.rpy:1861
translate russian continue_after_animation_2_68f528cc:

    # D "I feel warm."
    D "Мне тепло."

# game/scripts/episode3.rpy:1863
translate russian continue_after_animation_2_34ffe490:

    # X "Well we got some blankets here, throw one on if it gets chilly."
    X "У нас тут есть несколько одеял. Накинь одно, если станет прохладно."

# game/scripts/episode3.rpy:1864
translate russian continue_after_animation_2_4897db84:

    # X "Now try to get some rest."
    X "А теперь постарайся немного отдохнуть."

# game/scripts/episode3.rpy:1866
translate russian continue_after_animation_2_0fa5c482:

    # D "Will you sleep here with me?"
    D "Ты будешь спать со мной?"

# game/scripts/episode3.rpy:1868
translate russian continue_after_animation_2_813f87c2:

    # X "There is just this bed."
    X "Здесь есть только одна кровать."

# game/scripts/episode3.rpy:1869
translate russian continue_after_animation_2_38563062:

    # X "But I can always make the floor work too."
    X "Но я могу лечь на пол."

# game/scripts/episode3.rpy:1871
translate russian continue_after_animation_2_822209e5:

    # D "No, please don't go!"
    D "Нет, пожалуйста, не уходи!"

# game/scripts/episode3.rpy:1873
translate russian continue_after_animation_2_b285f0e3:

    # X "Oh well, if you insist."
    X "Что ж, если ты настаиваешь."

# game/scripts/episode3.rpy:1878
translate russian continue_after_animation_2_b064c4d5:

    # X "Goodnight [D]."
    X "Спокойной ночи, [D]."

# game/scripts/episode3.rpy:1879
translate russian continue_after_animation_2_5bfca034:

    # D "Goodnight daddy."
    D "Спокойной ночи, папочка."

# game/scripts/episode3.rpy:1883
translate russian continue_after_animation_2_b064c4d5_1:

    # X "Goodnight [D]."
    X "Спокойной ночи, [D]."

# game/scripts/episode3.rpy:1884
translate russian continue_after_animation_2_5bfca034_1:

    # D "Goodnight daddy."
    D "Спокойной ночи, папочка."

# game/scripts/episode3.rpy:1888
translate russian continue_after_animation_2_b1fb60d3:

    # D "Mmmm..."
    D "Мммм..."

# game/scripts/episode3.rpy:1890
translate russian continue_after_animation_2_3f529e8e:

    # X "[D], are you--"
    X "[D], ты--"

# game/scripts/episode3.rpy:1891
translate russian continue_after_animation_2_1b323a3d:

    # X "Wait, what's this sensation?"
    X "Стоп, что это за чувство?"

# game/scripts/episode3.rpy:2032
translate russian ep3_hotel_grind_intro_71904ab9:

    # X "Huh?!"
    X "А?!"

# game/scripts/episode3.rpy:2033
translate russian ep3_hotel_grind_intro_af95c5c7:

    # "Shit, am I dreaming?"
    "Чёрт, я сплю?"

# game/scripts/episode3.rpy:2034
translate russian ep3_hotel_grind_intro_406344f1:

    # "Even if it's a dream, I should stop this."
    "Даже если это сон, я должен остановить его."

# game/scripts/episode3.rpy:2035
translate russian ep3_hotel_grind_intro_af5ee6df:

    # "What to do..."
    "Что делать..."

# game/scripts/episode3.rpy:2039
translate russian ep3_hotel_grind_intro_c5144754:

    # "I won't risk waking her up and seeing this."
    "Я не хочу рисковать, чтобы она проснулась и увидела это."

# game/scripts/episode3.rpy:2040
translate russian ep3_hotel_grind_intro_d21fb6c5:

    # "I'll try to slowly get--"
    "Я постараюсь потихоньку выбраться--"

# game/scripts/episode3.rpy:2046
translate russian ep3_hotel_grind_intro_172f3cca:

    # X "Oh!"
    X "Ох!"

# game/scripts/episode3.rpy:2047
translate russian ep3_hotel_grind_intro_6c8b64f4:

    # "This isn't good!"
    "Это плохо!"

# game/scripts/episode3.rpy:2048
translate russian ep3_hotel_grind_intro_85455aac:

    # "Gotta do something about this."
    "Надо что-то с этим сделать."

# game/scripts/episode3.rpy:2067
translate russian continue_after_animation_3_9ed25bba:

    # "Shit, I can't stop it!"
    "Дерьмо, я не могу это остановить!"

# game/scripts/episode3.rpy:2068
translate russian continue_after_animation_3_b2a622aa:

    # "I have to--"
    "Я должен--"

# game/scripts/episode3.rpy:2071
translate russian continue_after_animation_3_47e7e2ab:

    # X "Ugghh!"
    X "Угхх!"

# game/scripts/episode3.rpy:2074
translate russian continue_after_animation_3_9893a8fe:

    # "What have I done..."
    "Что я наделал..."

# game/scripts/episode3.rpy:2079
translate russian ep3_turn_around_cc51b99c:

    # "That was close."
    "Это было близко."

# game/scripts/episode3.rpy:2080
translate russian ep3_turn_around_edb67377:

    # "I could've made a mistake there..."
    "Сейчас я мог допустить ошибку..."

translate russian strings:

    # game/scripts/episode3.rpy:111
    old "Hide (H)"
    new "Скрыть (H)"

    # game/scripts/episode3.rpy:735
    old "Chick flick"
    new "Плаксивая мелодрама"

    # game/scripts/episode3.rpy:735
    old "Comedy"
    new "Комедия"

    # game/scripts/episode3.rpy:735
    old "Sci-Fi Horror"
    new "Научно-фантастический хоррор"

    # game/scripts/episode3.rpy:735
    old "Action"
    new "Экшен"

    # game/scripts/episode3.rpy:878
    old "Relieve yourself"
    new "Облегчиться"

    # game/scripts/episode3.rpy:878
    old "Just wash the clothes"
    new "Просто постирать одежду"

    # game/scripts/episode3.rpy:905
    old "Go back to work"
    new "Вернуться к работе"

    # game/scripts/episode3.rpy:905
    old "Tell them off"
    new "Отчитать их"

    # game/scripts/episode3.rpy:954
    old "Celebrate BirthYear"
    new "Отпраздновать год рождения"

    # game/scripts/episode3.rpy:954
    old "Celebrate NameDay"
    new "Отпраздновать именины"

    # game/scripts/episode3.rpy:1064
    old "Let her help"
    new "Позволить ей помочь"

    # game/scripts/episode3.rpy:1064
    old "No need"
    new "Не нужно"

    # game/scripts/episode3.rpy:1874
    old "Kiss her cheek"
    new "Поцеловать её в щёку"

    # game/scripts/episode3.rpy:1874
    old "Kiss her forehead"
    new "Поцеловать её в лоб"

    # game/scripts/episode3.rpy:2036
    old "Stay still"
    new "Не шевелиться"

    # game/scripts/episode3.rpy:2036
    old "Quicky turn around"
    new "Быстро обернуться"

    # game/scripts/episode3.rpy:2087
    old "To be continued..."
    new "Продолжение следует..."

