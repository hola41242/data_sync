
translate russian strings:

    old "Episode 3"
    new "Эпизод 3"

    old "Back In The Game"
    new "Снова в игре"

    old "Gentle"
    new "Нежно"

    old "Rythmic"
    new "Ритмично"

    old "Pounding"
    new "Толчки"

    old "Deep Thrusts"
    new "Глубокие толчки"

    old "POV"
    new "От 1-го лица"

    old "ACTION"
    new "БЛИЗКО"

    old "SIDE"
    new "СБОКУ"

    old "Prone"
    new "Лёжа"

    old "Ride"
    new "Наездница"

    old "END"
    new "ЗАКОНЧИТЬ"

    old "Slow"
    new "Медленно"

    old "Riding"
    new "Скачуще"

    old "Deep"
    new "Глубоко"

    old "BUTT"
    new "ПОПА"

    old "Fast"
    new "Быстро"

    old "Head Squeeze"
    new "Внимание головке"

    old "Hold Still"
    new "Не двигаться"

    old "Move a little"
    new "Немного двигаться"

    old "Shift Position"
    new "Сдвинуться"

    old "Try pulling back"
    new "Попробовать потянуться"

    old "KITTY"
    new "КИСКА"


translate russian ep3_01_bathroom_fde30f4c:


    "Почему у меня встал именно сейчас?"


translate russian ep3_01_bathroom_fe3455c8:


    "Это не может быть из-за... неё."


translate russian ep3_01_bathroom_5eb9c25a:


    "Она так похожа на [Emily]."


translate russian ep3_01_bathroom_5f479130:


    "Да, скорее всего, так и есть!"


translate russian ep3_01_bathroom_16076183:


    "И всё же, что она об этом подумала?"


translate russian ep3_01_bathroom_535dd2b3:


    "Может, мне стоит поговорить с ней об этом завтра..."


translate russian ep3_dream_scene_49c3d96c:


    X "...значит, это первый раз, когда в тебя проникают?!"


translate russian ep3_dream_scene_28f6c382:


    Emily "Я же говорила тебе, я никогда ничего туда не совала!"


translate russian ep3_dream_scene_06df75e8:


    X "Даже ни одного крошечного огурчика?"


translate russian ep3_dream_scene_cbcb6954:


    Emily "Перестань дразнить меня!"


translate russian ep3_dream_scene_ea26c359:


    X "Ты правда хочешь начать с такого большого огурца?"


translate russian ep3_dream_scene_59dc35c8:


    Emily "Пожалуйста, [X]--"


translate russian ep3_dream_scene_7bdae608:


    Emily "Аах!"


translate russian ep3_dream_scene_02098835:


    Emily "Всё прошло, можешь продолжать."


translate russian ep3_dream_scene_66dc1efd:


    Emily "Пожалуйста, не торопись..."


translate russian ep3_dream_scene_46f9af13:


    X "Ух, вау!"


translate russian ep3_dream_scene_1df2673d:


    Emily "Вот оно!"


translate russian ep3_dream_scene_c1640518:


    Emily "Займись со мной любовью, [X]!"


translate russian continue_after_animation_25280b91:


    X "Угх!"


translate russian continue_after_animation_683424d6:


    X "Мне так хорошо, [Emily]."


translate russian continue_after_animation_a661932e:


    X "Я хочу делать это вечно!"


translate russian continue_after_animation_d41db32f:


    Emily "Да!"


translate russian continue_after_animation_67c94966:


    Emily "Я тоже, папочка!"


translate russian continue_after_animation_e0bf2cd8:


    X "Что?"


translate russian continue_after_animation_dd38644a:


    D "Я хочу, чтобы твоя любовь оказалась глубоко внутри меня!"


translate russian continue_after_animation_6c74e990:


    X "[D]?!"


translate russian continue_after_animation_85bb3922:


    X "Нет, это неправильно!"


translate russian continue_after_animation_3e193b93:


    D "Что случилось, пап?"


translate russian continue_after_animation_d772d49d:


    D "Тебе больно?"


translate russian continue_after_animation_c8158f5e:


    X "[D], эмм..."


translate russian continue_after_animation_5e252b90:


    X "Нет, я... мне приснился сон."


translate russian continue_after_animation_3e793ae2:


    X "А что такое?"


translate russian continue_after_animation_a3aedbc2:


    D "Я услышала стоны и подумала, что тебе больно."


translate russian continue_after_animation_e91f1c3a:


    D "Потом подошла к двери, ты позвал меня, и я вошла."


translate russian continue_after_animation_48237631:


    X "Ох, понятно, спасибо!"


translate russian continue_after_animation_cc9afd6b:


    X "Но я в порядке, беспокоиться не о чем."


translate russian continue_after_animation_00469b1a:


    X "Можешь возвращаться в кровать."


translate russian continue_after_animation_071b3e20:


    D "Хорошо..."


translate russian continue_after_animation_1b9f3990:


    "Должно быть, это была одна из тех ситуаций, когда реальность просачивается в сон."


translate russian continue_after_animation_7ff347c0:


    "Да, наверное, так оно и есть...."


translate russian continue_after_animation_c3cca0df:


    X "Итак, о прошлой ночи."


translate russian continue_after_animation_3dabebf1:


    D "Прости, что без спроса вошла в твою комнату!"


translate russian continue_after_animation_0ba47707:


    X "Тебе не за что извиняться!"


translate russian continue_after_animation_81e3e410:


    X "Мне просто снилось... кое-что. И я разговаривал во сне, вот и всё."


translate russian continue_after_animation_da178122:


    D "Снилось что-то страшное?"


translate russian continue_after_animation_1c43a5c9:


    X "Не совсем."


translate russian continue_after_animation_42fd9d7e:


    D "У тебя правда ничего не болело в тот момент?"


translate russian continue_after_animation_76250478:


    X "Да, правда. Почему ты спрашиваешь?"


translate russian continue_after_animation_bff52151:


    D "Из-за выпуклости."


translate russian continue_after_animation_d8dd56b5:


    X "Выпуклости?"


translate russian continue_after_animation_5367c33d:


    D "Твоего слоника."


translate russian continue_after_animation_5557e740:


    X "Ты имеешь в виду мой пенис!"


translate russian continue_after_animation_e322ca39:


    D "Да, твой..."


translate russian continue_after_animation_c7abf037:


    "Кажется, она мало что знает об этом."


translate russian continue_after_animation_ca07d257:


    "Лучше поговорить с ней."


translate russian continue_after_animation_e001c662:


    X "Говорить \"пенис\" - это нормально, это не ругательство."


translate russian continue_after_animation_7b9eeb69:


    X "И выпуклость тоже нормально."


translate russian continue_after_animation_ab77e852:


    D "Ох."


translate russian continue_after_animation_21f53673:


    D "Тогда ничего, если я расскажу тебе о своих... интимных местах?"


translate russian continue_after_animation_d515b7e1:


    X "Совершенно нормально. Какие бы проблемы у тебя ни возникли, ты можешь рассказать о них мне."


translate russian continue_after_animation_50f65977:


    X "Или поговори с [Eileen], если некомфортно."


translate russian continue_after_animation_fbd4c581:


    D "Ну, есть одна вещь..."


translate russian continue_after_animation_0ad44c85:


    D "Не уверена, что это моча, но сегодня утром я обнаружила, что мои трусики немного влажные."


translate russian continue_after_animation_5f8aff33:


    X "Были ли у тебя какие-либо боли?"


translate russian continue_after_animation_7eeecafc:


    D "Нет, но я также почувствовала, что там, внизу, немного тепло."


translate russian continue_after_animation_64651d32:


    "Может быть, она просто растёт."


translate russian continue_after_animation_fbb5ba36:


    X "Понимаю, в любом случае, если что-то ещё произойдёт, не стесняйся говорить об этом."


translate russian continue_after_animation_a058c9c0:


    D "Спасибо, папа!"


translate russian continue_after_animation_632178fa:


    Maya "Доброе утро, [X]."


translate russian continue_after_animation_892eac09:


    Maya "Я звоню, чтобы спросить, есть ли у вас время провести сеанс сегодня днём."


translate russian continue_after_animation_78be0355:


    X "Конечно. Нам нужно готовиться к олимпиаде."


translate russian continue_after_animation_cd5a36b1:


    X "Привет, док! Что нового?"


translate russian continue_after_animation_a0d6f651:


    Joan "Я поговорила с гинекологом о вашей дочери."


translate russian continue_after_animation_eba56e8b:


    Joan "У неё слишком низкий уровень гормонов для её возраста."


translate russian continue_after_animation_a4f4713f:


    X "Что это значит?"


translate russian continue_after_animation_57c93d14:


    Joan "Возможно, она поздно расцвела, но у неё уже произошёл скачок роста."


translate russian continue_after_animation_90c641b2:


    Joan "Так что, скорее всего, она принимала блокаторы полового созревания."


translate russian continue_after_animation_a4f396d5:


    Joan "Вы не знаете, были ли у неё какие-либо имплантаты или инъекции?"


translate russian continue_after_animation_35286392:


    X "Нет, но я могу спросить её."


translate russian continue_after_animation_d1304ed9:


    Joan "И если вы сможете найти её медицинскую карту, это действительно поможет."


translate russian continue_after_animation_ac38eab9:


    X "Я попробую."


translate russian continue_after_animation_7d99cf66:


    X "...а дома ты обычно принимала какие-нибудь лекарства?"


translate russian continue_after_animation_5725ee05:


    D "Принимала какие-то во время простуды."


translate russian continue_after_animation_705c1ad4:


    X "Это нормально."


translate russian continue_after_animation_fb514824:


    X "Ты принимала какие-нибудь таблетки, когда не болела?"


translate russian continue_after_animation_a49a69eb:


    X "Или какие-либо другие лекарства, например, инъекции?"


translate russian continue_after_animation_42d87d05:


    D "Нет."


translate russian continue_after_animation_5a43404d:


    D "Ой, подожди!"


translate russian continue_after_animation_4cd2799b:


    D "В этом году мне сделали прививку от гриппа."


translate russian continue_after_animation_cb5fee5a:


    D "Дело в том, что через месяц я всё равно заболела."


translate russian continue_after_animation_0b436681:


    X "Она была не от гриппа, да?"


translate russian continue_after_animation_66005784:


    X "Я говорил с ней об этом..."


translate russian continue_after_animation_4c5ec2dc:


    Joan "Ей могли ввести имплантат."


translate russian continue_after_animation_94dc54fc:


    Joan "Вам нужно сдать ещё несколько анализов, чтобы я могла сказать наверняка."


translate russian continue_after_animation_813c9822:


    X "Сделаем, спасибо, док!"


translate russian continue_after_animation_eb30fcee:


    "Чёрт возьми, что ещё они с ней делали..."


translate russian continue_after_animation_7f88a6ae:


    "Она может даже не осознавать того, что с ней произошло."


translate russian continue_after_animation_8c1f3fef:


    X "Я знаю, многое из этого для тебя в новинку."


translate russian continue_after_animation_502ac425:


    X "И требуется время, чтобы ознакомиться со здешними вещами, так что ничего страшного, если тебя что-то не устраивает."


translate russian continue_after_animation_a2f1b7ef:


    X "Например, есть что-то, что тебе не нравится, или называть меня папой, тебе не нужно заставлять себя делать что-либо из этого."


translate russian continue_after_animation_6ba497b1:


    D "Мне нравится называть тебя папой."


translate russian continue_after_animation_fb96fe7c:


    X "Даже если ты знаешь меня всего несколько дней?"


translate russian continue_after_animation_aa63e215:


    D "Я знала о тебе из того, что мама написала в дневнике."


translate russian continue_after_animation_aa2e9753:


    D "Я представляла, как мы все вместе разговариваем."


translate russian continue_after_animation_b226f779:


    X "И ты никогда не упоминала об этом своим приёмным родителям?"


translate russian continue_after_animation_21a9391d:


    D "Нет, [Radford]а никогда не было рядом. А если был, то не хотел разговаривать."


translate russian continue_after_animation_47d96f66:


    D "А с [Odelia] мне всегда приходилось вести себя так, как она хотела, или быть наказанной."


translate russian continue_after_animation_4750333a:


    D "Она никогда не хотела видеть {i}меня{/i}."


translate russian continue_after_animation_a7b17e06:


    X "Ну и чёрт с ними!"


translate russian continue_after_animation_77cec20a:


    X "Они всё равно тебя не заслуживают!"


translate russian continue_after_animation_a3fb1ef8:


    X "Эй, что ты думаешь о математике?"


translate russian continue_after_animation_406f0fa6:


    D "Я думаю, она интересная."


translate russian continue_after_animation_da43c7a1:


    X "Значит, ты не ненавидишь её! Это хорошо."


translate russian continue_after_animation_4b09de16:


    X "Я спросил это, потому что позже к нам придут две девушки для занятий."


translate russian continue_after_animation_7285d0c0:


    X "На днях ты познакомилась с [Alecia]."


translate russian continue_after_animation_7f50e911:


    D "Да."


translate russian continue_after_animation_b3f51836:


    X "Её подруга действительно хороша в математике, и я помогаю ей подготовиться к олимпиаде."


translate russian continue_after_animation_df6b9d47:


    D "Вау, правда?"


translate russian continue_after_animation_d9f23df4:


    X "Если хочешь, вы можете заниматься вместе."


translate russian continue_after_animation_f03647a3:


    X "Возможно, узнаете друг друга получше и даже подружитесь."


translate russian continue_after_animation_03180807:


    D "Я бы хотела этого!"


translate russian continue_after_animation_53f4cfe2:


    X "Думаю, это они!"


translate russian continue_after_animation_011b7b83:


    Maya "Привет!"


translate russian continue_after_animation_352ffe31:


    Maya "Я - [Maya], а эта девушка - [Sophie]."


translate russian continue_after_animation_999410a2:


    X "Это [D], моя дочь."


translate russian continue_after_animation_a1b05dd3:


    D "Здравствуйте, мисс [Maya] и [Sophie]!"


translate russian continue_after_animation_711a142b:


    Sophie "Привет!"


translate russian continue_after_animation_38a935d6:


    X "[D], можешь показать [Sophie] свою комнату?"


translate russian continue_after_animation_3d7314d6:


    X "На данный момент у меня нет лучшего места для вас."


translate russian continue_after_animation_a7d6fca3:


    D "Конечно!"


translate russian continue_after_animation_aa64c4b6:


    D "Она там, наверх по лестнице."


translate russian continue_after_animation_5a52ec5b:


    Maya "У вас есть минутка для разговора?"


translate russian continue_after_animation_895373f0:


    X "А как же [Alecia], она не придёт?"


translate russian continue_after_animation_d827be39:


    Maya "Сегодня её вызвали на работу."


translate russian continue_after_animation_8bfdd958:


    Maya "Она обещала прийти позже."


translate russian continue_after_animation_0db3ac33:


    X "Её нужно подвезти?"


translate russian continue_after_animation_56db0fc5:


    Maya "Нет, её привезёт коллега."


translate russian continue_after_animation_9896730e:


    X "Как там в детском доме?"


translate russian continue_after_animation_3ddcef56:


    Maya "Всё нормально, по крайней мере, до следующего сбора денег."


translate russian continue_after_animation_91bc6d43:


    X "Когда он будет?"


translate russian continue_after_animation_1409290c:


    Maya "Мне сказали, что Рождество - лучшее время для его организации."


translate russian continue_after_animation_101563ed:


    X "В этом есть смысл."


translate russian continue_after_animation_b04c8c28:


    X "Но было бы гораздо лучше просто получить достаточное финансирование от города."


translate russian continue_after_animation_2bffaf4c:


    Maya "Мы попробовали, но они продолжают говорить, что в этом нет необходимости, потому что с детским домом всё хорошо."


translate russian continue_after_animation_b9877a22:


    X "Поэтому они думают дать ещё меньше, как и в прошлом году."


translate russian continue_after_animation_7d2a624d:


    X "К тому же, причина, по которой у вас все хорошо, кроется в сообществе!"


translate russian continue_after_animation_92243b63:


    X "Да и откуда им это знать, ведь они же не часть этого!"


translate russian continue_after_animation_4c073dd9:


    Maya "Может быть, есть проблемы посерьёзнее наших."


translate russian continue_after_animation_333aa2ab:


    X "Да, но и о них они тоже не заботятся."


translate russian continue_after_animation_bedbe7ca:


    X "В любом случае, до Рождества ещё далеко."


translate russian continue_after_animation_1fb94f1d:


    X "И цены взлетели с прошлого года."


translate russian continue_after_animation_e4075d47:


    Maya "Мне удалось компенсировать это, поставляя продукты с фермы."


translate russian continue_after_animation_32f135ec:


    X "Вы нашли кого-то, кто может помочь? Может быть, муж?"


translate russian continue_after_animation_ca90bfea:


    Maya "Муж... боюсь, пока нет."


translate russian continue_after_animation_7f1816fd:


    Maya "Но [Alecia] ездила со мной."


translate russian continue_after_animation_9a580958:


    X "Вижу, она очень занята."


translate russian continue_after_animation_8ed6c1bf:


    Maya "Похоже, ей нравится процесс обучения."


translate russian continue_after_animation_332a60f0:


    X "Буду иметь это в виду."


translate russian continue_after_animation_692e0f1d:


    Maya "Не буду больше отнимать у вас время."


translate russian continue_after_animation_612218b6:


    X "Я провожу вас."


translate russian continue_after_animation_2034ca70:


    Maya "Нет, пожалуйста, не нужно."


translate russian continue_after_animation_b1e865d7:


    Maya "Я заеду за девочками позже."


translate russian continue_after_animation_03d5ef53:


    X "Окей."


translate russian continue_after_animation_96274ca7:


    Sophie "...и прямо сейчас мы изучаем это."


translate russian continue_after_animation_8fee8770:


    D "Я ничего об этом не знаю."


translate russian continue_after_animation_cec6bf03:


    D "В тесте было задание с этим, я его не поняла."


translate russian continue_after_animation_c3467cc1:


    Sophie "Если ты так много знаешь, может быть, мы будем в одном классе."


translate russian continue_after_animation_b5e7c7ac:


    D "Мне бы этого хотелось."


translate russian continue_after_animation_8eee2926:


    Sophie "И в любом случае ты можешь попросить мистера [X] помочь тебе."


translate russian continue_after_animation_43ab6c21:


    X "Кто этот мистер [X], о котором ты говоришь?"


translate russian continue_after_animation_1c40b665:


    Sophie "Простите, [X]."


translate russian continue_after_animation_9a5af023:


    X "Итак, я посмотрел материал, а также изучил предыдущие тесты."


translate russian continue_after_animation_8ce14445:


    X "Начнём с того, что посмотрим, как ты решала предыдущие задачи на соревнованиях."


translate russian continue_after_animation_064406f0:


    D "Что за соревнования?"


translate russian continue_after_animation_6fa166db:


    Sophie "В последние годы я участвовала в олимпиадах."


translate russian continue_after_animation_2d685471:


    D "Так вот почему ты всё это знаешь!"


translate russian continue_after_animation_6c28902d:


    Sophie "Большую часть материала я просматриваю заранее."


translate russian continue_after_animation_fa48be36:


    X "Чтобы всё это было свежо в памяти."


translate russian continue_after_animation_345034eb:


    Sophie "Эта задача заняла меня надолго. Я потеряла много времени, придумывая более элегантное решение."


translate russian continue_after_animation_9af51742:


    X "Вижу, ты выбрала очевидное решение, и в итоге оно оказалось слишком длинным."


translate russian continue_after_animation_02222d70:


    Sophie "Именно так."


translate russian continue_after_animation_c5b8316e:


    X "На более поздних этапах олимпиад возникает больше подобных задач."


translate russian continue_after_animation_398f56f6:


    X "Так что давайте поработаем над ними сейчас."


translate russian continue_after_animation_46ce5dc8:


    D "Ставят ли они меньше баллов, если твоё решение слишком длинное?"


translate russian continue_after_animation_f06edf56:


    X "Если они предполагали более простой вариант решения задачи, то да."


translate russian continue_after_animation_e6570b9d:


    Sophie "Также можно придумать что-то новое. За это ставят дополнительные баллы."


translate russian continue_after_animation_4b14c483:


    X "Что ж, почти закончили. Пойду приготовлю сэндвичи."


translate russian continue_after_animation_084d299d:


    D "Я могу помочь."


translate russian continue_after_animation_6cf55077:


    X "В этом нет необходимости. Вы, девочки, просто отдыхайте."


translate russian continue_after_animation_46a4c3c2:


    "Лучше снова не класть лук, на всякий случай."


translate russian continue_after_animation_b316f870:


    X "Открыто, входите!"


translate russian continue_after_animation_c85c810e:


    X "Эй, ты пришла!"


translate russian continue_after_animation_a4327726:


    Alecia "Меня отпустили только сейчас. Как мы и договаривались."


translate russian continue_after_animation_9baf736a:


    X "Я понимаю, но это только половина договора."


translate russian continue_after_animation_182946a5:


    Alecia "Я знаю."


translate russian continue_after_animation_99fc4a3a:


    X "И на сегодня мы почти закончили. Можешь помыть салат?"


translate russian continue_after_animation_45236dbe:


    Alecia "Да, конечно."


translate russian continue_after_animation_35628c10:


    "Если ей нравится агрономия, я могу попытаться вызвать у неё интерес и увлечь чем-нибудь."


translate russian continue_after_animation_c1446b59:


    X "Я купил его у местного фермера. Наверное, это такой же салат, что и в магазине."


translate russian continue_after_animation_5e2502f5:


    Alecia "Не такой же."


translate russian continue_after_animation_67aeeb90:


    X "Они оба зеленые, а вкус не чувствуется, какая разница?"


translate russian continue_after_animation_d290230e:


    Alecia "Даже близко не один и то же!"


translate russian continue_after_animation_89f52cea:


    Alecia "Вы хотя бы пробовали сравнивать что-нибудь ещё, кроме салата?"


translate russian continue_after_animation_fc79abaf:


    X "Но у меня есть только салат, что ещё нужно?"


translate russian continue_after_animation_b3b85c48:


    Alecia "Да вы шутите!"


translate russian continue_after_animation_476e4f84:


    Alecia "Вы готовите только сэндвичи?"


translate russian continue_after_animation_0783e249:


    X "Я также умею варить яйца."


translate russian continue_after_animation_926fcfc1:


    Alecia "Попробуйте шпинат, морковь, огурцы, помидоры - все они лучше от местных производителей."


translate russian continue_after_animation_1cda2ba5:


    X "Ты, кажется, действительно уверена в этом."


translate russian continue_after_animation_b5c262c3:


    X "Возможно, они просто покупают всё в магазине и продают якобы своё."


translate russian continue_after_animation_203ce8f5:


    X "Откуда тебе знать?"


translate russian continue_after_animation_9123a84b:


    Alecia "Потому что я работала с ними."


translate russian continue_after_animation_134e3165:


    X "Правда?"


translate russian continue_after_animation_ae689cd7:


    X "Я бы тоже хотел когда-нибудь съездить туда."


translate russian continue_after_animation_3d9d922c:


    Alecia "[Maya] часто уходит домой, чтобы ухаживать за посевами, и большую часть дня работает."


translate russian continue_after_animation_20c64e9a:


    Alecia "Не стесняйтесь протянуть руку помощи."


translate russian continue_after_animation_0223bce6:


    X "Я знаю, что она очень заботится о вас, ребята, но беспокоюсь, что она слишком сильно себя нагружает."


translate russian continue_after_animation_efbeff36:


    Alecia "Да, я хотела помочь, но она отказала мне."


translate russian continue_after_animation_0283f4d1:


    Alecia "Тогда я сказала ей, что интересуюсь агрономией, чтобы она не чувствовала себя виноватой за то, что якобы использовала меня."


translate russian continue_after_animation_1b7a0bcc:


    X "Тактично."


translate russian continue_after_animation_0759fc73:


    X "Так много работать вредно для здоровья. Я могу найти немного времени, чтобы помочь."


translate russian continue_after_animation_39f02934:


    Alecia "Уже скоро сбор урожая, так что дам вам знать, как придёт время."


translate russian continue_after_animation_f6e926c7:


    X "В следующий раз я попробую что-нибудь новенькое. Не хочу, чтобы я вам, девочки, надоел."


translate russian continue_after_animation_348a8c45:


    Alecia "Как предусмотрительно."


translate russian continue_after_animation_fce3291b:


    Sophie "Надеюсь, мы будем учиться в одном классе!"


translate russian continue_after_animation_08c29bdb:


    D "Я тоже!"


translate russian continue_after_animation_ca31b912:


    Alecia "До свидания."


translate russian continue_after_animation_6c529624:


    D "Пока, пока!"


translate russian continue_after_animation_a80a1dc6:


    X "Тебе понравилось?"


translate russian continue_after_animation_186afa30:


    X "Имею в виду не математику, а общение с [Sophie]."


translate russian continue_after_animation_75baada3:


    D "Да, она очень милая!"


translate russian continue_after_animation_0dbcd1b8:


    D "И можем ли мы ещё позаниматься математикой?"


translate russian continue_after_animation_af0e8133:


    X "Ещё!? Конечно, мы можем заниматься сколько захочешь!"


translate russian continue_after_animation_f8e4845e:


    X "Но на сегодня хватит, давай просто отдохнём."


translate russian continue_after_animation_778ca776:


    X "У меня есть несколько фильмов. Какой хочешь посмотреть?"


translate russian continue_after_animation_b72bc322:


    X "Это классический боевик, много перестрелок и взрывов."


translate russian continue_after_animation_a926909c:


    D "Ээ..."


translate russian continue_after_animation_7b2920cb:


    X "Не заинтересовал, я вижу."


translate russian continue_after_animation_18c21575:


    D "Что это?"


translate russian continue_after_animation_7ca6f4fb:


    X "Это комедия, с призраками и прочим."


translate russian continue_after_animation_fcedf5ca:


    D "Он страшный?"


translate russian continue_after_animation_aa2fd6f9:


    X "Может, для малышей да, но ты уже большая девочка."


translate russian continue_after_animation_2c115594:


    X "Это скорее научная фантастика. И он действительно страшный."


translate russian continue_after_animation_51b76fec:


    D "Я прочитала несколько научно-фантастических книг, они были забавными!"


translate russian continue_after_animation_e9ff8d30:


    X "Мы можем поговорить о них."


translate russian continue_after_animation_54c4ad44:


    X "Не знаю, как он ко мне попал."


translate russian continue_after_animation_cedb3c3d:


    D "О чём он?"


translate russian continue_after_animation_1d2fa072:


    X "Не знаю, я ещё его не смотрел."


translate russian continue_after_animation_d9863342:


    X "Но просмотр подобных фильмов по телевизору не отдаёт им должного."


translate russian continue_after_animation_cc2b97d3:


    X "В городе есть места, где можно посмотреть фильмы на гигантском экране!"


translate russian continue_after_animation_822b2daa:


    D "Ты имеешь в виду кинотеатры?"


translate russian continue_after_animation_ddffe675:


    X "Когда-нибудь была там?"


translate russian continue_after_animation_040c564a:


    D "Нет, но я читала о них."


translate russian continue_after_animation_6aed2803:


    X "Ну, так дело не пойдёт!"


translate russian continue_after_animation_42911239:


    X "Мы можем сходить в один из них завтра. Как тебе идея?"


translate russian continue_after_animation_69478917:


    D "Отлично!"


translate russian continue_after_animation_eaaa34b8:


    "А какой фильм посмотреть сейчас?"


translate russian continue_after_animation_175f1e00:


    "Этот, пожалуй, самый безопасный вариант."


translate russian continue_after_animation_5b4e0324:


    X "Давай посмотрим, о чём он."


translate russian continue_after_animation_a7a0eccd:


    X "Ну, это был... фильм."


translate russian continue_after_animation_650fcc42:


    D "Мне понравилось."


translate russian continue_after_animation_7c01a20c:


    X "А теперь пора спать, уже поздно."


translate russian continue_after_animation_d35ef31c:


    X "Давай посмотрим этот."


translate russian continue_after_animation_56f607db:


    X "И конец."


translate russian continue_after_animation_4da88a25:


    D "Это было весело!"


translate russian continue_after_animation_7c01a20c_1:


    X "А теперь пора спать, уже поздно."


translate russian continue_after_animation_db1355fc:


    "Похоже, этот её заинтересовал."


translate russian continue_after_animation_7e7a2435:


    X "Если тебе станет слишком страшно, мы всегда можем остановиться."


translate russian continue_after_animation_b5e21b9f:


    D "Хорошо!"


translate russian continue_after_animation_68637d9c:


    X "Конец."


translate russian continue_after_animation_163e929b:


    X "Несколько раз испугалась, но всё же посмотрела до конца."


translate russian continue_after_animation_dddcb969:


    D "Я хотела увидеть всю историю."


translate russian continue_after_animation_4f8d4969:


    X "Она завораживает."


translate russian continue_after_animation_7c01a20c_2:


    X "А теперь пора спать, уже поздно."


translate russian continue_after_animation_21845ff2:


    X "Начнём с классики."


translate russian continue_after_animation_071b3e20_1:


    D "Ладно..."


translate russian continue_after_animation_55aebe0d:


    X "Конец."


translate russian continue_after_animation_b9487200:


    D "Это было потрясающе."


translate russian continue_after_animation_7c01a20c_3:


    X "А теперь пора спать, уже поздно."


translate russian continue_after_animation_71b84993:


    "Сегодня по-прежнему никаких новостей."


translate russian continue_after_animation_e4a3bbd3:


    "Надо немного поспать..."


translate russian continue_after_animation_9f8720a5:


    D "Пап... Ты не спишь?"


translate russian continue_after_animation_9ab3b940:


    X "Да, что-то случилось?"


translate russian continue_after_animation_17f69cd9:


    D "Мне страшно!"


translate russian continue_after_animation_f0d9fc6b:


    D "Можно войти?"


translate russian continue_after_animation_a034287c:


    X "Конечно."


translate russian continue_after_animation_10315a8c:


    D "Я боюсь... инопланетян."


translate russian continue_after_animation_4fc491dd:


    X "Это нормально, после просмотра того фильма."


translate russian continue_after_animation_fab02c56:


    X "Если хочешь, можешь переночевать со мной."


translate russian continue_after_animation_7c55a997:


    D "Спасибо!"


translate russian continue_after_animation_61d84536:


    D "Я знаю, что это глупо, но ничего не могу с собой поделать."


translate russian continue_after_animation_15c2355c:


    X "У всех нас была такая реакция."


translate russian continue_after_animation_303d6103:


    X "Первый раз - когда я был маленьким. Туалет находился в другом конце коридора."


translate russian continue_after_animation_6e293880:


    D "И что ты сделал?"


translate russian continue_after_animation_cec359d3:


    X "Я упомянул, что был маленьким. И мне пришла в голову гениальная идея просто сделать это в окно."


translate russian continue_after_animation_fdd2c6d5:


    D "Ты пописал в окно?"


translate russian continue_after_animation_c8875320:


    X "Да, но никому не рассказывай!"


translate russian continue_after_animation_afe30f95:


    X "Мне это сошло с рук, в отличие от других проделок."


translate russian continue_after_animation_0f6a87c4:


    D "Например, каких?"


translate russian continue_after_animation_a250a877:


    X "Был один случай..."


translate russian continue_after_animation_073885b5:


    X "...в итоге я две недели чистил картошку в одиночку."


translate russian continue_after_animation_279b807d:


    X "Но они обошлись со мной справедливо--"


translate russian continue_after_animation_d42b1a74:


    "Она уснула."


translate russian continue_after_animation_a96b60c0:


    "Лучше немного прибавить температуру..."


translate russian continue_after_animation_e8077c6f:


    D "Мммм."


translate russian continue_after_animation_9ff8a76e:


    D "Папа..."


translate russian continue_after_animation_e680a7ee:


    X "[D]?"


translate russian continue_after_animation_c8caa825:


    X "Ты--"


translate russian continue_after_animation_c769d247:


    "Она трогает себя?"


translate russian continue_after_animation_803dd1a4:


    "Похоже, она всё ещё спит."


translate russian continue_after_animation_b80463dc:


    "Лучше уйти..."


translate russian continue_after_animation_c79144ba:


    "Она уже встала."


translate russian continue_after_animation_003a8989:


    "Одежды уже целая куча."


translate russian continue_after_animation_e804e301:


    "Время стирки."


translate russian continue_after_animation_b73d4cde:


    "Посмотрим, рубашка, брюки."


translate russian continue_after_animation_8b57161f:


    "Её пижама мокрая."


translate russian continue_after_animation_a01bbd01:


    "Не из-за пота, только в этой области мокро."


translate russian continue_after_animation_8e9b38a6:


    "Стоп!"


translate russian continue_after_animation_2fe60750:


    X "Ебена мать!"


translate russian continue_after_animation_28276cc7:


    "Это случилось снова. Должно быть, это из-за неё."


translate russian continue_after_animation_5117fd36:


    "Я мог бы... позаботиться об этом."


translate russian continue_after_animation_3e911982:


    "Просто потому, что она напоминает мне [Emily]."


translate russian continue_after_animation_fb6c8e33:


    "Да, в этом вся причина."


translate russian continue_after_animation_9920dd41:


    "Сделаю это быстро."


translate russian continue_after_animation_47e7e2ab:


    X "Уггхх!"


translate russian continue_after_animation_6fa9f974:


    X "Бля!"


translate russian continue_after_animation_4ec611da:


    "Это не казалось таким уж неправильным, как должно было..."


translate russian continue_after_animation_fcb734bd:


    "Она моя дочь!"


translate russian continue_after_animation_f552ce75:


    "О чём, чёрт возьми, я думаю!"


translate russian continue_after_animation_ab942fc8:


    "Давненько я не проверял свою почту."


translate russian continue_after_animation_3d2e8a3e:


    "Что за чёрт, предложение вернуться в компанию?!"


translate russian continue_after_animation_762084a6:


    "Видимо, они не смогли разобраться в моём говнокоде."


translate russian continue_after_animation_304dc1f1:


    "Некоторые из моей команды всё ещё там, я мог бы им помочь."


translate russian continue_after_animation_9ce875e9:


    "Или нет."


translate russian continue_after_animation_83262c29:


    "Они, наверное, чертовски стараются."


translate russian continue_after_animation_8448155b:


    "Я мог бы сделать это ради команды..."


translate russian continue_after_animation_b316be8a:


    "Да пошли они!"


translate russian continue_after_animation_f9333da7:


    "Но раз уж они дали мне возможность ответить..."


translate russian continue_after_animation_f4acfa56:


    "Кто бы это мог быть?"


translate russian continue_after_animation_3485efb1:


    X "Привет, [Eileen], что всё это значит?"


translate russian continue_after_animation_2e3a1180:


    Eileen "Всего несколько вещей для этой милашки, внизу есть ещё."


translate russian continue_after_animation_7a804aeb:


    Eileen "Там торт, так что будь осторожен!"


translate russian continue_after_animation_03d5ef53_1:


    X "Окей."


translate russian continue_after_animation_5a7a712e:


    Eileen "Где хозяйка дома?"


translate russian continue_after_animation_c8de816c:


    X "Наверху. Что ты принесла?"


translate russian continue_after_animation_89ff813d:


    Eileen "Девичьи штучки."


translate russian continue_after_animation_9ae218d9:


    Eileen "И я хочу удивить её тортом."


translate russian continue_after_animation_0a28f6ea:


    X "Хорошо, я займусь этим."


translate russian continue_after_animation_c3fece90:


    Eileen "Не подглядывать!"


translate russian continue_after_animation_47f6a295:


    D "У меня тоже глаза закрыты!"


translate russian continue_after_animation_7c078612:


    Eileen "С днём рождения!"


translate russian continue_after_animation_b481cf62:


    D "Это мне?"


translate russian continue_after_animation_e9c7bb39:


    Eileen "Конечно! Это клубника, я правильно поняла?"


translate russian continue_after_animation_dea0849b:


    D "Да!"


translate russian continue_after_animation_8d374151:


    D "Но на самом деле мой день рождения не сегодня."


translate russian continue_after_animation_c6268753:


    Eileen "Ой, чёрт! Тогда нам лучше найти, что отпраздновать."


translate russian continue_after_animation_35beac40:


    Eileen "Есть идеи, папочка?"


translate russian continue_after_animation_ecb071d7:


    X "Возможно, сегодня не ДЕНЬ твоего рождения, но сейчас ГОД твоего рождения."


translate russian continue_after_animation_95ef8ce8:


    Eileen "Ага, я поняла! Ты придумал небольшую лазейку."


translate russian continue_after_animation_cb6957c9:


    Eileen "Так что с годом рождения тебя..."


translate russian continue_after_animation_edbcd4ab:


    X "Как насчет дня именин?"


translate russian continue_after_animation_eb04dbf8:


    Eileen "Думаю, подходит."


translate russian continue_after_animation_c2b59c31:


    Eileen "А теперь загадай желание, но никому не говори."


translate russian continue_after_animation_24a93824:


    Eileen "Затем задуй свечу."


translate russian continue_after_animation_0caf9fe7:


    D "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}🌬️{/font}"


translate russian continue_after_animation_76c9fb76:


    "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}👏 👏 👏{/font}"


translate russian continue_after_animation_2e32624f:


    X "Ура!"


translate russian continue_after_animation_1732bc8e:


    Eileen "А теперь давайте возьмём по кусочку!"


translate russian continue_after_animation_79945813:


    Eileen "Как это было, [D]?"


translate russian continue_after_animation_9a8d11e3:


    Eileen "Отвечай честно!"


translate russian continue_after_animation_37b2f259:


    D "Просто огонь!"


translate russian continue_after_animation_d61dc6bf:


    D "Я правильно это использовала?"


translate russian continue_after_animation_1ce1f6df:


    Eileen "Прямо в точку!"


translate russian continue_after_animation_e650f26b:


    D "[Sophie] сказала это о доме."


translate russian continue_after_animation_6988079d:


    X "Правда? Ну, я думаю..."


translate russian continue_after_animation_961235a5:


    Eileen "Знаете, я сделала большую часть украшения в этом месте."


translate russian continue_after_animation_1a10d0a9:


    Eileen "И сделала бы правильно, но [X] практически выгнал меня."


translate russian continue_after_animation_8d0e7fcd:


    X "Я видел твою квартиру, ты бы просто продолжила, если бы я тебе позволил."


translate russian continue_after_animation_2fd97107:


    Eileen "Чертовски верно!"


translate russian continue_after_animation_86268987:


    Eileen "Здесь просто так много пустого пространства!"


translate russian continue_after_animation_862f2b62:


    Eileen "Уверена, что [D] со мной согласна."


translate russian continue_after_animation_63667c39:


    D "Дом... просторный."


translate russian continue_after_animation_9cfe6f43:


    X "И это хорошо!"


translate russian continue_after_animation_bbb14c18:


    Eileen "Но это не одно и то же, так что не создавай впечатление, что она со мной не согласна!"


translate russian continue_after_animation_c912c29e:


    Eileen "А теперь, как насчёт того, чтобы вы оба зашли ко мне?"


translate russian continue_after_animation_28eb372e:


    Eileen "Если мне удастся убедить [D] в своей точке зрения, ты должен разрешить больше украшений."


translate russian continue_after_animation_0fb8d540:


    Eileen "И [D] будет делать всё по своему усмотрению."


translate russian continue_after_animation_cfe1bfb4:


    X "Без проблем!"


translate russian continue_after_animation_6c5d53b3:


    X "А если она согласится со мной, ты должна будешь испечь ей торт, когда она захочет!"


translate russian continue_after_animation_3f89bf71:


    Eileen "С удовольствием, я в деле!"


translate russian continue_after_animation_66a483f9:


    X "Но нам придётся сделать это в другой раз."


translate russian continue_after_animation_05d4bc05:


    X "Мы уже договорились сходить вечером в кинотеатр."


translate russian continue_after_animation_401afbb7:


    D "О, ты можешь пойти с нами, [Eileen]!"


translate russian continue_after_animation_e825d52c:


    Eileen "Я бы с радостью, дорогая, но мне нужно идти. Осталось испечь ещё немного выпечки."


translate russian continue_after_animation_ab77e852_1:


    D "Ох."


translate russian continue_after_animation_cb134357:


    Eileen "Эй, не волнуйся! Я присоединюсь в другой раз."


translate russian continue_after_animation_05fa0064:


    Eileen "Может, даже испечём вместе торт, если захочешь."


translate russian continue_after_animation_a32fd5b5:


    D "Я бы с удовольствием!"


translate russian continue_after_animation_c2dbffc4:


    X "Нам лучше начать готовиться, пока не стало слишком поздно."


translate russian continue_after_animation_1b55994b:


    D "Я пойду приберусь."


translate russian continue_after_animation_9f168eee:


    Eileen "Мне нужно показать тебе кое-что, поэтому я пойду."


translate russian continue_after_animation_ced26554:


    X "Тогда я пойду в душ."


translate russian continue_after_animation_76e081db:


    Eileen "Эй, [X]! Ты ещё моешься?"


translate russian continue_after_animation_36f85856:


    X "Да."


translate russian continue_after_animation_516597e0:


    Eileen "Просто мне нужно в туалет."


translate russian continue_after_animation_a76fdc6c:


    X "Заходи."


translate russian continue_after_animation_6d698f69:


    Eileen "Я набрала ей ванну и рассказала об использовании прокладок и тампонов."


translate russian continue_after_animation_50ac8e30:


    X "Спасибо."


translate russian continue_after_animation_37a24bb8:


    X "Ты уже закончила?"


translate russian continue_after_animation_d887eb02:


    Eileen "Она умная девочка, быстро схватывает."


translate russian continue_after_animation_7d4803e5:


    X "Вся в мать."


translate russian continue_after_animation_6070a4d9:


    Eileen "Ага."


translate russian continue_after_animation_c5de5843:


    Eileen "Всплыло что-нибудь новое?"


translate russian continue_after_animation_80d39d09:


    X "Есть несколько вещей..."


translate russian continue_after_animation_1dc11827:


    Eileen "Они заставляли её принимать блокаторы половых гормонов?!"


translate russian continue_after_animation_3ccdc38d:


    X "Похоже на то. Всё ещё нужно сделать несколько тестов."


translate russian continue_after_animation_8c0a6c21:


    Eileen "И по-прежнему никаких новостей об [Emily]?"


translate russian continue_after_animation_e9adbce0:


    X "Жду, пока [Charlie] получит ордер и начнёт расследование в отношении приемных родителей [D]."


translate russian continue_after_animation_fc1b141e:


    Eileen "По крайней мере, дело продвигается."


translate russian continue_after_animation_887494a6:


    X "Ага."


translate russian continue_after_animation_b6b73106:


    Eileen "Я закончила, хочешь, я помою тебе спину?"


translate russian continue_after_animation_91f08f1e:


    X "Конечно, если хочешь."


translate russian continue_after_animation_1e478844:


    X "Подожди, а почему ты голая?"


translate russian continue_after_animation_ef32b422:


    Eileen "Решила, что получу бесплатный душ и сэкономлю деньги."


translate russian continue_after_animation_334bdb2e:


    Eileen "А что, какие-то проблемы?"


translate russian continue_after_animation_5b03ddc0:


    X "Не совсем, но мне кажется, что не стоит."


translate russian continue_after_animation_a9c687ae:


    Eileen "Просто не смотри!"


translate russian continue_after_animation_0d76db19:


    X "О, ты права, проблема решена."


translate russian continue_after_animation_01f3466e:


    X "Эй!"


translate russian continue_after_animation_771fc588:


    Eileen "Что?"


translate russian continue_after_animation_9dedf279:


    Eileen "Я вымыла твою спину, теперь ты вымой мою."


translate russian continue_after_animation_bc25fa5b:


    X "Я слишком легкомысленно отношусь к этому."


translate russian continue_after_animation_3c1c930b:


    Eileen "Так ты хочешь взять на себя ответственность, большой силач?"


translate russian continue_after_animation_10c52cd8:


    X "Не знаю."


translate russian continue_after_animation_63a06471:


    Eileen "Но я чувствую от тебя твёрдую инициативу."


translate russian continue_after_animation_247626d3:


    X "О, это... неправильно."


translate russian continue_after_animation_b2cbe444:


    Eileen "Да, похоже, ты придерживаешься более пофигистической позиции."


translate russian continue_after_animation_0e898710:


    Eileen "Хочешь ещё немного посидеть на заборе?"


translate russian continue_after_animation_6044d30b:


    X "Стой!"


translate russian continue_after_animation_79a703e1:


    X "Оохх!"


translate russian continue_after_animation_855623a9:


    Eileen "Расслабься, я обо всём позабочусь."


translate russian continue_after_animation_6ea30c82:


    X "Я могу... сделать это сам."


translate russian continue_after_animation_035420c9:


    Eileen "У тебя эрекция возникала сама по себе?"


translate russian continue_after_animation_36f85856_1:


    X "Да."


translate russian continue_after_animation_d78cab4b:


    Eileen "Без эротических снов?"


translate russian continue_after_animation_94957a9e:


    X "Ну..."


translate russian continue_after_animation_753c879c:


    "Не могу рассказать ей о тех временах."


translate russian continue_after_animation_aa50d3b8:


    Eileen "Нашёл кого-то, кто может это делать?"


translate russian continue_after_animation_75bf4b10:


    X "Нет..."


translate russian continue_after_animation_0452ce6b:


    Eileen "Тогда тебе всё ещё нужна моя помощь."


translate russian continue_after_animation_f53baa80:


    Eileen "Так что стой и наслаждайся."


translate russian continue_after_animation_2_2726fc24:


    X "Я сейчас кончу, [Eileen]!"


translate russian continue_after_animation_2_866b46fa:


    Eileen "Выплесни всё!"


translate russian continue_after_animation_2_03fdf9cb:


    X "Бляяя!"


translate russian continue_after_animation_2_d18bb5f1:


    Eileen "Её было... очень много."


translate russian continue_after_animation_2_6806fd4c:


    Eileen "Я могу сказать, что тебе это было нужно."


translate russian continue_after_animation_2_96eba18f:


    X "Возможно, это правда."


translate russian continue_after_animation_2_22e16407:


    X "Спасибо..."


translate russian continue_after_animation_2_1604b723:


    X "Я в порядке, спасибо."


translate russian continue_after_animation_2_bbd964a1:


    D "Ты правда не можешь пойти с нами сегодня вечером?"


translate russian continue_after_animation_2_2e7bb70c:


    Eileen "Прости, дорогая, мне правда пора идти."


translate russian continue_after_animation_2_94f1bce6:


    Eileen "Скоро куда-нибудь сходим, просто потерпи, хорошо?"


translate russian continue_after_animation_2_c6e11dd4:


    D "Угу!"


translate russian continue_after_animation_2_8046b76f:


    Eileen "Повеселитесь там!"


translate russian continue_after_animation_2_59164ff6:


    D "Пока, [Eileen]!"


translate russian continue_after_animation_2_651a7b67:


    Eileen "Пока, милашка!"


translate russian continue_after_animation_2_8236fe3d:


    X "Готова выходить?"


translate russian continue_after_animation_2_33d7bb86:


    D "Я пойду переоденусь."


translate russian continue_after_animation_2_41a158ff:


    X "Мы на месте."


translate russian continue_after_animation_2_a5be9227:


    D "Вау!"


translate russian continue_after_animation_2_f28fd22d:


    D "Выглядит совсем как в фильмах!"


translate russian continue_after_animation_2_18ce440c:


    X "Это старый классический стиль."


translate russian continue_after_animation_2_962efbdf:


    X "Как тебе эти сиденья?"


translate russian continue_after_animation_2_a225b3af:


    X "Мы можем пересесть на другие, если хочешь быть поближе к экрану."


translate russian continue_after_animation_2_899b1c9a:


    D "Меня всё устраивает."


translate russian continue_after_animation_2_60e6f914:


    X "Я подумал, что ты хочешь что-нибудь научно-фантастическое."


translate russian continue_after_animation_2_bf9eae15:


    "Она, кажется, поглощена происходящим."


translate russian continue_after_animation_2_321f1d5f:


    "Как можно ни разу не сводить ребёнка в кино?"


translate russian continue_after_animation_2_9108ad88:


    "И просто держить её дома."


translate russian continue_after_animation_2_e3074562:


    "Я никогда не позволю им забрать её!"


translate russian continue_after_animation_2_6f825c05:


    D "Пап."


translate russian continue_after_animation_2_3808f82c:


    X "Как тебе фильм?"


translate russian continue_after_animation_2_37b2f259:


    D "Супер!"


translate russian continue_after_animation_2_03d81513:


    D "Спасибо, что взял меня с собой!"


translate russian continue_after_animation_2_d8e62696:


    X "С удовольствием, мы можем ходить сюда столько, сколько захочешь."


translate russian continue_after_animation_2_07ea23c9:


    D "Это было очень весело!"


translate russian continue_after_animation_2_42725aec:


    D "Но у меня немного кружится голова."


translate russian continue_after_animation_2_3847e6c9:


    X "Должна скоро пройти."


translate russian continue_after_animation_2_da5278cd:


    X "Подожди здесь, я выброшу мусор."


translate russian continue_after_animation_2_7c3b4d90:


    "Похоже, я начинаю понимать, какого быть родите--"


translate russian continue_after_animation_2_4adef392:


    D "Ааааххх! Папочка!!"


translate russian continue_after_animation_2_a935fc86:


    X "[D]!!!"


translate russian continue_after_animation_2_6f9d58cc:


    X "Отпустите её, ублюдки!!!"


translate russian continue_after_animation_2_2fe60750:


    X "Проклятье!"


translate russian continue_after_animation_2_789d3f2b:


    "Какого хуя эти пидоры делают?"


translate russian continue_after_animation_2_06bd0b8f:


    "Они поехали этой дорогой?"


translate russian continue_after_animation_2_94cd69d6:


    X "СУКА!!"


translate russian continue_after_animation_2_ae5adc07:


    X "Потерял их!"


translate russian continue_after_animation_2_a5769621:


    "Но я знаю этих хуесосов!"


translate russian continue_after_animation_2_c3e65f95:


    "[Khalil] должен знать, куда они поехали."


translate russian continue_after_animation_2_5a48feb7:


    Khalil "Йоу, [X]! Как дела?"


translate russian continue_after_animation_2_c0b96a15:


    X "[Khalil], ты знаешь, где сейчас орудуют ублюдки?"


translate russian continue_after_animation_2_2275822b:


    Khalil "Дерьмо! У тебя с ними проблемы?"


translate russian continue_after_animation_2_395a0142:


    Khalil "Где ты?"


translate russian continue_after_animation_2_500d115e:


    X "У меня сейчас нет времени, просто скажи мне, где они."


translate russian continue_after_animation_2_31f461e5:


    Khalil "Они возле старого дока, на складе."


translate russian continue_after_animation_2_02b64f6b:


    Khalil "Что случилось то?"


translate russian continue_after_animation_2_72b5f660:


    X "Они забрали мою дочь!"


translate russian continue_after_animation_2_ce7e5dbb:


    Khalil "Твою дочь?!"


translate russian continue_after_animation_2_d7bd6d80:


    X "Я должен побыстрее с этим разобраться, поговорим после!"


translate russian continue_after_animation_2_1ae12f45:


    Khalil "Ладно, парень, если тебе нужна помощь, только скажи!"


translate russian continue_after_animation_2_92da22e7:


    "Похоже, это то самое место."


translate russian continue_after_animation_2_b0a53a6b:


    "Эти идиоты даже ворота не заперли."


translate russian continue_after_animation_2_fd9a16e2:


    "Как будто они хозяева улицы."


translate russian continue_after_animation_2_a98d9e00:


    "Нигде не вижу фургона."


translate russian continue_after_animation_2_0a48513a:


    "Бандит №1" "Ты не можешь позволить этой сучке так с тобой разговаривать!"


translate russian continue_after_animation_2_2aa99d28:


    "Бандит №1" "В следующий раз, когда она откроет рот, уда--"


translate russian continue_after_animation_2_0e91f280:


    X "Твой босс здесь? Мне нужно с ним поговорить."


translate russian continue_after_animation_2_2fc29893:


    "Бандит №1" "'Вот чёрт...'"


translate russian continue_after_animation_2_e6990407:


    "Бандит №1" "Убирайся на хрен, пока я не разбил твой череп об землю!"


translate russian continue_after_animation_2_c65dc125:


    X "Ты слишком много ругаешься."


translate russian continue_after_animation_2_ad7213d6:


    "Бандит №1" "Ты ублюдок!!"


translate russian continue_after_animation_2_848c6028:


    X "Осторожнее!"


translate russian continue_after_animation_2_51061233:


    X "Разве твои родители не учили тебя не играть с ножами?"


translate russian continue_after_animation_2_d14b437f:


    X "Я оставлю его себе."


translate russian continue_after_animation_2_62f2fd8e:


    Jerold "...и вот ты здесь, весь чистый!"


translate russian continue_after_animation_2_bd6d1481:


    "Я узнаю этот голос."


translate russian continue_after_animation_2_b72ad97d:


    Jerold "Не стесняйся всё посчитать."


translate russian continue_after_animation_2_17493949:


    "???" "Твой отец заверил меня, что в этом нет необходимости."


translate russian continue_after_animation_2_728ac186:


    Jerold "Теперь мы также можем помочь с выбором недвижимо--"


translate russian continue_after_animation_2_d0e4a5e3:


    X "Эй, [Jerold]!"


translate russian continue_after_animation_2_d6ea7756:


    X "Слышал, у тебя есть девушки."


translate russian continue_after_animation_2_0b63ba68:


    X "Мне бы хотелось молодую блондинку с глубокими голубыми глазами."


translate russian continue_after_animation_2_dfb3439a:


    X "Ты недавно обзавёлся такой?"


translate russian continue_after_animation_2_efde5941:


    "???" "Эй!"


translate russian continue_after_animation_2_e7d96504:


    "???" "Ты под кайфом, что ли?"


translate russian continue_after_animation_2_c9b7ad26:


    "???" "У нас тут совещание в самом разгаре!"


translate russian continue_after_animation_2_db7f421a:


    X "Ты можешь отправиться в отделение неотложной помощи или замолчать!"


translate russian continue_after_animation_2_e3bfc7aa:


    X "Твой выбор."


translate russian continue_after_animation_2_2499868a:


    Jerold "Всё в порядке, [Sergio]."


translate russian continue_after_animation_2_6622069e:


    Jerold "Похоже, произошло недопонимание."


translate russian continue_after_animation_2_cf5dbe3c:


    Jerold "Я не знаю, о каких девушках ты говоришь, [X]."


translate russian continue_after_animation_2_e25e10d2:


    X "Только про одну, твои ребята забрали её ранее."


translate russian continue_after_animation_2_da758b72:


    X "Ты знаешь, что она моя дочь?"


translate russian continue_after_animation_2_4ef5b19c:


    Jerold "Что?! Она твоя дочь?!"


translate russian continue_after_animation_2_5d8d8d1d:


    Jerold "Я-я понятия не имел!"


translate russian continue_after_animation_2_059da465:


    X "Скажи мне, где она!"


translate russian continue_after_animation_2_404827a4:


    X "Или тебя нужно как-то убедить?"


translate russian continue_after_animation_2_53283dc9:


    Jerold "Спокойно, нам не нужно туда идти."


translate russian continue_after_animation_2_f6978aa4:


    Jerold "Она в мотеле за городом."


translate russian continue_after_animation_2_ecfe6d8a:


    Jerold "Мои ребята ждут, когда парень придёт \"спасать\" её."


translate russian continue_after_animation_2_ccb21e7d:


    X "\"Спасать\" её?"


translate russian continue_after_animation_2_bd5f85a7:


    Jerold "Они должны притвориться, что ссорятся, а он приходит и уводит её."


translate russian continue_after_animation_2_a71aaad1:


    X "А этот парень, кто он, как он выглядит?"


translate russian continue_after_animation_2_af40e094:


    Jerold "Понятия не имею, с ним договаривался мой старик."


translate russian continue_after_animation_2_0ce82736:


    Jerold "Это практически всё, что я знаю."


translate russian continue_after_animation_2_6531d3ad:


    X "Не лги мне, [Jerold]!"


translate russian continue_after_animation_2_2c37990b:


    Jerold "Клянусь, это всё!"


translate russian continue_after_animation_2_a3f7658c:


    "Этот бесхребетный придурок, вероятно, ничего не знает обо всём этом."


translate russian continue_after_animation_2_bcd0430f:


    X "Лучше бы это было так!"


translate russian continue_after_animation_2_d91b2df8:


    X "Можете продолжать."


translate russian continue_after_animation_2_397fb063:


    Sergio "Хмпф!"


translate russian continue_after_animation_2_02a4f71f:


    X "Ты знаешь, что произойдёт, если мне придется вернуться."


translate russian continue_after_animation_2_80be734a:


    Jerold "Знаю!"


translate russian continue_after_animation_2_68c241e0:


    "Это тот самый фургон."


translate russian continue_after_animation_2_4322f12c:


    "Сейчас темно, может быть, они меня не узнают."


translate russian continue_after_animation_2_7d74c547:


    "Тогда я смогу подыгрывать им во всём, что они здесь делают."


translate russian continue_after_animation_2_36f5d5f7:


    "1-й бандит" "Ты рано!"


translate russian continue_after_animation_2_657a6596:


    X "Да?"


translate russian continue_after_animation_2_3cd6013b:


    X "Ты хочешь, чтобы я подождал, или мы покончим с этим поскорее?"


translate russian continue_after_animation_2_a5c9a4c3:


    "1-й бандит" "Думаю, нет."


translate russian continue_after_animation_2_96bbd1cc:


    "1-й бандит" "Эй, просыпайся, нам есть чем заняться!"


translate russian continue_after_animation_2_7c531f8e:


    X "Она здесь?"


translate russian continue_after_animation_2_723ff350:


    "1-й бандит" "В туалете."


translate russian continue_after_animation_2_f36fd613:


    "2-й бандит" "Боже, что за штучка!"


translate russian continue_after_animation_2_addd6e45:


    "2-й бандит" "Какие великолепные изгибы!"


translate russian continue_after_animation_2_fe01ae4c:


    "2-й бандит" "Настоящее мясо вагю."


translate russian continue_after_animation_2_d8ad2e08:


    "2-й бандит" "С такими бёдрами и фигурой она чертовски хороша!"


translate russian continue_after_animation_2_87e57f7b:


    X "Я предположу, что ты просто говоришь о какой-то корове, которую хочешь трахнуть."


translate russian continue_after_animation_2_1915d3b5:


    X "Просто чтобы я не проломил тебе голову."


translate russian continue_after_animation_2_53cf569d:


    "1-й бандит" "Не обращай на него внимания, он слишком много выпил!"


translate russian continue_after_animation_2_a6539927:


    X "Как скажешь. Давайте начнём!"


translate russian continue_after_animation_2_56fcd7ba:


    "1-й бандит" "Да, конечно."


translate russian continue_after_animation_2_119d39f8:


    "1-й бандит" "Эй, кто ты, блядь, такой?"


translate russian continue_after_animation_2_09083cdf:


    "2-й бандит" "Он нарывается на драку!"


translate russian continue_after_animation_2_a0ff6cbd:


    "2-й бандит" "Получай!"


translate russian continue_after_animation_2_b6d09e58:


    "2-й бандит" "Ай! Чёрт, как больно!"


translate russian continue_after_animation_2_63ac841d:


    "1-й бандит" "Тебе не жить!"


translate russian continue_after_animation_2_0b72b6e2:


    "1-й бандит" "Дерьмо! Моё лицо!"


translate russian continue_after_animation_2_12a39223:


    "Теперь у меня есть шанс!"


translate russian continue_after_animation_2_53fdeebf:


    "1-й бандит" "Как насчёт эт--"


translate russian continue_after_animation_2_ffa79278:


    X "Ииии..."


translate russian continue_after_animation_2_75ab5c36:


    "2-й бандит" "Какого хрена?!"


translate russian continue_after_animation_2_cce80fc1:


    "2-й бандит" "Ах ты, сукин сын!"


translate russian continue_after_animation_2_2fe2cb39:


    X "...снято!"


translate russian continue_after_animation_2_e680a7ee:


    X "[D]?"


translate russian continue_after_animation_2_8cced104:


    X "Ты там?"


translate russian continue_after_animation_2_e10b9c0d:


    X "[D]!"


translate russian continue_after_animation_2_4537aea9:


    X "Потерпи, будет немного больно!"


translate russian continue_after_animation_2_7e82fc62:


    D "Ай!"


translate russian continue_after_animation_2_68288753:


    X "Сиди спокойно, пока я не разрежу!"


translate russian continue_after_animation_2_022f0ee5:


    D "Папа! Ты пришёл!"


translate russian continue_after_animation_2_73622e71:


    D "Я была так напугана!"


translate russian continue_after_animation_2_db3939fa:


    X "Конечно!"


translate russian continue_after_animation_2_fe68dee5:


    X "Я никогда не позволю им отнять тебя у меня!"


translate russian continue_after_animation_2_4c462c9a:


    X "Ты ранена?"


translate russian continue_after_animation_2_73b307e7:


    D "Нет, но у меня затекли ноги."


translate russian continue_after_animation_2_763218ee:


    X "Держись за меня."


translate russian continue_after_animation_2_e105d102:


    D "Эти люди ушли?"


translate russian continue_after_animation_2_f5015348:


    X "Тебе не нужно беспокоиться о них."


translate russian continue_after_animation_2_2524a698:


    X "Пойдём к машине."


translate russian continue_after_animation_2_6bddd200:


    X "Кто-нибудь из них прикасался к твоим интимным местам?"


translate russian continue_after_animation_2_cdc1913a:


    D "Нет, они просто много кричали."


translate russian continue_after_animation_2_ff9cce7b:


    "Думаю, тогда я не буду ломать им ноги."


translate russian continue_after_animation_2_7311b82a:


    D "Мы можем поехать домой?"


translate russian continue_after_animation_2_5bd79876:


    X "Послушай, [D], сначала мне нужно кое о чём позаботиться."


translate russian continue_after_animation_2_2f574316:


    X "Мне нужно, чтобы ты посидела в машине и вела себя тихо, пока я не вернусь."


translate russian continue_after_animation_2_d871e7dc:


    D "Я поняла."


translate russian continue_after_animation_2_ffe46b61:


    X "Хорошая девочка!"


translate russian continue_after_animation_2_ed7eb800:


    X "Я вернусь, обещаю!"


translate russian continue_after_animation_2_051fd2ad:


    "[Charlie] должна знать обо всё случившемся."


translate russian continue_after_animation_2_2aa675d1:


    Charlie "[X]?"


translate russian continue_after_animation_2_2ecad973:


    Charlie "Что такое, что-то случилось?"


translate russian continue_after_animation_2_49371592:


    X "Они похитили [D], но я вернул её."


translate russian continue_after_animation_2_2ef5fb53:


    Charlie "Что, кто её похитил?"


translate russian continue_after_animation_2_63e5ef91:


    X "За ней охотился парень, вы были правы."


translate russian continue_after_animation_2_e5e8b8e5:


    X "Я сообщу вам местоположение."


translate russian continue_after_animation_2_bedb4112:


    X "Если что-то пойдет не так, мне нужно, чтобы вы позаботились о [D]."


translate russian continue_after_animation_2_d2b57b9a:


    Charlie "Я уже в пути, но вы должны дать мне больше информации!"


translate russian continue_after_animation_2_1fa6e783:


    X "Конечно..."


translate russian continue_after_animation_2_9642fb05:


    "Если он следил за ней, то, скорее всего, знает меня."


translate russian continue_after_animation_2_3f575468:


    "И у него могут возникнуть подозрения, если я буду так одет."


translate russian continue_after_animation_2_e27498e5:


    "Отлично, сгодится."


translate russian continue_after_animation_2_b6c0a155:


    "Возможно, это тот самый парень."


translate russian continue_after_animation_2_657a6596_1:


    X "Да?"


translate russian continue_after_animation_2_baab866d:


    "???" "Открывай, это я."


translate russian continue_after_animation_2_4fa0f187:


    "???" "Раз уж ты здесь, полагаю, она у тебя."


translate russian continue_after_animation_2_07b005e7:


    X "Да-да, она прямо здесь."


translate russian continue_after_animation_2_326f2d3e:


    "???" "Вас должно было быть двое."


translate russian continue_after_animation_2_983dbda3:


    "???" "Где ещё один?"


translate russian continue_after_animation_2_d992ef38:


    X "О, он вышел отлить."


translate russian continue_after_animation_2_f58b2d81:


    "???" "Туалет не работает или что?"


translate russian continue_after_animation_2_b46af19e:


    X "Девушка там."


translate russian continue_after_animation_2_92ba222e:


    X "И ты хотел, чтобы она была жива, верно?"


translate russian continue_after_animation_2_d12a57f1:


    "???" "Она как-то ранена?"


translate russian continue_after_animation_2_9b00dd5e:


    X "Нет, может быть, просто морально."


translate russian continue_after_animation_2_90abc142:


    "???" "Это хорошо, ради твоего же блага."


translate russian continue_after_animation_2_39d40bc8:


    "???" "Ты знаешь, что теперь делать."


translate russian continue_after_animation_2_6d412a9f:


    "О, конечно, знаю."


translate russian continue_after_animation_2_34e7975d:


    X "Эй, что ты здесь делаешь?!"


translate russian continue_after_animation_2_7fc08fc1:


    X "Получай!"


translate russian continue_after_animation_2_60d64305:


    X "Аййй! Моё лицо!"


translate russian continue_after_animation_2_51b50ed3:


    X "Ух! Нет, пожалуйста, она там!"


translate russian continue_after_animation_2_d1698074:


    X "Я сдаюсь!"


translate russian continue_after_animation_2_9823348a:


    "???" "Ну всё, хватит, теперь ложись и прикинься мёртвым."


translate russian continue_after_animation_2_3360d3ee:


    "???" "[Adalinda]?"


translate russian continue_after_animation_2_ecee6057:


    John "Это [John], меня прислал твой отец!"


translate russian continue_after_animation_2_316a97da:


    John "Постой... где она?"


translate russian continue_after_animation_2_175a4085:


    X "Ой, подожди! Она..."


translate russian continue_after_animation_2_7b1a1be2:


    X "Прямо..."


translate russian continue_after_animation_2_bb7da504:


    X "Здесь!"


translate russian continue_after_animation_2_2ff66a17:


    "Посмотрим, что я смогу вытянуть из него до приезда [Charlie]."


translate russian continue_after_animation_2_a313e7aa:


    X "Встаньки-встаньки!"


translate russian continue_after_animation_2_c100f958:


    John "АААХ!!"


translate russian continue_after_animation_2_91b71573:


    John "Что, блять, ты себе позволяешь?!"


translate russian continue_after_animation_2_ff8da1be:


    John "Где девочка?"


translate russian continue_after_animation_2_a8ee9ae8:


    X "О, с ней всё в порядке."


translate russian continue_after_animation_2_4ff0f955:


    X "Но сейчас..."


translate russian continue_after_animation_2_f9726758:


    X "В первую очередь ты должен беспокоиться о себе."


translate russian continue_after_animation_2_110f2f8b:


    John "Ты!!"


translate russian continue_after_animation_2_2d03ccdf:


    John "Как ты--"


translate russian continue_after_animation_2_e0f626be:


    X "Заткнись!"


translate russian continue_after_animation_2_c0a5ef11:


    X "Вопросы задаю я!"


translate russian continue_after_animation_2_75c30b20:


    "С чего бы начать?"


translate russian continue_after_animation_2_bee00a1c:


    X "Во-первых, на кого ты работаешь?"


translate russian continue_after_animation_2_d3045aea:


    John "Думаю, ты уже догадался на кого."


translate russian continue_after_animation_2_f2642345:


    X "Тебе нужно, чтобы я снова тебя ударил?"


translate russian continue_after_animation_2_6dfdf4af:


    John "На [Radford], он поручил мне вернуть его дочь."


translate russian continue_after_animation_2_7668ce26:


    X "Кто-нибудь ещё ищет её?"


translate russian continue_after_animation_2_aee3b980:


    John "Насколько я знаю, нет."


translate russian continue_after_animation_2_7c01d15d:


    X "Как давно ты на него работаешь?"


translate russian continue_after_animation_2_68bd074c:


    John "Может, пару десятков лет."


translate russian continue_after_animation_2_eb707b48:


    X "А как насчёт этого маленького спектакля, который ты заставил разыграть этих идиотов?"


translate russian continue_after_animation_2_2e20c1c1:


    John "Устрашение лучше, чем если бы у неё были реальные неприятности."


translate russian continue_after_animation_2_172918bd:


    X "И слишком напугать её, чтобы она снова сбежала."


translate russian continue_after_animation_2_9a8dde80:


    John "Такова была моя идея."


translate russian continue_after_animation_2_eda0e74d:


    X "Отличный план, но есть одна проблема."


translate russian continue_after_animation_2_2b270f76:


    X "На самом деле она моя дочь."


translate russian continue_after_animation_2_3e9aaa28:


    John "О чём ты говоришь?"


translate russian continue_after_animation_2_dd8e738a:


    "Похоже, он не знает о дневнике [Emily]."


translate russian continue_after_animation_2_ec307201:


    X "Её мать, девушка, которую они удочерили. Ты знаешь о ней?"


translate russian continue_after_animation_2_d96d6f9e:


    John "Как там её звали... [Emily]."


translate russian continue_after_animation_2_cfb0f3fa:


    X "Именно так. Где она сейчас?"


translate russian continue_after_animation_2_0e1aa622:


    John "Она... умерла."


translate russian continue_after_animation_2_a3a7ef9d:


    X "Что?! Когда?"


translate russian continue_after_animation_2_339b74d0:


    John "Прошло уже более десяти лет."


translate russian continue_after_animation_2_15192e4e:


    John "С ней произошёл несчастный случай, она упала с лестницы."


translate russian continue_after_animation_2_3240dd8f:


    X "Я тебе не верю!"


translate russian continue_after_animation_2_e796c00b:


    John "Я знаю только то, что [Radford] сказал мне."


translate russian continue_after_animation_2_e62abf8a:


    John "Сказал, что пыталась сбежать вместе с дочерью."


translate russian continue_after_animation_2_910dc5c8:


    John "Они боролись и она упала, а когда приехала скорая, было уже слишком поздно."


translate russian continue_after_animation_2_42a2a19a:


    X "Разве?"


translate russian continue_after_animation_2_750322a0:


    X "Он бы не доверил тебе вернуть её, если бы ты не был по уши в этом деле."


translate russian continue_after_animation_2_0e92df92:


    John "Слушай, это просто бизнес."


translate russian continue_after_animation_2_a1a6b654:


    John "Мы начали работать, когда он позвонил мне, чтобы рассказать историю своей семьи."


translate russian continue_after_animation_2_3c7bacfa:


    X "Зачем?"


translate russian continue_after_animation_2_460c7c15:


    John "После того, как они узнали, что [Emily] беременна, они хотели избежать скандала."


translate russian continue_after_animation_2_7cf2b43e:


    John "[Radford] сказал мне, что это его ребенок, так что я не понимаю, почему ты думаешь, что она твоя дочь."


translate russian continue_after_animation_2_c5681071:


    "Теперь мне действительно нужно достать этот дневник."


translate russian continue_after_animation_2_b30cf5f5:


    X "Просто так."


translate russian continue_after_animation_2_29b58ae5:


    X "И почему она попыталась сбежать?"


translate russian continue_after_animation_2_6ade8e2b:


    John "Он утверждал, что у неё проблемы с психикой."


translate russian continue_after_animation_2_61854727:


    X "Полная чушь!"


translate russian continue_after_animation_2_eec0257b:


    X "И ты, блять, просто веришь в это?"


translate russian continue_after_animation_2_537a3c9a:


    John "Мне заплатили за моё благоразумие, поэтому я не стал настаивать на этом вопросе."


translate russian continue_after_animation_2_4eec1ae2:


    X "У меня такое чувство, что ты чего-то недоговариваешь."


translate russian continue_after_animation_2_19a27200:


    John "Эй, смотри, всё записано!"


translate russian continue_after_animation_2_20cef9cf:


    John "Просто посмотри после того, как детектив это рассекретит."


translate russian continue_after_animation_2_5ae23476:


    X "Откуда ты об этом знаешь?"


translate russian continue_after_animation_2_5ad614f9:


    John "Не могу сказать."


translate russian continue_after_animation_2_ba3f2e54:


    X "Ты уверен в этом?"


translate russian continue_after_animation_2_ef607fa0:


    John "Бей меня, сколько хочешь, но это ничего не даст."


translate russian continue_after_animation_2_20a330f7:


    "Может быть, у него есть кто-то внутри или, может быть, какой-нибудь хакер."


translate russian continue_after_animation_2_6262975d:


    X "Тебе повезло, что у меня нет на это времени."


translate russian continue_after_animation_2_c80f5405:


    Charlie "Я рядом с этим местом. Где вы?"


translate russian continue_after_animation_2_8374e10f:


    X "В мотеле, встретимся у входа."


translate russian continue_after_animation_2_59fd3f92:


    X "Я вас вижу."


translate russian continue_after_animation_2_d9131e7b:


    Charlie "Что это на вас?"


translate russian continue_after_animation_2_e4bf8673:


    X "Мне нужна была маскировка."


translate russian continue_after_animation_2_4ee1bd64:


    Charlie "Расскажите мне, что произошло."


translate russian continue_after_animation_2_36ff0116:


    X "Мы вышли из кинотеатра после просмотра фильма."


translate russian continue_after_animation_2_506cdd96:


    X "Я отвернулся и они просто схватили её..."


translate russian continue_after_animation_2_505c5335:


    Charlie "Откуда вы знали, где найти [Jerold]?"


translate russian continue_after_animation_2_ba802829:


    X "На прошлой неделе до меня дошли слухи."


translate russian continue_after_animation_2_8b3091a0:


    "Не нужно втягивать [Khalil] в это."


translate russian continue_after_animation_2_2a6abde1:


    Charlie "Ну, мне придётся их забрать."


translate russian continue_after_animation_2_a0901d6f:


    Charlie "И за [D] могут прийти другие."


translate russian continue_after_animation_2_887494a6:


    X "Да."


translate russian continue_after_animation_2_e5a706fe:


    Charlie "А раз он знает о вас, возвращаться домой небезопасно."


translate russian continue_after_animation_2_3939264c:


    Charlie "Вы можете пойти ко мне."


translate russian continue_after_animation_2_3d91ef79:


    X "Он также знал о вас, так что они могут попробовать и там."


translate russian continue_after_animation_2_4485b956:


    X "Я найду отель, это лучший вариант."


translate russian continue_after_animation_2_04cc205a:


    Charlie "Хорошо, снимите комнату и мы встретимся там."


translate russian continue_after_animation_2_3a98d18c:


    X "...так что мы остановимся здесь на некоторое время."


translate russian continue_after_animation_2_be3a059b:


    X "Иди пока отдохни."


translate russian continue_after_animation_2_f9243d7d:


    "Только одна кровать?"


translate russian continue_after_animation_2_b8267645:


    "И что это за ванная комната такая?"


translate russian continue_after_animation_2_298226ee:


    "Ресепшен" "Стойка регистрации. Чем я могу вам помочь?"


translate russian continue_after_animation_2_6b9abff0:


    X "У вас есть другие комнаты, может быть, с двумя кроватями?"


translate russian continue_after_animation_2_112250fe:


    "Ресепшен" "Нам очень жаль, сэр, но все номера на сегодня полностью заняты."


translate russian continue_after_animation_2_d854006c:


    "Чёрт, я уже сказал [Charlie] об этом месте."


translate russian continue_after_animation_2_f121cfac:


    "Нужно просто пережить сегодняшний вечер."


translate russian continue_after_animation_2_2cb6c30d:


    X "Понятно, ничего страшного."


translate russian continue_after_animation_2_72c74c5c:


    "Ресепшен" "Я ещё раз прошу прощения, сэр. Хотите что-нибудь ещё?"


translate russian continue_after_animation_2_454bd57e:


    X "Всё в порядке."


translate russian continue_after_animation_2_e7b8540c:


    D "**Сопит**"


translate russian continue_after_animation_2_14710424:


    X "[D], в чём дело?"


translate russian continue_after_animation_2_5b2ebd17:


    X "Что-то болит?"


translate russian continue_after_animation_2_7d6dcdca:


    D "Нет..."


translate russian continue_after_animation_2_e3bc979b:


    D "Всё это произошло из-за меня."


translate russian continue_after_animation_2_d3dbb61e:


    D "Если бы я не сбежала..."


translate russian continue_after_animation_2_e6f35156:


    X "Не говори так!"


translate russian continue_after_animation_2_475c92c8:


    X "Ты не можешь винить себя за то, что они сделали!"


translate russian continue_after_animation_2_de65ce56:


    D "Но тебе пришлось драться с этими подлыми людьми."


translate russian continue_after_animation_2_8fd85053:


    D "Ты мог сильно пострадать, и всё из-за меня."


translate russian continue_after_animation_2_82b3225c:


    X "Послушай, [D]..."


translate russian continue_after_animation_2_6033756d:


    X "Да, я мог заработать несколько синяков."


translate russian continue_after_animation_2_a7fa9d76:


    X "Но это никогда не помешает мне защищать тебя."


translate russian continue_after_animation_2_41731df7:


    X "Что бы ни случилось, я не откажусь от тебя!"


translate russian continue_after_animation_2_8ad10eac:


    D "Я просто не хочу, чтобы тебе было больно, папочка!"


translate russian continue_after_animation_2_f6a20328:


    X "Эй, не волнуйся об этом."


translate russian continue_after_animation_2_39e937e8:


    X "Я крепче, чем кажусь, поверь мне!"


translate russian continue_after_animation_2_23ba7b9b:


    X "А теперь иди, готовься ко сну, уже действительно поздно."


translate russian continue_after_animation_2_1ddb325e:


    D "Да, папочка."


translate russian continue_after_animation_2_ed602bd3:


    D "И я надеюсь, что мы найдем маму и сможем жить все вместе."


translate russian continue_after_animation_2_29e8b645:


    X "Да, я тоже..."


translate russian continue_after_animation_2_f80695bb:


    Charlie "Я принесла вам кое-какие припасы и одежду для [D]."


translate russian continue_after_animation_2_50ac8e30:


    X "Спасибо."


translate russian continue_after_animation_2_ac680254:


    X "Что будет с тем парнем, [John]?"


translate russian continue_after_animation_2_0f730574:


    Charlie "Я могу задержать его в связи с делом [Emily]."


translate russian continue_after_animation_2_2a9ac959:


    Charlie "Но нам нужно повременить с тем, чтобы считать вас отцом [D]."


translate russian continue_after_animation_2_d3e70bba:


    Charlie "По крайней мере, пока у нас не будет доказательств для суда."


translate russian continue_after_animation_2_173d7a8c:


    X "Отцовство скоро будет установлено."


translate russian continue_after_animation_2_3b97f7cb:


    Charlie "Это и всё остальное, что мы сможем доказать."


translate russian continue_after_animation_2_f0a443da:


    X "Я посмотрю, что можно сделать."


translate russian continue_after_animation_2_686147a2:


    Charlie "Не выходите из отеля, держитесь здесь."


translate russian continue_after_animation_2_4d63f0d3:


    X "Конечно."


translate russian continue_after_animation_2_59486bb1:


    Charlie "Кроме того, это был травмирующий опыт для [D]."


translate russian continue_after_animation_2_ba570c30:


    Charlie "Сейчас ей нужна вся ваша поддержка."


translate russian continue_after_animation_2_dc751bfd:


    X "Я знаю."


translate russian continue_after_animation_2_3364cc42:


    Charlie "А если вам что-то понадобится, оставьте сообщение на стойке регистрации, я приду и прочитаю."


translate russian continue_after_animation_2_099b3efb:


    X "Понял."


translate russian continue_after_animation_2_da9d8f4f:


    X "И благодарю вас!"


translate russian continue_after_animation_2_92338fab:


    D "Эммм, папа?"


translate russian continue_after_animation_2_3dd6d314:


    X "Да, [D]!"


translate russian continue_after_animation_2_fca2b294:


    D "У меня здесь нет мыла, можешь принести?"


translate russian continue_after_animation_2_8811a474:


    X "Здесь есть и шампунь."


translate russian continue_after_animation_2_d2b48823:


    D "Спасибо."


translate russian continue_after_animation_2_064fec63:


    X "[Charlie] принесла тебе кое-какую одежду, я оставлю её здесь."


translate russian continue_after_animation_2_beec3fc5:


    D "Хорошо."


translate russian continue_after_animation_2_ab8aeefe:


    "Эти ублюдки так просто не сдадутся."


translate russian continue_after_animation_2_fdc67ecb:


    "Похоже, мне предстоит драка."


translate russian continue_after_animation_2_ec29b3f0:


    D "Они здесь?"


translate russian continue_after_animation_2_e0bf2cd8:


    X "Что?"


translate russian continue_after_animation_2_5f550c6b:


    D "Ничего, нашла их!"


translate russian continue_after_animation_2_4c5fb734:


    "Господи, для чего они проектировали эту комнату?"


translate russian continue_after_animation_2_9891ee33:


    D "Я всё."


translate russian continue_after_animation_2_19ec8b31:


    X "Как температура?"


translate russian continue_after_animation_2_68f528cc:


    D "Мне тепло."


translate russian continue_after_animation_2_34ffe490:


    X "У нас тут есть несколько одеял. Накинь одно, если станет прохладно."


translate russian continue_after_animation_2_4897db84:


    X "А теперь постарайся немного отдохнуть."


translate russian continue_after_animation_2_0fa5c482:


    D "Ты будешь спать со мной?"


translate russian continue_after_animation_2_813f87c2:


    X "Здесь есть только одна кровать."


translate russian continue_after_animation_2_38563062:


    X "Но я могу лечь на пол."


translate russian continue_after_animation_2_822209e5:


    D "Нет, пожалуйста, не уходи!"


translate russian continue_after_animation_2_b285f0e3:


    X "Что ж, если ты настаиваешь."


translate russian continue_after_animation_2_b064c4d5:


    X "Спокойной ночи, [D]."


translate russian continue_after_animation_2_5bfca034:


    D "Спокойной ночи, папочка."


translate russian continue_after_animation_2_b064c4d5_1:


    X "Спокойной ночи, [D]."


translate russian continue_after_animation_2_5bfca034_1:


    D "Спокойной ночи, папочка."


translate russian continue_after_animation_2_b1fb60d3:


    D "Мммм..."


translate russian continue_after_animation_2_3f529e8e:


    X "[D], ты--"


translate russian continue_after_animation_2_1b323a3d:


    X "Стоп, что это за чувство?"


translate russian ep3_hotel_grind_intro_71904ab9:


    X "А?!"


translate russian ep3_hotel_grind_intro_af95c5c7:


    "Чёрт, я сплю?"


translate russian ep3_hotel_grind_intro_406344f1:


    "Даже если это сон, я должен остановить его."


translate russian ep3_hotel_grind_intro_af5ee6df:


    "Что делать..."


translate russian ep3_hotel_grind_intro_c5144754:


    "Я не хочу рисковать, чтобы она проснулась и увидела это."


translate russian ep3_hotel_grind_intro_d21fb6c5:


    "Я постараюсь потихоньку выбраться--"


translate russian ep3_hotel_grind_intro_172f3cca:


    X "Ох!"


translate russian ep3_hotel_grind_intro_6c8b64f4:


    "Это плохо!"


translate russian ep3_hotel_grind_intro_85455aac:


    "Надо что-то с этим сделать."


translate russian continue_after_animation_3_9ed25bba:


    "Дерьмо, я не могу это остановить!"


translate russian continue_after_animation_3_b2a622aa:


    "Я должен--"


translate russian continue_after_animation_3_47e7e2ab:


    X "Угхх!"


translate russian continue_after_animation_3_9893a8fe:


    "Что я наделал..."


translate russian ep3_turn_around_cc51b99c:


    "Это было близко."


translate russian ep3_turn_around_edb67377:


    "Сейчас я мог допустить ошибку..."

translate russian strings:


    old "Hide (H)"
    new "Скрыть (H)"


    old "Chick flick"
    new "Плаксивая мелодрама"


    old "Comedy"
    new "Комедия"


    old "Sci-Fi Horror"
    new "Научно-фантастический хоррор"


    old "Action"
    new "Экшен"


    old "Relieve yourself"
    new "Облегчиться"


    old "Just wash the clothes"
    new "Просто постирать одежду"


    old "Go back to work"
    new "Вернуться к работе"


    old "Tell them off"
    new "Отчитать их"


    old "Celebrate BirthYear"
    new "Отпраздновать год рождения"


    old "Celebrate NameDay"
    new "Отпраздновать именины"


    old "Let her help"
    new "Позволить ей помочь"


    old "No need"
    new "Не нужно"


    old "Kiss her cheek"
    new "Поцеловать её в щёку"


    old "Kiss her forehead"
    new "Поцеловать её в лоб"


    old "Stay still"
    new "Не шевелиться"


    old "Quicky turn around"
    new "Быстро обернуться"


    old "To be continued..."
    new "Продолжение следует..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
