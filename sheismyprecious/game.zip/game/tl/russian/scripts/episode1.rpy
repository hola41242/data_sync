
translate russian strings:

    old "What is your name?"
    new "Как вас зовут?"

    old "Emsy"
    new "Эмси"

    old "Episode 1"
    new "Эпизод 1"

    old "An Old Hope"
    new "Старая надежда"


translate russian ep1_01_dream_3874842e:


    X "Тебе не обязательно уходить."


translate russian ep1_01_dream_d49a4d93:


    X "Мы просто можем сбежать!"


translate russian ep1_01_dream_0740ee27:


    Emily "Это последний год для нас."


translate russian ep1_01_dream_2034bb45:


    Emily "Если мы уйдём сейчас, то о поступлении в университет не может быть и речи."


translate russian ep1_01_dream_609f6f3f:


    Emily "Кроме того, ты обещал, что в этом году займёшь первое место."


translate russian ep1_01_dream_c6ff5e0d:


    X "А как насчёт тебя?"


translate russian ep1_01_dream_73956e0a:


    Emily "Они сказали, что это действительно хорошая школа."


translate russian ep1_01_dream_585d20b5:


    Emily "Я могу получить всё, что мне нужно, так что всё в порядке."


translate russian ep1_01_dream_9ac6a703:


    X "Это хорошо."


translate russian ep1_01_dream_05dcf7c7:


    Emily "Мы можем встретиться здесь следующим летом. В этом же месте."


translate russian ep1_01_dream_8f01c937:


    X "В это же время."


translate russian ep1_01_dream_4d829df8:


    Emily "Договорились."


translate russian ep1_01_dream_e10bce07:


    X "Я буду ждать тебя здесь."


translate russian ep1_01_dream_0b0e6e2d:


    X "Эй, тебе не кажется, что сегодня жарче?"


translate russian ep1_01_dream_8c0b4421:


    Emily "Немного. Хочешь пойти искупаться?"


translate russian ep1_01_dream_57815ff5:


    X "Что у тебя там под купальником?"


translate russian ep1_01_dream_e17a378b:


    Emily "Ничего..."


translate russian ep1_01_dream_7e73c71a:


    X "Тебе... нужно немного пространства?"


translate russian ep1_01_dream_e17a378b_1:


    Emily "Нет..."


translate russian ep1_01_dream_d6058f6a:


    Emily "Я не против."


translate russian ep1_01_dream_718fb7b3:


    Emily "Хочешь посмотреть?"


translate russian ep1_01_dream_03d4a9ac:


    X "Я... да. Хочу!"


translate russian ep1_01_dream_bf9b1140:


    X "Эмили."


translate russian ep1_01_dream_ef0ee5ca:


    Emily "Да?"


translate russian ep1_01_dream_c6564de5:


    X "Это наш последний день."


translate russian ep1_01_dream_f25e2306:


    X "Мы не увидимся ещё долгое время."


translate russian ep1_01_dream_32f3545c:


    Emily "Да..."


translate russian ep1_01_dream_3dda9473:


    Emily "Тогда мы должны извлечь из него максимум пользы."


translate russian ep1_01_dream_4b368dab:


    X "Согласен!"


translate russian ep1_01_dream_749d1115:


    Emily "Ты можешь помочь мне..."


translate russian ep1_01_dream_57c00b31:


    "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}💕💋💞{/font}"


translate russian ep1_01_dream_6c143454:


    Emily "Ты стал лучше в этом!"


translate russian ep1_01_dream_5d20bd94:


    X "Я практиковался."


translate russian ep1_01_dream_b20db10b:


    Emily "Правда? Как?"


translate russian ep1_01_dream_bf02b35c:


    X "С тобой, в своих мечтах..."


translate russian ep1_01_dream_ad7a7236:


    X "Я ввожу медленно, скажи, если будет больно."


translate russian ep1_01_dream_d5328e3f:


    Emily "Продолжай."


translate russian ep1_01_dream_4862ab17:


    Emily "Ааа!"


translate russian ep1_01_dream_1993c876:


    Emily "Задержись так на мгновение..."


translate russian ep1_01_dream_67384d82:


    Emily "...теперь стало лучше."


translate russian ep1_01_dream_966f50d0:


    X "Я продолжаю!"


translate russian ep1_01_dream_8c0a108c:


    Emily "Вот так! Да!"


translate russian ep1_01_dream_68488c5a:


    X "Мне так хорошо, [Emily]!"


translate russian ep1_01_dream_ef62569a:


    X "Я уже близко."


translate russian ep1_01_dream_647408f4:


    Emily "Я хочу кончить одновременно с тобой, [X]."


translate russian ep1_01_dream_873a7261:


    Emily "Так что не останавливайся!"


translate russian ep1_01_dream_69115b64:


    X "[Emily]..."


translate russian ep1_01_dream_159a94c5:


    X "Слишком хорошо!"


translate russian ep1_01_dream_a9a63983:


    X "Я хочу отдать тебе её всю, [Emily]!"


translate russian ep1_01_dream_52f7e5b8:


    Emily "Я вся твоя, [X]!"


translate russian ep1_01_dream_83f5a149:


    X "[Emily]!"


translate russian ep1_01_dream_7fe428f5:


    Emily "[X]!"


translate russian ep1_01_dream_5d9e2527:


    Emily "Я чувствую её всю!"


translate russian ep1_01_dream_30b5adcf:


    X "Мне нужно тебе кое-что сказать."


translate russian ep1_01_dream_abff5250:


    X "Я давно хотел это сказать."


translate russian ep1_01_dream_9fb95760:


    Emily "Сказать что?"


translate russian ep1_01_dream_04794e48:


    Emily "{cps=0}Сказать что?" nointeract


translate russian ep1_01_dream_35cb1b77:


    X "Я хочу, чтобы ты знала, что я--"


translate russian ep1_01_dream_e25ad233:


    X "Я люблю тебя, Эмили!"


translate russian ep1_01_dream_65f9ee34:


    X "Ты знаешь!"


translate russian ep1_01_dream_1e5bb1ee:


    Emily "Я не. Что это?"


translate russian ep1_01_dream_7c10ca7c:


    X "Это..."


translate russian ep1_01_dream_ce51b5cf:


    X "Который час?"


translate russian ep1_01_dream_5c7ce1fa:


    X "И кто мне звонит?"


translate russian ep1_01_dream_a9dc9eb3:


    X "Алло?"


translate russian ep1_01_dream_074a3ef7:


    Maya "Доброе утро, [X], это [Maya] из детского дома."


translate russian ep1_01_dream_feb6ca03:


    X "[Maya], да, доброе утро!"


translate russian ep1_01_dream_408c101e:


    Maya "Несколько дней назад мы с вами говорили о том, что нам нужно."


translate russian ep1_01_dream_01df64f8:


    X "Помню. Что-то появилось?"


translate russian ep1_01_dream_7f24f74a:


    Maya "Вы упомянули репетиторство в качестве одной из работ."


translate russian ep1_01_dream_617c97ad:


    X "Верно. Но сначала мне нужно привести себя в порядок."


translate russian ep1_01_dream_d4fb4aef:


    Maya "Конечно. Есть 2 девочки, которые нуждаются в помощи."


translate russian ep1_01_dream_e36b9451:


    Maya "Дело в математике, если вы преподаёте на достаточно продвинутом уровне."


translate russian ep1_01_dream_33271e0a:


    X "Об насколько продвинутом уровне мы говорим?"


translate russian ep1_01_dream_db662cfd:


    Maya "Об уровне национальной олимпиады."


translate russian ep1_01_dream_ddaa982c:


    Maya "Она выиграла несколько национальных соревнований."


translate russian ep1_01_dream_b0c7f5a3:


    X "Понятно. Если дело только в математике, то это вполне осуществимо."


translate russian ep1_01_dream_12e7e620:


    Maya "Я не хочу, чтобы это доставляло вам слишком много хлопот."


translate russian ep1_01_dream_b8d68cb6:


    X "Если всего две ученицы, то всё будет в порядке."


translate russian ep1_01_dream_3db11009:


    Maya "Я подумала о вашей профессии. Инженерия данных, верно?"


translate russian ep1_01_dream_36f85856:


    X "Да."


translate russian ep1_01_dream_b9134ba8:


    Maya "Вы регулярно применяете навыки математики, да?"


translate russian ep1_01_dream_76715d75:


    X "Верно. Так что это как раз по моей части."


translate russian ep1_01_dream_c29eb0ec:


    Maya "Итак, можем ли мы прийти сегодня днем?"


translate russian ep1_01_dream_e515079c:


    X "Конечно."


translate russian ep1_01_dream_9ae33d12:


    Maya "Отлично! Тогда ждите нас."


translate russian ep1_01_dream_5b37f757:


    "Снова тот же сон."


translate russian ep1_01_dream_7e18f326:


    "До сих пор не могу вспомнить её лицо..."


translate russian ep1_01_dream_09105b17:


    "Тот же сон в тот же день."


translate russian ep1_01_dream_f12cc627:


    "Возможно, они что-то нашли о ней."


translate russian ep1_01_dream_8c351382:


    "Скорее всего, нет."


translate russian ep1_01_dream_8851854e:


    "[Charlie] позвонила бы, если бы что-нибудь случилось..."


translate russian ep1_01_dream_73c736d3:


    "Конечно, он пустой, я здесь почти не живу."


translate russian ep1_01_dream_2584b393:


    "Этого должно хватить примерно на неделю."


translate russian ep1_01_dream_906d84fb:


    "По крайней мере, кофе здесь в достатке."


translate russian ep1_01_dream_296144e8:


    "Нужно проверить письма за 3 прошедших дня. Перейду к делу."


translate russian ep1_01_dream_daa247e1:


    "Система не работает?"


translate russian ep1_01_dream_3c0608ff:


    "К чёрту! Я проверю их позже."


translate russian ep1_01_dream_3b84a35e:


    John "Да?"


translate russian ep1_01_dream_bf10b31a:


    X "Привет, Джон. Как дела на базе, сбоев нет?"


translate russian ep1_01_dream_cafeec82:


    X "Я не могу войти в систему."


translate russian ep1_01_dream_269dab59:


    John "[X], ты ещё не слышал?!"


translate russian ep1_01_dream_25650a08:


    X "Слышал что?"


translate russian ep1_01_dream_cdc8626e:


    John "Новый владелец уволил весь отдел!"


translate russian ep1_01_dream_f3875f07:


    X "Ты издеваешься надо мной."


translate russian ep1_01_dream_2586049e:


    John "Прочти почту, чувак."


translate russian ep1_01_dream_37115bf9:


    X "Почта пуста."


translate russian ep1_01_dream_9d4e5d64:


    John "Корпоративную почту."


translate russian ep1_01_dream_b0509ce9:


    X "Я не могу войти в систему, потому что меня заблокировали!"


translate russian ep1_01_dream_52426860:


    John "Ах да."


translate russian ep1_01_dream_3738f060:


    John "Тогда я пришлю тебе копию."


translate russian ep1_01_dream_f4edd66f:


    X "Спасибо. Ты был там, когда это случилось?"


translate russian ep1_01_dream_48491ba0:


    John "Ага. Он вызвал нас на брифинг."


translate russian ep1_01_dream_332596f0:


    John "Произнёс речь на 2 минуты и велел всем навести порядок на своих столах."


translate russian ep1_01_dream_0defbe91:


    X "Какого хрена он всех уволил?"


translate russian ep1_01_dream_d9cd68c4:


    John "Я правда не знаю. Он говорил о \"замораживании персиков\" или что-то в этом роде."


translate russian ep1_01_dream_b030895a:


    X "Чего?!"


translate russian ep1_01_dream_d5f85c12:


    John "Я не знаю. В любом случае, мой адвокат сказал, что это лёгкий иск."


translate russian ep1_01_dream_dacb39a1:


    John "Вот и всё."


translate russian ep1_01_dream_500d72d9:


    X "Не сомневаюсь."


translate russian ep1_01_dream_72649d71:


    John "Хотя я уже определился с новой работой."


translate russian ep1_01_dream_71265a20:


    X "Блин, не теряешь ни секунды!"


translate russian ep1_01_dream_aaf3e746:


    John "Я подумал, что это может случиться, раз многие уходят. Так что я был готов к этому."


translate russian ep1_01_dream_d192347b:


    John "Если тебе нужна работа, я могу поговорить с другом."


translate russian ep1_01_dream_16491f63:


    X "Спасибо, я подумаю об этом."


translate russian ep1_01_dream_4be4e034:


    John "Что ж, мне нужно идти. Увидимся!"


translate russian ep1_01_dream_6588b065:


    X "Береги себя, парень."


translate russian ep1_01_dream_be668c43:


    "Пожалуй, продлю отпуск..."


translate russian ep1_01_dream_55ddeb84:


    "Вау, на этот раз ежевичное варенье!"


translate russian ep1_01_dream_d7535597:


    "Не могу найти соус, но это будет повкуснее."


translate russian ep1_01_dream_742012b9:


    "Сахар пригодится, если соус окажется слишком кислым."


translate russian ep1_01_dream_deafb577:


    "Не помешает немного риса."


translate russian ep1_01_dream_81c79af5:


    "[Eileen] никогда бы мне не простила, если бы я взял хлеб где-нибудь в другом месте."


translate russian ep1_01_dream_65ead6ea:


    "Нет, у меня есть время для готовки, не нуждаюсь в готовой еде."


translate russian ep1_01_dream_553430b1:


    "Картошка, лук и кое-что ещё..."


translate russian ep1_01_dream_0b7f1812:


    "???" "Эй, у нас тут подозрительный тип!"


translate russian ep1_01_dream_67c03dec:


    "???" "Думаю, он может быть бездомным."


translate russian ep1_01_dream_3a0fb633:


    X "Привет, Халил!"


translate russian ep1_01_dream_24406bad:


    Khalil "[X]?! Чёрт, я тебя не узнал, бро!"


translate russian ep1_01_dream_08c51b71:


    Khalil "Ты всё ещё ходишь в этих бомжатских шмотках."


translate russian ep1_01_dream_a6afddf5:


    X "И это говорит тип в одежде для подростков, которые ещё в школу ходят?"


translate russian ep1_01_dream_77be11eb:


    X "У тебя есть удостоверение личности? Иначе они не позволят тебе купить это пиво."


translate russian ep1_01_dream_bd339a28:


    Khalil "Чувак, каково это, когда тебе каждый раз говорят убираться из этих шикарных магазинов?"


translate russian ep1_01_dream_bc7191a8:


    X "Держу пари, тебя остановят и спросят, почему ты прогуливаешь школу."


translate russian ep1_01_dream_6dfce30f:


    Khalil "Эй, разносчик пиццы даёт ТЕБЕ чаевые?"


translate russian ep1_01_dream_678309d9:


    X "Хаха! Пойдём, парень."


translate russian ep1_01_dream_c7db18f8:


    X "Не рановато ли пить?"


translate russian ep1_01_dream_7942e86a:


    Khalil "Хочу отдохнуть после тренировки."


translate russian ep1_01_dream_868299da:


    Khalil "У меня пара матчей в следующем месяце."


translate russian ep1_01_dream_36169fd1:


    Khalil "Так что каждый день мне приходится оттачивать свою форму."


translate russian ep1_01_dream_b2640c3d:


    X "Ну, в конце концов, ты стал профессионалом."


translate russian ep1_01_dream_62b11bd7:


    Khalil "Да. И я должен поблагодарить этих ублюдков."


translate russian ep1_01_dream_1569e76e:


    X "У тебя были проблемы с ними в последнее время?"


translate russian ep1_01_dream_3c278490:


    Khalil "Нет, давненько их уже не видел."


translate russian ep1_01_dream_15b1fdc8:


    Khalil "В любом случае, я собираюсь пройтись за хот-догом. Хочешь со мной?"


translate russian ep1_01_dream_993e4099:


    X "Вообще-то да, я ещё не завтракал."


translate russian ep1_01_dream_54bfb293:


    Khalil "Эх ты, бедный сукин сын! Пойдём, я угощаю."


translate russian ep1_01_dream_3c849ffb:


    Khalil "Значит, он уволил вас всех?!"


translate russian ep1_01_dream_2157453a:


    X "Весь отдел."


translate russian ep1_01_dream_bf1c7890:


    Khalil "Чёртов мудак! Мне никогда не нравился этот парень."


translate russian ep1_01_dream_c589c4a0:


    X "Может, так даже лучше."


translate russian ep1_01_dream_c6c2a7af:


    Khalil "Почему?"


translate russian ep1_01_dream_3a06bbdd:


    X "Теперь у меня больше времени на размышления. Может, займусь чем-нибудь другим."


translate russian ep1_01_dream_9f173b48:


    Khalil "Не сдавайся, главное! Ты справишься."


translate russian ep1_01_dream_cd3e4aec:


    Jimmy "Как дела, чуваки?"


translate russian ep1_01_dream_bc76f790:


    Khalil "Просто делаю доброе дело на сегодня."


translate russian ep1_01_dream_d3a8ea10:


    Khalil "Кормлю голодного."


translate russian ep1_01_dream_dd894fa5:


    X "Да, этот парень - настоящий благородный гражданин!"


translate russian ep1_01_dream_bd87e89a:


    Jimmy "Добавить горчицу, верно, [X]?"


translate russian ep1_01_dream_c75779cb:


    X "Ты меня знаешь!"


translate russian ep1_01_dream_c7e8f112:


    Khalil "Больше горчицы!"


translate russian ep1_01_dream_c8aca5d1:


    Jimmy "Понял тебя!"


translate russian ep1_01_dream_6e6c98e7:


    Jimmy "Хорошего дня!"


translate russian ep1_01_dream_e0a5e0f4:


    X "Спасибо, [Jimmy]!"


translate russian ep1_01_dream_393b1002:


    X "Наконец-то ты попал в высшую лигу, парень."


translate russian ep1_01_dream_2b536d65:


    Khalil "Не могу остановиться, пока не окажусь на вершине!"


translate russian ep1_01_dream_a8155745:


    Khalil "А ты, наоборот, размягчал."


translate russian ep1_01_dream_e055ab94:


    Khalil "Тусуешься со всеми этими технарями-ботаниками."


translate russian ep1_01_dream_d2d6bb29:


    X "О чём ты блять говоришь?"


translate russian ep1_01_dream_1738874d:


    X "Похоже, тебе нужно напомнить о том, на что я способен."


translate russian ep1_01_dream_f2f0d413:


    Khalil "Хохохо!"


translate russian ep1_01_dream_43f7f00a:


    Khalil "Как я уже сказал, я буду ходить в спортзал каждый день."


translate russian ep1_01_dream_4d6a4cd0:


    Khalil "Так что не стесняйся заходить и... освежать мне память."


translate russian ep1_01_dream_a694d67c:


    X "Эй, не волнуйся, я не буду слишком усердствовать."


translate russian ep1_01_dream_7cf95adc:


    X "Не хочу, чтобы ты получил травму перед матчем."


translate russian ep1_01_dream_5d00c6ad:


    Khalil "Ты просто беспокоишься о своей силиконовой заднице."


translate russian ep1_01_dream_fbe2ae5b:


    Khalil "В любом случае, пора идти."


translate russian ep1_01_dream_25703f70:


    Khalil "Люблю тебя, мужик."


translate russian ep1_01_dream_c9f5a398:


    X "И я тебя."


translate russian ep1_01_dream_496efb48:


    Eileen "Сейчас подойду!"


translate russian ep1_01_dream_6926ad3b:


    Eileen "Так, так, так!"


translate russian ep1_01_dream_7cb7cdef:


    X "Давненько не виделись, [Eileen]. Как дела?"


translate russian ep1_01_dream_eda0837f:


    Eileen "Не жалуюсь."


translate russian ep1_01_dream_881fa617:


    Eileen "Присаживайся, я сейчас подойду."


translate russian ep1_01_dream_56bdc7b0:


    Eileen "Хочешь кофе?"


translate russian ep1_01_dream_1604b723:


    X "Нет, спасибо."


translate russian ep1_01_dream_7983519f:


    Eileen "Итак, чем ты занимался с прошлого года?"


translate russian ep1_table_chat_176d8531:


    X "В основном был занят работой."


translate russian ep1_table_chat_5d30556f:


    Eileen "Всегда работаешь. Ты едва успеваешь навещать меня!"


translate russian ep1_table_chat_3b9fd033:


    X "Если тебе станет легче, я теперь безработный."


translate russian ep1_table_chat_80459c34:


    X "Так что у меня будет больше времени для тебя."


translate russian ep1_table_chat_92dfac98:


    Eileen "Как это произошло?"


translate russian ep1_table_chat_43f4ec26:


    Eileen "Ты ни с кем не дрался?"


translate russian ep1_table_chat_ad70aeb1:


    X "Да ладно!"


translate russian ep1_table_chat_d317da6f:


    X "Так вот каким ты меня видишь, каким-то жестоким головорезом?"


translate russian ep1_table_chat_5f208b2a:


    Eileen "Среди прочего."


translate russian ep1_table_chat_ebc23a88:


    Eileen "Как ты до этого дошёл?"


translate russian ep1_table_chat_c51cec98:


    X "Я не совсем уверен. Думаю, просто не понравился новому боссу."


translate russian ep1_table_chat_7bac9509:


    Eileen "И это всё?"


translate russian ep1_table_chat_8218579e:


    X "В электронном письме не упоминалось о каких-либо жалобах на мою работу или о чём-то ещё."


translate russian ep1_table_chat_c104fd22:


    Eileen "По-моему, это похоже на незаконное увольнение. Ты должен подать в суд."


translate russian ep1_table_chat_9faacdf6:


    X "Возможно, ты права."


translate russian ep1_table_chat_22495115:


    Eileen "Есть ещё что-нибудь интересное?"


translate russian ep1_table_chat_70478e1a:


    X "Захотелось больше тренироваться."


translate russian ep1_table_chat_aa37622f:


    Eileen "Хочешь похудеть?"


translate russian ep1_table_chat_e949fa95:


    X "Не совсем. Просто хочу привести себя в форму."


translate russian ep1_table_chat_5fa90b92:


    Eileen "Понятно. Я испугалась, что ты перестанешь быть сладкоежкой."


translate russian ep1_table_chat_922fd927:


    X "Даже не мечтай об этом!"


translate russian ep1_table_chat_b3f9266b:


    Eileen "Так что же заставило тебя задуматься об этом?"


translate russian ep1_table_chat_09248379:


    X "Несколько раз я шёл до офиса пешком из-за безумных пробок."


translate russian ep1_table_chat_c7665ca2:


    Eileen "Какое расстояние?"


translate russian ep1_table_chat_a425fc72:


    X "Менее трёх километров."


translate russian ep1_table_chat_59753416:


    X "И вот я уже у входа, весь измотанный и потный."


translate russian ep1_table_chat_41c6b2a8:


    Eileen "Жарко!"


translate russian ep1_table_chat_c95691fc:


    X "Было жарко, но дело не только в этом."


translate russian ep1_table_chat_859c3f16:


    X "Я подумывал о том, чтобы немного побегать, сходить в спортзал."


translate russian ep1_table_chat_5a2c9dae:


    Eileen "[Khalil] сейчас тренируется там."


translate russian ep1_table_chat_bf09086e:


    X "Да, мы встречались сегодня утром."


translate russian ep1_table_chat_3d0d3cb3:


    Eileen "Что ещё у тебя есть?"


translate russian ep1_table_chat_78555305:


    X "На самом деле прямо сейчас я просто хочу полакомиться выпечкой."


translate russian ep1_table_chat_a53fb625:


    Eileen "Стоит только попросить!"


translate russian ep1_table_chat_a35bba76:


    Eileen "Твой хлеб готов."


translate russian ep1_table_chat_452ffc4e:


    X "Откуда ты знаешь, чего я хочу?"


translate russian ep1_table_chat_739fb984:


    Eileen "В это время года ты всегда хочешь одно и то же, когда приходишь сюда."


translate russian ep1_table_chat_b6eb7e9f:


    Eileen "Затем ты делаешь сэндвичи и едёшь на пляж."


translate russian ep1_table_chat_fdf4ce24:


    Eileen "И ждёшь Эмили."


translate russian ep1_table_chat_d2c120e4:


    X "Ты так хорошо меня знаешь."


translate russian ep1_table_chat_1825c8b5:


    Eileen "Конечно! Мы знакомы со школы."


translate russian ep1_table_chat_3b5f8e55:


    Eileen "Ты знаешь, я тоже по ней скучаю."


translate russian ep1_table_chat_6b5ec015:


    Eileen "Кстати, тебе не обязательно что-то покупать здесь ради меня."


translate russian ep1_table_chat_6b045669:


    X "Что ты имеешь в виду?"


translate russian ep1_table_chat_3e63b504:


    Eileen "Ну, раз уж ты можешь позволить себе дорогие вещи."


translate russian ep1_table_chat_b36bc626:


    X "О чём ты говоришь?"


translate russian ep1_table_chat_b41c2ef2:


    X "Твои булочки - мои любимые!"


translate russian ep1_table_chat_66f81dc3:


    Eileen "Очень мило. Спасибо."


translate russian ep1_table_chat_9ce986d8:


    Eileen "Подожди-ка!"


translate russian ep1_table_chat_87250884:


    Eileen "Ты пытаешься получить скидку?"


translate russian ep1_table_chat_8a28a602:


    X "Гипотетически, если бы это было правдой, ты бы сделала её?"


translate russian ep1_table_chat_b7c10ca8:


    Eileen "Даже за такую вопиющую попытку..."


translate russian ep1_table_chat_faf1288b:


    Eileen "Я должна сказать \"да\"."


translate russian ep1_table_chat_eb03b815:


    X "В таком случае я тоже возьму немного сладостей."


translate russian ep1_table_chat_f4f5d1b6:


    X "Что-то вроде полдника."


translate russian ep1_table_chat_7d4a4c45:


    Eileen "Сейчас будет."


translate russian ep1_table_chat_31510771:


    X "Они не одни и те же. Твои вкуснее."


translate russian ep1_table_chat_9489ba36:


    X "Вроде тех, что готовила твоя мама, когда мы были маленькими."


translate russian ep1_table_chat_897fc1fa:


    Eileen "Хорошо, мне радостно от твоих слов."


translate russian ep1_table_chat_2cd44f4b:


    X "А можно мне тоже чего-нибудь сладкого?"


translate russian ep1_table_chat_f4f5d1b6_1:


    X "Что-то вроде полдника."


translate russian ep1_table_chat_7d4a4c45_1:


    Eileen "Сейчас будет."


translate russian ep1_table_chat_33917014:


    Eileen "Будешь что-то менять в этом году?"


translate russian ep1_table_chat_06645fbd:


    X "Сегодня займусь репетиторством."


translate russian ep1_table_chat_1118314a:


    X "Я решил, что, имея под рукой кое-какую работу, будет надёжнее."


translate russian ep1_table_chat_189c822a:


    Eileen "С каких это пор ты занимаешься репетиторством?"


translate russian ep1_table_chat_6cd10510:


    X "С сегодняшнего дня. Майя позвонила мне сегодня утром по поводу пары учениц."


translate russian ep1_table_chat_cad88cab:


    Eileen "Понятно."


translate russian ep1_table_chat_b195acdc:


    Eileen "В таком случае я могу кое-что порекомендовать..."


translate russian ep1_table_chat_b07bfd9a:


    Eileen "Нам стоит потусоваться как-нибудь. Наверстать упущенное как следует."


translate russian ep1_table_chat_a6079e11:


    X "Ты свободна в эти выходные?"


translate russian ep1_table_chat_43b46947:


    Eileen "Да, ещё увидимся!"


translate russian ep1_table_chat_652ba305:


    X "Лучше прибраться до их прихода."


translate russian tidy_house_loop_88b5b383:


    "Уберу этот мусор."


translate russian tidy_house_loop_8b1c0ae0:


    "Нельзя забывать о туалетной бумаге."


translate russian tidy_house_loop_609a70de:


    "Вот так."


translate russian tidy_house_loop_93dbeac8:


    X "Они здесь."


translate russian tidy_house_loop_2a62714d:


    Maya "Добрый день!"


translate russian tidy_house_loop_ca6c628c:


    X "Добро пожаловать! Проходите."


translate russian tidy_house_loop_2b6ff13f:


    Maya "Итак, это мистер [X]!"


translate russian tidy_house_loop_2f8d9d29:


    Maya "Он будет помогать тебе с математикой, [Sophie]."


translate russian tidy_house_loop_4a86d45b:


    Sophie "Здравствуйте, мистер [X]."


translate russian tidy_house_loop_24cad18e:


    X "Привет, [Sophie]."


translate russian tidy_house_loop_0ffc103b:


    X "И, пожалуйста, никаких \"мистеров\"!"


translate russian tidy_house_loop_350e90f6:


    "???" "Довольно большой дом, вы живёте с женой?"


translate russian tidy_house_loop_56c9a814:


    X "Я не женат, живу один."


translate russian tidy_house_loop_c13f2787:


    Maya "А это [Alecia]."


translate russian tidy_house_loop_53a84e5e:


    Maya "Ей нужна помощь по большинству предметов."


translate russian tidy_house_loop_92db4296:


    X "Понял."


translate russian tidy_house_loop_e05893ea:


    X "Проходите в гостинную."


translate russian tidy_house_loop_299b12f3:


    X "И чувствуйте себя как дома."


translate russian tidy_house_loop_0f967f62:


    Maya "Мы можем немного поговорить?"


translate russian tidy_house_loop_4d63f0d3:


    X "Конечно."


translate russian tidy_house_loop_cdea5611:


    Maya "Прошу прощения за то, что попросила вас об этом."


translate russian tidy_house_loop_7b60f6ba:


    Maya "Ведь вы уже и так сильно помогли нашему детскому дому."


translate russian tidy_house_loop_1eb26b1f:


    Maya "Но никто не мог обучать [Sophie]."


translate russian tidy_house_loop_6fdd3db2:


    X "Вы упомянули, что она участвовала и победила на национальных соревнованиях."


translate russian tidy_house_loop_3786fb9e:


    Maya "Верно."


translate russian tidy_house_loop_59bf6133:


    X "Как же так получилось, что ей никто не помогает?"


translate russian tidy_house_loop_9a3f27d9:


    Maya "У всех учителей очень высокие тарифы. И мы просто не можем себе их позволить."


translate russian tidy_house_loop_07309b2d:


    X "Вау! Похоже, рынок процветает."


translate russian tidy_house_loop_40fae894:


    Maya "Я не знаю."


translate russian tidy_house_loop_813b6764:


    Maya "Но [Sophie] очень старательная!"


translate russian tidy_house_loop_f3b965ce:


    Maya "И если вы сможете провести хотя бы несколько коротких сеансов, это окажет огромную помощь."


translate russian tidy_house_loop_51da3d7e:


    Maya "Я не хочу добавлять слишком много к той работе, которую вы уже выполняете."


translate russian tidy_house_loop_a68fac55:


    X "Вообще-то, я буду свободен некоторое время. Так что не стоит об этом беспокоиться."


translate russian tidy_house_loop_a20f3ada:


    X "И ещё насчёт [Alecia], в чём ей нужна помощь?"


translate russian tidy_house_loop_c1b52c76:


    Maya "В прошлом году у неё были проблемы с оценками."


translate russian tidy_house_loop_fc47d6a0:


    Maya "Теперь она должна посещать школу летом вместе с [Sophie]."


translate russian tidy_house_loop_a4e4d6a6:


    Maya "Она умная девочка. Так что больше всего её нужно убедить учиться."


translate russian tidy_house_loop_db10cfa3:


    X "Думаю, я получил общее представление о них обоих."


translate russian tidy_house_loop_6e7304c2:


    Maya "В таком случае я оставляю вас наедине с ними."


translate russian tidy_house_loop_8a32dfc7:


    Maya "И вернусь, чтобы забрать их, когда придёт время."


translate russian tidy_house_loop_3c774ee7:


    Maya "Если возникнут какие-то проблемы, вы всегда можете позвонить мне."


translate russian tidy_house_loop_0aefb079:


    Maya "И ещё раз спасибо вам!"


translate russian tidy_house_loop_11ce8c7b:


    X "Да не за что."


translate russian tidy_house_loop_6d3d9bd1:


    Maya "Я ухожу, а вы, девочки, ведите себя прилично!"


translate russian tidy_house_loop_4f19e64f:


    Sophie "Да, мисс [Maya]!"


translate russian tidy_house_loop_a5e0dffc:


    Alecia "Она говорила не о тебе, [Sophie]."


translate russian tidy_house_loop_eb7fe8b1:


    X "Я провожу вас."


translate russian tidy_house_loop_a7751c10:


    Maya "Всё в порядке, я знаю дорогу!"


translate russian tidy_house_loop_c3fa066f:


    X "Девочки, хотите что-нибудь выпить или поесть?"


translate russian tidy_house_loop_dcbb2b46:


    Sophie "Нет, спасибо."


translate russian tidy_house_loop_7e4370ee:


    Alecia "Я попью воды из-под крана."


translate russian tidy_house_loop_c7f14528:


    X "Из-под крана?"


translate russian tidy_house_loop_ea215acf:


    X "У меня есть свежевыжатый апельсиновый сок, или гранатовый, смотря какой любишь."


translate russian tidy_house_loop_16e1caf8:


    Alecia "Вода из-под крана подойдет."


translate russian tidy_house_loop_db705120:


    X "Хорошо."


translate russian tidy_house_loop_71824be5:


    X "Это домашнее задание?"


translate russian tidy_house_loop_433997b9:


    Sophie "Да, для летних уроков."


translate russian tidy_house_loop_9692137a:


    X "Круто. Можешь пока продолжать."


translate russian tidy_house_loop_5ff2ae21:


    X "Сначала я должен ознакомиться с материалом и всё запомнить."


translate russian tidy_house_loop_bc878c73:


    Sophie "Окей."


translate russian tidy_house_loop_3a331ef2:


    X "Слышал, в прошлом году ты дошла до национальных соревнований."


translate russian tidy_house_loop_9747da87:


    X "Ты готовилась к ним самостоятельно?"


translate russian tidy_house_loop_43cbf7cd:


    Sophie "Мне кое-кто помогал."


translate russian tidy_house_loop_e290d923:


    Alecia "Получить несколько советов от учителей после школы не считается, [Sophie]."


translate russian tidy_house_loop_59a2fac1:


    Alecia "Ей пришлось всё делать самой."


translate russian tidy_house_loop_d01b2b21:


    Sophie "Школа оплатила поездку."


translate russian tidy_house_loop_914a6814:


    Alecia "Карла заставила школу заплатить за неё!"


translate russian tidy_house_loop_e4f0ccf5:


    X "Карла?"


translate russian tidy_house_loop_c2a99637:


    Sophie "Директор школы."


translate russian tidy_house_loop_97075685:


    Alecia "Кажется, она единственная, кому не всё равно."


translate russian tidy_house_loop_73b8c774:


    Alecia "Даже пыталась заниматься репетиторством с [Sophie], но она преподаёт историю."


translate russian tidy_house_loop_d9058a23:


    X "Вау! Неужели всё так плохо?"


translate russian tidy_house_loop_15eca170:


    Alecia "Они все, наверное, думают, что не стоит беспокоиться о девочке-сироте."


translate russian tidy_house_loop_f7d1ca29:


    Alecia "И они также хотят кучу денег."


translate russian tidy_house_loop_4288b6d3:


    Alecia "Кстати, вы собираетесь преподавать в школе или что-то в этом роде?"


translate russian tidy_house_loop_409b6d41:


    X "У меня для этого нет никакой квалификации."


translate russian tidy_house_loop_aae8c194:


    Alecia "Но ведь вам за это платят?"


translate russian tidy_house_loop_f925f814:


    X "Я просто хочу помочь, мне не нужны деньги."


translate russian tidy_house_loop_70484651:


    Alecia "Это правильно..."


translate russian tidy_house_loop_bdab8637:


    X "[Sophie], когда ты начала серьёзно заниматься этим?"


translate russian tidy_house_loop_d0021183:


    Sophie "Мне всегда это нравилось."


translate russian tidy_house_loop_e29ccd0e:


    X "В своё время я сам участвовал в нескольких этапах."


translate russian tidy_house_loop_d14387d0:


    X "Проблема была в том, что я поздно осознал, что у меня есть к этому талант."


translate russian tidy_house_loop_f6dcf06d:


    Sophie "Почему?"


translate russian tidy_house_loop_8660952f:


    X "Большую часть школьных лет я не особо любил учиться."


translate russian tidy_house_loop_107c66da:


    X "Потом я встретил кое-кого, кто помог мне осознать это, помимо всего прочего."


translate russian tidy_house_loop_916bfa84:


    Sophie "Рада, что вы в конце концов осознали это."


translate russian tidy_house_loop_e34a1ccb:


    X "И я."


translate russian tidy_house_loop_f46d82ef:


    Alecia "Вы играете, [X]?"


translate russian tidy_house_loop_12dd4d7c:


    X "Играю во что?"


translate russian tidy_house_loop_05c3d683:


    X "Ах, на нём! Балуюсь время от времени."


translate russian tidy_house_loop_eb8fbab2:


    Alecia "Вы купили целое пианино только ради этого?"


translate russian tidy_house_loop_77faa7e9:


    X "Нет, на самом деле оно для кого-то другого. Для того, кто действительно может хорошо играть."


translate russian tidy_house_loop_ec1edbc8:


    X "Можешь попробовать, если хочешь."


translate russian tidy_house_loop_fe2eb51c:


    Alecia "Может, как-нибудь в другой раз."


translate russian tidy_house_loop_91417b83:


    X "И не стесняйся осматриваться."


translate russian tidy_house_loop_d7a8715c:


    X "Прошло уже много времени. Как насчет перерыва на перекус?"


translate russian tidy_house_loop_32c36096:


    X "Если вам, девочки, это не нравится, скажите мне, и я принесу что-нибудь другое."


translate russian tidy_house_loop_9ceb3812:


    Alecia "Не люблю сладости."


translate russian tidy_house_loop_f053eefa:


    X "Могу придумать что-нибудь ещё."


translate russian tidy_house_loop_e226287a:


    Alecia "Не беспокойтесь, я всё равно не голодна."


translate russian tidy_house_loop_140a8acc:


    X "Ну, как хочешь."


translate russian tidy_house_loop_56d8df5a:


    X "Тебе нравится, Софи?"


translate russian tidy_house_loop_38af9192:


    Sophie "Да. У них домашний вкус."


translate russian tidy_house_loop_ab46848e:


    X "Моей подруге будет приятно это услышать. Именно этого она и добивалась."


translate russian tidy_house_loop_77b0c082:


    Alecia "У вас есть девушка?"


translate russian tidy_house_loop_68cd65dc:


    X "Эээ, нет! Но мы знаем друг друга с начальной школы."


translate russian tidy_house_loop_d3e1843e:


    Alecia "Не подскажете, где туалет?"


translate russian tidy_house_loop_75cd702a:


    X "Вон прямо там."


translate russian tidy_house_loop_2ef9d43d:


    Alecia "Я быстро."


translate russian tidy_house_loop_e52bbf9d:


    X "Ладно..."


translate russian tidy_house_loop_efda42f5:


    Sophie "Они тоже с шоколадом?"


translate russian tidy_house_loop_e4366898:


    X "У них какая-то кремовая начинка. Не уверен, какая именно."


translate russian tidy_house_loop_f300265e:


    Sophie "Надеюсь, шоколад."


translate russian tidy_house_loop_34ce47d3:


    Sophie "О, нет!"


translate russian tidy_house_loop_a06b32a8:


    X "Давай я принесу полотенце!"


translate russian tidy_house_loop_eb24b15f:


    Sophie "Простите, я не заметила!"


translate russian tidy_house_loop_520bda97:


    X "Не беспокойся об этом."


translate russian tidy_house_loop_5d52e3e6:


    X "Тебе следует сходить в туалет, чтобы просохнуть."


translate russian tidy_house_loop_bc878c73_1:


    Sophie "Хорошо."


translate russian tidy_house_loop_9ad7d671:


    X "Он вверх по лестнице, дверь слева, пройди прямо через спальню."


translate russian tidy_house_loop_1a3b80b9:


    X "Где-то там есть сушилка."


translate russian tidy_house_loop_27455b67:


    Sophie "Спасибо!"


translate russian tidy_house_loop_bbb3c637:


    "У меня есть время сделать несколько сэндвичей."


translate russian tidy_house_loop_dee4aaca:


    "Может быть, ещё несколько для девочек."


translate russian tidy_house_loop_db02c6e8:


    Alecia "Где Софи?"


translate russian tidy_house_loop_2809f023:


    X "Она пошла обсохнуть, облилась водой."


translate russian tidy_house_loop_bdffcbe4:


    Alecia "Куда?"


translate russian tidy_house_loop_c94fc115:


    X "В туалет наверху."


translate russian tidy_house_loop_dd5cdc72:


    Alecia "Вон там?"


translate russian tidy_house_loop_def4ae4b:


    X "Дверь слева."


translate russian tidy_house_loop_38d4756d:


    Alecia "Слева от вас?"


translate russian tidy_house_loop_36f85856:


    X "Ага."


translate russian tidy_house_loop_4b42e3e4:


    X "Ты действительно любознательна."


translate russian tidy_house_loop_1179e61b:


    X "Может быть, у тебя есть вопросы о--"


translate russian tidy_house_loop_01f3466e:


    X "Эй!"


translate russian tidy_house_loop_36f2ba59:


    X "Что ты делаешь??"


translate russian tidy_house_loop_49800bd8:


    Alecia "Наверху две спальни, я проверила!"


translate russian tidy_house_loop_7d42b1f5:


    Alecia "Если причините Софи какую-либо боль, вы пожалеете об этом!"


translate russian tidy_house_loop_0e4a0f58:


    X "Стоп! Подожди!"


translate russian tidy_house_loop_b951b463:


    X "Туалет дальше, в конце коридора!"


translate russian tidy_house_loop_37891ca1:


    Alecia "О, правда?"


translate russian tidy_house_loop_621ef077:


    Alecia "[Sophie]!"


translate russian tidy_house_loop_1b2ced37:


    Alecia "[Sophie]!!"


translate russian tidy_house_loop_82df79fd:


    X "Она, наверное, сейчас пользуется сушилкой, поэтому не слышит тебя."


translate russian tidy_house_loop_e07e2a29:


    Alecia "Ну разве это не удобно!"


translate russian tidy_house_loop_c70702a3:


    X "Удобно для кого??"


translate russian tidy_house_loop_894fb8ed:


    Alecia "Богатого плейбоя вроде вас!"


translate russian tidy_house_loop_9a622738:


    Alecia "Живёте один в огромной квартире."


translate russian tidy_house_loop_bbc83bc6:


    Alecia "Принимаете девочек-сирот, угощаете их \"вкусняшками\"."


translate russian tidy_house_loop_49d5d590:


    Alecia "И занимаетесь репетиторством бесплатно."


translate russian tidy_house_loop_e4caafd8:


    Alecia "Тогда они теряют бдительность, и вы пользуетесь ими в своих интересах!"


translate russian tidy_house_loop_dff0f620:


    Alecia "Такие люди, как вы, просто не могут дождаться, когда им представится такая возможность!"


translate russian tidy_house_loop_b887e4a4:


    X "Эй, ты делаешь поспешные выводы!"


translate russian tidy_house_loop_5cbf677e:


    Alecia "Правда? Тогда у вас должно быть хорошее объяснение!"


translate russian tidy_house_loop_690e0882:


    Alecia "Верно?"


translate russian tidy_house_loop_7eccd23e:


    "Это просто смешно."


translate russian tidy_house_loop_a0698400:


    X "Сейчас же"


translate russian tidy_house_loop_a18b75ab:


    X "убери"


translate russian tidy_house_loop_d05bb22a:


    X "руку!"


translate russian tidy_house_loop_7a04f0cf:


    Alecia "Я так и знала!"


translate russian tidy_house_loop_c809fdf5:


    Alecia "Вам это не сойдет с рук!"


translate russian tidy_house_loop_ace7fb7d:


    X "Слушай, Майя позвонила сегодня утром и спросила, могу ли я немного позаниматься с вами."


translate russian tidy_house_loop_a9fecd1d:


    X "Некоторое время назад я сказал ей, что могу многое сделать, и мы составили список."


translate russian tidy_house_loop_ad2dc36a:


    X "Кроме того, я не в первый раз помогаю детскому дому."


translate russian tidy_house_loop_28fa20ee:


    Alecia "Допустим."


translate russian tidy_house_loop_bf4d86a4:


    Alecia "Но почему мы вас так волнуем?"


translate russian tidy_house_loop_2f31babf:


    X "Я знаю, что бюджет сокращается каждый год."


translate russian tidy_house_loop_16bf4552:


    X "К тому же я там вырос!"


translate russian tidy_house_loop_af888351:


    Alecia "В детском доме?"


translate russian tidy_house_loop_36f85856_1:


    X "Да."


translate russian tidy_house_loop_f00f51d3:


    Alecia "Ну и дела!"


translate russian tidy_house_loop_4df31bd7:


    Sophie "Простите, что так долго!"


translate russian tidy_house_loop_7e480a1f:


    X "Всё в порядке. Я готовлю сэндвичи. Скажи, что тебе нравится."


translate russian tidy_house_loop_364ee442:


    Sophie "О, я не знаю."


translate russian tidy_house_loop_056061cc:


    Sophie "Что угодно."


translate russian tidy_house_loop_ace7fb7d_1:


    X "Слушай, Майя позвонила сегодня утром и спросила, могу ли я немного позаниматься с вами."


translate russian tidy_house_loop_a9fecd1d_1:


    X "Некоторое время назад я сказал ей, что могу многое сделать, и мы составили список."


translate russian tidy_house_loop_ad2dc36a_1:


    X "Кроме того, я не в первый раз помогаю детскому дому."


translate russian tidy_house_loop_bf4d86a4_1:


    Alecia "Но почему мы вас так волнуем?"


translate russian tidy_house_loop_2f31babf_1:


    X "Я знаю, что бюджет сокращается каждый год."


translate russian tidy_house_loop_16bf4552_1:


    X "К тому же я там вырос!"


translate russian tidy_house_loop_af888351_1:


    Alecia "В детском доме?"


translate russian tidy_house_loop_36f85856_2:


    X "Да."


translate russian tidy_house_loop_5c02f092:


    X "С самого детства."


translate russian tidy_house_loop_4df31bd7_1:


    Sophie "Простите, что так долго!"


translate russian tidy_house_loop_7e480a1f_1:


    X "Всё в порядке. Я готовлю сэндвичи. Скажи, что тебе нравится."


translate russian tidy_house_loop_364ee442_1:


    Sophie "О, я не знаю."


translate russian tidy_house_loop_056061cc_1:


    Sophie "Что угодно."


translate russian tidy_house_loop_7f3039e9:


    Maya "Я немного опоздаю."


translate russian tidy_house_loop_56f5692c:


    Maya "Не могли бы вы побыть с ними ещё немного, пожалуйста?"


translate russian tidy_house_loop_b93f52c0:


    X "Я не против сам отвезти их."


translate russian tidy_house_loop_8453baa3:


    Maya "Не нужно. Вы и так делаете слишком много для нас!"


translate russian tidy_house_loop_befdbdfc:


    X "Вообще, я собираюсь развеяться позже. И по сути, мне по пути, так что никаких проблем."


translate russian tidy_house_loop_6d3311da:


    Maya "В таком случае, спасибо вам!"


translate russian tidy_house_loop_959f4057:


    X "А вот и мы!"


translate russian tidy_house_loop_018abb09:


    Sophie "Спасибо, мистер... то есть [X]!"


translate russian tidy_house_loop_4daf4dba:


    X "Не забудь про еду."


translate russian tidy_house_loop_807a22f7:


    Sophie "Она у меня в рюкзаке."


translate russian tidy_house_loop_536a3923:


    Alecia "Иди, Софи, я буду через минуту."


translate russian tidy_house_loop_a570c441:


    Alecia "Эй... Прошу прощения за недавнее недоразумение!"


translate russian tidy_house_loop_4786148d:


    Alecia "Я пойму, если вы больше не захотите меня видеть у себя."


translate russian tidy_house_loop_7d9f27c7:


    Alecia "Но, пожалуйста, не отказывайтесь от Софи, вы ей действительно нужны."


translate russian tidy_house_loop_6babfc60:


    X "Я не откажусь от неё, не волнуйся."


translate russian tidy_house_loop_e61361d2:


    X "Что касается тебя, то я хочу немного большего, чем просто \"извините\"."


translate russian tidy_house_loop_7d6ec8ea:


    Alecia "Что вы имеете в виду?"


translate russian tidy_house_loop_e15f3bf8:


    X "Вам придется продолжать приходить, а также пытаться что-то понять."


translate russian tidy_house_loop_4a6008c6:


    X "И после этого, возможно, мы будем в рассчете."


translate russian tidy_house_loop_58f63b79:


    Alecia "Вы серьёзно?"


translate russian tidy_house_loop_2f504bd0:


    X "Ещё как."


translate russian tidy_house_loop_c57de1ef:


    Alecia "Ладно, как угодно."


translate russian tidy_house_loop_23dc3d25:


    X "Увидимся в следующий раз!"


translate russian tidy_house_loop_9a0d4713:


    Alecia "Конечно."


translate russian tidy_house_loop_7a1f909a:


    "Этот день определенно прервал монотонность."


translate russian tidy_house_loop_14f574dc:


    "У [Alecia] есть некоторые проблемы с доверием. На самом деле я не могу её винить."


translate russian tidy_house_loop_ac8e9a77:


    "Кто-то ещё нашел это место?"


translate russian tidy_house_loop_2c8dfa3f:


    "Это она..."


translate russian tidy_house_loop_2c541bcc:


    X "[Emily]?!"


translate russian tidy_house_loop_ca274e97:


    "???" "Так звали мою маму."


translate russian tidy_house_loop_77fee8a4:


    "Её лицо... она выглядит точно так же, как..."


translate russian tidy_house_loop_55489514:


    X "Ты... [D]?"


translate russian tidy_house_loop_306941fb:


    D "Да. К-Кто ты?"


translate russian tidy_house_loop_1266c48b:


    X "Всё в порядке, меня зовут [X]. Мы с [Emily] вместе учились в школе."


translate russian tidy_house_loop_9604d1a0:


    X "Ей пришлось уйти до окончания школы."


translate russian tidy_house_loop_0d61e66f:


    D "[X]... мама писала о тебе."


translate russian tidy_house_loop_29f1f4dc:


    D "Она сказала, что ты мой отец."


translate russian tidy_house_loop_aecf9081:


    X "Я... я твой отец?"


translate russian tidy_house_loop_7f50e911:


    D "Да."


translate russian tidy_house_loop_030054ca:


    X "Вау, это..."


translate russian tidy_house_loop_af178197:


    X "Подожди."


translate russian tidy_house_loop_63266438:


    X "С кем ты сюда пришла?"


translate russian tidy_house_loop_394ea321:


    D "Я пришла одна. Мама написала, что обещала встретиться с тобой здесь."


translate russian tidy_house_loop_24b69eaf:


    D "Я не знала, куда ещё пойти."


translate russian tidy_house_loop_c0693580:


    X "Всё верно, мы обещали встретиться здесь."


translate russian tidy_house_loop_cfa0d125:


    X "С тех пор я...{w=1} прихожу сюда."


translate russian tidy_house_loop_9016919f:


    X "И [Emily]. Где она сейчас?"


translate russian tidy_house_loop_86cdaedf:


    D "Когда я была маленькой, они... они сказали мне, что она сбежала."


translate russian tidy_house_loop_e0bf2cd8:


    X "Что?"


translate russian tidy_house_loop_91223645:


    D "Когда мне было пять, я видела её в последний раз."


translate russian tidy_house_loop_bd5cf9d6:


    X "Кто тебе сказал, что она сбежала?"


translate russian tidy_house_loop_92059fdc:


    D "Люди, с которыми я жила. Те, кто удочерил её."


translate russian tidy_house_loop_e52fced3:


    "Её приемные родители."


translate russian tidy_house_loop_85bcaf67:


    X "А они знают, что ты здесь?"


translate russian tidy_house_loop_0aef2935:


    D "Нет, я сбежала."


translate russian tidy_house_loop_3c7bacfa:


    X "Зачем?"


translate russian tidy_house_loop_b993b267:


    D "Они лгали мне, они заставляли мою маму притворяться горничной!"


translate russian tidy_house_loop_828153d4:


    D "Апчхи!"


translate russian tidy_house_loop_bbbe84bf:


    X "Ладно, нам пора идти, становится холодно."


translate russian tidy_house_loop_e491aa42:


    X "Поговорим дома."


translate russian tidy_house_loop_41a158ff:


    X "Мы на месте."


translate russian tidy_house_loop_0611bcb3:


    D "Я вижу всё снаружи!"


translate russian tidy_house_loop_1ee37d32:


    X "Тебе нравится?"


translate russian tidy_house_loop_c9c5108e:


    D "Это потрясающе!"


translate russian tidy_house_loop_33c6f71d:


    X "Ты голодна? Хочешь что-нибудь поесть?"


translate russian tidy_house_loop_c737905d:


    D "Да, пожалуйста."


translate russian tidy_house_loop_a72e967b:


    X "У меня нет ничего готового, кроме них."


translate russian tidy_house_loop_710f1f75:


    D "Подойдёт, спасибо!"


translate russian tidy_house_loop_3d0eaba9:


    X "Далеко ли это место, откуда ты пришла?"


translate russian tidy_house_loop_42a0cffb:


    X "Как долго ты была в пути?"


translate russian tidy_house_loop_693446b4:


    D "Дней шесть, мне кажется."


translate russian tidy_house_loop_565b9a33:


    X "Прости, я не спросил твоего имени."


translate russian tidy_house_loop_e08eddeb:


    D "Мне не нужно имя."


translate russian tidy_house_loop_fec69eda:


    X "Ты не ХОЧЕШЬ иметь имя?"


translate russian tidy_house_loop_21dd2d25:


    D "Его подарили моей маме."


translate russian tidy_house_loop_e94db809:


    D "Я ненавижу его!"


translate russian tidy_house_loop_441cead2:


    X "Окей. Тогда как же мне тебя называть?"


translate russian tidy_house_loop_bf8fda76:


    D "Выбирай сам!"


translate russian tidy_house_loop_e0bf2cd8_1:


    X "Что?"


translate russian tidy_house_loop_7a5d3e00:


    D "В конце концов, ты мой отец."


translate russian tidy_house_loop_64d557e3:


    X "Да, я всё ещё пытаюсь осознать это."


translate russian tidy_house_loop_038d6295:


    X "Но если хочешь, я могу просто звать тебя--"


translate russian tidy_house_loop_e68f6a69:


    D "Стой!"


translate russian tidy_house_loop_9248edc0:


    D "Пока не надо."


translate russian tidy_house_loop_fd09bcff:


    D "Я выйду на улицу и встану перед дверью..."


translate russian tidy_house_loop_34b2ba36:


    D "Ты откроешь её и скажешь моё имя!"


translate russian tidy_house_loop_201fd5f5:


    X "Это... конечно! Мы сделаем это по-твоему."


translate russian tidy_house_loop_9be9bbae:


    "Они таким же образом назвали [Emily]?"


translate russian tidy_house_loop_eda2aaa6:


    "Это странно."


translate russian tidy_house_loop_c894bb30:


    "И я отец. Должно быть, это произошло в тот раз на пляже..."


translate russian tidy_house_loop_14df273a:


    X "Я открываю дверь."


translate russian tidy_house_loop_e1d8fdbc:


    X "Привет, [D]!"


translate russian tidy_house_loop_4c8eea32:


    D "Привет, папа!"


translate russian tidy_house_loop_09a1d11b:


    D "{font=fonts/NotoEmoji-Bold.ttf}{color=#69094c}🥱{/font}"


translate russian tidy_house_loop_a24fabad:


    X "Ты, наверное, устала."


translate russian tidy_house_loop_a5b357d4:


    X "Я пойду приготовлю ванну, а потом покажу твою спальню."


translate russian tidy_house_loop_518899a8:


    X "Это твоя комната."


translate russian tidy_house_loop_36ceaf43:


    X "Одежду можешь оставить в корзине для белья."


translate russian tidy_house_loop_b53f3e25:


    X "Там есть полотенца, мыло и всё остальное."


translate russian tidy_house_loop_7499843e:


    X "Я пойду поищу, что тебе надеть."


translate russian tidy_house_loop_beec3fc5:


    D "Хорошо."


translate russian tidy_house_loop_508b80cd:


    "Всё готово."


translate russian tidy_house_loop_36d0fb36:


    X "У меня есть только своя одежда."


translate russian tidy_house_loop_93b88678:


    X "Пока её будет достаточно."


translate russian tidy_house_loop_899b1c9a:


    D "Я не против."


translate russian tidy_house_loop_de9888c2:


    X "Выбери из гардероба всё, что захочешь."


translate russian tidy_house_loop_c1fd4ac5:


    X "Постель заправлена и готова."


translate russian tidy_house_loop_7ec63a7d:


    X "Я оставлю тебя одеваться."


translate russian tidy_house_loop_7c55a997:


    D "Спасибо!"


translate russian tidy_house_loop_22d38537:


    X "Пожалуйста!"


translate russian tidy_house_loop_e2edf103:


    "Забыл упомянуть ещё кое-что."


translate russian tidy_house_loop_6e184a1c:


    X "[D], могу я войти?"


translate russian tidy_house_loop_7f50e911_1:


    D "Да."


translate russian tidy_house_loop_114c4d8b:


    "Упс..."


translate russian tidy_house_loop_6e184a1c_1:


    X "[D], могу я войти?"


translate russian tidy_house_loop_7f50e911_2:


    D "Да."


translate russian tidy_house_loop_cd7dc865:


    X "Если ты всё ещё голодна, я могу что-нибудь приготовить."


translate russian tidy_house_loop_c1863690:


    D "Нет, всё в порядке."


translate russian tidy_house_loop_c6bec13b:


    X "Хорошо, но если проголодаешься, ешь всё, что хочешь."


translate russian tidy_house_loop_22343be8:


    D "Поняла, спасибо!"


translate russian tidy_house_loop_e018061f:


    "Мне нужно выяснить, кто эти люди."


translate russian tidy_house_loop_2c6f0f12:


    "Стоп! Забыл спросить о них!"


translate russian tidy_house_loop_064739ce:


    X "[D]."


translate russian tidy_house_loop_5ad9f54f:


    X "Мне нужно тебя кое о чём спросить!"


translate russian tidy_house_loop_5036f8f9:


    "Не отвечает..."


translate russian tidy_house_loop_a310f992:


    "Крепко спит. Должно быть, она устала."


translate russian tidy_house_loop_f4d9c83c:


    "Может, они солгали, что она исчезла?"


translate russian tidy_house_loop_d34da59d:


    "Мне нужно выяснить, что произошло."


translate russian tidy_house_loop_e049d492:


    "Нужно постараться отдохнуть."


translate russian tidy_house_loop_5023866e:


    "Мне нужна ясная голова для всего этого."


translate russian tidy_house_loop_b622a3d9:


    "???" "{cps=10}Не отпускай её...{w=1}"


translate russian tidy_house_loop_83f5a149:


    X "[Emily]!"


translate russian tidy_house_loop_a1debcb2:


    "Это был ещё один сон?"


translate russian tidy_house_loop_28d58032:


    "Не могу ничего вспомнить..."


translate russian tidy_house_loop_be8a95df:


    "Что за запах?"


translate russian tidy_house_loop_2a1f302c:


    "Значит, это был не сон..."


translate russian tidy_house_loop_844e8ecd:


    X "Доброе утро!"


translate russian tidy_house_loop_e5fd2ed1:


    D "Доброе!"


translate russian tidy_house_loop_6ca9fae3:


    D "Я приготовила завтрак, так как вчера съела твои сэндвичи."


translate russian tidy_house_loop_27e1d7ef:


    D "Присаживайся, всё почти готово."


translate russian tidy_house_loop_1e94a351:


    D "Я не знала, что тебе нравится, поэтому разнообразила его."


translate russian tidy_house_loop_4674549c:


    X "Вкуснотища!"


translate russian tidy_house_loop_b55c7a1f:


    X "Но тебе не нужно было этого делать."


translate russian tidy_house_loop_aa25042f:


    D "Всё в порядке, мне нравится готовить."


translate russian tidy_house_loop_064739ce_1:


    X "[D]."


translate russian tidy_house_loop_6584dbf5:


    D "Да?"


translate russian tidy_house_loop_6b789f98:


    X "Ты уверена, что согласна, чтобы я тебя так называл?"


translate russian tidy_house_loop_c8c729eb:


    D "Да, мне нравится так!"


translate russian tidy_house_loop_c6a0adb0:


    D "Ну если ты так уверена..."


translate russian tidy_house_loop_917e4d06:


    X "О людях, с которыми ты была."


translate russian tidy_house_loop_84bc4a09:


    X "Мне нужно кое-что о них узнать."


translate russian tidy_house_loop_1696fe15:


    X "Если ты беспокоишься..."


translate russian tidy_house_loop_dd17bfea:


    X "Я не расскажу им о тебе. Обещаю!"


translate russian tidy_house_loop_025868f9:


    D "Их зовут [Radford] и [Odelia], а меня они называли Адалиндой."


translate russian tidy_house_loop_a649a0c8:


    X "Ты знаешь адрес их дома?"


translate russian tidy_house_loop_7f50e911_3:


    D "Да."


translate russian tidy_house_loop_809ec91e:


    X "И они сказали тебе, что [Emily] была просто горничной?"


translate russian tidy_house_loop_d2e9d562:


    D "Она была единственной, кто заботился обо мне, когда я была маленькой."


translate russian tidy_house_loop_747223ad:


    X "Ты упомянула, что она где-то это написала."


translate russian tidy_house_loop_3791ba5c:


    D "Да, в дневнике. Он закопан."


translate russian tidy_house_loop_06f4379e:


    D "Он начинается с моего рождения."


translate russian tidy_house_loop_a5e2ef97:


    X "И они назвали вас обеих [Adalinda]?"


translate russian tidy_house_loop_5f73d8dd:


    D "Когда её удочерили, они сменили ей имя."


translate russian tidy_house_loop_6bc8e731:


    D "Но после моего рождения они стали называть меня её новым именем. А она снова стала [Emily]."


translate russian tidy_house_loop_8e6b2e82:


    X "Это неправильно!"


translate russian tidy_house_loop_6f9a2dd9:


    X "Ты пробовала поговорить с другими людьми, например, в школе?"


translate russian tidy_house_loop_df4c5fcb:


    D "Я не училась в школе. Иногда приходил репетитор."


translate russian tidy_house_loop_a663f98d:


    X "Значит, большую часть жизни ты была на домашнем обучении?"


translate russian tidy_house_loop_4a9f6159:


    D "Они говорили мне, что внешний мир слишком опасен, что он развратит меня."


translate russian tidy_house_loop_a6a0cca1:


    "Какого чёрта..."


translate russian tidy_house_loop_811c11bd:


    X "Встречалась ли ты с другими людьми, кроме них?"


translate russian tidy_house_loop_fae67871:


    D "Мне не разрешалось выходить за пределы участка."


translate russian tidy_house_loop_0363ef9c:


    X "А как же медицинские осмотры? Когда ты в последний раз посещала врача?"


translate russian tidy_house_loop_82349ea9:


    D "Думаю, он приезжал года три назад."


translate russian tidy_house_loop_5da626e9:


    "Конечно..."


translate russian tidy_house_loop_09a1d11b_1:


    D "{font=fonts/NotoEmoji-Bold.ttf}{color=#69094c}🥱{/font}"


translate russian tidy_house_loop_7d026639:


    X "Как и где ты спала?"


translate russian tidy_house_loop_5bb3a95e:


    D "В поезде, в автобусе, однажды в библиотеке."


translate russian tidy_house_loop_8906e483:


    X "Судя по всему, ты не могла хорошо выспаться."


translate russian tidy_house_loop_9d10fb38:


    X "Лучше отдохни, не изнуряй себя."


translate russian tidy_house_loop_8fe0f840:


    D "Я встану до обеда."


translate russian tidy_house_loop_5ab6b4df:


    X "Не беспокойся о готовке, если ты об ней думаешь!"


translate russian tidy_house_loop_d2133371:


    X "Я могу сам это сделать. Спи сколько захочешь."


translate russian tidy_house_loop_31273e68:


    D "Поняла..."


translate russian tidy_house_loop_059d04b4:


    X "...да, полное обследование, как можно скорее."


translate russian tidy_house_loop_9d19f666:


    "Оператор" "Ваша страховка недавно была аннулирована, мистер [X]."


translate russian tidy_house_loop_4020b891:


    "Что ж, а они быстрые."


translate russian tidy_house_loop_c88f6336:


    X "Это неважно, обследование не меня, а молодой девушки, моей... дочери."


translate russian tidy_house_loop_a6f736dc:


    "Оператор" "Понятно."


translate russian tidy_house_loop_8744b8e0:


    "Оператор" "В таком случае мы можем записать вас на завтра."


translate russian tidy_house_loop_6d476863:


    "Оператор" "Однако это премиум-опция, поэтому плата за неё выше."


translate russian tidy_house_loop_8e951ecd:


    X "Отлично. Я заплачу, сколько бы она ни стоила."


translate russian tidy_house_loop_04563b8b:


    "Оператор" "Тогда окей! И под каким именем мне следует зарегистрировать пациентку?"


translate russian tidy_house_loop_064739ce_2:


    X "[D]."


translate russian tidy_house_loop_7d811a66:


    "Оператор" "Готово! Первый приём состоится завтра в 9 часов."


translate russian tidy_house_loop_0678ef4d:


    "Оператор" "Хорошего дня, мистер [X]!"


translate russian tidy_house_loop_d0029623:


    "Неудивительно, что я её не нашел, записей о них почти нет."


translate russian tidy_house_loop_fc6cc3de:


    "По крайней мере, у [Charlie] уже есть кое-какие зацепки..."


translate russian tidy_house_loop_f5786a36:


    D "Папа!"


translate russian tidy_house_loop_5cbaae6f:


    X "Да, [D]?"


translate russian tidy_house_loop_41dda929:


    D "Это что... телевизор?"


translate russian tidy_house_loop_aaa78443:


    X "Тот факт, что ты это так произнесла, и то что ты спрашиваешь о нём..."


translate russian tidy_house_loop_5909d188:


    X "Наводит меня на мысль, что у тебя его не было."


translate russian tidy_house_loop_eea6b9ec:


    D "Один был, но большой и больше походил на коробку."


translate russian tidy_house_loop_adef9cc1:


    X "Наверное, очень старый."


translate russian tidy_house_loop_934f6d5e:


    D "Но чаще всего он показывал только блох."


translate russian tidy_house_loop_7d092c1a:


    X "Блох? Ты имеешь в виду статику?"


translate russian tidy_house_loop_2ddc3212:


    D "Думаю, да."


translate russian tidy_house_loop_a50d7ba7:


    X "...так что вот как работает пульт."


translate russian tidy_house_loop_26e7b722:


    D "Поняла."


translate russian tidy_house_loop_a22e7b3d:


    X "Смотри всё, что нравится."


translate russian tidy_house_loop_5f0d57ad:


    X "Я должен разобраться с этим."


translate russian tidy_house_loop_2870d77e:


    Charlie "Приветствую, [X]! Я получила ваше сообщение."


translate russian tidy_house_loop_9192c7e0:


    Charlie "Вы уверены, что это хорошая зацепка?"


translate russian tidy_house_loop_113469bc:


    X "Несомненно, это они её удочерили."


translate russian tidy_house_loop_6dbf4bfc:


    Charlie "Как вы вообще её нашли?"


translate russian tidy_house_loop_5c553784:


    X "Скорее, она меня нашла."


translate russian tidy_house_loop_7236c04c:


    X "Точнее, меня нашла её и моя дочь."


translate russian tidy_house_loop_fbfc5a5d:


    Charlie "Ваша дочь?!"


translate russian tidy_house_loop_13ea5980:


    X "Да, мы с [Emily] познакомились... до того, как её удочерили."


translate russian tidy_house_loop_0da6bae0:


    Charlie "..."


translate russian tidy_house_loop_e52046f1:


    Charlie "Понятно... не буду винить вас за то, что вы не упомянули об этом."


translate russian tidy_house_loop_855b4836:


    Charlie "Но вы сможете рассказать мне все подробности, когда мы встретимся."


translate russian tidy_house_loop_17a5a459:


    Charlie "Я посмотрю, что мне удастся накопать к тому времени."


translate russian tidy_house_loop_edfef00b:


    X "Конечно, и спасибо, что сразу же взялись за дело."


translate russian tidy_house_loop_bbe22e00:


    Charlie "Не проблема. В конце концов мне ведь надо закончить начатое."


translate russian tidy_house_loop_3505c389:


    Charlie "Я позвоню, когда всё будет готово."


translate russian tidy_house_loop_4a247e30:


    X "Время для ужина."


translate russian tidy_house_loop_4439d1b4:


    X "Я могу что-нибудь приготовить или мы можем заказать пиццу."


translate russian tidy_house_loop_a70cf6a8:


    D "Нет, я умею готовить!"


translate russian tidy_house_loop_20d17008:


    X "В этом нет необходимости, [D]. К тому же ты уже готовила завтрак этим утром."


translate russian tidy_house_loop_074569d9:


    D "Нет, я люблю готовить!"


translate russian tidy_house_loop_f91faedb:


    D "Мне приходилось постоянно тренироваться."


translate russian tidy_house_loop_367c918e:


    X "Я посмотрел на дом, он больше похож на особняк."


translate russian tidy_house_loop_76fc7cc5:


    X "Ты сбежала. Как тебе это удалось?"


translate russian tidy_house_loop_308fa32b:


    D "Мы поехали навестить человека, который собирался жениться."


translate russian tidy_house_loop_8ff2cda1:


    D "Со мной всегда был опекун. Мне сказали, что это для моей безопасности."


translate russian tidy_house_loop_8f37d1c7:


    D "Он всегда наблюдал за мной."


translate russian tidy_house_loop_b4ba6784:


    X "Всегда?"


translate russian tidy_house_loop_0e4572db:


    D "Кроме тех случаев, когда я ходила в туалет, тогда он просто стоял снаружи."


translate russian tidy_house_loop_e3874863:


    D "Вот тогда я и сбежала."


translate russian tidy_house_loop_b47b94c4:


    X "Если за тобой круглосуточно следили, то, вероятно, ожидали, что ты сбежишь."


translate russian tidy_house_loop_c0309a27:


    D "Однажды, когда я была маленькой, я последовала за котёнком на улицу."


translate russian tidy_house_loop_1b78f96a:


    D "Они разозлились и сказали, что мне больше нельзя оставаться одной."


translate russian tidy_house_loop_1b020a76:


    D "С тех пор я не должна была оставаться одной."


translate russian tidy_house_loop_b6e7ca26:


    D "Они сказали, что я исчезну точно так же, как [Emily], если ещё раз выйду на улицу одна."


translate russian tidy_house_loop_fe1ac9ab:


    "Господи..."


translate russian tidy_house_loop_020dcc22:


    X "Но, несмотря на это, ты всё равно ушла. Должно быть, это было нелегко."


translate russian tidy_house_loop_fe6a0dfd:


    D "Найдя дневник, я просто не поверила ничему, что они говорили."


translate russian tidy_house_loop_dab18d8f:


    X "Ты взяла его с собой?"


translate russian tidy_house_loop_d814d34a:


    D "Нет, но я спрятала его."


translate russian tidy_house_loop_eeab6513:


    X "Это было восхитительно!"


translate russian tidy_house_loop_a71b61a6:


    X "Практика действительно приводит к совершенству."


translate russian tidy_house_loop_68244322:


    D "Рада, что тебе понравилось."


translate russian tidy_house_loop_b88de3dc:


    X "И кстати, завтра мы проведём тебе полное медицинское обследование."


translate russian tidy_house_loop_4b7346a5:


    X "Поскольку ты упомянула, что уже много лет не ходила к врачу."


translate russian tidy_house_loop_074af5df:


    D "Полное обследование?"


translate russian tidy_house_loop_01e1dbd8:


    X "Да, нам нужно несколько анализов, и они всё осмотрят."


translate russian tidy_house_loop_6dbbb53c:


    D "Всё? Даже внизу... там?"


translate russian tidy_house_loop_4486d5cb:


    X "И там тоже, да."


translate russian tidy_house_loop_da8a59e6:


    X "Это сделает женский врач, так что не волнуйся!"


translate russian tidy_house_loop_0a0f91f5:


    D "Спасибо, я пойду помою посуду."


translate russian tidy_house_loop_6044d30b:


    X "Постой!"


translate russian tidy_house_loop_06fd6eee:


    X "Кое-кто позаботится об этом за тебя."


translate russian tidy_house_loop_3bc78a6d:


    X "Он справится со всем, что ты туда положишь."


translate russian tidy_house_loop_b2301f69:


    X "Кастрюли, сковородки, что угодно."


translate russian tidy_house_loop_60ea4257:


    X "Он отмоет любые пятна, даже самые маленькие."


translate russian tidy_house_loop_bd689fa9:


    X "Я называю его... \"Мой Вейдер\"!"


translate russian tidy_house_loop_686c14d1:


    D "Почему?"


translate russian tidy_house_loop_6ec1f519:


    D "Почему?!"


translate russian tidy_house_loop_bebefade:


    X "Ты знаешь... \"Я - твой отец!\""


translate russian tidy_house_loop_a7394244:


    D "Я знаю!"


translate russian tidy_house_loop_66bca81d:


    X "Нет, это не то, что я... Неважно."


translate russian tidy_house_loop_081c815a:


    X "Тебе нужно больше смотреть телевизор!"


translate russian tidy_house_loop_409f2707:


    D "Согласна!"


translate russian tidy_house_loop_38e0af6b:


    D "Могу я пойти в туалет?"


translate russian tidy_house_loop_1c701a15:


    X "Да, и не надо спрашивать!"


translate russian tidy_house_loop_3828de61:


    "Наверное, лучше всего взять её анализы дома."


translate russian tidy_house_loop_64545ae3:


    "Возможно, ей будет слишком неудобно делать это в больнице."


translate russian tidy_house_loop_1f517d04:


    "Она всё ещё в ванной?"


translate russian tidy_house_loop_6f0b7f35:


    X "[D], всё в порядке?"


translate russian tidy_house_loop_5308c5ae:


    D "Мне... мне нужна кое-какая помощь."


translate russian tidy_house_loop_ef4f69df:


    X "Тебе нужно что-то принести?"


translate russian tidy_house_loop_667e4980:


    D "Не мог бы ты зайти?"


translate russian tidy_house_loop_c72fc6b9:


    X "Что случилось?"


translate russian tidy_house_loop_a25448d7:


    D "Я не могу снять его."


translate russian tidy_house_loop_e15144ef:


    X "Снять что?"


translate russian tidy_house_loop_637dc8ff:


    X "Эй, что ты..."


translate russian tidy_house_loop_6139e3b4:


    D "Я пыталась, но он просто не снимается."


translate russian tidy_house_loop_19f3756b:


    D "Он заперт на ключ."


translate russian tidy_house_loop_f4715af1:


    X "Заперт?"


translate russian tidy_house_loop_0d5897b7:


    X "Это... это пояс целомудрия?!"

translate russian strings:


    old "Give her your love"
    new "Дать ей свою любовь"


    old "Say it"
    new "Сказать это"


    old "Hesitate"
    new "Колебаться"


    old "Talk work"
    new "Поговорить о работе"


    old "Talk fitness"
    new "Поговорить о фитнесе"


    old "Favorite shop"
    new "Любимый магазин"


    old "Nostalgia"
    new "Ностальгия"


    old "Check livingroom"
    new "Проверить гостиную"


    old "Check lower bathroom"
    new "Проверить туалет"


    old "Check your room"
    new "Проверить свою комнату"


    old "Wait for [Maya]"
    new "Ждать [Maya]"


    old "Grab her arm"
    new "Взять её за руку"


    old "Explain"
    new "Объяснить"


    old "Knock on the door"
    new "Постучать в дверь"


    old "Open the door"
    new "Открыть дверь"

    old "Continue"
    new "Продолжить"

    old "What should I name my dad?"
    new "Как мне назвать свою дочь?"

    old "Filia"
    new "Филия"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
