﻿# TODO: Translation updated at 2024-02-11 21:34
translate russian strings:
    
    old "What is your name?"
    new "Как вас зовут?"

    old "Emsy"
    new "Эмси"

    old "Episode 1"
    new "Эпизод 1"

    old "An Old Hope"
    new "Старая надежда"

# game/scripts/episode1.rpy:27
translate russian ep1_01_dream_3874842e:

    # X "You don't have to leave."
    X "Тебе не обязательно уходить."

# game/scripts/episode1.rpy:29
translate russian ep1_01_dream_d49a4d93:

    # X "We can run away instead!"
    X "Мы просто можем сбежать!"

# game/scripts/episode1.rpy:30
translate russian ep1_01_dream_0740ee27:

    # Emily "It's the final year for us."
    Emily "Это последний год для нас."

# game/scripts/episode1.rpy:32
translate russian ep1_01_dream_2034bb45:

    # Emily "If we leave now, then going to university is out of the picture."
    Emily "Если мы уйдём сейчас, то о поступлении в университет не может быть и речи."

# game/scripts/episode1.rpy:33
translate russian ep1_01_dream_609f6f3f:

    # Emily "Also you did promise to shoot for first place this year."
    Emily "Кроме того, ты обещал, что в этом году займёшь первое место."

# game/scripts/episode1.rpy:35
translate russian ep1_01_dream_c6ff5e0d:

    # X "And what about you?"
    X "А как насчёт тебя?"

# game/scripts/episode1.rpy:37
translate russian ep1_01_dream_73956e0a:

    # Emily "They said it's a really nice school."
    Emily "Они сказали, что это действительно хорошая школа."

# game/scripts/episode1.rpy:39
translate russian ep1_01_dream_585d20b5:

    # Emily "I can get anything I need, so it's fine."
    Emily "Я могу получить всё, что мне нужно, так что всё в порядке."

# game/scripts/episode1.rpy:40
translate russian ep1_01_dream_9ac6a703:

    # X "That's good."
    X "Это хорошо."

# game/scripts/episode1.rpy:42
translate russian ep1_01_dream_05dcf7c7:

    # Emily "We can meet here next summer. Same place."
    Emily "Мы можем встретиться здесь следующим летом. В этом же месте."

# game/scripts/episode1.rpy:43
translate russian ep1_01_dream_8f01c937:

    # X "Same time."
    X "В это же время."

# game/scripts/episode1.rpy:44
translate russian ep1_01_dream_4d829df8:

    # Emily "It's a promise."
    Emily "Договорились."

# game/scripts/episode1.rpy:46
translate russian ep1_01_dream_e10bce07:

    # X "I'll be be here waiting."
    X "Я буду ждать тебя здесь."

# game/scripts/episode1.rpy:48
translate russian ep1_01_dream_0b0e6e2d:

    # X "Hey, does it seem hotter today?"
    X "Эй, тебе не кажется, что сегодня жарче?"

# game/scripts/episode1.rpy:50
translate russian ep1_01_dream_8c0b4421:

    # Emily "A bit. Want to go for a swim?"
    Emily "Немного. Хочешь пойти искупаться?"

# game/scripts/episode1.rpy:52
translate russian ep1_01_dream_57815ff5:

    # X "What you got a swimsuit under there?"
    X "Что у тебя там под купальником?"

# game/scripts/episode1.rpy:53
translate russian ep1_01_dream_e17a378b:

    # Emily "No..."
    Emily "Ничего..."

# game/scripts/episode1.rpy:55
translate russian ep1_01_dream_7e73c71a:

    # X "Do you... need some space?"
    X "Тебе... нужно немного пространства?"

# game/scripts/episode1.rpy:56
translate russian ep1_01_dream_e17a378b_1:

    # Emily "No..."
    Emily "Нет..."

# game/scripts/episode1.rpy:57
translate russian ep1_01_dream_d6058f6a:

    # Emily "I don't mind."
    Emily "Я не против."

# game/scripts/episode1.rpy:58
translate russian ep1_01_dream_718fb7b3:

    # Emily "Do you want to look?"
    Emily "Хочешь посмотреть?"

# game/scripts/episode1.rpy:60
translate russian ep1_01_dream_03d4a9ac:

    # X "I... yes. I want to!"
    X "Я... да. Хочу!"

# game/scripts/episode1.rpy:63
translate russian ep1_01_dream_bf9b1140:

    # X "Emily."
    X "Эмили."

# game/scripts/episode1.rpy:65
translate russian ep1_01_dream_ef0ee5ca:

    # Emily "Yes?"
    Emily "Да?"

# game/scripts/episode1.rpy:67
translate russian ep1_01_dream_c6564de5:

    # X "It's the last day we get."
    X "Это наш последний день."

# game/scripts/episode1.rpy:69
translate russian ep1_01_dream_f25e2306:

    # X "We won't see each other for a long time."
    X "Мы не увидимся ещё долгое время."

# game/scripts/episode1.rpy:71
translate russian ep1_01_dream_32f3545c:

    # Emily "True."
    Emily "Да..."

# game/scripts/episode1.rpy:72
translate russian ep1_01_dream_3dda9473:

    # Emily "We should make the most of it then."
    Emily "Тогда мы должны извлечь из него максимум пользы."

# game/scripts/episode1.rpy:74
translate russian ep1_01_dream_4b368dab:

    # X "Agreed!"
    X "Согласен!"

# game/scripts/episode1.rpy:77
translate russian ep1_01_dream_749d1115:

    # Emily "Can you give me a hand..."
    Emily "Ты можешь помочь мне..."

# game/scripts/episode1.rpy:82
translate russian ep1_01_dream_57c00b31:

    # "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}💕💋💞{/font}"
    "{font=fonts/NotoEmoji-Bold.ttf}{color=#7c0006}💕💋💞{/font}"

# game/scripts/episode1.rpy:84
translate russian ep1_01_dream_6c143454:

    # Emily "You've gotten better at this!"
    Emily "Ты стал лучше в этом!"

# game/scripts/episode1.rpy:85
translate russian ep1_01_dream_5d20bd94:

    # X "I've been practicing."
    X "Я практиковался."

# game/scripts/episode1.rpy:86
translate russian ep1_01_dream_b20db10b:

    # Emily "Really? How?"
    Emily "Правда? Как?"

# game/scripts/episode1.rpy:88
translate russian ep1_01_dream_bf02b35c:

    # X "With you, in my dreams..."
    X "С тобой, в своих мечтах..."

# game/scripts/episode1.rpy:90
translate russian ep1_01_dream_ad7a7236:

    # X "I'm putting in slowly, tell me if it hurts."
    X "Я ввожу медленно, скажи, если будет больно."

# game/scripts/episode1.rpy:92
translate russian ep1_01_dream_d5328e3f:

    # Emily "Keep going."
    Emily "Продолжай."

# game/scripts/episode1.rpy:94
translate russian ep1_01_dream_4862ab17:

    # Emily "Aaa!"
    Emily "Ааа!"

# game/scripts/episode1.rpy:96
translate russian ep1_01_dream_1993c876:

    # Emily "Hold like this for a moment..."
    Emily "Задержись так на мгновение..."

# game/scripts/episode1.rpy:99
translate russian ep1_01_dream_67384d82:

    # Emily "...it's better now."
    Emily "...теперь стало лучше."

# game/scripts/episode1.rpy:101
translate russian ep1_01_dream_966f50d0:

    # X "Here I go!"
    X "Я продолжаю!"

# game/scripts/episode1.rpy:105
translate russian ep1_01_dream_8c0a108c:

    # Emily "Just like that! Yes!"
    Emily "Вот так! Да!"

# game/scripts/episode1.rpy:107
translate russian ep1_01_dream_68488c5a:

    # X "You feel so good [Emily]!"
    X "Мне так хорошо, [Emily]!"

# game/scripts/episode1.rpy:108
translate russian ep1_01_dream_ef62569a:

    # X "I'm already close."
    X "Я уже близко."

# game/scripts/episode1.rpy:109
translate russian ep1_01_dream_647408f4:

    # Emily "I want to go all the way with you [X]."
    Emily "Я хочу кончить одновременно с тобой, [X]."

# game/scripts/episode1.rpy:110
translate russian ep1_01_dream_873a7261:

    # Emily "So don't stop!"
    Emily "Так что не останавливайся!"

# game/scripts/episode1.rpy:111
translate russian ep1_01_dream_69115b64:

    # X "[Emily]..."
    X "[Emily]..."

# game/scripts/episode1.rpy:114
translate russian ep1_01_dream_159a94c5:

    # X "It's too good!"
    X "Слишком хорошо!"

# game/scripts/episode1.rpy:117
translate russian ep1_01_dream_a9a63983:

    # X "I want to give you everything [Emily]!"
    X "Я хочу отдать тебе её всю, [Emily]!"

# game/scripts/episode1.rpy:118
translate russian ep1_01_dream_52f7e5b8:

    # Emily "I'm all yours [X]!"
    Emily "Я вся твоя, [X]!"

# game/scripts/episode1.rpy:122
translate russian ep1_01_dream_83f5a149:

    # X "[Emily]!"
    X "[Emily]!"

# game/scripts/episode1.rpy:123
translate russian ep1_01_dream_7fe428f5:

    # Emily "[X]!"
    Emily "[X]!"

# game/scripts/episode1.rpy:125
translate russian ep1_01_dream_5d9e2527:

    # Emily "I feel it all!"
    Emily "Я чувствую её всю!"

# game/scripts/episode1.rpy:128
translate russian ep1_01_dream_30b5adcf:

    # X "I need to tell you something."
    X "Мне нужно тебе кое-что сказать."

# game/scripts/episode1.rpy:129
translate russian ep1_01_dream_abff5250:

    # X "I wanted to say it for a long time."
    X "Я давно хотел это сказать."

# game/scripts/episode1.rpy:130
translate russian ep1_01_dream_9fb95760:

    # Emily "Say what?"
    Emily "Сказать что?"

# game/scripts/episode1.rpy:132
translate russian ep1_01_dream_04794e48:

    # Emily "{cps=0}Say what?" nointeract
    Emily "{cps=0}Сказать что?" nointeract

# game/scripts/episode1.rpy:135
translate russian ep1_01_dream_35cb1b77:

    # X "I want you to know that I--"
    X "Я хочу, чтобы ты знала, что я--"

# game/scripts/episode1.rpy:138
translate russian ep1_01_dream_e25ad233:

    # X "I love you Emily!"
    X "Я люблю тебя, Эмили!"

# game/scripts/episode1.rpy:141
translate russian ep1_01_dream_65f9ee34:

    # X "You know!"
    X "Ты знаешь!"

# game/scripts/episode1.rpy:142
translate russian ep1_01_dream_1e5bb1ee:

    # Emily "I don't. What is it?"
    Emily "Я не. Что это?"

# game/scripts/episode1.rpy:143
translate russian ep1_01_dream_7c10ca7c:

    # X "It's that..."
    X "Это..."

# game/scripts/episode1.rpy:152
translate russian ep1_01_dream_ce51b5cf:

    # X "What time is it?"
    X "Который час?"

# game/scripts/episode1.rpy:154
translate russian ep1_01_dream_5c7ce1fa:

    # X "And who would be calling?"
    X "И кто мне звонит?"

# game/scripts/episode1.rpy:160
translate russian ep1_01_dream_a9dc9eb3:

    # X "Hello?"
    X "Алло?"

# game/scripts/episode1.rpy:161
translate russian ep1_01_dream_074a3ef7:

    # Maya "Good morning [X], it's [Maya] from the orphanage."
    Maya "Доброе утро, [X], это [Maya] из детского дома."

# game/scripts/episode1.rpy:162
translate russian ep1_01_dream_feb6ca03:

    # X "[Maya], yes, good morning!"
    X "[Maya], да, доброе утро!"

# game/scripts/episode1.rpy:163
translate russian ep1_01_dream_408c101e:

    # Maya "We talked some time ago about what we needed here."
    Maya "Несколько дней назад мы с вами говорили о том, что нам нужно."

# game/scripts/episode1.rpy:164
translate russian ep1_01_dream_01df64f8:

    # X "I remember. What came up?"
    X "Помню. Что-то появилось?"

# game/scripts/episode1.rpy:165
translate russian ep1_01_dream_7f24f74a:

    # Maya "You mentioned tutoring as one of the jobs."
    Maya "Вы упомянули репетиторство в качестве одной из работ."

# game/scripts/episode1.rpy:166
translate russian ep1_01_dream_617c97ad:

    # X "That's right. But I need to brush up first."
    X "Верно. Но сначала мне нужно привести себя в порядок."

# game/scripts/episode1.rpy:167
translate russian ep1_01_dream_d4fb4aef:

    # Maya "Of course. There are 2 girls who are in need."
    Maya "Конечно. Есть 2 девочки, которые нуждаются в помощи."

# game/scripts/episode1.rpy:168
translate russian ep1_01_dream_e36b9451:

    # Maya "The thing is with mathematics, if you can do more advanced stuff."
    Maya "Дело в математике, если вы преподаёте на достаточно продвинутом уровне."

# game/scripts/episode1.rpy:170
translate russian ep1_01_dream_33271e0a:

    # X "How advanced are we talking?"
    X "Об насколько продвинутом уровне мы говорим?"

# game/scripts/episode1.rpy:171
translate russian ep1_01_dream_db662cfd:

    # Maya "National Olympiad level."
    Maya "Об уровне национальной олимпиады."

# game/scripts/episode1.rpy:172
translate russian ep1_01_dream_ddaa982c:

    # Maya "She has won a few on national."
    Maya "Она выиграла несколько национальных соревнований."

# game/scripts/episode1.rpy:173
translate russian ep1_01_dream_b0c7f5a3:

    # X "I see. If it's just the math then it's doable."
    X "Понятно. Если дело только в математике, то это вполне осуществимо."

# game/scripts/episode1.rpy:174
translate russian ep1_01_dream_12e7e620:

    # Maya "I don't want it be too much trouble for you."
    Maya "Я не хочу, чтобы это доставляло вам слишком много хлопот."

# game/scripts/episode1.rpy:175
translate russian ep1_01_dream_b8d68cb6:

    # X "With just 2 students it should be fine."
    X "Если всего две ученицы, то всё будет в порядке."

# game/scripts/episode1.rpy:177
translate russian ep1_01_dream_3db11009:

    # Maya "I thought about your line of work. Data engineering right?"
    Maya "Я подумала о вашей профессии. Инженерия данных, верно?"

# game/scripts/episode1.rpy:178
translate russian ep1_01_dream_36f85856:

    # X "Yes."
    X "Да."

# game/scripts/episode1.rpy:179
translate russian ep1_01_dream_b9134ba8:

    # Maya "You apply math regularly no?"
    Maya "Вы регулярно применяете навыки математики, да?"

# game/scripts/episode1.rpy:180
translate russian ep1_01_dream_76715d75:

    # X "That's correct. So it's right up my alley."
    X "Верно. Так что это как раз по моей части."

# game/scripts/episode1.rpy:181
translate russian ep1_01_dream_c29eb0ec:

    # Maya "And so can we come by this afternoon?"
    Maya "Итак, можем ли мы прийти сегодня днем?"

# game/scripts/episode1.rpy:182
translate russian ep1_01_dream_e515079c:

    # X "I'm open."
    X "Конечно."

# game/scripts/episode1.rpy:183
translate russian ep1_01_dream_9ae33d12:

    # Maya "Great! We'll meet you then."
    Maya "Отлично! Тогда ждите нас."

# game/scripts/episode1.rpy:185
translate russian ep1_01_dream_5b37f757:

    # "Same dream again."
    "Снова тот же сон."

# game/scripts/episode1.rpy:187
translate russian ep1_01_dream_7e18f326:

    # "Still can't remember her face..."
    "До сих пор не могу вспомнить её лицо..."

# game/scripts/episode1.rpy:189
translate russian ep1_01_dream_09105b17:

    # "Same dream on the same day."
    "Тот же сон в тот же день."

# game/scripts/episode1.rpy:191
translate russian ep1_01_dream_f12cc627:

    # "Maybe they found something about her."
    "Возможно, они что-то нашли о ней."

# game/scripts/episode1.rpy:193
translate russian ep1_01_dream_8c351382:

    # "Probably not."
    "Скорее всего, нет."

# game/scripts/episode1.rpy:197
translate russian ep1_01_dream_8851854e:

    # "[Charlie] would call if anything came up..."
    "[Charlie] позвонила бы, если бы что-нибудь случилось..."

# game/scripts/episode1.rpy:206
translate russian ep1_01_dream_73c736d3:

    # "Of course it's empty, I barely live here."
    "Конечно, он пустой, я здесь почти не живу."

# game/scripts/episode1.rpy:208
translate russian ep1_01_dream_2584b393:

    # "Restocking for about a week should do it."
    "Этого должно хватить примерно на неделю."

# game/scripts/episode1.rpy:210
translate russian ep1_01_dream_906d84fb:

    # "At least the coffee is in ample supply."
    "По крайней мере, кофе здесь в достатке."

# game/scripts/episode1.rpy:212
translate russian ep1_01_dream_296144e8:

    # "3 days worth of mails, let's get to it."
    "Нужно проверить письма за 3 прошедших дня. Перейду к делу."

# game/scripts/episode1.rpy:214
translate russian ep1_01_dream_daa247e1:

    # "Is the system down?"
    "Система не работает?"

# game/scripts/episode1.rpy:216
translate russian ep1_01_dream_3c0608ff:

    # "Screw it! I'll check them later."
    "К чёрту! Я проверю их позже."

# game/scripts/episode1.rpy:227
translate russian ep1_01_dream_3b84a35e:

    # John "Yeah?"
    John "Да?"

# game/scripts/episode1.rpy:228
translate russian ep1_01_dream_bf10b31a:

    # X "Hey John. How are things at base, any crashes?"
    X "Привет, Джон. Как дела на базе, сбоев нет?"

# game/scripts/episode1.rpy:229
translate russian ep1_01_dream_cafeec82:

    # X "I can't log in to the system."
    X "Я не могу войти в систему."

# game/scripts/episode1.rpy:230
translate russian ep1_01_dream_269dab59:

    # John "[X] you haven't heard?!"
    John "[X], ты ещё не слышал?!"

# game/scripts/episode1.rpy:231
translate russian ep1_01_dream_25650a08:

    # X "Hear what?"
    X "Слышал что?"

# game/scripts/episode1.rpy:232
translate russian ep1_01_dream_cdc8626e:

    # John "The new owner fired the whole department!"
    John "Новый владелец уволил весь отдел!"

# game/scripts/episode1.rpy:235
translate russian ep1_01_dream_f3875f07:

    # X "You're fucking with me."
    X "Ты издеваешься надо мной."

# game/scripts/episode1.rpy:236
translate russian ep1_01_dream_2586049e:

    # John "Read the mail dude."
    John "Прочти почту, чувак."

# game/scripts/episode1.rpy:237
translate russian ep1_01_dream_37115bf9:

    # X "I didn't get any."
    X "Почта пуста."

# game/scripts/episode1.rpy:238
translate russian ep1_01_dream_9d4e5d64:

    # John "The company mail."
    John "Корпоративную почту."

# game/scripts/episode1.rpy:241
translate russian ep1_01_dream_b0509ce9:

    # X "I can't get in the system because they locked me out!"
    X "Я не могу войти в систему, потому что меня заблокировали!"

# game/scripts/episode1.rpy:242
translate russian ep1_01_dream_52426860:

    # John "Oh right."
    John "Ах да."

# game/scripts/episode1.rpy:243
translate russian ep1_01_dream_3738f060:

    # John "I'll send you a copy then."
    John "Тогда я пришлю тебе копию."

# game/scripts/episode1.rpy:246
translate russian ep1_01_dream_f4edd66f:

    # X "Thanks. Were you there when it happened?"
    X "Спасибо. Ты был там, когда это случилось?"

# game/scripts/episode1.rpy:247
translate russian ep1_01_dream_48491ba0:

    # John "Yeah. He called us in for a briefing."
    John "Ага. Он вызвал нас на брифинг."

# game/scripts/episode1.rpy:248
translate russian ep1_01_dream_332596f0:

    # John "Gave a speech for 2 minutes and told everyone to clean out their desks."
    John "Произнёс речь на 2 минуты и велел всем навести порядок на своих столах."

# game/scripts/episode1.rpy:250
translate russian ep1_01_dream_0defbe91:

    # X "Why the fuck did he fire everyone?"
    X "Какого хрена он всех уволил?"

# game/scripts/episode1.rpy:251
translate russian ep1_01_dream_d9cd68c4:

    # John "I'm really not sure. He was going on about 'freezing peaches' or something."
    John "Я правда не знаю. Он говорил о \"замораживании персиков\" или что-то в этом роде."

# game/scripts/episode1.rpy:253
translate russian ep1_01_dream_b030895a:

    # X "What?!"
    X "Чего?!"

# game/scripts/episode1.rpy:254
translate russian ep1_01_dream_d5f85c12:

    # John "I don't know man. Anyway my lawyer said it's an easy suit."
    John "Я не знаю. В любом случае, мой адвокат сказал, что это лёгкий иск."

# game/scripts/episode1.rpy:255
translate russian ep1_01_dream_dacb39a1:

    # John "So there's that."
    John "Вот и всё."

# game/scripts/episode1.rpy:257
translate russian ep1_01_dream_500d72d9:

    # X "I bet."
    X "Не сомневаюсь."

# game/scripts/episode1.rpy:258
translate russian ep1_01_dream_72649d71:

    # John "I'm already set with a new job though."
    John "Хотя я уже определился с новой работой."

# game/scripts/episode1.rpy:259
translate russian ep1_01_dream_71265a20:

    # X "Damn you don't waste a second!"
    X "Блин, не теряешь ни секунды!"

# game/scripts/episode1.rpy:261
translate russian ep1_01_dream_aaf3e746:

    # John "I figured it might happen since so many were leaving. So I was preped for it."
    John "Я подумал, что это может случиться, раз многие уходят. Так что я был готов к этому."

# game/scripts/episode1.rpy:262
translate russian ep1_01_dream_d192347b:

    # John "If you need work I can talk to a friend."
    John "Если тебе нужна работа, я могу поговорить с другом."

# game/scripts/episode1.rpy:263
translate russian ep1_01_dream_16491f63:

    # X "Thanks, I'll think about it."
    X "Спасибо, я подумаю об этом."

# game/scripts/episode1.rpy:264
translate russian ep1_01_dream_4be4e034:

    # John "Well I need to go. I'll be seeing you!"
    John "Что ж, мне нужно идти. Увидимся!"

# game/scripts/episode1.rpy:266
translate russian ep1_01_dream_6588b065:

    # X "Take care man."
    X "Береги себя, парень."

# game/scripts/episode1.rpy:268
translate russian ep1_01_dream_be668c43:

    # "Guess I'll extend my vacation here..."
    "Пожалуй, продлю отпуск..."

# game/scripts/episode1.rpy:271
translate russian ep1_01_dream_55ddeb84:

    # "Whoa, blackberry jam this time!"
    "Вау, на этот раз ежевичное варенье!"

# game/scripts/episode1.rpy:273
translate russian ep1_01_dream_d7535597:

    # "Can't find the sauce, but these are better."
    "Не могу найти соус, но это будет повкуснее."

# game/scripts/episode1.rpy:275
translate russian ep1_01_dream_742012b9:

    # "This will be handy if the sauce turns up too sour."
    "Сахар пригодится, если соус окажется слишком кислым."

# game/scripts/episode1.rpy:277
translate russian ep1_01_dream_deafb577:

    # "Some rice would be nice."
    "Не помешает немного риса."

# game/scripts/episode1.rpy:279
translate russian ep1_01_dream_81c79af5:

    # "[Eileen] would never forgive me if I got bread from somewhere else."
    "[Eileen] никогда бы мне не простила, если бы я взял хлеб где-нибудь в другом месте."

# game/scripts/episode1.rpy:281
translate russian ep1_01_dream_65ead6ea:

    # "No I got time to cook, don't need these."
    "Нет, у меня есть время для готовки, не нуждаюсь в готовой еде."

# game/scripts/episode1.rpy:283
translate russian ep1_01_dream_553430b1:

    # "Potatoes, onions and then there's..."
    "Картошка, лук и кое-что ещё..."

# game/scripts/episode1.rpy:287
translate russian ep1_01_dream_0b7f1812:

    # "???" "Yo we got a shady lookin' mofo' over here!"
    "???" "Эй, у нас тут подозрительный тип!"

# game/scripts/episode1.rpy:289
translate russian ep1_01_dream_67c03dec:

    # "???" "Think he might be a homeless dude."
    "???" "Думаю, он может быть бездомным."

# game/scripts/episode1.rpy:290
translate russian ep1_01_dream_3a0fb633:

    # X "Hey Khalil!"
    X "Привет, Халил!"

# game/scripts/episode1.rpy:292
translate russian ep1_01_dream_24406bad:

    # Khalil "[X]?! Shit, I didn't recognize you man!"
    Khalil "[X]?! Чёрт, я тебя не узнал, бро!"

# game/scripts/episode1.rpy:295
translate russian ep1_01_dream_08c51b71:

    # Khalil "You still rockin' that bum drip."
    Khalil "Ты всё ещё ходишь в этих бомжатских шмотках."

# game/scripts/episode1.rpy:298
translate russian ep1_01_dream_a6afddf5:

    # X "You're talking! With that high-school gear?"
    X "И это говорит тип в одежде для подростков, которые ещё в школу ходят?"

# game/scripts/episode1.rpy:301
translate russian ep1_01_dream_77be11eb:

    # X "Got ID on you? They won't let you buy those beers otherwise."
    X "У тебя есть удостоверение личности? Иначе они не позволят тебе купить это пиво."

# game/scripts/episode1.rpy:304
translate russian ep1_01_dream_bd339a28:

    # Khalil "Man how's it like getting told every time to get out of those swanky stores?"
    Khalil "Чувак, каково это, когда тебе каждый раз говорят убираться из этих шикарных магазинов?"

# game/scripts/episode1.rpy:307
translate russian ep1_01_dream_bc7191a8:

    # X "I bet you get pulled over and asked why you're skipping school."
    X "Держу пари, тебя остановят и спросят, почему ты прогуливаешь школу."

# game/scripts/episode1.rpy:310
translate russian ep1_01_dream_6dfce30f:

    # Khalil "Hey does the pizza guy tip YOU?"
    Khalil "Эй, разносчик пиццы даёт ТЕБЕ чаевые?"

# game/scripts/episode1.rpy:313
translate russian ep1_01_dream_678309d9:

    # X "Haha! What's going on man."
    X "Хаха! Пойдём, парень."

# game/scripts/episode1.rpy:316
translate russian ep1_01_dream_c7db18f8:

    # X "Isn't it a little early to drink?"
    X "Не рановато ли пить?"

# game/scripts/episode1.rpy:319
translate russian ep1_01_dream_7942e86a:

    # Khalil "It's for after training."
    Khalil "Хочу отдохнуть после тренировки."

# game/scripts/episode1.rpy:322
translate russian ep1_01_dream_868299da:

    # Khalil "Got a couple of matches next month."
    Khalil "У меня пара матчей в следующем месяце."

# game/scripts/episode1.rpy:325
translate russian ep1_01_dream_36169fd1:

    # Khalil "So everyday I gotta grind it."
    Khalil "Так что каждый день мне приходится оттачивать свою форму."

# game/scripts/episode1.rpy:328
translate russian ep1_01_dream_b2640c3d:

    # X "Well you did go pro after all."
    X "Ну, в конце концов, ты стал профессионалом."

# game/scripts/episode1.rpy:331
translate russian ep1_01_dream_62b11bd7:

    # Khalil "Yeah. And I got those fuckers to thank."
    Khalil "Да. И я должен поблагодарить этих ублюдков."

# game/scripts/episode1.rpy:332
translate russian ep1_01_dream_1569e76e:

    # X "Had any problems with them lately?"
    X "У тебя были проблемы с ними в последнее время?"

# game/scripts/episode1.rpy:335
translate russian ep1_01_dream_3c278490:

    # Khalil "No, haven't seen them in a bit."
    Khalil "Нет, давненько их уже не видел."

# game/scripts/episode1.rpy:338
translate russian ep1_01_dream_15b1fdc8:

    # Khalil "Anyway I'm going around the block for a hot-dog. Wanna come?"
    Khalil "В любом случае, я собираюсь пройтись за хот-догом. Хочешь со мной?"

# game/scripts/episode1.rpy:341
translate russian ep1_01_dream_993e4099:

    # X "Actually yes, haven't had breakfast yet."
    X "Вообще-то да, я ещё не завтракал."

# game/scripts/episode1.rpy:344
translate russian ep1_01_dream_54bfb293:

    # Khalil "Oh you poor bastard! Come on, it's my treat."
    Khalil "Эх ты, бедный сукин сын! Пойдём, я угощаю."

# game/scripts/episode1.rpy:350
translate russian ep1_01_dream_3c849ffb:

    # Khalil "So he fired all of you?!"
    Khalil "Значит, он уволил вас всех?!"

# game/scripts/episode1.rpy:353
translate russian ep1_01_dream_2157453a:

    # X "Everyone in the department."
    X "Весь отдел."

# game/scripts/episode1.rpy:356
translate russian ep1_01_dream_bf1c7890:

    # Khalil "That fucking asshole! I never liked that guy."
    Khalil "Чёртов мудак! Мне никогда не нравился этот парень."

# game/scripts/episode1.rpy:359
translate russian ep1_01_dream_c589c4a0:

    # X "Maybe it's better actually."
    X "Может, так даже лучше."

# game/scripts/episode1.rpy:362
translate russian ep1_01_dream_c6c2a7af:

    # Khalil "How's that?"
    Khalil "Почему?"

# game/scripts/episode1.rpy:365
translate russian ep1_01_dream_3a06bbdd:

    # X "I got more time to think now. Maybe do something else."
    X "Теперь у меня больше времени на размышления. Может, займусь чем-нибудь другим."

# game/scripts/episode1.rpy:368
translate russian ep1_01_dream_9f173b48:

    # Khalil "Roll with the punches! That's more your style."
    Khalil "Не сдавайся, главное! Ты справишься."

# game/scripts/episode1.rpy:371
translate russian ep1_01_dream_cd3e4aec:

    # Jimmy "How's it going my dudes?"
    Jimmy "Как дела, чуваки?"

# game/scripts/episode1.rpy:374
translate russian ep1_01_dream_bc76f790:

    # Khalil "Just doing my good deed for the day."
    Khalil "Просто делаю доброе дело на сегодня."

# game/scripts/episode1.rpy:375
translate russian ep1_01_dream_d3a8ea10:

    # Khalil "Feeding the hungry over here."
    Khalil "Кормлю голодного."

# game/scripts/episode1.rpy:378
translate russian ep1_01_dream_dd894fa5:

    # X "Yeah real upstanding citizen this guy!"
    X "Да, этот парень - настоящий благородный гражданин!"

# game/scripts/episode1.rpy:381
translate russian ep1_01_dream_bd87e89a:

    # Jimmy "Double up and hold the ketchup, right [X]?"
    Jimmy "Добавить горчицу, верно, [X]?"

# game/scripts/episode1.rpy:382
translate russian ep1_01_dream_c75779cb:

    # X "You know me!"
    X "Ты меня знаешь!"

# game/scripts/episode1.rpy:385
translate russian ep1_01_dream_c7e8f112:

    # Khalil "Extra ketchup here!"
    Khalil "Больше горчицы!"

# game/scripts/episode1.rpy:386
translate russian ep1_01_dream_c8aca5d1:

    # Jimmy "I got you!"
    Jimmy "Понял тебя!"

# game/scripts/episode1.rpy:388
translate russian ep1_01_dream_6e6c98e7:

    # Jimmy "Have a good one you hear!"
    Jimmy "Хорошего дня!"

# game/scripts/episode1.rpy:389
translate russian ep1_01_dream_e0a5e0f4:

    # X "Thanks [Jimmy]!"
    X "Спасибо, [Jimmy]!"

# game/scripts/episode1.rpy:393
translate russian ep1_01_dream_393b1002:

    # X "You finally getting in the big leagues man."
    X "Наконец-то ты попал в высшую лигу, парень."

# game/scripts/episode1.rpy:396
translate russian ep1_01_dream_2b536d65:

    # Khalil "Can't stop till I'm on top!"
    Khalil "Не могу остановиться, пока не окажусь на вершине!"

# game/scripts/episode1.rpy:399
translate russian ep1_01_dream_a8155745:

    # Khalil "You on the other hand got soft."
    Khalil "А ты, наоборот, размягчал."

# game/scripts/episode1.rpy:400
translate russian ep1_01_dream_e055ab94:

    # Khalil "Hanging out with all those tech nerds."
    Khalil "Тусуешься со всеми этими технарями-ботаниками."

# game/scripts/episode1.rpy:403
translate russian ep1_01_dream_d2d6bb29:

    # X "'the fuck you talking about?"
    X "О чём ты блять говоришь?"

# game/scripts/episode1.rpy:404
translate russian ep1_01_dream_1738874d:

    # X "You seem to need a reminder of what I'm capable of."
    X "Похоже, тебе нужно напомнить о том, на что я способен."

# game/scripts/episode1.rpy:406
translate russian ep1_01_dream_f2f0d413:

    # Khalil "Hohoho!"
    Khalil "Хохохо!"

# game/scripts/episode1.rpy:407
translate russian ep1_01_dream_43f7f00a:

    # Khalil "Like I said, I'll be at the gym everyday."
    Khalil "Как я уже сказал, я буду ходить в спортзал каждый день."

# game/scripts/episode1.rpy:409
translate russian ep1_01_dream_4d6a4cd0:

    # Khalil "So feel free to come by and... refresh my memory."
    Khalil "Так что не стесняйся заходить и... освежать мне память."

# game/scripts/episode1.rpy:411
translate russian ep1_01_dream_a694d67c:

    # X "Hey no worries, I won't go too hard."
    X "Эй, не волнуйся, я не буду слишком усердствовать."

# game/scripts/episode1.rpy:412
translate russian ep1_01_dream_7cf95adc:

    # X "Don't want you to get hurt before the match."
    X "Не хочу, чтобы ты получил травму перед матчем."

# game/scripts/episode1.rpy:413
translate russian ep1_01_dream_5d00c6ad:

    # Khalil "You just worry about your own silicone ass."
    Khalil "Ты просто беспокоишься о своей силиконовой заднице."

# game/scripts/episode1.rpy:415
translate russian ep1_01_dream_fbe2ae5b:

    # Khalil "Anyway, gotta bounce."
    Khalil "В любом случае, пора идти."

# game/scripts/episode1.rpy:416
translate russian ep1_01_dream_25703f70:

    # Khalil "Love you man."
    Khalil "Люблю тебя, мужик."

# game/scripts/episode1.rpy:418
translate russian ep1_01_dream_c9f5a398:

    # X "Love you too."
    X "И я тебя."

# game/scripts/episode1.rpy:426
translate russian ep1_01_dream_496efb48:

    # Eileen "I'll be there in a sec!"
    Eileen "Сейчас подойду!"

# game/scripts/episode1.rpy:428
translate russian ep1_01_dream_6926ad3b:

    # Eileen "Well well well!"
    Eileen "Так, так, так!"

# game/scripts/episode1.rpy:429
translate russian ep1_01_dream_7cb7cdef:

    # X "It's been a while [Eileen]. How's business?"
    X "Давненько не виделись, [Eileen]. Как дела?"

# game/scripts/episode1.rpy:431
translate russian ep1_01_dream_eda0837f:

    # Eileen "Can't really complain."
    Eileen "Не жалуюсь."

# game/scripts/episode1.rpy:433
translate russian ep1_01_dream_881fa617:

    # Eileen "Grab a seat, I'll be right up."
    Eileen "Присаживайся, я сейчас подойду."

# game/scripts/episode1.rpy:435
translate russian ep1_01_dream_56bdc7b0:

    # Eileen "Want some coffee?"
    Eileen "Хочешь кофе?"

# game/scripts/episode1.rpy:436
translate russian ep1_01_dream_1604b723:

    # X "I'm good, thanks."
    X "Нет, спасибо."

# game/scripts/episode1.rpy:438
translate russian ep1_01_dream_7983519f:

    # Eileen "So what have you been up to since last year?"
    Eileen "Итак, чем ты занимался с прошлого года?"

# game/scripts/episode1.rpy:445
translate russian ep1_table_chat_176d8531:

    # X "Been busy with the job mostly."
    X "В основном был занят работой."

# game/scripts/episode1.rpy:447
translate russian ep1_table_chat_5d30556f:

    # Eileen "Always working. You barely have time to visit me!"
    Eileen "Всегда работаешь. Ты едва успеваешь навещать меня!"

# game/scripts/episode1.rpy:449
translate russian ep1_table_chat_3b9fd033:

    # X "If it makes you feel better, I'm unemployed now."
    X "Если тебе станет легче, я теперь безработный."

# game/scripts/episode1.rpy:450
translate russian ep1_table_chat_80459c34:

    # X "So I'll have more time for you."
    X "Так что у меня будет больше времени для тебя."

# game/scripts/episode1.rpy:452
translate russian ep1_table_chat_92dfac98:

    # Eileen "How did that happen?"
    Eileen "Как это произошло?"

# game/scripts/episode1.rpy:454
translate russian ep1_table_chat_43f4ec26:

    # Eileen "You didn't beat up someone did you?"
    Eileen "Ты ни с кем не дрался?"

# game/scripts/episode1.rpy:456
translate russian ep1_table_chat_ad70aeb1:

    # X "Come on!"
    X "Да ладно!"

# game/scripts/episode1.rpy:457
translate russian ep1_table_chat_d317da6f:

    # X "Is that how you see me, as some violent thug?"
    X "Так вот каким ты меня видишь, каким-то жестоким головорезом?"

# game/scripts/episode1.rpy:459
translate russian ep1_table_chat_5f208b2a:

    # Eileen "Among other things."
    Eileen "Среди прочего."

# game/scripts/episode1.rpy:461
translate russian ep1_table_chat_ebc23a88:

    # Eileen "So how did it get to that?"
    Eileen "Как ты до этого дошёл?"

# game/scripts/episode1.rpy:463
translate russian ep1_table_chat_c51cec98:

    # X "Not really sure. Think it's because the new boss didn't like me."
    X "Я не совсем уверен. Думаю, просто не понравился новому боссу."

# game/scripts/episode1.rpy:465
translate russian ep1_table_chat_7bac9509:

    # Eileen "That's it?"
    Eileen "И это всё?"

# game/scripts/episode1.rpy:467
translate russian ep1_table_chat_8218579e:

    # X "The e-mail didn't mention any personal work complaints or anything."
    X "В электронном письме не упоминалось о каких-либо жалобах на мою работу или о чём-то ещё."

# game/scripts/episode1.rpy:469
translate russian ep1_table_chat_c104fd22:

    # Eileen "Sounds like a wrongful termination to me. You should sue."
    Eileen "По-моему, это похоже на незаконное увольнение. Ты должен подать в суд."

# game/scripts/episode1.rpy:470
translate russian ep1_table_chat_9faacdf6:

    # X "Maybe you're right."
    X "Возможно, ты права."

# game/scripts/episode1.rpy:472
translate russian ep1_table_chat_22495115:

    # Eileen "Anything else interesting?"
    Eileen "Есть ещё что-нибудь интересное?"

# game/scripts/episode1.rpy:477
translate russian ep1_table_chat_70478e1a:

    # X "Been wanting to workout more."
    X "Захотелось больше тренироваться."

# game/scripts/episode1.rpy:479
translate russian ep1_table_chat_aa37622f:

    # Eileen "Looking to lose some weight?"
    Eileen "Хочешь похудеть?"

# game/scripts/episode1.rpy:481
translate russian ep1_table_chat_e949fa95:

    # X "Not really. Just want to get in shape."
    X "Не совсем. Просто хочу привести себя в форму."

# game/scripts/episode1.rpy:483
translate russian ep1_table_chat_5fa90b92:

    # Eileen "I see. Was worried you might cut back on the sweets."
    Eileen "Понятно. Я испугалась, что ты перестанешь быть сладкоежкой."

# game/scripts/episode1.rpy:484
translate russian ep1_table_chat_922fd927:

    # X "Wouldn't dream of it!"
    X "Даже не мечтай об этом!"

# game/scripts/episode1.rpy:486
translate russian ep1_table_chat_b3f9266b:

    # Eileen "So what made you think about it?"
    Eileen "Так что же заставило тебя задуматься об этом?"

# game/scripts/episode1.rpy:488
translate russian ep1_table_chat_09248379:

    # X "A few times I decide to walk to the office, because of the insane traffic."
    X "Несколько раз я шёл до офиса пешком из-за безумных пробок."

# game/scripts/episode1.rpy:490
translate russian ep1_table_chat_c7665ca2:

    # Eileen "Was it far?"
    Eileen "Какое расстояние?"

# game/scripts/episode1.rpy:492
translate russian ep1_table_chat_a425fc72:

    # X "Not even 2 miles."
    X "Менее трёх километров."

# game/scripts/episode1.rpy:493
translate russian ep1_table_chat_59753416:

    # X "And there I was at the entrance all winded and sweaty."
    X "И вот я уже у входа, весь измотанный и потный."

# game/scripts/episode1.rpy:495
translate russian ep1_table_chat_41c6b2a8:

    # Eileen "Hot!"
    Eileen "Жарко!"

# game/scripts/episode1.rpy:497
translate russian ep1_table_chat_c95691fc:

    # X "It was hot, but it wasn't just that."
    X "Было жарко, но дело не только в этом."

# game/scripts/episode1.rpy:499
translate russian ep1_table_chat_859c3f16:

    # X "So I was thinking of doing some running, heading to the gym for awhile."
    X "Я подумывал о том, чтобы немного побегать, сходить в спортзал."

# game/scripts/episode1.rpy:500
translate russian ep1_table_chat_5a2c9dae:

    # Eileen "[Khalil]'s doing his training there now."
    Eileen "[Khalil] сейчас тренируется там."

# game/scripts/episode1.rpy:501
translate russian ep1_table_chat_bf09086e:

    # X "Yeah we met this morning."
    X "Да, мы встречались сегодня утром."

# game/scripts/episode1.rpy:503
translate russian ep1_table_chat_3d0d3cb3:

    # Eileen "So what other stuff you got?"
    Eileen "Что ещё у тебя есть?"

# game/scripts/episode1.rpy:507
translate russian ep1_table_chat_78555305:

    # X "Actually right now I just want to enjoy some pastries."
    X "На самом деле прямо сейчас я просто хочу полакомиться выпечкой."

# game/scripts/episode1.rpy:509
translate russian ep1_table_chat_a53fb625:

    # Eileen "Ask and ye shall receive!"
    Eileen "Стоит только попросить!"

# game/scripts/episode1.rpy:511
translate russian ep1_table_chat_a35bba76:

    # Eileen "Got all your breads ready."
    Eileen "Твой хлеб готов."

# game/scripts/episode1.rpy:513
translate russian ep1_table_chat_452ffc4e:

    # X "How do you know what I want?"
    X "Откуда ты знаешь, чего я хочу?"

# game/scripts/episode1.rpy:515
translate russian ep1_table_chat_739fb984:

    # Eileen "You get the same thing when you come by this time of year."
    Eileen "В это время года ты всегда хочешь одно и то же, когда приходишь сюда."

# game/scripts/episode1.rpy:517
translate russian ep1_table_chat_b6eb7e9f:

    # Eileen "Then you go make some sandwiches and drive to the beach."
    Eileen "Затем ты делаешь сэндвичи и едёшь на пляж."

# game/scripts/episode1.rpy:518
translate russian ep1_table_chat_fdf4ce24:

    # Eileen "And wait for Emily."
    Eileen "И ждёшь Эмили."

# game/scripts/episode1.rpy:520
translate russian ep1_table_chat_d2c120e4:

    # X "You know me so well."
    X "Ты так хорошо меня знаешь."

# game/scripts/episode1.rpy:522
translate russian ep1_table_chat_1825c8b5:

    # Eileen "Of course I do! We've known each other since school."
    Eileen "Конечно! Мы знакомы со школы."

# game/scripts/episode1.rpy:524
translate russian ep1_table_chat_3b5f8e55:

    # Eileen "I miss her too you know."
    Eileen "Ты знаешь, я тоже по ней скучаю."

# game/scripts/episode1.rpy:526
translate russian ep1_table_chat_6b5ec015:

    # Eileen "By the way, you don't need to come shop here for my sake."
    Eileen "Кстати, тебе не обязательно что-то покупать здесь ради меня."

# game/scripts/episode1.rpy:528
translate russian ep1_table_chat_6b045669:

    # X "What do you mean?"
    X "Что ты имеешь в виду?"

# game/scripts/episode1.rpy:530
translate russian ep1_table_chat_3e63b504:

    # Eileen "Since you can afford the high-end stuff."
    Eileen "Ну, раз уж ты можешь позволить себе дорогие вещи."

# game/scripts/episode1.rpy:536
translate russian ep1_table_chat_b36bc626:

    # X "What are you talking about?"
    X "О чём ты говоришь?"

# game/scripts/episode1.rpy:539
translate russian ep1_table_chat_b41c2ef2:

    # X "Your buns are my favorite!"
    X "Твои булочки - мои любимые!"

# game/scripts/episode1.rpy:541
translate russian ep1_table_chat_66f81dc3:

    # Eileen "That's nice. Thank you."
    Eileen "Очень мило. Спасибо."

# game/scripts/episode1.rpy:543
translate russian ep1_table_chat_9ce986d8:

    # Eileen "Wait a minute!"
    Eileen "Подожди-ка!"

# game/scripts/episode1.rpy:544
translate russian ep1_table_chat_87250884:

    # Eileen "Are you trying to get a discount?"
    Eileen "Ты пытаешься получить скидку?"

# game/scripts/episode1.rpy:546
translate russian ep1_table_chat_8a28a602:

    # X "Hypothetically, if I was, would you give it?"
    X "Гипотетически, если бы это было правдой, ты бы сделала её?"

# game/scripts/episode1.rpy:548
translate russian ep1_table_chat_b7c10ca8:

    # Eileen "Even for such a blatant attempt."
    Eileen "Даже за такую вопиющую попытку..."

# game/scripts/episode1.rpy:549
translate russian ep1_table_chat_faf1288b:

    # Eileen "I have to say yes."
    Eileen "Я должна сказать \"да\"."

# game/scripts/episode1.rpy:551
translate russian ep1_table_chat_eb03b815:

    # X "In that case. I'll take some sweets too."
    X "В таком случае я тоже возьму немного сладостей."

# game/scripts/episode1.rpy:552
translate russian ep1_table_chat_f4f5d1b6:

    # X "Something like an afternoon snack."
    X "Что-то вроде полдника."

# game/scripts/episode1.rpy:553
translate russian ep1_table_chat_7d4a4c45:

    # Eileen "Coming right up."
    Eileen "Сейчас будет."

# game/scripts/episode1.rpy:557
translate russian ep1_table_chat_31510771:

    # X "It's not the same. Yours just taste better."
    X "Они не одни и те же. Твои вкуснее."

# game/scripts/episode1.rpy:559
translate russian ep1_table_chat_9489ba36:

    # X "Like the ones your mom used to make when we were little."
    X "Вроде тех, что готовила твоя мама, когда мы были маленькими."

# game/scripts/episode1.rpy:561
translate russian ep1_table_chat_897fc1fa:

    # Eileen "Okay, I'll happily take that."
    Eileen "Хорошо, мне радостно от твоих слов."

# game/scripts/episode1.rpy:563
translate russian ep1_table_chat_2cd44f4b:

    # X "And can I get some sweet stuff too?"
    X "А можно мне тоже чего-нибудь сладкого?"

# game/scripts/episode1.rpy:564
translate russian ep1_table_chat_f4f5d1b6_1:

    # X "Something like an afternoon snack."
    X "Что-то вроде полдника."

# game/scripts/episode1.rpy:565
translate russian ep1_table_chat_7d4a4c45_1:

    # Eileen "Coming right up."
    Eileen "Сейчас будет."

# game/scripts/episode1.rpy:568
translate russian ep1_table_chat_33917014:

    # Eileen "Are we changing it up this year?"
    Eileen "Будешь что-то менять в этом году?"

# game/scripts/episode1.rpy:571
translate russian ep1_table_chat_06645fbd:

    # X "Just got some tutoring today."
    X "Сегодня займусь репетиторством."

# game/scripts/episode1.rpy:573
translate russian ep1_table_chat_1118314a:

    # X "I figured having some stuff on hand will make it easier."
    X "Я решил, что, имея под рукой кое-какую работу, будет надёжнее."

# game/scripts/episode1.rpy:576
translate russian ep1_table_chat_189c822a:

    # Eileen "Since when are you tutoring?"
    Eileen "С каких это пор ты занимаешься репетиторством?"

# game/scripts/episode1.rpy:578
translate russian ep1_table_chat_6cd10510:

    # X "Since today. Maya called me this morning for a couple of students."
    X "С сегодняшнего дня. Майя позвонила мне сегодня утром по поводу пары учениц."

# game/scripts/episode1.rpy:580
translate russian ep1_table_chat_cad88cab:

    # Eileen "I see."
    Eileen "Понятно."

# game/scripts/episode1.rpy:581
translate russian ep1_table_chat_b195acdc:

    # Eileen "In that case, there's somethings I recommend..."
    Eileen "В таком случае я могу кое-что порекомендовать..."

# game/scripts/episode1.rpy:583
translate russian ep1_table_chat_b07bfd9a:

    # Eileen "We should hang out some time. Catch up properly."
    Eileen "Нам стоит потусоваться как-нибудь. Наверстать упущенное как следует."

# game/scripts/episode1.rpy:585
translate russian ep1_table_chat_a6079e11:

    # X "Are you free this week-end?"
    X "Ты свободна в эти выходные?"

# game/scripts/episode1.rpy:586
translate russian ep1_table_chat_43b46947:

    # Eileen "See you then!"
    Eileen "Да, ещё увидимся!"

# game/scripts/episode1.rpy:590
translate russian ep1_table_chat_652ba305:

    # X "Better tidy up before they get here."
    X "Лучше прибраться до их прихода."

# game/scripts/episode1.rpy:596
translate russian tidy_house_loop_88b5b383:

    # "Get this stuff out of the way."
    "Уберу этот мусор."

# game/scripts/episode1.rpy:602
translate russian tidy_house_loop_8b1c0ae0:

    # "Can't forget the toilet paper."
    "Нельзя забывать о туалетной бумаге."

# game/scripts/episode1.rpy:608
translate russian tidy_house_loop_609a70de:

    # "There."
    "Вот так."

# game/scripts/episode1.rpy:617
translate russian tidy_house_loop_93dbeac8:

    # X "They're here."
    X "Они здесь."

# game/scripts/episode1.rpy:628
translate russian tidy_house_loop_2a62714d:

    # Maya "Good afternoon!"
    Maya "Добрый день!"

# game/scripts/episode1.rpy:629
translate russian tidy_house_loop_ca6c628c:

    # X "Welcome! Come in."
    X "Добро пожаловать! Проходите."

# game/scripts/episode1.rpy:631
translate russian tidy_house_loop_2b6ff13f:

    # Maya "So this is mister [X]!"
    Maya "Итак, это мистер [X]!"

# game/scripts/episode1.rpy:632
translate russian tidy_house_loop_2f8d9d29:

    # Maya "He'll be helping you with mathematics [Sophie]."
    Maya "Он будет помогать тебе с математикой, [Sophie]."

# game/scripts/episode1.rpy:634
translate russian tidy_house_loop_4a86d45b:

    # Sophie "Hello mister [X]."
    Sophie "Здравствуйте, мистер [X]."

# game/scripts/episode1.rpy:635
translate russian tidy_house_loop_24cad18e:

    # X "Hi [Sophie]."
    X "Привет, [Sophie]."

# game/scripts/episode1.rpy:637
translate russian tidy_house_loop_0ffc103b:

    # X "And please, no 'mister'!"
    X "И, пожалуйста, никаких \"мистеров\"!"

# game/scripts/episode1.rpy:639
translate russian tidy_house_loop_350e90f6:

    # "???" "Pretty big house, you live with your wife?"
    "???" "Довольно большой дом, вы живёте с женой?"

# game/scripts/episode1.rpy:640
translate russian tidy_house_loop_56c9a814:

    # X "I'm not married, and it's just me."
    X "Я не женат, живу один."

# game/scripts/episode1.rpy:643
translate russian tidy_house_loop_c13f2787:

    # Maya "And that is [Alecia]."
    Maya "А это [Alecia]."

# game/scripts/episode1.rpy:644
translate russian tidy_house_loop_53a84e5e:

    # Maya "She could use help with most subjects."
    Maya "Ей нужна помощь по большинству предметов."

# game/scripts/episode1.rpy:645
translate russian tidy_house_loop_92db4296:

    # X "I see."
    X "Понял."

# game/scripts/episode1.rpy:647
translate russian tidy_house_loop_e05893ea:

    # X "You can use the living room over there."
    X "Проходите в гостинную."

# game/scripts/episode1.rpy:648
translate russian tidy_house_loop_299b12f3:

    # X "And make yourselves at home."
    X "И чувствуйте себя как дома."

# game/scripts/episode1.rpy:650
translate russian tidy_house_loop_0f967f62:

    # Maya "Can we talk for a bit?"
    Maya "Мы можем немного поговорить?"

# game/scripts/episode1.rpy:651
translate russian tidy_house_loop_4d63f0d3:

    # X "Sure."
    X "Конечно."

# game/scripts/episode1.rpy:653
translate russian tidy_house_loop_cdea5611:

    # Maya "I apologize for asking you to do this."
    Maya "Прошу прощения за то, что попросила вас об этом."

# game/scripts/episode1.rpy:655
translate russian tidy_house_loop_7b60f6ba:

    # Maya "Since you have already helped the orphanage so much."
    Maya "Ведь вы уже и так сильно помогли нашему детскому дому."

# game/scripts/episode1.rpy:657
translate russian tidy_house_loop_1eb26b1f:

    # Maya "But no one has been available for tutoring [Sophie]."
    Maya "Но никто не мог обучать [Sophie]."

# game/scripts/episode1.rpy:659
translate russian tidy_house_loop_6fdd3db2:

    # X "You mentioned she competed and won on nationals."
    X "Вы упомянули, что она участвовала и победила на национальных соревнованиях."

# game/scripts/episode1.rpy:661
translate russian tidy_house_loop_3786fb9e:

    # Maya "That's correct."
    Maya "Верно."

# game/scripts/episode1.rpy:663
translate russian tidy_house_loop_59bf6133:

    # X "So how is it possible that no one's helping her?"
    X "Как же так получилось, что ей никто не помогает?"

# game/scripts/episode1.rpy:665
translate russian tidy_house_loop_9a3f27d9:

    # Maya "All the teachers have very high rates. And we simply cannot afford it."
    Maya "У всех учителей очень высокие тарифы. И мы просто не можем себе их позволить."

# game/scripts/episode1.rpy:668
translate russian tidy_house_loop_07309b2d:

    # X "Wow! Sounds like the market's booming."
    X "Вау! Похоже, рынок процветает."

# game/scripts/episode1.rpy:671
translate russian tidy_house_loop_40fae894:

    # Maya "I wouldn't know."
    Maya "Я не знаю."

# game/scripts/episode1.rpy:674
translate russian tidy_house_loop_813b6764:

    # Maya "But [Sophie] is very diligent!"
    Maya "Но [Sophie] очень старательная!"

# game/scripts/episode1.rpy:677
translate russian tidy_house_loop_f3b965ce:

    # Maya "And if you can do even a few short sessions. That would be of tremendous help."
    Maya "И если вы сможете провести хотя бы несколько коротких сеансов, это окажет огромную помощь."

# game/scripts/episode1.rpy:680
translate russian tidy_house_loop_51da3d7e:

    # Maya "I don't want to add too much to the work you already do."
    Maya "Я не хочу добавлять слишком много к той работе, которую вы уже выполняете."

# game/scripts/episode1.rpy:682
translate russian tidy_house_loop_a68fac55:

    # X "Actually, I'll be free for some time. So there's no need to worry about that."
    X "Вообще-то, я буду свободен некоторое время. Так что не стоит об этом беспокоиться."

# game/scripts/episode1.rpy:683
translate russian tidy_house_loop_a20f3ada:

    # X "Also about [Alecia], what does she need help with?"
    X "И ещё насчёт [Alecia], в чём ей нужна помощь?"

# game/scripts/episode1.rpy:685
translate russian tidy_house_loop_c1b52c76:

    # Maya "She has had some problems with her grades last year."
    Maya "В прошлом году у неё были проблемы с оценками."

# game/scripts/episode1.rpy:687
translate russian tidy_house_loop_fc47d6a0:

    # Maya "Now she has to attend school during the summer along with [Sophie]."
    Maya "Теперь она должна посещать школу летом вместе с [Sophie]."

# game/scripts/episode1.rpy:688
translate russian tidy_house_loop_a4e4d6a6:

    # Maya "She's a smart girl. So what she needs the most is to be convinced to study."
    Maya "Она умная девочка. Так что больше всего её нужно убедить учиться."

# game/scripts/episode1.rpy:690
translate russian tidy_house_loop_db10cfa3:

    # X "Think I got the general picture with both of them."
    X "Думаю, я получил общее представление о них обоих."

# game/scripts/episode1.rpy:692
translate russian tidy_house_loop_6e7304c2:

    # Maya "In that case, I will leave you to it."
    Maya "В таком случае я оставляю вас наедине с ними."

# game/scripts/episode1.rpy:693
translate russian tidy_house_loop_8a32dfc7:

    # Maya "And will return to pick them up."
    Maya "И вернусь, чтобы забрать их, когда придёт время."

# game/scripts/episode1.rpy:694
translate russian tidy_house_loop_3c774ee7:

    # Maya "If there are any issues, you can always call me."
    Maya "Если возникнут какие-то проблемы, вы всегда можете позвонить мне."

# game/scripts/episode1.rpy:696
translate russian tidy_house_loop_0aefb079:

    # Maya "And thank you again!"
    Maya "И ещё раз спасибо вам!"

# game/scripts/episode1.rpy:697
translate russian tidy_house_loop_11ce8c7b:

    # X "Don't mention it."
    X "Да не за что."

# game/scripts/episode1.rpy:699
translate russian tidy_house_loop_6d3d9bd1:

    # Maya "I'm leaving, you girls behave now!"
    Maya "Я ухожу, а вы, девочки, ведите себя прилично!"

# game/scripts/episode1.rpy:700
translate russian tidy_house_loop_4f19e64f:

    # Sophie "Yes miss [Maya]!"
    Sophie "Да, мисс [Maya]!"

# game/scripts/episode1.rpy:701
translate russian tidy_house_loop_a5e0dffc:

    # Alecia "She wasn't talking about you [Sophie]."
    Alecia "Она говорила не о тебе, [Sophie]."

# game/scripts/episode1.rpy:703
translate russian tidy_house_loop_eb7fe8b1:

    # X "I'll show you out."
    X "Я провожу вас."

# game/scripts/episode1.rpy:704
translate russian tidy_house_loop_a7751c10:

    # Maya "No it's okay, I know the way!"
    Maya "Всё в порядке, я знаю дорогу!"

# game/scripts/episode1.rpy:706
translate russian tidy_house_loop_c3fa066f:

    # X "Do you girls want anything to drink or eat?"
    X "Девочки, хотите что-нибудь выпить или поесть?"

# game/scripts/episode1.rpy:708
translate russian tidy_house_loop_dcbb2b46:

    # Sophie "No thank you."
    Sophie "Нет, спасибо."

# game/scripts/episode1.rpy:709
translate russian tidy_house_loop_7e4370ee:

    # Alecia "I'll have some tap water."
    Alecia "Я попью воды из-под крана."

# game/scripts/episode1.rpy:711
translate russian tidy_house_loop_c7f14528:

    # X "Tap water?"
    X "Из-под крана?"

# game/scripts/episode1.rpy:712
translate russian tidy_house_loop_ea215acf:

    # X "I have some fresh orange juice, or pomegranate if you prefer."
    X "У меня есть свежевыжатый апельсиновый сок, или гранатовый, смотря какой любишь."

# game/scripts/episode1.rpy:713
translate russian tidy_house_loop_16e1caf8:

    # Alecia "Tap water's fine."
    Alecia "Вода из-под крана подойдет."

# game/scripts/episode1.rpy:714
translate russian tidy_house_loop_db705120:

    # X "All right."
    X "Хорошо."

# game/scripts/episode1.rpy:716
translate russian tidy_house_loop_71824be5:

    # X "Is that homework?"
    X "Это домашнее задание?"

# game/scripts/episode1.rpy:718
translate russian tidy_house_loop_433997b9:

    # Sophie "Yes, for summer classes."
    Sophie "Да, для летних уроков."

# game/scripts/episode1.rpy:720
translate russian tidy_house_loop_9692137a:

    # X "Cool. You can just go on with that for now."
    X "Круто. Можешь пока продолжать."

# game/scripts/episode1.rpy:722
translate russian tidy_house_loop_5ff2ae21:

    # X "I have to first take a look at the material and remember all of this."
    X "Сначала я должен ознакомиться с материалом и всё запомнить."

# game/scripts/episode1.rpy:724
translate russian tidy_house_loop_bc878c73:

    # Sophie "Okay."
    Sophie "Окей."

# game/scripts/episode1.rpy:726
translate russian tidy_house_loop_3a331ef2:

    # X "Heard you made it all the way to the nationals last year."
    X "Слышал, в прошлом году ты дошла до национальных соревнований."

# game/scripts/episode1.rpy:728
translate russian tidy_house_loop_9747da87:

    # X "Did you study for it all on your own?"
    X "Ты готовилась к ним самостоятельно?"

# game/scripts/episode1.rpy:730
translate russian tidy_house_loop_43cbf7cd:

    # Sophie "I had some help."
    Sophie "Мне кое-кто помогал."

# game/scripts/episode1.rpy:732
translate russian tidy_house_loop_e290d923:

    # Alecia "Getting a few pointers from the teachers after school doesn't count [Sophie]."
    Alecia "Получить несколько советов от учителей после школы не считается, [Sophie]."

# game/scripts/episode1.rpy:734
translate russian tidy_house_loop_59a2fac1:

    # Alecia "She had to do all of it by herself."
    Alecia "Ей пришлось всё делать самой."

# game/scripts/episode1.rpy:736
translate russian tidy_house_loop_d01b2b21:

    # Sophie "The school did pay for the trip."
    Sophie "Школа оплатила поездку."

# game/scripts/episode1.rpy:738
translate russian tidy_house_loop_914a6814:

    # Alecia "Carla got the school to pay for it!"
    Alecia "Карла заставила школу заплатить за неё!"

# game/scripts/episode1.rpy:739
translate russian tidy_house_loop_e4f0ccf5:

    # X "Carla?"
    X "Карла?"

# game/scripts/episode1.rpy:741
translate russian tidy_house_loop_c2a99637:

    # Sophie "The principal."
    Sophie "Директор школы."

# game/scripts/episode1.rpy:743
translate russian tidy_house_loop_97075685:

    # Alecia "She seems like the only one who gives a shit."
    Alecia "Кажется, она единственная, кому не всё равно."

# game/scripts/episode1.rpy:745
translate russian tidy_house_loop_73b8c774:

    # Alecia "Even tried tutoring [Sophie], but she teaches history."
    Alecia "Даже пыталась заниматься репетиторством с [Sophie], но она преподаёт историю."

# game/scripts/episode1.rpy:747
translate russian tidy_house_loop_d9058a23:

    # X "Wow! Is it that bad?"
    X "Вау! Неужели всё так плохо?"

# game/scripts/episode1.rpy:749
translate russian tidy_house_loop_15eca170:

    # Alecia "They all probably think it's not worth bothering for an orphan girl."
    Alecia "Они все, наверное, думают, что не стоит беспокоиться о девочке-сироте."

# game/scripts/episode1.rpy:750
translate russian tidy_house_loop_f7d1ca29:

    # Alecia "And they want boatloads of cash too."
    Alecia "И они также хотят кучу денег."

# game/scripts/episode1.rpy:752
translate russian tidy_house_loop_4288b6d3:

    # Alecia "By the way, are you coming to teach at school or something?"
    Alecia "Кстати, вы собираетесь преподавать в школе или что-то в этом роде?"

# game/scripts/episode1.rpy:754
translate russian tidy_house_loop_409b6d41:

    # X "I don't have any qualifications for that."
    X "У меня для этого нет никакой квалификации."

# game/scripts/episode1.rpy:756
translate russian tidy_house_loop_aae8c194:

    # Alecia "But you ARE being paid for this right?"
    Alecia "Но ведь вам за это платят?"

# game/scripts/episode1.rpy:758
translate russian tidy_house_loop_f925f814:

    # X "Just doing this to help, I don't need any money."
    X "Я просто хочу помочь, мне не нужны деньги."

# game/scripts/episode1.rpy:760
translate russian tidy_house_loop_70484651:

    # Alecia "Is that right..."
    Alecia "Это правильно..."

# game/scripts/episode1.rpy:762
translate russian tidy_house_loop_bdab8637:

    # X "[Sophie], when did you start getting serious with it?"
    X "[Sophie], когда ты начала серьёзно заниматься этим?"

# game/scripts/episode1.rpy:764
translate russian tidy_house_loop_d0021183:

    # Sophie "I have always liked it."
    Sophie "Мне всегда это нравилось."

# game/scripts/episode1.rpy:766
translate russian tidy_house_loop_e29ccd0e:

    # X "I competed in a few rounds myself back in the day."
    X "В своё время я сам участвовал в нескольких этапах."

# game/scripts/episode1.rpy:768
translate russian tidy_house_loop_d14387d0:

    # X "Problem was that I realized that I had a talent for it late."
    X "Проблема была в том, что я поздно осознал, что у меня есть к этому талант."

# game/scripts/episode1.rpy:770
translate russian tidy_house_loop_f6dcf06d:

    # Sophie "Why is that?"
    Sophie "Почему?"

# game/scripts/episode1.rpy:772
translate russian tidy_house_loop_8660952f:

    # X "Wasn't much in to studying for most of my school years."
    X "Большую часть школьных лет я не особо любил учиться."

# game/scripts/episode1.rpy:773
translate russian tidy_house_loop_107c66da:

    # X "Then I found someone who helped me discover it, among other things."
    X "Потом я встретил кое-кого, кто помог мне осознать это, помимо всего прочего."

# game/scripts/episode1.rpy:775
translate russian tidy_house_loop_916bfa84:

    # Sophie "I'm glad that you found it eventually."
    Sophie "Рада, что вы в конце концов осознали это."

# game/scripts/episode1.rpy:777
translate russian tidy_house_loop_e34a1ccb:

    # X "Me too."
    X "И я."

# game/scripts/episode1.rpy:781
translate russian tidy_house_loop_f46d82ef:

    # Alecia "Do you play [X]?"
    Alecia "Вы играете, [X]?"

# game/scripts/episode1.rpy:784
translate russian tidy_house_loop_12dd4d7c:

    # X "Play what?"
    X "Играю во что?"

# game/scripts/episode1.rpy:785
translate russian tidy_house_loop_05c3d683:

    # X "Oh that! I dabble from time to time."
    X "Ах, на нём! Балуюсь время от времени."

# game/scripts/episode1.rpy:788
translate russian tidy_house_loop_eb8fbab2:

    # Alecia "You bought a whole piano just for that?"
    Alecia "Вы купили целое пианино только ради этого?"

# game/scripts/episode1.rpy:789
translate russian tidy_house_loop_77faa7e9:

    # X "No, it's for someone else really. Someone who can actually play it well."
    X "Нет, на самом деле оно для кого-то другого. Для того, кто действительно может хорошо играть."

# game/scripts/episode1.rpy:792
translate russian tidy_house_loop_ec1edbc8:

    # X "You can go ahead if you want."
    X "Можешь попробовать, если хочешь."

# game/scripts/episode1.rpy:793
translate russian tidy_house_loop_fe2eb51c:

    # Alecia "Some other time maybe."
    Alecia "Может, как-нибудь в другой раз."

# game/scripts/episode1.rpy:794
translate russian tidy_house_loop_91417b83:

    # X "And feel free to look around."
    X "И не стесняйся осматриваться."

# game/scripts/episode1.rpy:797
translate russian tidy_house_loop_d7a8715c:

    # X "It's been some time. How about a snack break?"
    X "Прошло уже много времени. Как насчет перерыва на перекус?"

# game/scripts/episode1.rpy:801
translate russian tidy_house_loop_32c36096:

    # X "If you girls don't like these, tell me and I'll bring something else."
    X "Если вам, девочки, это не нравится, скажите мне, и я принесу что-нибудь другое."

# game/scripts/episode1.rpy:804
translate russian tidy_house_loop_9ceb3812:

    # Alecia "Not in to sweets."
    Alecia "Не люблю сладости."

# game/scripts/episode1.rpy:805
translate russian tidy_house_loop_f053eefa:

    # X "I can fix up something else."
    X "Могу придумать что-нибудь ещё."

# game/scripts/episode1.rpy:807
translate russian tidy_house_loop_e226287a:

    # Alecia "Don't bother, I'm not hungry anyway."
    Alecia "Не беспокойтесь, я всё равно не голодна."

# game/scripts/episode1.rpy:811
translate russian tidy_house_loop_140a8acc:

    # X "Suit yourself."
    X "Ну, как хочешь."

# game/scripts/episode1.rpy:814
translate russian tidy_house_loop_56d8df5a:

    # X "You like it Sophie?"
    X "Тебе нравится, Софи?"

# game/scripts/episode1.rpy:817
translate russian tidy_house_loop_38af9192:

    # Sophie "Yes. They taste homemade."
    Sophie "Да. У них домашний вкус."

# game/scripts/episode1.rpy:820
translate russian tidy_house_loop_ab46848e:

    # X "My friend will like to hear that, it's exactly what she was going for."
    X "Моей подруге будет приятно это услышать. Именно этого она и добивалась."

# game/scripts/episode1.rpy:823
translate russian tidy_house_loop_77b0c082:

    # Alecia "Your girlfriend?"
    Alecia "У вас есть девушка?"

# game/scripts/episode1.rpy:826
translate russian tidy_house_loop_68cd65dc:

    # X "Oh no! But we've known each other since grade school."
    X "Эээ, нет! Но мы знаем друг друга с начальной школы."

# game/scripts/episode1.rpy:830
translate russian tidy_house_loop_d3e1843e:

    # Alecia "Where's the bathroom?"
    Alecia "Не подскажете, где туалет?"

# game/scripts/episode1.rpy:833
translate russian tidy_house_loop_75cd702a:

    # X "It's right over there."
    X "Вон прямо там."

# game/scripts/episode1.rpy:835
translate russian tidy_house_loop_2ef9d43d:

    # Alecia "I won't take too long."
    Alecia "Я быстро."

# game/scripts/episode1.rpy:836
translate russian tidy_house_loop_e52bbf9d:

    # X "Ok..."
    X "Ладно..."

# game/scripts/episode1.rpy:838
translate russian tidy_house_loop_efda42f5:

    # Sophie "Are these with chocolate too?"
    Sophie "Они тоже с шоколадом?"

# game/scripts/episode1.rpy:840
translate russian tidy_house_loop_e4366898:

    # X "They have some cream filling. Not sure what exactly."
    X "У них какая-то кремовая начинка. Не уверен, какая именно."

# game/scripts/episode1.rpy:842
translate russian tidy_house_loop_f300265e:

    # Sophie "Hope it's chocolate."
    Sophie "Надеюсь, шоколад."

# game/scripts/episode1.rpy:845
translate russian tidy_house_loop_34ce47d3:

    # Sophie "Oh no!"
    Sophie "О, нет!"

# game/scripts/episode1.rpy:848
translate russian tidy_house_loop_a06b32a8:

    # X "Let me get you a towel!"
    X "Давай я принесу полотенце!"

# game/scripts/episode1.rpy:850
translate russian tidy_house_loop_eb24b15f:

    # Sophie "I'm sorry, I wasn't paying attention!"
    Sophie "Простите, я не заметила!"

# game/scripts/episode1.rpy:852
translate russian tidy_house_loop_520bda97:

    # X "Don't worry about it."
    X "Не беспокойся об этом."

# game/scripts/episode1.rpy:853
translate russian tidy_house_loop_5d52e3e6:

    # X "You should get to the bathroom to dry up."
    X "Тебе следует сходить в туалет, чтобы просохнуть."

# game/scripts/episode1.rpy:855
translate russian tidy_house_loop_bc878c73_1:

    # Sophie "Okay."
    Sophie "Хорошо."

# game/scripts/episode1.rpy:858
translate russian tidy_house_loop_9ad7d671:

    # X "It's up the stairs, left door, just go straight through the bedroom."
    X "Он вверх по лестнице, дверь слева, пройди прямо через спальню."

# game/scripts/episode1.rpy:860
translate russian tidy_house_loop_1a3b80b9:

    # X "There's a drier somewhere."
    X "Где-то там есть сушилка."

# game/scripts/episode1.rpy:861
translate russian tidy_house_loop_27455b67:

    # Sophie "Thank you!"
    Sophie "Спасибо!"

# game/scripts/episode1.rpy:863
translate russian tidy_house_loop_bbb3c637:

    # "I got time to make some sandwiches."
    "У меня есть время сделать несколько сэндвичей."

# game/scripts/episode1.rpy:865
translate russian tidy_house_loop_dee4aaca:

    # "Maybe a few extra for the girls."
    "Может быть, ещё несколько для девочек."

# game/scripts/episode1.rpy:867
translate russian tidy_house_loop_db02c6e8:

    # Alecia "Where's Sophie?"
    Alecia "Где Софи?"

# game/scripts/episode1.rpy:868
translate russian tidy_house_loop_2809f023:

    # X "Oh she went to dry up, had some water spill on her."
    X "Она пошла обсохнуть, облилась водой."

# game/scripts/episode1.rpy:869
translate russian tidy_house_loop_bdffcbe4:

    # Alecia "Where?"
    Alecia "Куда?"

# game/scripts/episode1.rpy:870
translate russian tidy_house_loop_c94fc115:

    # X "The bathroom upstairs."
    X "В туалет наверху."

# game/scripts/episode1.rpy:872
translate russian tidy_house_loop_dd5cdc72:

    # Alecia "Over there?"
    Alecia "Вон там?"

# game/scripts/episode1.rpy:873
translate russian tidy_house_loop_def4ae4b:

    # X "The door on the left there."
    X "Дверь слева."

# game/scripts/episode1.rpy:875
translate russian tidy_house_loop_38d4756d:

    # Alecia "On your left?"
    Alecia "Слева от вас?"

# game/scripts/episode1.rpy:876
translate russian tidy_house_loop_36f85856:

    # X "Yes."
    X "Ага."

# game/scripts/episode1.rpy:878
translate russian tidy_house_loop_4b42e3e4:

    # X "You've been really inquisitive."
    X "Ты действительно любознательна."

# game/scripts/episode1.rpy:879
translate russian tidy_house_loop_1179e61b:

    # X "Do you maybe have some questions about--"
    X "Может быть, у тебя есть вопросы о--"

# game/scripts/episode1.rpy:882
translate russian tidy_house_loop_01f3466e:

    # X "Hey!"
    X "Эй!"

# game/scripts/episode1.rpy:884
translate russian tidy_house_loop_36f2ba59:

    # X "What are you doing??"
    X "Что ты делаешь??"

# game/scripts/episode1.rpy:887
translate russian tidy_house_loop_49800bd8:

    # Alecia "There are two bedrooms upstairs, I checked!"
    Alecia "Наверху две спальни, я проверила!"

# game/scripts/episode1.rpy:890
translate russian tidy_house_loop_7d42b1f5:

    # Alecia "If you hurt Sophie in any way, you won't live to regret it!"
    Alecia "Если причините Софи какую-либо боль, вы пожалеете об этом!"

# game/scripts/episode1.rpy:891
translate russian tidy_house_loop_0e4a0f58:

    # X "Wait! Wait!"
    X "Стоп! Подожди!"

# game/scripts/episode1.rpy:893
translate russian tidy_house_loop_b951b463:

    # X "The bathroom's further down at the end!"
    X "Туалет дальше, в конце коридора!"

# game/scripts/episode1.rpy:896
translate russian tidy_house_loop_37891ca1:

    # Alecia "Oh really?"
    Alecia "О, правда?"

# game/scripts/episode1.rpy:899
translate russian tidy_house_loop_621ef077:

    # Alecia "[Sophie]!"
    Alecia "[Sophie]!"

# game/scripts/episode1.rpy:900
translate russian tidy_house_loop_1b2ced37:

    # Alecia "[Sophie]!!"
    Alecia "[Sophie]!!"

# game/scripts/episode1.rpy:902
translate russian tidy_house_loop_82df79fd:

    # X "She's probably using the dryer right now. So she can't hear."
    X "Она, наверное, сейчас пользуется сушилкой, поэтому не слышит тебя."

# game/scripts/episode1.rpy:905
translate russian tidy_house_loop_e07e2a29:

    # Alecia "Well isn't that convenient!"
    Alecia "Ну разве это не удобно!"

# game/scripts/episode1.rpy:907
translate russian tidy_house_loop_c70702a3:

    # X "Convenient for what??"
    X "Удобно для кого??"

# game/scripts/episode1.rpy:909
translate russian tidy_house_loop_894fb8ed:

    # Alecia "A rich playboy like you!"
    Alecia "Богатого плейбоя вроде вас!"

# game/scripts/episode1.rpy:911
translate russian tidy_house_loop_9a622738:

    # Alecia "Living alone in a massive apartment."
    Alecia "Живёте один в огромной квартире."

# game/scripts/episode1.rpy:914
translate russian tidy_house_loop_bbc83bc6:

    # Alecia "Who takes in some orphan girls, gives them 'treats'."
    Alecia "Принимаете девочек-сирот, угощаете их \"вкусняшками\"."

# game/scripts/episode1.rpy:915
translate russian tidy_house_loop_49d5d590:

    # Alecia "And doing some tutoring for free."
    Alecia "И занимаетесь репетиторством бесплатно."

# game/scripts/episode1.rpy:918
translate russian tidy_house_loop_e4caafd8:

    # Alecia "Then they let their guard down, and you take advantage of them!"
    Alecia "Тогда они теряют бдительность, и вы пользуетесь ими в своих интересах!"

# game/scripts/episode1.rpy:921
translate russian tidy_house_loop_dff0f620:

    # Alecia "People like you just can't wait to see how much they can get away with!"
    Alecia "Такие люди, как вы, просто не могут дождаться, когда им представится такая возможность!"

# game/scripts/episode1.rpy:924
translate russian tidy_house_loop_b887e4a4:

    # X "Alright, you're jumping to conclusions here!"
    X "Эй, ты делаешь поспешные выводы!"

# game/scripts/episode1.rpy:927
translate russian tidy_house_loop_5cbf677e:

    # Alecia "Is that so? Then you must have a good explanation then!"
    Alecia "Правда? Тогда у вас должно быть хорошее объяснение!"

# game/scripts/episode1.rpy:929
translate russian tidy_house_loop_690e0882:

    # Alecia "Right?"
    Alecia "Верно?"

# game/scripts/episode1.rpy:931
translate russian tidy_house_loop_7eccd23e:

    # "This is ridiculous."
    "Это просто смешно."

# game/scripts/episode1.rpy:935
translate russian tidy_house_loop_a0698400:

    # X "Now" 
    X "Сейчас же"

# game/scripts/episode1.rpy:937
translate russian tidy_house_loop_a18b75ab:

    # X "hold"
    X "убери"

# game/scripts/episode1.rpy:939
translate russian tidy_house_loop_d05bb22a:

    # X "the phone!"
    X "руку!"

# game/scripts/episode1.rpy:941
translate russian tidy_house_loop_7a04f0cf:

    # Alecia "I knew it!"
    Alecia "Я так и знала!"

# game/scripts/episode1.rpy:943
translate russian tidy_house_loop_c809fdf5:

    # Alecia "You won't get away with this!"
    Alecia "Вам это не сойдет с рук!"

# game/scripts/episode1.rpy:945
translate russian tidy_house_loop_ace7fb7d:

    # X "Look, Maya called this morning to ask if I can do some tutoring."
    X "Слушай, Майя позвонила сегодня утром и спросила, могу ли я немного позаниматься с вами."

# game/scripts/episode1.rpy:946
translate russian tidy_house_loop_a9fecd1d:

    # X "I told her a while ago that I can do a bunch a things, so we made a list."
    X "Некоторое время назад я сказал ей, что могу многое сделать, и мы составили список."

# game/scripts/episode1.rpy:947
translate russian tidy_house_loop_ad2dc36a:

    # X "It's also not my first time helping out at the orphanage."
    X "Кроме того, я не в первый раз помогаю детскому дому."

# game/scripts/episode1.rpy:949
translate russian tidy_house_loop_28fa20ee:

    # Alecia "Right."
    Alecia "Допустим."

# game/scripts/episode1.rpy:951
translate russian tidy_house_loop_bf4d86a4:

    # Alecia "And why do you care so much?"
    Alecia "Но почему мы вас так волнуем?"

# game/scripts/episode1.rpy:953
translate russian tidy_house_loop_2f31babf:

    # X "I know it's been getting budget cuts every year now."
    X "Я знаю, что бюджет сокращается каждый год."

# game/scripts/episode1.rpy:954
translate russian tidy_house_loop_16bf4552:

    # X "Plus I grew up there!"
    X "К тому же я там вырос!"

# game/scripts/episode1.rpy:956
translate russian tidy_house_loop_af888351:

    # Alecia "At the orphanage?"
    Alecia "В детском доме?"

# game/scripts/episode1.rpy:957
translate russian tidy_house_loop_36f85856_1:

    # X "Yes."
    X "Да."

# game/scripts/episode1.rpy:959
translate russian tidy_house_loop_f00f51d3:

    # Alecia "Well shit!"
    Alecia "Ну и дела!"

# game/scripts/episode1.rpy:962
translate russian tidy_house_loop_4df31bd7:

    # Sophie "Sorry I took so long!"
    Sophie "Простите, что так долго!"

# game/scripts/episode1.rpy:964
translate russian tidy_house_loop_7e480a1f:

    # X "It's Ok. I'm making sandwiches, tell me what you like."
    X "Всё в порядке. Я готовлю сэндвичи. Скажи, что тебе нравится."

# game/scripts/episode1.rpy:966
translate russian tidy_house_loop_364ee442:

    # Sophie "Oh I don't know."
    Sophie "О, я не знаю."

# game/scripts/episode1.rpy:968
translate russian tidy_house_loop_056061cc:

    # Sophie "Whatever is fine."
    Sophie "Что угодно."

# game/scripts/episode1.rpy:971
translate russian tidy_house_loop_ace7fb7d_1:

    # X "Look, Maya called this morning to ask if I can do some tutoring."
    X "Слушай, Майя позвонила сегодня утром и спросила, могу ли я немного позаниматься с вами."

# game/scripts/episode1.rpy:974
translate russian tidy_house_loop_a9fecd1d_1:

    # X "I told her a while ago that I can do a bunch a things, so we made a list."
    X "Некоторое время назад я сказал ей, что могу многое сделать, и мы составили список."

# game/scripts/episode1.rpy:975
translate russian tidy_house_loop_ad2dc36a_1:

    # X "It's also not my first time helping out at the orphanage."
    X "Кроме того, я не в первый раз помогаю детскому дому."

# game/scripts/episode1.rpy:977
translate russian tidy_house_loop_bf4d86a4_1:

    # Alecia "And why do you care so much?"
    Alecia "Но почему мы вас так волнуем?"

# game/scripts/episode1.rpy:979
translate russian tidy_house_loop_2f31babf_1:

    # X "I know it's been getting budget cuts every year now."
    X "Я знаю, что бюджет сокращается каждый год."

# game/scripts/episode1.rpy:980
translate russian tidy_house_loop_16bf4552_1:

    # X "Plus I grew up there!"
    X "К тому же я там вырос!"

# game/scripts/episode1.rpy:982
translate russian tidy_house_loop_af888351_1:

    # Alecia "At the orphanage?"
    Alecia "В детском доме?"

# game/scripts/episode1.rpy:984
translate russian tidy_house_loop_36f85856_2:

    # X "Yes."
    X "Да."

# game/scripts/episode1.rpy:985
translate russian tidy_house_loop_5c02f092:

    # X "Ever since I was little."
    X "С самого детства."

# game/scripts/episode1.rpy:990
translate russian tidy_house_loop_4df31bd7_1:

    # Sophie "Sorry I took so long!"
    Sophie "Простите, что так долго!"

# game/scripts/episode1.rpy:992
translate russian tidy_house_loop_7e480a1f_1:

    # X "It's Ok. I'm making sandwiches, tell me what you like."
    X "Всё в порядке. Я готовлю сэндвичи. Скажи, что тебе нравится."

# game/scripts/episode1.rpy:994
translate russian tidy_house_loop_364ee442_1:

    # Sophie "Oh I don't know."
    Sophie "О, я не знаю."

# game/scripts/episode1.rpy:996
translate russian tidy_house_loop_056061cc_1:

    # Sophie "Whatever is fine."
    Sophie "Что угодно."

# game/scripts/episode1.rpy:999
translate russian tidy_house_loop_7f3039e9:

    # Maya "I'll be running a little late."
    Maya "Я немного опоздаю."

# game/scripts/episode1.rpy:1000
translate russian tidy_house_loop_56f5692c:

    # Maya "Can you stay with them a bit longer please?"
    Maya "Не могли бы вы побыть с ними ещё немного, пожалуйста?"

# game/scripts/episode1.rpy:1001
translate russian tidy_house_loop_b93f52c0:

    # X "I don't mind taking them home."
    X "Я не против сам отвезти их."

# game/scripts/episode1.rpy:1002
translate russian tidy_house_loop_8453baa3:

    # Maya "That would be too much of a bother!"
    Maya "Не нужно. Вы и так делаете слишком много для нас!"

# game/scripts/episode1.rpy:1003
translate russian tidy_house_loop_befdbdfc:

    # X "Actually I'm going out later. And it's on the way, so it's no trouble."
    X "Вообще, я собираюсь развеяться позже. И по сути, мне по пути, так что никаких проблем."

# game/scripts/episode1.rpy:1004
translate russian tidy_house_loop_6d3311da:

    # Maya "In that case, thank you!"
    Maya "В таком случае, спасибо вам!"

# game/scripts/episode1.rpy:1006
translate russian tidy_house_loop_959f4057:

    # X "Here we are!"
    X "А вот и мы!"

# game/scripts/episode1.rpy:1008
translate russian tidy_house_loop_018abb09:

    # Sophie "Thanks mister-- I mean [X]!"
    Sophie "Спасибо, мистер... то есть [X]!"

# game/scripts/episode1.rpy:1010
translate russian tidy_house_loop_4daf4dba:

    # X "Don't forget the food."
    X "Не забудь про еду."

# game/scripts/episode1.rpy:1011
translate russian tidy_house_loop_807a22f7:

    # Sophie "It's in my bag."
    Sophie "Она у меня в рюкзаке."

# game/scripts/episode1.rpy:1012
translate russian tidy_house_loop_536a3923:

    # Alecia "You go ahead Sophie, I'll be there in a minute."
    Alecia "Иди, Софи, я буду через минуту."

# game/scripts/episode1.rpy:1014
translate russian tidy_house_loop_a570c441:

    # Alecia "Hey so... I'm sorry about what I did earlier!"
    Alecia "Эй... Прошу прощения за недавнее недоразумение!"

# game/scripts/episode1.rpy:1015
translate russian tidy_house_loop_4786148d:

    # Alecia "It's fine if you don't want me to come anymore."
    Alecia "Я пойму, если вы больше не захотите меня видеть у себя."

# game/scripts/episode1.rpy:1018
translate russian tidy_house_loop_7d9f27c7:

    # Alecia "But please don't give up on Sophie, she really needs this."
    Alecia "Но, пожалуйста, не отказывайтесь от Софи, вы ей действительно нужны."

# game/scripts/episode1.rpy:1020
translate russian tidy_house_loop_6babfc60:

    # X "I'm not giving up on her, don't worry."
    X "Я не откажусь от неё, не волнуйся."

# game/scripts/episode1.rpy:1021
translate russian tidy_house_loop_e61361d2:

    # X "As far as you're concerned, I want a little more than a 'sorry'."
    X "Что касается тебя, то я хочу немного большего, чем просто \"извините\"."

# game/scripts/episode1.rpy:1023
translate russian tidy_house_loop_7d6ec8ea:

    # Alecia "What do you mean?"
    Alecia "Что вы имеете в виду?"

# game/scripts/episode1.rpy:1025
translate russian tidy_house_loop_e15f3bf8:

    # X "You're going to have to keep coming and also try to actually study something."
    X "Вам придется продолжать приходить, а также пытаться что-то понять."

# game/scripts/episode1.rpy:1026
translate russian tidy_house_loop_4a6008c6:

    # X "Then after that, maybe we can call it even."
    X "И после этого, возможно, мы будем в рассчете."

# game/scripts/episode1.rpy:1028
translate russian tidy_house_loop_58f63b79:

    # Alecia "Are you serious?"
    Alecia "Вы серьёзно?"

# game/scripts/episode1.rpy:1029
translate russian tidy_house_loop_2f504bd0:

    # X "Very."
    X "Ещё как."

# game/scripts/episode1.rpy:1031
translate russian tidy_house_loop_c57de1ef:

    # Alecia "Fine, whatever."
    Alecia "Ладно, как угодно."

# game/scripts/episode1.rpy:1033
translate russian tidy_house_loop_23dc3d25:

    # X "See you next time!"
    X "Увидимся в следующий раз!"

# game/scripts/episode1.rpy:1034
translate russian tidy_house_loop_9a0d4713:

    # Alecia "Sure."
    Alecia "Конечно."

# game/scripts/episode1.rpy:1039
translate russian tidy_house_loop_7a1f909a:

    # "This day certainly broke the monotony."
    "Этот день определенно прервал монотонность."

# game/scripts/episode1.rpy:1040
translate russian tidy_house_loop_14f574dc:

    # "[Alecia] has some trust issues. Can't really blame her."
    "У [Alecia] есть некоторые проблемы с доверием. На самом деле я не могу её винить."

# game/scripts/episode1.rpy:1044
translate russian tidy_house_loop_ac8e9a77:

    # "Did someone else find this place?"
    "Кто-то ещё нашел это место?"

# game/scripts/episode1.rpy:1046
translate russian tidy_house_loop_2c8dfa3f:

    # "Is she..."
    "Это она..."

# game/scripts/episode1.rpy:1049
translate russian tidy_house_loop_2c541bcc:

    # X "[Emily]?!"
    X "[Emily]?!"

# game/scripts/episode1.rpy:1051
translate russian tidy_house_loop_ca274e97:

    # "???" "That was my mom's name."
    "???" "Так звали мою маму."

# game/scripts/episode1.rpy:1052
translate russian tidy_house_loop_77fee8a4:

    # "Her face... she looks just like..."
    "Её лицо... она выглядит точно так же, как..."

# game/scripts/episode1.rpy:1053
translate russian tidy_house_loop_55489514:

    # X "Are you... [D]?"
    X "Ты... [D]?"

# game/scripts/episode1.rpy:1055
translate russian tidy_house_loop_306941fb:

    # D "Yes. W-Who are you?"
    D "Да. К-Кто ты?"

# game/scripts/episode1.rpy:1056
translate russian tidy_house_loop_1266c48b:

    # X "It's OK, my name is [X]. [Emily] and I were in school together."
    X "Всё в порядке, меня зовут [X]. Мы с [Emily] вместе учились в школе."

# game/scripts/episode1.rpy:1058
translate russian tidy_house_loop_9604d1a0:

    # X "She had to leave before we finished it."
    X "Ей пришлось уйти до окончания школы."

# game/scripts/episode1.rpy:1060
translate russian tidy_house_loop_0d61e66f:

    # D "[X]... mom wrote about you."
    D "[X]... мама писала о тебе."

# game/scripts/episode1.rpy:1061
translate russian tidy_house_loop_29f1f4dc:

    # D "She said you were my dad."
    D "Она сказала, что ты мой отец."

# game/scripts/episode1.rpy:1063
translate russian tidy_house_loop_aecf9081:

    # X "I... I am your father?"
    X "Я... я твой отец?"

# game/scripts/episode1.rpy:1066
translate russian tidy_house_loop_7f50e911:

    # D "Yes."
    D "Да."

# game/scripts/episode1.rpy:1070
translate russian tidy_house_loop_030054ca:

    # X "Wow this is..."
    X "Вау, это..."

# game/scripts/episode1.rpy:1072
translate russian tidy_house_loop_af178197:

    # X "Hold on."
    X "Подожди."

# game/scripts/episode1.rpy:1073
translate russian tidy_house_loop_63266438:

    # X "Who did you come here with?"
    X "С кем ты сюда пришла?"

# game/scripts/episode1.rpy:1075
translate russian tidy_house_loop_394ea321:

    # D "I came by myself. Mom wrote that she promised to meet you back here."
    D "Я пришла одна. Мама написала, что обещала встретиться с тобой здесь."

# game/scripts/episode1.rpy:1077
translate russian tidy_house_loop_24b69eaf:

    # D "I didn't know where else to go."
    D "Я не знала, куда ещё пойти."

# game/scripts/episode1.rpy:1079
translate russian tidy_house_loop_c0693580:

    # X "That's right, we promised to meet back here."
    X "Всё верно, мы обещали встретиться здесь."

# game/scripts/episode1.rpy:1080
translate russian tidy_house_loop_cfa0d125:

    # X "I've been...{w=1} coming here ever since."
    X "С тех пор я...{w=1} прихожу сюда."

# game/scripts/episode1.rpy:1081
translate russian tidy_house_loop_9016919f:

    # X "And [Emily]. Where is she now?"
    X "И [Emily]. Где она сейчас?"

# game/scripts/episode1.rpy:1083
translate russian tidy_house_loop_86cdaedf:

    # D "When I was little they... they told me she ran away."
    D "Когда я была маленькой, они... они сказали мне, что она сбежала."

# game/scripts/episode1.rpy:1084
translate russian tidy_house_loop_e0bf2cd8:

    # X "What?"
    X "Что?"

# game/scripts/episode1.rpy:1086
translate russian tidy_house_loop_91223645:

    # D "When I was five, that's when I last saw her."
    D "Когда мне было пять, я видела её в последний раз."

# game/scripts/episode1.rpy:1088
translate russian tidy_house_loop_bd5cf9d6:

    # X "Who told you she ran away?"
    X "Кто тебе сказал, что она сбежала?"

# game/scripts/episode1.rpy:1091
translate russian tidy_house_loop_92059fdc:

    # D "The people I lived with, the ones who adopted her."
    D "Люди, с которыми я жила. Те, кто удочерил её."

# game/scripts/episode1.rpy:1092
translate russian tidy_house_loop_e52fced3:

    # "Her foster parents."
    "Её приемные родители."

# game/scripts/episode1.rpy:1095
translate russian tidy_house_loop_85bcaf67:

    # X "And do they know you're here?"
    X "А они знают, что ты здесь?"

# game/scripts/episode1.rpy:1097
translate russian tidy_house_loop_0aef2935:

    # D "No, I ran away."
    D "Нет, я сбежала."

# game/scripts/episode1.rpy:1098
translate russian tidy_house_loop_3c7bacfa:

    # X "Why?"
    X "Зачем?"

# game/scripts/episode1.rpy:1100
translate russian tidy_house_loop_b993b267:

    # D "They lied to me, they forced my mom to pretend she was a maid!"
    D "Они лгали мне, они заставляли мою маму притворяться горничной!"

# game/scripts/episode1.rpy:1102
translate russian tidy_house_loop_828153d4:

    # D "Achoo!"
    D "Апчхи!"

# game/scripts/episode1.rpy:1104
translate russian tidy_house_loop_bbbe84bf:

    # X "OK we have to go, it's getting cold."
    X "Ладно, нам пора идти, становится холодно."

# game/scripts/episode1.rpy:1106
translate russian tidy_house_loop_e491aa42:

    # X "We'll talk back at the house."
    X "Поговорим дома."

# game/scripts/episode1.rpy:1113
translate russian tidy_house_loop_41a158ff:

    # X "Here we are."
    X "Мы на месте."

# game/scripts/episode1.rpy:1115
translate russian tidy_house_loop_0611bcb3:

    # D "I can see everything outside!"
    D "Я вижу всё снаружи!"

# game/scripts/episode1.rpy:1116
translate russian tidy_house_loop_1ee37d32:

    # X "You like it?"
    X "Тебе нравится?"

# game/scripts/episode1.rpy:1117
translate russian tidy_house_loop_c9c5108e:

    # D "It's amazing!"
    D "Это потрясающе!"

# game/scripts/episode1.rpy:1119
translate russian tidy_house_loop_33c6f71d:

    # X "Are you hungry? Do you want something to eat?"
    X "Ты голодна? Хочешь что-нибудь поесть?"

# game/scripts/episode1.rpy:1120
translate russian tidy_house_loop_c737905d:

    # D "Yes please."
    D "Да, пожалуйста."

# game/scripts/episode1.rpy:1123
translate russian tidy_house_loop_a72e967b:

    # X "I don't have anything ready but these."
    X "У меня нет ничего готового, кроме них."

# game/scripts/episode1.rpy:1124
translate russian tidy_house_loop_710f1f75:

    # D "It's fine, thank you!"
    D "Подойдёт, спасибо!"

# game/scripts/episode1.rpy:1127
translate russian tidy_house_loop_3d0eaba9:

    # X "Is it far where you came from?"
    X "Далеко ли это место, откуда ты пришла?"

# game/scripts/episode1.rpy:1128
translate russian tidy_house_loop_42a0cffb:

    # X "How long have you been on the road?"
    X "Как долго ты была в пути?"

# game/scripts/episode1.rpy:1131
translate russian tidy_house_loop_693446b4:

    # D "It's been 6 days I think."
    D "Дней шесть, мне кажется."

# game/scripts/episode1.rpy:1134
translate russian tidy_house_loop_565b9a33:

    # X "I'm sorry, didn't ask for your name."
    X "Прости, я не спросил твоего имени."

# game/scripts/episode1.rpy:1137
translate russian tidy_house_loop_e08eddeb:

    # D "I don't want my name."
    D "Мне не нужно имя."

# game/scripts/episode1.rpy:1140
translate russian tidy_house_loop_fec69eda:

    # X "You don't WANT your name?"
    X "Ты не ХОЧЕШЬ иметь имя?"

# game/scripts/episode1.rpy:1143
translate russian tidy_house_loop_21dd2d25:

    # D "It's the same one they gave to my mom."
    D "Его подарили моей маме."

# game/scripts/episode1.rpy:1146
translate russian tidy_house_loop_e94db809:

    # D "I hate it!"
    D "Я ненавижу его!"

# game/scripts/episode1.rpy:1149
translate russian tidy_house_loop_441cead2:

    # X "OK. So then what should I call you?"
    X "Окей. Тогда как же мне тебя называть?"

# game/scripts/episode1.rpy:1152
translate russian tidy_house_loop_bf8fda76:

    # D "You choose it!"
    D "Выбирай сам!"

# game/scripts/episode1.rpy:1153
translate russian tidy_house_loop_e0bf2cd8_1:

    # X "What?"
    X "Что?"

# game/scripts/episode1.rpy:1156
translate russian tidy_house_loop_7a5d3e00:

    # D "You are my dad after all."
    D "В конце концов, ты мой отец."

# game/scripts/episode1.rpy:1159
translate russian tidy_house_loop_64d557e3:

    # X "Yeah I'm still trying to wrap my head around that."
    X "Да, я всё ещё пытаюсь осознать это."

# game/scripts/episode1.rpy:1160
translate russian tidy_house_loop_038d6295:

    # X "But if you want, I could just call you--"
    X "Но если хочешь, я могу просто звать тебя--"

# game/scripts/episode1.rpy:1162
translate russian tidy_house_loop_e68f6a69:

    # D "Wait!"
    D "Стой!"

# game/scripts/episode1.rpy:1165
translate russian tidy_house_loop_9248edc0:

    # D "Not yet."
    D "Пока не надо."

# game/scripts/episode1.rpy:1168
translate russian tidy_house_loop_fd09bcff:

    # D "I'll go outside in front of the door..."
    D "Я выйду на улицу и встану перед дверью..."

# game/scripts/episode1.rpy:1171
translate russian tidy_house_loop_34b2ba36:

    # D "You open it and then say it!"
    D "Ты откроешь её и скажешь моё имя!"

# game/scripts/episode1.rpy:1172
translate russian tidy_house_loop_201fd5f5:

    # X "That's... sure! We'll do it your way."
    X "Это... конечно! Мы сделаем это по-твоему."

# game/scripts/episode1.rpy:1175
translate russian tidy_house_loop_9be9bbae:

    # "They gave the same name to [Emily]?"
    "Они таким же образом назвали [Emily]?"

# game/scripts/episode1.rpy:1176
translate russian tidy_house_loop_eda2aaa6:

    # "That's strange."
    "Это странно."

# game/scripts/episode1.rpy:1177
translate russian tidy_house_loop_c894bb30:

    # "And I'm a father, it must have been that time at the beach..."
    "И я отец. Должно быть, это произошло в тот раз на пляже..."

# game/scripts/episode1.rpy:1188
translate russian tidy_house_loop_14df273a:

    # X "I'm opening the door."
    X "Я открываю дверь."

# game/scripts/episode1.rpy:1190
translate russian tidy_house_loop_e1d8fdbc:

    # X "Hello [D]!"
    X "Привет, [D]!"

# game/scripts/episode1.rpy:1192
translate russian tidy_house_loop_4c8eea32:

    # D "Hi dad!"
    D "Привет, папа!"

# game/scripts/episode1.rpy:1194
translate russian tidy_house_loop_09a1d11b:

    # D "{font=fonts/NotoEmoji-Bold.ttf}{color=#69094c}🥱{/font}"
    D "{font=fonts/NotoEmoji-Bold.ttf}{color=#69094c}🥱{/font}"

# game/scripts/episode1.rpy:1195
translate russian tidy_house_loop_a24fabad:

    # X "You must be tired."
    X "Ты, наверное, устала."

# game/scripts/episode1.rpy:1197
translate russian tidy_house_loop_a5b357d4:

    # X "I'll go run a bath. Then show you where you'll be sleeping."
    X "Я пойду приготовлю ванну, а потом покажу твою спальню."

# game/scripts/episode1.rpy:1200
translate russian tidy_house_loop_518899a8:

    # X "This is your room."
    X "Это твоя комната."

# game/scripts/episode1.rpy:1203
translate russian tidy_house_loop_36ceaf43:

    # X "You can leave your clothes in the hamper."
    X "Одежду можешь оставить в корзине для белья."

# game/scripts/episode1.rpy:1204
translate russian tidy_house_loop_b53f3e25:

    # X "You've got towels, soaps and everything there."
    X "Там есть полотенца, мыло и всё остальное."

# game/scripts/episode1.rpy:1205
translate russian tidy_house_loop_7499843e:

    # X "I'll find something for you to wear."
    X "Я пойду поищу, что тебе надеть."

# game/scripts/episode1.rpy:1207
translate russian tidy_house_loop_beec3fc5:

    # D "Okay."
    D "Хорошо."

# game/scripts/episode1.rpy:1209
translate russian tidy_house_loop_508b80cd:

    # "All done here."
    "Всё готово."

# game/scripts/episode1.rpy:1211
translate russian tidy_house_loop_36d0fb36:

    # X "I only have my own clothes."
    X "У меня есть только своя одежда."

# game/scripts/episode1.rpy:1212
translate russian tidy_house_loop_93b88678:

    # X "It'll have to do for now."
    X "Пока её будет достаточно."

# game/scripts/episode1.rpy:1214
translate russian tidy_house_loop_899b1c9a:

    # D "I don't mind."
    D "Я не против."

# game/scripts/episode1.rpy:1216
translate russian tidy_house_loop_de9888c2:

    # X "Just pick whatever you want out of the wardrobe."
    X "Выбери из гардероба всё, что захочешь."

# game/scripts/episode1.rpy:1218
translate russian tidy_house_loop_c1fd4ac5:

    # X "Bed's made and ready."
    X "Постель заправлена и готова."

# game/scripts/episode1.rpy:1221
translate russian tidy_house_loop_7ec63a7d:

    # X "I'll leave you to get dressed then."
    X "Я оставлю тебя одеваться."

# game/scripts/episode1.rpy:1223
translate russian tidy_house_loop_7c55a997:

    # D "Thank you!"
    D "Спасибо!"

# game/scripts/episode1.rpy:1225
translate russian tidy_house_loop_22d38537:

    # X "You're welcome!"
    X "Пожалуйста!"

# game/scripts/episode1.rpy:1227
translate russian tidy_house_loop_e2edf103:

    # "Forgot to mention a few things."
    "Забыл упомянуть ещё кое-что."

# game/scripts/episode1.rpy:1233
translate russian tidy_house_loop_6e184a1c:

    # X "[D], can I come in?"
    X "[D], могу я войти?"

# game/scripts/episode1.rpy:1235
translate russian tidy_house_loop_7f50e911_1:

    # D "Yes."
    D "Да."

# game/scripts/episode1.rpy:1241
translate russian tidy_house_loop_114c4d8b:

    # "Ooops..."
    "Упс..."

# game/scripts/episode1.rpy:1244
translate russian tidy_house_loop_6e184a1c_1:

    # X "[D], can I come in?"
    X "[D], могу я войти?"

# game/scripts/episode1.rpy:1246
translate russian tidy_house_loop_7f50e911_2:

    # D "Yes."
    D "Да."

# game/scripts/episode1.rpy:1249
translate russian tidy_house_loop_cd7dc865:

    # X "If you're still hungry, I can make you something."
    X "Если ты всё ещё голодна, я могу что-нибудь приготовить."

# game/scripts/episode1.rpy:1251
translate russian tidy_house_loop_c1863690:

    # D "No, it's fine."
    D "Нет, всё в порядке."

# game/scripts/episode1.rpy:1253
translate russian tidy_house_loop_c6bec13b:

    # X "Ok, but if you get hungry, go ahead and eat whatever you want."
    X "Хорошо, но если проголодаешься, ешь всё, что хочешь."

# game/scripts/episode1.rpy:1255
translate russian tidy_house_loop_22343be8:

    # D "I understand, thanks you!"
    D "Поняла, спасибо!"

# game/scripts/episode1.rpy:1259
translate russian tidy_house_loop_e018061f:

    # "I need to look in to who these people are."
    "Мне нужно выяснить, кто эти люди."

# game/scripts/episode1.rpy:1260
translate russian tidy_house_loop_2c6f0f12:

    # "Wait! Forgot to ask about them!"
    "Стоп! Забыл спросить о них!"

# game/scripts/episode1.rpy:1263
translate russian tidy_house_loop_064739ce:

    # X "[D]."
    X "[D]."

# game/scripts/episode1.rpy:1264
translate russian tidy_house_loop_5ad9f54f:

    # X "I need to you ask you about a few things!"
    X "Мне нужно тебя кое о чём спросить!"

# game/scripts/episode1.rpy:1266
translate russian tidy_house_loop_5036f8f9:

    # "Not answering..."
    "Не отвечает..."

# game/scripts/episode1.rpy:1269
translate russian tidy_house_loop_a310f992:

    # "Fast asleep. She must have been exhausted."
    "Крепко спит. Должно быть, она устала."

# game/scripts/episode1.rpy:1271
translate russian tidy_house_loop_f4d9c83c:

    # "Maybe they lied about her disapearing."
    "Может, они солгали, что она исчезла?"

# game/scripts/episode1.rpy:1272
translate russian tidy_house_loop_d34da59d:

    # "I need to find out what happened."
    "Мне нужно выяснить, что произошло."

# game/scripts/episode1.rpy:1274
translate russian tidy_house_loop_e049d492:

    # "Gotta try and get some rest."
    "Нужно постараться отдохнуть."

# game/scripts/episode1.rpy:1276
translate russian tidy_house_loop_5023866e:

    # "I need a clear head for all of this"
    "Мне нужна ясная голова для всего этого."

# game/scripts/episode1.rpy:1280
translate russian tidy_house_loop_b622a3d9:

    # "???" "{cps=10}Don't let her go...{w=1}"
    "???" "{cps=10}Не отпускай её...{w=1}"

# game/scripts/episode1.rpy:1283
translate russian tidy_house_loop_83f5a149:

    # X "[Emily]!"
    X "[Emily]!"

# game/scripts/episode1.rpy:1285
translate russian tidy_house_loop_a1debcb2:

    # "Was that another dream?"
    "Это был ещё один сон?"

# game/scripts/episode1.rpy:1286
translate russian tidy_house_loop_28d58032:

    # "Can't recall anything..."
    "Не могу ничего вспомнить..."

# game/scripts/episode1.rpy:1288
translate russian tidy_house_loop_be8a95df:

    # "What's that smell?"
    "Что за запах?"

# game/scripts/episode1.rpy:1292
translate russian tidy_house_loop_2a1f302c:

    # "So it wasn't all a dream..."
    "Значит, это был не сон..."

# game/scripts/episode1.rpy:1294
translate russian tidy_house_loop_844e8ecd:

    # X "Good morning!"
    X "Доброе утро!"

# game/scripts/episode1.rpy:1295
translate russian tidy_house_loop_e5fd2ed1:

    # D "Good morning!"
    D "Доброе!"

# game/scripts/episode1.rpy:1296
translate russian tidy_house_loop_6ca9fae3:

    # D "I made breakfast since I ate your sandwiches yesterday."
    D "Я приготовила завтрак, так как вчера съела твои сэндвичи."

# game/scripts/episode1.rpy:1298
translate russian tidy_house_loop_27e1d7ef:

    # D "Have a seat, it's almost ready."
    D "Присаживайся, всё почти готово."

# game/scripts/episode1.rpy:1300
translate russian tidy_house_loop_1e94a351:

    # D "I didn't know what you liked so I varied it."
    D "Я не знала, что тебе нравится, поэтому разнообразила его."

# game/scripts/episode1.rpy:1302
translate russian tidy_house_loop_4674549c:

    # X "It's a treat!"
    X "Вкуснотища!"

# game/scripts/episode1.rpy:1304
translate russian tidy_house_loop_b55c7a1f:

    # X "But you didn't have to."
    X "Но тебе не нужно было этого делать."

# game/scripts/episode1.rpy:1306
translate russian tidy_house_loop_aa25042f:

    # D "It's fine, I enjoy cooking."
    D "Всё в порядке, мне нравится готовить."

# game/scripts/episode1.rpy:1308
translate russian tidy_house_loop_064739ce_1:

    # X "[D]."
    X "[D]."

# game/scripts/episode1.rpy:1310
translate russian tidy_house_loop_6584dbf5:

    # D "Yes?"
    D "Да?"

# game/scripts/episode1.rpy:1312
translate russian tidy_house_loop_6b789f98:

    # X "Are you sure you want me calling you that?"
    X "Ты уверена, что согласна, чтобы я тебя так называл?"

# game/scripts/episode1.rpy:1314
translate russian tidy_house_loop_c8c729eb:

    # D "I like it!"
    D "Да, мне нравится так!"

# game/scripts/episode1.rpy:1316
translate russian tidy_house_loop_c6a0adb0:

    # D "If you're sure..."
    D "Ну если ты так уверена..."

# game/scripts/episode1.rpy:1319
translate russian tidy_house_loop_917e4d06:

    # X "About the people you stayed with."
    X "О людях, с которыми ты была."

# game/scripts/episode1.rpy:1321
translate russian tidy_house_loop_84bc4a09:

    # X "I need to know some stuff about them."
    X "Мне нужно кое-что о них узнать."

# game/scripts/episode1.rpy:1324
translate russian tidy_house_loop_1696fe15:

    # X "If you're worried."
    X "Если ты беспокоишься..."

# game/scripts/episode1.rpy:1327
translate russian tidy_house_loop_dd17bfea:

    # X "I won't tell them about you. I promise!"
    X "Я не расскажу им о тебе. Обещаю!"

# game/scripts/episode1.rpy:1329
translate russian tidy_house_loop_025868f9:

    # D "Their names are [Radford] and [Odelia], and they called me Adalinda."
    D "Их зовут [Radford] и [Odelia], а меня они называли Адалиндой."

# game/scripts/episode1.rpy:1331
translate russian tidy_house_loop_a649a0c8:

    # X "Do you know the address of the house?"
    X "Ты знаешь адрес их дома?"

# game/scripts/episode1.rpy:1333
translate russian tidy_house_loop_7f50e911_3:

    # D "Yes."
    D "Да."

# game/scripts/episode1.rpy:1335
translate russian tidy_house_loop_809ec91e:

    # X "And they told you that [Emily] was just a maid?"
    X "И они сказали тебе, что [Emily] была просто горничной?"

# game/scripts/episode1.rpy:1338
translate russian tidy_house_loop_d2e9d562:

    # D "She was the one who took care of me when I was little."
    D "Она была единственной, кто заботился обо мне, когда я была маленькой."

# game/scripts/episode1.rpy:1340
translate russian tidy_house_loop_747223ad:

    # X "You mentioned she wrote this somewhere."
    X "Ты упомянула, что она где-то это написала."

# game/scripts/episode1.rpy:1343
translate russian tidy_house_loop_3791ba5c:

    # D "Yes, a journal. Buried in the grounds."
    D "Да, в дневнике. Он закопан."

# game/scripts/episode1.rpy:1344
translate russian tidy_house_loop_06f4379e:

    # D "It started from after I was born."
    D "Он начинается с моего рождения."

# game/scripts/episode1.rpy:1346
translate russian tidy_house_loop_a5e2ef97:

    # X "And they called you both [Adalinda]?"
    X "И они назвали вас обеих [Adalinda]?"

# game/scripts/episode1.rpy:1349
translate russian tidy_house_loop_5f73d8dd:

    # D "When she was adopted, they changed her name."
    D "Когда её удочерили, они сменили ей имя."

# game/scripts/episode1.rpy:1351
translate russian tidy_house_loop_6bc8e731:

    # D "But after I was born they called me by that. And she became [Emily] again."
    D "Но после моего рождения они стали называть меня её новым именем. А она снова стала [Emily]."

# game/scripts/episode1.rpy:1352
translate russian tidy_house_loop_8e6b2e82:

    # X "That is not right!"
    X "Это неправильно!"

# game/scripts/episode1.rpy:1354
translate russian tidy_house_loop_6f9a2dd9:

    # X "Have you tried talking to other people, at school maybe?"
    X "Ты пробовала поговорить с другими людьми, например, в школе?"

# game/scripts/episode1.rpy:1356
translate russian tidy_house_loop_df4c5fcb:

    # D "I wasn't in school. A tutor came by sometimes."
    D "Я не училась в школе. Иногда приходил репетитор."

# game/scripts/episode1.rpy:1358
translate russian tidy_house_loop_a663f98d:

    # X "So you were home-schooled for most of your life?"
    X "Значит, большую часть жизни ты была на домашнем обучении?"

# game/scripts/episode1.rpy:1360
translate russian tidy_house_loop_4a9f6159:

    # D "They told me that the outside world was too dangerous, that it would corrupt me."
    D "Они говорили мне, что внешний мир слишком опасен, что он развратит меня."

# game/scripts/episode1.rpy:1361
translate russian tidy_house_loop_a6a0cca1:

    # "What the hell..."
    "Какого чёрта..."

# game/scripts/episode1.rpy:1363
translate russian tidy_house_loop_811c11bd:

    # X "Did you meet other people besides them?"
    X "Встречалась ли ты с другими людьми, кроме них?"

# game/scripts/episode1.rpy:1366
translate russian tidy_house_loop_fae67871:

    # D "I wasn't allowed outside the grounds."
    D "Мне не разрешалось выходить за пределы участка."

# game/scripts/episode1.rpy:1369
translate russian tidy_house_loop_0363ef9c:

    # X "What about medical checkups? When have you last seen a doctor?"
    X "А как же медицинские осмотры? Когда ты в последний раз посещала врача?"

# game/scripts/episode1.rpy:1371
translate russian tidy_house_loop_82349ea9:

    # D "I think he has visited maybe three years ago."
    D "Думаю, он приезжал года три назад."

# game/scripts/episode1.rpy:1372
translate russian tidy_house_loop_5da626e9:

    # "Of course..."
    "Конечно..."

# game/scripts/episode1.rpy:1374
translate russian tidy_house_loop_09a1d11b_1:

    # D "{font=fonts/NotoEmoji-Bold.ttf}{color=#69094c}🥱{/font}"
    D "{font=fonts/NotoEmoji-Bold.ttf}{color=#69094c}🥱{/font}"

# game/scripts/episode1.rpy:1375
translate russian tidy_house_loop_7d026639:

    # X "How and where have you been sleeping?"
    X "Как и где ты спала?"

# game/scripts/episode1.rpy:1378
translate russian tidy_house_loop_5bb3a95e:

    # D "On the train, the bus, once in a library."
    D "В поезде, в автобусе, однажды в библиотеке."

# game/scripts/episode1.rpy:1380
translate russian tidy_house_loop_8906e483:

    # X "Figures, you couldn't have slept well."
    X "Судя по всему, ты не могла хорошо выспаться."

# game/scripts/episode1.rpy:1381
translate russian tidy_house_loop_9d10fb38:

    # X "Better go get more rest, don't push yourself."
    X "Лучше отдохни, не изнуряй себя."

# game/scripts/episode1.rpy:1383
translate russian tidy_house_loop_8fe0f840:

    # D "I'll be up before lunch."
    D "Я встану до обеда."

# game/scripts/episode1.rpy:1385
translate russian tidy_house_loop_5ab6b4df:

    # X "Don't worry about cooking if that's what you're thinking!"
    X "Не беспокойся о готовке, если ты об ней думаешь!"

# game/scripts/episode1.rpy:1386
translate russian tidy_house_loop_d2133371:

    # X "I can do that. Just sleep as much as you need."
    X "Я могу сам это сделать. Спи сколько захочешь."

# game/scripts/episode1.rpy:1388
translate russian tidy_house_loop_31273e68:

    # D "I understand..."
    D "Поняла..."

# game/scripts/episode1.rpy:1392
translate russian tidy_house_loop_059d04b4:

    # X "...yes a full checkup, as soon as possible."
    X "...да, полное обследование, как можно скорее."

# game/scripts/episode1.rpy:1393
translate russian tidy_house_loop_9d19f666:

    # "Operator" "I see your insurance has recently been canceled mister [X]."
    "Оператор" "Ваша страховка недавно была аннулирована, мистер [X]."

# game/scripts/episode1.rpy:1394
translate russian tidy_house_loop_4020b891:

    # "Well that was fast."
    "Что ж, а они быстрые."

# game/scripts/episode1.rpy:1395
translate russian tidy_house_loop_c88f6336:

    # X "That doesn't matter, it's not for me. It's for a young girl, my... dad."
    X "Это неважно, обследование не меня, а молодой девушки, моей... дочери."

# game/scripts/episode1.rpy:1396
translate russian tidy_house_loop_a6f736dc:

    # "Operator" "I see."
    "Оператор" "Понятно."

# game/scripts/episode1.rpy:1397
translate russian tidy_house_loop_8744b8e0:

    # "Operator" "In that case we can schedule you for tomorrow."
    "Оператор" "В таком случае мы можем записать вас на завтра."

# game/scripts/episode1.rpy:1398
translate russian tidy_house_loop_6d476863:

    # "Operator" "However that is a premium option, so the fees are higher."
    "Оператор" "Однако это премиум-опция, поэтому плата за неё выше."

# game/scripts/episode1.rpy:1399
translate russian tidy_house_loop_8e951ecd:

    # X "That's fine, I'll pay whatever it costs."
    X "Отлично. Я заплачу, сколько бы она ни стоила."

# game/scripts/episode1.rpy:1400
translate russian tidy_house_loop_04563b8b:

    # "Operator" "OK then! And what name should I put the patient under?"
    "Оператор" "Тогда окей! И под каким именем мне следует зарегистрировать пациентку?"

# game/scripts/episode1.rpy:1401
translate russian tidy_house_loop_064739ce_2:

    # X "[D]."
    X "[D]."

# game/scripts/episode1.rpy:1403
translate russian tidy_house_loop_7d811a66:

    # "Operator" "Done! You have the first appointment tomorrow at 9 o'clock."
    "Оператор" "Готово! Первый приём состоится завтра в 9 часов."

# game/scripts/episode1.rpy:1404
translate russian tidy_house_loop_0678ef4d:

    # "Operator" "Have a good day mister [X]!"
    "Оператор" "Хорошего дня, мистер [X]!"

# game/scripts/episode1.rpy:1410
translate russian tidy_house_loop_d0029623:

    # "No wonder I didn't find her, there are barely any records about them."
    "Неудивительно, что я её не нашел, записей о них почти нет."

# game/scripts/episode1.rpy:1411
translate russian tidy_house_loop_fc6cc3de:

    # "At least [Charlie] has some leads to go by now..."
    "По крайней мере, у [Charlie] уже есть кое-какие зацепки..."

# game/scripts/episode1.rpy:1418
translate russian tidy_house_loop_f5786a36:

    # D "dad!"
    D "Папа!"

# game/scripts/episode1.rpy:1420
translate russian tidy_house_loop_5cbaae6f:

    # X "Yes [D]?"
    X "Да, [D]?"

# game/scripts/episode1.rpy:1421
translate russian tidy_house_loop_41dda929:

    # D "Is that... a television?"
    D "Это что... телевизор?"

# game/scripts/episode1.rpy:1424
translate russian tidy_house_loop_aaa78443:

    # X "The fact that you refer to it like that, and that you have to ask."
    X "Тот факт, что ты это так произнесла, и то что ты спрашиваешь о нём..."

# game/scripts/episode1.rpy:1426
translate russian tidy_house_loop_5909d188:

    # X "Leads me to think you didn't have one."
    X "Наводит меня на мысль, что у тебя его не было."

# game/scripts/episode1.rpy:1429
translate russian tidy_house_loop_eea6b9ec:

    # D "There was one, but it was big, and more like a box."
    D "Один был, но большой и больше походил на коробку."

# game/scripts/episode1.rpy:1431
translate russian tidy_house_loop_adef9cc1:

    # X "Those are really old."
    X "Наверное, очень старый."

# game/scripts/episode1.rpy:1434
translate russian tidy_house_loop_934f6d5e:

    # D "But most of the time, all it showed were fleas."
    D "Но чаще всего он показывал только блох."

# game/scripts/episode1.rpy:1437
translate russian tidy_house_loop_7d092c1a:

    # X "Fleas? You mean static?"
    X "Блох? Ты имеешь в виду статику?"

# game/scripts/episode1.rpy:1440
translate russian tidy_house_loop_2ddc3212:

    # D "I think so, yes."
    D "Думаю, да."

# game/scripts/episode1.rpy:1443
translate russian tidy_house_loop_a50d7ba7:

    # X "...so that's how you navigate."
    X "...так что вот как работает пульт."

# game/scripts/episode1.rpy:1445
translate russian tidy_house_loop_26e7b722:

    # D "I get it."
    D "Поняла."

# game/scripts/episode1.rpy:1447
translate russian tidy_house_loop_a22e7b3d:

    # X "Go ahead and watch whatever you like."
    X "Смотри всё, что нравится."

# game/scripts/episode1.rpy:1448
translate russian tidy_house_loop_5f0d57ad:

    # X "I have to get this."
    X "Я должен разобраться с этим."

# game/scripts/episode1.rpy:1452
translate russian tidy_house_loop_2870d77e:

    # Charlie "Hey [X]! I received your message."
    Charlie "Приветствую, [X]! Я получила ваше сообщение."

# game/scripts/episode1.rpy:1453
translate russian tidy_house_loop_9192c7e0:

    # Charlie "Are you sure this is a good lead?"
    Charlie "Вы уверены, что это хорошая зацепка?"

# game/scripts/episode1.rpy:1454
translate russian tidy_house_loop_113469bc:

    # X "Positive, they're the ones who adopted her."
    X "Несомненно, это они её удочерили."

# game/scripts/episode1.rpy:1455
translate russian tidy_house_loop_6dbf4bfc:

    # Charlie "How did you find this anyway?"
    Charlie "Как вы вообще её нашли?"

# game/scripts/episode1.rpy:1457
translate russian tidy_house_loop_5c553784:

    # X "More like it found me."
    X "Скорее, она меня нашла."

# game/scripts/episode1.rpy:1458
translate russian tidy_house_loop_7236c04c:

    # X "To be more precise, my dad found me."
    X "Точнее, меня нашла её и моя дочь."

# game/scripts/episode1.rpy:1459
translate russian tidy_house_loop_fbfc5a5d:

    # Charlie "Your dad?!"
    Charlie "Ваша дочь?!"

# game/scripts/episode1.rpy:1460
translate russian tidy_house_loop_13ea5980:

    # X "Yeah, me and [Emily] we met... before she was adopted."
    X "Да, мы с [Emily] познакомились... до того, как её удочерили."

# game/scripts/episode1.rpy:1461
translate russian tidy_house_loop_0da6bae0:

    # Charlie "..."
    Charlie "..."

# game/scripts/episode1.rpy:1462
translate russian tidy_house_loop_e52046f1:

    # Charlie "I see... won't hold it against you for not mentioning this."
    Charlie "Понятно... не буду винить вас за то, что вы не упомянули об этом."

# game/scripts/episode1.rpy:1463
translate russian tidy_house_loop_855b4836:

    # Charlie "But you can give me all the details when we meet."
    Charlie "Но вы сможете рассказать мне все подробности, когда мы встретимся."

# game/scripts/episode1.rpy:1464
translate russian tidy_house_loop_17a5a459:

    # Charlie "I'll see what I can dig up till then."
    Charlie "Я посмотрю, что мне удастся накопать к тому времени."

# game/scripts/episode1.rpy:1466
translate russian tidy_house_loop_edfef00b:

    # X "Sure, and thanks for getting on this right away."
    X "Конечно, и спасибо, что сразу же взялись за дело."

# game/scripts/episode1.rpy:1467
translate russian tidy_house_loop_bbe22e00:

    # Charlie "Not a problem, I have to finish what I started after all."
    Charlie "Не проблема. В конце концов мне ведь надо закончить начатое."

# game/scripts/episode1.rpy:1468
translate russian tidy_house_loop_3505c389:

    # Charlie "Call you when it's done."
    Charlie "Я позвоню, когда всё будет готово."

# game/scripts/episode1.rpy:1471
translate russian tidy_house_loop_4a247e30:

    # X "It's around dinner time."
    X "Время для ужина."

# game/scripts/episode1.rpy:1474
translate russian tidy_house_loop_4439d1b4:

    # X "I can make something or we could order a pizza."
    X "Я могу что-нибудь приготовить или мы можем заказать пиццу."

# game/scripts/episode1.rpy:1477
translate russian tidy_house_loop_a70cf6a8:

    # D "No, I can cook!"
    D "Нет, я умею готовить!"

# game/scripts/episode1.rpy:1480
translate russian tidy_house_loop_20d17008:

    # X "There's no need [D]. Plus you already made breakfast this morning?"
    X "В этом нет необходимости, [D]. К тому же ты уже готовила завтрак этим утром."

# game/scripts/episode1.rpy:1483
translate russian tidy_house_loop_074569d9:

    # D "No, it's my pleasure!"
    D "Нет, я люблю готовить!"

# game/scripts/episode1.rpy:1486
translate russian tidy_house_loop_f91faedb:

    # D "I got to practice all the time."
    D "Мне приходилось постоянно тренироваться."

# game/scripts/episode1.rpy:1490
translate russian tidy_house_loop_367c918e:

    # X "I looked at the house, it's more like a mansion."
    X "Я посмотрел на дом, он больше похож на особняк."

# game/scripts/episode1.rpy:1491
translate russian tidy_house_loop_76fc7cc5:

    # X "Did you sneak away, how did you escape?"
    X "Ты сбежала. Как тебе это удалось?"

# game/scripts/episode1.rpy:1494
translate russian tidy_house_loop_308fa32b:

    # D "We actually went to visit someone who was getting married."
    D "Мы поехали навестить человека, который собирался жениться."

# game/scripts/episode1.rpy:1497
translate russian tidy_house_loop_8ff2cda1:

    # D "There was always a guardian with me, they told me it was for my safety."
    D "Со мной всегда был опекун. Мне сказали, что это для моей безопасности."

# game/scripts/episode1.rpy:1500
translate russian tidy_house_loop_8f37d1c7:

    # D "He always watched me."
    D "Он всегда наблюдал за мной."

# game/scripts/episode1.rpy:1501
translate russian tidy_house_loop_b4ba6784:

    # X "Always?"
    X "Всегда?"

# game/scripts/episode1.rpy:1504
translate russian tidy_house_loop_0e4572db:

    # D "Except when I used the bathroom, then he just stood outside."
    D "Кроме тех случаев, когда я ходила в туалет, тогда он просто стоял снаружи."

# game/scripts/episode1.rpy:1505
translate russian tidy_house_loop_e3874863:

    # D "It's how I got away."
    D "Вот тогда я и сбежала."

# game/scripts/episode1.rpy:1508
translate russian tidy_house_loop_b47b94c4:

    # X "If they had someone watching you 24/7, then they probably expected you to run away."
    X "Если за тобой круглосуточно следили, то, вероятно, ожидали, что ты сбежишь."

# game/scripts/episode1.rpy:1511
translate russian tidy_house_loop_c0309a27:

    # D "One time when I was little, I followed a kitten outside."
    D "Однажды, когда я была маленькой, я последовала за котёнком на улицу."

# game/scripts/episode1.rpy:1513
translate russian tidy_house_loop_1b78f96a:

    # D "They became angry and told me I wasn't allowed to be alone anymore."
    D "Они разозлились и сказали, что мне больше нельзя оставаться одной."

# game/scripts/episode1.rpy:1514
translate russian tidy_house_loop_1b020a76:

    # D "Ever since then, I had to have someone with me all of the time."
    D "С тех пор я не должна была оставаться одной."

# game/scripts/episode1.rpy:1518
translate russian tidy_house_loop_b6e7ca26:

    # D "They said I would disappear just like [Emily] if I ever went out alone again."
    D "Они сказали, что я исчезну точно так же, как [Emily], если ещё раз выйду на улицу одна."

# game/scripts/episode1.rpy:1519
translate russian tidy_house_loop_fe1ac9ab:

    # "Christ..."
    "Господи..."

# game/scripts/episode1.rpy:1522
translate russian tidy_house_loop_020dcc22:

    # X "But despite that you still left, that couldn't have been easy."
    X "Но, несмотря на это, ты всё равно ушла. Должно быть, это было нелегко."

# game/scripts/episode1.rpy:1525
translate russian tidy_house_loop_fe6a0dfd:

    # D "After finding the journal, I just didn't believe anything they said."
    D "Найдя дневник, я просто не поверила ничему, что они говорили."

# game/scripts/episode1.rpy:1528
translate russian tidy_house_loop_dab18d8f:

    # X "Did you bring it with you?"
    X "Ты взяла его с собой?"

# game/scripts/episode1.rpy:1531
translate russian tidy_house_loop_d814d34a:

    # D "I couldn't, but I left it hidden."
    D "Нет, но я спрятала его."

# game/scripts/episode1.rpy:1534
translate russian tidy_house_loop_eeab6513:

    # X "That was delicious!"
    X "Это было восхитительно!"

# game/scripts/episode1.rpy:1536
translate russian tidy_house_loop_a71b61a6:

    # X "Practice does indeed make perfect."
    X "Практика действительно приводит к совершенству."

# game/scripts/episode1.rpy:1539
translate russian tidy_house_loop_68244322:

    # D "I'm happy you liked it."
    D "Рада, что тебе понравилось."

# game/scripts/episode1.rpy:1541
translate russian tidy_house_loop_b88de3dc:

    # X "And by the way, tomorrow we're going to get you a full medical check-up."
    X "И кстати, завтра мы проведём тебе полное медицинское обследование."

# game/scripts/episode1.rpy:1544
translate russian tidy_house_loop_4b7346a5:

    # X "Since you mentioned not seeing a doctor in years."
    X "Поскольку ты упомянула, что уже много лет не ходила к врачу."

# game/scripts/episode1.rpy:1546
translate russian tidy_house_loop_074af5df:

    # D "A full check-up?"
    D "Полное обследование?"

# game/scripts/episode1.rpy:1548
translate russian tidy_house_loop_01e1dbd8:

    # X "Yes, we need some samples and they'll take a look at everything."
    X "Да, нам нужно несколько анализов, и они всё осмотрят."

# game/scripts/episode1.rpy:1551
translate russian tidy_house_loop_6dbbb53c:

    # D "Everything? Even down... there?"
    D "Всё? Даже внизу... там?"

# game/scripts/episode1.rpy:1552
translate russian tidy_house_loop_4486d5cb:

    # X "That too, yes."
    X "И там тоже, да."

# game/scripts/episode1.rpy:1554
translate russian tidy_house_loop_da8a59e6:

    # X "A woman doctor will do that, so don't worry!"
    X "Это сделает женский врач, так что не волнуйся!"

# game/scripts/episode1.rpy:1557
translate russian tidy_house_loop_0a0f91f5:

    # D "Thank you, I'll go wash the dishes."
    D "Спасибо, я пойду помою посуду."

# game/scripts/episode1.rpy:1558
translate russian tidy_house_loop_6044d30b:

    # X "Wait!"
    X "Постой!"

# game/scripts/episode1.rpy:1561
translate russian tidy_house_loop_06fd6eee:

    # X "There's a certain someone who takes care of that."
    X "Кое-кто позаботится об этом за тебя."

# game/scripts/episode1.rpy:1563
translate russian tidy_house_loop_3bc78a6d:

    # X "He can deal with anything you throw in there."
    X "Он справится со всем, что ты туда положишь."

# game/scripts/episode1.rpy:1564
translate russian tidy_house_loop_b2301f69:

    # X "Pots, pans, whatever."
    X "Кастрюли, сковородки, что угодно."

# game/scripts/episode1.rpy:1566
translate russian tidy_house_loop_60ea4257:

    # X "He'll wipe out any stains, even the little ones."
    X "Он отмоет любые пятна, даже самые маленькие."

# game/scripts/episode1.rpy:1567
translate russian tidy_house_loop_bd689fa9:

    # X "I call him... 'Dish Vader'!"
    X "Я называю его... \"Мой Вейдер\"!"

# game/scripts/episode1.rpy:1571
translate russian tidy_house_loop_686c14d1:

    # D "Why?"
    D "Почему?"

# game/scripts/episode1.rpy:1574
translate russian tidy_house_loop_6ec1f519:

    # D "Why?!"
    D "Почему?!"

# game/scripts/episode1.rpy:1576
translate russian tidy_house_loop_bebefade:

    # X "You know... 'I am your father'!"
    X "Ты знаешь... \"Я - твой отец!\""

# game/scripts/episode1.rpy:1578
translate russian tidy_house_loop_a7394244:

    # D "I know!"
    D "Я знаю!"

# game/scripts/episode1.rpy:1580
translate russian tidy_house_loop_66bca81d:

    # X "No that's not what I... nevermind."
    X "Нет, это не то, что я... Неважно."

# game/scripts/episode1.rpy:1581
translate russian tidy_house_loop_081c815a:

    # X "You need to watch more TV!"
    X "Тебе нужно больше смотреть телевизор!"

# game/scripts/episode1.rpy:1584
translate russian tidy_house_loop_409f2707:

    # D "Agreed!"
    D "Согласна!"

# game/scripts/episode1.rpy:1586
translate russian tidy_house_loop_38e0af6b:

    # D "Can I use the bathroom?"
    D "Могу я пойти в туалет?"

# game/scripts/episode1.rpy:1588
translate russian tidy_house_loop_1c701a15:

    # X "Yes, and you do not have to ask!"
    X "Да, и не надо спрашивать!"

# game/scripts/episode1.rpy:1590
translate russian tidy_house_loop_3828de61:

    # "It's probably best to get her samples from home."
    "Наверное, лучше всего взять её анализы дома."

# game/scripts/episode1.rpy:1592
translate russian tidy_house_loop_64545ae3:

    # "She might be too uncomfortable doing it at the hospital."
    "Возможно, ей будет слишком неудобно делать это в больнице."

# game/scripts/episode1.rpy:1594
translate russian tidy_house_loop_1f517d04:

    # "Is she still in the bathroom?"
    "Она всё ещё в ванной?"

# game/scripts/episode1.rpy:1597
translate russian tidy_house_loop_6f0b7f35:

    # X "[D], is everything all right?"
    X "[D], всё в порядке?"

# game/scripts/episode1.rpy:1599
translate russian tidy_house_loop_5308c5ae:

    # D "I... I need some help."
    D "Мне... мне нужна кое-какая помощь."

# game/scripts/episode1.rpy:1601
translate russian tidy_house_loop_ef4f69df:

    # X "You need me to get you something?"
    X "Тебе нужно что-то принести?"

# game/scripts/episode1.rpy:1602
translate russian tidy_house_loop_667e4980:

    # D "Can you come inside please?"
    D "Не мог бы ты зайти?"

# game/scripts/episode1.rpy:1604
translate russian tidy_house_loop_c72fc6b9:

    # X "What's wrong, what happened?"
    X "Что случилось?"

# game/scripts/episode1.rpy:1606
translate russian tidy_house_loop_a25448d7:

    # D "I can't get it to come off."
    D "Я не могу снять его."

# game/scripts/episode1.rpy:1608
translate russian tidy_house_loop_e15144ef:

    # X "Get what off?"
    X "Снять что?"

# game/scripts/episode1.rpy:1610
translate russian tidy_house_loop_637dc8ff:

    # X "Hey what are you..."
    X "Эй, что ты..."

# game/scripts/episode1.rpy:1612
translate russian tidy_house_loop_6139e3b4:

    # D "I've tried, but it just won't come off."
    D "Я пыталась, но он просто не снимается."

# game/scripts/episode1.rpy:1614
translate russian tidy_house_loop_19f3756b:

    # D "It's locked in the back."
    D "Он заперт на ключ."

# game/scripts/episode1.rpy:1616
translate russian tidy_house_loop_f4715af1:

    # X "Locked?"
    X "Заперт?"

# game/scripts/episode1.rpy:1617
translate russian tidy_house_loop_0d5897b7:

    # X "Is... is that a chastity-belt?!"
    X "Это... это пояс целомудрия?!"

translate russian strings:

    # game/scripts/episode1.rpy:115
    old "Give her your love"
    new "Дать ей свою любовь"

    # game/scripts/episode1.rpy:131
    old "Say it"
    new "Сказать это"

    # game/scripts/episode1.rpy:131
    old "Hesitate"
    new "Колебаться"

    # game/scripts/episode1.rpy:442
    old "Talk work"
    new "Поговорить о работе"

    # game/scripts/episode1.rpy:442
    old "Talk fitness"
    new "Поговорить о фитнесе"

    # game/scripts/episode1.rpy:531
    old "Favorite shop"
    new "Любимый магазин"

    # game/scripts/episode1.rpy:531
    old "Nostalgia"
    new "Ностальгия"

    # game/scripts/episode1.rpy:592
    old "Check livingroom"
    new "Проверить гостиную"

    # game/scripts/episode1.rpy:592
    old "Check lower bathroom"
    new "Проверить туалет"

    # game/scripts/episode1.rpy:592
    old "Check your room"
    new "Проверить свою комнату"

    # game/scripts/episode1.rpy:592
    old "Wait for [Maya]"
    new "Ждать [Maya]"

    # game/scripts/episode1.rpy:932
    old "Grab her arm"
    new "Взять её за руку"

    # game/scripts/episode1.rpy:932
    old "Explain"
    new "Объяснить"

    # game/scripts/episode1.rpy:1228
    old "Knock on the door"
    new "Постучать в дверь"

    # game/scripts/episode1.rpy:1228
    old "Open the door"
    new "Открыть дверь"

    old "Continue"
    new "Продолжить"

    old "What should I name my dad?"
    new "Как мне назвать свою дочь?"

    old "Filia"
    new "Филия"

