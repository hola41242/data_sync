

translate russian strings:

    old "Language"
    new "Язык"

    old "{size=+12}{color=#ffffff}Presents"
    new "{size=+12}{color=#ffffff}Представляет"

    old "{size=+66}{color=#e926ae}She Is My Precious"
    new "{size=+66}{color=#e926ae}Она - моя драгоценность"

    old "{size=+66}{color=#ffffff}Thanks for playing!"
    new "{size=+50}{color=#ffffff}Спасибо за игру!\n\n\n\n"

    old "{size=+24}{color=#ffffff}Check out {a=https://patreon.com/finestartproductions}{color=#ff2a0d}patreon{/color}{/a} for updates\n   (New episode every month)"
    new "{size=+20}{color=#ffffff}Заходите на {a=https://patreon.com/finestartproductions}{color=#ff2a0d}Patreon{/color}{/a} за обновлениями\n     (Новый эпизод каждый месяц)\n\n\n\n\n\nИгру перевела студия переводов\n       \"Наша версия\" ({a=https://vk.com/nashaversia}{color=#ff2a0d}VK{/color}{/a})\n\n\n"


    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⬅️{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⬅️{/size}{/font}"


    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}📖{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}📖{/size}{/font}"


    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⏩{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⏩{/size}{/font}"


    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⏯️{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⏯️{/size}{/font}"


    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}💾{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}💾{/size}{/font}"


    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}🔼{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}🔼{/size}{/font}"


    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}🔽{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}🔽{/size}{/font}"


    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⚙️{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⚙️{/size}{/font}"


    old "Start"
    new "Начать игру"


    old "History"
    new "История"


    old "Save"
    new "Сохранить"


    old "Load"
    new "Загрузить"


    old "Preferences"
    new "Настройки"


    old "End Replay"
    new "Закончить повтор"


    old "Main Menu"
    new "Главное меню"


    old "About"
    new "Об игре"


    old "Help"
    new "Помощь"


    old "Quit"
    new "Выйти из игры"


    old "Version [config.version!t]\n"
    new "Версия [config.version!t]\n"


    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Создано на {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"


    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"


    old "empty slot"
    new "пустой слот"


    old "<"
    new "<"


    old "{#auto_page}A"
    new "{#auto_page}A"


    old "{#quick_page}Q"
    new "{#quick_page}Q"


    old ">"
    new ">"


    old "Display"
    new "Режим окна"


    old "Window"
    new "Оконный"


    old "Fullscreen"
    new "Полноэкранный"


    old "Skip"
    new "Пропуск"


    old "Unseen Text"
    new "Непрочитанного текста"


    old "After Choices"
    new "После выборов"


    old "Transitions"
    new "Эффектов переходов"


    old "Text Speed"
    new "Скорость текста"


    old "Auto-Forward Time"
    new "Время автоперемотки"


    old "Music Volume"
    new "Громкость музыки"


    old "Sound Volume"
    new "Громкость звука"


    old "Test"
    new "Тест"


    old "Ambience Volume"
    new "Громкость окружения"


    old "Mute All"
    new "Заглушить всё"


    old "The dialogue history is empty."
    new "История диалогов пуста."


    old "Keyboard"
    new "Клавиатура"


    old "Mouse"
    new "Мышь"


    old "Gamepad"
    new "Геймпад"


    old "Enter"
    new "Enter"


    old "Advances dialogue and activates the interface."
    new "Продвигает диалог и активирует интерфейс."


    old "Space"
    new "Space (Пробел)"


    old "Advances dialogue without selecting choices."
    new "Продвигает диалог без выбора вариантов."


    old "Arrow Keys"
    new "Клавиши со стрелками"


    old "Navigate the interface."
    new "Перемещение по интерфейсу."


    old "Escape"
    new "Escape"


    old "Accesses the game menu."
    new "Открывает игровое меню."


    old "Ctrl"
    new "Ctrl"


    old "Skips dialogue while held down."
    new "Пропускает диалог при удержании кнопки."


    old "Tab"
    new "Tab"


    old "Toggles dialogue skipping."
    new "Включает/Выключает пропуск диалогов."


    old "Page Up"
    new "Page Up"


    old "Rolls back to earlier dialogue."
    new "Возвращает к предыдущему диалогу."


    old "Page Down"
    new "Page Down"


    old "Rolls forward to later dialogue."
    new "Переходит к следующему диалогу."


    old "Hides the user interface."
    new "Скрывает пользовательский интерфейс."


    old "Takes a screenshot."
    new "Делает скриншот."


    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Включает/Выключает вспомогательное {a=https://www.renpy.org/l/voicing}самоозвучивание{/a}."


    old "Opens the accessibility menu."
    new "Открывает меню специальных возможностей."


    old "Left Click"
    new "ЛКМ (Левая кнопка мыши)"


    old "Middle Click"
    new "СКМ (Средняя кнопка мыши)"


    old "Right Click"
    new "ПКМ (Правая кнопка мыши)"


    old "Mouse Wheel Up\nClick Rollback Side"
    new "Колесико мыши вверх\nНажатие стороны отката"


    old "Mouse Wheel Down"
    new "Колесико мыши вниз"


    old "Right Trigger\nA/Bottom Button"
    new "Правый триггер\nA/Нижняя кнопка"


    old "Left Trigger\nLeft Shoulder"
    new "Левый триггер\nЛевое плечо"


    old "Right Shoulder"
    new "Правое плечо"


    old "D-Pad, Sticks"
    new "D-Pad, Стики"


    old "Start, Guide"
    new "Начать, Гайд"


    old "Y/Top Button"
    new "Y/Верхняя кнопка"


    old "Calibrate"
    new "Калибровка"


    old "Skipping"
    new "Пропускаем"


    old "Back"
    new "Назад"


    old "Auto"
    new "Авто"


    old "Menu"
    new "Меню"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
