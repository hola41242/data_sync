﻿# TODO: Translation updated at 2024-02-11 21:34

translate russian strings:
    
    old "Language"
    new "Язык"

    old "{size=+12}{color=#ffffff}Presents"
    new "{size=+12}{color=#ffffff}Представляет"

    old "{size=+66}{color=#e926ae}She Is My Precious"
    new "{size=+66}{color=#e926ae}Она - моя драгоценность"

    old "{size=+66}{color=#ffffff}Thanks for playing!"
    new "{size=+50}{color=#ffffff}Спасибо за игру!\n\n\n\n"

    old "{size=+24}{color=#ffffff}Check out {a=https://patreon.com/finestartproductions}{color=#ff2a0d}patreon{/color}{/a} for updates\n   (New episode every month)"
    new "{size=+20}{color=#ffffff}Заходите на {a=https://patreon.com/finestartproductions}{color=#ff2a0d}Patreon{/color}{/a} за обновлениями\n     (Новый эпизод каждый месяц)\n\n\n\n\n\nИгру перевела студия переводов\n       \"Наша версия\" ({a=https://vk.com/nashaversia}{color=#ff2a0d}VK{/color}{/a})\n\n\n"
    
    # game/scripts/screens.rpy:350
    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⬅️{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⬅️{/size}{/font}"

    # game/scripts/screens.rpy:351
    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}📖{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}📖{/size}{/font}"

    # game/scripts/screens.rpy:352
    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⏩{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⏩{/size}{/font}"

    # game/scripts/screens.rpy:353
    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⏯️{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⏯️{/size}{/font}"

    # game/scripts/screens.rpy:354
    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}💾{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}💾{/size}{/font}"

    # game/scripts/screens.rpy:355
    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}🔼{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}🔼{/size}{/font}"

    # game/scripts/screens.rpy:356
    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}🔽{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}🔽{/size}{/font}"

    # game/scripts/screens.rpy:357
    old "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⚙️{/size}{/font}"
    new "{size=+6}{font=fonts/NotoEmoji-Bold.ttf}⚙️{/size}{/font}"

    # game/scripts/screens.rpy:398
    old "Start"
    new "Начать игру"

    # game/scripts/screens.rpy:402
    old "History"
    new "История"

    # game/scripts/screens.rpy:404
    old "Save"
    new "Сохранить"

    # game/scripts/screens.rpy:406
    old "Load"
    new "Загрузить"

    # game/scripts/screens.rpy:408
    old "Preferences"
    new "Настройки"

    # game/scripts/screens.rpy:412
    old "End Replay"
    new "Закончить повтор"

    # game/scripts/screens.rpy:416
    old "Main Menu"
    new "Главное меню"

    # game/scripts/screens.rpy:418
    old "About"
    new "Об игре"

    # game/scripts/screens.rpy:423
    old "Help"
    new "Помощь"

    # game/scripts/screens.rpy:429
    old "Quit"
    new "Выйти из игры"

    # game/scripts/screens.rpy:659
    old "Version [config.version!t]\n"
    new "Версия [config.version!t]\n"

    # game/scripts/screens.rpy:665
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Создано на {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/scripts/screens.rpy:743
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/scripts/screens.rpy:743
    old "empty slot"
    new "пустой слот"

    # game/scripts/screens.rpy:760
    old "<"
    new "<"

    # game/scripts/screens.rpy:763
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/scripts/screens.rpy:766
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/scripts/screens.rpy:772
    old ">"
    new ">"

    # game/scripts/screens.rpy:829
    old "Display"
    new "Режим окна"

    # game/scripts/screens.rpy:830
    old "Window"
    new "Оконный"

    # game/scripts/screens.rpy:831
    old "Fullscreen"
    new "Полноэкранный"

    # game/scripts/screens.rpy:835
    old "Skip"
    new "Пропуск"

    # game/scripts/screens.rpy:836
    old "Unseen Text"
    new "Непрочитанного текста"

    # game/scripts/screens.rpy:837
    old "After Choices"
    new "После выборов"

    # game/scripts/screens.rpy:838
    old "Transitions"
    new "Эффектов переходов"

    # game/scripts/screens.rpy:851
    old "Text Speed"
    new "Скорость текста"

    # game/scripts/screens.rpy:855
    old "Auto-Forward Time"
    new "Время автоперемотки"

    # game/scripts/screens.rpy:862
    old "Music Volume"
    new "Громкость музыки"

    # game/scripts/screens.rpy:869
    old "Sound Volume"
    new "Громкость звука"

    # game/scripts/screens.rpy:875
    old "Test"
    new "Тест"

    # game/scripts/screens.rpy:887
    old "Ambience Volume"
    new "Громкость окружения"

    # game/scripts/screens.rpy:896
    old "Mute All"
    new "Заглушить всё"

    # game/scripts/screens.rpy:1015
    old "The dialogue history is empty."
    new "История диалогов пуста."

    # game/scripts/screens.rpy:1083
    old "Keyboard"
    new "Клавиатура"

    # game/scripts/screens.rpy:1084
    old "Mouse"
    new "Мышь"

    # game/scripts/screens.rpy:1087
    old "Gamepad"
    new "Геймпад"

    # game/scripts/screens.rpy:1100
    old "Enter"
    new "Enter"

    # game/scripts/screens.rpy:1101
    old "Advances dialogue and activates the interface."
    new "Продвигает диалог и активирует интерфейс."

    # game/scripts/screens.rpy:1104
    old "Space"
    new "Space (Пробел)"

    # game/scripts/screens.rpy:1105
    old "Advances dialogue without selecting choices."
    new "Продвигает диалог без выбора вариантов."

    # game/scripts/screens.rpy:1108
    old "Arrow Keys"
    new "Клавиши со стрелками"

    # game/scripts/screens.rpy:1109
    old "Navigate the interface."
    new "Перемещение по интерфейсу."

    # game/scripts/screens.rpy:1112
    old "Escape"
    new "Escape"

    # game/scripts/screens.rpy:1113
    old "Accesses the game menu."
    new "Открывает игровое меню."

    # game/scripts/screens.rpy:1116
    old "Ctrl"
    new "Ctrl"

    # game/scripts/screens.rpy:1117
    old "Skips dialogue while held down."
    new "Пропускает диалог при удержании кнопки."

    # game/scripts/screens.rpy:1120
    old "Tab"
    new "Tab"

    # game/scripts/screens.rpy:1121
    old "Toggles dialogue skipping."
    new "Включает/Выключает пропуск диалогов."

    # game/scripts/screens.rpy:1124
    old "Page Up"
    new "Page Up"

    # game/scripts/screens.rpy:1125
    old "Rolls back to earlier dialogue."
    new "Возвращает к предыдущему диалогу."

    # game/scripts/screens.rpy:1128
    old "Page Down"
    new "Page Down"

    # game/scripts/screens.rpy:1129
    old "Rolls forward to later dialogue."
    new "Переходит к следующему диалогу."

    # game/scripts/screens.rpy:1133
    old "Hides the user interface."
    new "Скрывает пользовательский интерфейс."

    # game/scripts/screens.rpy:1137
    old "Takes a screenshot."
    new "Делает скриншот."

    # game/scripts/screens.rpy:1141
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Включает/Выключает вспомогательное {a=https://www.renpy.org/l/voicing}самоозвучивание{/a}."

    # game/scripts/screens.rpy:1145
    old "Opens the accessibility menu."
    new "Открывает меню специальных возможностей."

    # game/scripts/screens.rpy:1151
    old "Left Click"
    new "ЛКМ (Левая кнопка мыши)"

    # game/scripts/screens.rpy:1155
    old "Middle Click"
    new "СКМ (Средняя кнопка мыши)"

    # game/scripts/screens.rpy:1159
    old "Right Click"
    new "ПКМ (Правая кнопка мыши)"

    # game/scripts/screens.rpy:1163
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Колесико мыши вверх\nНажатие стороны отката"

    # game/scripts/screens.rpy:1167
    old "Mouse Wheel Down"
    new "Колесико мыши вниз"

    # game/scripts/screens.rpy:1174
    old "Right Trigger\nA/Bottom Button"
    new "Правый триггер\nA/Нижняя кнопка"

    # game/scripts/screens.rpy:1178
    old "Left Trigger\nLeft Shoulder"
    new "Левый триггер\nЛевое плечо"

    # game/scripts/screens.rpy:1182
    old "Right Shoulder"
    new "Правое плечо"

    # game/scripts/screens.rpy:1187
    old "D-Pad, Sticks"
    new "D-Pad, Стики"

    # game/scripts/screens.rpy:1191
    old "Start, Guide"
    new "Начать, Гайд"

    # game/scripts/screens.rpy:1195
    old "Y/Top Button"
    new "Y/Верхняя кнопка"

    # game/scripts/screens.rpy:1198
    old "Calibrate"
    new "Калибровка"

    # game/scripts/screens.rpy:1310
    old "Skipping"
    new "Пропускаем"

    # game/scripts/screens.rpy:1530
    old "Back"
    new "Назад"

    # game/scripts/screens.rpy:1532
    old "Auto"
    new "Авто"

    # game/scripts/screens.rpy:1533
    old "Menu"
    new "Меню"

