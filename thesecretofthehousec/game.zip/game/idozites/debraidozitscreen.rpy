screen debramitcsinaljon:
    if hanyadiknapvan == 1:
        if agynemuhejen == False:
            if debraholcsinal == "napaliban":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "furdo"),
                SetVariable('debrafurdoban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                if holvagyok == "napaliban":
                    if debranapaliban == True:
                        timer 2.0 repeat True action Jump ("debraanapalibavissza")
                if holvagyok == "napaliban":
                    if menyiharomgyokalat <= 1:
                        imagebutton:
                            idle "ajtok/debporz.png"
                            xpos 0.61
                            ypos 0.2
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debranapalibanelgondolkodva")
                    if menyiharomgyokalat == 3:
                        imagebutton:
                            idle "ajtok/debporz.png"
                            xpos 0.61
                            ypos 0.2
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debranapalibanelgondolkodva")
            if debraholcsinal == "furdo":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "fojasoball"),
                SetVariable('debraballfoban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                if holvagyok == "furdo":
                    if debrafurdoban == True:
                        timer 2.0 repeat True action Jump ("debrafurdobevissza")
                if holvagyok == "furdo":
                    if agynemukaptal == False:
                        imagebutton:
                            idle "ajtok/debporz.png"
                            xpos 0.4
                            ypos 0.2
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debratolkerdezel")
            if debraholcsinal == "fojasoball":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "fojasojobb"),
                SetVariable('debrajobbfoban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                if holvagyok == "fojasoball":
                    if debraballfoban == True:
                        timer 2.0 repeat True action Jump ("debrafojballvissza")
                if holvagyok == "fojasoball":
                    imagebutton:
                        idle "ajtok/nszajobbz.png"
                        xpos 0.5
                        ypos 0.3
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("debrafojasonalanez")
            if ujsagafoldonkidobva == False:
                if debraholcsinal == "fojasojobb":
                    timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                    true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                    SetVariable('debraholcsinal', "napaliban"),
                    SetVariable('debranapaliban', True)],
                    false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                    if holvagyok == "fojasojobb":
                        if debrajobbfoban == True:
                            timer 2.0 repeat True action Jump ("debrafojjobbvissza")
                    if holvagyok == "fojasojobb":
                        imagebutton:
                            idle "ajtok/debporz.png"
                            xpos 0.53
                            ypos 0.4
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debratolkerdezel")
            if ujsagafoldonkidobva == True:
                if debraholcsinal == "fojasojobb":
                    timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                    true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                    SetVariable('debraholcsinal', "napaliban2"),
                    SetVariable('debranapaliban', True)],
                    false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                    if holvagyok == "fojasojobb":
                        if debrajobbfoban == True:
                            timer 2.0 repeat True action Jump ("debrafojjobbvissza")
                    if holvagyok == "fojasojobb":
                        if agynemukaptal == False:
                            imagebutton:
                                idle "ajtok/debporz.png"
                                xpos 0.53
                                ypos 0.4
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action Jump ("debratolkerdezel")
            if debraholcsinal == "napaliban2":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "napaliban"),
                SetVariable('debranapaliban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                if holvagyok == "napaliban":
                    if debranapaliban == True:
                        timer 2.0 repeat True action Jump ("debraanapalibavissza")
                if holvagyok == "napaliban":
                    imagebutton:
                        idle "ajtok/debporz.png"
                        xpos 0.65
                        ypos 0.25
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("debraanapaliolvas")
    if hanyadiknapvan == 2:
        if debraindul == True:
            if debraholcsinal == "napaliban2":
                if debraindulhat2resz == True:
                    timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                    true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                    SetVariable('debraholcsinal', "dolgozo"),
                    SetVariable('debradolgozo', True)],
                    false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                    if holvagyok == "napaliban":
                        if debranapaliban == True:
                            timer 2.0 repeat True action Jump ("debraanapalibavissza")
                if holvagyok == "napaliban":
                    imagebutton:
                        idle "ajtok/debporz.png"
                        xpos 0.65
                        ypos 0.25
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("debraanapaliolvas")
            if debraholcsinal == "dolgozo":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "furdo"),
                SetVariable('debrafurdoban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                if holvagyok == "napaliban":
                    if debranapaliban == True:
                        timer 2.0 repeat True action Jump ("debraanapalibavissza")
            if debraholcsinal == "furdo":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "fojasoball"),
                SetVariable('debraballfoban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
            if debraholcsinal == "fojasoball":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "fojasojobb"),
                SetVariable('debrajobbfoban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                if holvagyok == "fojasoball":
                    if debraballfoban == True:
                        timer 2.0 repeat True action Jump ("debrafojballvissza")
                if holvagyok == "fojasoball":
                    if csinalszvalamit == "semit":
                        imagebutton:
                            idle "ajtok/nszajobbz.png"
                            xpos 0.5
                            ypos 0.3
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debrafojasonalanez")
            if debraholcsinal == "fojasojobb":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "konyha"),
                SetVariable('debrakonyhaban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                if holvagyok == "fojasojobb":
                    if debrajobbfoban == True:
                        timer 2.0 repeat True action Jump ("debrafojjobbvissza")
                if holvagyok == "fojasojobb":
                    imagebutton:
                        idle "ajtok/debporz.png"
                        xpos 0.53
                        ypos 0.4
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("debratolkerdezel")
            if debraholcsinal == "konyha":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                SetVariable('debraholcsinal', "furdo2"),
                SetVariable('debrafurdoban', True)],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                if holvagyok == "konyha":
                    if debrakonyhaban == True:
                        timer 2.0 repeat True action Jump ("debrakanyhavissza")
                if holvagyok == "konyha":
                    if csinalszvalamit == "semit":
                        imagebutton:
                            idle "ajtok/kijaratz.png"
                            xpos 0.81
                            ypos 0.22
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debrakonyhabanfoz")
            if tvprogramkesz == False:
                if debraholcsinal == "furdo2":
                    timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                    true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                    SetVariable('debraholcsinal', "napaliban2"),
                    SetVariable('debranapaliban', True)],
                    false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                    if holvagyok == "furdo":
                        if debrafurdoban == True:
                            timer 2.0 repeat True action Jump ("debrafurdobevissza2")
                    if holvagyok == "furdo":
                        imagebutton:
                            idle "ajtok/ruhazz.png"
                            xpos 0.45
                            ypos 0.6
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debrafurdobenfelmos")
            if tvprogramkesz == True:
                if debraholcsinal == "furdo2":
                    timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                    true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                    SetVariable('debraholcsinal', "napaliban3"),
                    SetVariable('debranapaliban', True)],
                    false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                    if holvagyok == "furdo":
                        if debrafurdoban == True:
                            timer 2.0 repeat True action Jump ("debrafurdobevissza2")
                    if holvagyok == "furdo":
                        imagebutton:
                            idle "ajtok/ruhazz.png"
                            xpos 0.45
                            ypos 0.6
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debrafurdobenfelmos")
                if debraholcsinal == "napaliban3":
                    timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                    true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 20),
                    SetVariable('debraholcsinal', "napaliban2"),
                    SetVariable('debranapaliban', True)],
                    false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
                    if holvagyok == "napaliban":
                        if debranapaliban == True:
                            timer 2.0 repeat True action Jump ("debraanapalibavissza")
                    if holvagyok == "napaliban":
                        imagebutton:
                            idle "ajtok/debporz.png"
                            xpos 0.65
                            ypos 0.25
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debraanapaliolvas")



        if csinalszvalamit == "semit":
            if debraelveteaszedvicset <= 2:
                if debrakedvencszedvicse == True:
                    if holvagyok == "konyha":
                        timer 0.1 repeat True action SetVariable('debraelveteaszedvicset', debraelveteaszedvicset + 1), Jump ("debralevesziaszedvicset")
        if szedvicbenvaj == True:
            if szedvicbenparizsi == True:
                if szedvicbensalata == True:
                    if szedvicbenkecsap == True:
                        if debraelveteaszedvicset <= 2:
                            if debrakedvencszedvicse == False:
                                timer 0.1 repeat True action SetVariable('debrakedvencszedvicse', True)
    if hanyadiknapvan == 4:
        if regell4resz == True:
            if debraholcsinal == "konyhaeszik":
                timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
                true=[SetVariable('debraholcsinal', "dolgozo"),
                Hide('debramitcsinaljon')],
                false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
    if hanyadiknapvan == 6:
        if debraholcsinal == "furdo2":
            timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
            true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 60),
            SetVariable('debraholcsinal', "konyhatorol"),
            SetVariable('debrakonyhaban', True)],
            false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
            if holvagyok == "furdo":
                imagebutton:
                    idle "ajtok/debporz.png"
                    xpos 0.5
                    ypos 0.3
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrafurdobenbudittakarit")
        if debraholcsinal == "konyhatorol":
            timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
            true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 60),
            SetVariable('debraholcsinal', "ablakotpucoljobbfojason"),
            SetVariable('debrajobbfoban', True)],
            false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
            if holvagyok == "konyha":
                if debrakonyhaban == True:
                    if beszedmamavalkonyhaban6resz == False:
                        timer 2.0 repeat True action Jump ("debrakanyhavissza2")
            if holvagyok == "konyha":
                if beszedmamavalkonyhaban6resz == False:
                    imagebutton:
                        idle "ajtok/debpor2z.png"
                        xpos 0.45
                        ypos 0.25
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("debrakanyhatorolget")
        if debraholcsinal == "ablakotpucoljobbfojason":
            timer 1.0 repeat True action If(debravalamitcsinalido <= 0,
            true=[SetVariable('debravalamitcsinalido', debravalamitcsinalido + 60),
            SetVariable('debraholcsinal', "napalikusztum"),
            SetVariable('debranapaliban', True),
            SetVariable('debravegigpan', debravegigpan + 1)],
            false=[SetVariable('debravalamitcsinalido', debravalamitcsinalido - 1)])
            if holvagyok == "fojasojobb":
                if debrajobbfoban == True:
                    timer 2.0 repeat True action Jump ("debrafojjobbvissza2")
            if holvagyok == "fojasojobb":
                if porszivotkeres == False:
                    imagebutton:
                        idle "ajtok/nszaballz.png"
                        xpos 0.26
                        ypos 0.27
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("debrajobbfojasonablakottorol")
        if debraholcsinal == "napalikusztum":
            if holvagyok == "napaliban":
                if debranapaliban == True:
                    timer 2.0 repeat True action Jump ("debraanapalibavissza2")






screen mutat:
    text "{color=#000000}[tanulhac12nap]":
        xpos 0.5
        ypos 0.4
    text "{color=#000000}[lidiaholvan]":
        xpos 0.5
        ypos 0.5
    text "{color=#000000}[ragasztonalad]":
        xpos 0.5
        ypos 0.6
    text "{color=#000000}[debrakert2benholvan]":
        xpos 0.5
        ypos 0.7
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
