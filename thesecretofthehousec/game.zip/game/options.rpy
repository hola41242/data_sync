













define config.name = _("")
define config.layers = ['master', 'transient','hatsominus1','hatso','hatso1','hatso2','hatso3', 'kozep','kozep2','kozep3','kozep4','elotte'
,'elotte1', 'elotte2', 'elotte3', 'elotte4', 'elotte5', 'elotte6', 'screens', 'screens2', 'over_screens', 'overlay' ]





define gui.show_name = True




define config.version = "Chapter1Day1to12"





define gui.about = _p("""
""")






define build.name = "TheSecretOfTheHouse"







define config.has_sound = True
define config.has_music = True
define config.has_voice = True
























define config.enter_transition = dissolve
define config.exit_transition = dissolve




define config.intra_transition = dissolve




define config.after_load_transition = None




define config.end_game_transition = None
















define config.window = "auto"




define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)







default preferences.text_cps = 0





default preferences.afm_time = 15
















define config.save_directory = "TheSecretOfTheHouse-1597161286"






define config.window_icon = "gui/window_icon.png"






init python:




















    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)



    build.classify('game/**.png', 'archive')
    build.classify('game/**.ogg', 'archive')
    build.classify('game/**.jpg', 'archive')
    build.classify('game/**.wav', 'archive')
    build.classify('game/**.rpy', 'archive')
    build.classify('game/**.rpyc', 'archive')
    build.classify('game/**.rpyb', 'archive')




    build.documentation('*.html')
    build.documentation('*.txt')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
