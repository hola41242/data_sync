label start:
    play music "audio/banyabolt.ogg" fadeout 1
    show screen blockctrl
    window hide
    f "I would like to tell you my story. I will be short."
    show kezdjel1:
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 1.0
    f "This is our home."
    show kezdjel2:
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 1.0
    f "Here you can see our home after my dad blew it… He made… suicide…"
    show kezdjel3:
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 1.0
    f "When the firefighters extinguished the fire we had only ashes all around. Sorry, i wanted to draw you my story, but i can not draw... really..."
    show kezdjel4:
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 1.0
    f "Sorry! These are my…dreams…"
    show kezdjel5:
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 1.0
    f "Since my dad died, I am totally alone!"
    f "Luckily my fathers best friend, Bertalan took me to his home, but the family is not happy because i am around…"

    jump kezd
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
