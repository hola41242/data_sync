screen fifiodapisilt:
    if fifipisi1 == False:
        if holvagyok == "fojasoball":
            if fifipisilt >= 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.54
                    ypos 0.74
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump('fifipisifeltakarit')
    if fifipisi2 == False:
        if holvagyok == "napaliban":
            if fifipisilt >= 2:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.16
                    ypos 0.72
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump('fifipisifeltakarit2')
    if fifipisi3 == False:
        if holvagyok == "napaliban":
            if fifipisilt >= 3:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.65
                    ypos 0.74
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump('fifipisifeltakarit3')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
