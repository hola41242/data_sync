screen estkezelo:
    if hanyadiknapvan == 2:
        if esteighatralevoido > 0:
            timer 1.0 repeat True action If(esteighatralevoido <= 0,
            true=[],
            false=[SetVariable('esteighatralevoido', esteighatralevoido - 1)])
    if hanyadiknapvan == 3:
        if esteighatralevoido > 0:
            timer 1.0 repeat True action If(esteighatralevoido <= 0,
            true=[],
            false=[SetVariable('esteighatralevoido', esteighatralevoido - 1)])
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
