screen tvvisszakerul:
    if tvhoztak == False:
        timer 1.0 repeat True action If(tvhoznakido <= 0,
        true=[SetVariable('tvhoznakido', tvhoznakido + 10),
        SetVariable('csengettek', True),
        Hide('tvvisszakerul'),
        Show ('megintcsengetnek'),
        Jump('csengetnektvmiadt')],
        false=[SetVariable('tvhoznakido', tvhoznakido - 1)])
screen megintcsengetnek:
    if tvhoztak == False:
        timer 1.0 repeat True action If(tvhoznakido <= 0,
        true=[SetVariable('tvhoznakido', tvhoznakido + 10),
        Jump('csengetnektvmiadt')],
        false=[SetVariable('tvhoznakido', tvhoznakido - 1)])
screen tvprogramozas:
    if tiltokkilepest == False:
        frame:
            background ('fram')
            xpos 0.15
            ypos 0.9
            xalign 0.5
            textbutton "I stop programming.":
                mouse "aktion"
                action Jump ("tvprogramozasabahagy")
                text_style "fegeteszov"
    if tvprogramkesz == False:
        timer 1.0 repeat True action If(tvprogramido <= 0,
        true=[SetVariable('tvprogramkesz', True),
        Jump('tvprogramozasabahagy')],
        false=[SetVariable('tvprogramido', tvprogramido - 1),
        SetVariable('tvprogrameltetido', tvprogrameltetido + 1)])
        bar:
            left_bar "#f00"
            if tvprogramido <= 60:
                left_bar "#0ff"
            if tvprogramido <= 0:
                left_bar "#0f0"
            value StaticValue(tvprogrameltetido, 120) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20

    if tvprogramido == 100:
        if debrabejopiszkalni == 0:
            timer 0.1 repeat True action SetVariable("debrabejopiszkalni", debrabejopiszkalni + 1), Jump ('debrabejopiszkalni')
    if tvprogramido == 60:
        if debrabejopiszkalni == 1:
            timer 0.1 repeat True action SetVariable("debrabejopiszkalni", debrabejopiszkalni + 1), Jump ('debrabejopiszkalni')
    if tvprogramido == 30:
        if debrabejopiszkalni == 2:
            timer 0.1 repeat True action SetVariable("debrabejopiszkalni", debrabejopiszkalni + 1), Jump ('debrabejopiszkalni')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
