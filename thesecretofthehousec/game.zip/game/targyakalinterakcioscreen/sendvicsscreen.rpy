screen szedvicskerdes:
    frame:
        background ('fram')
        xalign 0.5
        yalign 0.45
        textbutton "Eat it.":
            mouse "aktion"
            action Jump ("szedvicselszov2")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xalign 0.5
        yalign 0.55
        textbutton "Leav it.":
            mouse "aktion"
            action Jump ("szedvicselszov3")
            text_style "fegeteszov"

screen szedvicsepites:
    if hanyadiknapvan < 9:
        frame:
            background ('fram')
            xalign 0.05
            yalign 0.95
            textbutton "Back":
                mouse "aktion"
                action Jump ("szedvicskilep")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xalign 0.95
            yalign 0.95
            textbutton "Ready":
                mouse "aktion"
                action Jump ("szedvicskesz")
                text_style "fegeteszov"
    if szedvicskesz == False:
        frame:
            background ('fram')
            xalign 0.05
            yalign 0.95
            textbutton "Back":
                mouse "aktion"
                action Jump ("szedvicskilep")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xalign 0.95
            yalign 0.95
            textbutton "Ready":
                mouse "aktion"
                action Jump ("szedvicskesz")
                text_style "fegeteszov"
        if szedvicbenkecsap == False:
            if szedvicbenmajonez == False:
                if szedvicbenmustar == False:
                    frame:
                        background ('fram')
                        xpos 0.1
                        ypos 0.15
                        xalign 0.5
                        textbutton "Ketchup":
                            mouse "aktion"
                            action Jump ("szedvicbenkecsap")
                            text_style "fegeteszov"
                    frame:
                        background ('fram')
                        xpos 0.1
                        ypos 0.25
                        xalign 0.5
                        textbutton "Mayonnaise":
                            mouse "aktion"
                            action Jump ("szedvicbenmajonez")
                            text_style "fegeteszov"
                    frame:
                        background ('fram')
                        xpos 0.1
                        ypos 0.35
                        xalign 0.5
                        textbutton "Mustard":
                            mouse "aktion"
                            action Jump ("szedvicbenmustar")
                            text_style "fegeteszov"
        if szedvicbenvaj == False:
            frame:
                background ('fram')
                xpos 0.1
                ypos 0.45
                xalign 0.5
                textbutton "Butter":
                    mouse "aktion"
                    action Jump ("szedvicbenvaj")
                    text_style "fegeteszov"
        if szedvicbenparizsi == False:
            if szedvicbenszalami == False:
                frame:
                    background ('fram')
                    xpos 0.9
                    ypos 0.15
                    xalign 0.5
                    textbutton "Slices of Paris":
                        mouse "aktion"
                        action Jump ("szedvicbenparizsi")
                        text_style "fegeteszov"
                frame:
                    background ('fram')
                    xpos 0.9
                    ypos 0.35
                    xalign 0.5
                    textbutton "Salami":
                        mouse "aktion"
                        action Jump ("szedvicbenszalami")
                        text_style "fegeteszov"
        if szedvicbensalata == False:
            frame:
                background ('fram')
                xpos 0.9
                ypos 0.25
                xalign 0.5
                textbutton "Salat":
                    mouse "aktion"
                    action Jump ("szedvicbensalata")
                    text_style "fegeteszov"
    if vanszedvicsed == True:
        if hanyadiknapvan == 2:
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.45
                xalign 0.5
                textbutton "Put it in my pocket.":
                    mouse "aktion"
                    action Jump ("szedvicsazinvertoriba")
                    text_style "fegeteszov"
            if megetedvanszedvicsed <= 2:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.55
                    xalign 0.5
                    textbutton "Eat it.":
                        mouse "aktion"
                        action Jump ("szedvicmegeszed")
                        text_style "fegeteszov"
        if hanyadiknapvan == 3:
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.45
                xalign 0.5
                textbutton "I put it in my pocket. I will eat this at the university.":
                    mouse "aktion"
                    action Jump ("szedvicsazinvertoriba")
                    text_style "fegeteszov"
            if megetedvanszedvicsed <= 2:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.55
                    xalign 0.5
                    textbutton "Eat it.":
                        mouse "aktion"
                        action Jump ("szedvicmegeszed")
                        text_style "fegeteszov"
        if hanyadiknapvan == 4:
            vbox xpos 0.5 ypos 0.5 xalign 0.5 yalign 0.5 spacing 50:
                if ennivini <= 2:
                    frame:
                        background ('fram')
                        xalign 0.5
                        textbutton "I put it in my pocket. I will eat this at the university.":
                            mouse "aktion"
                            action Jump ("szedvicsazinvertoriba")
                            text_style "fegeteszov"
                if mamaszedvicsetker == True:
                    if mamaszedvicsetker4resz == False:
                        frame:
                            background ('fram')
                            xalign 0.5
                            textbutton "A sandwich for Grandma.":
                                mouse "aktion"
                                action Jump ("szedvicsazinvertoribamamanak")
                                text_style "fegeteszov"
                if megetedvanszedvicsed <= 2:
                    frame:
                        background ('fram')
                        xalign 0.5
                        textbutton "Eat it.":
                            mouse "aktion"
                            action Jump ("szedvicmegeszed")
                            text_style "fegeteszov"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
