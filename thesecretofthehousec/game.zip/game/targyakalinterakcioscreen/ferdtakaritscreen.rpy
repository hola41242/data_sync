screen takaritabahagy:
    frame:
        background ('fram')
        xpos 0.15
        ypos 0.9
        xalign 0.5
        textbutton "I do not clean up.":
            mouse "aktion"
            action Jump ("takaritabahagy")
            text_style "fegeteszov"
screen ferdtakarit:
    if szivacskoszoslett >= 11:
        if dolgozoltakaritido >= 1:
            timer 0.1 repeat True action Jump ('takaritabahagy')
        if dolgozoltakarit2ido >= 1:
            timer 0.1 repeat True action Jump ('takaritabahagy')
        if dolgozoltakarit3ido >= 1:
            timer 0.1 repeat True action Jump ('takaritabahagy')
    if csinalszvalamit == "takarit":
        timer 1.0 repeat True action If(dolgozoltakaritido <= 0,
        true=[SetVariable('fifipisi1', True),
        Hide('takaritabahagy'),Hide('ferdtakarit'),
        Jump('takaritaskesz')],
        false=[SetVariable('dolgozoltakaritido', dolgozoltakaritido - 1),
        SetVariable('szivacskoszoslett', szivacskoszoslett + 1),
        SetVariable('dolgozoltakaritelteltido', dolgozoltakaritelteltido + 1)])
        bar:
            left_bar "#f00"
            if dolgozoltakaritido <= 5:
                left_bar "#0ff"
            if dolgozoltakaritido <= 0:
                left_bar "#0f0"
            value StaticValue(dolgozoltakaritelteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if csinalszvalamit == "takarit2":
        timer 1.0 repeat True action If(dolgozoltakarit2ido <= 0,
        true=[SetVariable('fifipisi2', True),
        Hide('takaritabahagy'),Hide('ferdtakarit'),
        Jump('takaritaskesz')],
        false=[SetVariable('dolgozoltakarit2ido', dolgozoltakarit2ido - 1),
        SetVariable('szivacskoszoslett', szivacskoszoslett + 1),
        SetVariable('dolgozoltakarit2elteltido', dolgozoltakarit2elteltido + 1)])
        bar:
            left_bar "#f00"
            if dolgozoltakarit2ido <= 5:
                left_bar "#0ff"
            if dolgozoltakarit2ido <= 0:
                left_bar "#0f0"
            value StaticValue(dolgozoltakarit2elteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if csinalszvalamit == "takarit3":
        timer 1.0 repeat True action If(dolgozoltakarit3ido <= 0,
        true=[SetVariable('fifipisi3', True),
        Hide('takaritabahagy'),Hide('ferdtakarit'),
        Jump('takaritaskesz2')],
        false=[SetVariable('dolgozoltakarit3ido', dolgozoltakarit3ido - 1),
        SetVariable('szivacskoszoslett', szivacskoszoslett + 1),
        SetVariable('dolgozoltakarit3elteltido', dolgozoltakarit3elteltido + 1)])
        bar:
            left_bar "#f00"
            if dolgozoltakarit3ido <= 5:
                left_bar "#0ff"
            if dolgozoltakarit3ido <= 0:
                left_bar "#0f0"
            value StaticValue(dolgozoltakarit3elteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if csinalszvalamit == "takarit4":
        timer 1.0 repeat True action If(dolgozoltakaritido <= 0,
        true=[SetVariable('kakialatpisi', 2),
        Hide('takaritabahagy'),Hide('ferdtakarit'),
        Jump('takaritaskesz4')],
        false=[SetVariable('dolgozoltakaritido', dolgozoltakaritido - 1),
        SetVariable('szivacskoszoslett', szivacskoszoslett + 1),
        SetVariable('dolgozoltakaritelteltido', dolgozoltakaritelteltido + 1)])
        bar:
            left_bar "#f00"
            if dolgozoltakaritido <= 10:
                left_bar "#0ff"
            if dolgozoltakaritido <= 0:
                left_bar "#0f0"
            value StaticValue(dolgozoltakaritelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen ferdporszivoz:
    frame:
        background ('fram')
        xpos 0.15
        ypos 0.9
        xalign 0.5
        textbutton "Stop cleaning.":
            mouse "aktion"
            action Jump ("porszivozabahagy")
            text_style "fegeteszov"
    if holvagyok == "fojasojobb":
        timer 1.0 repeat True action If(porszivozfojasojobbido <= 0,
        true=[SetVariable('porszivozfojasojobb', 1),
        SetVariable('porszivozotszobak', porszivozotszobak + 1),
        Hide('ferdporszivoz'),
        Jump('porszivozabahagy')],
        false=[SetVariable('porszivozfojasojobbido', porszivozfojasojobbido - 1),
        SetVariable('porszivozfojasojobbelteltido', porszivozfojasojobbelteltido + 1)])
        bar:
            left_bar "#f00"
            if porszivozfojasojobbido <= 10:
                left_bar "#0ff"
            if porszivozfojasojobbido <= 0:
                left_bar "#0f0"
            value StaticValue(porszivozfojasojobbelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if holvagyok == "fojasoball":
        timer 1.0 repeat True action If(porszivozfojasobalido <= 0,
        true=[SetVariable('porszivozfojasobal', 1),
        SetVariable('porszivozotszobak', porszivozotszobak + 1),
        Hide('ferdporszivoz'),
        Jump('porszivozabahagy')],
        false=[SetVariable('porszivozfojasobalido', porszivozfojasobalido - 1),
        SetVariable('porszivozfojasobaleltelido', porszivozfojasobaleltelido + 1)])
        bar:
            left_bar "#f00"
            if porszivozfojasobalido <= 10:
                left_bar "#0ff"
            if porszivozfojasobalido <= 0:
                left_bar "#0f0"
            value StaticValue(porszivozfojasobaleltelido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if holvagyok == "napaliban":
        timer 1.0 repeat True action If(porszivoznapaliido <= 0,
        true=[SetVariable('porszivoznapali', 1),
        SetVariable('porszivozotszobak', porszivozotszobak + 1),
        Hide('ferdporszivoz'),
        Jump('porszivozabahagy')],
        false=[SetVariable('porszivoznapaliido', porszivoznapaliido - 1),
        SetVariable('porszivoznapalielteltido', porszivoznapalielteltido + 1)])
        bar:
            left_bar "#f00"
            if porszivoznapaliido <= 10:
                left_bar "#0ff"
            if porszivoznapaliido <= 0:
                left_bar "#0f0"
            value StaticValue(porszivoznapalielteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if holvagyok == "atjaro":
        timer 1.0 repeat True action If(porszivozatjaroido <= 0,
        true=[SetVariable('porszivozatjaro', 1),
        SetVariable('porszivozotszobak', porszivozotszobak + 1),
        Hide('ferdporszivoz'),
        Jump('porszivozabahagy')],
        false=[SetVariable('porszivozatjaroido', porszivozatjaroido - 1),
        SetVariable('porszivozatjaroelteltido', porszivozatjaroelteltido + 1)])
        bar:
            left_bar "#f00"
            if porszivozatjaroido <= 10:
                left_bar "#0ff"
            if porszivozatjaroido <= 0:
                left_bar "#0f0"
            value StaticValue(porszivozatjaroelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if holvagyok == "furdo":
        timer 1.0 repeat True action If(porszivozfurdoido <= 0,
        true=[SetVariable('porszivozfurdo', 1),
        SetVariable('porszivozotszobak', porszivozotszobak + 1),
        Hide('ferdporszivoz'),
        Jump('porszivozabahagy')],
        false=[SetVariable('porszivozfurdoido', porszivozfurdoido - 1),
        SetVariable('porszivozfurdoelteltido', porszivozfurdoelteltido + 1)])
        bar:
            left_bar "#f00"
            if porszivozfurdoido <= 5:
                left_bar "#0ff"
            if porszivozfurdoido <= 0:
                left_bar "#0f0"
            value StaticValue(porszivozfurdoelteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if holvagyok == "konyha":
        timer 1.0 repeat True action If(porszivozkonyhaido <= 0,
        true=[SetVariable('porszivozkonyha', 1),
        SetVariable('porszivozotszobak', porszivozotszobak + 1),
        Hide('ferdporszivoz'),
        Jump('porszivozabahagy')],
        false=[SetVariable('porszivozkonyhaido', porszivozkonyhaido - 1),
        SetVariable('porszivozkonyhaelteltido', porszivozkonyhaelteltido + 1)])
        bar:
            left_bar "#f00"
            if porszivozkonyhaido <= 5:
                left_bar "#0ff"
            if porszivozkonyhaido <= 0:
                left_bar "#0f0"
            value StaticValue(porszivozkonyhaelteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
