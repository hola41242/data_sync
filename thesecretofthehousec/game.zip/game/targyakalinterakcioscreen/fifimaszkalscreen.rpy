screen fifimozog:
    if hanyadiknapvan == 2:
        if fifitfelvetem == False:
            if egyszervegigment == False:
                if fifiholcsinal == "napaliban":
                    timer 1.0 repeat True action If(fificsinalido <= 0,
                    true=[SetVariable('fificsinalido', fificsinalido + 20),
                    SetVariable('fifiholcsinal', "fojasoball"),
                    SetVariable('fifiballfoban', True)],
                    false=[SetVariable('fificsinalido', fificsinalido - 1)])
                    if holvagyok == "napaliban":
                        if fifinapaliban == True:
                            timer 2.0 repeat True action Jump ("fifinapalibanmozog")
                if fifiholcsinal == "fojasoball":
                    timer 1.0 repeat True action If(fificsinalido <= 0,
                    true=[SetVariable('fificsinalido', fificsinalido + 20),
                    SetVariable('fifiholcsinal', "napaliban2"),
                    SetVariable('fifipisilt', fifipisilt + 1),
                    SetVariable('fifinapaliban', True)],
                    false=[SetVariable('fificsinalido', fificsinalido - 1)])
                    if holvagyok == "fojasoball":
                        if fifiballfoban == True:
                            timer 2.0 repeat True action Jump ("fififojasoballbanmozog")
                if fifiholcsinal == "napaliban2":
                    timer 1.0 repeat True action If(fificsinalido <= 0,
                    true=[SetVariable('fificsinalido', fificsinalido + 60),
                    SetVariable('fifiholcsinal', "napaliban3"),
                    SetVariable('fifipisilt', fifipisilt + 1),
                    SetVariable('fifinapaliban', True)],
                    false=[SetVariable('fificsinalido', fificsinalido - 1)])
                    if holvagyok == "napaliban":
                        if fifinapaliban == True:
                            timer 2.0 repeat True action Jump ("fifinapalibanmozog")
                if fifiholcsinal == "napaliban3":
                    timer 1.0 repeat True action If(fificsinalido <= 0,
                    true=[SetVariable('fificsinalido', fificsinalido + 20),
                    SetVariable('fifiholcsinal', "napaliban4"),
                    SetVariable('fifinapaliban', True)],
                    false=[SetVariable('fificsinalido', fificsinalido - 1)])
                    if holvagyok == "napaliban":
                        if fifinapaliban == True:
                            timer 2.0 repeat True action Jump ("fifinapalibanmozog")
                if fifiholcsinal == "napaliban4":
                    timer 1.0 repeat True action If(fificsinalido <= 0,
                    true=[SetVariable('fificsinalido', fificsinalido + 120),
                    SetVariable('fifiholcsinal', "atjaro"),
                    SetVariable('fifipisilt', fifipisilt + 1),
                    SetVariable('egyszervegigment', True),
                    SetVariable('fifiatjaroban', True)],
                    false=[SetVariable('fificsinalido', fificsinalido - 1)])
                    if holvagyok == "napaliban":
                        if fifinapaliban == True:
                            timer 2.0 repeat True action Jump ("fifinapalibanmozog")
                if fifiholcsinal == "atjaro":
                    timer 1.0 repeat True action If(fificsinalido <= 0,
                    true=[Hide ('fifimozog'),Jump ('gameover')],
                    false=[SetVariable('fificsinalido', fificsinalido - 1)])
                    if holvagyok == "atjaro":
                        if fifiatjaroban == True:
                            timer 2.0 repeat True action Jump ("fifiatjarobanmozog")
            if egyszervegigment == True:
                if fifiholcsinal == "napaliban":
                    timer 1.0 repeat True action If(fificsinalido <= 0,
                    true=[SetVariable('fificsinalido', fificsinalido + 60),
                    SetVariable('fifiholcsinal', "napaliban5"),
                    SetVariable('fifinapaliban', True)],
                    false=[SetVariable('fificsinalido', fificsinalido - 1)])
                    if holvagyok == "napaliban":
                        if fifinapaliban == True:
                            timer 2.0 repeat True action Jump ("fifinapalibanmozog")
                if boritekazinvertoriba == False:
                    if fifiholcsinal == "napaliban5":
                        timer 1.0 repeat True action If(fificsinalido <= 0,
                        true=[SetVariable('fificsinalido', fificsinalido + 120),
                        SetVariable('fifiholcsinal', "atjaro"),
                        SetVariable('egyszervegigment', True),
                        SetVariable('fifiatjaroban', True)],
                        false=[SetVariable('fificsinalido', fificsinalido - 1)])
                        if holvagyok == "napaliban":
                            if fifinapaliban == True:
                                timer 2.0 repeat True action Jump ("fifinapalibanmozog")
                                if csinalszvalamit == "tvprogramoz":
                                    timer 0.1 repeat True action SetVariable('fifinapaliban', False)
                if boritekazinvertoriba == True:
                    if fifiholcsinal == "napaliban5":
                        timer 1.0 repeat True action If(fificsinalido <= 0,
                        true=[SetVariable('fificsinalido', fificsinalido + 120),
                        SetVariable('fifiholcsinal', "napaliban")],
                        false=[SetVariable('fificsinalido', fificsinalido - 1)])
                if fifiholcsinal == "atjaro":
                    timer 1.0 repeat True action If(fificsinalido <= 0,
                    true=[Hide ('fifimozog'),Jump ('gameover')],
                    false=[SetVariable('fificsinalido', fificsinalido - 1)])
                    if holvagyok == "atjaro":
                        if fifiatjaroban == True:
                            timer 2.0 repeat True action Jump ("fifiatjarobanmozog")
                    if holvagyok == "napaliban":
                        if fifiatjaroban == True:
                            timer 2.0 repeat True action Jump ("fifiatjarobamegy")

screen ujraszamolinvertori:
    timer 1.0 repeat True action SetVariable('invertorieszkozszam', receptnalad + tojasnalad + uditosmagamhozveni + tulipannalad + lizaviragnalad + gyongyviragnalad + elesztonalad + poknalad + gombanalad), Hide ('ujraszamolinvertori')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
