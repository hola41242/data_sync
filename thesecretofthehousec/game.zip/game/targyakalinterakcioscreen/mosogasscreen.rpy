screen mosogatabahagy:
    if csinalszvalamit == "mosogat":
        frame:
            background ('fram')
            xpos 0.15
            ypos 0.85
            xalign 0.5
            textbutton "I don't do the{p}dishes anymore.":
                mouse "aktion"
                action Jump ("mosogatabahagy")
                text_style "fegeteszov"
    if csinalszvalamit == "mosogat2":
        frame:
            background ('fram')
            xpos 0.15
            ypos 0.85
            xalign 0.5
            textbutton "I stop cleaning{p}the sponge.":
                mouse "aktion"
                action Jump ("mosogatabahagy")
                text_style "fegeteszov"


screen ferdmosogat:
    if csinalszvalamit == "mosogat":
        timer 1.0 repeat True action If(dolgozolmosogatasido <= 0,
        true=[SetVariable('dolgozolmosogatas', dolgozolmosogatas + 1),
        Hide('mosogatabahagy'),Hide('ferdmosogat'),
        Jump('mosogataskesz')],
        false=[SetVariable('dolgozolmosogatasido', dolgozolmosogatasido - 1),
        SetVariable('dolgozolmosogataselteltido', dolgozolmosogataselteltido + 1)])
        if hanyadiknapvan <= 4:
            bar:
                left_bar "#f00"
                if dolgozolmosogatasido <= 30:
                    left_bar "#0ff"
                if dolgozolmosogatasido <= 0:
                    left_bar "#0f0"
                value StaticValue(dolgozolmosogataselteltido, 60) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
        if hanyadiknapvan == 5:
            bar:
                left_bar "#f00"
                if dolgozolmosogatasido <= 15:
                    left_bar "#0ff"
                if dolgozolmosogatasido <= 0:
                    left_bar "#0f0"
                value StaticValue(dolgozolmosogataselteltido, 30) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if hanyadiknapvan == 3:
        if dolgozolmosogatasido == 40:
            if debraeszik == 0:
                timer 0.1 repeat True action Jump ('debraeszik')
        if dolgozolmosogatasido == 10:
            if debraeszik == 1:
                timer 0.1 repeat True action Jump ('debraeszik')

    if csinalszvalamit == "mosogat2":
        if szivacskoszoslettidoszamol == False:
            timer 0.01 repeat True action If(szivacskoszoslettidoszamol == False,
            true=[SetVariable('szivacskoszoslettido', szivacskoszoslettido + (szivacskoszoslett * 0.5)),
            SetVariable('dolgozolmosogataselteltido2', 0),
            SetVariable('szivacskoszoslettidoszamol', True)],
            false=[])
        timer 0.5 repeat True action If(szivacskoszoslett <= 0,
        true=[SetVariable('dolgozolmosogataselteltido2', 0),
        Hide('mosogatabahagy'),Hide('ferdmosogat'),
        Jump('mosogataskesz')],
        false=[SetVariable('szivacskoszoslett', szivacskoszoslett - 1),
        SetVariable('dolgozolmosogataselteltido2', dolgozolmosogataselteltido2 + 1)])
        if hanyadiknapvan == 5:
            bar:
                left_bar "#f00"
                if szivacskoszoslett <= szivacskoszoslettido * 0.5:
                    left_bar "#0ff"
                if szivacskoszoslett <= 0:
                    left_bar "#0f0"
                if szivacskoszoslettidoszamol == True:
                    value StaticValue(dolgozolmosogataselteltido2, szivacskoszoslettido) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
