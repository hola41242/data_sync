label nyomortanya:
    $ holvagyok = "nyomortanya"
    jump tiltasok
$ renpy. pause(hard=True)
label nyomortanyaszov:
    $ invertorialapjelenyenmeg = True
    show nyomortanyaalap
    if nyomortanyabago1 == 1:
        show nyomortanyabago1
    if nyomortanyabago2 == 1:
        show nyomortanyabago2
    if nyomortanyabago3 == 1:
        show nyomortanyabago3
    if nyomortanyabago4 == 1:
        show nyomortanyabago4
    if nyomortanyabago5 == 1:
        show nyomortanyabago5
    if nyomortanyabago6 == 1:
        show nyomortanyabago6
    if nyomortanyabago7 == 1:
        show nyomortanyabago7
    if nyomortanyadoboz1nalad == 0:
        show nyomortanyadoboz1
    if nyomortanyadoboz2nalad == 0:
        show nyomortanyadoboz2
    if nyomortanyadoboz3nalad == 0:
        show nyomortanyadoboz3
    if nyomortanyakoszosruhanalad == 0:
        show nyomortanyakoszosruha
    if nyomortanyamama == 1:
        show nyomortanyamama
    if nyomortanyakod == 1:
        show nyomortanyakod onlayer elotte
    if boboholvan == "nyomortanya":
        show boboalap:
            zoom 0.9
            xpos 0.3
            ypos 0.35

    if nyomortanyanjartal == 0:
        $ nyomortanyanjartal = 1
        jump nyomortanyajelenet1

    jump engedejek
$ renpy. pause(hard=True)
label nyomortanyacigeretacikeshamutarto:
    hide screen nyomortanya
    f "Used cigarettes and an old ashtray."
    show screen nyomortanya
$ renpy. pause(hard=True)
label nyomortanyacigeretacik:
    hide screen nyomortanya
    f "Used cigarettes."
    show screen nyomortanya
$ renpy. pause(hard=True)
label boriszruhajatfel:
    hide screen nyomortanya
    f "This dress is the same dress in the photo."
    $ nyomortanyakoszosruhanalad = 1
    $ szenyesnalad = True
    $ szenyeskimosva = False
    $ mosopor = False
    show nyomortanyakoszosruha:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen nyomortanya
$ renpy. pause(hard=True)
label doboztmagadhozvenni3:
    hide screen nyomortanya
    f "Heavy! What could be in this box?"
    f "I can carry only one box of these each time."
    $ nyomortanyadoboz3nalad = 1
    $ tiltjaatereketsetlanahaza = False
    show nyomortanyadoboz3:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen nyomortanya
$ renpy. pause(hard=True)
label doboztmagadhozvenni2:
    hide screen nyomortanya
    if nyomortanyadoboz3nalad == 1:
        f "It is too heavy. I can carry only one of these boxes."
        show screen nyomortanya
        $ renpy. pause(hard=True)
    $ nyomortanyadoboz2nalad = 1
    show nyomortanyadoboz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen nyomortanya
$ renpy. pause(hard=True)
label doboztmagadhozvenni1:
    hide screen nyomortanya
    if nyomortanyadoboz2nalad == 1:
        f "It is too heavy. I can carry only one of these boxes."
        show screen nyomortanya
        $ renpy. pause(hard=True)
    $ nyomortanyadoboz1nalad = 1
    show nyomortanyadoboz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen nyomortanya
$ renpy. pause(hard=True)
label nyomortanyajelenet1:
    $ svetlanahaza = True
    show svetlana1080:
        xpos 0.17
        ypos 0.05
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    ed "What kind of dress is this? You murderer!"
    s "Do not start this over again Mom..."
    show nyomortanyaalapkozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show editpoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show svetlanapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    ed "What? You killed my son!"
    s "This is not true and you know this Mom..."
    ed "You made the memory of my son dirty you wore! Where have you been yesterday night?"
    s "I spent the night in my new home. I asked you several times to come but you just do not listen to me…"
    show svetlanapoz1s2 onlayer elotte
    s "You said you are waiting for your son and you will not move from here without him…"
    ed "Yes! Where is my son? He will come and take us…"
    s "Fucking amazing... You forgot again. Your son died Mom..."
    ed "This is not true! You lie to me! You can not trick me! You chased him away..."
    hide svetlanapoz1s2 onlayer elotte
    s "Yes... and I choose you to take care of..."
    ed "You want my money and my home. You have nothing and you need me to be fine financially…"
    show svetlanapoz1s2 onlayer elotte
    s "Let us stop this nonsense talk. Our helper arrived it seems. He will carry the heavy boxes to the new home and he will bring you to the house."
    play music "audio/balesetala.ogg" fadeout 1
    show nyomortanyaalapkozeli3 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide svetlanapoz1s2 onlayer elotte
    hide svetlanapoz1 onlayer elotte
    show svetlanapoz1 onlayer elotte:
        alpha 0.0
        linear 2.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 2.0 alpha 1.0
    show screen s3
    u ""
    hide nyomortanyaalapkozeli onlayer elotte
    hide editpoz1 onlayer elotte
    hide svetlanapoz1s2 onlayer elotte
    s "I am glad you are here Fred!"
    f "Hello! Who is this old lady?"
    s "She is my mother-in-law."
    f "You never told me you are married."
    show svetlanapoz1s2 onlayer elotte
    s "Yeap. I do not like to talk about this. Memories hurt, you know?"
    f "The old lady talked about your husband. She told you chased him away. She told first you killed him. What happened?"
    show ferdpoz1szemlefelenez onlayer elotte
    f "I can not believe a guy would leave you alone."
    hide svetlanapoz1s2 onlayer elotte
    s "Hey Fred! My eyes are up there! What are you looking at?"
    hide ferdpoz1szemlefelenez onlayer elotte
    s "Thank you! You know... Mom is not the same as before. He changed when her son died."
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Did you kill him? Did you land in the jail and you lose everything? Is this the reason why you live here?"
    show svetlanapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show svetlanapoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    s "Are you really such a bastard? Or are you just playing to be dump?"
    show fiupoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Tell me your story please! Maybe I can help…"
    s "Maybe you are right. You will shut up at least…"
    show svetlanapoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show svetlanapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    s "Let me start the story when my life totally changed."
    s "We lived in Russia. I lived in Russia with my husband and with her mother, Edit."
    s "I was an orphan, but after the marriage I had a nice family. "
    s "Boris was a real estate salesman and he got a great offer from America."
    s "I advised him to accept the great offer and we moved to America."
    s "My life was just like a dream, a dream I never wanted to wake from."
    hide fekete onlayer elotte
    show fekete onlayer elotte:
        alpha 0.0
        linear 3.0 alpha 1.0
    s "Everything was so nice. Edit helped a lot around the house, she was not a fool, like she is now..."
    show fekete onlayer elotte:
        alpha 1.0
    s "You know… I was pregnant at that time and I had a biiig tummy..."
    show svetlanabaleset1 onlayer elotte:
        alpha 0.0
    show svetlanabaleset2 onlayer elotte:
        alpha 0.0
        linear 2.0 alpha 1.0
    show svetlanabaleset3 onlayer elotte:
        alpha 0.0
    show screen s2
    u ""
    s "I can remember, Edit helped me a lot with the housework and she took care of me like a fantastic mother..."
    s "I was so happy and we had only a few weeks to let the baby be born..."
    s "I had to go to the hospital to do some research. Boris took a day off so he could drive me to the hospital."
    show svetlanabaleset1 onlayer elotte:
        alpha 0.0
        linear 2.0 alpha 1.0
    show svetlanabaleset3 onlayer elotte:
        alpha 0.0
        linear 2.0 alpha 1.0
    show screen s2
    u ""
    s "I can remember that Wednesday really well. The baby was 8 months old in my tummy..."
    s "Boris drived the car. He drove so well. He drove very safely. He never drove fast..."
    s "He told me: If you have to go somewhere, go earlier, not faster…"
    hide fekete onlayer elotte
    show fekete onlayer elotte:
        alpha 0.0
        linear 3.0 alpha 1.0
    s "But a truck driver slept in and he switched to the opposite lane..."
    show fekete onlayer elotte:
        alpha 1.0
    queue sound "audio/baleset.ogg"
    queue sound "audio/ambulance.ogg"
    s "He did not use a break and he run into our car full speed.Boris shouted:"
    s "Take care of our Baby Svetlana!"
    s "After that I saw only darkness around me and I heard some noises... I felt a terrible pain in my stomach. I remember the sound of the ambulance car and that I could not move..."
    s "I woke up many days later in the hospital..."
    s "I could barely talk. I asked about the baby... The Dr. saied:"
    o "I am sorry. I have bad news for you. Your husband died in the accident and you lost the baby after arriving at the hospital."
    o "We called your mother-in-law and she had a nervous breakdown."
    s "So you can think how I felt…"
    s "We, me and Edit are not the same since that day…"
    s "I paid all bills for the hospital and paid for the funeral. We had to spend all our money. We had to sell our home."
    s "But you know… I do not care about the money. The only thing I can not handle is I could not fulfill the last wish of Boris… I lost the Baby, I could not protect him..."
    hide fekete onlayer elotte
    hide fiupoz1 onlayer elotte
    hide svetlanabaleset1 onlayer elotte
    hide svetlanabaleset2 onlayer elotte
    hide svetlanabaleset3 onlayer elotte
    show fiupoz5 onlayer elotte
    stop sound
    show fekete onlayer elotte:
        alpha 1.0
        linear 3.0 alpha 0.0
    f "What should I say? This is terrible!"
    s "It's so nice you can find a word for this… Listening to such a story and being a part of it are two different things..."
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz5 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    s "Now you know my story, so please help me carry the boxes to our new home. Here is the money I promised."
    $ penz += 3500
    s "Mom does not understand english so well, so try to talk to her in russian if needed..."
    s "Your job is to carry these big boxes to my house and you have to bring Mom to the house. Here is my address. I had no paper so I wrote the address on this."
    s "This is an old photo of my Boris. The address is on the other side. Give me back this photo after you finish please!"
    s "I have a lot of photos of him but still.. I do not want to lose any of them..."
    f "Ok, but why is Mom not moving with you?"
    s "She is kind of stubborn. She wishes to leave only with her son... But he died…"
    f "Fine... but how should I solve this problem?"
    show svetlanapoz1s2 onlayer elotte
    s "I do not know. I have to go now. These memories made me feel dizzy. I have to rest a bit."
    s "Bring me the boxes please. I will wait for you there and I will tell you where to put them."
    f "Ok! See you soon!"
    show svetlanapoz1s2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show svetlanapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ hazamehetc = False
    $ boriszfenykepenalad = 1
    $ tiltjaatereketsetlanahaza = True
    $ svetlanaholvan = "svetlanaatjarojaban"
    $ fekete = True
    show screen s1
    u ""
    play music "audio/iskolaesterkep.ogg" fadeout 1
    hide svetlanapoz1s2 onlayer elotte
    hide svetlanapoz1 onlayer elotte
    hide svetlana1080
    show nyomortanyaalapkozeli3 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    jump engedejek
$ renpy. pause(hard=True)
label edittelbeszelninyomortanyan:
    hide screen nyomortanya
    $ fekete = True
    hide nyomortanyaalapkozeli onlayer elotte
    hide editpoz1 onlayer elotte
    hide fiupoz1 onlayer elotte
    hide ferdpoz1szemlefelenez onlayer elotte
    hide fiupoz4 onlayer elotte
    show nyomortanyaalapkozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show editpoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show ferdpoz1szemlefelenez onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    $ beszelteledittel = True
    f "Good morning!"
    ed "What do you want?"
    f "You should go, you should live in a house Mom..."
    ed "Go then!"
    f "You should come with me... You should live there from now on..."
    ed "I do not understand you. Do you have a cigarette?"
    f "I do not smoke. It is unhealthy. I will bring you to Svetlana."
    ed "No! I don't want to go! I will go only if my son Boris brings me there..I don't want to go to that bitch! Она большая сука! Ты оставляешь меня в одиночестве!"
    show fiupoz1 onlayer elotte:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show ferdpoz1szemlefelenez onlayer elotte:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4 onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Fine. Should I pull her all the way long? She will shout very loud and I will get in trouble in no time..."
    show fiupoz1 onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show ferdpoz1szemlefelenez onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz4 onlayer elotte:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    f "I will come back for you later..."
    ed "Hy!"



    show nyomortanyaalapkozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show editpoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show ferdpoz1szemlefelenez onlayer elotte:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0

    jump engedejek
$ renpy. pause(hard=True)
label bobovalbeszelnianyomortanyan:
    hide screen nyomortanya
    show nyomortanyaalapkozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1szem2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show bobopoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""

    if bobonakadtalkokot == True:
        if kokonalad == 1:
            f "Hy Bobo! Could you help me a bit?"
            bo "If I could I would not help you either. You are an asshole!"
            f "I have to go now. Bye Bodo!"
        else:
            f "What is Daboa? Did you find a hobbit hole to use?"
            bo "Just move and do not talk to strangers!"
            f "I am cautious, but I like to get to know new people and make new friendships…"
            bo "So move on and be cautious and make friends somewhere else!"
            f "Why are you here?"
            bo "Not your business! Giraffe!"
            f "I have to go now..."
            bo "I will not miss you at all. I will remember you while I poop in the toilet."
    if bobonakadtalkokot == False:
        $ bobonakadtalkokot = True
        $ kokonalad -= 1
        f "Hy Bubu!"
        bo "My name is Bobo, not Bubu!"
        f "Oh yeah! I remember your name. I meant that…"
        bo "Are you afraid of me bastard?"
        f "Why would I?"
        bo "Because you have some more packages left."
        f "How do you know that?"
        bo "You know… Cili just called me and she told me you are the delivery boy today. Give me my bag and go away!"
        f "Ofcourse! Just let me bend really deep down first to reach your small hand…"
        bo "Lick my ass, giant!"
        if kokonalad == 1:
            $ lidiaholvan = "cukrazdabanszamlazik"
            $ debraholcsinal = "napaliban3"




    show nyomortanyaalapkozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1szem2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show bobopoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen nyomortanya
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
