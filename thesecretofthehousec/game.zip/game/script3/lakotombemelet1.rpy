label lakotomb1emelet:
    $ holvagyok = "lakotomb1emelet"
    jump tiltasok
$ renpy. pause(hard=True)
label lakotomb1emeletszov:
    $ invertorialapjelenyenmeg = True
    $ viragnovekszik = 4
    show lakotomb1emelet
    show pilango animated:
        xalign 0.56
        yalign 0.44
    show pilango1 animated:
        xzoom -1.0
        xalign 0.524
        yalign 0.45
    show pilango2 animated:
        zoom 0.8
        xalign 0.543
        yalign 0.424
    show pilango4 animated:
        xzoom -1.0
        zoom 1.1
        xalign 0.552
        yalign 0.4
    show pilango5 animated:
        xzoom -1.0
        xalign 0.53
        yalign 0.39
    show pilango6 animated:
        xzoom -1.0
        xalign 0.533
        yalign 0.416
    show pilango7 animated:
        zoom 0.9
        xalign 0.528
        yalign 0.45
    show pilango8 animated:
        xzoom -1.0
        zoom 0.6
        xalign 0.528
        yalign 0.45
    if naptar == 2:
        show naptar9:
            zoom 0.8
            xzoom -0.7
            rotate -5.0
            xalign 0.41
            yalign 0.39
    if naptar == 1:
        show naptar5:
            zoom 0.8
            xzoom -0.7
            rotate -5.0
            xalign 0.41
            yalign 0.39
    if naptar == 0:
        show naptar1:
            zoom 0.8
            xzoom -0.7
            rotate -5.0
            xalign 0.41
            yalign 0.39
    show kana1:
        xalign 0.425
        yalign 0.9
    show ladafolyson onlayer hatso:
        xalign 0.425
        yalign 0.9
    if viragnovekszik == 5:
        show novekvovirag8 onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvovirag8k onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvovirag8p onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirag8s onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvovirag8f onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 4:
        show novekvovirag7f onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvovirag7k onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvovirag7p onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirag7s onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvovirag7ff onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 3:
        show novekvovirag5 onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvovirag5k onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvovirag5p onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirag5s onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvovirag5f onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 2:
        show novekvovirag3 onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvovirag3k onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvovirag3p onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirag3s onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvovirag3f onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 1:
        show novekvovirag1 onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvovirag1k onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvovirag1p onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirag1s onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvovirag1f onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if sabrinaholvan == "lakotombemelet1":
        show sabrina:
            xzoom -1.0
            zoom 0.4
            xpos 0.445
            ypos 0.44
    jump engedejek
$ renpy. pause(hard=True)
label naptar:
    if naptar == 2:
        hide screen lakotomb1emelet
        play sound "audio/elvesz2.wav"
        $ naptar = 0
        hide naptar9
        hide naptar2 animated
        show naptar3 animated:
            zoom 0.8
            xzoom -0.7
            rotate -5.0
            xalign 0.41
            yalign 0.39
        pause 0.4
        show screen lakotomb1emelet
        $ renpy. pause(hard=True)
    if naptar == 1:
        play sound "audio/elvesz2.wav"
        hide screen lakotomb1emelet
        $ naptar = 2
        hide naptar5
        hide naptar1 animated
        show naptar2 animated:
            zoom 0.8
            xzoom -0.7
            rotate -5.0
            xalign 0.41
            yalign 0.39
        pause 0.4
        show screen lakotomb1emelet
        $ renpy. pause(hard=True)
    if naptar == 0:
        play sound "audio/elvesz2.wav"
        hide screen lakotomb1emelet
        $ naptar = 1
        hide naptar1
        hide naptar3 animated
        show naptar1 animated:
            zoom 0.8
            xzoom -0.7
            rotate -5.0
            xalign 0.41
            yalign 0.39
        pause 0.4
        show screen lakotomb1emelet
$ renpy. pause(hard=True)
label locsolanimszov:
    $ locsol = 1
    hide screen lakotomb1emelet
    hide kanaviz animated onlayer kozep2
    hide kana animated
    hide kana1
    play sound "audio/viz13.ogg"
    show kana animated:
        xalign 0.425
        yalign 0.9
    show kanaviz animated onlayer kozep2:
        xalign 0.425
        yalign 0.9
    show screen s1
    u ""
    if viragnovekszik == 4:
        $ viragnovekszik = 4
        show screen lakotomb1emelet
        $ renpy. pause(hard=True)
    if viragnovekszik == 6:
        $ viragnovekszik = 0
    if viragnovekszik == 5:
        hide novekvovirag8 onlayer kozep
        hide novekvovirag8f onlayer kozep
        hide novekvovirag8k onlayer kozep
        hide novekvovirag8p onlayer kozep
        hide novekvovirag8s onlayer kozep
        hide szarazviragf animated onlayer kozep
        hide szarazviragff animated onlayer kozep
        hide szarazviragk animated onlayer kozep
        hide szarazviragp animated onlayer kozep
        hide szarazvirags animated onlayer kozep
        $ viragnovekszik = 6
        play channel1 "audio/vir7.wav"
        show szarazviragf2 animated onlayer kozep:
            xalign 0.455
            yalign 0.79
        show szarazviragk2 animated onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show szarazviragp2 animated onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show szarazvirags2 animated onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show szarazviragff2 animated onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 4:
        hide novekvovirag7s onlayer kozep
        hide novekvovirag7p onlayer kozep
        hide novekvovirag7k onlayer kozep
        hide novekvovirag7f onlayer kozep
        hide novekvovirag7ff onlayer kozep
        hide novekvoviragf4 animated onlayer kozep
        hide novekvoviragff4 animated onlayer kozep
        hide novekvoviragk4 animated onlayer kozep
        hide novekvoviragp4 animated onlayer kozep
        hide novekvovirags4 animated onlayer kozep
        play channel1 "audio/vir6.wav"
        $ viragnovekszik = 5
        show szarazviragf animated onlayer kozep:
            xalign 0.455
            yalign 0.79
        show szarazviragk animated onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show szarazviragp animated onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show szarazvirags animated onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show szarazviragff animated onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 3:
        hide novekvovirag5 onlayer kozep
        hide novekvovirag5f onlayer kozep
        hide novekvovirag5k onlayer kozep
        hide novekvovirag5p onlayer kozep
        hide novekvovirag5s onlayer kozep
        hide novekvoviragf3 animated onlayer kozep
        hide novekvoviragff3 animated onlayer kozep
        hide novekvoviragk3 animated onlayer kozep
        hide novekvoviragp3 animated onlayer kozep
        hide novekvovirags3 animated onlayer kozep
        play channel1 "audio/vir4.wav"
        $ viragnovekszik = 4
        show novekvoviragf4 animated onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvoviragk4 animated onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvoviragp4 animated onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirags4 animated onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvoviragff4 animated onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 2:
        hide novekvovirag3 onlayer kozep
        hide novekvovirag3f onlayer kozep
        hide novekvovirag3k onlayer kozep
        hide novekvovirag3p onlayer kozep
        hide novekvovirag3s onlayer kozep
        hide novekvoviragf2 animated onlayer kozep
        hide novekvoviragff2 animated onlayer kozep
        hide novekvoviragk2 animated onlayer kozep
        hide novekvoviragp2 animated onlayer kozep
        hide novekvovirags2 animated onlayer kozep
        play channel1 "audio/vir3.wav"
        $ viragnovekszik = 3
        show novekvoviragf3 animated onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvoviragk3 animated onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvoviragp3 animated onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirags3 animated onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvoviragff3 animated onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 1:
        hide novekvovirag1 onlayer kozep
        hide novekvovirag1f onlayer kozep
        hide novekvovirag1k onlayer kozep
        hide novekvovirag1p onlayer kozep
        hide novekvovirag1s onlayer kozep
        hide novekvoviragf animated onlayer kozep
        hide novekvoviragff animated onlayer kozep
        hide novekvoviragk animated onlayer kozep
        hide novekvoviragp animated onlayer kozep
        hide novekvovirags animated onlayer kozep
        play channel1 "audio/vir2.wav"
        $ viragnovekszik = 2
        show novekvoviragf2 animated onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvoviragk2 animated onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvoviragp2 animated onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirags2 animated onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvoviragff2 animated onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932
    if viragnovekszik == 0:
        hide szarazviragf2 animated onlayer kozep
        hide szarazviragff2 animated onlayer kozep
        hide szarazviragk2 animated onlayer kozep
        hide szarazviragp2 animated onlayer kozep
        hide szarazvirags2 animated onlayer kozep
        play channel1 "audio/vir1.wav"
        $ viragnovekszik = 1
        show novekvoviragf animated onlayer kozep:
            xalign 0.455
            yalign 0.79
        show novekvoviragk animated onlayer kozep:
            zoom 1.05
            xalign 0.44
            yalign 0.87
        show novekvoviragp animated onlayer kozep:
            zoom 1.1
            xalign 0.428
            yalign 0.97
        show novekvovirags animated onlayer kozep:
            crop (0, 0, 369, 580)
            zoom 1.15
            xalign 0.415
            yalign 0.97
        show novekvoviragff animated onlayer kozep:
            crop (0, 0, 369, 540)
            zoom 1.2
            xalign 0.405
            yalign 0.932

    show screen lakotomb1emelet
$ renpy. pause(hard=True)
label locsolvissza:
    hide kana animated
    show kana1:
        xalign 0.425
        yalign 0.9
    $ locsol = 0
$ renpy. pause(hard=True)
label elsoemelethatso:
    hide screen lakotomb1emelet
    f "why should I enter this room?"
    show screen lakotomb1emelet
$ renpy. pause(hard=True)
label elsoemeletelso:
    hide screen lakotomb1emelet
    f "why should I enter this room?"
    show screen lakotomb1emelet
$ renpy. pause(hard=True)
label szabrinavalbeszelniemelet1gyen:
    hide screen lakotomb1emelet
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen invertori2
    show sabrinakozeliemelet1gyen onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    if kokonalad >= 1:
        if sabrinanakadtalkokot == False:
            $ sabrinanakadtalkokot = True
            $ kokonalad -= 1
            if beszeltelsabrinaval == False:
                f "Hy! My name is Fred."
                sab "Hello! My name is Sabrina. I like your t-shirt."
            f "Are you waiting for a package?"
            sab "Yes, I do."
            f "I think you're waiting for this small bag with ground sugar in it."
            sab "Yeap, but I will complain if I find ground sugar inside."
            f "Could you please just take the bag before someone might see us? It is dangerous…"
            sab "Sure. Give it to me! I never saw you, I do not know you. Alright?"
            f "Ok."
            if kokonalad == 1:
                $ lidiaholvan = "cukrazdabanszamlazik"
                $ debraholcsinal = "napaliban3"
            jump ugrik12napsabrina
    $ beszeltelsabrinaval = True
    f "Hy! My name is Fred."
    sab "Hello Fred! I like your t-shirt."
    f "I like your t-shirt, too."
    sab "Could you lend me your t-shirt?"
    f "I would lend you my t-shirt ,if you gave me yours."
    sab "Let me think about it. Maybe you could lend me something else…"
    f "I have not so much stuff... I should go now."
    sab "Ok. I am waiting for Anett."
    f "Goodbye!"
label ugrik12napsabrina:
    show sabrinakozeliemelet1gyen onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori
    show screen lakotomb1emelet
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
