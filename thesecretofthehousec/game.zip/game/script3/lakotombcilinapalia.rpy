label ciliszoba:
    $ holvagyok = "lakotombcilinapali"
    jump tiltasok
$ renpy. pause(hard=True)
label ciliszobaszov:
    show cilinappalia
    if sujzonalad == 2:
        show sujzoklizalan:
            xpos -0.4
            ypos 0.1
    if ciliholvan == "cilinapaliaban":
        if sujzonalad == 1:
            show cili:
                zoom 0.7
                xpos 0.5
                ypos 0.2
            jump cilijelenet12nap
    if ciliholvan == "cilinapaliabanul":
        show ciliulnapaliban

    jump engedejek
$ renpy. pause(hard=True)
label cililakasanemenged:
    hide screen ciliszoba
    f "why should I enter this room?"
    show screen ciliszoba
$ renpy. pause(hard=True)
label cililakasavirag:
    hide screen ciliszoba
    f "Flowers."
    show screen ciliszoba
$ renpy. pause(hard=True)
label cililakasmagazin:
    hide screen ciliszoba
    f "Magazin."
    show screen ciliszoba
$ renpy. pause(hard=True)
label cililakaskerm:
    hide screen ciliszoba
    f "Cream."
    show screen ciliszoba
$ renpy. pause(hard=True)
label cililakaslampa:
    hide screen ciliszoba
    f "Lamp."
    show screen ciliszoba
$ renpy. pause(hard=True)
label cililakaskep:
    hide screen ciliszoba
    f "This picture looks like a few newspapers glued on a paper."
    show screen ciliszoba
$ renpy. pause(hard=True)
label cilijelenet12nap:
    $ fekete = True
    $ ciliholvan = "cilinapaliabanul"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show cilinappaliakozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show cilipoz1 onlayer elotte:
        zoom 0.9
        xpos 0.1
        yalign 1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        ypos 0.07
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    c "Hy Fred! Nice to see you again!"
    f "I brought you the dumbbells from Liza. You can be happy!"
    c "Women do not like you for your brain, do they?"
    show fiupoz1 onlayer elotte:
        ypos 0.07
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz6 onlayer elotte:
        ypos 0.07
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Women love me for sure and… I have a great body for sure…"
    c "Are you kidding? I will get red from the shame…"
    f "Why do you think women love you? Are the dumbbells not heavy?"
    c "Why do you not put them down?"
    f "They are heavy…"
    c "Put them down!"
    show fiupoz6 onlayer elotte:
        ypos 0.07
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4 onlayer elotte:
        ypos 0.07
        alpha 0.0
        linear 1.0 alpha 1.0
    f "You have right. I am brainless for sure. Where can I put them?"
    c "Lie them next to the couch. I will put the dumbbells on the right place later."
    $ sujzonalad = 2
    show sujzoklizalan:
        xpos -0.4
        ypos 0.1
    show fiupoz4 onlayer elotte:
        ypos 0.07
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2 onlayer elotte:
        ypos 0.07
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Ok. I am done... I have to g…"
    c "Wait a minute!"
    show fiupoz2 onlayer elotte:
        ypos 0.07
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        ypos 0.07
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Why?"
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen invertori2
    show cilicsokolfred onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    u ""
    show cilikozelibeszedcilinapaliban2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    c "Why did you step back?"
    f "I told you before! You can not buy me!"
    show cilikozelibeszedcilinapaliban1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    c "I thought you would react like that so I have prepared."
    f "Did you prepare for the rejection?"
    c "We could say, yes. How about I tell this to Liza?"
    f "Why would it disturb me?"
    c "Silly me... Let me think. How about I tell this to a person called…. Debra?"
    show cilitelotmutat onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    c "How would she react to this video?"
    f "What do you know about Debra? How?"
    c "I have the perfect liaison to know things… You might get in trouble if I showed this to her? Or not?"
    f "What do you want for that video?"
    show cilikozelibeszedcilinapaliban3 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    c "You could do me a small favor..."
    f "What kind of favor?"
    c "You should deliver these drug bags to my customers, that is all…"
    f "What the fuck? Are you kidding me? I will call the Cops!"
    queue sound "audio/cseng.ogg"
    show screen s3
    u ""
    b "The police you mean? Interesting! Oh sorry! I have to answer this call…"
    show cilijelenetmoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    play sound "audio/elvesz2.wav"
    show cilijelenetmoz12 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    c "Hello?"
    i "Boss! He doesn't want to talk."
    c "Try to convince him."
    hide cilijelenetmoz2 onlayer elotte
    show cilijelenetmoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    i "Try to convince him."
    show cilijelenetanimlimbal onlayer elotte
    show screen s3
    u ""
    hide cilijelenetmoz12 onlayer elotte
    show cilijelenetmoz12 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    c "Did he tell you about the business?"
    i "He is stubborn like a mule."
    c "In this case, teach the bird to fly!"
    i "Understood."
    hide cilijelenetmoz2 onlayer elotte
    show cilijelenetmoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    i "Teach the bird to fly!"
    show cilijelenetanimdob onlayer elotte
    show screen s1
    u ""
    play sound "audio/zuhan.wav"
    show screen s4
    u ""
    show cilijelenetmoz13 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    i "The bird broke his wings… Hehhhe… still alive...."
    c "No problem. We will find another bird to sing for us..."
    c "You should bring Mariner to me, if he did not pay the money he owes me."
    i "Ok, Boss!"
    hide cilijelenetmoz11 onlayer elotte
    show cilijelenetmoz11 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    play sound "audio/elvesz2.wav"
    c "Where did we stop?"
    c "Oh yes! The police... Let us go inside the living room!"
    f "…Ok…"
    hide cilikozelibeszedcilinapaliban1 onlayer elotte
    show cilikozelibeszedcilinapaliban1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    c "So here are the five bags. Will you accept this mission, Birdy?"
    f "…GULP…Yes…"
    c "You seem to get cleverer…"
    c "Will you call the cops? My little canary?"
    f "Of course not. I changed my mind."
    c "You earned my sympathy. Let Us discuss the details."
    hide cilikozelibeszedcilinapaliban2 onlayer elotte
    show cilikozelibeszedcilinapaliban2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    c "You have to deliver the packages. You will not receive any money. You should deliver the drug bags to:"
    c "Buzzy, Bobo, Zoli, Sabrina and Alfonz. You have to deliver the packages today."
    f "Can you give me the addresses please?"
    hide cilikozelibeszedcilinapaliban1 onlayer elotte
    show cilikozelibeszedcilinapaliban1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    c "Addresses? Why would I? Let us make this business a bit interesting! "
    c "These people are in the city at the moment. This information should be enough for you. You have to deliver the packages today or you will learn to fly tomorrow the way the guy did before..."
    c "Now go! Call me if you are finished. My phone number is: + 36….."
    f "Alright."
    $ kokonalad = 5
    $ holvanliza = "dolgozik"
    $ setalodagatnoholvan = "parkban"
    $ izomcavoholvan = "lizahazaelot"
    $ boboholvan = "nyomortanya"
    $ ismeretlencokaholvan = "cukrazda"
    $ zoliholvan = "othon"
    hide cilijelenetmoz13 onlayer elotte
    hide cilijelenetmoz1 onlayer elotte
    hide cilijelenetmoz2 onlayer elotte
    hide cilijelenetmoz3 onlayer elotte
    hide cilijelenetmoz10 onlayer elotte
    hide cilijelenetmoz11 onlayer elotte
    hide cilijelenetmoz12 onlayer elotte
    hide cilijelenetanimlimbal onlayer elotte
    hide cilijelenetanimdob onlayer elotte
    hide cilitelotmutat onlayer elotte
    hide cilicsokolfred onlayer elotte
    hide cilinappaliakozeli onlayer elotte
    hide cilipoz1 onlayer elotte
    hide fiupoz1 onlayer elotte
    hide cilikozelibeszedcilinapaliban2 onlayer elotte
    hide cilikozelibeszedcilinapaliban3 onlayer elotte
    hide cili
    show ciliulnapaliban
    show cilikozelibeszedcilinapaliban1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    jump engedejek
$ renpy. pause(hard=True)
label cililakaskanapen:
    hide screen ciliszoba
    f "Could you tell me the names of the people I should give the bags to?"
    c "Of course! Buzzy, Bobo, Zoli, Sabrina and Alfonz."
    f "Thank you!"
    c "It was a pleasure my little turtledove... Do not forget, the time passes by… Tick–Tack! Tick-Tack!"
    show screen ciliszoba
$ renpy. pause(hard=True)
label cililakassujzo:
    hide screen ciliszoba
    f "Dumbbells. They are heavy. I better not move them."
    show screen ciliszoba
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
