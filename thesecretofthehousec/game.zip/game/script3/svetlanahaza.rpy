label svetlanahaza:
    $ holvagyok = "svetlanahaza"
    jump tiltasok
$ renpy. pause(hard=True)
label svetlanahazaszov:
    $ invertorialapjelenyenmeg = True
    show svetlanaeloter
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori
    show screen invertoriszov
    hide fekete onlayer screens
    show fekete onlayer screens
    if nyomortanyadoboz1nalad == 1:
        $ nyomortanyadoboz1nalad = 2
        if oroszkonyvnalad == 1:
            if mubajuszkell == 2:
                if nyomortanyadoboz1nalad == 2:
                    $ hazamehetc = True
    if nyomortanyadoboz1nalad == 2:
        show svetlanaeloterdoboz1
    if nyomortanyadoboz3nalad == 1:
        $ nyomortanyadoboz3nalad = 2
    if nyomortanyadoboz3nalad == 2:
        show svetlanaeloterdoboz3
    if nyomortanyadoboz2nalad == 1:
        $ nyomortanyadoboz2nalad = 2
    if nyomortanyadoboz2nalad == 2:
        show svetlanaeloterdoboz2
    if almaktalban == 1:
        show almaktalban
    if borisznaploja == 1:
        show borisznaploja
    if fogasallo == 1:
        show fogasallo
    if fogasallorajtaruha == 1:
        show fogasallorajtaruha
    if szakadtmedve == 1:
        show szakadtmedve
    if szakadtmedvekulcsa == 1:
        show szakadtmedvekulcsa
    if boriszfotokeretben == 1:
        show boriszfotokeretben



    if editholvan == "svetlanahaza":
        show svetlanaelotermama
    if svetlanaholvan == "svetlanaatjarojaban":
        show svetlana1080:
            zoom 0.8
            xpos 0.05
            ypos 0.22
    if svetlanajelnet11nap == 1:
        jump svetlanajelnet11nap
    if svetlanaholvan == "szetlanaakanapen":
        show svetlanakerestavolimoz1
        show svetlanakerestavoliszemanim

    jump engedejek

$ renpy. pause(hard=True)
label szetlanajoboldaliajtaja:
    hide screen svetlanahaza
    f "I can not go there."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label szetlanabaloldaliajtaja:
    hide screen svetlanahaza
    f "I can not go there."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label szetlanaszekreny:
    hide screen svetlanahaza
    f "Cabinet."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label szetlanakanape:
    hide screen svetlanahaza
    f "Couch."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label szetlanakep:
    hide screen svetlanahaza
    f "Modern image."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label svetlanavalbeszelni11napatjarojaban:
    hide screen svetlanahaza
    show svetlanaeloterkozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show svetlanapoz1 onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    if hanyadiknapvan == 12:
        if svetlanajelenet12nap == 1:
            f "Hy! What is up?"
            s "Why did you come?"
            f "I just walked around and I have time until 21:00 Pm… I thought I will visit you and ask you… How are you?"
            s "I am fine, and you?"
            f "I am fine… Are you angry because of yesterday?"
            show svetlanapoz1 onlayer elotte:
                xzoom -1.0
                alpha 1.0
                linear 1.0 alpha 0.0
            show svetlanapoz2 onlayer elotte:
                xzoom -1.0
                alpha 0.0
                linear 1.0 alpha 1.0
            s "Not really. It was my fault. I lost my mind for a bit… Please forget it!"
            s "Oh now I remember!"
            show fiupoz1 onlayer elotte:
                xzoom -1.0
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz7 onlayer elotte:
                xzoom -1.0
                alpha 0.0
                linear 1.0 alpha 1.0
            f "What are you remembering? I remember some interesting stuff from yesterday."
            s "How about you do me a favor?"
            f "Anything you wish!"
            hide invertori onlayer elotte6
            hide screen invertori
            show svetlanapozol1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            s "I don't really know… How should I ask you? Here is the couch… and…"
            f "Oh yes! Continue!"
            s "I could just sit on the couch and…"
            f "Yeah! Tell me! What should I do?"
            s "Could you please pack out the last big box? Only one is left but I got so tired…"
            hide fiupoz7 onlayer elotte
            hide fiupoz4 onlayer elotte
            show fiupoz4 onlayer elotte:
                xzoom -1.0
            hide svetlanapoz1 onlayer elotte
            show svetlanapoz1 onlayer elotte:
                xzoom -1.0
            hide svetlanapoz2 onlayer elotte
            hide svetlanapozol1 onlayer elotte
            show svetlanapozol1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            f "You killed the romantic... But fine! I will do it for you!"
            show svetlana1080:
                zoom 0.8
                xpos 0.05
                ypos 0.22
            show svetlanaeloterkozeli onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz4 onlayer elotte:
                xzoom -1.0
                alpha 1.0
                linear 1.0 alpha 0.0
            show svetlanapoz1 onlayer elotte:
                xzoom -1.0
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            show svetlana1080:
                zoom 0.8
                xpos 0.05
                ypos 0.22
                alpha 1.0
                linear 1.0 alpha 0.0
            show svetlanakerestavolianim:
                alpha 0.0
                linear 1.0 alpha 1.0
            show svetlanakerestavoliszemanim:
                alpha 0.0
                linear 1.0 alpha 1.0
            $ nap12estelegyen += 1
            $ svetlanaholvan = "sehol"
            $ almaktalban = 1
            $ borisznaploja = 1
            $ fogasallo = 1
            $ fogasallorajtaruha = 1
            $ szakadtmedve = 1
            $ szakadtmedvekulcsa = 1
            $ boriszfotokeretben = 1
            show screen s1
            u ""
            show felsurolfiu2:
                zoom 0.5
                xpos 0.32
                ypos 0.59
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show screen svetlananalkipakol
            show screen s1
            u ""
            show almaktalban:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show borisznaploja:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show fogasallo:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show fogasallorajtaruha:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show szakadtmedve:
                alpha 0.0
                linear 1.0 alpha 1.0
            show szakadtmedvekulcsa:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show screen s3
            f "A picture frame. The photo of Boris should belong here. I will put the photo back there."
            $ boriszfenykepenalad = 2
            show boriszfotokeretben:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show felsurolfiu2:
                zoom 0.5
                xpos 0.32
                ypos 0.59
                alpha 1.0
                linear 1.0 alpha 0.0
            s "It should be here. Where did I lose it?"
            show svetlanakereskozelianim onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show svetlanakereskozeliszemanim onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show svetlanakereskozeliszaj1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide svetlanakereskozeliszaj1 onlayer elotte
            show svetlanakereskozeliszajanim onlayer elotte
            s "Will I find it or not?"
            show svetlanakereskozeliszaj1 onlayer elotte
            hide svetlanakereskozeliszajanim onlayer elotte
            show screen s3
            u ""
            hide svetlanakereskozeliszaj1 onlayer elotte
            show svetlanakereskozeliszajanim onlayer elotte
            s "Oh! Got it!"
            show svetlanakereskozeliszaj1 onlayer elotte
            hide svetlanakereskozeliszajanim onlayer elotte
            hide svetlanaeloterkozeli onlayer elotte
            hide fiupoz1 onlayer elotte
            hide svetlanapoz1 onlayer elotte
            show svetlanaeloterkozeli onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show svetlanapoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""

            f "I packed out the box. I put the photo of Boris back in the picture frame."
            s "Thank you! Where is the old dress?"
            f "I left it in my room at home. Should I bring it back to you?"
            s "No need for that. You have to dress like Boris in the future to lead Edit unfortunately."
            show svetlanapoz1s2 onlayer elotte
            s "But you will not trick me next time..."
            f "I did not want to trick you yesterday."
            hide svetlanapoz1s2 onlayer elotte
            f "Should I throw the box in the trash?"
            s "No need for that. I can use it later. Here you are! I bought you a Phonecard. You can top up your balance."
            f "Thank you! Call me if you need anything!"
            s "I will. Now go! I have to rest a bit."
            f "Bye!"
            hide svetlanakerestavolimoz1
            hide svetlanakerestavoliszemanim
            $ feltoltokartyanalad = 1
            hide svetlanakereskozelianim onlayer elotte
            hide svetlanakereskozeliszemanim onlayer elotte
            hide svetlanakereskozeliszaj1 onlayer elotte
            hide svetlanakereskozelimoz1 onlayer elotte
            hide svetlanakerestavolianim
            hide svetlanakerestavoliszemanim
            $ svetlanajelenet12nap = 2
            show svetlanaeloterkozeli onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show svetlanapoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            if nap12estelegyen == 5:
                $ ancikaholvan = "sehol"
                $ eszterholvan = "sehol"
                $ mamaholvan = "mamakanapenanapaliban"
                $ tiltjaatereketsetlanahaza = True
                $ tiltjaatereketnyomortanya = True
                $ tiltjaatereketlakotomb = True
                $ tiltjaatereketcukrazda = True
                $ tiltjaatereketszomszedok = True
                $ esteighatralevoido = 0
                $ tiltjaatereketegyetem = True
                $ tiltjaatereketpark = True
                $ tiltjaatereketsritbar = False
                $ boltbanemmehetek = True
                $ tiltjaadebrakertjet = True
            show invertori onlayer elotte6:
                yalign 0.0
            show screen invertori
            show screen svetlanahaza
            $ renpy. pause(hard=True)



    if svetlanajelnet11nap == 0:
        f "How should I bring your mother-in- law here?"
        s "I do not know. I have been begging her since yesterday..."
        f "I looked at the photo of Boris. We are a bit similar."
        s "You are not similar at all. Maybe if you would let your beard and mustache grow and put on a big old coat..."
        s "If someone has bad eyes, that person could get confused.."
        f "Are the eyes of Edit bad?"
        s "Yes, her eyes are not the best. She wears glasses but still, she is almost blind..."
        s "I got it! Dress like Boris and talk a bit in russian! Maybe you can confuse Mom a bit and she will follow you..."
        s "She is crazy a bit so this plan could work. You should act like Boris a bit."
        f "Ok, Super! I will dress like Boris but let us wash this dirty old dress first."
        s "I have no washing machine yet. You should solve this problem."
        f "Ok, I will wash it, but where should I get a mustache?"
        s "I do not know! I do not care! Now go!"
        s "Bring me the boxes first. Put them down here. I will pack the boxes out."
        f "Ok, I will."
        $ oroszkonyvetfelveheted = True
        if mubajuszkell == 0:
            $ mubajuszkell = 1
            $ lidiaholvan = "kintall"
    if svetlanajelnet11nap == 2:
        s "Leave me alone."
    show svetlanaeloterkozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show svetlanapoz1 onlayer elotte:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen svetlanahaza
$ renpy. pause(hard=True)
label svetlanajelnet11nap:
    $ fekete = True
    $ svetlanajelnet11nap = 2
    $ editholvan = "sehol"
    show svetlanaelotermama
    hide svetlana1080
    show svetlana1080:
        zoom 0.8
        xpos 0.05
        ypos 0.22
    show svetlana1080szem2:
        zoom 0.8
        xpos 0.05
        ypos 0.22
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    s "Did you come all alone?"
    ed "Nope! My son came and brought me here finally..."
    s "Where is your son?"
    ed "He is drinking outside. He got really thirsty on the long way here..."
    ed "He told me, we will live here from now on. Come Dear! Show me my room! I need some rest."
    sg "What happened to Mom? Did He give her some kind of drugs? I will kill him!"
    s "Your room is on the left. Go and have some rest! I will look after Fre… I mean Borsi…."
    ed "Alright! I will go now..."
    show svetlanaelotermama:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    sg "Just enter this house and I will kill you! You Bastard! What did you do with Mom?"
    play music "audio/baszosalap.ogg"
    show screen s05
    u ""
    show svetlana11napjelenet0 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "HOT! This dress is soooo hot! I will get cooked in it!"
    f "Where is Edit? Do not tell me she turned back again! Should I go and search for her?"
    s "She went to her room …Boris…"
    f "The heat must cause some problems in my brain. Did Svetlana call me Boris?"
    show svetlana11napjelenet1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    s "Are you that, Boris? They told me you died a long time ago…"
    f "Svetlana! Do you not remember me? Hello?"
    s "It was only a bad nightmare! Wasn’t it? You came back…"
    f "It is me… "
    show svetlana11napjelenet2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "WOW! What should I do now? What is she doing? Why is she kissing me? No wonder I could trick Edit. Svetlana believes I am Boris as well. Do I look so similar to that man?"
    show svetlana11napjelenet3alap onlayer elotte
    show svetlana11napjelenet3nyelvanim onlayer elotte
    show svetlana11napjelenet3fedo onlayer elotte
    hide svetlana11napjelenet2 onlayer elotte
    show svetlana11napjelenet2 onlayer elotte
    fg "I can not push her away. She would have a nervous breakdown..."
    show svetlana11napjelenet2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    fg "I never thought I would look so much like Bors… But this mustache and dress... It is easy to look like a Russian man..."
    show screen s2
    u ""
    fg "What is she doing? Her hand is in my pants… She took off my penis!"
    show screen s2
    u ""
    fg "She wants it! She lifted her leg and wrapped it around my waist…"
    show svetlana11napjelenet4moz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    s "Do not let me wait anymore! We had sex so long ago… You want it. I can feel it."
    hide svetlana11napjelenet3alap onlayer elotte
    hide svetlana11napjelenet3nyelvanim onlayer elotte
    hide svetlana11napjelenet3fedo onlayer elotte
    hide svetlana11napjelenet0 onlayer elotte
    hide svetlana11napjelenet1 onlayer elotte
    hide svetlana11napjelenet2 onlayer elotte
    show svetlana11napjelenet4anim1 onlayer elotte
    show screen s6
    u ""
    show svetlana11napjelenet4anim2 onlayer elotte
    show screen s6
    u ""
    show screen basziksvetlana11nap
    $ renpy. pause(hard=True)
label basziksvetlana11napgyenge:
    if basziksvetlana11napgyenge == 0:
        if basziksvetlana11napsebeseg == "eros":
            hide svetlana11napjelenet4anim2 onlayer elotte
            show svetlana11napjelenet4anim2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            jump basziksvetlana11napugrik1
        show svetlana11napjelenet5anim onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
    if basziksvetlana11napgyenge == 1:
        if basziksvetlana11napsebeseg == "gyenge":
            if basziksvetlana11naphogyan == "alulrol":
                jump basziksvetlana11napugrik1
            hide svetlana11napjelenet4anim2 onlayer elotte
            show svetlana11napjelenet4anim2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
        if basziksvetlana11napsebeseg == "eros":
            if basziksvetlana11naphogyan == "alulrol":
                hide svetlana11napjelenet4anim4 onlayer elotte
                show svetlana11napjelenet4anim4 onlayer elotte
                jump basziksvetlana11napugrik1
            hide svetlana11napjelenet4anim4 onlayer elotte
            show svetlana11napjelenet4anim4 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
label basziksvetlana11napugrik1:
    if basziksvetlana11napgyenge == 1:
        show screen s3
        u ""
        hide svetlana11napjelenet5anim onlayer elotte
        show svetlana11napjelenet5anim onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
    show screen s4
    u ""
    if basziksvetlana11napgyenge == 0:
        sg2 "I am so glad! You came back!How I missed your touch…"
    show screen s2
    u ""
    if basziksvetlana11napgyenge == 0:
        fg "She moves so fine! Her ass is just perfect!"
    show screen s2
    u ""
    if basziksvetlana11napgyenge == 0:
        fg "I hope she won't kill me if she „wakes up”!!!"
    show screen s2
    u ""
    $ basziksvetlana11napgyenge = 1
    $ basziksvetlana11napbaszasvege = True
    $ basziksvetlana11naphogyan = "gyengen"
    $ basziksvetlana11napsebeseg = "gyenge"
    show screen basziksvetlana11nap
    $ renpy. pause(hard=True)
label basziksvetlana11naperos:
    if basziksvetlana11naperos == 0:
        hide svetlana11napjelenet4anim3 onlayer elotte
        show svetlana11napjelenet4anim3 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s3
        u ""
        show svetlana11napjelenet6anim1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
    if basziksvetlana11naperos == 1:
        if basziksvetlana11napsebeseg == "gyenge":
            if basziksvetlana11naphogyan == "alulrol":
                hide svetlana11napjelenet4anim3 onlayer elotte
                show svetlana11napjelenet4anim3 onlayer elotte
                show screen s3
                u ""
                jump basziksvetlana11napugrik2
            hide svetlana11napjelenet4anim3 onlayer elotte
            show svetlana11napjelenet4anim3 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
        if basziksvetlana11napsebeseg == "eros":
            if basziksvetlana11naphogyan == "alulrol":
                jump basziksvetlana11napugrik2
            hide svetlana11napjelenet4anim5 onlayer elotte
            show svetlana11napjelenet4anim5 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
        show screen s3
        u ""
label basziksvetlana11napugrik2:
    if basziksvetlana11naperos == 1:
        hide svetlana11napjelenet6anim1 onlayer elotte
        show svetlana11napjelenet6anim1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
    show screen s4
    u ""
    if basziksvetlana11naperos == 0:
        s "Oh! Fine! Do it!"
    show screen s2
    u ""
    if basziksvetlana11naperos == 0:
        f "This feels so good!"
    show screen s2
    u ""
    if basziksvetlana11naperos == 0:
        fg "This is so cool! I am sweating like a bear, but who cares about it anymore!?"
    show screen s2
    u ""
    $ basziksvetlana11naphogyan = "erosen"
    $ basziksvetlana11napsebeseg = "eros"
    $ basziksvetlana11napbaszasvege = True
    $ basziksvetlana11naperos = 1
    show screen basziksvetlana11nap
    $ renpy. pause(hard=True)
label basziksvetlana11napmasigszog:
    hide svetlana11napjelenet4anim5 onlayer elotte
    show svetlana11napjelenet4anim5 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    hide svetlana11napjelenet6v3anim1 onlayer elotte
    show svetlana11napjelenet6v3anim1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s6
    u ""
    $ basziksvetlana11naphogyan = "masiksog2"
    show screen basziksvetlana11nap
$ renpy. pause(hard=True)
label basziksvetlana11napalulrol:
    if basziksvetlana11napsebeseg == "gyenge":
        hide svetlana11napjelenet4anim2 onlayer elotte
        show svetlana11napjelenet4anim2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
    if basziksvetlana11napsebeseg == "eros":
        hide svetlana11napjelenet4anim5 onlayer elotte
        show svetlana11napjelenet4anim5 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0

    show screen s6
    u ""
    $ basziksvetlana11naphogyan = "alulrol"
    show screen basziksvetlana11nap
$ renpy. pause(hard=True)
label basziksvetlana11napvege:
    hide svetlana11napjelenet6v2anim1 onlayer elotte
    show svetlana11napjelenet6v2anim1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    sg2 "Why do I have this strange feeling? Is he really my Boris?"
    show screen s2
    u ""
    sg2 "I want you, I Missed you so much, but I still feel worried for some reason still…"
    show screen s2
    u ""
    sg2 "Is it him or not? Why do I want to stop this?"
    hide svetlana11napjelenet10 onlayer elotte
    show svetlana11napjelenet10 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    sg2 "It was a nightmare only. You are alive..."
    show svetlana11napjelenet7 onlayer elotte
    show svetlana11napjelenet7szaj1 onlayer elotte
    show svetlana11napjelenet7szemanim onlayer elotte
    hide svetlana11napjelenet10 onlayer elotte
    show svetlana11napjelenet10 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    hide svetlana11napjelenet7szaj1 onlayer elotte
    show svetlana11napjelenet7szajanim onlayer elotte
    s "Did everyone lie? The funeral? The family... the loss…."
    s "Are you that, Boris?"
    show svetlana11napjelenet7szaj1 onlayer elotte
    hide svetlana11napjelenet7szajanim onlayer elotte
    show svetlana11napjelenet8 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""

    play music "audio/svetlanahazaalap.ogg" fadeout 1
    s "No! You are not my Boris! He died! I wish you would be my beloved one!"
    f "I am sorry! I could not tell you… everything happened so fast and …I…"
    s "What did I do? I made his memory dirty!"
    f "No! This is not your fault! You suffered so much and you got crazy for a moment..."
    f "You should calm down! I stay here until you feel better. Please! Do not cry!"
    show svetlana11napjelenet9 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    s "Thank you! I feel much better! You really look a bit like him and I…"
    f "Are you ok? Are you sure?"
    s "Sure! Just help me stand up please. I feel fine now..."
    f "Ok, Take my hand!"
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0

    show screen s1
    u ""
    hide svetlana11napjelenet4moz1 onlayer elotte
    hide svetlana11napjelenet7szaj1 onlayer elotte
    hide svetlana11napjelenet3nyelvanim onlayer elotte
    hide svetlana11napjelenet4anim1 onlayer elotte
    hide svetlana11napjelenet4anim2 onlayer elotte
    hide svetlana11napjelenet4anim3 onlayer elotte
    hide svetlana11napjelenet4anim4 onlayer elotte
    hide svetlana11napjelenet5anim onlayer elotte
    hide svetlana11napjelenet6anim1 onlayer elotte
    hide svetlana11napjelenet6v2anim1 onlayer elotte
    hide svetlana11napjelenet6v3anim1 onlayer elotte
    hide svetlana11napjelenet7szajanim onlayer elotte
    hide svetlana11napjelenet7szemanim onlayer elotte
    hide svetlana11napjelenet0 onlayer elotte
    hide svetlana11napjelenet1 onlayer elotte
    hide svetlana11napjelenet2 onlayer elotte
    hide svetlana11napjelenet3alap onlayer elotte
    hide svetlana11napjelenet3fedo onlayer elotte
    hide svetlana11napjelenet7 onlayer elotte
    hide svetlana11napjelenet8 onlayer elotte
    hide svetlana11napjelenet9 onlayer elotte
    hide svetlana11napjelenet4anim5 onlayer elotte

    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""







    $ debraholcsinal = "napalibanallva"
    $ csacsimotyo = 1
    jump engedejek
$ renpy. pause(hard=True)
label svetlanavalbeszelni11napatjarojabanulve:
    hide screen svetlanahaza
    f "She is resting."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label mualmaksvetlana:
    hide screen svetlanahaza
    f "Plastic apple."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label naploborisz:
    hide screen svetlanahaza
    f "A diary. It is closed."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label kogassvetlana:
    hide screen svetlanahaza
    f "A hanger and a jacket."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label szakatmedvesvetlana:
    hide screen svetlanahaza
    f "A poor old bear."
    show screen svetlanahaza
$ renpy. pause(hard=True)
label boriszkepkerete:
    hide screen svetlanahaza
    f "A photo of Boris."
    show screen svetlanahaza
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
