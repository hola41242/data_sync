screen terkep:
    if hanyadiknapvan == 3:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.35
            yalign 0.05
            if teremjelenetek == 0:
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("tanterem")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.75
            yalign 0.2
            if resz3hazamegy == True:
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("fojasojobb")
        if harmadikreszkonyha >= 5:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.15
                yalign 0.85
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("bolttok")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.42
                yalign 0.72
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("leegethaz")
            if baloldaliszomszed == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.32
                    yalign 0.59
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("baloldaliszomszed")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.52
                yalign 0.82
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("jobboldaliszomszed")
    if hanyadiknapvan == 4:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.35
            yalign 0.05
            if teremjelenetek == 0:
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("tanterem")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.75
            yalign 0.2
            mouse "aktion"
            if regell4resz == True:
                activate_sound "audio/click.wav"
                action Jump ("fojasojobb")
            if jobboldaliszomszed == 1:
                activate_sound "audio/click.wav"
                action Jump ("fojasojobb")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.15
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("bolttok")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.42
            yalign 0.72
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("leegethaz")
        if baloldaliszomszed == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.32
                yalign 0.59
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("baloldaliszomszed")
        if jobboldaliszomszed == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.52
                yalign 0.82
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("jobboldaliszomszed")
    if hanyadiknapvan == 5:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.75
            yalign 0.2
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("fojasojobb")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.15
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("bolttok")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.35
            yalign 0.05
            if teremjelenetek == 0:
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("tanterem")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.32
            yalign 0.59
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("baloldaliszomszed")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.52
            yalign 0.82
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("jobboldaliszomszed")
        if lizagyurulye >= 4:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.025
                yalign 0.15
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("stripbar")
    if hanyadiknapvan == 6:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.75
            yalign 0.2
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("fojasojobb")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.15
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("bolttok")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.32
            yalign 0.59
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("baloldaliszomszed")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.52
            yalign 0.82
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("jobboldaliszomszed")
    if hanyadiknapvan >= 7:
        if kittyparkotenged == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.85
                yalign 0.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketpark == False:
                    action Jump ("park")
                if tiltjaatereketpark == True:
                    action Jump ("nemengedodaaterkepen")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.95
                yalign 0.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketpark == False:
                    action Jump ("park")
                if tiltjaatereketpark == True:
                    action Jump ("nemengedodaaterkepen")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.025
            yalign 0.15
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaatereketsritbar == False:
                action Jump ("stripbar")
            if tiltjaatereketsritbar == True:
                action Jump ("nemengedodaaterkepen")
    if hanyadiknapvan == 7:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.35
            yalign 0.05
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("tanterem")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.75
            yalign 0.2
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("fojasojobb")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.15
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("bolttok")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.32
            yalign 0.59
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("baloldaliszomszed")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.52
            yalign 0.82
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("jobboldaliszomszed")
    if hanyadiknapvan >= 8:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.35
            yalign 0.05
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaatereketegyetem == False:
                action Jump ("tanterem")
            if tiltjaatereketegyetem == True:
                action Jump ("nemengedodaaterkepen")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.75
            yalign 0.2
            mouse "aktion"
            activate_sound "audio/click.wav"
            if hazamehetc == True:
                action Jump ("fojasojobb")
            if hazamehetc == False:
                action Jump ("nemengedodaaterkepen2")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.15
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaatereketbolt == False:
                action Jump ("bolttok")
            if tiltjaatereketbolt == True:
                action Jump ("nemengedodaaterkepen")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.32
            yalign 0.59
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaatereketszomszedok == False:
                action Jump ("baloldaliszomszed")
            if tiltjaatereketszomszedok == True:
                action Jump ("nemengedodaaterkepen")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.52
            yalign 0.82
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaatereketszomszedok == False:
                action Jump ("jobboldaliszomszed")
            if tiltjaatereketszomszedok == True:
                action Jump ("nemengedodaaterkepen")
    if hanyadiknapvan >= 9:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 1.0
            yalign 1.0
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaaterekettemeto == False:
                action Jump ("temetokapu")
            if tiltjaaterekettemeto == True:
                action Jump ("nemengedodaaterkepen")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.9
            yalign 1.0
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaaterekettemeto == False:
                action Jump ("temetokapu")
            if tiltjaaterekettemeto == True:
                action Jump ("nemengedodaaterkepen")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.8
            yalign 1.0
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaaterekettemeto == False:
                action Jump ("temetokapu")
            if tiltjaaterekettemeto == True:
                action Jump ("nemengedodaaterkepen")
    if hanyadiknapvan >= 10:
        if cukrazdalathato == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.58
                ypos 0.83
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketcukrazda == False:
                    action Jump ("cukrazda")
                if tiltjaatereketcukrazda == True:
                    action Jump ("nemengedodaaterkepen")
    if hanyadiknapvan >= 11:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.05
            ypos 0.3
            mouse "aktion"
            activate_sound "audio/click.wav"
            if tiltjaatereketnyomortanya == False:
                action Jump ("nyomortanya")
            if tiltjaatereketnyomortanya == True:
                action Jump ("nemengedodaaterkepen")
        if svetlanahaza == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.85
                ypos 0.63
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketsetlanahaza == False:
                    action Jump ("svetlanahaza")
                if tiltjaatereketsetlanahaza == True:
                    action Jump ("nemengedodaaterkepen")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.83
                ypos 0.58
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketsetlanahaza == False:
                    action Jump ("svetlanahaza")
                if tiltjaatereketsetlanahaza == True:
                    action Jump ("nemengedodaaterkepen")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.84
                ypos 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketsetlanahaza == False:
                    action Jump ("svetlanahaza")
                if tiltjaatereketsetlanahaza == True:
                    action Jump ("nemengedodaaterkepen")
    if hanyadiknapvan >= 12:
        if lakotombaterkepen == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 1.0
                ypos 0.4
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketlakotomb == False:
                    action Jump ("lakotomb1emelet")
                if tiltjaatereketlakotomb == True:
                    action Jump ("nemengedodaaterkepen")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 1.0
                ypos 0.27
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketlakotomb == False:
                    action Jump ("lakotomb1emelet")
                if tiltjaatereketlakotomb == True:
                    action Jump ("nemengedodaaterkepen")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 1.0
                ypos 0.15
                mouse "aktion"
                activate_sound "audio/click.wav"
                if tiltjaatereketlakotomb == False:
                    action Jump ("lakotomb1emelet")
                if tiltjaatereketlakotomb == True:
                    action Jump ("nemengedodaaterkepen")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
