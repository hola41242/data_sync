screen furdo:
    imagebutton:
        idle "ajtok/furdoajtoz1z.png"
        xalign 0.00
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("nappali")
    imagebutton:
        idle "ajtok/furdoszekrenyz.png"
        xalign 0.29
        ypos 0.565
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("furdoszekreny")
    imagebutton:
        idle "ajtok/debpor2z.png"
        xalign 0.9
        ypos 0.8
        mouse "aktion"
        activate_sound "audio/click.wav"
        if mosopor == False:
            action Jump ("mosogepszov")
        if mosopor == True:
            action Jump ("mosolvalami")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.67
        ypos 0.38
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debratorolkozofurdo")
    if mosnivalodvan == False:
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.9
            ypos 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("mosogepszov")
    if hanyadiknapvan == 1:
        if agynemukaptal == False:
            imagebutton:
                idle "ajtok/debpor2z.png"
                xalign 0.9
                ypos 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mosogepszov")
        if agynemukaptal == True:
            imagebutton:
                idle "ajtok/debpor2z.png"
                xalign 0.9
                ypos 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mosodazagynemut")
        if locsolokannafel == False:
            if viragokmegontozese == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.33
                    ypos 0.82
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("locsolokannafel")
        if viragokmegontozese == True:
            if locsolokannafel == True:
                timer 0.001 repeat True action SetVariable('locsolokannafel', False)
        if viragokmegontozese == False:
            if locsolokannafel == True:
                if furdovirag == False:
                    imagebutton:
                        idle "ajtok/ruhaz.png"
                        xalign 0.33
                        ypos 0.4
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("locsolfurdo")
    if hanyadiknapvan == 2:
        if torloszivacsnalad == False:
            imagebutton:
                idle "ajtok/furdoszekrenyz.png"
                xalign 0.29
                ypos 0.565
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("furdoszekreny2")
        if torloszivacsnalad == True:
            imagebutton:
                idle "ajtok/furdoszekrenyz.png"
                xalign 0.29
                ypos 0.565
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("furdoszekreny")
        if mosnivalodvan == True:
            imagebutton:
                idle "ajtok/debpor2z.png"
                xalign 0.9
                ypos 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mosolvalami")
    if hanyadiknapvan == 2:
        if wczett == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.75
                ypos 0.63
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("wczek")
    if hanyadiknapvan == 3:
        if wczett == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.75
                ypos 0.63
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("wczek")
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.9
            ypos 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            if mosopor == False:
                action Jump ("mosogepszov")
            if mosopor == True:
                action Jump ("mosolvalami")
    if hanyadiknapvan == 4:
        if wczett == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.75
                ypos 0.63
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("wczek")
    if hanyadiknapvan >= 5:
        if wczett == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.75
                ypos 0.63
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("wczek")
    if hanyadiknapvan == 5:
        if regell5resz == True:
            if furdobenvagy == 1:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.6
                    ypos 0.2
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debratmegtapizod5resz")
        if torloszivacsnalad == False:
            imagebutton:
                idle "ajtok/furdoszekrenyz.png"
                xalign 0.29
                ypos 0.565
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("furdoszekreny2")
    if hanyadiknapvan == 6:
        if wczett == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.75
                ypos 0.63
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("wczek")
        if debrafulbevalotmegkeresni1 == 1:
            if debrafulbevalo1 == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.34
                    yalign 0.46
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("anyakereszt1fel")
        if debraholcsinal == "furdo2":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/debporz.png"
                    xpos 0.5
                    ypos 0.3
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrafurdobenbudittakarit")
    if hanyadiknapvan == 7:
        if debraholcsinal == "nap7vegjelenetafurdoben":
            imagebutton:
                idle "ajtok/debpor2z.png"
                xalign 0.93
                ypos 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("nap7szexjelenetdebra")



screen leskelodes:
    if hanyadiknapvan == 1:
        frame:
            background ('fram')
            xalign 0.5
            yalign 0.45
            textbutton "Enter bathroom.":
                mouse "aktion"
                action Jump ("wcbenyit")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xalign 0.5
            yalign 0.55
            textbutton "Look through keyhole.":
                mouse "aktion"
                action Jump ("wcbeles")
                text_style "fegeteszov"
    if hanyadiknapvan == 2:
        frame:
            background ('fram')
            xalign 0.5
            yalign 0.45
            textbutton "Leave it.":
                mouse "aktion"
                action Jump ("engedejek")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xalign 0.5
            yalign 0.55
            textbutton "Look through keyhole.":
                mouse "aktion"
                action Jump ("wcbeles2")
                text_style "fegeteszov"
    if hanyadiknapvan == 5:
        if regell5resz == True:
            if furdobenvagy == 1:
                frame:
                    background ('fram')
                    xalign 0.5
                    yalign 0.45
                    textbutton "Touch her.":
                        mouse "aktion"
                        action Hide ('leskelodes'), Jump ("megfogdosoddebrat5resz")
                        text_style "fegeteszov"
                frame:
                    background ('fram')
                    xalign 0.5
                    yalign 0.55
                    textbutton "Talk to Debra.":
                        mouse "aktion"
                        action Hide ('leskelodes'), Jump ("beszelszdebraval5reszfurdo")
                        text_style "fegeteszov"
            if furdobenvagy == 2:
                frame:
                    background ('fram')
                    xalign 0.5
                    yalign 0.45
                    textbutton "Leave it.":
                        mouse "aktion"
                        action Hide ('leskelodes'), Jump ("engedejek")
                        text_style "fegeteszov"
                frame:
                    background ('fram')
                    xalign 0.5
                    yalign 0.55
                    textbutton "Look through keyhole.":
                        mouse "aktion"
                        action Hide ('leskelodes'), Jump ("wcbeles3")
                        text_style "fegeteszov"

screen debrafurdenikezd:
    if torloszivacsnalad == True:
        timer 60.0 repeat True action Hide ('debrafurdenikezd'), SetVariable('debrafurdik', True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
