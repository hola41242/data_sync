init:
    $ config.mouse = { "default": (('images/cursor/cursor_DEFAULT.png', 0, 0), ('images/cursor/cursor_DEFAULT.png', 0, 0)),
                                     "aktion": (('images/cursor/cursor_AKTIV.png', 0, 0), ('images/cursor/cursor_AKTIV.png', 0, 0)), }


init python:
    renpy.music.register_channel("channel1", loop=False)
    renpy.music.register_channel("channel2", loop=False)
    renpy.music.register_channel("channel3", loop=False)

define u = Character("", window_background=None)
define i = Character("Unknown")
define inf = Character("info")
define o = Character("Orvos")

define a = Character("Anika")
define ad = Character("Adriana")
define al = Character("Alfonz")
define am = Character("Amanda")
define an = Character("Anna")
define anc = Character("Ancika")
define b = Character("Baby")
define ba = Character("Andrew")
define br = Character("Bram")
define be = Character("Bertalan")
define bo = Character("Bobo")
define bu = Character("Buzzy")
define c = Character("Cili")
define d = Character("Debra")
define dg = Character("Debra (Debra thinking)",who_color="#3a36e5",what_color="#9f9dff",what_size=30)
define dg2 = Character("Debra (Debra thinking)",who_color="#e6e68d",what_color="#ffffa1",what_size=30)
define dalva = Character("Debra (Debra talks at sleep)",who_color="#e6e68d",what_color="#ffffa1",what_size=30)
define da = Character("Puffy (David)")
define dag = Character("Puffy (David thinking)",who_color="#3a36e5",what_color="#9f9dff",what_size=30)
define e = Character("Ester")
define ed = Character("Edit")
define f = Character("Fred")
define fg = Character("Fred (thinking)",who_color="#3a36e5",what_color="#9f9dff",what_size=30)
define fr = Character("Fodo")
define fu = Character("Courier woman")
define gy = Character("Gyula")
define j = Character("Jim")
define k = Character("Kitty")
define l = Character("Liza")
define lg = Character("Liza (thinking)",who_color="#3a36e5",what_color="#9f9dff",what_size=30)
define li = Character("Lidia")
define mk = Character("Mark")
define m = Character("Grandma(Bertalan's Mother)Diana")
define mg = Character("Grandma (Diana thinking)",who_color="#3a36e5",what_color="#9f9dff",what_size=30)
define mo = Character("Monica")
define mr = Character("Mr. Puli")
define mre = Character("Mr. Edwards")
define m2 = Character("Mong")
define p = Character("Piri")
define r = Character("Rita")
define ro = Character("Rose")
define sab = Character("Sabrina")
define sa = Character("Alexander")
define s = Character("Svetlana")
define sam = Character("Samanta")
define sg = Character("Svetlana (thinking)",who_color="#3a36e5",what_color="#9f9dff",what_size=30)
define sg2 = Character("Svetlana (thinking)",who_color="#e6e68d",what_color="#ffffa1",what_size=30)
define z = Character("Zoli")








style fegeteszov is default:
    xalign 0.5
    text_align 0.5
    color "#000000"
    hover_color "#ff0000"
screen perc10:
    text "{b}{size=+10}10 minutes later.":
        xpos 0.5
        xalign 0.5
        yalign 0.475
        text_align 0.5
screen perc25:
    text "{b}{size=+10}25 minutes later.":
        xpos 0.5
        xalign 0.5
        yalign 0.475
        text_align 0.5


label osszezalha:
    default kezd = False
    default kozepsoaljto = False
    default holvagyok = "napaliban"
    default poszterafalon1 = False
    default poszterafalon2 = False
    default poszterafalon3 = False
    default mitkelltennem = False
    default fekete = False
    default ujsagafoldon = False
    default semeteszsakafoldon = False
    default ujsagafoldonkidobva = False
    default semeteszsakafoldonkidobva = False
    default kukucska = 1
    default olvasdebra = 1
    default menyiharomgyokalat = 1
    default viragokmegontozese = False
    default viragokmegontozve = 0
    default locsolokannafel = False
    default locsolokannaviz = 2

    default szobakipakolas = False
    default korbenezni = False
    default fojasojobb = False
    default furdo = False
    default szoveguresdobozkidobva = False
    default szemetafojason = False
    default hozdbeazujsagot = False
    default szendvicsmilesz = False
    default szendvicsmilesznemetted = False
    default szendvicsinvertoriba = False
    default szendviamamanal = False
    default agynemu = False
    default agynemukaptal = False
    default agynemukosos = False
    default agynemuhejen = False
    default mosopor = False
    default parnanalad = False
    default parnaahejen = False
    default wcremehetek = False
    default furdovirag = False
    default fojasoballvirag = False
    default fojasojobbvirag = False
    default napalivirag = False
    default napalivirag2 = False
    default atjarovirag = False
    default atjarovirag2 = False
    default atjarovirag3 = False

    default atjarokonyvszov = False
    default atjarokonyvszov2 = False
    default atjaroruhavszov = False
    default atjaroruhav2szov = False
    default atjaroboritekszov = False


    default debravalamitcsinalido = 20
    default debraholcsinal = "napaliban"
    default debramitcsinal = "sopor"
    default debratmegnezed = "nemnezed"
    default debranapaliban = False
    default debrafurdoban = False
    default debraballfoban = False
    default debrajobbfoban = False
    default debradolgozo = False
    default debrakonyhaban = False
    default debratmertkeresed = "nemkeresem"



    default fifitfelvetem = False
    default fifitletettem = False
    default fificsinalido = 60
    default fifiholcsinal = "sehol"
    default fifimitcsinal = "semit"
    default fifinapaliban = False
    default fififurdoban = False
    default fifiballfoban = False
    default fifijobbfoban = False
    default fifiatjaroban = False
    default fifikonyhaban = False
    default fifipisilt = 0
    default egyszervegigment = False
    default fifipisi1 = False
    default fifipisi2 = False
    default fifipisi3 = False


    default Tanulnimatematika = 0
    default Tanulnimatematikaido = 60
    default Tanulnimatematikaeltetido = 0
    default Tanulniepiteszet = 0
    default Tanulniepiteszetido = 60
    default Tanulniepiteszeteltetido = 0
    default Tanulnitortenelem = 0
    default Tanulnitortenelemido = 60
    default Tanulnitortenelemeltetido = 0
    default nemtanulhatsztobbet = False


    default dolgozolmosogatas = 0
    default dolgozolmosogatasido = 60
    default dolgozolmosogataselteltido = 0
    default dolgozoltakaritido = 10
    default dolgozoltakaritelteltido = 0
    default dolgozoltakarit2ido = 10
    default dolgozoltakarit2elteltido = 0
    default dolgozoltakarit3ido = 10
    default dolgozoltakarit3elteltido = 0
    default szivacskoszoslett = 0

label osszezalhav1:
    default szoveguresdoboz = False
    default szovegureszsakhoz = False
    default szoveguresujsaghoz = False
    default szovegszedvicshez = False
    default szovegszenyeshez = False
    default szovegtisztahozhez = False
    default szoveglocsolokanahoz = False
    default szovegmosoporhoz = False
    default szovegparna = False
    default szovegfiuszenyeshez = False
    default szovegfiutisztaruha = False
    default szovegszivacshoz = False
    default szovegkososszivacshoz = False
    default szovegtvhoz = False
    default szovegtvtaviranyitohoz = False
    default szovegtelepoharhoz = False
    default szovegurespoharhoz = False
    default szovegboritekomhoz = False
    default szovegfotohoz = False
    default szoveguditohoz = False
    default szovegvizeskancohoz = False
    default szovegureskutyatalhoz = False
    default szovegtelekutyatalhoz = False
    default szovegkavehoz = False
    default szovegtaskahoz = False
    default szovegpenzhoz = False
    default szovegtejhoz = False
    default szovegnyalokahoz = False
    default szovegpornomagazinhoz = False
    default szovegkenyerhez = False
    default szovegkutyataphoz = False
    default szovegkonzevnyitohoz = False
    default szovegbetadinhoz = False
    default szovegzacskohoz = False
    default szovegfelmosohoz = False
    default szoveglampahoz = False
    default szoveglizagyuruhoz = False
    default szovegbutykoshoz = False
    default szovegporszivohozhoz = False
    default szovegszulbevalohoz = False
    default szovegnyaklanchoz = False
    default szoveggerebjefejhoz = False
    default szoveggerebjehoz = False
    default szoveggerebjenyelhoz = False
    default szoveglizaszemeteszsakhoz = False
    default szoveglizamadarhahoz = False
    default szovegcsavarhoz = False
    default szovegcsavarhuzohoz = False
    default szovegtuhuzohoz = False
    default szovegvaszon1huzohoz = False
    default szovegvaszon2huzohoz = False
    default szovegcernahoz = False
    default szovegtorolkozohoz = False
    default szovegmobilhoz = False
    default szovegzalogjegyhoz = False
    default szovegermehoz = False
    default szovegkiskendohoz = False
    default szovegruhakosarhoz = False
    default szovegviragcserephoz = False
    default szovegmetszoollohoz = False
    default szovegmadzaghoz = False
    default szovegoblitohoz = False
    default szovegrecepthoz = False
    default szovegmozsarhoz = False
    default szoveglizaviraghoz = False
    default szovegtulipanhoz = False
    default szoveggyongyviraghoz = False
    default szovegrovarirtohoz = False
    default szovegtojashoz = False
    default szovegelesztohoz = False
    default szovegpokhoz = False
    default szovegtisztitoszerhoz = False
    default szovegtapaszhoz = False
    default szoveggombahoz = False
    default szovegnaracslehoz = False
    default festekoldohoz = False
    default faaghoz = False
    default horoghoz = False
    default gilisztahoz = False
    default salgcsohoz = False
    default leengedohoz = False
    default poharhoz = False
    default kutyatalhoz = False
    default tejhoz = False
    default szedvicshoz = False
    default halhoz = False
    default gyufahoz = False
    default agfureszhoz = False
default szovegmacskahoz = False
default szovegfagyihoz = False
default szovegcottonhoz = False
default szovegladahoz = False
default szovegspaklihoz = False
default szovegkarkotohoz = False
default szovegoroszruhahoz = False
default szovegosvetlanadobozaihoz = False
default szovegooroszszorarhoz = False
default szovegboriszfotohoz = False
default szovegmubajuszhoz = False
default szovegrozsakhoz = False
default szovegragasztohoz = False
default szovegizzohoz = False
default szovegletrahoz = False
default szovegcsacsikalaphoz = False
default szovegsujzohoz = False
default szovegkokohoz = False
default szovegasohoz = False
default szovegkomposzthoz = False
default szoveghagymahoz = False
default szovegmamakenocshoz = False
default szovegviragvaza2hoz = False
default szovegszemethoz = False
default szovegfeltoltohoz = False
default szovegegerhoz = False
default szoveggiroszhoz = False



default kivelbeszelsz = "senki"


label osszezalha2:
    default wczett = 0
    default alvas = 0
    default egyel = False
    default screentiltas = False
    default atjaroszov = 0
    default furdoszov = 0
    default napaliszov = 0
    default fojasoballszov = 0
    default fojasojobbszov = 0
    default konyhaszov = 0
    default atjarosecialisengedej = 0
    default boritekmizeria = 0
    default boritekmizeriamegoldva = False
    default boritekazinvertoriba = False
    default szovegfifi = False
    default mamabeszeldebraval = False
    default masodiknapfeladatokdebratol = False
    default szenyeseltakaritasa = 0
    default mamavalfoglalkoz = 0
    default kutyapisok = 0
    default csinalszvalamit = "semit"
    default debraindul = False
    default szedvicbenvaj = False
    default szedvicbenkecsap = False
    default szedvicbenmajonez = False
    default szedvicbenmustar = False
    default szedvicbensalata = False
    default szedvicbenparizsi = False
    default szedvicbenszalami = False
    default szedvicskesz = False
    default vanszedvicsed = False
    default megetedvanszedvicsed = 0
    default torloszivacsnalad = False
    default szenyesafoldon = True
    default szenyesnalad = False
    default mijenszenyesvannalad = "semilyen"
    default szenyeskimosva = False
    default szenyeskimosvaahejen = False
    default mamakeresei = 0
    default tvhoznakido = 80
    default csengettek = False
    default tvhoztak = False
    default tvnapaliban = False
    default tvtaviranyitonalad = False
    default tvtaviranyitomamanal = False
    default tvprogramido = 120
    default tvprogrameltetido = 0
    default tvprogramkesz = False
    default debrabejopiszkalni = 0
    default tiltokkilepest = False
    default poharnalad = False
    default urespoharnalad = False
    default debrakedvencszedvicse = False
    default debraelveteaszedvicset = 0
    default esteighatralevoido = 800
    default bebramarotvan = False
    default dabraboritekotkaphat = False
    default enneegyszedvicset = 0
    default mamasolit = 0
    default lopotfotokat = False
    default alvasmasodikreszvege = 0
    default mitfozol = 0
    default nemjoszendvics = 0
    default mosnivalodvan = False
    default konyhafelmos = False

label osszezalha3:
    default tvkivankapcsolva = False
    default mamanemkapotkavet = False
    default mamavalbeszeltel = 0
    default debravalbeszeltel3resz = 0
    default regell3resz = True
    default uditosmagamhozveni = 0
    default ennivini = 0
    default megetted = False
    default harmadikreszkonyha = 0
    default vanszedvicsed2 = 0
    default beszedvalamivelkapcsolatban = "semi"
    default kaveamamanak = False
    default kaveamamanakkesz = False
    default kavehaznalatiut = 0
    default felszereliaszurot = False
    default felszereliakupakot = False
    default kavefozobekapcsolva = False
    default megkaptadavizeskancsot = False
    default megkaptadakavekiontott = False
    default akavekiontohejen = False
    default vizeskancsovizes = False
    default vizakavefozoben = False
    default lefottaviz = False
    default kavefifinel = False
    default kavefrednel = False
    default kaveahejen = False
    default kaveazasztalon = False
    default kaveazasztalon2 = False
    default kaveazasztalrolinvertoriba = False
    default fifieniker = False
    default fifienikap = False
    default kutyatalakonyhaban = False
    default kutyatalaltelenalad = False
    default kutyatalaltelefifinel = False
    default kavefozoheztettel = False
    default isztaruhafel = 0
    default taskafel = 0
    default invertorinejelenyenmeg = False
    default teremjelenetek = 0
    default dagivalbeszed = 0
    default markvalbeszed = 0
    default anikavalbeszed = 0
    default resz3hazamegy = False
    default terkeproljovet = False
    default hoztejet = 0
    default neznyomozosfilmet = 0
    default beszeljaszomszedokkal = 0
    default penz = 0
    default baloldaliszomszed = 0
    default jobboldaliszomszed = 0
    default tejetvetem = False
    default nyalokavetem = False
    default magazinvetem = False
    default tejetlerektam = False
    default nyalokatodaadtam = False
    default debraeszik = 0
    default harmadikreszvegehez = False
    default magazinraveri = False
    default felszerelszurotarto = False
    default mamaelkoszont = False
    default Tanulnimatematika3resz = False
    default Tanulniepiteszet3resz = False
    default Tanulnitortenelem3resz = False
    default nemtanulhatsztobbet3resz = False
    default terkeproljovet2 = False

label osszezalha4:
    default regell4resz = True
    default pornomagazint = "semi"
    default mamaszedvicsamitelfogad = False
    default mamaszedvicsetker4resz = False
    default mamaszedvicsetker = False
    default mamaszedvicsetkap = False
    default mamakonyhabanregel4resz = True
    default mamanapalibanregel4resz = True
    default mamauditotker = False
    default mamauditotkap = False
    default mamabeszednapali = 0
    default mamanakkonyhaszedvics = False
    default mamanakmegteritvakonyha = False
    default mamaszedvics = 0
    default mamakave = 0
    default fifitregeliztetni = 0
    default mamanakteritve = 0
    default nincskenyeraszedvicshez = True
    default kenyeretvetetem = False
    default debratolkenyeretkerni = 0
    default debrareggel4resznapaliben = True
    default debratolkerdeznikenyer = False
    default kutyatap = False
    default konzevnyito = False
    default kutyatapkibontva = False
    default kutyatalfojasojobb = True
    default nincskutyatap = False
    default kutyatapotkernidebratol = False
    default debrakutyatapboltban = 0
    default beszeljamamaval = 0
    default fifipoziciok = 0
    default debrapanasz = 0
    default dagimama4resz = False
    default dagitmegharaptafifi = 0
    default debratolelsosegej = 0
    default dagiszovege = 1

label osszezalha5:
    default regell5resz = True
    default debraafurdoben5resz = 0
    default furdobenvagy = 1
    default debratprobalodmegfogdosni = 1
    default kakitfeltakaritani = 1
    default felmosotvenni = 1
    default debravalbeszed = 1
    default kakitfeltakaritanikersz = False
    default debratolkerniszivacs = 0
    default zsacskonalad = 1
    default felvetedaszivacsot = 0
    default debrafurdik = False
    default kakialatpisi = 0
    default szivacskimosasaproba = 0
    default dolgozolmosogataselteltido2 = 0
    default szivacskoszoslettido = 0
    default szivacskoszoslettidoszamol = False
    default szedvisz1 = True
    default szedvisz2 = True
    default szemetettkidobni5resz = 0
    default lampatkidobni5resz = 0
    default beszedmarkkal = 0
    default beszedritakal = 0
    default beszedanikakal = 0
    default beszedjimkal = 0
    default beszedkittykal = 0
    default santakolduszolieknal = 0
    default csiposzenyo = 0
    default boltosalbeszelni = 0
    default barkacsboltosalbeszelni = 0
    default lampaboltosalbeszelni = 0
    default lampabarkacsboltosalbeszelni = 0
    default lizanincsothon = True
    default lizanaljatal = 0
    default lizanalbeszeltel = 0
    default zolivalbeszeltel = 0
    default koldussalbeszeltel = 0
    default koldusnovelbeszeltel = 0
    default svetlananakatalpenzt = 0
    default svetlanavalbeszed = 0
    default svetlanavalbeszedmirol = 0
    default kolduskulacsa = 0
    default lizagyurulye = 0
    default lizagyurulyesvetlanatol = 0
    default lizavalmunkabameni = False
    default penzemhianyzik = 0
    default lizavalbeszeltelapenzrol = False
    default debrakolcsonadoltt = 0
    default zoliinfo = False
    default invertorikep = False
    default lizajelenetvege5resz = False
    default kerdezkorbe = False
    default annabesze = 0
    default fiupoz = 1

label osszezalha6:
    default regell6resz = True
    default porszivofelveni = 0
    default porszivofeladet = 0
    default porszivozotszobak = 0
    default porszivozfojasojobb = 0
    default porszivozfojasobal = 0
    default porszivoznapali = 0
    default porszivozatjaro = 0
    default porszivozfurdo = 0
    default porszivozkonyha = 0
    default porszivozfojasojobbido = 20
    default porszivozfojasojobbelteltido = 0
    default porszivozfojasobalido = 20
    default porszivozfojasobaleltelido = 0
    default porszivoznapaliido = 20
    default porszivoznapalielteltido = 0
    default porszivozatjaroido = 20
    default porszivozatjaroelteltido = 0
    default porszivozfurdoido = 10
    default porszivozfurdoelteltido = 0
    default porszivozkonyhaido = 10
    default porszivozkonyhaelteltido = 0
    default debraeddigmozgott = False
    default debravegigpan = 0
    default debrafulbevalotmegkeresni1 = 0
    default debrafulbevalotmegkeresni2 = 0
    default debrafulbevalo1 = 0
    default debrafulbevalo2 = 0
    default mamanyaklanc = 0
    default fredkutatszennyesido = 20
    default fredkutatszennyeselteltido = 0
    default fredkutatporszivoido = 20
    default fredkutatporszivoelteltido = 0
    default mamavalbeszed = 1
    default fredkutatromokido = 20
    default fredkutatromokelteltido = 0
    default gerebjefej = 0
    default gerebjenyel = 0
    default gerebjekell = 0
    default lizanapaliabamehec = False
    default lizanapaliaeloszormesz = True
    default lizakertjeszemet1 = 1
    default lizakertjeszemet2 = 1
    default lizakertjeszemet3 = 1
    default lizakertjeszemet4 = 1
    default beszedmamavalkonyhaban6resz = False
    default porszivotkeres = False
    default lizakertjedudva1 = 1
    default lizakertjedudva2 = 1
    default lizakertjedudva3 = 1
    default lizakertjedudva4 = 1
    default lizakertjegomba = 1
    default lizakertjelevelek = 1
    default lizakertjemadarhaza = 0
    default lizakertjekesz = 0
    default lizakertjefeledatok = 0
    default lizakertjedudvafelszedve = False
    default lizakertjeszemetosszeszedve = False
    default lizakertjelevelekosszeszedve = False
    default lizakertjemadarhazaahejen = False
    default lizakertjekerdeztezlevelek = False
    default lizakertjekerdeztezmadarhaz = False
    default lizakertjekerdeztezcsavarok = False
    default lizakertjekukaszsakotkersz = False
    default lizakertjekukaszsakotkaptal = False
    default lizaszemeteszakja = 1
    default lizamadarhaza = 0
    default lizakertjeszemet1ido = 5
    default lizakertjeszemet2ido = 5
    default lizakertjeszemet3ido = 5
    default lizakertjeszemet4ido = 5
    default lizakertjeszemet1elteltido = 0
    default lizakertjeszemet2elteltido = 0
    default lizakertjeszemet3elteltido = 0
    default lizakertjeszemet4elteltido = 0
    default gerebjetkutatido = 20
    default gerebjetkutatelteltido = 0
    default csavar6resz = 0
    default csavarhuzo6resz = 0
    default feleslegesenkeres6reszido = 20
    default feleslegesenkeres6reszelteltido = 0
    default feleslegesenkeres6resz = False
    default svetlanagerebjekerdes = False
    default anikafodomellet6resz = False
    default mamaholvan = "szobajaban"
    default mamalatszik = False
    default lizatudbeszelni = False
    default zenenincsismetles = 1
    default kerdeztedabarkacsboltostol6resz = False

label osszezalha7:
    default debrakertjedudvak1 = 1
    default debrakertjedudvak2 = 1
    default debrakertjedudvak3 = 1
    default debrakertjedudvak4 = 1
    default debrakertjedudvak5 = 1
    default debrakertjegombakelveheto = 1
    default debrakertjekivagnivalobokor = 1
    default debrakertjekivagnivalobokorenged = False
    default debrakertjekomposztladafu1 = 0
    default debrakertjekomposztladafu2 = 0
    default debrakertje2bokorgaz = 1
    default debrakertje2erme = 0
    default debrakertje2foldturas = 0
    default debrakertje2foldturasazermen = 0
    default debrakertje2jomadzag = 1
    default debrakertje2leerestocso = 0
    default debrakertje2leerestocsohejen = 0
    default debrakertje2medencekosz = 1
    default debrakertje2medencekoszosviz = 1
    default debrakertje2medencetisztaviz = 0
    default debrakertje2roszmadzag = 0
    default debrakertje2ruhafent = 0
    default debrakertje2ruhalent = 0
    default debrakertje2salgcso = 0
    default debrakertje2salgcsofoltok = 0
    default debrakertje2vetemenyesdudva = 1
    default parkszemet1 = 1
    default parkszemet2 = 1
    default parkszemet3 = 1
    default parkszemet4 = 1
    default parkszemet5 = 1
    default parkszemet6 = 1
    default parkszemet7 = 1
    default parkszemet8 = 1
    default parkadriana = 0
    default szemeteszsaknalad = False
    default kittyparkotenged = False
    default kulcsajatekhoz = "0"
    default penztkaszlizatol7resz = False
    default beszeljzolival = 0
    default szerezegymobilt = 0
    default mobil = False
    default dagivalbeszeltel7resz = 0
    default pulivalbeszelsz = 0
    default pulinapozoagya = 0
    default pulinapozoagyakesz = False
    default tu = 0
    default vaszon1 = 0
    default vaszon2 = 0
    default cerna = 0
    default adrianahazaakarmenni = False
    default adrianahazaakarmenniszojbramnak = False
    default szoltalbramnakadrianarol = False
    default parkbanjarsz = 0
    default parktakaritasa = False
    default kittyholtakarit = 0
    default szemeteszak = 1
    default szemeteszedtel = 0
    default gyulaelmegy = False
    default pulinapozoagyaido = 20
    default pulinapozoagyaelteltido = 0
    default lizanvangeci = True
    default kiskendofurdoben = True
    default kiskendolizanal = False
    default szenyesmizeria = 0
    default ruhakosarnalad = False
    default ruhakosarnaladtele = True
    default ruhakosarnaladtelemijenruhaval = "semijen"
    default fojasokertfelemehtesz = False
    default debraviragcserepe = 0
    default mamanyaklanczalogjegy = 0
    default metszoollo = 0
    default metszoolloido = 20
    default metszoolloelteltido = 0
    default svetlanaermeje = 0
    default bokorazutbanido = 20
    default bokorazutbanelteltido = 0
    default kiteritesiproba = 0
    default ruhaszaritoido = 20
    default ruhaszaritoelteltido = 0
    default mamakert2benholvan = 0
    default madzagveheto = 0
    default fifiazutban = 0
    default eremkiasva = 0
    default fifiholvanakertben = "1"
    default oblitosuveg = 0
    default madzagido = 10
    default madzagelteltido = 0
    default madzagkerestemlomosszoba = 0
    default szaritojo = True

label osszezalha8:
    default kenocspulinak = 0
    default holvanliza = "tornazik"
    default pulilevanegve = True
    default kerdezkorbe8resz = False
    default boltostkerdezted8resz = False
    default debratkerdezted8resz = False
    default mamatkerdezted8resz = False
    default fodoholvan = "sehol"
    default mrpuliholvan = "napozoagy"
    default receptnalad = 0
    default tojasnalad = 0
    default tulipannalad = 0
    default tisztitoszernalad = 0
    default lizaviragnalad = 0
    default gyongyviragnalad = 0
    default elesztonalad = 0
    default tapasznalad = 0
    default poknalad = 0
    default mozsarnalad = 0
    default gombanalad = 0
    default rovarirtonalad = 0
    default lizanakmegmutatadareceptet = False
    default parktoszemet1 = 1
    default parktoszemet2 = 1
    default parktoszemet3 = 1
    default parktoszemet4 = 1
    default parktoszemet5 = 1
    default parktoszemet6 = 1
    default parktoszemet7 = 1
    default parktoszemet8 = 1
    default pokel = True
    default pokfelvetel = 0
    default rovarirtokukaban = 0
    default mehetszaparktohoz = False
    default parktotiszta = False
    default parktoszemet2ido = 20
    default parktoszemet6ido = 20
    default parktoszemet2elteltido = 0
    default parktoszemet6elteltido = 0
    default parktoszemet3ido = 5
    default parktoszemet5ido = 5
    default parktoszemet8ido = 5
    default parktoszemet3elteltido = 0
    default parktoszemet5elteltido = 0
    default parktoszemet8elteltido = 0
    default gerebjekell8resz = False
    default gerebjenalad = 0
    default gerebjekiveszido = 5
    default gerebjekiveszelteltido = 0
    default metszoollonalad = 0
    default metszoollokiveszido = 5
    default metszoollokiveszelteltido = 0
    default lizamekpozbanvan = 1
    default invertorimutateleje = 1
    default invertorimutavege = 5
    default targyazinvertoriban = 0
    default invertorieszkozszam = 0
    default pillangokaparktoban = False
    default fodobealt = False
    default svetlana = "sehol"
    default svetlanabeszetelmikorgazdag = 0
    default svetlanapan = 0
    default mozsarazasztalon = 0
    default receptkeszulido = 20
    default receptkeszulelteltido = 0
    default pulimegfordulido = 20
    default pulimegfordulelteltido = 0
    default pulimegfordulvigyazgomb = 0
    default pulimegfordulhanyadik = 0
    default vigyazgombholvan = '1'
    default debrakertje2sokdudvafelszed1 = 1
    default debrakertje2sokdudvafelszed2 = 1
    default debrakertje2sokdudvafelszed3 = 1
    default debrakertje2sokdudvafelszed4 = 1
    default debrakertje2sokdudvafelszed5 = 1
    default debrakertje2sokdudvafelszed6 = 1
    default debrakertje2sokdudvafelszed7 = 1
    default debrakertje2sokdudvafelszed8 = 1
    default debrakertje2sokdudvafelszed9 = 1
    default debrakertje2sokdudvafelszed10 = 1
    default debrakertje2sokdudvafelszed11 = 1
    default debrakertje2sokdudvafelszed12 = 1
    default debrakert2dudva = 12
    default debrautasit8reszkertben = False
    default kompostszemet = False
    default bokornyiras8reszelteltido = 0
    default bokornyiras8reszido = 20
    default mamakert2pozbanvan = 1
    default debrakert2pozbanvan = 1
    default debrakert2benholvan = '1'
    default sokfol8resz = 0
    default sokfol8reszido = 20
    default sokfol8reszelteltido = 0
    default vegea8resznek = False

label osszezalha9:
    default festekoldonalad = 0
    default faagnalad = 0
    default horognalad = 0
    default gilisztanalad = 0
    default giliszta = 1
    default giliszta2 = 1
    default salgcsonalad = 0
    default leengedonalad = 0
    default poharnalad2 = 0
    default kutyatalnalad = 0
    default tejnalad = 0
    default szedvicsnalad = 0
    default halnalad = 0
    default gyufanalad = 0
    default agfuresznalad = 0
    default szivacsnalad = 0
    default temetokapuszemet1 = 1
    default temetokapuszemet2 = 1
    default temetokapuszemet3 = 1
    default temetokapuszemet4 = 1
    default temetokapuszemet5 = 1
    default temetokapuszemet6 = 1
    default temetokapuszemet7 = 1
    default temetokapuszemet8 = 1
    default temetokapuszemet9 = 1
    default temetokapuszemet10 = 1
    default temetokapuszemet11 = 1
    default temetokapuszemet12 = 1
    default temetokapuszemet13 = 1
    default temetokapuszemet14 = 1
    default temetokapuszemet15 = 1
    default temetokapuszemet16 = 1
    default temetokapuszemet17 = 1
    default temetokapuszemet18 = 1
    default temetokapuszemet19 = 1
    default temetokapuszemet20 = 1
    default temetokapuszemet21 = 1
    default temetokapuszemet22 = 1
    default temetokapuszemet23 = 1
    default temetosirkosz1 = 1
    default temetosirkosz2 = 1
    default temetosirkosz3 = 1
    default temetoigyufa = 1
    default kutyatalban = "semmi"
    default poharbanban = "semmi"
    default kittykeriagyufat = False
    default kellegyagfuresz = False
    default debraindulhat2resz = False
    default Edwardsholvan = "sehol"
    default parkpadoshaterfaag = 1
    default parkpadoshaterlevel = 1
    default parkpadoshaterszedvics = 0
    default parkpadoshatertaska = 1
    default parkpadoshatertej = 0
    default parkpadoshaterzsepi = 1
    default pecabotkell = False
    default resz9jelenet1 = False
    default resz9jelenet2 = False
    default tiltjaatereketszomszedok = False
    default tiltjaatereketpark = False
    default tiltjaatereketbolt = False
    default tiltjaatereketegyetem = False
    default tiltjaatereketsritbar = False
    default tiltjaaterekettemeto = False
    default tiltjaadebrakertjet = False
    default medencetkitakaritanidebramondja = False
    default beszeltelannaval9resz = False
    default leengedocsofelveheted = False
    default kittyholvan = "parkban"
    default adrianaholvan = "sehol"
    default adriananakvizkell = False
    default adrianavalbeszeltel9resz = 0
    default adrianahadja9resz = False
    default medenceleengedido = 20
    default medenceleengedelteltido = 0
    default leengedocsoafoldon = 0
    default debraszivacsotestisztitoszertker9resz = False
    default debravalesmamavalbeszeltel9resz = False
    default mamatbekented9resz = False
    default puffyholvan = "sehol"
    default ritaholvan = "sehol"
    default annaholvan = "sehol"
    default macskaholvan = "sehol"
    default macskaelszaladt = False
    default vetelkiamacskanakkajatahutobol = 0
    default pulikutyaholvan = "sehol"
    default beszeltelmredwardssal = 0
    default macskanakkinaltadakutyakajat = False
    default macskanakkinaltadatejet = False
    default ruhaszalitonalad = 0
    default fogjhalat = 0
    default annavalbeseltelparktonal = 0
    default betadinnalad = 0
    default annatholfogdosod = 0
    default annaajultido = 120
    default annaajultelteltido = 0
    default ferdhorgaszido = 20
    default ferdhorgaszelteltido = 0
    default macskanalad = 0
    default tiltjaaterkepet = False
    default taviranyito = 0
    default invertorialapjelenyenmeg = False
    default sanyiholvan = "boltnal"
    default boboholvan = "parkban"
    default bandiholvan = "boltnal"
    default keresedjet = False
    default kutyatalatfelveheted = False
    default metszoollofelveheted = False
    default ruhakosaratfelveheted = False
    default csovekkelenek9resz = 0
    default szivacsestisztitodebranal = False
    default beszeljpuffyval9resz = 0
    default ritamacskaja = 0
    default ritamacskajakajatpap = 0
    default neztvt9resz = 0

label osszezalha10:
    default tiltjaatereketcukrazda = False
    default ismeretlencokaholvan = "cukrazda"
    default cukraszdaismeretlencokavalbeszeltel = 0
    default cukraszdaritavalbeszeltel = 0
    default cukraszdamrpulivalbeszeltel = 0
    default lidiaholvan = "sehol"
    default dagiholvan = "sehol"
    default zoliholvan = "sehol"
    default bertalanholvan = "sehol"
    default alhat10reszvegen = 0
    default lidiamarapultnal = False
    default fagylaltoknalad = 0
    default cottonnalad = 0
    default pucernoaparkban = 0
    default pucernoaparktoban = 0
    default mama10reszcotton = 0
    default fodo10reszcotton = 0
    default eszter10reszcotton = 0
    default zoli10reszcotton = 0
    default cukrazdalathato = False
    default anikahogyall = 1
    default egyetemenvoltal10resz = 0
    default ladatmegtalalhatod = 0
    default kerjmunkatkerhec = False
    default ladabanvagyok = False
    default ladabanvanvalamiszamodra = True
    default ladalakatjanakkodjabeirt = 0
    default ladalakatnyithato = False
    default talaltlada9reszbelurrolkarkotoresz1 = 1
    default talaltlada9reszbelurrolkarkotoresz2 = 1
    default talaltlada9reszbelurrolkarkotoresz3 = 1
    default talaltlada9reszbelurrolkarkotoresz4 = 1
    default talaltlada9reszbelurrolkarkotoresz5 = 1
    default talaltlada9reszbelurrolkarkotoresz6 = 1
    default karkotonalad = 0
    default spaklinalad = 0
    default sirfestekeshezkell = False
    default sirmohashezkell = False
    default sirrozashezkell = False
    default kittyvelbeszeltel10resz = False
    default adtalpenzdaginak10resz = False
    default adtalpenzbebynak10resz = False
    default debrakendobenazagyon = False
    default temetolevagotrozsak = 0
    default ritavalbeszeltelacukrazdaban = False
    default sirokatmegtisztithatod = False

label osszezalha11:
    default svetlanahaza = False
    default tiltjaatereketnyomortanya = False
    default tiltjaatereketsetlanahaza = False
    default nyomortanyabago1 = 1
    default nyomortanyabago2 = 1
    default nyomortanyabago3 = 1
    default nyomortanyabago4 = 1
    default nyomortanyabago5 = 1
    default nyomortanyabago6 = 1
    default nyomortanyabago7 = 1
    default nyomortanyamama = 1
    default nyomortanyakoszosruhanalad = 0
    default nyomortanyakod = 1
    default nyomortanyadoboz1nalad = 0
    default nyomortanyadoboz2nalad = 0
    default nyomortanyadoboz3nalad = 0
    default oroszruha = "koszos"
    default oroszkonyvnalad = 0
    default oroszkonyvetfelveheted = False
    default egyetemenvoltal11resz = 0
    default nyomortanyanjartal = 0
    default rozsaholvan = "sehol"
    default bramholvan = "sehol"
    default ragasztonalad = 0
    default ragasztokell = False
    default rozsakatfelszedheted = False
    default rozsaknalad = 0
    default mubajuszkell = 0
    default hazamehetc = True
    default boriszfenykepenalad = 0
    default boriszfenykepenezted = False
    default beszelteledittel = False
    default editholvan = "nyomortanya"
    default svetlanaholvan = "sehol"
    default beszeltelbrammalabajusrol = False
    default rozsatfelveszido = 20
    default rozsatfelveszidoelteltido = 0
    default amandaholvan = "sehol"
    default amandapan2 = 0
    default mosogepjo = False
    default mosogepetmegkeljavitani = 0
    default mosogepetmegkeljavitanibobovalbeszeltel = False
    default ciliholvan = "sehol"
    default sanyithivhatod = 0
    default sanyithivtad = False
    default ciliszovegvaltozik = False
    default oroszultanulszido = 20
    default oroszultanulszelteltido = 0
    default oroszultanultal = False
    default svetlanajelnet11nap = 0
    default debra11napfeladatotad = 0
    default izzoknalad = 0
    default letranalad = 0
    default cottonkell11nap = 0
    default csacsiholvan = "parkban"
    default csacsimotyo = 0
    default csacsikalapja = 0
    default csacsikalapjanalad = 0
    default csacsikalapjatfelveheted = False
    default basziksvetlana11naphogyan = "sehogy"
    default basziksvetlana11napsebeseg = "semilyen"
    default basziksvetlana11napgyenge = 0
    default basziksvetlana11naperos = 0
    default basziksvetlana11napmasigszog = 0
    default basziksvetlana11napbaszasvege = False
    default debracicibaszi11nap = "sehogy"
    default debracicibaszi11naperoseg = "semilyen"
    default eszterrelbeszeltel11nap = False

label osszezalha12:
    default egyetemenvoltal12resz = 0
    default eszterholvan = "sehol"
    default tiltjaatereketlakotomb = False
    default lakotombaterkepen = False
    default naptar = 0
    default locsol = 0
    default viragnovekszik = 0
    default sabrinaholvan = "sehol"
    default jimholvan = "sehol"
    default markholvan = "sehol"
    default setalodagatnoholvan = "sehol"
    default izomcavoholvan = "sehol"
    default ancikaholvan = "sehol"
    default kokonalad = 0
    default sujzonalad = 0
    default sabrinanakadtalkokot = False
    default zolinakadtalkokot = False
    default ismeretlenakadtalkokot = False
    default bobonakadtalkokot = False
    default bisztonsaginakadtalkokot = False
    default tanterembenbeszeltelpuffy = False
    default tanterembenbeszeltelmark = False
    default tanterembenbeszeltelkitty = False
    default tanterembenbeszelteljim = False
    default tanterembenbeszeltelrita = False
    default kimehecaterembol12nap = False
    default lizafehiv12nap = False
    default lizafehiv12napesbeszeltelvele = False
    default beszeltelsabrinaval = False
    default esztercsilogot = False
    default asonallad = 0
    default debrafeladatotad12nap = 0
    default etterembenmenufuzet2 = 1
    default lidiaraer12nap = False
    default komposztnallad = 0
    default viraghagymanallad = 0
    default konyhakertido = 10
    default konyhakertelteltido = 0
    default mamakenocsenalad = 0
    default mamahatatbekellkeni12nap = 0
    default viragcserepnalad2 = 0
    default svetlanajelenet12nap = 0
    default kittyszemetetfelveheted = False
    default kittyszemetenalad = 0
    default tanulhac12nap = 0
    default ritaszex12nap = 0
    default debraseggenelbeszeltem = False
    default hogyanutdebra = 0
    default almaktalban = 0
    default borisznaploja = 0
    default fogasallo = 0
    default fogasallorajtaruha = 0
    default szakadtmedve = 0
    default szakadtmedvekulcsa = 0
    default boriszfotokeretben = 0
    default sevtlananalkipakolido = 10
    default sevtlananalkipakolelteltido = 0
    default feltoltokartyanalad = 0
    default lidianakregiegerkell = False
    default regiegernalad = 0
    default girosznalad = 0
    default debraszex12napjel4tovabb = 0
    default debraszex12napjel4gyors = 0
    default debraszex12napjel4gyorsabb = 0
    default debraszex12napjel4holvagy1 = 0
    default debraszex12napjel4holvagy2 = 0
    default debraszex12napjel4holvagy3 = 0
    default nap12estelegyen = 0
    default boltbanemmehetek = False
    default invertorijelenyenmeg = True
    default lizavalszexeltel = False
    default milyensebesegelcsinalodlizaval12napgombmelyik1 = 0
    default milyensebesegelcsinalodlizaval12napgombmelyik2 = 0
    default milyensebesegelcsinalodlizaval12napgombmelyik3 = 0
    default milyensebesegelcsinalodlizaval12naplassu = 0
    default milyensebesegelcsinalodlizaval12napgors = 0
    default milyensebesegelcsinalodlizaval12napgorsabb = 0
    default milyensebesegelcsinalodlizaval12napelelvezhec = 0
    default cilinekjelenteni = False
    default telefonalsz = False






default svetlanakedvel = 0



default hanyadiknapvan = 1
image fram = Frame("tablazathater", 40, 40, 40, 40, tile=True)

screen vege:
    text "{b}{size=+10}The Secret Of The House{vspace=20}End Of Day 12{vspace=20}To Be Continued{vspace=20}Support Me:{vspace=20}{a=https://www.patreon.com/DiscreenVision}www.patreon.com/DiscreenVision{/a}":
        xpos 0.5
        xalign 0.5
        yalign 0.475
        text_align 0.5
screen jelszokell:
    text "{b}{size=+10}The Secret Of The House{vspace=20}To Be Continued{vspace=20}Support Me:{vspace=20}{a=https://www.patreon.com/DiscreenVision}www.patreon.com/DiscreenVision{/a}":
        xpos 0.5
        xalign 0.5
        yalign 0.475
        text_align 0.5

screen blockctrl:
    key "rollback" action [[]]
    key "rollforward" action [[]]
    key "toggle_skip" action [[]]
screen s25:
    timer 0.25 action [Hide ("s25"), Return ("value")]
    key "dismiss" action [[]]
screen s04:
    timer 0.4 action [Hide ("s04"), Return ("value")]
    key "dismiss" action [[]]
screen s05:
    timer 0.5 action [Hide ("s05"), Return ("value")]
    key "dismiss" action [[]]
screen s06:
    timer 0.6 action [Hide ("s06"), Return ("value")]
    key "dismiss" action [[]]
screen s0e75:
    timer 0.75 action [Hide ("s0e75"), Return ("value")]
    key "dismiss" action [[]]
screen s1:
    timer 1.0 action [Hide ("s1"), Return ("value")]
    key "dismiss" action [[]]
screen s1e2:
    timer 1.2 action [Hide ("s1e2"), Return ("value")]
    key "dismiss" action [[]]
screen s1e5:
    timer 1.5 action [Hide ("s1e5"), Return ("value")]
    key "dismiss" action [[]]
screen s1e8:
    timer 1.8 action [Hide ("s1e8"), Return ("value")]
    key "dismiss" action [[]]
screen s2:
    timer 2.0 action [Hide ("s2"), Return ("value")]
    key "dismiss" action [[]]
screen s2e3:
    timer 2.3 action [Hide ("s2e3"), Return ("value")]
    key "dismiss" action [[]]
screen s2e5:
    timer 2.5 action [Hide ("s2e5"), Return ("value")]
    key "dismiss" action [[]]
screen s3:
    timer 3.0 action [Hide ("s3"), Return ("value")]
    key "dismiss" action [[]]
screen s3e4:
    timer 3.4 action [Hide ("s3e4"), Return ("value")]
    key "dismiss" action [[]]
screen s3e75:
    timer 3.75 action [Hide ("s3e75"), Return ("value")]
    key "dismiss" action [[]]
screen s4:
    timer 4.0 action [Hide ("s4"), Return ("value")]
    key "dismiss" action [[]]
screen s5:
    timer 5.0 action [Hide ("s5"), Return ("value")]
    key "dismiss" action [[]]
screen s6:
    timer 6.0 action [Hide ("s6"), Return ("value")]
    key "dismiss" action [[]]
screen s7:
    timer 7.0 action [Hide ("s7"), Return ("value")]
    key "dismiss" action [[]]
screen s8:
    timer 8.0 action [Hide ("s8"), Return ("value")]
    key "dismiss" action [[]]
screen s8e5:
    timer 8.5 action [Hide ("s8e5"), Return ("value")]
    key "dismiss" action [[]]
screen s10:
    timer 10.0 action [Hide ("s10"), Return ("value")]
    key "dismiss" action [[]]
screen s11:
    timer 11.0 action [Hide ("s11"), Return ("value")]
    key "dismiss" action [[]]
screen s12:
    timer 12.0 action [Hide ("s12"), Return ("value")]
    key "dismiss" action [[]]

label gameover:
    show fekete onlayer screens:
        alpha 0.0
        linear 2.0 alpha 1.0
    show fifigameover onlayer screens:
        alpha 0.0
        linear 2.0 alpha 1.0
    show text "Game Over" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s5
    u ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
