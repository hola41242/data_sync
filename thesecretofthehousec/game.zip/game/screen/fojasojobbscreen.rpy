screen fojasojobb:
    imagebutton:
        idle "ajtok/feaz.png"
        xalign 0.9
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("dolgozoszoba")
    imagebutton:
        idle "ajtok/fhaz.png"
        xalign 0.55
        yalign 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("fajasokertfele")
    imagebutton:
        idle "ajtok/fliftz.png"
        xalign 0.06
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("lomosszoba")
    imagebutton:
        idle "nyilafojason.png"
        xalign 0.45
        yalign 0.98
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("fojasoball")
    imagebutton:
        idle "ajtok/kijaratz.png"
        xalign 0.45
        yalign 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("kijaratiajto")
    if hanyadiknapvan == 1:
        if semeteszsakafoldon == False:
            imagebutton:
                idle "eszkozok/szemeteszsakz.png"
                xalign 0.40
                yalign 0.68
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('szemeteszsakfel')
        if ujsagafoldon == False:
            imagebutton:
                idle "eszkozok/ujsagkicsiz.png"
                xalign 0.475
                yalign 0.565
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('ujsagkicsifel')
        if viragokmegontozese == False:
            if locsolokannafel == True:
                if fojasojobbvirag == False:
                    imagebutton:
                        idle "ajtok/kijaratz.png"
                        xpos 0.265
                        ypos 0.61
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("locsolfojjobb")
    if hanyadiknapvan == 3:
        if lefottaviz == True:
            if kutyatalaltelenalad == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.4
                    yalign 0.65
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("fifivediakavet")
        if lefottaviz == True:
            if fifieniker == True:
                if kavefrednel == False:
                    if kutyatalaltelenalad == True:
                        imagebutton:
                            idle "ajtok/ruhaz.png"
                            xalign 0.4
                            yalign 0.65
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("fifiengedikavet")
    if hanyadiknapvan == 4:
        if fifitregeliztetni == 1:
            if kutyatalfojasojobb == True:
                imagebutton:
                    idle "ajtok/minuszz.png"
                    xalign 0.445
                    yalign 0.655
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kutyatalfelfojasojobb")
    if hanyadiknapvan == 5:
        if szemetettkidobni5resz == 1:
            if lizavalmunkabameni == False:
                imagebutton:
                    idle "eszkozok/szemeteszsakz.png"
                    xalign 0.40
                    yalign 0.68
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ('szemeteszsakfel')
        if lampatkidobni5resz == 1:
            imagebutton:
                idle "ajtok/kijaratz.png"
                xalign 0.32
                yalign 0.7
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('lampafel')
    if hanyadiknapvan == 6:
        if debraholcsinal == "lomolgatfojasojobb":
            if porszivotkeres == False:
                imagebutton:
                    idle "ajtok/nszaballz.png"
                    xpos 0.5
                    ypos 0.3
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrajobbfojasonallomol")
        if debraholcsinal == "ablakotpucoljobbfojason":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/nszaballz.png"
                    xpos 0.26
                    ypos 0.27
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrajobbfojasonablakottorol")
    if hanyadiknapvan == 7:
        if debraholcsinal == "ablakotpucoljobbfojason":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/nszaballz.png"
                    xpos 0.26
                    ypos 0.27
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrajobbfojasonablakottorol")
        if fifiazutban == 1:
            if fifitfelvetem == False:
                imagebutton:
                    idle "ajtok/minuszz.png"
                    xpos 0.44
                    ypos 0.47
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("fifitfelvenni7nap")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
