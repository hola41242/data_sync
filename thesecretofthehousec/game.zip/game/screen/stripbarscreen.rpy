screen stripbar:
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.0
        ypos 0.52
        mouse "aktion"
        activate_sound "audio/click.wav"
        action SetVariable('invertorinejelenyenmeg', True), Jump ("terkep")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.65
        ypos 0.7
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("stripbarkidobaltlimlom")
    imagebutton:
        idle "ajtok/debporz.png"
        xpos 0.45
        ypos 0.05
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("buzzyvalbeszelni")
    if rozsaholvan == "stripbar":
        imagebutton:
            idle "ajtok/debporz.png"
            xpos 0.3
            ypos 0.37
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("rozsivalbeszelnistripbar")
screen lizasexvaltas:
    if milyensebesegelcsinalodlizaval12napgombmelyik1 == 1:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Slow":
                mouse "aktion"
                action Hide ('lizasexvaltas'), Jump ("lizaszex12naplassu")
                text_style "fegeteszov"
    if milyensebesegelcsinalodlizaval12napgombmelyik2 == 1:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.8
            xalign 0.5
            textbutton "Fast":
                mouse "aktion"
                action Hide ('lizasexvaltas'), Jump ("lizaszex12napgyors")
                text_style "fegeteszov"
    if milyensebesegelcsinalodlizaval12napgombmelyik3 == 1:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.7
            xalign 0.5
            textbutton "Faster":
                mouse "aktion"
                action Hide ('lizasexvaltas'), Jump ("lizaszex12napgyorssabb")
                text_style "fegeteszov"
    if milyensebesegelcsinalodlizaval12napelelvezhec == 1:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.6
            xalign 0.5
            textbutton "Cum!":
                mouse "aktion"
                action Hide ('lizasexvaltas'), Jump ("lizaszex12napelevez")
                text_style "fegeteszov"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
