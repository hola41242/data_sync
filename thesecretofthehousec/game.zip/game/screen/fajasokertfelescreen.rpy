screen fajasokertfele:
    imagebutton:
        idle "ajtok/feaz.png"
        xalign 0.1
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ismeretlenajto1")
    imagebutton:
        idle "ajtok/fhaz.png"
        xalign 0.45
        yalign 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("gyerekszoba")
    imagebutton:
        idle "ajtok/fliftz.png"
        xalign 0.94
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ismeretlenajto1")
    imagebutton:
        idle "nyilafojason.png"
        xalign 0.55
        yalign 0.98
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("fojasojobb")
    imagebutton:
        idle "ajtok/kijaratz.png"
        xalign 0.55
        yalign 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje")
    if hanyadiknapvan == 7:
        if debraviragcserepe == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.57
                ypos 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("viragcserepfel")
    if viragcserepnalad2 == 2:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.64
            ypos 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("viragcserepbeultetett")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
