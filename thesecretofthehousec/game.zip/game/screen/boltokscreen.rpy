screen bolt:

    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Hide ('bolt'), Jump ("terkep")
            text_style "fegeteszov"
    imagebutton:
        idle "ajtok/nszaballz.png"
        xalign 0.42
        yalign 0.77
        mouse "aktion"
        activate_sound "audio/click.wav"
        if boltbanemmehetek == True:
            action Jump ("boltbanemmehetek")
        if boltbanemmehetek == False:
            action Jump ("supermarket")
    imagebutton:
        idle "ajtok/kijaratz.png"
        xalign 0.75
        yalign 0.76
        mouse "aktion"
        activate_sound "audio/click.wav"
        if boltbanemmehetek == True:
            action Jump ("boltbanemmehetek")
        if boltbanemmehetek == False:
            action Jump ("toolshop")
    imagebutton:
        idle "ajtok/kijaratz.png"
        xalign 0.97
        yalign 0.78
        mouse "aktion"
        activate_sound "audio/click.wav"
        if boltbanemmehetek == True:
            action Jump ("boltbanemmehetek")
        if boltbanemmehetek == False:
            action Jump ("sindyclothingstore")
    if hanyadiknapvan == 5:
        if regell5resz == False:
            if kolduskulacsa < 2:
                imagebutton:
                    idle "ajtok/kijaratz.png"
                    xalign 0.82
                    yalign 0.8
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("svetlanabeszedboltnal")
        if lizanaljatal >= 1:
            if lizagyurulye < 4:
                imagebutton:
                    idle "ajtok/kijaratz.png"
                    xalign 0.22
                    yalign 0.73
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("lizabeszedboltnal")
    if hanyadiknapvan == 6:
        if mamanyaklanc < 2:
            imagebutton:
                idle "ajtok/kijaratz.png"
                xalign 0.82
                yalign 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("svetlanabeszedboltnal")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.62
            yalign 0.75
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("kittiesritabeszedboltnal6resz")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.23
            yalign 0.75
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("anikaesfodobeszedboltnal6resz")
    if hanyadiknapvan == 7:
        if adrianahazaakarmenniszojbramnak == False:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.25
                yalign 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("boltnalbelehalgatgyulaesrozsibeszed")
        if adrianahazaakarmenniszojbramnak == True:
            if gyulaelmegy == False:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.25
                    yalign 0.75
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("boltnalgyulabeszed")
        if adrianahazaakarmenni == True:
            if svetlanaermeje < 2:
                imagebutton:
                    idle "ajtok/kijaratz.png"
                    xalign 0.82
                    yalign 0.8
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("svetlanabeszedboltnal")
        if parkadriana == 2:
            if vaszon2 == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.92
                    ypos 0.75
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("vaszon2fel")
    if hanyadiknapvan == 8:
        if fodoholvan == "boltelott":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.23
                yalign 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("fodobeszedboltnal8resz")
        if svetlana == "boltnal":
            imagebutton:
                idle "ajtok/kijaratz.png"
                xalign 0.82
                yalign 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("svetlanabeszedboltnal")
    if hanyadiknapvan == 9:
        if puffyholvan == "boltnal":
            if svetlana == "boltnal":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.68
                    yalign 0.75
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("svetlanabeszedboltnalpuffyval")
        if pulikutyaholvan == "boltoknal":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.2
                ypos 0.75
                if kutyatalban == "semmi":
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("pulimegesziamitamacskameghagyott")
                if kutyatalban == "kutyakaja":
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("pulimegesziamitamacskameghagyott")
                if kutyatalban == "tej":
                    if macskanakkinaltadatejet == True:
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("pulimegesziamitamacskameghagyott")
        if sanyiholvan == "boltnal":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.22
                ypos 0.57
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("sanyiboltnal")
        if bandiholvan == "boltnal":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.52
                ypos 0.52
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("bandiboltnal")
    if hanyadiknapvan == 10:
        if svetlana == "boltnal":
            imagebutton:
                idle "ajtok/kijaratz.png"
                xalign 0.82
                yalign 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("svetlanabeszedboltnal")
    if hanyadiknapvan >= 11:
        if fodoholvan == "boltelott":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.23
                yalign 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("fodobeszedboltnal8resz")
        if rozsaholvan == "boltoknal":
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.62
                yalign 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("rozsaboltnal")
        if sanyiholvan == "boltnal":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.22
                ypos 0.57
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("sanyiboltnal")
    if hanyadiknapvan == 12:
        if eszterholvan == "boltelott":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.55
                ypos 0.56
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("eszterboltnal")
        if eszterholvan == "boltelott":
            if ancikaholvan == "boltnal":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.55
                    ypos 0.56
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("eszterboltnalancikaval")
screen vegyesboltaru:
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Jump ("supermarketki")
            text_style "fegeteszov"
    if hanyadiknapvan == 3:
        if tejetvetem == False:
            frame:
                background ('fram')
                xpos 0.2
                ypos 0.2
                xalign 0.5
                textbutton "Milk: 250 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 250), SetVariable('tejetvetem', True)
                    text_style "fegeteszov"
        if nyalokavetem == False:
            frame:
                background ('fram')
                xpos 0.2
                ypos 0.3
                xalign 0.5
                textbutton "Lollipop: 100 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 100), SetVariable('nyalokavetem', True)
                    text_style "fegeteszov"
        if magazinvetem == False:
            frame:
                background ('fram')
                xpos 0.2
                ypos 0.4
                xalign 0.5
                textbutton "Porn Magazine: 300 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 300), SetVariable('magazinvetem', True)
                    text_style "fegeteszov"
    if hanyadiknapvan == 4:
        if debratolkenyeretkerni == 1:
            frame:
                background ('fram')
                xpos 0.2
                ypos 0.2
                xalign 0.5
                textbutton "Bread: 350 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 350), SetVariable('debratolkenyeretkerni', debratolkenyeretkerni + 1), SetVariable('kenyeretvetetem', True)
                    text_style "fegeteszov"
        if debrakutyatapboltban == 2:
            if kutyatap == False:
                frame:
                    background ('fram')
                    xpos 0.2
                    ypos 0.3
                    xalign 0.5
                    textbutton "Dog Food: 250 Ft":
                        mouse "aktion"
                        action SetVariable('penz', penz - 250), SetVariable('kutyatap', True)
                        text_style "fegeteszov"
        if debrakutyatapboltban == 4:
            if konzevnyito == False:
                frame:
                    background ('fram')
                    xpos 0.2
                    ypos 0.4
                    xalign 0.5
                    textbutton "Can opener: 150 Ft":
                        mouse "aktion"
                        action SetVariable('penz', penz - 150), SetVariable('konzevnyito', True), SetVariable('debrakutyatapboltban', debrakutyatapboltban + 1)
                        text_style "fegeteszov"
    if hanyadiknapvan == 5:
        if boltosalbeszelni == 1:
            imagebutton:
                idle "ajtok/nagyajto2z.png"
                xalign 0.95
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("boltosalesterbeszed")
        if kolduskulacsa == 1:
            imagebutton:
                idle "ajtok/nagyajto2z.png"
                xalign 0.95
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("boltosalesterbeszed")
        if felvetedaszivacsot == 2:
            frame:
                background ('fram')
                xpos 0.2
                ypos 0.2
                xalign 0.5
                textbutton "Sponge: 300 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 300), SetVariable('felvetedaszivacsot', felvetedaszivacsot + 1), SetVariable('torloszivacsnalad', True)
                    text_style "fegeteszov"
    if hanyadiknapvan == 6:
        if gerebjekell == 1:
            imagebutton:
                idle "ajtok/nagyajto2z.png"
                xalign 0.95
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("boltosalesterbeszed")
        if lizakertjemadarhaza == 2:
            if csavar6resz == 0:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.95
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("boltosalesterbeszed")
            if csavarhuzo6resz == 0:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.95
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("boltosalesterbeszed")
    if hanyadiknapvan == 7:
        if pulinapozoagya == 1:
            if vaszon2 == 0:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.95
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("boltosalesterbeszed")
    if hanyadiknapvan == 8:
        if receptnalad == 0:
            if kerdezkorbe8resz == True:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.95
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("boltosalesterbeszed")
        if receptnalad == 1:
            if lizanakmegmutatadareceptet == False:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.95
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("boltosalesterbeszed")
        if lizanakmegmutatadareceptet == True:
            if elesztonalad == 0:
                frame:
                    background ('fram')
                    xpos 0.2
                    ypos 0.2
                    xalign 0.5
                    has textbutton "Dry yeast: 250 Ft"
                    if penz < 250:
                        mouse "aktion"
                        action Jump ('nincsrapenzem')
                        text_style "fegeteszov"
                    if penz >= 250:
                        mouse "aktion"
                        action SetVariable('penz', penz - 250), SetVariable('elesztonalad', elesztonalad + 1), SetVariable('debraholcsinal', "kertbentanul" )
                        text_style "fegeteszov"
    if hanyadiknapvan == 10:
        if kerjmunkatkerhec == True:
            if ladatmegtalalhatod == 0:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.95
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("boltosalesterbeszed")
        if fagylaltoknalad == 2:
            if cottonnalad == 0:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.95
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("boltosalesterbeszed")
    if hanyadiknapvan == 11:
        if cottonkell11nap == 1:
            imagebutton:
                idle "ajtok/nagyajto2z.png"
                xalign 0.95
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("boltosalesterbeszed")
screen toolshop:
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Jump ("toolshopki")
            text_style "fegeteszov"
    if hanyadiknapvan == 5:
        if felmosotvenni == 1:
            frame:
                background ('fram')
                xpos 0.8
                ypos 0.3
                xalign 0.5
                textbutton "Mop: 1250 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 1250), SetVariable('felmosotvenni', felmosotvenni + 1)
                    text_style "fegeteszov"
        if barkacsboltosalbeszelni == 1:
            imagebutton:
                idle "ajtok/nagyajto2z.png"
                xalign 0.21
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("toolshoppiribeszed")
        if kolduskulacsa == 1:
            imagebutton:
                idle "ajtok/nagyajto2z.png"
                xalign 0.21
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("toolshoppiribeszed")
    if hanyadiknapvan == 6:
        if lizakertjemadarhaza == 2:
            if csavar6resz == 0:
                frame:
                    background ('fram')
                    xpos 0.8
                    ypos 0.3
                    xalign 0.5
                    textbutton "Get the Screws: 250 Ft":
                        mouse "aktion"
                        action SetVariable('penz', penz - 250), SetVariable('csavar6resz', 1)
                        text_style "fegeteszov"
            if csavarhuzo6resz == 0:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.21
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("toolshoppiribeszed")
    if hanyadiknapvan == 7:
        if pulinapozoagya == 1:
            if vaszon2 == 0:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.21
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("toolshoppiribeszed")
        if parkadriana == 1:
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.75
                ypos 0.16
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("beszedbrammalboltban")
        if metszoollo == 1:
            frame:
                background ('fram')
                xpos 0.8
                ypos 0.3
                xalign 0.5
                textbutton "Get the secateurs: 2250 Ft":
                    mouse "aktion"
                    action Jump ('metszoollotoolshopban')
                    text_style "fegeteszov"
        if madzagveheto == 1:
            frame:
                background ('fram')
                xpos 0.8
                ypos 0.3
                xalign 0.5
                textbutton "Get the clothesline: 220 Ft":
                    mouse "aktion"
                    action Jump ('ruhaszaritomadzag7nap')
                    text_style "fegeteszov"
    if hanyadiknapvan == 8:
        if receptnalad == 1:
            if lizanakmegmutatadareceptet == False:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.21
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("toolshoppiribeszed")
    if hanyadiknapvan == 10:
        if kerjmunkatkerhec == True:
            if ladatmegtalalhatod == 0:
                imagebutton:
                    idle "ajtok/nagyajto2z.png"
                    xalign 0.21
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("toolshoppiribeszed")
    if hanyadiknapvan >= 11:
        if bramholvan == "barkacsboltban":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.75
                ypos 0.16
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("beszedbrammalboltban")
        if mubajuszkell == 1:
            imagebutton:
                idle "ajtok/nagyajto2z.png"
                xalign 0.21
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("toolshoppiribeszed")
screen lizaboltnal:
    frame:
        background ('fram')
        xpos 0.85
        ypos 0.2
        xalign 0.5
        textbutton "Let us touch her.":
            mouse "aktion"
            action Hide ('lizaboltnal'), Jump ('lizaboltnalfogdos')
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.85
        ypos 0.3
        xalign 0.5
        textbutton "Just kidding.":
            mouse "aktion"
            action Hide ('lizaboltnal'), Jump ('beszedugrik5resz3')
            text_style "fegeteszov"
screen anikaelmegyfodomellol6resz:
    timer 60.0 repeat True action SetVariable('anikafodomellet6resz', True), Hide ('anikaelmegyfodomellol6resz')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
