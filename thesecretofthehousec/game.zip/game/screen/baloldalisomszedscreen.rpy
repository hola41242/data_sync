screen baloldalisomszed:
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Hide ('baloldalisomszed'), Jump ("terkep")
            text_style "fegeteszov"
    if hanyadiknapvan == 4:
        if baloldaliszomszed == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.43
                ypos 0.67
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizavalbeszelsz")
        if jobboldaliszomszed == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 1.0
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
    if hanyadiknapvan == 5:
        if lizagyurulye == 0:
            imagebutton:
                idle "ajtok/debpor2z.png"
                xalign 0.3
                ypos 0.4
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizavalbeszelsz")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.95
            ypos 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
        if lizagyurulye >= 1:
            if kolduskulacsa < 3:
                imagebutton:
                    idle "ajtok/kijaratz.png"
                    xalign 0.47
                    yalign 0.82
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("koldusalbeszed")
        imagebutton:
            idle "ajtok/kijaratz.png"
            xalign 0.85
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("beszedannaval5resz")
    if hanyadiknapvan == 6:
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.3
            ypos 0.4
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizanapalia")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            ypos 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
        imagebutton:
            idle "ajtok/kijaratz.png"
            xalign 0.85
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("beszedannaval5resz")
        if gerebjefej == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.65
                yalign 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("romkutatasa")
        if lizakertjemadarhaza == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.0
                ypos 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("madarhazfel6resz")
        if lizaszemeteszakja > 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.05
                yalign 0.77
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szemeteskontener6resz")
    if hanyadiknapvan == 7:
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.3
            ypos 0.4
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizanapalia")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            ypos 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
        imagebutton:
            idle "ajtok/kijaratz.png"
            xalign 0.85
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("beszedannaval5resz")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.65
            yalign 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("romkutatasa")
    if hanyadiknapvan == 8:
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.3
            ypos 0.4
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizanapalia")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            ypos 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
        imagebutton:
            idle "ajtok/kijaratz.png"
            xalign 0.85
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("beszedannaval5resz")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.65
            yalign 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("romkutatasa")
    if hanyadiknapvan == 9:
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.3
            ypos 0.4
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizanapalia")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            ypos 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
        if leengedocsofelveheted == False:
            imagebutton:
                idle "ajtok/kijaratz.png"
                xalign 0.85
                yalign 0.85
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("beszedannaval9resz")
        if leengedocsofelveheted == True:
            if leengedonalad == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.88
                    yalign 0.85
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("leengedocsofel")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.65
            yalign 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("romkutatasa")
        if salgcsonalad == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.0
                ypos 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("salgcsofell")
        if ritaholvan == "lizautcajaban":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.12
                ypos 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ritavalbeszelniutcakepen")
    if hanyadiknapvan == 10:
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.3
            ypos 0.4
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizanapalia")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            ypos 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.65
            yalign 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("romkutatasa")
    if hanyadiknapvan == 11:
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.3
            ypos 0.4
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizanapalia")
        if holvanliza == "hazelotgyomlal":
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.42
                ypos 0.67
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizavalbeszelsz")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            ypos 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.65
            yalign 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("romkutatasa")
    if hanyadiknapvan == 12:
        imagebutton:
            idle "ajtok/debpor2z.png"
            xalign 0.3
            ypos 0.4
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizanapalia")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            ypos 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Hide ('baloldalisomszed'), Jump ("jobboldaliszomszed")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.65
            yalign 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("romkutatasa")
        if izomcavoholvan == "lizahazaelot":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.6
                yalign 0.78
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("alfonzalbeszelni")
        if amandaholvan == "lizaekelott":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.18
                ypos 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("amandavalbeszelnilizaelott")
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.18
                ypos 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("amandavalbeszelnilizaelott")

screen kutatromok:
    frame:
        background ('fram')
        xpos 0.15
        ypos 0.9
        xalign 0.5
        textbutton "Stop searching.":
            mouse "aktion"
            action Jump ("romkutatasaabbahagy")
            text_style "fegeteszov"

    timer 1.0 repeat True action If(fredkutatromokido <= 0,
    true=[SetVariable('gerebjefej', gerebjefej + 1),
    Hide('kutatromok'),
    Jump('romkutatasaabbahagy')],
    false=[SetVariable('fredkutatromokido', fredkutatromokido - 1),
    SetVariable('fredkutatromokelteltido', fredkutatromokelteltido + 1)])
    bar:
        left_bar "#f00"
        if fredkutatromokido <= 10:
            left_bar "#0ff"
        if fredkutatromokido <= 0:
            left_bar "#0f0"
        value StaticValue(fredkutatromokelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen kutatromok2:
    timer 1.0 repeat True action If(fredkutatromokido <= 0,
    true=[SetVariable('ladatmegtalalhatod', ladatmegtalalhatod + 1),
    Hide('kutatromok2'),
    Jump('romkutatasaabbahagy')],
    false=[SetVariable('fredkutatromokido', fredkutatromokido - 1),
    SetVariable('fredkutatromokelteltido', fredkutatromokelteltido + 1)])
    bar:
        left_bar "#f00"
        if fredkutatromokido <= 15:
            left_bar "#0ff"
        if fredkutatromokido <= 0:
            left_bar "#0f0"
        value StaticValue(fredkutatromokelteltido, 30) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
