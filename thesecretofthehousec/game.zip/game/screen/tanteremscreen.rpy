screen tanterem:
    if hanyadiknapvan <= 4:
        imagebutton:
            idle "ajtok/kijaratz.png"
            xalign 0.17
            yalign 0.32
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("tanterembolki")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.05
            yalign 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("dagivalbeszed")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.22
            yalign 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("markvalbeszed")
        imagebutton:
            idle "ajtok/nagyajtoz.png"
            xalign 1.0
            yalign 1.0
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("anikavalbeszed")
    if hanyadiknapvan == 5:
        if csiposzenyo == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.35
                yalign 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("csiposzenyo")
        if beszedmarkkal == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.22
                yalign 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("markvalbeszed")
        if beszedritakal == 0:
            imagebutton:
                idle "ajtok/debporz.png"
                xalign 1.0
                yalign 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ritavalbeszed")
        if beszedanikakal == 0:
            imagebutton:
                idle "ajtok/debporz.png"
                xalign 0.8
                yalign 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("anikavalbeszed")
        if beszedjimkal == 0:
            imagebutton:
                idle "ajtok/debporz.png"
                xalign 0.5
                yalign 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("jimvalbeszed")
        if beszedjimkal == 1:
            if beszedkittykal == 0:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.5
                    yalign 0.6
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kittyvalbeszed")
        if beszedmarkkal == 1:
            if beszedritakal == 1:
                if beszedanikakal == 1:
                    if beszedjimkal == 1:
                        if beszedkittykal == 1:
                            imagebutton:
                                idle "ajtok/kijaratz.png"
                                xalign 0.17
                                yalign 0.32
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action Jump ("tanterembolki")
    if hanyadiknapvan == 7:
        imagebutton:
            idle "ajtok/debpor3z.png"
            xalign 1.0
            yalign 0.6
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("ritavalbeszed")
        imagebutton:
            idle "ajtok/debpor3z.png"
            xalign 0.8
            yalign 0.6
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("anikavalbeszed")
        imagebutton:
            idle "ajtok/debpor3z.png"
            xalign 0.62
            yalign 0.6
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("jimvalbeszed")
        if kittyparkotenged == False:
            imagebutton:
                idle "ajtok/debpor3z.png"
                xalign 0.48
                yalign 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kittyvalbeszed")
        imagebutton:
            idle "ajtok/kijaratz.png"
            xalign 0.17
            yalign 0.32
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("tanterembolki")
        if dagivalbeszeltel7resz < 2:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.05
                yalign 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("dagivalbeszed")
    if hanyadiknapvan == 8:
        imagebutton:
            idle "ajtok/kijaratz.png"
            xalign 0.17
            yalign 0.32
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("tanterembolki")
        if lizanakmegmutatadareceptet == True:
            if uditosmagamhozveni == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.6
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("naracslefel8resz")
    if hanyadiknapvan >= 9:
        imagebutton:
            idle "ajtok/kijaratz.png"
            xalign 0.17
            yalign 0.32
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("tanterembolki")
    if hanyadiknapvan == 10:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.22
            yalign 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("markvalbeszed")
    if hanyadiknapvan >= 11:
        if oroszkonyvnalad == 0:
            imagebutton:
                idle "ajtok/minuszz.png"
                xalign 0.0
                ypos 0.63
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("oroszkonyvfel")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xpos 0.0
            ypos 0.25
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("modernkepalkotastanteremben")
        imagebutton:
            idle "ajtok/minuszz.png"
            xpos 0.27
            ypos 0.27
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("kepegyepuletroltanteremben")
        imagebutton:
            idle "ajtok/minuszz.png"
            xpos 0.66
            ypos 0.27
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("kepmariakiralynoroltanteremben")
        imagebutton:
            idle "ajtok/minuszz.png"
            xpos 0.52
            ypos 0.27
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("vegzosoktanteremben")
        imagebutton:
            idle "ajtok/minuszz.png"
            xpos 0.35
            ypos 0.27
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("konyvajalotanteremben")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xpos 0.8
            ypos 0.25
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("ablaktanteremben")
    if hanyadiknapvan == 12:
        if jimholvan == "iskola":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.52
                yalign 0.9
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("jimvalbeszed12nap")
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.52
                yalign 0.7
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("jimvalbeszed12nap")
        if ritaholvan == "iskola":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.97
                yalign 0.58
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ritavalbeszed12nap")
        if kittyholvan == "iskola":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.62
                yalign 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kittyvalbeszed12nap")
        if puffyholvan == "iskola":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.07
                yalign 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("puffyvalbeszed12nap")
        if markholvan == "iskola":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.22
                yalign 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("markvalbeszed12nap")


screen anikahogyall:
    if anikahogyall == 1:
        timer 6.0 repeat True action SetVariable('anikahogyall', 2)
    if anikahogyall == 2:
        timer 6.0 repeat True action SetVariable('anikahogyall', 1)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
