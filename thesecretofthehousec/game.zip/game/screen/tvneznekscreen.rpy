screen kerdesnyaloka:
    frame:
        background ('fram')
        xpos 0.5
        ypos 0.45
        xalign 0.5
        textbutton "I eat the lollipop.":
            mouse "aktion"
            action Hide ('kerdesnyaloka'), Jump ("feredmegeszi3resz")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.5
        ypos 0.55
        xalign 0.5
        textbutton "I give the lollipop to Debra.":
            mouse "aktion"
            action Hide ('kerdesnyaloka'), Jump ("ferednemmegeszi3resz")
            text_style "fegeteszov"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
