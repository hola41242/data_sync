screen atjaro:
    if szobakipakolas == False:
        imagebutton:
            idle "ajtok/aszhaz.png"
            xalign 0.4
            yalign 0.54
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("atjaroszov3")
    if szobakipakolas == True:
        imagebutton:
            idle "ajtok/aszhaz.png"
            xalign 0.4
            yalign 0.54
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("nappali")

        if menyiharomgyokalat == 1:
            if szobakipakolas == True:
                if hanyadiknapvan == 1:
                    imagebutton:
                        idle "ajtok/ruhaz.png"
                        xalign 0.57
                        ypos 0.65
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('atjarokonyvszov', True)
        if menyiharomgyokalat >= 2:
            if szobakipakolas == True:
                if hanyadiknapvan == 1:
                    imagebutton:
                        idle "ajtok/ruhaz.png"
                        xalign 0.57
                        ypos 0.65
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('atjarokonyvszov2', True), SetVariable('menyiharomgyokalat', 3)
    if hanyadiknapvan == 2:
        if Tanulnimatematika == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.57
                ypos 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ferdtanuljon")
        if Tanulniepiteszet == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.57
                ypos 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ferdtanuljon")
        if Tanulnitortenelem == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.57
                ypos 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ferdtanuljon")
        if nemtanulhatsztobbet == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.57
                ypos 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action SetVariable('atjarokonyvszov', True)
    if hanyadiknapvan == 3:
        if isztaruhafel == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.12
                ypos 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("tisztaruhafel")
        if taskafel == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.25
                ypos 0.73
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("taskaazinvertoriba")
        if harmadikreszkonyha >= 4:
            if Tanulnimatematika3resz == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.57
                    ypos 0.65
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("ferdtanuljon")
            if Tanulniepiteszet3resz == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.57
                    ypos 0.65
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("ferdtanuljon")
            if Tanulnitortenelem3resz == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.57
                    ypos 0.65
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("ferdtanuljon")
            if nemtanulhatsztobbet3resz == True:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.57
                    ypos 0.65
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('atjarokonyvszov', True)
    if hanyadiknapvan == 4:
        if szenyeskimosvaahejen == True:
            if isztaruhafel == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.12
                    ypos 0.6
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("tisztaruhafel")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.57
                ypos 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action SetVariable('atjarokonyvszov', True)
        if taskafel == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.14
                ypos 0.83
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("taskaazinvertoriba")
    if hanyadiknapvan == 5:
        if kakitfeltakaritanikersz == False:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.35
                ypos 0.76
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump('kakittakarit')
        if kakitfeltakaritanikersz == True:
            if kakialatpisi == 1:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.35
                    ypos 0.76
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump('fifipisifeltakarit4')
        if taskafel == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.14
                ypos 0.83
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("taskaazinvertoriba")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.57
            ypos 0.65
            mouse "aktion"
            activate_sound "audio/click.wav"
            action SetVariable('atjarokonyvszov', True)
    if hanyadiknapvan == 6:
        if debraholcsinal == "atjaro":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/nszaballz.png"
                    xpos 0.63
                    ypos 0.3
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debraatjaro")
    if hanyadiknapvan == 10:
        if taskafel == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.14
                ypos 0.83
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("taskaazinvertoriba")
        if sirfestekeshezkell == True:
            if festekoldonalad == 0:
                imagebutton:
                    idle "ajtok/minuszz.png"
                    xpos 0.55
                    ypos 0.62
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("festekoldofel")
    if hanyadiknapvan == 11:
        if taskafel == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.14
                ypos 0.83
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("taskaazinvertoriba")
    if hanyadiknapvan == 12:
        if taskafel == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.14
                ypos 0.83
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("taskaazinvertoriba")
        if tanulhac12nap == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.57
                ypos 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ferdtanuljon")
        if kokonalad == 0:
            if boltbanemmehetek == True:
                if lizavalszexeltel == False:
                    imagebutton:
                        idle "ajtok/debpor2z.png"
                        xpos -0.05
                        ypos 0.5
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ('alszomegyet12napnem')
                if cilinekjelenteni == False:
                    imagebutton:
                        idle "ajtok/debpor2z.png"
                        xpos -0.05
                        ypos 0.5
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ('alszomegyet12napnem')
            if lizavalszexeltel == True:
                if cilinekjelenteni == True:
                    imagebutton:
                        idle "ajtok/debpor2z.png"
                        xpos -0.05
                        ypos 0.5
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ('alszomegyet12napigen')

    if szobakipakolas == True:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.68
            ypos 0.6
            mouse "aktion"
            activate_sound "audio/click.wav"
            action SetVariable('atjaroruhavszov', True)
        if hanyadiknapvan == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.76
                ypos 0.82
                mouse "aktion"
                activate_sound "audio/click.wav"
                action SetVariable('atjaroboritekszov', True)
        if hanyadiknapvan == 2:
            if boritekazinvertoriba == False:
                if boritekmizeria < 2:
                    imagebutton:
                        idle "invertori/semmi.png"
                        xalign 0.67
                        ypos 0.62
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        if dabraboritekotkaphat == True:
                            action Jump('boritekazinvertoriba')
                        if dabraboritekotkaphat == False:
                            action SetVariable('atjaroboritekszov', True)
            if szenyeskimosvaahejen == True:
                imagebutton:
                    idle "invertori/mitkeszitsenalapz.png"
                    xalign 0.61
                    ypos 0.68
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('atjaroruhav2szov', True)
    imagebutton:
        idle "ajtok/aszeaz.png"
        xalign 0.98
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("konyha")
    if agynemukaptal == True:
        if agynemuhejen == False:
            imagebutton:
                idle "ajtok/debpor2z.png"
                xpos -0.05
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('Beagyazas')
    if hanyadiknapvan == 2:
        if alvas == 0:
            imagebutton:
                idle "ajtok/debpor2z.png"
                xpos -0.05
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('alszomegyet')
    if viragokmegontozese == False:
        if locsolokannafel == True:
            if atjarovirag == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.53
                    ypos 0.55
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("locsolatjaro1")
    if viragokmegontozese == False:
        if locsolokannafel == True:
            if atjarovirag2 == False:
                imagebutton:
                    idle "ajtok/kijaratz.png"
                    xpos 0.78
                    ypos 0.72
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("locsolatjaro2")
    if viragokmegontozese == False:
        if locsolokannafel == True:
            if atjarovirag3 == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.56
                    ypos 0.55
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("locsolatjaro3")

screen kipakolandodoboz:
    imagebutton:
        idle "eszkozok/doboz.png"
        xalign 0.26
        yalign 0.8
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("atjaroszov2")
screen poszterekgomjai:
    zorder 100
    if poszterafalon1 == False:
        imagebutton:
            idle "poszterdoboz/poszterjobbz.png"
            xpos 0.0
            ypos 0.76
            mouse "aktion"
            activate_sound "audio/click.wav"
            action SetVariable('poszterafalon1', True)
    if poszterafalon2 == False:
        imagebutton:
            idle "poszterdoboz/poszterjobbz.png"
            xpos 0.04
            ypos 0.76
            mouse "aktion"
            activate_sound "audio/click.wav"
            action SetVariable('poszterafalon2', True)
    if poszterafalon3 == False:
        imagebutton:
            idle "poszterdoboz/poszterjobbz.png"
            xpos 0.08
            ypos 0.76
            mouse "aktion"
            activate_sound "audio/click.wav"
            action SetVariable('poszterafalon3', True)
    if poszterafalon1 == True:
        imagebutton:
            idle "poszterdoboz/fauna2falonz.png"
            xpos 0.225
            ypos 0.3
            mouse "aktion"
            activate_sound "audio/click.wav"
            action SetVariable('poszterafalon1', False)
    if poszterafalon2 == True:
        imagebutton:
            idle "poszterdoboz/faunafalonz.png"
            xpos 0.56
            ypos 0.159
            mouse "aktion"
            activate_sound "audio/click.wav"
            action SetVariable('poszterafalon2', False)
    if poszterafalon3 == True:
        imagebutton:
            idle "poszterdoboz/petykafalonz.png"
            xpos 0.08
            ypos 0.3
            mouse "aktion"
            activate_sound "audio/click.wav"
            action SetVariable('poszterafalon3', False)
screen poszterekkepei:
    if poszterafalon1 == False:
        imagemap:
            idle "poszterdoboz/poszterbal.png"
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        imagemap:
            idle "poszterdoboz/poszterkozep.png"
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        imagemap:
            idle "poszterdoboz/poszterjobb.png"
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        imagemap:
            idle "poszterdoboz/fauna2falon.png"
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        imagemap:
            idle "poszterdoboz/faunafalon.png"
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        imagemap:
            idle "poszterdoboz/petykafalon.png"
            xpos 0.08
            ypos 0.3
screen atjaroszov:
    vbox xalign 0.5 yalign 0.2:
        if atjarokonyvszov == True:
            text "{color=000000}My books. I don't need them right now.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('atjarokonyvszov', False)
        if atjarokonyvszov2 == True:
            text "{color=000000}N-th root of 3 is 1,73.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('atjarokonyvszov2', False)
        if atjaroruhavszov == True:
            text "{color=000000}All my clothes, which remain...":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('atjaroruhavszov', False)
        if atjaroruhav2szov == True:
            text "{color=000000}Clean dresses for tomorrow.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('atjaroruhav2szov', False)
        if atjaroboritekszov == True:
            if hanyadiknapvan == 1:
                text "{color=000000}If you are ready, open it my dear son!":
                    xalign 0.5
            if hanyadiknapvan == 2:
                text "{color=000000}The papers dad gave to me. I need to put these in a  safe place.":
                    xalign 0.5
            timer 3.0 repeat True action SetVariable('atjaroboritekszov', False)
screen fifiboritekpiszkal:
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.76
        ypos 0.82
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump('boritekelteszfifitol')
screen fifiboritekpiszkal:
    if boritekmizeria == 0:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.76
            ypos 0.82
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump('boritekelteszfifitol')
    if boritekmizeria == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.5
            ypos 0.66
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump('fififelvesz')
screen szennyesfoldon:
    if hanyadiknapvan == 2:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.235
            ypos 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump('szenyesfelvesz')
    if hanyadiknapvan == 3:
        if harmadikreszkonyha >= 5:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.235
                ypos 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump('szenyesfelvesz')
    if hanyadiknapvan == 4:
        if szenyeskimosva == False:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.235
                ypos 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump('szenyesfelvesz')
screen atjarosecial:
    imagebutton:
        idle "ajtok/aszhaz.png"
        xalign 0.4
        yalign 0.54
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("nappali")
screen kiverjemvagyne:
    if hanyadiknapvan >= 3:
        if magazinvetem == True:
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.35
                xalign 0.5
                textbutton "Watch the magazine and fap.":
                    mouse "aktion"
                    action Jump ("kiveri3pan")
                    text_style "fegeteszov"
    if lopotfotokat == True:
        frame:
            background ('fram')
            xpos 0.5
            ypos 0.45
            xalign 0.5
            textbutton "I watch Debra on the photo and fap.":
                mouse "aktion"
                action Jump ("kiveri2pan")
                text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.5
        ypos 0.55
        xalign 0.5
        has textbutton "I am tired. I sleep."
        mouse "aktion"
        if hanyadiknapvan == 2:
            action Jump ("alszik2nap")
        if hanyadiknapvan == 3:
            action Jump ("alszik3nap")
        if hanyadiknapvan == 8:
            action Hide ('kiverjemvagyne'), Hide ('atjaro'), Jump ("alszik8nap2")
        if hanyadiknapvan == 10:
            action Hide ('kiverjemvagyne'), Hide ('atjaro'), Jump ("alszik10nap")
        text_style "fegeteszov"
screen alvas:
    if alvasmasodikreszvege == 1:
        if lopotfotokat == True:
            imagebutton:
                idle "ajtok/debpor2z.png"
                xpos -0.05
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('alvaselotidontes')
        if magazinvetem == True:
            imagebutton:
                idle "ajtok/debpor2z.png"
                xpos -0.05
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('alvaselotidontes')
        if lopotfotokat == False:
            if magazinvetem == False:
                imagebutton:
                    idle "ajtok/debpor2z.png"
                    xpos -0.05
                    ypos 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if hanyadiknapvan == 2:
                        action Jump ('alszik2nap')
                    if hanyadiknapvan == 3:
                        action Jump ('alszik3nap')
                    if hanyadiknapvan == 4:
                        action Jump ('alszik4nap')
                    if hanyadiknapvan == 5:
                        action Jump ('alszik5nap')
                    if hanyadiknapvan == 6:
                        action Jump ('alszik6nap')
                    if hanyadiknapvan == 7:
                        action Jump ('alszik7nap')
                    if hanyadiknapvan == 8:
                        action Hide ('alvas'), Hide ('atjaro'), Jump ('alszik8nap2')
                    if hanyadiknapvan == 9:
                        action Hide ('alvas'), Hide ('atjaro'), Jump ('alszik9nap')
                    if hanyadiknapvan == 10:
                        action Hide ('alvas'), Hide ('atjaro'), Jump ('alszik8nap2')
                    if hanyadiknapvan == 11:
                        action Hide ('alvas'), Hide ('atjaro'), Jump ('alszik8nap2')
                    if hanyadiknapvan == 12:
                        action Hide ('alvas'), Hide ('atjaro'), Jump ('alszik8nap2')
                    if hanyadiknapvan == 13:
                        action Hide ('alvas'), Hide ('atjaro'), Jump ('alszik8nap2')
screen debrafotoi:
    imagebutton:
        idle "ajtok/ruhazz.png"
        xpos 0.39
        ypos 0.22
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump('debrafotokozelebrol2resz')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
