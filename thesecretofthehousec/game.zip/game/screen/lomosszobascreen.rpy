screen porszivotkutatt:
    frame:
        background ('fram')
        xpos 0.15
        ypos 0.9
        xalign 0.5
        textbutton "Stop searching.":
            mouse "aktion"
            action Jump ("porszivokutattabahagy")
            text_style "fegeteszov"

    timer 1.0 repeat True action If(fredkutatporszivoido <= 0,
    true=[SetVariable('porszivofelveni', porszivofelveni + 1),
    Hide('porszivotkutatt'),
    Jump('porszivokutattabahagy')],
    false=[SetVariable('fredkutatporszivoido', fredkutatporszivoido - 1),
    SetVariable('fredkutatporszivoelteltido', fredkutatporszivoelteltido + 1)])
    bar:
        left_bar "#f00"
        if fredkutatporszivoido <= 10:
            left_bar "#0ff"
        if fredkutatporszivoido <= 0:
            left_bar "#0f0"
        value StaticValue(fredkutatporszivoelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen gerebjetkeres:
    frame:
        background ('fram')
        xpos 0.15
        ypos 0.9
        xalign 0.5
        textbutton "Stop searching.":
            mouse "aktion"
            action Jump ("gerebjetkeresabahagy")
            text_style "fegeteszov"

    timer 1.0 repeat True action If(gerebjetkutatido <= 0,
    true=[SetVariable('gerebjenyel', gerebjenyel + 1),
    Hide('gerebjetkeres'),
    Jump('gerebjetkeresabahagy')],
    false=[SetVariable('gerebjetkutatido', gerebjetkutatido - 1),
    SetVariable('gerebjetkutatelteltido', gerebjetkutatelteltido + 1)])
    bar:
        left_bar "#f00"
        if gerebjetkutatido <= 10:
            left_bar "#0ff"
        if gerebjetkutatido <= 0:
            left_bar "#0f0"
        value StaticValue(gerebjetkutatelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen feleslegesenkeres6resz:
    frame:
        background ('fram')
        xpos 0.15
        ypos 0.9
        xalign 0.5
        textbutton "Stop searching.":
            mouse "aktion"
            action Jump ("feleslegesenkeres6reszabahagy")
            text_style "fegeteszov"

    timer 1.0 repeat True action If(feleslegesenkeres6reszido <= 0,
    true=[SetVariable('feleslegesenkeres6resz', True),
    Hide('feleslegesenkeres6resz'),
    Jump('feleslegesenkeres6reszabahagy')],
    false=[SetVariable('feleslegesenkeres6reszido', feleslegesenkeres6reszido - 1),
    SetVariable('feleslegesenkeres6reszelteltido', feleslegesenkeres6reszelteltido + 1)])
    bar:
        left_bar "#f00"
        if feleslegesenkeres6reszido <= 10:
            left_bar "#0ff"
        if feleslegesenkeres6reszido <= 0:
            left_bar "#0f0"
        value StaticValue(feleslegesenkeres6reszelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen metszoollo:
    timer 1.0 repeat True action If(metszoolloido <= 0,
    true=[SetVariable('metszoollo', metszoollo + 1),
    SetVariable('debrakertjekivagnivalobokorenged', True),
    Hide('metszoollo'),
    Jump('mamakerdeztoled7nap')],
    false=[SetVariable('metszoolloido', metszoolloido - 1),
    SetVariable('metszoolloelteltido', metszoolloelteltido + 1)])
    bar:
        left_bar "#f00"
        if metszoollo <= 10:
            left_bar "#0ff"
        if metszoollo <= 0:
            left_bar "#0f0"
        value StaticValue(metszoolloelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen madzagkereses:
    timer 1.0 repeat True action If(madzagido <= 0,
    true=[Hide('madzagkereses'),
    Jump('nemtalalmadzagot')],
    false=[SetVariable('madzagido', madzagido - 1),
    SetVariable('madzagelteltido', madzagelteltido + 1)])
    bar:
        left_bar "#f00"
        if madzagido <= 5:
            left_bar "#0ff"
        if madzagido <= 0:
            left_bar "#0f0"
        value StaticValue(madzagelteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen gerebjekivetel:
    timer 1.0 repeat True action If(gerebjekiveszido <= 0,
    true=[SetVariable('gerebjenalad', gerebjenalad + 1),
    Hide('gerebjekivetel')],
    false=[SetVariable('gerebjekiveszido', gerebjekiveszido - 1),
    SetVariable('gerebjekiveszelteltido', gerebjekiveszelteltido + 1)])
    bar:
        left_bar "#f00"
        if gerebjekiveszido <= 2:
            left_bar "#0ff"
        if gerebjekiveszido <= 0:
            left_bar "#0f0"
        value StaticValue(gerebjekiveszelteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen metszoollokivetel:
    timer 1.0 repeat True action If(metszoollokiveszido <= 0,
    true=[SetVariable('metszoollonalad', metszoollonalad + 1),
    Hide('metszoollokivetel')],
    false=[SetVariable('metszoollokiveszido', metszoollokiveszido - 1),
    SetVariable('metszoollokiveszelteltido', metszoollokiveszelteltido + 1)])
    bar:
        left_bar "#f00"
        if metszoollokiveszido <= 2:
            left_bar "#0ff"
        if metszoollokiveszido <= 0:
            left_bar "#0f0"
        value StaticValue(metszoollokiveszelteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen izzotkivetel:
    timer 1.0 repeat True action If(izzotkiveszido <= 0,
    true=[SetVariable('izzoknalad', izzoknalad + 1),
    Hide('izzotkivetel')],
    false=[SetVariable('izzotkiveszido', izzotkiveszido - 1),
    SetVariable('izzotkiveszelteltido', izzotkiveszelteltido + 1)])
    bar:
        left_bar "#f00"
        if izzotkiveszido <= 2:
            left_bar "#0ff"
        if izzotkiveszido <= 0:
            left_bar "#0f0"
        value StaticValue(izzotkiveszelteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
