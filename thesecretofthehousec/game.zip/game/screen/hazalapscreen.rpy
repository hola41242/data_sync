screen nappali:
    imagebutton:
        idle "ajtok/nszaballz.png"
        xalign 0.0
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("furdo")
    imagebutton:
        idle "ajtok/nszajobbz.png"
        xalign 0.575
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("fojasoball")
    imagebutton:
        idle "ajtok/nszakozzepz.png"
        xalign 0.46
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("atjaro")
    if hanyadiknapvan == 1:
        if viragokmegontozese == False:
            if locsolokannafel == True:
                if napalivirag == False:
                    imagebutton:
                        idle "ajtok/ruhaz.png"
                        xalign 0.22
                        ypos 0.26
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("locsolnapali1")
        if viragokmegontozese == False:
            if locsolokannafel == True:
                if napalivirag2 == False:
                    imagebutton:
                        idle "ajtok/debporz.png"
                        xpos 0.92
                        ypos 0.18
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("locsolnapali2")
        if agynemukaptal == True:
            if parnanalad == False:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xpos -0.09
                    ypos 0.7
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('parnanalad', True)
        if furdo == True:
            if szendvicsmilesz == False:
                if szendvicsmilesznemetted == False:
                    imagebutton:
                        idle "ajtok/ruhaz.png"
                        xalign 0.385
                        ypos 0.53
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("szedvicsel")
            if szendvicsmilesznemetted == True:
                if szendvicsinvertoriba == False:
                    imagebutton:
                        idle "ajtok/ruhaz.png"
                        xalign 0.385
                        ypos 0.53
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("szedvicsinvertoriba")
    if hanyadiknapvan == 2:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.28
            ypos 0.28
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("mamavalbeszel")
        if fifitfelvetem == True:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.28
                ypos 0.28
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("fifitmamanak")
    if hanyadiknapvan == 3:
        if mamanemkapotkavet == False:
            if kaveazasztalrolinvertoriba == False:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.33
                    ypos 0.3
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mamavalbeszel")
        if mamanemkapotkavet == False:
            if kaveazasztalrolinvertoriba == True:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.33
                    ypos 0.3
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mamavalbeszel")
        if mamanemkapotkavet == True:
            if beszeljaszomszedokkal < 2:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.28
                    ypos 0.28
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mamavalbeszel")
        if regell3resz == True:
            if isztaruhafel == 2:
                if taskafel == 2:
                    if harmadikreszkonyha == 2:
                        imagebutton:
                            idle "ajtok/nszajobbz.png"
                            xalign 0.575
                            ypos 0.18
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("mamaelkoszon3reszregel")
    if hanyadiknapvan == 4:
        if mamanapalibanregel4resz == True:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.33
                ypos 0.3
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mamavalbeszel")
        if debrareggel4resznapaliben == True:
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.65
                ypos 0.25
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debraanapaliolvas")
        if dagitmegharaptafifi == 1:
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.6
                ypos 0.25
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("dagivalbeszelszanapaliban")
    if hanyadiknapvan >= 3:
        if lopotfotokat == False:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.38
                ypos 0.68
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump('lopfotott')
    if hanyadiknapvan == 6:
        if mamaholvan == "nappali":
            imagebutton:
                idle "ajtok/nszaballz.png"
                xpos 0.65
                ypos 0.18
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mamabeszelni6resznapali")
        if debraholcsinal == "napalikusztum":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.6
                ypos 0.2
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debrabeszelni6resznapali")
    if hanyadiknapvan == 8:
        if mamaholvan == "napaliban":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/debporz.png"
                    xpos 0.6
                    ypos 0.2
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mamabeszelni8resznapali")
    if hanyadiknapvan == 9:
        if neztvt9resz == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.84
                ypos 0.42
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ferdtvnezzen")
    if hanyadiknapvan == 12:
        if debraholcsinal == "napaliban3":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.7
                ypos 0.2
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debrafeladatotad12nap")
        if mamakenocsenalad == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.36
                ypos 0.54
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mamakenocsefel")
        if debraholcsinal == "taviranyitotkeres":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.08
                ypos 0.2
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debrataviranyitotkeres12nap")
        if mamaholvan == "mamakanapenanapaliban":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.2
                ypos 0.25
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mama12napbeszel")


screen lopolfenykep:
    frame:
        background ('fram')
        xpos 0.5
        ypos 0.45
        xalign 0.5
        textbutton "I steal some photos of Debra.":
            mouse "aktion"
            action Jump ("lopfotott")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.5
        ypos 0.55
        xalign 0.5
        textbutton "I do not steal any photo of Debra.":
            mouse "aktion"
            action Jump ("nemlopfotott")
            text_style "fegeteszov"
screen dontes12napdebrarol:
    if debraseggenelbeszeltem == False:
        frame:
            background ('fram')
            xpos 0.8
            ypos 0.65
            xalign 0.5
            textbutton "Talk":
                mouse "aktion"
                action Hide ('dontes12napdebrarol'), Jump ("beszelekdebraval12nap")
                text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.8
        ypos 0.75
        xalign 0.5
        textbutton "Touch her ass":
            mouse "aktion"
            action Hide ('dontes12napdebrarol'), Jump ("seggetsimogatok12nap")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.8
        ypos 0.85
        xalign 0.5
        textbutton "Push the penis to her ass":
            mouse "aktion"
            action Hide ('dontes12napdebrarol'), Jump ("dorgolok12nap")
            text_style "fegeteszov"



screen debracicibaszi11nap:
    if debracicibaszi11naperoseg == "vissza3":
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.9
            xalign 0.5
            textbutton "Next":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napgyengen")
                text_style "fegeteszov"
    if debracicibaszi11naperoseg == "vissza2":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napvissza3")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.9
            xalign 0.5
            textbutton "Next":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napgyengen")
                text_style "fegeteszov"
    if debracicibaszi11naperoseg == "vissza":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napvissza2")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.9
            xalign 0.5
            textbutton "Next":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napgyengen")
                text_style "fegeteszov"
    if debracicibaszi11nap == "sehogy":
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.9
            xalign 0.5
            textbutton "Hard":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11naperosen")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Gentle":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napgyengen")
                text_style "fegeteszov"
    if debracicibaszi11naperoseg == "lassu":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napvissza")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.9
            xalign 0.5
            textbutton "Hard":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11naperosen")
                text_style "fegeteszov"
    if debracicibaszi11naperoseg == "gyors":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Gentle":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napgyengen")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.9
            xalign 0.5
            textbutton "Harder":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napmegerosebben")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.8
            xalign 0.5
            textbutton "Cum":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napjelenetvege")
                text_style "fegeteszov"
    if debracicibaszi11naperoseg == "gyorsabb":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Gentle":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napgyengen")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.9
            xalign 0.5
            textbutton "Hard":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11naperosen")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.8
            xalign 0.5
            textbutton "Cum":
                mouse "aktion"
                action Hide ('debracicibaszi11nap'), Jump ("debracicibaszi11napjelenetvege")
                text_style "fegeteszov"
screen debra12napszexjel4sebesegvalt:
    if debraszex12napjel4tovabb == 1:
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.9
            xalign 0.5
            textbutton "Next":
                mouse "aktion"
                action Hide ('debra12napszexjel4sebesegvalt'), Jump ("debra12napszexjel5")
                text_style "fegeteszov"
    if debraszex12napjel4holvagy1 == 0:
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.8
            xalign 0.5
            textbutton "Slow":
                mouse "aktion"
                action Hide ('debra12napszexjel4sebesegvalt'), Jump ("debra12napszexjel4lassu")
                text_style "fegeteszov"
    if debraszex12napjel4holvagy2 == 0:
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.7
            xalign 0.5
            textbutton "Fast":
                mouse "aktion"
                action Hide ('debra12napszexjel4sebesegvalt'), Jump ("debra12napszexjel4gyors")
                text_style "fegeteszov"
    if debraszex12napjel4holvagy3 == 0:
        frame:
            background ('fram')
            xpos 0.925
            ypos 0.6
            xalign 0.5
            textbutton "Faster":
                mouse "aktion"
                action Hide ('debra12napszexjel4sebesegvalt'), Jump ("debra12napszexjel4gyorsabb")
                text_style "fegeteszov"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
