screen konyha:

    imagebutton:
        idle "nyilakonyha.png"
        xalign 0.025
        yalign 0.975
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("atjaro")
    imagebutton:
        idle "ajtok/debporz.png"
        xalign 0.0
        yalign 0.5
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("huto")
    if mamauditotker == True:
        if mamauditotkap == False:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.24
                yalign 0.43
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("poharudito")
    if hanyadiknapvan == 2:
        if vanszedvicsed == False:
            if mamakeresei < 5:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.0
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("szedvicskeszites")
        if debraholcsinal == "konyha2":
            imagebutton:
                idle "ajtok/debporz.png"
                xalign 0.0
                yalign 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("raesosjelenet2nap")
        if mamakeresei == 5:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.24
                yalign 0.43
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("poharudito")
        if dolgozolmosogatas == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.32
                yalign 0.43
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mosogas")
        if tvnapaliban == True:
            if tvtaviranyitonalad == False:
                imagebutton:
                    idle "ajtok/minuszz.png"
                    xpos 0.87
                    ypos 0.56
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("tvtaviranyitofel")
    if hanyadiknapvan == 3:
        if uditosmagamhozveni == 0:
            imagebutton:
                idle "ajtok/debporz.png"
                xalign 0.0
                yalign 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("uditomagamhozvenni")
        if harmadikreszkonyha < 4:
            if vanszedvicsed2 <=1:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.0
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("szedvicskeszites")
        if regell3resz == True:
            if kaveamamanakkesz == False:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.48
                    yalign 0.48
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debraval3reszkonyhareggel")
        if kaveamamanakkesz == False:
            imagebutton:
                idle "ajtok/minuszz.png"
                xalign 0.99
                yalign 0.35
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kavetkeszit")
        if megkaptadavizeskancsot == True:
            if vizeskancsovizes == False:
                if kaveamamanakkesz == False:
                    imagebutton:
                        idle "ajtok/ruhazz.png"
                        xalign 0.3
                        yalign 0.35
                        mouse "aktion"
                        activate_sound "audio/viz13.wav"
                        action SetVariable('vizeskancsovizes', True)
        if lefottaviz == True:
            if kutyatalakonyhaban == False:
                if fifieniker == True:
                    imagebutton:
                        idle "ajtok/ruhaz.png"
                        xalign 0.83
                        yalign 1.0
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("kutyatalfelvesz")
        if kutyatalakonyhaban == True:
            if kutyatalaltelenalad == False:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.0
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kutyakajatkiveszed")
        if kaveamamanakkesz == True:
            if kaveazasztalrolinvertoriba == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.96
                    yalign 0.47
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kaveazasztalrolinvertoriba")
        if dolgozolmosogatas == 1:
            if harmadikreszkonyha >= 6:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.32
                    yalign 0.43
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mosogas")
        if dolgozolmosogatas == 1:
            if harmadikreszkonyha <= 5:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.32
                    yalign 0.43
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mosogas")
        if beszeljaszomszedokkal == 2:
            if tejetvetem == True:
                if tejetlerektam == False:
                    imagebutton:
                        idle "ajtok/kijaratz.png"
                        xpos 0.81
                        ypos 0.22
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("debrakonyhabanfoz")
    if hanyadiknapvan == 4:
        if regell4resz == True:
            if uditosmagamhozveni == 0:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.0
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("uditomagamhozvenni")
            if nincskenyeraszedvicshez == True:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.0
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("nincskenyer")
            if nincskenyeraszedvicshez == False:
                if vanszedvicsed2 <= 1:
                    imagebutton:
                        idle "ajtok/debporz.png"
                        xalign 0.0
                        yalign 0.5
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("szedvicskeszites")
                if mamaszedvicsetker == True:
                    if mamaszedvicsetker4resz == False:
                        imagebutton:
                            idle "ajtok/debporz.png"
                            xalign 0.0
                            yalign 0.5
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("szedvicskeszites")
            if kutyatalfojasojobb == False:
                if kutyatapotkernidebratol == False:
                    imagebutton:
                        idle "ajtok/debporz.png"
                        xalign 0.0
                        yalign 0.5
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("kutyakajatkiveszed")
            if mamakonyhabanregel4resz == False:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.86
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mamavalbeszelniakonyhaban")
            if kaveamamanakkesz == False:
                imagebutton:
                    idle "ajtok/minuszz.png"
                    xalign 0.99
                    yalign 0.35
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kavetkeszit")
            if megkaptadavizeskancsot == True:
                if vizeskancsovizes == False:
                    if kaveamamanakkesz == False:
                        imagebutton:
                            idle "ajtok/ruhazz.png"
                            xalign 0.3
                            yalign 0.35
                            mouse "aktion"
                            activate_sound "audio/viz13.wav"
                            action SetVariable('vizeskancsovizes', True)
            if kutyatalaltelenalad == True:
                if fifienikap == False:
                    imagebutton:
                        idle "ajtok/ruhaz.png"
                        xalign 0.35
                        yalign 0.8
                        mouse "aktion"
                        activate_sound "audio/viz13.wav"
                        action Jump ('kutyatalfifinek')
    if hanyadiknapvan == 5:
        if zsacskonalad == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.37
                yalign 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("zsacsitfelvesz")
        if kakitfeltakaritanikersz == True:
            if dolgozolmosogatas <= 1:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.32
                    yalign 0.43
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mosogas")
        if dolgozolmosogatas == 2:
            if szivacskoszoslett > 0:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.32
                    yalign 0.43
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kimosniaszivacsot")
        if szedvisz1 == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.58
                ypos 0.48
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szedvisz1fel")
        if szedvisz2 == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.52
                ypos 0.47
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szedvisz2fel")
        if uditosmagamhozveni == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.65
                ypos 0.38
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("teremkola3fel")
    if hanyadiknapvan == 6:
        if debrafulbevalotmegkeresni1 == 1:
            if mamanyaklanc == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.43
                    ypos 0.85
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("keresztnyaklancfel")
        if regell6resz == True:
            if mamaholvan == "Konyha":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.76
                    ypos 0.2
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("beszedmamavalkonyhaban6resz")
        if debraholcsinal == "konyhatorol":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.6
                    ypos 0.25
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakanyhatorolget")
    if hanyadiknapvan >= 7:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.37
            yalign 0.6
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("mosogatoalatireszkonyha")
        if szenyesmizeria == 0:
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.14
                ypos 0.16
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("beszedmamavalkonyhaban7resz")
    if hanyadiknapvan == 8:
        if debraholcsinal == "konyhatorol":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.6
                    ypos 0.25
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakanyhatorolget")
        if mozsarazasztalon == 1:
            imagebutton:
                idle "invertori/semmi.png"
                xpos 0.53
                ypos 0.43
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mozsarhasznal")
    if hanyadiknapvan == 9:
        if adriananakvizkell == True:
            if poharnalad2 == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.24
                    yalign 0.43
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("poharfel")
            if poharnalad2 == 1:
                if poharbanban == "semmi":
                    imagebutton:
                        idle "ajtok/ruhazz.png"
                        xalign 0.32
                        yalign 0.43
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("vizapoharba")
        if kutyatalatfelveheted == True:
            if kutyatalakonyhaban == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.83
                    yalign 1.0
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kutyatalfelvesz")
        if kutyatalakonyhaban == True:
            if vetelkiamacskanakkajatahutobol == 0:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.0
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kutyakajatkiveszed")
        if tejnalad == 0:
            if macskanakkinaltadakutyakajat == True:
                if vetelkiamacskanakkajatahutobol == 1:
                    imagebutton:
                        idle "ajtok/debporz.png"
                        xalign 0.0
                        yalign 0.5
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("kutyakajatkiveszed")
        if szedvicsnalad == 0:
            if beszeltelmredwardssal == 2:
                imagebutton:
                    idle "ajtok/debporz.png"
                    xalign 0.0
                    yalign 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("szedvicskeszites")
    if hanyadiknapvan == 10:
        if szedvisz1 == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.58
                ypos 0.48
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szedvisz1fel")
        if szedvisz2 == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.52
                ypos 0.47
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szedvisz2fel")
        if uditosmagamhozveni == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.65
                ypos 0.38
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("teremkola3fel")
    if hanyadiknapvan == 11:
        if szedvisz1 == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.58
                ypos 0.48
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szedvisz1fel")
        if szedvisz2 == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.52
                ypos 0.47
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szedvisz2fel")
        if uditosmagamhozveni == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.65
                ypos 0.38
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("teremkola3fel")
    if hanyadiknapvan == 12:
        if szedvisz1 == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.58
                ypos 0.48
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szedvisz1fel")
        if szedvisz2 == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.52
                ypos 0.47
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("szedvisz2fel")
        if uditosmagamhozveni == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.65
                ypos 0.38
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("teremkola3fel")
        if debraholcsinal == "konyhatorol":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.6
                    ypos 0.25
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakanyhatorolget")

    if mamaholvan == "konyha":
        imagebutton:
            idle "ajtok/debporz.png"
            xpos 0.16
            ypos 0.16
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("beszedmamavalkonyhaban8resz")
    if debraholcsinal == "foz":
        imagebutton:
            idle "ajtok/kijaratz.png"
            xpos 0.81
            ypos 0.22
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("debrakonyhabanfoz2")



screen udito:
    frame:
        background ('fram')
        xpos 0.1
        ypos 0.2
        xalign 0.5
        textbutton "Apple":
            mouse "aktion"
            action Jump ("uditokesz2")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.1
        ypos 0.3
        xalign 0.5
        textbutton "Elderberry":
            mouse "aktion"
            action Jump ("uditokesz2")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.1
        ypos 0.4
        xalign 0.5
        textbutton "Peach":
            mouse "aktion"
            action Jump ("uditokesz2")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.1
        ypos 0.5
        xalign 0.5
        textbutton "Grape":
            mouse "aktion"
            action Jump ("uditokesz2")
            text_style "fegeteszov"
screen receptelkeszitese:
    timer 1.0 repeat True action If(receptkeszulido <= 0,
    true=[SetVariable('mozsarnalad', mozsarnalad + 1),
    Hide('receptelkeszitese')],
    false=[SetVariable('receptkeszulido', receptkeszulido - 1),
    SetVariable('receptkeszulelteltido', receptkeszulelteltido + 1)])
    bar:
        left_bar "#f00"
        if receptkeszulido <= 10:
            left_bar "#0ff"
        if receptkeszulido <= 0:
            left_bar "#0f0"
        value StaticValue(receptkeszulelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
