screen fojasoball:
    imagebutton:
        idle "ajtok/feaz.png"
        xalign 0.1
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szuloszoba")
    imagebutton:
        idle "ajtok/fhaz.png"
        xalign 0.45
        yalign 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("nappali")
    imagebutton:
        idle "ajtok/fliftz.png"
        xalign 0.94
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("nagyiszoba")
    imagebutton:
        idle "nyilafojason.png"
        xalign 0.55
        yalign 0.98
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("fojasojobb")

    if viragokmegontozese == False:
        if locsolokannafel == True:
            if fojasoballvirag == False:
                imagebutton:
                    idle "ajtok/kijaratz.png"
                    xpos 0.365
                    ypos 0.67
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("locsolfojball")
    if hanyadiknapvan == 4:
        if debraholcsinal == "fojasoballpisi":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.55
                yalign 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('debrapisittorol')
        if debratolelsosegej == 1:
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.58
                ypos 0.25
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debraablakotpucolballoldalt")
    if hanyadiknapvan == 6:
        if debrafulbevalotmegkeresni2 == 1:
            if debrafulbevalo2 == 0:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.58
                    ypos 0.65
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("anyakereszt2fel")
        if mamaholvan == "fojasoball":
            if csinalszvalamit == "semit":
                imagebutton:
                    idle "ajtok/nszaballz.png"
                    xpos 0.65
                    ypos 0.27
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mamafojasoball")
        if debraholcsinal == "ablakotpucolballfojason":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.58
                ypos 0.25
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debraablakotpucolballoldalt")
            imagebutton:
                idle "ajtok/fhaz.png"
                xalign 0.45
                yalign 0.4
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debraablakotpucolballoldalt")
    if hanyadiknapvan == 7:
        if szenyesmizeria == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.58
                ypos 0.65
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("balfojasoszennyesfel")
    if hanyadiknapvan == 9:
        if fogjhalat == 1:
            if ruhaszalitonalad == 0:
                if ruhakosaratfelveheted == True:
                    imagebutton:
                        idle "ajtok/ruhazz.png"
                        xpos 0.58
                        ypos 0.65
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("balfojasoszennyesfel9resz")
    if hanyadiknapvan == 10:
        if debraholcsinal == "ablakotpucolballfojason":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.58
                ypos 0.25
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debraablakotpucolballoldalt")

screen fredkutatszennyes:
    frame:
        background ('fram')
        xpos 0.15
        ypos 0.9
        xalign 0.5
        textbutton "Stop searching.":
            mouse "aktion"
            action Jump ("anyakereszt2abahagy")
            text_style "fegeteszov"

    timer 1.0 repeat True action If(fredkutatszennyesido <= 0,
    true=[SetVariable('debrafulbevalo2', debrafulbevalo2 + 1),
    Hide('fredkutatszennyes'),
    Jump('anyakereszt2abahagy')],
    false=[SetVariable('fredkutatszennyesido', fredkutatszennyesido - 1),
    SetVariable('fredkutatszennyeselteltido', fredkutatszennyeselteltido + 1)])
    bar:
        left_bar "#f00"
        if fredkutatszennyesido <= 10:
            left_bar "#0ff"
        if fredkutatszennyesido <= 0:
            left_bar "#0f0"
        value StaticValue(fredkutatszennyeselteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
