screen svetlenaback:
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Hide ('svetlenaback'), Jump ("svetlanaki")
            text_style "fegeteszov"
    imagebutton:
        idle "ajtok/debporz.png"
        xalign 0.75
        yalign 0.6
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Hide ('svetlenaback'), Jump ("svetlanavalbeszed")

    if hanyadiknapvan == 5:
        if svetlananakatalpenzt < 250:
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.3
                xalign 0.5
                textbutton "I am searching for{p}a lame guy.":
                    mouse "aktion"
                    action Hide ('svetlenaback'), Jump ('svetlanabeszedboltnalsantarol')
                    text_style "fegeteszov"
        if koldussalbeszeltel >= 1:
            if kolduskulacsa == 0:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.4
                    xalign 0.5
                    textbutton "I searched for Fodo’s{p}brandy bottle.":
                        mouse "aktion"
                        action Hide ('svetlenaback'), Jump ('svetlanabeszedboltnalkulacsrol')
                        text_style "fegeteszov"
        if lizagyurulyesvetlanatol >= 4:
            if lizagyurulyesvetlanatol < 6:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.5
                    xalign 0.5
                    textbutton "Exchange: The lamp for{p}the brandy bottle.":
                        mouse "aktion"
                        action Hide ('svetlenaback'), Jump ('svetlanabeszedboltnallampacsere')
                        text_style "fegeteszov"
        if lizagyurulye == 1:
            if lizagyurulyesvetlanatol == 0:
                if koldussalbeszeltel == 0:
                    frame:
                        background ('fram')
                        xpos 0.5
                        ypos 0.6
                        xalign 0.5
                        textbutton "Did you find a{p}wedding ring?":
                            mouse "aktion"
                            action Hide ('svetlenaback'), Jump ('svetlanabeszedboltnalgyururol')
                            text_style "fegeteszov"
    if hanyadiknapvan == 6:
        if gerebjekell == 1:
            if svetlanagerebjekerdes == False:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.4
                    xalign 0.5
                    textbutton "Can you sell{p}me a rake?":
                        mouse "aktion"
                        action Hide ('svetlenaback'), Jump ('svetlanabeszedboltnalgerebje')
                        text_style "fegeteszov"
        if lizakertjemadarhaza == 2:
            if csavarhuzo6resz == 0:
                if kerdeztedabarkacsboltostol6resz == True:
                    frame:
                        background ('fram')
                        xpos 0.5
                        ypos 0.4
                        xalign 0.5
                        textbutton "Do you have{p}a screwdriver?":
                            mouse "aktion"
                            action Hide ('svetlenaback'), Jump ('svetlanabeszedboltnalcsavarhuzo')
                            text_style "fegeteszov"
    if hanyadiknapvan == 7:
        if vaszon2 == 0:
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.4
                xalign 0.5
                textbutton "Do you have any tools{p} to repair a sunbed?":
                    mouse "aktion"
                    action Hide ('svetlenaback'), Jump ('svetlanabeszedboltnalnapozo')
                    text_style "fegeteszov"
        if mamanyaklanc == 3:
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.4
                xalign 0.5
                has textbutton "Give me back the necklace!"
                mouse "aktion"
                text_style "fegeteszov"
                if svetlanaermeje <= 1:
                    action Hide ('svetlenaback'), Jump ('megkerdezedanyaklancot')


screen ajalatoksvetlananak:
    if svetlananakatalpenzt > 1:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide('ajalatoksvetlananak'), Jump ("svetlanaki")
                text_style "fegeteszov"
    if hanyadiknapvan == 5:
        if svetlananakatalpenzt < 250:
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.3
                xalign 0.5
                textbutton "1. offer: 50 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 50),SetVariable('svetlananakatalpenzt', svetlananakatalpenzt + 50), Hide ('ajalatoksvetlananak'), Jump ('ajalat1resz5')
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.4
                xalign 0.5
                textbutton "1 offer: 250 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 250),SetVariable('svetlananakatalpenzt', svetlananakatalpenzt + 250), Hide ('ajalatoksvetlananak'), Jump ('ajalat2resz5')
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.5
                xalign 0.5
                textbutton "1 offer: 500 Ft":
                    mouse "aktion"
                    action SetVariable('penz', penz - 500),SetVariable('svetlananakatalpenzt', svetlananakatalpenzt + 500), Hide ('ajalatoksvetlananak'), Jump ('ajalat3resz5')
                    text_style "fegeteszov"
        if svetlananakatalpenzt >= 250:
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.3
                xalign 0.5
                textbutton "Answer like a bastard.":
                    mouse "aktion"
                    action Hide ('ajalatoksvetlananak'), Jump ('bunkovalaszsvetlananak')
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.4
                xalign 0.5
                textbutton "Answer nice.":
                    mouse "aktion"
                    action Hide ('ajalatoksvetlananak'), Jump ('kedvesvalaszsvetlananak')
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.5
                ypos 0.5
                xalign 0.5
                textbutton "Here is 250 Ft Extra.":
                    mouse "aktion"
                    action SetVariable('penz', penz - 250),SetVariable('svetlananakatalpenzt', svetlananakatalpenzt + 250),Hide ('ajalatoksvetlananak'), Jump ('kedves250valaszsvetlananak')
                    text_style "fegeteszov"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
