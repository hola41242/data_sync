screen nyomortanya:
    if nyomortanyabago7 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.03
            yalign 0.96
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('nyomortanyacigeretacik')
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Hide ('nyomortanya'), Jump ("terkep")
            text_style "fegeteszov"
    if editholvan == "nyomortanya":
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.25
            yalign 0.38
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('edittelbeszelninyomortanyan')

    if nyomortanyabago1 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.1
            yalign 0.8
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('nyomortanyacigeretacikeshamutarto')
    if nyomortanyabago2 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.8
            yalign 0.97
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('nyomortanyacigeretacik')
    if nyomortanyabago3 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 1.0
            yalign 0.85
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('nyomortanyacigeretacik')
    if nyomortanyabago4 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.52
            yalign 0.98
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('nyomortanyacigeretacik')
    if nyomortanyabago5 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.25
            yalign 0.97
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('nyomortanyacigeretacik')
    if nyomortanyabago6 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.0
            yalign 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('nyomortanyacigeretacik')
    if nyomortanyakoszosruhanalad == 0:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.65
            yalign 0.4
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('boriszruhajatfel')
    if nyomortanyakoszosruhanalad == 1:
        if nyomortanyadoboz3nalad == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.65
                yalign 0.4
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('doboztmagadhozvenni3')
    if nyomortanyadoboz3nalad >= 1:
        if nyomortanyadoboz2nalad == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.65
                yalign 0.7
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('doboztmagadhozvenni2')
    if nyomortanyadoboz2nalad >= 1:
        if nyomortanyadoboz1nalad == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.65
                yalign 0.9
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ('doboztmagadhozvenni1')
    if boboholvan == "nyomortanya":
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.42
            yalign 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('bobovalbeszelnianyomortanyan')
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.42
            yalign 0.83
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ('bobovalbeszelnianyomortanyan')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
