screen svetlanahaza:
    imagebutton:
        idle "ajtok/debporz.png"
        xalign 0.43
        yalign 0.37
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("terkep")
    imagebutton:
        idle "ajtok/debporz.png"
        xalign 0.6
        yalign 0.37
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("terkep")
    imagebutton:
        idle "ajtok/ajto1z.png"
        xalign 0.84
        yalign 0.37
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanajoboldaliajtaja")
    imagebutton:
        idle "ajtok/ajto1z.png"
        xalign 0.175
        yalign 0.37
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanabaloldaliajtaja")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.03
        yalign 0.9
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanaszekreny")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 1.0
        yalign 0.9
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanakanape")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.0
        yalign 0.45
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanakep")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.0
        yalign 0.3
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanakep")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 1.0
        yalign 0.45
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanakep")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 1.0
        yalign 0.45
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanakep")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 1.0
        yalign 0.3
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("szetlanakep")
    if almaktalban == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.0
            yalign 0.78
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("mualmaksvetlana")
    if borisznaploja == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.0
            yalign 0.88
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("naploborisz")
    if fogasallorajtaruha == 1:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.75
            yalign 0.3
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("kogassvetlana")
    if szakadtmedvekulcsa == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.12
            yalign 0.9
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("szakatmedvesvetlana")
    if boriszfotokeretben == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.08
            yalign 0.7
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("boriszkepkerete")
    if svetlanaholvan == "svetlanaatjarojaban":
        imagebutton:
            idle "ajtok/debporz.png"
            xalign 0.25
            yalign 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("svetlanavalbeszelni11napatjarojaban")
    if svetlanaholvan == "szetlanaakanapen":
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            yalign 0.58
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("svetlanavalbeszelni11napatjarojabanulve")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 1.0
            yalign 0.78
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("svetlanavalbeszelni11napatjarojabanulve")
screen basziksvetlana11nap:
    if basziksvetlana11naphogyan == "sehogy":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Gentle":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napgyenge")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.8
            xalign 0.5
            textbutton "Harder":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11naperos")
                text_style "fegeteszov"
    if basziksvetlana11naphogyan == "gyengen":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Look from down":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napalulrol")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.8
            xalign 0.5
            textbutton "Harder":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11naperos")
                text_style "fegeteszov"
    if basziksvetlana11naphogyan == "erosen":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Gentle":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napgyenge")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.8
            xalign 0.5
            textbutton "Another angle":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napmasigszog")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.7
            xalign 0.5
            textbutton "Look from down":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napalulrol")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.6
            xalign 0.5
            textbutton "Story":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napvege")
                text_style "fegeteszov"
    if basziksvetlana11naphogyan == "masiksog2":
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Gentle":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napgyenge")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.8
            xalign 0.5
            textbutton "Closer":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11naperos")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.7
            xalign 0.5
            textbutton "Look from down":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napalulrol")
                text_style "fegeteszov"
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.6
            xalign 0.5
            textbutton "Story":
                mouse "aktion"
                action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napvege")
                text_style "fegeteszov"
    if basziksvetlana11naphogyan == "alulrol":
        if basziksvetlana11napsebeseg == "gyenge":
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.9
                xalign 0.5
                textbutton "Another angle":
                    mouse "aktion"
                    action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napgyenge")
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.8
                xalign 0.5
                textbutton "Harder":
                    mouse "aktion"
                    action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11naperos")
                    text_style "fegeteszov"
        if basziksvetlana11napsebeseg == "eros":
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.7
                xalign 0.5
                textbutton "Story":
                    mouse "aktion"
                    action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napvege")
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.9
                xalign 0.5
                textbutton "Another angle":
                    mouse "aktion"
                    action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11naperos")
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.8
                xalign 0.5
                textbutton "Gentle":
                    mouse "aktion"
                    action Hide ('basziksvetlana11nap'), Jump ("basziksvetlana11napgyenge")
                    text_style "fegeteszov"
screen svetlananalkipakol:
    timer 1.0 repeat True action If(sevtlananalkipakolido <= 0,
    true=[Hide('svetlananalkipakol')],
    false=[SetVariable('sevtlananalkipakolido', sevtlananalkipakolido - 1),
    SetVariable('sevtlananalkipakolelteltido', sevtlananalkipakolelteltido + 1)])
    bar:
        left_bar "#f00"
        if sevtlananalkipakolido <= 5:
            left_bar "#0ff"
        if sevtlananalkipakolido <= 0:
            left_bar "#0f0"
        value StaticValue(sevtlananalkipakolelteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
