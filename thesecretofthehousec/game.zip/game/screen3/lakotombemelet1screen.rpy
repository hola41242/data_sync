screen lakotomb1emelet:
    imagebutton:
        idle "nyilafojason.png"
        xalign 0.55
        yalign 0.98
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("terkep")
    imagebutton:
        idle "ajtok/naptarz2.png"
        xalign 0.42
        yalign 0.42
        mouse "aktion"
        action Jump ("naptar")
    imagebutton:
        idle "ajtok/locsolokanafolysonz.png"
        xalign 0.51
        yalign 0.735
        mouse "aktion"
        action Jump ("locsolanimszov")
    imagebutton:
        idle "ajtok/fhaz.png"
        xalign 0.45
        yalign 0.41
        mouse "aktion"
        action Jump ("elsoemelethatso")
    imagebutton:
        idle "ajtok/feaz.png"
        xalign 0.09
        yalign 1.
        mouse "aktion"
        action Jump ("elsoemeletelso")
    imagebutton:
        idle "ajtok/fliftz.png"
        xalign 0.94
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/ajto5.wav"
        action Jump ("ciliszoba")
    if sabrinaholvan == "lakotombemelet1":
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.53
            yalign 0.57
            mouse "aktion"
            action Jump ("szabrinavalbeszelniemelet1gyen")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
