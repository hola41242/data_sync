screen ciliszoba:
    imagebutton:
        idle "ajtok/nszaballz.png"
        xalign 0.0
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/ajto5.wav"
        action Jump ("lakotomb1emelet")
    imagebutton:
        idle "ajtok/nszakozzepz.png"
        xalign 0.46
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakasanemenged")
    imagebutton:
        idle "ajtok/nszakozzepz.png"
        xalign 0.91
        ypos 0.17
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakasanemenged")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.01
        ypos 0.68
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakasavirag")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.12
        ypos 0.52
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakasavirag")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.32
        ypos 0.35
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakasavirag")
    imagebutton:
        idle "ajtok/minuszz.png"
        xpos 0.505
        ypos 0.6
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakasavirag")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.61
        ypos 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakasavirag")
    imagebutton:
        idle "ajtok/minuszz.png"
        xpos 0.56
        ypos 0.6
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakaskerm")
    imagebutton:
        idle "ajtok/minuszz.png"
        xpos 0.45
        ypos 0.6
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakasmagazin")
    imagebutton:
        idle "ajtok/minuszz.png"
        xpos 0.02
        ypos 0.5
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakaslampa")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.22
        ypos 0.16
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakaskep")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.22
        ypos 0.23
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cililakaskep")
    if ciliholvan == "cilinapaliabanul":
        imagebutton:
            idle "ajtok/ruhazz.png"
            xpos 0.25
            ypos 0.29
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("cililakaskanapen")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xpos 0.25
            ypos 0.51
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("cililakaskanapen")
    if sujzonalad == 2:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.13
            ypos 0.82
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("cililakassujzo")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
