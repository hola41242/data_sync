screen invertori:
    hbox xpos 0.01 ypos 0.02:
        if mitkelltennem == False:
            imagebutton:
                idle "invertori/invertori notesz.png"
                mouse "aktion"
                activate_sound "audio/click.wav"
                action SetVariable('mitkelltennem', True)
        if mitkelltennem == True:
            imagebutton:
                idle "invertori/invertori notesz.png"
                mouse "aktion"
                activate_sound "audio/click.wav"
                action SetVariable('mitkelltennem', False)
        if penz >= 1:
            if penz <= 500:
                imagebutton:
                    idle "invertori/penz1azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegpenzhoz', True)
        if penz >= 501:
            if penz <= 1000:
                imagebutton:
                    idle "invertori/penz2azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegpenzhoz', True)
        if penz >= 1001:
            if penz <= 5000:
                imagebutton:
                    idle "invertori/penz3azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegpenzhoz', True)
        if penz >= 5001:
            if penz <= 20000:
                imagebutton:
                    idle "invertori/penz3azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegpenzhoz', True)
        if penz >= 20001:
            imagebutton:
                idle "invertori/penz2azinvertoriban.png"
                mouse "aktion"
                activate_sound "audio/click.wav"
                action SetVariable('szovegpenzhoz', True)
        if hanyadiknapvan >= 4:
            if lopotfotokat == True:
                imagebutton:
                    idle "invertori/fotoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegfotohoz', True)
                    if holvagyok == "atjaro":
                        action SetVariable('szovegfotohoz', False), Jump ('debrafotokozelebrol')
            if magazinvetem == True:
                imagebutton:
                    idle "invertori/magazinazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegpornomagazinhoz', True)
                    if holvagyok == "atjaro":
                        action SetVariable('szovegpornomagazinhoz', False), Jump ('magazinbabelenezek')
        if hanyadiknapvan >= 7:
            if mobil == True:
                imagebutton:
                    idle "invertori/mobilazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if sanyithivhatod == 1:
                        action Jump ('sanyithivod')
                    if kokonalad == 0:
                        if cilinekjelenteni == False:
                            if feltoltokartyanalad >= 2:
                                action Jump ('hivodcilit')
                    action SetVariable('szovegmobilhoz', True)
            if ruhakosarnalad == True:
                if ruhakosarnaladtele == False:
                    imagebutton:
                        idle "invertori/ruhakosarazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegruhakosarhoz', True)
            if ruhakosarnalad == True:
                if ruhakosarnaladtele == True:
                    imagebutton:
                        idle "invertori/ruhakosarteleazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegruhakosarhoz', True)
            if mosopor == True:
                imagebutton:
                    idle "invertori/invertori mosopor.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmosoporhoz', True)
            if szemeteszsaknalad == True:
                if szemeteszak == 1:
                    imagebutton:
                        idle "invertori/kukaszsak1azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaszemeteszsakhoz', True)
                if szemeteszak == 2:
                    imagebutton:
                        idle "invertori/kukaszsak2azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaszemeteszsakhoz', True)
                if szemeteszak == 3:
                    imagebutton:
                        idle "invertori/kukaszsak3azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaszemeteszsakhoz', True)
                if szemeteszak >= 4:
                    imagebutton:
                        idle "invertori/kukaszsak4azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaszemeteszsakhoz', True)
        if hanyadiknapvan == 1:
            if szobakipakolas == True:
                if szoveguresdobozkidobva == False:
                    imagebutton:
                        idle "invertori/invertori doboz.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveguresdoboz', True)
            if semeteszsakafoldon == True:
                if semeteszsakafoldonkidobva == False:
                    imagebutton:
                        idle "invertori/szemetazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegureszsakhoz', True)
            if ujsagafoldon == True:
                if ujsagafoldonkidobva == False:
                    imagebutton:
                        idle "invertori/invertori ujsag.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveguresujsaghoz', True)
            if szendvicsinvertoriba == True:
                if szendviamamanal == False:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegszedvicshez', True)
            if agynemukaptal == True:
                if agynemukosos == False:
                    imagebutton:
                        idle "invertori/invertori szenyes.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegszenyeshez', True)
            if agynemukaptal == True:
                if agynemukosos == True:
                    if agynemuhejen == False:
                        imagebutton:
                            idle "invertori/invertori tiszta.png"
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action SetVariable('szovegtisztahozhez', True)
            if locsolokannafel == True:
                imagebutton:
                    idle "invertori/invertori locsolokanna.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szoveglocsolokanahoz', True)
            if mosopor == True:
                if agynemukosos == False:
                    imagebutton:
                        idle "invertori/invertori mosopor.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegmosoporhoz', True)
            if parnanalad == True:
                if agynemuhejen == False:
                    imagebutton:
                        idle "invertori/invertori parna.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegparna', True)
        if hanyadiknapvan == 2:
            if fifitfelvetem == True:
                imagebutton:
                    idle "invertori/invertorififi.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegfifi', True)
            if szendvicsinvertoriba == True:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if szivacskoszoslett == 0:
                if torloszivacsnalad == True:
                    imagebutton:
                        idle "invertori/szivacs.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegszivacshoz', True)
            if szivacskoszoslett > 0:
                if szivacskoszoslett < 6:
                    imagebutton:
                        idle "invertori/hugyosszivacs.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkososszivacshoz', True)
            if szivacskoszoslett > 5:
                if szivacskoszoslett < 12:
                    imagebutton:
                        idle "invertori/hugyosszivacs2.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkososszivacshoz', True)
            if mosopor == True:
                imagebutton:
                    idle "invertori/invertori mosopor.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmosoporhoz', True)
            if szenyesnalad == True:
                if szenyeskimosva == False:
                    imagebutton:
                        idle "invertori/szennyes.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegfiuszenyeshez', True)
            if szenyeskimosva == True:
                if szenyeskimosvaahejen == False:
                    imagebutton:
                        idle "invertori/tiszta.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegfiutisztaruha', True)
            if tvhoztak == True:
                if tvnapaliban == False:
                    imagebutton:
                        idle "invertori/invertoritv.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegtvhoz', True)
            if holvagyok == "napaliban":
                if tvtaviranyitonalad == True:
                    if tvtaviranyitomamanal == False:
                        imagebutton:
                            idle "invertori/invertoritaviranyito.png"
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump('tvprogramozas')
            else:
                if tvtaviranyitonalad == True:
                    if tvtaviranyitomamanal == False:
                        imagebutton:
                            idle "invertori/invertoritaviranyito.png"
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action SetVariable('szovegtvtaviranyitohoz', True)

            if poharnalad == True:
                if urespoharnalad == False:
                    imagebutton:
                        idle "invertori/invertoripohar.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegtelepoharhoz', True)
            if poharnalad == True:
                if urespoharnalad == True:
                    imagebutton:
                        idle "invertori/invertoripohar.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegurespoharhoz', True)
            if boritekazinvertoriba == True:
                if boritekmizeriamegoldva == False:
                    imagebutton:
                        idle "invertori/boritekazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegboritekomhoz', True)
            if lopotfotokat == True:
                imagebutton:
                    idle "invertori/fotoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegfotohoz', True)
        if hanyadiknapvan == 3:
            if megetted == False:
                if vanszedvicsed2 >= 1:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegszedvicshez', True)
                if vanszedvicsed2 >= 2:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegszedvicshez', True)
                if uditosmagamhozveni == 1:
                    imagebutton:
                        idle "invertori/uditoazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveguditohoz', True)
                if lopotfotokat == True:
                    imagebutton:
                        idle "invertori/fotoazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegfotohoz', True)
                        if holvagyok == "atjaro":
                            action SetVariable('szovegfotohoz', False), Jump ('debrafotokozelebrol')
            if kaveamamanakkesz == False:
                if megkaptadavizeskancsot == True:
                    if vizeskancsovizes == False:
                        imagebutton:
                            idle "invertori/vizeskancsoazinvertoriban.png"
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action SetVariable('szovegvizeskancohoz', True)
                if megkaptadavizeskancsot == True:
                    if vizeskancsovizes == True:
                        imagebutton:
                            idle "invertori/vizeskancsovizesazinvertoriban.png"
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action SetVariable('szovegvizeskancohoz', True)
            if kutyatalakonyhaban == True:
                if kutyatalaltelenalad == False:
                    imagebutton:
                        idle "invertori/kutyataluazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegureskutyatalhoz', True)
            if kutyatalaltelenalad == True:
                if fifienikap == False:
                    imagebutton:
                        idle "invertori/kutyataltazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegtelekutyatalhoz', True)
            if kavefrednel == True:
                if kaveazasztalon == False:
                    imagebutton:
                        idle "invertori/kaveazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkavehoz', True)
            if kaveazasztalrolinvertoriba == True:
                if harmadikreszkonyha == 1:
                    imagebutton:
                        idle "invertori/kavecseszeazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkavehoz', True)
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtaskahoz', True)
            if mosopor == True:
                imagebutton:
                    idle "invertori/invertori mosopor.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmosoporhoz', True)
            if szenyesnalad == True:
                if szenyeskimosva == False:
                    imagebutton:
                        idle "invertori/szennyes.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegfiuszenyeshez', True)
            if szenyeskimosva == True:
                if szenyeskimosvaahejen == False:
                    imagebutton:
                        idle "invertori/tiszta.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegfiutisztaruha', True)
            if tejetvetem == True:
                if tejetlerektam == False:
                    imagebutton:
                        idle "invertori/tejazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegtejhoz', True)
            if nyalokavetem == True:
                if nyalokatodaadtam == False:
                    imagebutton:
                        idle "invertori/nyalokavertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegnyalokahoz', True)
            if magazinvetem == True:
                imagebutton:
                    idle "invertori/magazinazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegpornomagazinhoz', True)
        if hanyadiknapvan == 4:
            if vanszedvicsed2 >= 1:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if vanszedvicsed2 >= 2:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if uditosmagamhozveni == 1:
                imagebutton:
                    idle "invertori/uditocolaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szoveguditohoz', True)
            if kaveamamanakkesz == False:
                if megkaptadavizeskancsot == True:
                    if vizeskancsovizes == False:
                        imagebutton:
                            idle "invertori/vizeskancsoazinvertoriban.png"
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action SetVariable('szovegvizeskancohoz', True)
                if megkaptadavizeskancsot == True:
                    if vizeskancsovizes == True:
                        imagebutton:
                            idle "invertori/vizeskancsovizesazinvertoriban.png"
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action SetVariable('szovegvizeskancohoz', True)
            if kutyatalfojasojobb == False:
                if kutyatalaltelenalad == False:
                    imagebutton:
                        idle "invertori/kutyataluazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegureskutyatalhoz', True)
            if kutyatalaltelenalad == True:
                if fifienikap == False:
                    imagebutton:
                        idle "invertori/kutyataltazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        if holvagyok == "konyha":
                            action Jump ('kutyatalfifinek')
                        else:
                            action SetVariable('szovegtelekutyatalhoz', True)
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtaskahoz', True)
            if mosopor == True:
                imagebutton:
                    idle "invertori/invertori mosopor.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmosoporhoz', True)
            if szenyesnalad == True:
                if szenyeskimosva == False:
                    imagebutton:
                        idle "invertori/szennyes.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegfiuszenyeshez', True)
            if szenyeskimosva == True:
                if szenyeskimosvaahejen == False:
                    imagebutton:
                        idle "invertori/tiszta.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegfiutisztaruha', True)
            if debratolkenyeretkerni == 2:
                if nincskenyeraszedvicshez == True:
                    imagebutton:
                        idle "invertori/kenyerazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkenyerhez', True)
            if kutyatap == True:
                if kutyatapkibontva == False:
                    imagebutton:
                        idle "invertori/kutyakonzevazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        if debrakutyatapboltban < 3:
                            if holvagyok == "konyha":
                                if konzevnyito == False:
                                    action Jump ('letortakonzervnit')
                            else:
                                action SetVariable('szovegkutyataphoz', True)
                        if debrakutyatapboltban >= 3:
                            if holvagyok == "konyha":
                                if konzevnyito == True:
                                    action Jump ('kutyakajatkiveszed')
                                else:
                                    action SetVariable('szovegkutyataphoz', True)

                            else:
                                action SetVariable('szovegkutyataphoz', True)


            if konzevnyito == True:
                if kutyatapkibontva == False:
                    imagebutton:
                        idle "invertori/konzevnyitoazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkonzevnyitohoz', True)
            if dagitmegharaptafifi == 1:
                if debratolelsosegej == 2:
                    imagebutton:
                        idle "invertori/betedinazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegbetadinhoz', True)
        if hanyadiknapvan == 5:
            if regell5resz == True:
                if vanszedvicsed2 >= 1:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegszedvicshez', True)
                if vanszedvicsed2 >= 2:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegszedvicshez', True)
                if uditosmagamhozveni == 1:
                    imagebutton:
                        idle "invertori/uditocolaazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveguditohoz', True)
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtaskahoz', True)
            if zsacskonalad == 2:
                imagebutton:
                    idle "invertori/zacskotisztaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegzacskohoz', True)
            if zsacskonalad == 3:
                if kakitfeltakaritani == 1:
                    imagebutton:
                        idle "invertori/zacsikoszosazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegzacskohoz', True)
            if szivacskoszoslett == 0:
                if torloszivacsnalad == True:
                    imagebutton:
                        idle "invertori/szivacs.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegszivacshoz', True)
            if szivacskoszoslett > 0:
                if szivacskoszoslett < 6:
                    imagebutton:
                        idle "invertori/hugyosszivacs.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkososszivacshoz', True)
            if szivacskoszoslett > 5:
                if szivacskoszoslett < 12:
                    imagebutton:
                        idle "invertori/hugyosszivacs2.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkososszivacshoz', True)
            if felmosotvenni == 2:
                imagebutton:
                    idle "invertori/felmosoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegfelmosohoz', True)
            if szemetettkidobni5resz == 2:
                imagebutton:
                    idle "invertori/szemetazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegureszsakhoz', True)
            if lampatkidobni5resz >= 2:
                if lampatkidobni5resz < 3:
                    imagebutton:
                        idle "invertori/lampaazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglampahoz', True)
            if kolduskulacsa == 2:
                imagebutton:
                    idle "invertori/falskaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegbutykoshoz', True)
            if lizagyurulye == 3:
                imagebutton:
                    idle "invertori/lizagyuruazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szoveglizagyuruhoz', True)
        if hanyadiknapvan == 6:
            if porszivofelveni == 1:
                imagebutton:
                    idle "invertori/porszivoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if holvagyok == "fojasojobb":
                        if porszivozfojasojobb == 0:
                            action Jump('porszivoz')
                    if holvagyok == "fojasoball":
                        if porszivozfojasobal == 0:
                            action Jump('porszivoz')
                    if holvagyok == "napaliban":
                        if porszivoznapali == 0:
                            action Jump('porszivoz')
                    if holvagyok == "atjaro":
                        if porszivozatjaro == 0:
                            action Jump('porszivoz')
                    if holvagyok == "furdo":
                        if porszivozfurdo == 0:
                            action Jump('porszivoz')
                    if holvagyok == "konyha":
                        if porszivozkonyha == 0:
                            action Jump('porszivoz')
                    action SetVariable('szovegporszivohozhoz', True)
            if debrafulbevalo1 == 1:
                imagebutton:
                    idle "invertori/anyakereszt1azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszulbevalohoz', True)
            if debrafulbevalo2 == 1:
                imagebutton:
                    idle "invertori/anyakereszt2azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszulbevalohoz', True)
            if mamanyaklanc == 1:
                imagebutton:
                    idle "invertori/keresztnyaklancazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegnyaklanchoz', True)
            if gerebjenyel == 0:
                if gerebjefej == 1:
                    imagebutton:
                        idle "invertori/gerebjefejazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveggerebjefejhoz', True)
            if gerebjenyel == 1:
                if gerebjefej == 0:
                    imagebutton:
                        idle "invertori/gerebjenyelazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveggerebjenyelhoz', True)
            if gerebjenyel == 1:
                if gerebjefej == 1:
                    imagebutton:
                        idle "invertori/gerebjeazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveggerebjehoz', True)
            if lizakertjekukaszsakotkaptal == True:
                if lizaszemeteszakja == 1:
                    imagebutton:
                        idle "invertori/kukaszsak1azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaszemeteszsakhoz', True)
                if lizaszemeteszakja == 2:
                    imagebutton:
                        idle "invertori/kukaszsak2azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaszemeteszsakhoz', True)
                if lizaszemeteszakja == 3:
                    imagebutton:
                        idle "invertori/kukaszsak3azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaszemeteszsakhoz', True)
                if lizaszemeteszakja >= 4:
                    imagebutton:
                        idle "invertori/kukaszsak4azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaszemeteszsakhoz', True)
                if lizakertjemadarhaza == 2:
                    imagebutton:
                        idle "invertori/madarhazazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizamadarhahoz', True)
                if csavar6resz == 1:
                    imagebutton:
                        idle "invertori/csavarokazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegcsavarhoz', True)
                if csavarhuzo6resz == 1:
                    imagebutton:
                        idle "invertori/csavarhuzoazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegcsavarhuzohoz', True)
        if hanyadiknapvan == 7:
            if tu == 1:
                imagebutton:
                    idle "invertori/tuazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtuhuzohoz', True)
            if cerna == 1:
                imagebutton:
                    idle "invertori/cernaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegcernahoz', True)
            if vaszon1 == 1:
                imagebutton:
                    idle "invertori/vaszon1azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegvaszon1huzohoz', True)
            if vaszon2 == 1:
                imagebutton:
                    idle "invertori/vaszon2azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegvaszon2huzohoz', True)
            if kiskendofurdoben == False:
                if kiskendolizanal == False:
                    imagebutton:
                        idle "invertori/lizakendojeazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegkiskendohoz', True)
            if debraviragcserepe == 1:
                imagebutton:
                    idle "invertori/viragcserepazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if holvagyok == "debrakertje":
                        action Jump ('viragcserepetletenni')
                    else:
                        action SetVariable('szovegviragcserephoz', True)
            if mamanyaklanczalogjegy == 2:
                imagebutton:
                    idle "invertori/zalogjegyazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegzalogjegyhoz', True)
            if metszoollo == 2:
                imagebutton:
                    idle "invertori/metszoolloazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmetszoollohoz', True)
            if fifitfelvetem == True:
                imagebutton:
                    idle "invertori/invertorififi.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if holvagyok == "debrakertje2":
                        action Jump ('fifitleteszedhatsokertben')
                    else:
                        action SetVariable('szovegfifi', True)
            if madzagveheto == 2:
                imagebutton:
                    idle "invertori/ruhaszaritomadzagazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmadzaghoz', True)
            if svetlanaermeje == 1:
                imagebutton:
                    idle "invertori/ermeazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegermehoz', True)
            if oblitosuveg == 2:
                imagebutton:
                    idle "invertori/oblitoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegoblitohoz', True)
        if hanyadiknapvan == 8:
            if mamanyaklanczalogjegy == 2:
                imagebutton:
                    idle "invertori/zalogjegyazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegzalogjegyhoz', True)
            if invertorieszkozszam <= 5:
                if receptnalad == 1:
                    imagebutton:
                        idle "invertori/napegesreceptazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegrecepthoz', True)
                if uditosmagamhozveni == 1:
                    imagebutton:
                        idle "invertori/uditoazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegnaracslehoz', True)
                if gombanalad == 1:
                    imagebutton:
                        idle "invertori/gombaazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveggombahoz', True)
                if rovarirtonalad == 1:
                    imagebutton:
                        idle "invertori/rovaroloazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegrovarirtohoz', True)
                if poknalad == 1:
                    imagebutton:
                        idle "invertori/pokazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegpokhoz', True)
                if tojasnalad == 1:
                    imagebutton:
                        idle "invertori/tojasazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegtojashoz', True)
                if gyongyviragnalad == 1:
                    imagebutton:
                        idle "invertori/gyongyviragazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveggyongyviraghoz', True)
                if tulipannalad == 1:
                    imagebutton:
                        idle "invertori/tulipanazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegtulipanhoz', True)
                if lizaviragnalad == 1:
                    imagebutton:
                        idle "invertori/lizaviragazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szoveglizaviraghoz', True)
                if elesztonalad == 1:
                    imagebutton:
                        idle "invertori/elesztoazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('szovegelesztohoz', True)
                if mozsarnalad == 1:
                    imagebutton:
                        idle "invertori/mozsarazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        if holvagyok == "lizakertje":
                            action Jump('pulinapegeseelmulik')
                        else:
                            action SetVariable('szovegmozsarhoz', True)
            if invertorieszkozszam >= 6:
                if invertorimutateleje > 1:
                    imagebutton:
                        idle "invertori/ballraazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('invertorimutateleje', invertorimutateleje - 1), SetVariable('invertorimutavege', invertorimutavege - 1)
                if invertorimutateleje == 1:
                    if receptnalad == 1:
                        imagebutton:
                            idle "invertori/napegesreceptazinvertoriban.png"
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action SetVariable('szovegrecepthoz', True)
                if invertorimutateleje >= 1:
                    if invertorimutavege < 7:
                        if uditosmagamhozveni == 1:
                            imagebutton:
                                idle "invertori/uditoazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szovegnaracslehoz', True)
                if invertorimutateleje >= 1:
                    if invertorimutavege < 8:
                        if gombanalad == 1:
                            imagebutton:
                                idle "invertori/gombaazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szoveggombahoz', True)
                if invertorimutateleje >= 1:
                    if invertorimutavege < 9:
                        if rovarirtonalad == 1:
                            imagebutton:
                                idle "invertori/rovaroloazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szovegrovarirtohoz', True)
                if invertorimutateleje >= 1:
                    if invertorimutavege < 9:
                        if poknalad == 1:
                            imagebutton:
                                idle "invertori/pokazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szovegpokhoz', True)
                if invertorimutateleje >= 2:
                    if invertorimutavege < 10:
                        if tojasnalad == 1:
                            imagebutton:
                                idle "invertori/tojasazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szovegtojashoz', True)
                if invertorimutateleje >= 3:
                    if invertorimutavege < 11:
                        if gyongyviragnalad == 1:
                            imagebutton:
                                idle "invertori/gyongyviragazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szoveggyongyviraghoz', True)
                if invertorimutateleje >= 4:
                    if invertorimutavege < 12:
                        if tulipannalad == 1:
                            imagebutton:
                                idle "invertori/tulipanazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szovegtulipanhoz', True)
                if invertorimutateleje >= 5:
                    if invertorimutavege < 13:
                        if lizaviragnalad == 1:
                            imagebutton:
                                idle "invertori/lizaviragazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szoveglizaviraghoz', True)
                if invertorimutateleje >= 6:
                    if invertorimutavege < 14:
                        if elesztonalad == 1:
                            imagebutton:
                                idle "invertori/elesztoazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szovegelesztohoz', True)
                if invertorimutateleje >= 7:
                    if invertorimutavege < 15:
                        if mozsarnalad == 1:
                            imagebutton:
                                idle "invertori/mozsarazinvertoriban.png"
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                action SetVariable('szovegmozsarhoz', True)
                if targyazinvertoriban >= 1:
                    imagebutton:
                        idle "invertori/jobbra1azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('invertorimutateleje', invertorimutateleje + 1), SetVariable('invertorimutavege', invertorimutavege + 1)
            if gerebjenalad == 1:
                imagebutton:
                    idle "invertori/gerebjeazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if holvagyok == "debrakertje2":
                        if debraholcsinal == "furdo":
                            if debrakertje2foldturas == 1:
                                action Jump ('foldeltuntetese')
                            else:
                                action SetVariable('szoveggerebjehoz', True)
                        else:
                            action SetVariable('szoveggerebjehoz', True)
                    else:
                        action SetVariable('szoveggerebjehoz', True)
            if metszoollonalad == 1:
                imagebutton:
                    idle "invertori/metszoolloazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmetszoollohoz', True)
        if hanyadiknapvan == 9:
            if mamanyaklanczalogjegy == 2:
                imagebutton:
                    idle "invertori/zalogjegyazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegzalogjegyhoz', True)
            if szivacsnalad == 1:
                imagebutton:
                    idle "invertori/szivacs.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszivacshoz', True)
            if festekoldonalad == 1:
                imagebutton:
                    idle "invertori/festekoldoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('festekoldohoz', True)
            if tisztitoszernalad == 1:
                imagebutton:
                    idle "invertori/tisztitoszerazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtisztitoszerhoz', True)
            if tapasznalad == 1:
                imagebutton:
                    idle "invertori/tapaszazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtapaszhoz', True)
            if metszoollonalad == 1:
                imagebutton:
                    idle "invertori/metszoolloazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmetszoollohoz', True)
            if faagnalad >= 1:
                if faagnalad < 3:
                    imagebutton:
                        if faagnalad == 1:
                            idle "invertori/faagazinvertoriban.png"
                        if faagnalad == 2:
                            idle "invertori/faagpecabotazinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        if holvagyok == "parkto":
                            if halnalad == 0:
                                action Jump ('horgaszparktonal')
                            else:
                                action SetVariable('faaghoz', True)
                        else:
                            action SetVariable('faaghoz', True)
            if horognalad == 1:
                imagebutton:
                    idle "invertori/horogazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('horoghoz', True)
            if gilisztanalad >= 1:
                if gilisztanalad < 3:
                    imagebutton:
                        if gilisztanalad == 2:
                            idle "invertori/giliszta2azinvertoriban.png"
                        if gilisztanalad == 1:
                            idle "invertori/giliszta1azinvertoriban.png"
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action SetVariable('gilisztahoz', True)
            if salgcsonalad == 1:
                imagebutton:
                    idle "invertori/slagcsoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('salgcsohoz', True)
            if leengedonalad == 1:
                imagebutton:
                    idle "invertori/leengedocsoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('leengedohoz', True)
            if poharnalad2 == 1:
                imagebutton:
                    idle "invertori/invertoripohar.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('poharhoz', True)
            if kutyatalnalad == 1:
                imagebutton:
                    if kutyatalban == "semmi":
                        idle "invertori/kutyataluazinvertoriban.png"
                    if kutyatalban == "kutyakaja":
                        idle "invertori/kutyataltazinvertoriban.png"
                    if kutyatalban == "tej":
                        idle "invertori/kutyataltejesazinvertoriban.png"
                    if kutyatalban == "hal":
                        idle "invertori/kutyatalhallalazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('kutyatalhoz', True)
            if tejnalad == 1:
                imagebutton:
                    idle "invertori/tej2azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if kutyatalban == "semmi":
                        action SetVariable('tejhoz', True), SetVariable('kutyatalban', "tej" ), SetVariable('tejnalad', tejnalad + 1),
                    else:
                        action SetVariable('tejhoz', True)
            if szedvicsnalad == 1:
                imagebutton:
                    idle "invertori/invertori szedvics2.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szedvicshoz', True)
            if halnalad == 1:
                imagebutton:
                    idle "invertori/halazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if kutyatalban == "semmi":
                        action SetVariable('halhoz', True), SetVariable('kutyatalban', "hal" ), SetVariable('halnalad', halnalad + 1),
                    else:
                        action SetVariable('halhoz', True)
            if agfuresznalad == 1:
                imagebutton:
                    idle "invertori/agfureszazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('agfureszhoz', True)
            if madzagveheto == 2:
                imagebutton:
                    idle "invertori/ruhaszaritomadzagazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmadzaghoz', True)
            if betadinnalad == 1:
                imagebutton:
                    idle "invertori/betedinazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegbetadinhoz', True)
            if macskanalad == 1:
                imagebutton:
                    idle "invertori/macskaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmacskahoz', True)
        if hanyadiknapvan == 10:
            if vanszedvicsed2 >= 1:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if vanszedvicsed2 >= 2:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if uditosmagamhozveni == 1:
                imagebutton:
                    idle "invertori/uditocolaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szoveguditohoz', True)
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtaskahoz', True)
            if ladatmegtalalhatod == 1:
                imagebutton:
                    idle "invertori/ladaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if karkotonalad == 0:
                        if ladabanvanvalamiszamodra == True:
                            action Jump ('ladaazinvertoriban')
                        if ladabanvanvalamiszamodra == False:
                            action SetVariable('szovegladahoz', True)
                    else:
                        action SetVariable('szovegladahoz', True)
            if karkotonalad == 1:
                imagebutton:
                    idle "invertori/karkotoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegkarkotohoz', True)
            if festekoldonalad == 1:
                imagebutton:
                    idle "invertori/festekoldoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('festekoldohoz', True)
            if metszoollonalad == 1:
                imagebutton:
                    idle "invertori/metszoolloazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmetszoollohoz', True)
            if gyufanalad == 1:
                imagebutton:
                    idle "invertori/gyufaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('gyufahoz', True)
            if spaklinalad == 1:
                imagebutton:
                    idle "invertori/spakliazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegspaklihoz', True)
            if fagylaltoknalad == 1:
                imagebutton:
                    idle "invertori/fagylaltokazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegfagyihoz', True)
            if cottonnalad == 1:
                imagebutton:
                    idle "invertori/kottonazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegcottonhoz', True)
        if hanyadiknapvan == 11:
            if vanszedvicsed2 >= 1:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if vanszedvicsed2 >= 2:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if uditosmagamhozveni == 1:
                imagebutton:
                    idle "invertori/uditocolaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szoveguditohoz', True)
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtaskahoz', True)
            if nyomortanyakoszosruhanalad == 1:
                imagebutton:
                    if oroszruha == "koszos":
                        idle "invertori/oroszruhakoszosazinvertoriban.png"
                    else:
                        idle "invertori/oroszruhatisztaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegoroszruhahoz', True)
            if nyomortanyadoboz1nalad == 1:
                imagebutton:
                    idle "invertori/svetlanadoboz1azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegosvetlanadobozaihoz', True)
            if nyomortanyadoboz2nalad == 1:
                imagebutton:
                    idle "invertori/svetlanadoboz2azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegosvetlanadobozaihoz', True)
            if nyomortanyadoboz3nalad == 1:
                imagebutton:
                    idle "invertori/svetlanadoboz3azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegosvetlanadobozaihoz', True)
            if oroszkonyvnalad == 1:
                imagebutton:
                    idle "invertori/oroszszotarazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if holvagyok == "atjaro":
                        if oroszultanultal == False:
                            action Jump ('tanuloros')
                    else:
                        action SetVariable('szovegooroszszorarhoz', True)
            if boriszfenykepenalad == 1:
                imagebutton:
                    idle "invertori/oroszfotoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegboriszfotohoz', True)
            if mubajuszkell == 2:
                imagebutton:
                    idle "invertori/alszakalazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmubajuszhoz', True)
            if rozsaknalad == 1:
                imagebutton:
                    idle "invertori/rozsakazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegrozsakhoz', True)
            if ragasztonalad == 1:
                imagebutton:
                    idle "invertori/ragasztoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegragasztohoz', True)
            if letranalad == 1:
                imagebutton:
                    idle "invertori/letraazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if holvagyok == "napaliban":
                        if izzoknalad == 1:
                            if letranalad == 1:
                                action Jump ('napalijelenet11nap')
                    else:
                        action SetVariable('szovegletrahoz', True)
            if izzoknalad == 1:
                imagebutton:
                    idle "invertori/izzokazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if holvagyok == "napaliban":
                        if izzoknalad == 1:
                            if letranalad == 1:
                                action Jump ('napalijelenet11nap')
                    else:
                        action SetVariable('szovegizzohoz', True)
            if cottonnalad == 1:
                imagebutton:
                    idle "invertori/kottonazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegcottonhoz', True)
            if csacsikalapjanalad == 1:
                imagebutton:
                    idle "invertori/csacsikalapazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegcsacsikalaphoz', True)
        if hanyadiknapvan == 12:
            if vanszedvicsed2 >= 1:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if vanszedvicsed2 >= 2:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszedvicshez', True)
            if uditosmagamhozveni == 1:
                imagebutton:
                    idle "invertori/uditocolaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szoveguditohoz', True)
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegtaskahoz', True)
            if oroszkonyvnalad == 1:
                imagebutton:
                    idle "invertori/oroszszotarazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegooroszszorarhoz', True)
            if boriszfenykepenalad == 1:
                imagebutton:
                    idle "invertori/oroszfotoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegboriszfotohoz', True)
            if sujzonalad == 1:
                imagebutton:
                    idle "invertori/sujzoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegsujzohoz', True)
            if kokonalad >= 1:
                imagebutton:
                    if kokonalad == 1:
                        idle "invertori/kokain1azinvertoriban.png"
                    if kokonalad == 2:
                        idle "invertori/kokain2azinvertoriban.png"
                    if kokonalad == 3:
                        idle "invertori/kokain3azinvertoriban.png"
                    if kokonalad == 4:
                        idle "invertori/kokain4azinvertoriban.png"
                    if kokonalad == 5:
                        idle "invertori/kokain5azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegkokohoz', True)
            if asonallad == 1:
                imagebutton:
                    idle "invertori/asoazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegasohoz', True)
            if komposztnallad == 1:
                imagebutton:
                    idle "invertori/komposztazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegkomposzthoz', True)
            if viraghagymanallad == 1:
                imagebutton:
                    idle "invertori/viraghagymaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szoveghagymahoz', True)
            if mamakenocsenalad == 1:
                imagebutton:
                    idle "invertori/mamakenocseazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegmamakenocshoz', True)
            if viragcserepnalad2 == 1:
                imagebutton:
                    idle "invertori/beultetetviragazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    if holvagyok == "fajasokertfele":
                        action Jump ('viragcserepledebrakertjefele')
                    else:
                        action SetVariable('szovegviragvaza2hoz', True)
            if kittyszemetenalad == 1:
                imagebutton:
                    idle "invertori/szemet2azinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegszemethoz', True)
            if cottonnalad == 1:
                imagebutton:
                    idle "invertori/kottonazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegcottonhoz', True)
            if feltoltokartyanalad == 1:
                imagebutton:
                    idle "invertori/feltoltokartyaazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegfeltoltohoz', True)
            if regiegernalad == 1:
                imagebutton:
                    idle "invertori/egerazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szovegegerhoz', True)
            if girosznalad == 1:
                imagebutton:
                    idle "invertori/girosazinvertoriban.png"
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action SetVariable('szoveggiroszhoz', True)












    if mitkelltennem == True:
        imagemap:
            idle "eszkozok/noteszhasznal.png"
            xpos 0.0
            ypos 0.05
        if hanyadiknapvan == 1:
            vbox xpos 0.71 ypos 0.26:
                if szobakipakolas == False:
                    text "{color=000000}Pack out your stuffs."
                if szobakipakolas == True:
                    text "{color=000000}{s}Pack out your stuffs."
                if agynemu == True:
                    if agynemukaptal == False:
                        text "{color=000000}Ask for a bed sheet."
                if agynemu == True:
                    if agynemukaptal == True:
                        text "{color=000000}{s}Ask for a bed sheet."
                if agynemukaptal == True:
                    if agynemukosos == False:
                        text "{color=000000}I need to wash the bed sheet."
                if agynemukaptal == True:
                    if agynemukosos == True:
                        text "{color=000000}{s}I need to wash the bed sheet."
                if agynemukosos == True:
                    if agynemuhejen == False:
                        text "{color=000000}I need to make my bed."
                if agynemukosos == True:
                    if agynemuhejen == True:
                        text "{color=000000}{s}I need to make my bed."
                if korbenezni == False:
                    text "{color=000000}Look around."
                if korbenezni == True:
                    text "{color=000000}{s}Look around."
                if hozdbeazujsagot == False:
                    text "{color=000000}Bring the newspaper{p}in the living room."
                if hozdbeazujsagot == True:
                    text "{color=000000}{s}Bring the newspaper{p}in the living room."
                if viragokmegontozese == False:
                    text "{color=000000}Water the plants [viragokmegontozve]/8"
                if viragokmegontozese == True:
                    text "{color=000000}{s}Water the plants [viragokmegontozve]/8"
                if szobakipakolas == True:
                    if szoveguresdobozkidobva == False:
                        text "{color=000000}Throw out the trash."
                if szobakipakolas == True:
                    if szoveguresdobozkidobva == True:
                        text "{color=000000}{s}Throw out the trash."
                if szemetafojason == False:
                    text "{color=000000}Throw out the garbage bag."
                if szemetafojason == True:
                    text "{color=000000}{s}Throw out the garbage bag."
                if szendvicsmilesznemetted == True:
                    if szendviamamanal == False:
                        text "{color=000000}Give the sandwich{p}to Grandma."
                if szendvicsmilesznemetted == True:
                    if szendviamamanal == True:
                        text "{color=000000}{s}Give the sandwich{p} to Grandma."
                if menyiharomgyokalat == 2:
                    text "{color=000000}N-th root of 3?"
                if menyiharomgyokalat == 3:
                    text "{color=000000}N-th root of 3?"
                if menyiharomgyokalat == 4:
                    text "{color=000000}{s}N-th root of 3?"
                if wcremehetek == True:
                    text "{color=000000}Go to pee."
        if hanyadiknapvan == 2:
            vbox xpos 0.71 ypos 0.26:
                if boritekmizeriamegoldva == False:
                    text "{color=000000}Envelope. I should put it {p}on a safe place."
                if boritekmizeriamegoldva == True:
                    text "{color=000000}{s}Envelope. I should put it {p}on a safe place."
                if nemtanulhatsztobbet == False:
                    text "{color=000000}Study."
                if nemtanulhatsztobbet == True:
                    text "{color=000000}{s}Study."
                if dolgozolmosogatas == 1:
                    text "{color=000000}Wash the dishes."
                if dolgozolmosogatas == 2:
                    text "{color=000000}{s}Wash the dishes."
                if szenyeseltakaritasa == 1:
                    text "{color=000000}Laundry."
                if szenyeseltakaritasa == 2:
                    text "{color=000000}{s}Laundry."
                if mamavalfoglalkoz == 1:
                    text "{color=000000}Take care of „Grandma”."
                if mamavalfoglalkoz == 2:
                    text "{color=000000}{s}Take care of „Grandma”."
                if kutyapisok == 1:
                    text "{color=000000}Clan up Fifi’s dirt."
                if kutyapisok == 2:
                    text "{color=000000}{s}Clan up Fifi’s dirt."
                if mamakeresei == 1:
                    text "{color=000000}Bring in the television."
                if mamakeresei >= 2:
                    text "{color=000000}{s}Bring in the television."
                if mamakeresei == 2:
                    text "{color=000000}Find the controller."
                if mamakeresei >= 3:
                    text "{color=000000}{s}Find the controller."
                if mamakeresei == 3:
                    text "{color=000000}Programming television."
                if mamakeresei >= 4:
                    text "{color=000000}{s}Programming television."
                if mamakeresei == 4:
                    text "{color=000000}Bring Grandma a sandwich."
                if mamakeresei >= 5:
                    text "{color=000000}{s}Bring Grandma a sandwich."
                if mamakeresei == 5:
                    text "{color=000000}Bring Grandma a drink."
                if mamakeresei >= 6:
                    text "{color=000000}{s}Bring Grandma a drink."
                if enneegyszedvicset == 1:
                    text "{color=000000}Eta a sandwich."
                if enneegyszedvicset == 2:
                    text "{color=000000}{s}Eta a sandwich."
        if hanyadiknapvan == 3:
            vbox xpos 0.71 ypos 0.26:
                if teremjelenetek == 0:
                    if wczett == 0:
                        text "{color=000000}I need to pee."
                    if wczett == 1:
                        text "{color=000000}{s}I need to pee."
                    if ennivini <= 1:
                        text "{color=000000}I need to prepare {p}[vanszedvicsed2]/2 sandwiches."
                    if ennivini == 2:
                        text "{color=000000}{s}I need to prepare {p}2/2 sandwiches."
                    if uditosmagamhozveni == 0:
                        text "{color=000000}I need some drink."
                    if uditosmagamhozveni == 1:
                        text "{color=000000}{s}I need some drink."
                    if isztaruhafel == 1:
                        text "{color=000000}I should change{p}my dresses."
                    if isztaruhafel == 2:
                        text "{color=000000}{s}I should change{p}my dresses."
                    if taskafel == 1:
                        text "{color=000000}I need to pick up{p}my bag."
                    if taskafel == 2:
                        text "{color=000000}{s}I need to pick up{p}my bag."
                    if harmadikreszkonyha == 1:
                        text "{color=000000}Give Grandmother{p}the coffee."
                    if harmadikreszkonyha == 2:
                        text "{color=000000}{s}Give Grandmother{p}the coffee."
                    if lefottaviz == True:
                        if kavefrednel == False:
                            text "{color=000000}Get the ground coffee."
                    if lefottaviz == True:
                        if kavefrednel == True:
                            text "{color=000000}{s}Get the ground coffee."
                    if fifieniker == True:
                        if fifienikap == False:
                            text "{color=000000}Feed Fifi with dog food{p}from the fridge."
                    if fifieniker == True:
                        if fifienikap == True:
                            text "{color=000000}{s}Feed Fifi with dog food{p}from the fridge."
                if teremjelenetek == 0:
                    text "{color=000000}Go to the university."
                if teremjelenetek >= 1:
                    text "{color=000000}{s}Go to the university."
                if dolgozolmosogatas == 1:
                    text "{color=000000}Wash the dishes."
                if dolgozolmosogatas == 2:
                    text "{color=000000}{s}Wash the dishes."
                if szenyeseltakaritasa == 1:
                    text "{color=000000}Laundry."
                if szenyeseltakaritasa == 2:
                    text "{color=000000}{s}Laundry."
                if harmadikreszkonyha >= 4:
                    if nemtanulhatsztobbet3resz == False:
                        text "{color=000000}Study."
                    if nemtanulhatsztobbet3resz == True:
                        text "{color=000000}{s}Study."
                if hoztejet == 1:
                    text "{color=000000}Buy milk."
                if hoztejet == 2:
                    text "{color=000000}{s}Buy milk."
                if neznyomozosfilmet == 1:
                    text "{color=000000}Watch detective film."
                if neznyomozosfilmet == 2:
                    text "{color=000000}{s}Watch detective film."
                if beszeljaszomszedokkal == 1:
                    text "{color=000000}Talk with the neighbors."
                if beszeljaszomszedokkal == 2:
                    text "{color=000000}{s}Talk with the neighbors."
        if hanyadiknapvan == 4:
            vbox xpos 0.71 ypos 0.22:
                if uditosmagamhozveni < 2:
                    if ennivini <= 1:
                        text "{color=000000}I need to prepare{p}[vanszedvicsed2]/2 sandwiches."
                    if ennivini == 2:
                        text "{color=000000}{s}I need to prepare{p}2/2 sandwiches."
                    if uditosmagamhozveni == 0:
                        text "{color=000000}I need some drink."
                    if uditosmagamhozveni == 1:
                        text "{color=000000}{s}I need some drink."
                    if isztaruhafel == 1:
                        text "{color=000000}I should change{p}my dresses."
                    if isztaruhafel == 2:
                        text "{color=000000}{s}I should change{p}my dresses."
                    if taskafel == 1:
                        text "{color=000000}I need to pick{p}up my bag."
                    if taskafel == 2:
                        text "{color=000000}{s}I need to pick{p}up my bag."
                    if beszeljamamaval == 1:
                        text "{color=000000}Ask Grandma what{p}to do."
                    if mamaszedvics == 1:
                        text "{color=000000}Prepare a sandwich{p}for Grandma."
                    if mamaszedvics == 2:
                        text "{color=000000}{s}Prepare a sandwich{p}for Grandma."
                    if mamakave == 1:
                        text "{color=000000}Make a cup of coffee{p}for Grandma."
                    if mamakave == 2:
                        text "{color=000000}{s}Make a cup of coffee{p}for Grandma."
                    if mamanakteritve == 1:
                        text "{color=000000}Tell Grandma- you{p}set the table."
                    if mamanakteritve == 2:
                        text "{color=000000}{s}Tell Grandma- you{p}set the table."
                    if fifitregeliztetni == 1:
                        if debrakutyatapboltban < 2:
                            text "{color=000000}Feed Fifi."
                        if debrakutyatapboltban >= 2:
                            text "{color=000000}Feed Fifi in{p}the kitchen."
                    if fifitregeliztetni == 2:
                        if debrakutyatapboltban >= 2:
                            text "{color=000000}{s}Feed Fifi in{p}the kitchen."
                    if kutyatalfojasojobb == False:
                        if kutyatapotkernidebratol == False:
                            text "{color=000000}Take the dog food from{p}the fridge."
                    if kutyatalfojasojobb == False:
                        if kutyatapotkernidebratol == True:
                            text "{color=000000}{s}Take the dog food from{p}the fridge."
                    if debrakutyatapboltban == 1:
                        if kutyatapotkernidebratol == True:
                            text "{color=000000}Ask Debra about{p}Dog Food."
                    if debrakutyatapboltban == 2:
                        text "{color=000000}{s}Ask Debra about{p}Dog Food."
                    if debrakutyatapboltban == 2:
                        if kutyatap == False:
                            text "{color=000000}Buy dog food."
                    if kutyatap == True:
                        text "{color=000000}{s}Buy dog food."
                    if debrakutyatapboltban >= 4:
                        if konzevnyito == False:
                            text "{color=000000}Buy can opener."
                    if konzevnyito == True:
                        text "{color=000000}{s}Buy can opener."
                    if debratolkerdeznikenyer == True:
                        if debratolkenyeretkerni == 0:
                            text "{color=000000}Ask Debra about{p}the bread."
                    if debratolkerdeznikenyer == True:
                        if debratolkenyeretkerni >= 1:
                            text "{color=000000}{s}Ask Debra about{p}the bread."
                    if debratolkenyeretkerni == 1:
                        text "{color=000000}Buy bread."
                    if debratolkenyeretkerni >= 2:
                        text "{color=000000}{s}Buy bread."
                    if debratolkenyeretkerni == 2:
                        text "{color=000000}Put the bread in{p}the fridge."
                    if debratolkenyeretkerni == 3:
                        text "{color=000000}{s}Put the bread in{p}the fridge."
                    if teremjelenetek == 1:
                        text "{color=000000}Go to the university."
                    if teremjelenetek >= 2:
                        text "{color=000000}{s}Go to the university."
            vbox xpos 0.71 ypos 0.26:
                if uditosmagamhozveni == 2:
                    if jobboldaliszomszed == 0:
                        text "{color=000000}Talk to Zoli."
                    if jobboldaliszomszed == 1:
                        text "{color=000000}{s}Talk to Zoli."
                    if taskafel == 2:
                        text "{color=000000}Put your bag down{p}in your room."
                    if taskafel == 3:
                        text "{color=000000}{s}Put your bag down{p}in your room."
                    if dagitmegharaptafifi == 1:
                        text "{color=000000}Care about Puffy’s{p}injuries."
                    if dagitmegharaptafifi == 2:
                        text "{color=000000}{s}Care about Puffy’s{p}injuries."
                    if debratolelsosegej == 1:
                        text "{color=000000}Ask for Bandage{p}from Debra."
                    if debratolelsosegej == 2:
                        text "{color=000000}{s}Ask for Bandage{p}from Debra."
                    if jobboldaliszomszed == 1:
                        text "{color=000000}Talk to Bertalan."
        if hanyadiknapvan == 5:
            vbox xpos 0.71 ypos 0.26:
                if regell5resz == True:
                    if ennivini <= 1:
                        text "{color=000000}I need to pick up{p}[vanszedvicsed2]/2 sandwiches."
                    if ennivini == 2:
                        text "{color=000000}{s}I need to pick up{p}2/2 sandwiches."
                    if uditosmagamhozveni == 0:
                        text "{color=000000}I need some drink."
                    if uditosmagamhozveni == 1:
                        text "{color=000000}{s}I need some drink."
                    if taskafel == 1:
                        text "{color=000000}I need to pick{p}up my bag."
                    if taskafel == 2:
                        text "{color=000000}{s}I need to pick{p}up my bag."
                    if kakitfeltakaritanikersz == False:
                        text "{color=000000}Clean up the{p}„surprise”."
                    if kakitfeltakaritanikersz == True:
                        text "{color=000000}{s}Clean up the{p}„surprise”."
                    if kakialatpisi == 1:
                        text "{color=000000}Clean up the pee."
                    if kakialatpisi == 2:
                        text "{color=000000}{s}Clean up the pee."
                    if dolgozolmosogatas == 1:
                        text "{color=000000}Wash the dishes."
                    if dolgozolmosogatas == 2:
                        text "{color=000000}{s}Wash the dishes."
                    if kakitfeltakaritanikersz == True:
                        if kakitfeltakaritani == 1:
                            text "{color=000000}Throw out the shit."
                    if kakitfeltakaritanikersz == True:
                        if kakitfeltakaritani == 2:
                            text "{color=000000}{s}Throw out the shit."
                    if torloszivacsnalad == False:
                        text "{color=000000}I need a sponge."
                    if torloszivacsnalad == True:
                        text "{color=000000}{s}I need a sponge."
                    if felvetedaszivacsot == 1:
                        text "{color=000000}Ask Debra to let you{p}in the bathroom."
                    if felvetedaszivacsot >= 2:
                        text "{color=000000}{s}Ask Debra to let you{p}in the bathroom."
                    if felvetedaszivacsot == 2:
                        text "{color=000000}Pick up the sponge."
                    if felvetedaszivacsot >= 3:
                        text "{color=000000}{s}Pick up the sponge."
                    if zsacskonalad == 1:
                        text "{color=000000}Pick up the rubbish bag!{p}It is under the kitchen sink."
                    if zsacskonalad >= 2:
                        text "{color=000000}{s}Pick up the rubbish bag!{p}It is under the kitchen sink."
                    if felmosotvenni == 1:
                        text "{color=000000}Buy a mop!"
                    if felmosotvenni >= 2:
                        text "{color=000000}{s}Buy a mop!"
                    if felmosotvenni == 2:
                        text "{color=000000}Put the mop in{p}the storage room."
                    if felmosotvenni >= 3:
                        text "{color=000000}{s}Put the mop in{p}the storage room."
                    if teremjelenetek <= 1:
                        text "{color=000000}Go to the university."
                    if teremjelenetek >= 2:
                        text "{color=000000}{s}Go to the university."
            vbox xpos 0.71 ypos 0.22:
                if regell5resz == False:
                    if felmosotvenni == 1:
                        text "{color=000000}Buy a mop!"
                    if felmosotvenni >= 2:
                        text "{color=000000}{s}Buy a mop!"
                    if felmosotvenni == 2:
                        text "{color=000000}Put the mop in the{p}storage room."
                    if felmosotvenni >= 3:
                        text "{color=000000}{s}Put the mop in the{p}storage room."
                    if kerdezkorbe == False:
                        text "{color=000000}Ask around."
                    if kerdezkorbe == True:
                        text "{color=000000}{s}Ask around."
                    if lizanalbeszeltel == 0:
                        text "{color=000000}Talk to Liza."
                    if lizanalbeszeltel >= 1:
                        text "{color=000000}{s}Talk to Liza."
                    if santakolduszolieknal == 1:
                        text "{color=000000}Talk to the{p}lame guy."
                    if santakolduszolieknal == 2:
                        text "{color=000000}{s}Talk to the{p}lame guy."
                    if boltosalbeszelni == 1:
                        text "{color=000000}Talk to Eszter."
                    if boltosalbeszelni == 2:
                        text "{color=000000}{s}Talk to Eszter."
                    if barkacsboltosalbeszelni == 1:
                        text "{color=000000}Talk to the shop assistant{p}in the tool shop."
                    if barkacsboltosalbeszelni == 2:
                        text "{color=000000}{s}Talk to the shop assistant{p}in the tool shop."
                    if lizagyurulye == 1:
                        text "{color=000000}Find the ring."
                    if lizagyurulye >= 2:
                        text "{color=000000}{s}Find the ring."
                    if lizagyurulye >= 2:
                        if lizagyurulye < 4:
                            text "{color=000000}Give the ring{p}to Liza."
                    if lizagyurulye >= 4:
                        text "{color=000000}{s}Give the ring{p}to Liza."
                    if lizavalmunkabameni == False:
                        text "{color=000000}Go to the Strip bar."
                    if lizavalmunkabameni == True:
                        text "{color=000000}{s}Go to the Strip bar."
                    if lizagyurulyesvetlanatol == 0:
                        if kolduskulacsa == 1:
                            text "{color=000000}Find the brandy bottle."
                        if kolduskulacsa >= 2:
                            text "{color=000000}{s}Find the brandy bottle."
                    if lizagyurulyesvetlanatol >= 1:
                        if kolduskulacsa == 1:
                            text "{color=000000}Get the brandy{p}bottle from Svetlana."
                        if kolduskulacsa >= 2:
                            text "{color=000000}{s}Get the brandy{p}bottle from Svetlana."
                    if kolduskulacsa == 2:
                        text "{color=000000}Exchange the brandy{p}bottle for the ring."
                    if kolduskulacsa >= 3:
                        text "{color=000000}{s}Exchange the brandy{p}bottle for the ring."
                    if lizagyurulyesvetlanatol >= 2:
                        if lizagyurulyesvetlanatol < 4:
                            text "{color=000000}Search for a lamp."
                    if lizagyurulyesvetlanatol >= 4:
                        text "{color=000000}{s}Search for a lamp."
                    if lizavalbeszeltelapenzrol == True:
                        if lizagyurulyesvetlanatol == 3:
                            text "{color=000000}Ask Debra about{p}the lamp."
                        if lizagyurulyesvetlanatol >= 5:
                            text "{color=000000}{s}Ask Debra about{p}the lamp."
                    if szemetettkidobni5resz == 1:
                        if lampatkidobni5resz == 1:
                            text "{color=000000}Throw out the trash."
                    if szemetettkidobni5resz >= 2:
                        if lampatkidobni5resz >= 2:
                            text "{color=000000}{s}Throw out the trash."
                    if zolivalbeszeltel == 2:
                        text "{color=000000}Talk to Zoli."
                    if zoliinfo == True:
                        text "{color=000000}{s}Talk to Zoli."
        if hanyadiknapvan == 6:
            vbox xpos 0.71 ypos 0.26:
                if regell6resz == True:
                    if porszivofelveni == 0:
                        text "{color=000000}Pick up the vacuum {p}cleaner."
                    if porszivofelveni >= 1:
                        text "{color=000000}{s}Pick up the vacuum {p}cleaner."
                    if porszivofeladet == 1:
                        text "{color=000000}Clean up in 6 rooms.[porszivozotszobak]/6"
                    if porszivofeladet >= 2:
                        text "{color=000000}{s}Clean up in 6 rooms.[porszivozotszobak]/6"
                    if porszivofeladet == 2:
                        text "{color=000000}Put the vacuum cleaner{p}back in the{p}storage room."
                    if porszivofeladet == 3:
                        text "{color=000000}{s}Put the vacuum cleaner{p}back in the{p}storage room."
                    if debrafulbevalotmegkeresni1 >= 1:
                        if debrafulbevalotmegkeresni1 <= 2:
                            text "{color=000000}Search for Debra’s{p}earrings."
                    if debrafulbevalotmegkeresni1 == 3:
                        text "{color=000000}{s}Search for Debra’s{p}earrings."
                if regell6resz == False:
                    if lizanapaliabamehec == True:
                        if lizakertjekesz == 0:
                            text "{color=000000}Clean Liza’s{p}backyard."
                    if lizanapaliabamehec == True:
                        if lizakertjekesz == 1:
                            text "{color=000000}{s}Clean Liza’s{p}backyard."
                    if lizakertjefeledatok == 1:
                        if lizakertjedudvafelszedve == False:
                            text "{color=000000}Weed."
                        if lizakertjedudvafelszedve == True:
                            text "{color=000000}{s}Weed."
                        if lizakertjeszemetosszeszedve == False:
                            text "{color=000000}Pick up the trash."
                        if lizakertjeszemetosszeszedve == True:
                            text "{color=000000}{s}Pick up the trash."
                        if lizakertjelevelekosszeszedve == False:
                            text "{color=000000}Pick up the leaves."
                        if lizakertjelevelekosszeszedve == True:
                            text "{color=000000}{s}Pick up the leaves."
                        if gerebjekell == 1:
                            text "{color=000000}Find a rake."
                        if gerebjekell >= 1:
                            if gerebjenyel == 1:
                                if gerebjefej == 1:
                                    text "{color=000000}{s}Find a rake."
                        if lizakertjemadarhaza >= 1:
                            if lizakertjekerdeztezmadarhaz == True:
                                if lizakertjemadarhazaahejen == False:
                                    text "{color=000000}Fix the aviary."
                                if lizakertjemadarhazaahejen == True:
                                    text "{color=000000}{s}Fix the aviary."
                        if lizakertjemadarhaza >= 2:
                            if csavar6resz == 0:
                                text "{color=000000}Get the Screws."
                            if csavarhuzo6resz == 0:
                                text "{color=000000}Get the Screwdriver."
                        if lizakertjekesz >= 1:
                            text "{color=000000}Go home and sleep."
        if hanyadiknapvan == 7:
            vbox xpos 0.71 ypos 0.26:
                if penztkaszlizatol7resz == False:
                    text "{color=000000}Visit Liza and{p}get your money."
                if penztkaszlizatol7resz == True:
                    text "{color=000000}{s}Visit Liza and{p}get your money."
                if szerezegymobilt >= 0:
                    if szerezegymobilt <= 2:
                        text "{color=000000}Find a way to{p}know when{p}Mr. Baby appears{p}again by the ruins."
                if szerezegymobilt >= 3:
                    text "{color=000000}{s}Find a way to{p}know when{p}Mr. Baby appears{p}again by the ruins."
                if pulinapozoagya >= 1:
                    if pulinapozoagyakesz == False:
                        text "{color=000000}Repair the sunbed."
                if pulinapozoagyakesz == True:
                    text "{color=000000}{s}Repair the sunbed."
                if szenyesmizeria >= 1:
                    if kiteritesiproba >= 0:
                        if ruhakosarnaladtelemijenruhaval == "koszos":
                            text "{color=000000}Wash the laundry."
                        if ruhakosarnaladtelemijenruhaval == "semijen":
                            text "{color=000000}Wash the laundry."
                if ruhakosarnaladtelemijenruhaval == "vizes":
                    text "{color=000000}{s}Wash the laundry."
                if fojasokertfelemehtesz == False:
                    if szaritojo == False:
                        if kiteritesiproba >= 0:
                            if kiteritesiproba < 4:
                                text "{color=000000}Dry the wet clothes."
                if fojasokertfelemehtesz == True:
                    if szaritojo == False:
                        if kiteritesiproba >= 0:
                            if kiteritesiproba < 4:
                                text "{color=000000}Spread out the clothes."
                    if kiteritesiproba == 4:
                        text "{color=000000}{s}Spread out the clothes."
                if mamanyaklanc == 3:
                    if mamanyaklanczalogjegy <= 1:
                        text "{color=000000}Get back the necklace{p}from Svetlana."
                if mamanyaklanczalogjegy == 2:
                    text "{color=000000}{s}Get back the necklace{p}from Svetlana."
                if oblitosuveg >= 1:
                    if oblitosuveg < 3:
                        text "{color=000000}Find something slippery."
                if oblitosuveg == 3:
                    text "{color=000000}{s}Find something slippery."
        if hanyadiknapvan == 8:
            vbox xpos 0.71 ypos 0.26:
                if kenocspulinak == 0:
                    text "{color=000000}Go to Liza."
                if kenocspulinak >= 1:
                    text "{color=000000}{s}Go to Liza."
                if kenocspulinak >= 1:
                    if receptnalad == 0:
                        text "{color=000000}Find a home made{p}recipe against sunburn."
                if kenocspulinak >= 1:
                    if receptnalad >= 1:
                        text "{color=000000}{s}Find a home made{p}recipe against sunburn."
                if receptnalad >= 1:
                    if lizanakmegmutatadareceptet == False:
                        text "{color=000000}Find someone who{p}can read the recipe."
                if receptnalad >= 1:
                    if lizanakmegmutatadareceptet >= True:
                        text "{color=000000}{s}Find someone who{p}can read the recipe."
                if lizanakmegmutatadareceptet >= True:
                    if mozsarnalad < 2:
                        text "{color=000000}Find the ingredients{p}to the recipe.{p}Apply the cream{p}on Mr. Puli."
                    if mozsarnalad >= 2:
                        text "{color=000000}{s}Find the ingredients{p}to the recipe.{p}Apply the cream{p}on Mr. Puli."
                if debrautasit8reszkertben >= True:
                    if debrakert2dudva >= 1:
                        text "{color=000000}Pick up the weed{p}from the backyard."
                    else:
                        text "{color=000000}{s}Pick up the weed{p}from the backyard."
                    if debrakertje2bokorgaz == 1:
                        text "{color=000000}Clean the bushes{p}in the backyard."
                    else:
                        text "{color=000000}{s}Clean the bushes{p}in the backyard."
                    if debraholcsinal == "furdo":
                        if sokfol8resz == 1:
                            text "{color=000000}Rake the ground."
                        else:
                            text "{color=000000}{s}Rake the ground."
                            text "{color=000000}Go to sleep."
        if hanyadiknapvan == 9:
            vbox xpos 0.71 ypos 0.26:
                if ritamacskaja < 2:
                    if medencetkitakaritanidebramondja == True:
                        if debrakertje2medencekoszosviz == 1:
                            text "{color=000000}Get rid of the{p}dirty water."
                    if debrakertje2medencekoszosviz == 0:
                        text "{color=000000}{s}Get rid of the{p}dirty water."
                    if csovekkelenek9resz == True:
                        if debrakertje2medencekoszosviz == 1:
                            text "{color=000000}Find a downpipe{p}and a hose pipe."
                    if csovekkelenek9resz == 2:
                        text "{color=000000}{s}Find a downpipe{p}and a hose pipe."
                    if salgcsonalad == 1:
                        text "{color=000000}Repair the hose pipe{p}and put it on the{p}water supply."
                    if tapasznalad == 2:
                        text "{color=000000}{s}Repair the hose pipe{p}and put it on the{p}water supply."
                    if keresedjet == True:
                        if leengedocsofelveheted == False:
                            text "{color=000000}Search for „J”."
                    if leengedocsofelveheted == True:
                        text "{color=000000}{s}Search for „J”."
                    if debraszivacsotestisztitoszertker9resz == True:
                        if szivacsestisztitodebranal == False:
                            text "{color=000000}Find the sponge and{p}the detergent{p}for Debra."
                    if szivacsestisztitodebranal == True:
                        text "{color=000000}{s}Find the sponge and{p}the detergent{p}for Debra."
                if ritamacskaja == 1:
                    text "{color=000000}Give the cat to Rita."
                if ritamacskaja == 2:
                    text "{color=000000}{s}Give the cat to Rita."
                if fogjhalat == 1:
                    text "{color=000000}Catch a fish."
                if fogjhalat == 2:
                    text "{color=000000}{s}Catch a fish."
                if fogjhalat == 1:
                    if faagnalad >= 0:
                        if faagnalad < 2:
                            text "{color=000000}Build a fishing rod."
                if faagnalad == 2:
                    text "{color=000000}{s}Build a fishing rod."
                if annavalbeseltelparktonal >= 1:
                    if betadinnalad == 0:
                        text "{color=000000}Search for some{p}kind of disinfectant."
                    if betadinnalad >= 1:
                        text "{color=000000}{s}Search for some{p}kind of disinfectant."
                if debraholcsinal == "szobajabanmaszturbal9resz":
                    text "{color=000000}Call Debra."
                if debraholcsinal == "szobajaban":
                    text "{color=000000}Go to sleep."
        if hanyadiknapvan == 10:
            vbox xpos 0.71 ypos 0.26:
                if teremjelenetek <= 1:
                    text "{color=000000}Go to the university."
                if teremjelenetek >= 2:
                    text "{color=000000}{s}Go to the university."
                if kerjmunkatkerhec == True:
                    if adtalpenzdaginak10resz == False:
                        text "{color=000000}Find money and give{p}it to Puffy."
                    if adtalpenzdaginak10resz == True:
                        text "{color=000000}{s}Find money and give{p}it to Puffy."
                    if cottonnalad <= 1:
                        text "{color=000000}Meet Rita."
                    if cottonnalad == 2:
                        text "{color=000000}{s}Meet Rita."
                        text "{color=000000}Go to sleep."
        if hanyadiknapvan == 11:
            vbox xpos 0.71 ypos 0.26:
                if egyetemenvoltal11resz == 0:
                    text "{color=000000}Go to the university."
                if egyetemenvoltal11resz == 1:
                    text "{color=000000}{s}Go to the university."
                if svetlanajelnet11nap <= 1:
                    text "{color=000000}Help Svetlana."
                if svetlanajelnet11nap == 2:
                    text "{color=000000}{s}Help Svetlana."
                if debra11napfeladatotad == 1:
                    text "{color=000000}Change bulbs."
                if debra11napfeladatotad == 2:
                    text "{color=000000}{s}Change bulbs."
                if debra11napfeladatotad == 2:
                    if letranalad == 1:
                        text "{color=000000}Put the ladder{p}in the storage room."
                if letranalad == 2:
                    text "{color=000000}{s}Put the ladder{p}in the storage room."
                if letranalad == 2:
                    if cottonnalad > 0:
                        text "{color=000000}Put a condom{p}in the emergency box."
                if cottonnalad == 0:
                    text "{color=000000}{s}Put a condom{p}in the emergency box."
                    text "{color=000000}Go to sleep."
        if hanyadiknapvan == 12:
            vbox xpos 0.71 ypos 0.26:
                if egyetemenvoltal12resz == 0:
                    text "{color=000000}Go to the university."
                if egyetemenvoltal12resz == 1:
                    text "{color=000000}{s}Go to the university."
                if lizafehiv12nap == True:
                    if lizafehiv12napesbeszeltelvele == False:
                        text "{color=000000}Go to Liza."
                if lizafehiv12napesbeszeltelvele == True:
                    text "{color=000000}{s}Go to Liza"
                if lizafehiv12napesbeszeltelvele == True:
                    if sujzonalad < 2:
                        text "{color=000000}Pick up the dumbbells."
                    if sujzonalad == 2:
                        text "{color=000000}{s}Pick up the dumbbells."
                if kokonalad <= 1:
                    if debrafeladatotad12nap == 1:
                        text "{color=000000}Debra asked you to prepare{p}a flowerpot with onion,{p}put the pot on the corridor."
                    if debrafeladatotad12nap == 2:
                        text "{color=000000}{s}Debra asked you to prepare{p}a flowerpot with onion,{p}put the pot on the corridor."
                if debrafeladatotad12nap == 2:
                    if nap12estelegyen < 5:
                        text "{color=000000}Help people until{p}it gets dark."
                    if nap12estelegyen == 5:
                        text "{color=000000}{s}Help people until{p}it gets dark."
                if tanulhac12nap == 1:
                    text "{color=000000}Learn."
                if tanulhac12nap == 2:
                    text "{color=000000}{s}Learn."
                if sujzonalad == 2:
                    if kokonalad >= 1:
                        text "{color=000000}Deliver the drug{p}packages."
                    if kokonalad == 0:
                        text "{color=000000}{s}Deliver the drug{p}packages."
                        if lizavalszexeltel == True:
                            text "{color=000000}Go to sleep."













screen invertori2:
    hbox xpos 0.01 ypos 0.02:
        imagebutton:
            idle "invertori/invertori notesz.png"
        if penz >= 1:
            if penz <= 500:
                imagebutton:
                    idle "invertori/penz1azinvertoriban.png"
                    mouse "aktion"
        if penz >= 501:
            if penz <= 1000:
                imagebutton:
                    idle "invertori/penz2azinvertoriban.png"
                    mouse "aktion"
        if penz >= 1001:
            if penz <= 5000:
                imagebutton:
                    idle "invertori/penz3azinvertoriban.png"
                    mouse "aktion"
        if penz >= 5001:
            if penz <= 20000:
                imagebutton:
                    idle "invertori/penz3azinvertoriban.png"
                    mouse "aktion"
        if penz >= 20001:
            imagebutton:
                idle "invertori/penz2azinvertoriban.png"
                mouse "aktion"
        if hanyadiknapvan >= 4:
            if lopotfotokat == True:
                imagebutton:
                    idle "invertori/fotoazinvertoriban.png"
            if magazinvetem == True:
                imagebutton:
                    idle "invertori/magazinazinvertoriban.png"
        if hanyadiknapvan >= 7:
            if mobil == True:
                imagebutton:
                    idle "invertori/mobilazinvertoriban.png"
            if ruhakosarnalad == True:
                if ruhakosarnaladtele == False:
                    imagebutton:
                        idle "invertori/ruhakosarazinvertoriban.png"
            if ruhakosarnalad == True:
                if ruhakosarnaladtele == True:
                    imagebutton:
                        idle "invertori/ruhakosarteleazinvertoriban.png"
            if mosopor == True:
                imagebutton:
                    idle "invertori/invertori mosopor.png"
            if szemeteszsaknalad == True:
                if szemeteszak == 1:
                    imagebutton:
                        idle "invertori/kukaszsak1azinvertoriban.png"
                if szemeteszak == 2:
                    imagebutton:
                        idle "invertori/kukaszsak2azinvertoriban.png"
                if szemeteszak == 3:
                    imagebutton:
                        idle "invertori/kukaszsak3azinvertoriban.png"
                if szemeteszak >= 4:
                    imagebutton:
                        idle "invertori/kukaszsak4azinvertoriban.png"
        if hanyadiknapvan == 1:
            if szobakipakolas == True:
                if szoveguresdobozkidobva == False:
                    imagebutton:
                        idle "invertori/invertori doboz.png"
            if semeteszsakafoldon == True:
                if semeteszsakafoldonkidobva == False:
                    imagebutton:
                        idle "invertori/szemetazinvertoriban.png"
            if ujsagafoldon == True:
                if ujsagafoldonkidobva == False:
                    imagebutton:
                        idle "invertori/invertori ujsag.png"
            if szendvicsinvertoriba == True:
                if szendviamamanal == False:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
            if agynemukaptal == True:
                if agynemukosos == False:
                    imagebutton:
                        idle "invertori/invertori szenyes.png"
            if agynemukaptal == True:
                if agynemukosos == True:
                    if agynemuhejen == False:
                        imagebutton:
                            idle "invertori/invertori tiszta.png"
            if locsolokannafel == True:
                imagebutton:
                    idle "invertori/invertori locsolokanna.png"
            if mosopor == True:
                if agynemukosos == False:
                    imagebutton:
                        idle "invertori/invertori mosopor.png"
            if parnanalad == True:
                if agynemuhejen == False:
                    imagebutton:
                        idle "invertori/invertori parna.png"
        if hanyadiknapvan == 2:
            if fifitfelvetem == True:
                imagebutton:
                    idle "invertori/invertorififi.png"
            if szendvicsinvertoriba == True:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if szivacskoszoslett == 0:
                if torloszivacsnalad == True:
                    imagebutton:
                        idle "invertori/szivacs.png"
            if szivacskoszoslett > 0:
                if szivacskoszoslett < 6:
                    imagebutton:
                        idle "invertori/hugyosszivacs.png"
            if szivacskoszoslett > 5:
                if szivacskoszoslett < 12:
                    imagebutton:
                        idle "invertori/hugyosszivacs2.png"
            if mosopor == True:
                imagebutton:
                    idle "invertori/invertori mosopor.png"
            if szenyesnalad == True:
                if szenyeskimosva == False:
                    imagebutton:
                        idle "invertori/szennyes.png"
            if szenyeskimosva == True:
                if szenyeskimosvaahejen == False:
                    imagebutton:
                        idle "invertori/tiszta.png"
            if tvhoztak == True:
                if tvnapaliban == False:
                    imagebutton:
                        idle "invertori/invertoritv.png"
            if tvtaviranyitonalad == True:
                if tvtaviranyitomamanal == False:
                    imagebutton:
                        idle "invertori/invertoritaviranyito.png"
            if poharnalad == True:
                if urespoharnalad == False:
                    imagebutton:
                        idle "invertori/invertoripohar.png"
            if poharnalad == True:
                if urespoharnalad == True:
                    imagebutton:
                        idle "invertori/invertoripohar.png"
            if boritekazinvertoriba == True:
                if boritekmizeriamegoldva == False:
                    imagebutton:
                        idle "invertori/boritekazinvertoriban.png"
            if lopotfotokat == True:
                imagebutton:
                    idle "invertori/fotoazinvertoriban.png"
        if hanyadiknapvan == 3:
            if megetted == False:
                if vanszedvicsed2 >= 1:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                if vanszedvicsed2 >= 2:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                if uditosmagamhozveni == 1:
                    imagebutton:
                        idle "invertori/uditoazinvertoriban.png"
                if lopotfotokat == True:
                    imagebutton:
                        idle "invertori/fotoazinvertoriban.png"
            if kaveamamanakkesz == False:
                if megkaptadavizeskancsot == True:
                    if vizeskancsovizes == False:
                        imagebutton:
                            idle "invertori/vizeskancsoazinvertoriban.png"
                if megkaptadavizeskancsot == True:
                    if vizeskancsovizes == True:
                        imagebutton:
                            idle "invertori/vizeskancsovizesazinvertoriban.png"
            if kutyatalakonyhaban == True:
                if kutyatalaltelenalad == False:
                    imagebutton:
                        idle "invertori/kutyataluazinvertoriban.png"
            if kutyatalaltelenalad == True:
                if fifienikap == False:
                    imagebutton:
                        idle "invertori/kutyataltazinvertoriban.png"
            if kavefrednel == True:
                if kaveazasztalon == False:
                    imagebutton:
                        idle "invertori/kaveazinvertoriban.png"
            if kaveazasztalrolinvertoriba == True:
                if harmadikreszkonyha == 1:
                    imagebutton:
                        idle "invertori/kavecseszeazinvertoriban.png"
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
            if mosopor == True:
                imagebutton:
                    idle "invertori/invertori mosopor.png"
            if szenyesnalad == True:
                if szenyeskimosva == False:
                    imagebutton:
                        idle "invertori/szennyes.png"
            if szenyeskimosva == True:
                if szenyeskimosvaahejen == False:
                    imagebutton:
                        idle "invertori/tiszta.png"
            if tejetvetem == True:
                if tejetlerektam == False:
                    imagebutton:
                        idle "invertori/tejazinvertoriban.png"
            if nyalokavetem == True:
                if nyalokatodaadtam == False:
                    imagebutton:
                        idle "invertori/nyalokavertoriban.png"
            if magazinvetem == True:
                imagebutton:
                    idle "invertori/magazinazinvertoriban.png"
        if hanyadiknapvan == 4:
            if vanszedvicsed2 >= 1:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if vanszedvicsed2 >= 2:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if uditosmagamhozveni == 1:
                imagebutton:
                    idle "invertori/uditocolaazinvertoriban.png"
            if kaveamamanakkesz == False:
                if megkaptadavizeskancsot == True:
                    if vizeskancsovizes == False:
                        imagebutton:
                            idle "invertori/vizeskancsoazinvertoriban.png"
                if megkaptadavizeskancsot == True:
                    if vizeskancsovizes == True:
                        imagebutton:
                            idle "invertori/vizeskancsovizesazinvertoriban.png"
            if kutyatalfojasojobb == False:
                if kutyatalaltelenalad == False:
                    imagebutton:
                        idle "invertori/kutyataluazinvertoriban.png"
            if kutyatalaltelenalad == True:
                if fifienikap == False:
                    imagebutton:
                        idle "invertori/kutyataltazinvertoriban.png"
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
            if mosopor == True:
                imagebutton:
                    idle "invertori/invertori mosopor.png"
            if szenyesnalad == True:
                if szenyeskimosva == False:
                    imagebutton:
                        idle "invertori/szennyes.png"
            if szenyeskimosva == True:
                if szenyeskimosvaahejen == False:
                    imagebutton:
                        idle "invertori/tiszta.png"
            if debratolkenyeretkerni == 2:
                if nincskenyeraszedvicshez == True:
                    imagebutton:
                        idle "invertori/kenyerazinvertoriban.png"
            if kutyatap == True:
                if kutyatapkibontva == False:
                    imagebutton:
                        idle "invertori/kutyakonzevazinvertoriban.png"
            if konzevnyito == True:
                if kutyatapkibontva == False:
                    imagebutton:
                        idle "invertori/konzevnyitoazinvertoriban.png"
            if dagitmegharaptafifi == 1:
                if debratolelsosegej == 2:
                    imagebutton:
                        idle "invertori/betedinazinvertoriban.png"
        if hanyadiknapvan == 5:
            if regell5resz == True:
                if vanszedvicsed2 >= 1:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                if vanszedvicsed2 >= 2:
                    imagebutton:
                        idle "invertori/invertori szedvics.png"
                if uditosmagamhozveni == 1:
                    imagebutton:
                        idle "invertori/uditocolaazinvertoriban.png"
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
            if zsacskonalad == 2:
                imagebutton:
                    idle "invertori/zacskotisztaazinvertoriban.png"
            if zsacskonalad == 3:
                if kakitfeltakaritani == 1:
                    imagebutton:
                        idle "invertori/zacsikoszosazinvertoriban.png"
            if szivacskoszoslett == 0:
                if torloszivacsnalad == True:
                    imagebutton:
                        idle "invertori/szivacs.png"
            if szivacskoszoslett > 0:
                if szivacskoszoslett < 6:
                    imagebutton:
                        idle "invertori/hugyosszivacs.png"
            if szivacskoszoslett > 5:
                if szivacskoszoslett < 12:
                    imagebutton:
                        idle "invertori/hugyosszivacs2.png"
            if felmosotvenni == 2:
                imagebutton:
                    idle "invertori/felmosoazinvertoriban.png"
            if szemetettkidobni5resz == 2:
                imagebutton:
                    idle "invertori/szemetazinvertoriban.png"
            if lampatkidobni5resz >= 2:
                if lampatkidobni5resz < 3:
                    imagebutton:
                        idle "invertori/lampaazinvertoriban.png"
            if kolduskulacsa == 2:
                imagebutton:
                    idle "invertori/falskaazinvertoriban.png"
            if lizagyurulye == 3:
                imagebutton:
                    idle "invertori/lizagyuruazinvertoriban.png"
        if hanyadiknapvan == 6:
            if porszivofelveni == 1:
                imagebutton:
                    idle "invertori/porszivoazinvertoriban.png"
            if debrafulbevalo1 == 1:
                imagebutton:
                    idle "invertori/anyakereszt1azinvertoriban.png"
            if debrafulbevalo2 == 1:
                imagebutton:
                    idle "invertori/anyakereszt2azinvertoriban.png"
            if mamanyaklanc == 1:
                imagebutton:
                    idle "invertori/keresztnyaklancazinvertoriban.png"
            if gerebjenyel == 0:
                if gerebjefej == 1:
                    imagebutton:
                        idle "invertori/gerebjefejazinvertoriban.png"
            if gerebjenyel == 1:
                if gerebjefej == 0:
                    imagebutton:
                        idle "invertori/gerebjenyelazinvertoriban.png"
            if gerebjenyel == 1:
                if gerebjefej == 1:
                    imagebutton:
                        idle "invertori/gerebjeazinvertoriban.png"
            if lizakertjekukaszsakotkaptal == True:
                if lizaszemeteszakja == 1:
                    imagebutton:
                        idle "invertori/kukaszsak1azinvertoriban.png"
                if lizaszemeteszakja == 2:
                    imagebutton:
                        idle "invertori/kukaszsak2azinvertoriban.png"
                if lizaszemeteszakja == 3:
                    imagebutton:
                        idle "invertori/kukaszsak3azinvertoriban.png"
                if lizaszemeteszakja >= 4:
                    imagebutton:
                        idle "invertori/kukaszsak4azinvertoriban.png"
                if lizakertjemadarhaza == 2:
                    imagebutton:
                        idle "invertori/madarhazazinvertoriban.png"
                if csavar6resz == 1:
                    imagebutton:
                        idle "invertori/csavarokazinvertoriban.png"
                if csavarhuzo6resz == 1:
                    imagebutton:
                        idle "invertori/csavarhuzoazinvertoriban.png"
        if hanyadiknapvan == 7:
            if tu == 1:
                imagebutton:
                    idle "invertori/tuazinvertoriban.png"
            if cerna == 1:
                imagebutton:
                    idle "invertori/cernaazinvertoriban.png"
            if vaszon1 == 1:
                imagebutton:
                    idle "invertori/vaszon1azinvertoriban.png"
            if vaszon2 == 1:
                imagebutton:
                    idle "invertori/vaszon2azinvertoriban.png"
            if kiskendofurdoben == False:
                if kiskendolizanal == False:
                    imagebutton:
                        idle "invertori/lizakendojeazinvertoriban.png"
            if debraviragcserepe == 1:
                imagebutton:
                    idle "invertori/viragcserepazinvertoriban.png"
            if mamanyaklanczalogjegy == 2:
                imagebutton:
                    idle "invertori/zalogjegyazinvertoriban.png"
            if metszoollo == 2:
                imagebutton:
                    idle "invertori/metszoolloazinvertoriban.png"
            if fifitfelvetem == True:
                imagebutton:
                    idle "invertori/invertorififi.png"
            if madzagveheto == 2:
                imagebutton:
                    idle "invertori/ruhaszaritomadzagazinvertoriban.png"
            if svetlanaermeje == 1:
                imagebutton:
                    idle "invertori/ermeazinvertoriban.png"
            if oblitosuveg == 2:
                imagebutton:
                    idle "invertori/oblitoazinvertoriban.png"
        if hanyadiknapvan == 8:
            if mamanyaklanczalogjegy == 2:
                imagebutton:
                    idle "invertori/zalogjegyazinvertoriban.png"
            if invertorieszkozszam <= 5:
                if receptnalad == 1:
                    imagebutton:
                        idle "invertori/napegesreceptazinvertoriban.png"
                if uditosmagamhozveni == 1:
                    imagebutton:
                        idle "invertori/uditoazinvertoriban.png"
                if gombanalad == 1:
                    imagebutton:
                        idle "invertori/gombaazinvertoriban.png"
                if rovarirtonalad == 1:
                    imagebutton:
                        idle "invertori/rovaroloazinvertoriban.png"
                if poknalad == 1:
                    imagebutton:
                        idle "invertori/pokazinvertoriban.png"
                if tojasnalad == 1:
                    imagebutton:
                        idle "invertori/tojasazinvertoriban.png"
                if gyongyviragnalad == 1:
                    imagebutton:
                        idle "invertori/gyongyviragazinvertoriban.png"
                if tulipannalad == 1:
                    imagebutton:
                        idle "invertori/tulipanazinvertoriban.png"
                if lizaviragnalad == 1:
                    imagebutton:
                        idle "invertori/lizaviragazinvertoriban.png"
                if elesztonalad == 1:
                    imagebutton:
                        idle "invertori/elesztoazinvertoriban.png"
                if mozsarnalad == 1:
                    imagebutton:
                        idle "invertori/mozsarazinvertoriban.png"
            if invertorieszkozszam >= 6:
                if invertorimutateleje > 1:
                    imagebutton:
                        idle "invertori/ballraazinvertoriban.png"
                if invertorimutateleje == 1:
                    if receptnalad == 1:
                        imagebutton:
                            idle "invertori/napegesreceptazinvertoriban.png"
                if invertorimutateleje >= 1:
                    if invertorimutavege < 7:
                        if uditosmagamhozveni == 1:
                            imagebutton:
                                idle "invertori/uditoazinvertoriban.png"
                if invertorimutateleje >= 1:
                    if invertorimutavege < 8:
                        if gombanalad == 1:
                            imagebutton:
                                idle "invertori/gombaazinvertoriban.png"
                if invertorimutateleje >= 1:
                    if invertorimutavege < 9:
                        if rovarirtonalad == 1:
                            imagebutton:
                                idle "invertori/rovaroloazinvertoriban.png"
                if invertorimutateleje >= 1:
                    if invertorimutavege < 9:
                        if poknalad == 1:
                            imagebutton:
                                idle "invertori/pokazinvertoriban.png"
                if invertorimutateleje >= 2:
                    if invertorimutavege < 10:
                        if tojasnalad == 1:
                            imagebutton:
                                idle "invertori/tojasazinvertoriban.png"
                if invertorimutateleje >= 3:
                    if invertorimutavege < 11:
                        if gyongyviragnalad == 1:
                            imagebutton:
                                idle "invertori/gyongyviragazinvertoriban.png"
                if invertorimutateleje >= 4:
                    if invertorimutavege < 12:
                        if tulipannalad == 1:
                            imagebutton:
                                idle "invertori/tulipanazinvertoriban.png"
                if invertorimutateleje >= 5:
                    if invertorimutavege < 13:
                        if lizaviragnalad == 1:
                            imagebutton:
                                idle "invertori/lizaviragazinvertoriban.png"
                if invertorimutateleje >= 6:
                    if invertorimutavege < 14:
                        if elesztonalad == 1:
                            imagebutton:
                                idle "invertori/elesztoazinvertoriban.png"
                if invertorimutateleje >= 7:
                    if invertorimutavege < 15:
                        if mozsarnalad == 1:
                            imagebutton:
                                idle "invertori/mozsarazinvertoriban.png"
                if targyazinvertoriban >= 1:
                    imagebutton:
                        idle "invertori/jobbra1azinvertoriban.png"
            if tisztitoszernalad == 1:
                imagebutton:
                    idle "invertori/tisztitoszerazinvertoriban.png"
            if tapasznalad == 1:
                imagebutton:
                    idle "invertori/tapaszazinvertoriban.png"
            if gerebjenalad == 1:
                imagebutton:
                    idle "invertori/gerebjeazinvertoriban.png"
            if metszoollonalad == 1:
                imagebutton:
                    idle "invertori/metszoolloazinvertoriban.png"
        if hanyadiknapvan == 9:
            if mamanyaklanczalogjegy == 2:
                imagebutton:
                    idle "invertori/zalogjegyazinvertoriban.png"
            if szivacsnalad == 1:
                imagebutton:
                    idle "invertori/szivacs.png"
            if festekoldonalad == 1:
                imagebutton:
                    idle "invertori/festekoldoazinvertoriban.png"
            if tisztitoszernalad == 1:
                imagebutton:
                    idle "invertori/tisztitoszerazinvertoriban.png"
            if tapasznalad == 1:
                imagebutton:
                    idle "invertori/tapaszazinvertoriban.png"
            if metszoollonalad == 1:
                imagebutton:
                    idle "invertori/metszoolloazinvertoriban.png"
            if faagnalad >= 1:
                if faagnalad < 3:
                    imagebutton:
                        if faagnalad == 1:
                            idle "invertori/faagazinvertoriban.png"
                        if faagnalad == 2:
                            idle "invertori/faagpecabotazinvertoriban.png"
            if horognalad == 1:
                imagebutton:
                    idle "invertori/horogazinvertoriban.png"
            if gilisztanalad >= 1:
                if gilisztanalad < 3:
                    imagebutton:
                        if gilisztanalad == 2:
                            idle "invertori/giliszta2azinvertoriban.png"
                        if gilisztanalad == 1:
                            idle "invertori/giliszta1azinvertoriban.png"
            if salgcsonalad == 1:
                imagebutton:
                    idle "invertori/slagcsoazinvertoriban.png"
            if leengedonalad == 1:
                imagebutton:
                    idle "invertori/leengedocsoazinvertoriban.png"
            if poharnalad2 == 1:
                imagebutton:
                    idle "invertori/invertoripohar.png"
            if kutyatalnalad == 1:
                imagebutton:
                    if kutyatalban == "semmi":
                        idle "invertori/kutyataluazinvertoriban.png"
                    if kutyatalban == "kutyakaja":
                        idle "invertori/kutyataltazinvertoriban.png"
                    if kutyatalban == "tej":
                        idle "invertori/kutyataltejesazinvertoriban.png"
                    if kutyatalban == "hal":
                        idle "invertori/kutyatalhallalazinvertoriban.png"
            if tejnalad == 1:
                imagebutton:
                    idle "invertori/tej2azinvertoriban.png"
            if szedvicsnalad == 1:
                imagebutton:
                    idle "invertori/invertori szedvics2.png"
            if halnalad == 1:
                imagebutton:
                    idle "invertori/halazinvertoriban.png"
            if gyufanalad == 1:
                imagebutton:
                    idle "invertori/gyufaazinvertoriban.png"
            if agfuresznalad == 1:
                imagebutton:
                    idle "invertori/agfureszazinvertoriban.png"
            if madzagveheto == 2:
                imagebutton:
                    idle "invertori/ruhaszaritomadzagazinvertoriban.png"
            if betadinnalad == 1:
                imagebutton:
                    idle "invertori/betedinazinvertoriban.png"
            if macskanalad == 1:
                imagebutton:
                    idle "invertori/macskaazinvertoriban.png"
        if hanyadiknapvan == 10:
            if vanszedvicsed2 >= 1:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if vanszedvicsed2 >= 2:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if uditosmagamhozveni == 1:
                imagebutton:
                    idle "invertori/uditocolaazinvertoriban.png"
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
            if ladatmegtalalhatod == 1:
                imagebutton:
                    idle "invertori/ladaazinvertoriban.png"
            if karkotonalad == 1:
                imagebutton:
                    idle "invertori/karkotoazinvertoriban.png"
            if festekoldonalad == 1:
                imagebutton:
                    idle "invertori/festekoldoazinvertoriban.png"
            if metszoollonalad == 1:
                imagebutton:
                    idle "invertori/metszoolloazinvertoriban.png"
            if gyufanalad == 1:
                imagebutton:
                    idle "invertori/gyufaazinvertoriban.png"
            if spaklinalad == 1:
                imagebutton:
                    idle "invertori/spakliazinvertoriban.png"
            if fagylaltoknalad == 1:
                imagebutton:
                    idle "invertori/fagylaltokazinvertoriban.png"
            if cottonnalad == 1:
                imagebutton:
                    idle "invertori/kottonazinvertoriban.png"
        if hanyadiknapvan == 11:
            if vanszedvicsed2 >= 1:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if vanszedvicsed2 >= 2:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if uditosmagamhozveni == 1:
                imagebutton:
                    idle "invertori/uditocolaazinvertoriban.png"
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
            if nyomortanyakoszosruhanalad == 1:
                imagebutton:
                    if oroszruha == "koszos":
                        idle "invertori/oroszruhakoszosazinvertoriban.png"
                    else:
                        idle "invertori/oroszruhatisztaazinvertoriban.png"
            if nyomortanyadoboz1nalad == 1:
                imagebutton:
                    idle "invertori/svetlanadoboz1azinvertoriban.png"
            if nyomortanyadoboz2nalad == 1:
                imagebutton:
                    idle "invertori/svetlanadoboz2azinvertoriban.png"
            if nyomortanyadoboz3nalad == 1:
                imagebutton:
                    idle "invertori/svetlanadoboz3azinvertoriban.png"
            if oroszkonyvnalad == 1:
                imagebutton:
                    idle "invertori/oroszszotarazinvertoriban.png"
            if boriszfenykepenalad == 1:
                imagebutton:
                    idle "invertori/oroszfotoazinvertoriban.png"
            if mubajuszkell == 2:
                imagebutton:
                    idle "invertori/alszakalazinvertoriban.png"
            if rozsaknalad == 1:
                imagebutton:
                    idle "invertori/rozsakazinvertoriban.png"
            if ragasztonalad == 1:
                imagebutton:
                    idle "invertori/ragasztoazinvertoriban.png"
            if letranalad == 1:
                imagebutton:
                    idle "invertori/letraazinvertoriban.png"
            if izzoknalad == 1:
                imagebutton:
                    idle "invertori/izzokazinvertoriban.png"
            if cottonnalad == 1:
                imagebutton:
                    idle "invertori/kottonazinvertoriban.png"
            if csacsikalapjanalad == 1:
                imagebutton:
                    idle "invertori/csacsikalapazinvertoriban.png"
        if hanyadiknapvan == 12:
            if vanszedvicsed2 >= 1:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if vanszedvicsed2 >= 2:
                imagebutton:
                    idle "invertori/invertori szedvics.png"
            if uditosmagamhozveni == 1:
                imagebutton:
                    idle "invertori/uditocolaazinvertoriban.png"
            if taskafel == 2:
                imagebutton:
                    idle "invertori/taskaazinvertoriban.png"
            if oroszkonyvnalad == 1:
                imagebutton:
                    idle "invertori/oroszszotarazinvertoriban.png"
            if boriszfenykepenalad == 1:
                imagebutton:
                    idle "invertori/oroszfotoazinvertoriban.png"
            if sujzonalad == 1:
                imagebutton:
                    idle "invertori/sujzoazinvertoriban.png"
            if kokonalad >= 1:
                imagebutton:
                    if kokonalad == 1:
                        idle "invertori/kokain1azinvertoriban.png"
                    if kokonalad == 2:
                        idle "invertori/kokain2azinvertoriban.png"
                    if kokonalad == 3:
                        idle "invertori/kokain3azinvertoriban.png"
                    if kokonalad == 4:
                        idle "invertori/kokain4azinvertoriban.png"
                    if kokonalad == 5:
                        idle "invertori/kokain5azinvertoriban.png"
            if asonallad == 1:
                imagebutton:
                    idle "invertori/asoazinvertoriban.png"
            if komposztnallad == 1:
                imagebutton:
                    idle "invertori/komposztazinvertoriban.png"
            if viraghagymanallad == 1:
                imagebutton:
                    idle "invertori/viraghagymaazinvertoriban.png"
            if mamakenocsenalad == 1:
                imagebutton:
                    idle "invertori/mamakenocseazinvertoriban.png"
            if viragcserepnalad2 == 1:
                imagebutton:
                    idle "invertori/beultetetviragazinvertoriban.png"
            if kittyszemetenalad == 1:
                imagebutton:
                    idle "invertori/szemet2azinvertoriban.png"
            if cottonnalad == 1:
                imagebutton:
                    idle "invertori/kottonazinvertoriban.png"
            if feltoltokartyanalad == 1:
                imagebutton:
                    idle "invertori/feltoltokartyaazinvertoriban.png"
            if regiegernalad == 1:
                imagebutton:
                    idle "invertori/egerazinvertoriban.png"
            if girosznalad == 1:
                imagebutton:
                    idle "invertori/girosazinvertoriban.png"



screen invertoriszov:
    vbox xpos 0.5 yalign 0.2 xalign 0.5:
        if szoveguresdoboz == True:
            text "{color=000000}Empty box, I need to throw this out.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveguresdoboz', False)
        if szovegureszsakhoz == True:
            text "{color=000000}A garbage bag. I need to throw this in the trash can.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegureszsakhoz', False)
        if szoveguresujsaghoz == True:
            text "{color=000000}Put the newspaper in the living room.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveguresujsaghoz', False)
        if szovegszedvicshez == True:
            if hanyadiknapvan >= 3:
                text "{color=000000}The sandwich.":
                    xalign 0.5
                timer 2.0 repeat True action SetVariable('szovegszedvicshez', False)
            if hanyadiknapvan < 3:
                text "{color=000000}A nice sandwich for Grandma.":
                    xalign 0.5
                timer 2.0 repeat True action SetVariable('szovegszedvicshez', False)
        if szovegszenyeshez == True:
            text "{color=000000}I need to wash the dirty sheet.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegszenyeshez', False)
        if szovegtisztahozhez == True:
            text "{color=000000}This is clean. I can make my bed.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegtisztahozhez', False)
        if szoveglocsolokanahoz == True:
            text "{color=000000}Water can. I fill the can when I am in the bathroom.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveglocsolokanahoz', False)
        if szovegmosoporhoz == True:
            text "{color=000000}Washing powder.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegmosoporhoz', False)
        if szovegparna == True:
            text "{color=000000}Pillow for my bed.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegparna', False)
        if szovegfifi == True:
            text "{color=000000}Fifi does not like me.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegfifi', False)
        if szovegfiuszenyeshez == True:
            text "{color=000000}Laundry, I should wash it.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegfiuszenyeshez', False)
        if szovegfiutisztaruha == True:
            text "{color=000000}Clean dress, I should put it in my room.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegfiutisztaruha', False)
        if szovegszivacshoz == True:
            text "{color=000000}Clean sponge.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegszivacshoz', False)
        if szovegkososszivacshoz == True:
            if hanyadiknapvan <= 4:
                text "{color=000000}Dirty sponge with a lot of pee! Jack!{p}I should clean it in the bathroom.":
                    xalign 0.5
            if hanyadiknapvan == 5:
                text "{color=000000}Dirty sponge with a lot of pee! Jack!{p}I should clean it in the kitchem.":
                    xalign 0.5
            if hanyadiknapvan > 5:
                text "{color=000000}Dirty sponge with a lot of pee! Jack!{p}I should clean it in the bathroom."
            timer 2.0 repeat True action SetVariable('szovegkososszivacshoz', False)
        if szovegtvhoz == True:
            text "{color=000000}A heavy television.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegtvhoz', False)
        if szovegtvtaviranyitohoz == True:
            text "{color=000000}Controller.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegtvtaviranyitohoz', False)
        if szovegtelepoharhoz == True:
            text "{color=000000}A nice drink.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegtelepoharhoz', False)
        if szovegurespoharhoz == True:
            text "{color=000000}Empty, dirty glass.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegurespoharhoz', False)
        if szovegboritekomhoz == True:
            text "{color=000000}Envelope. I should give it to Debra.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegboritekomhoz', False)
        if szovegfotohoz == True:
            text "{color=000000}Sexy photos of Debra.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegfotohoz', False)
        if szoveguditohoz == True:
            if hanyadiknapvan == 3:
                text "{color=000000}100 % juice.":
                    xalign 0.5
            if hanyadiknapvan >= 4:
                text "{color=000000}Cola drink.":
                    xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveguditohoz', False)
        if szovegvizeskancohoz == True:
            if vizeskancsovizes == False:
                text "{color=000000}Water jug-empty.":
                    xalign 0.5
                timer 2.0 repeat True action SetVariable('szovegvizeskancohoz', False)
            if vizeskancsovizes == True:
                text "{color=000000}Water jug-filled.":
                    xalign 0.5
                timer 2.0 repeat True action SetVariable('szovegvizeskancohoz', False)
        if szovegureskutyatalhoz == True:
            text "{color=000000}Empty dog bowl.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegureskutyatalhoz', False)
        if szovegtelekutyatalhoz == True:
            text "{color=000000}Dog bowl with food... what a nice smell...":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegtelekutyatalhoz', False)
        if szovegkavehoz == True:
            if kaveazasztalrolinvertoriba == False:
                text "{color=000000}Coffee.":
                    xalign 0.5
                timer 2.0 repeat True action SetVariable('szovegkavehoz', False)
            if kaveazasztalrolinvertoriba == True:
                text "{color=000000}Coffee for Grandma.":
                    xalign 0.5
                timer 2.0 repeat True action SetVariable('szovegkavehoz', False)
        if szovegtaskahoz == True:
            text "{color=000000}My bag. The only thing I had by me when our house blew up...":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegtaskahoz', False)
        if szovegpenzhoz == True:
            text "{color=000000}Money(Forint): [penz]Ft.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegpenzhoz', False)
        if szovegtejhoz == True:
            text "{color=000000}Milk.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegtejhoz', False)
        if szovegnyalokahoz == True:
            text "{color=000000}Lollipop.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegnyalokahoz', False)
        if szovegpornomagazinhoz == True:
            text "{color=000000}Porn Magazine.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegpornomagazinhoz', False)
        if szovegkenyerhez == True:
            text "{color=000000}Put the bread in the kitchen.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegkenyerhez', False)
        if szovegkutyataphoz == True:
            if debrakutyatapboltban < 3:
                text "{color=000000}Give Fifif the dog food (in the kitchen).":
                    xalign 0.5
            if debrakutyatapboltban >= 3:
                text "{color=000000}Give Fifif the dog food (in the kitchen). You need a can opener.":
                    xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegkutyataphoz', False)
        if szovegkonzevnyitohoz == True:
            text "{color=000000}Can opener.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegkonzevnyitohoz', False)
        if szovegbetadinhoz == True:
            text "{color=000000}Disinfectant and bandage.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegbetadinhoz', False)
        if szovegzacskohoz == True:
            if zsacskonalad == 2:
                text "{color=000000}Rubbish bag.":
                    xalign 0.5
            if zsacskonalad == 3:
                text "{color=000000}Rubbish bag full with shit.":
                    xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegzacskohoz', False)
        if szovegfelmosohoz == True:
            text "{color=000000}A new mop for Debra. I should put it in the storage room.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegfelmosohoz', False)
        if szoveglampahoz == True:
            text "{color=000000}An old, dirty lamp. I think Svetlana will love this.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveglampahoz', False)
        if szoveglizagyuruhoz == True:
            text "{color=000000}Liza’s ring.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveglizagyuruhoz', False)
        if szovegbutykoshoz == True:
            text "{color=000000}Brandy bottle.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegbutykoshoz', False)
        if szovegporszivohozhoz == True:
            text "{color=000000}Vacuum cleaner.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegporszivohozhoz', False)
        if szovegszulbevalohoz == True:
            text "{color=000000}Earring.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegszulbevalohoz', False)
        if szovegnyaklanchoz == True:
            text "{color=000000}Necklace.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegnyaklanchoz', False)
        if szoveggerebjefejhoz == True:
            text "{color=000000}Rake head.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveggerebjefejhoz', False)
        if szoveggerebjehoz == True:
            text "{color=000000}Rake.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveggerebjehoz', False)
        if szoveggerebjenyelhoz == True:
            text "{color=000000}Rake handle.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveggerebjenyelhoz', False)
        if szoveglizaszemeteszsakhoz == True:
            if lizaszemeteszakja == 1:
                text "{color=000000}Strong garbage.":
                    xalign 0.5
            if lizaszemeteszakja == 2:
                text "{color=000000}Strong garbage and trash.":
                    xalign 0.5
            if lizaszemeteszakja == 3:
                text "{color=000000}Strong garbage almost filled with trash.":
                    xalign 0.5
            if lizaszemeteszakja >= 4:
                text "{color=000000}Strong garbage filled with trash.":
                    xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveglizaszemeteszsakhoz', False)
        if szoveglizamadarhahoz == True:
            text "{color=000000}Aviary.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szoveglizamadarhahoz', False)
        if szovegcsavarhoz == True:
            text "{color=000000}Screws.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegcsavarhoz', False)
        if szovegcsavarhuzohoz == True:
            text "{color=000000}Screwdriver.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegcsavarhuzohoz', False)
        if szovegtuhuzohoz == True:
            text "{color=000000}Sewing needle.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegtuhuzohoz', False)
        if szovegcernahoz == True:
            text "{color=000000}Thread.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegcernahoz', False)
        if szovegvaszon1huzohoz == True:
            text "{color=000000}Canvas.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegvaszon1huzohoz', False)
        if szovegvaszon2huzohoz == True:
            text "{color=000000}Big old Towel.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegvaszon2huzohoz', False)
        if szovegkiskendohoz == True:
            text "{color=000000}Towel.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegkiskendohoz', False)
        if szovegmobilhoz == True:
            text "{color=000000}My mobile phone.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegmobilhoz', False)
        if szovegruhakosarhoz == True:
            if ruhakosarnaladtele == True:
                if ruhakosarnaladtelemijenruhaval == "koszos":
                    text "{color=000000}Clothes basket and dirty clothes.":
                        xalign 0.5
            if ruhakosarnaladtele == True:
                if ruhakosarnaladtelemijenruhaval == "vizes":
                    text "{color=000000}Clothes basket and wet clothes.":
                        xalign 0.5
            if ruhakosarnaladtele == True:
                if ruhakosarnaladtelemijenruhaval == "tiszta":
                    text "{color=000000}Clothes basket and clean clothes.":
                        xalign 0.5
            if ruhakosarnaladtele == False:
                text "{color=000000}Clothes basket.":
                    xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegruhakosarhoz', False)
        if szovegviragcserephoz == True:
            text "{color=000000}Flowerpot.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegviragcserephoz', False)
        if szovegzalogjegyhoz == True:
            text "{color=000000}Pawnshop ticket.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegzalogjegyhoz', False)
        if szovegmetszoollohoz == True:
            text "{color=000000}Secateurs.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegmetszoollohoz', False)
        if szovegmadzaghoz == True:
            text "{color=000000}Clothesline":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegmadzaghoz', False)
        if szovegermehoz == True:
            text "{color=000000}Coin":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegermehoz', False)
        if szovegoblitohoz == True:
            text "{color=000000}Rinse aid":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegoblitohoz', False)
        if szovegrecepthoz == True:
            if lizanakmegmutatadareceptet == False:
                text "{color=000000}I can not read this.":
                    xalign 0.5
                    text_align 0.5
            if lizanakmegmutatadareceptet == True:
                text "{color=000000}{p}{p}Recipe against sunburn.{p}Egg{p}Dry yeaster{p}Orange juice{p}Tulip{p}Hyacinth{p}White palmack flower{p}Mushroom{p}Spider{p}Put the ingredients in a bowl and crumble them{p}until you can apply the cream easy...":
                    xalign 0.5
                    text_align 0.5
            timer 4.0 repeat True action SetVariable('szovegrecepthoz', False)
        if szovegtulipanhoz == True:
            text "{color=000000}Tulip.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegtulipanhoz', False)
        if szoveggyongyviraghoz == True:
            text "{color=000000}Hyacinth.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szoveggyongyviraghoz', False)
        if szoveglizaviraghoz == True:
            text "{color=000000}White palmack flower.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szoveglizaviraghoz', False)
        if szovegmozsarhoz == True:
            text "{color=000000}Bowl with the cream.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegmozsarhoz', False)
        if szovegrovarirtohoz == True:
            text "{color=000000}Insecticide spray.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegrovarirtohoz', False)
        if szovegtojashoz == True:
            text "{color=000000}Egg.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegtojashoz', False)
        if szovegelesztohoz == True:
            text "{color=000000}Dry yeaster.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegelesztohoz', False)
        if szovegpokhoz == True:
            text "{color=000000}Spider.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegpokhoz', False)
        if szovegtisztitoszerhoz == True:
            text "{color=000000}detergent":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegtisztitoszerhoz', False)
        if szovegtapaszhoz == True:
            text "{color=000000}Sticking plasters.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegtapaszhoz', False)
        if szoveggombahoz == True:
            text "{color=000000}Mushroom.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szoveggombahoz', False)
        if szovegnaracslehoz == True:
            text "{color=000000}Orange juice.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegnaracslehoz', False)
        if festekoldohoz == True:
            text "{color=000000}Paint remover.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('festekoldohoz', False)
        if faaghoz == True:
            if faagnalad == 1:
                text "{color=000000}Strong branch.":
                    xalign 0.5
                    text_align 0.5
            if faagnalad == 2:
                text "{color=000000}Selfmade fishing rod.":
                    xalign 0.5
                    text_align 0.5
            timer 2.0 repeat True action SetVariable('faaghoz', False)
        if horoghoz == True:
            text "{color=000000}Hook.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('horoghoz', False)
        if gilisztahoz == True:
            if gilisztanalad == 1:
                text "{color=000000}A worm.":
                    xalign 0.5
                    text_align 0.5
            if gilisztanalad == 2:
                text "{color=000000}2 Worms.":
                    xalign 0.5
                    text_align 0.5
            timer 2.0 repeat True action SetVariable('gilisztahoz', False)
        if salgcsohoz == True:
            text "{color=000000}Hose pipe with a lot of holes.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('salgcsohoz', False)
        if leengedohoz == True:
            text "{color=000000}Downpipe.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('leengedohoz', False)
        if poharhoz == True:
            if poharbanban == "semmi":
                text "{color=000000}Empty glass.":
                    xalign 0.5
                    text_align 0.5
            if poharbanban == "vizes":
                text "{color=000000}A glass of water.":
                    xalign 0.5
                    text_align 0.5
            timer 2.0 repeat True action SetVariable('poharhoz', False)
        if kutyatalhoz == True:
            if kutyatalban == "semmi":
                text "{color=000000}Empty dog bowl.":
                    xalign 0.5
                    text_align 0.5
            if kutyatalban == "kutyakaja":
                text "{color=000000}Dog bowl with dog food.":
                    xalign 0.5
                    text_align 0.5
            if kutyatalban == "tej":
                text "{color=000000}Dog bowl with milk.":
                    xalign 0.5
                    text_align 0.5
            if kutyatalban == "hal":
                text "{color=000000}Dog bowl with fish.":
                    xalign 0.5
                    text_align 0.5
            timer 2.0 repeat True action SetVariable('kutyatalhoz', False)
        if tejhoz == True:
            text "{color=000000}Mlik.":
                xalign 0.5
                text_align 0.5
            if kutyatalban == "kutyakaja":
                text "{color=000000}I can not put it in the bowl. The bowl is full.":
                    xalign 0.5
                    text_align 0.5
            timer 2.0 repeat True action SetVariable('tejhoz', False)
        if szedvicshoz == True:
            text "{color=000000}Sandwich.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szedvicshoz', False)
        if halhoz == True:
            text "{color=000000}Fresh fish.":
                xalign 0.5
                text_align 0.5
            if kutyatalban == "tej":
                text "{color=000000}I can not put it in the bowl. The bowl is full.":
                    xalign 0.5
                    text_align 0.5
            timer 2.0 repeat True action SetVariable('halhoz', False)
        if gyufahoz == True:
            text "{color=000000}Matches.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('gyufahoz', False)
        if agfureszhoz == True:
            text "{color=000000}Branch saw.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('agfureszhoz', False)
        if szovegmacskahoz == True:
            text "{color=000000}Debra talks at sleep.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegmacskahoz', False)
        if szovegfagyihoz == True:
            text "{color=000000}Ice cream.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegfagyihoz', False)
        if szovegcottonhoz == True:
            text "{color=000000}Condom.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegcottonhoz', False)
        if szovegladahoz == True:
            text "{color=000000}An old dirty box.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegladahoz', False)
        if szovegspaklihoz == True:
            text "{color=000000}Spatula.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegspaklihoz', False)
        if szovegkarkotohoz == True:
            text "{color=000000}A Bracelet.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegkarkotohoz', False)
        if szovegoroszruhahoz == True:
            if oroszruha == "koszos":
                text "{color=000000}Old dress of Boris. It is dirty.":
                    xalign 0.5
                    text_align 0.5
            if oroszruha == "vizes":
                text "{color=000000}The old dress is wet. I have to dry it fast.":
                    xalign 0.5
                    text_align 0.5
            if oroszruha == "tiszta":
                text "{color=000000}Old dress of Boris.":
                    xalign 0.5
                    text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegoroszruhahoz', False)
        if szovegosvetlanadobozaihoz == True:
            text "{color=000000}The boksz of Svetlana.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegosvetlanadobozaihoz', False)
        if szovegooroszszorarhoz == True:
            text "{color=000000}Russian dictionary.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegooroszszorarhoz', False)
        if szovegmubajuszhoz == True:
            if ragasztonalad == 0:
                text "{color=000000}An artificial mustache. How should I fix it on my face?":
                    xalign 0.5
                    text_align 0.5
                if ragasztokell == False:
                    timer 0.1 repeat True action SetVariable('ragasztokell', True)
            if ragasztonalad == 1:
                text "{color=000000}Artificial mustache.":
                    xalign 0.5
                    text_align 0.5
            timer 3.0 repeat True action SetVariable('szovegmubajuszhoz', False)
        if szovegrozsakhoz == True:
            text "{color=000000}Roses.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegrozsakhoz', False)
        if szovegragasztohoz == True:
            text "{color=000000}Glue.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegragasztohoz', False)
        if szovegizzohoz == True:
            text "{color=000000}Working bulbs.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegizzohoz', False)
        if szovegletrahoz == True:
            text "{color=000000}Ladder.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegletrahoz', False)
        if szovegcsacsikalaphoz == True:
            text "{color=000000}This would be good for the donkey.":
                xalign 0.5
            timer 2.0 repeat True action SetVariable('szovegcsacsikalaphoz', False)
        if szovegsujzohoz == True:
            text "{color=000000}dumbbells.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegsujzohoz', False)
        if szovegkokohoz == True:
            text "{color=000000}Drug.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegkokohoz', False)
        if szovegasohoz == True:
            text "{color=000000}A borrowed spade.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegasohoz', False)
        if szovegkomposzthoz == True:
            text "{color=000000}Compost soil.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegkomposzthoz', False)
        if szoveghagymahoz == True:
            text "{color=000000}Onion of a flower.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szoveghagymahoz', False)
        if szovegmamakenocshoz == True:
            text "{color=000000}Cream.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegmamakenocshoz', False)
        if szovegviragvaza2hoz == True:
            text "{color=000000}Flowerpot, planted.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegviragvaza2hoz', False)
        if szovegszemethoz == True:
            text "{color=000000}Trash.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegszemethoz', False)
        if szovegfeltoltohoz == True:
            text "{color=000000}A phonecard. The amount is 1500 Forints. Now I can make a call.":
                xalign 0.5
                text_align 0.5
            timer 4.0 repeat True action SetVariable('szovegfeltoltohoz', False)
            if feltoltokartyanalad == 1:
                timer 2.0 repeat True action SetVariable('feltoltokartyanalad', feltoltokartyanalad + 1)
        if szovegegerhoz == True:
            text "{color=000000}Mouse for PC.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szovegegerhoz', False)
        if szoveggiroszhoz == True:
            text "{color=000000}Gyros.":
                xalign 0.5
                text_align 0.5
            timer 2.0 repeat True action SetVariable('szoveggiroszhoz', False)
    vbox xpos 0.5 ypos 0.2 xalign 0.5:
        if hanyadiknapvan == 11:
            if szovegboriszfotohoz == True:
                text "{color=000000}Let us see… This is Boris... A big cap, russian coat, mustache and beard... Typical Russian male…":
                    xalign 0.5
                    text_align 0.5
                imagemap:
                    idle "11/boriszfoto.png"
                    xalign 0.5
                if boriszfenykepenezted == False:
                    timer 0.5 repeat True action SetVariable('boriszfenykepenezted', True)
                if boriszfenykepenezted == True:
                    if beszelteledittel == True:
                        if nyomortanyakoszosruhanalad >= 1:
                            text "{color=000000}I look a bit like Boris. How about dressing like him?":
                                xalign 0.5
                                text_align 0.5
                timer 3.0 repeat True action SetVariable('szovegboriszfotohoz', False)
        if hanyadiknapvan == 12:
            if szovegboriszfotohoz == True:
                imagemap:
                    idle "11/boriszfoto.png"
                    xalign 0.5
                text "{color=000000}I look a bit like Boris.":
                    xalign 0.5
                    text_align 0.5
                timer 3.0 repeat True action SetVariable('szovegboriszfotohoz', False)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
