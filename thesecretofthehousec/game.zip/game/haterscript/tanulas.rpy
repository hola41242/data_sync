label ferdtanuljon:
    if hanyadiknapvan == 12:
        if tanulhac12nap == 2:
            f "már tanultam szerintem eléglesz majd még tanulok később."
            $ renpy. pause(hard=True)
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    $ csinalszvalamit = "Tanul"
    jump tiltasok
label ferdtanuljonszov:
    if hanyadiknapvan == 12:
        $ tanulhac12nap = 2
        jump tanulkep
    show screen mittanuljak
$ renpy. pause(hard=True)
label tanulmatek:
    $ csinalszvalamit = "tanulmatek"
    show screen ferdtanul
    jump tanulkep
$ renpy. pause(hard=True)
label tanulepit:
    $ csinalszvalamit = "tanulepit"
    show screen ferdtanul
    jump tanulkep
$ renpy. pause(hard=True)
label tanultori:
    $ csinalszvalamit = "tanultori"
    show screen ferdtanul
    jump tanulkep
$ renpy. pause(hard=True)
label tanuloros:
    $ csinalszvalamit = "tanuloros"
    show screen ferdtanul
    jump tanulkep
$ renpy. pause(hard=True)
label tanulkep:
    play music "audio/alap.ogg" fadeout 1
    show fiutanul:
        alpha 0.0
        linear 2.0 alpha 1.0
    if hanyadiknapvan == 12:
        hide screen atjaro
        hide screen poszterekgomjai
        hide screen poszterekkepei
        hide invertori onlayer elotte6
        hide screen invertori2
        hide screen invertori
        if poszterafalon1 == False:
            show poszterbal:
                xpos 0.0
                ypos 0.76
        if poszterafalon2 == False:
            show poszterkozep:
                xpos 0.0
                ypos 0.76
        if poszterafalon3 == False:
            show poszterjobb:
                xpos 0.0
                ypos 0.76
        if poszterafalon1 == True:
            show fauna2falon:
                xpos 0.225
                ypos 0.3
        if poszterafalon2 == True:
            show faunafalon:
                xpos 0.56
                ypos 0.158
        if poszterafalon3 == True:
            show petykafalon:
                xpos 0.08
                ypos 0.3
        show screen s3
        u ""
        show fekete onlayer screens:
            alpha 0.0
            linear 1.0 alpha 1.0
        play sound "audio/telofelvesz.wav"
        show screen s3
        u ""
        show atjarohomajos
        show fredtelefonal:
            xpos 0.2
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        f "Hallo!"
        r "Hy! This is me! I am your Love! Rita… I just called you."
        f "I didn't even notice… What do you want?"
        r "Do you miss me?"
        f "Nope. I saw you at the university… It was enough for today."
        r "Oh, you are so funny! Letus meet somewhere!"
        f "Where?"
        r "Let us meet in the park. Bring me a condom please! I want you!"
        f "Ok. I will be right there…"
        $ ritaholvan = "parkbanpadon"
        show atjarohomajos:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fredtelefonal:
            xpos 0.2
            alpha 1.0
            linear 1.0 alpha 0.0
        hide fiutanul
        $ fekete = True
        play music "audio/banyabolt.ogg" fadeout 1
        jump engedejek
    if hanyadiknapvan == 11:
        hide screen atjaro
        hide screen poszterekgomjai
        hide screen poszterekkepei
        hide invertori onlayer elotte6
        hide screen invertori2
        hide screen invertori
        if poszterafalon1 == False:
            show poszterbal:
                xpos 0.0
                ypos 0.76
        if poszterafalon2 == False:
            show poszterkozep:
                xpos 0.0
                ypos 0.76
        if poszterafalon3 == False:
            show poszterjobb:
                xpos 0.0
                ypos 0.76
        if poszterafalon1 == True:
            show fauna2falon:
                xpos 0.225
                ypos 0.3
        if poszterafalon2 == True:
            show faunafalon:
                xpos 0.56
                ypos 0.158
        if poszterafalon3 == True:
            show petykafalon:
                xpos 0.08
                ypos 0.3
        show screen s10
        u ""
        hide screen ferdtanul
        show atjarokozeli2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrakosztumbenmoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrakosztumbenmoz1pislog onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        show debrakosztumbenmoz1beszed onlayer elotte
        d "Hy! Idiot! What are you learning?"
        hide debrakosztumbenmoz1beszed onlayer elotte
        f "I am learning a few words in russian."
        show debrakosztumbenmoz1beszed onlayer elotte
        d "Why? Do you learn Russian at university?"
        hide debrakosztumbenmoz1beszed onlayer elotte
        f "No. I help out a friend. "
        show debrakosztumbenmoz1beszed onlayer elotte
        d "Is your friend a girl?"
        hide debrakosztumbenmoz1beszed onlayer elotte
        f "Well, she is a girl, I mean a kind of woman."
        hide debrakosztumbenmoz1 onlayer elotte
        hide debrakosztumbenmoz1pislog onlayer elotte
        show debrakosztumbenanimfel onlayer elotte
        show screen s1
        u ""
        show debrakosztumbenmoz5beszed onlayer elotte
        d "Well… Do you like older women?"
        hide debrakosztumbenmoz5beszed onlayer elotte
        f "I do not know. I never thought of it that way… I think age is not really important."
        f "The most important thing about a woman is to look good."
        show debrakosztumbenmoz5beszed onlayer elotte
        d "Tell this to Grandma… She thinks she will never get old and cases after young boys…"
        hide debrakosztumbenmoz5beszed onlayer elotte
        f "I know. She has a kind of relationship with Puffy and she is cocetating with me sometimes…"
        hide debrakosztumbenanimfel onlayer elotte
        show debrakosztumbenanimle onlayer elotte
        show screen s1
        u ""
        show debrakosztumbenmoz1beszed onlayer elotte
        hide debrakosztumbenmoz1pislog onlayer elotte
        show debrakosztumbenmoz1pislog onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 0.0
            alpha 1.0
        d "Keep an eye on her! She might get pregnant and she will ask you to marry her…"
        hide debrakosztumbenmoz1beszed onlayer elotte
        f "I do not think she can get pregnant anymore…"
        show debrakosztumbenmoz1beszed onlayer elotte
        d "You are a total Idiot! Anyone can fool you, yerk! The old bitch has a lot of tricks… Anyway… Do you help for free or for money?"
        hide debrakosztumbenmoz1beszed onlayer elotte
        f "She will pay me."
        show debrakosztumbenmoz1beszed onlayer elotte
        d "I understand… Could you repair the drying machine with the money?"
        hide debrakosztumbenmoz1beszed onlayer elotte
        if mosogepjo == False:
            f "We will see. I will try my best because it is really uncomfortable to use the clothes dryer in the garden."
            show debrakosztumbenmoz1beszed onlayer elotte
            d "Yeap, and on the top of it, someone stole the clothesline."
            hide debrakosztumbenmoz1beszed onlayer elotte
            f "Oh... well… I was it! I needed the clothesline…"
        if mosogepjo == True:
            f "I will fix it in no time…"
            show debrakosztumbenmoz1beszed onlayer elotte
            d "Yeap, and on the top of it, someone stole the clothesline..."
            hide debrakosztumbenmoz1beszed onlayer elotte
            f "Oh... well… I was it! I needed the clothesline…"
        hide debrakosztumbenmoz1pislog onlayer elotte
        hide debrakosztumbenanimle onlayer elotte
        hide debrakosztumbenanimfel onlayer elotte
        show debrakosztumbenanimfel onlayer elotte
        show screen s1
        u ""
        show debrakosztumbenmoz5beszed onlayer elotte
        d "I thought so… I have something to do. I leave you with your russian book. I will be in my working room."
        hide debrakosztumbenmoz5beszed onlayer elotte
        f "Ok. Where have you been? You look awesome!"
        show debrakosztumbenmoz5beszed onlayer elotte
        d "Thank you for your compliment but you have nothing to do with my stuff. I am going now. Bye!"
        hide debrakosztumbenmoz5beszed onlayer elotte
        show screen ferdtanul
        hide debrakosztumbenanimfel onlayer elotte
        show debrakosztumbenmoz5 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show atjarokozeli2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        $ debraholcsinal = "dolgozo"
        $ oroszultanultal = True
        show screen s10
        u ""
        if oroszultanultal == True:
            if oroszruha == "tiszta":
                if ragasztonalad == 1:
                    f "I can dress in now. I will do it."
                    jump beoltozikfred11nap



        show screen poszterekgomjai
        show screen poszterekkepei
        show invertori onlayer elotte6:
            ypos 0.0
        show screen invertori
        jump tanulabahagy


$ renpy. pause(hard=True)
label tanulabahagy:
    $ fekete = True
    hide screen mittanuljak
    hide screen ferdtanul
    if hanyadiknapvan == 3:
        if Tanulnimatematikaido == 0:
            $ Tanulnimatematika3resz = True
        if Tanulniepiteszetido == 0:
            $ Tanulniepiteszet3resz = True
        if Tanulnitortenelemido == 0:
            $ Tanulnitortenelem3resz = True
        if Tanulnimatematika3resz == True:
            if Tanulniepiteszet3resz == True:
                if Tanulnitortenelem3resz == True:
                    $ nemtanulhatsztobbet3resz = True
    if hanyadiknapvan == 2:
        if Tanulnimatematika == 1:
            if Tanulniepiteszet == 1:
                if Tanulnitortenelem == 1:
                    $ nemtanulhatsztobbet = True
    show fiutanul:
        alpha 1.0
        linear 2.0 alpha 0.0
    play music "audio/banyabolt.ogg" fadeout 1
    jump engedejek
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
