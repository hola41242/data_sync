label kavetkeszit:
    $ csinalszvalamit = "kavet"
    jump tiltasok
$ renpy. pause(hard=True)
label kavetkeszitszov:
    if debraholcsinal == "konyhaeszik":
        hide debrakonyhabaneszikanim onlayer hatso
        hide debrakonyhabaneszikalap onlayer hatso
    hide konyhazoldelol onlayer elotte
    show konyhazoldelol
    hide screen invertori2
    hide invertori onlayer elotte6
    if hanyadiknapvan >= 4:
        $ megkaptadavizeskancsot = True

    show kavefozoosszeszereles
    if kavehaznalatiut == 0:
        show kavefozoosszeszereleshasznal
    if kavefrednel == True:
        $ kaveazasztalon = True
        show kavefozoosszeszereleskave
    if megkaptadavizeskancsot == True:
        show kavefozoosszeszerelesvizeskocsog:
            zoom 0.65
            xpos 0.38
            ypos 0.15
    if vizeskancsovizes == True:
        show kavefozoosszeszerelesvizeskocsogvize:
            zoom 0.65
            xpos 0.38
            ypos 0.15
    if felszerelszurotarto == False:
        show kavefozoosszeszerelesszorotartolent
    show kavefozoosszeszerelesszedo onlayer hatso
    if felszereliakupakot == False:
        show kavefozoosszeszereleskupaklent
    if felszereliakupakot == True:
        show kavefozoosszeszereleskupakfent
    if felszereliaszurot == False:
        show kavefozoosszeszerelesszurolent onlayer hatso
    if kaveahejen == True:
        show kavefozoosszeszerelesszurolentkave onlayer hatso1
        if felszereliaszurot == True:
            hide kavefozoosszeszerelesszurolentkave onlayer hatso1
            show zacosszuroazedenyben onlayer hatso1
    if felszereliaszurot == True:
        show szuroazedenyben onlayer hatso
    if felszerelszurotarto == True:
        show kavefozoosszeszerelesszorotartofent
        if felszereliaszurot == True:
            hide szuroazedenyben onlayer hatso
            hide zacosszuroazedenyben onlayer hatso1
    if megkaptadakavekiontott == True:
        if akavekiontohejen == False:
            show kavefozoosszeszereleskionto2:
                zoom 1.1
                ypos 0.25
    if akavekiontohejen == True:
        show kavefozoosszeszereleskionto



    show screen kavefozo
$ renpy. pause(hard=True)
label hasznalatiutmutatoolvas:
    $ kavefozobekapcsolva = True
    $ kavehaznalatiut = 1
    show kavejelalap onlayer hatso
    show kavejelalapfredk9 onlayer hatso
    show kavejelalapdebrak8 onlayer hatso
    pause 1.0
    f "First step.: remove the packaging…"
    f "Second step: Check to…"
    hide kavefozoosszeszereleshasznal
    pause 2.0
    d "Are you kidding me? This is a long list! Will you read it all? It will take hours!"
    d "Throw that shit away and put the damn machine together! I do not have a day to do this!"
    f "As you wish!"
    show kavejelalap onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    show kavejelalapfredk9 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    show kavejelalapdebrak8 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    $ kavehaznalatiut = 2
    hide kavejelalap onlayer hatso
    hide kavejelalapfredk9 onlayer hatso
    hide kavejelalapdebrak8 onlayer hatso
    $ kavefozobekapcsolva = False
$ renpy. pause(hard=True)
label felszereliaszurotartot:
    $ felszerelszurotarto = True
    $ kavefozoheztettel = True
    hide kavefozoosszeszerelesszorotartolent
    show kavefozoosszeszerelesszorotartolent:
        alpha 1.0
        linear 1.0 alpha 0.0
    show kavefozoosszeszerelesszorotartofent:
        alpha 0.0
        linear 1.0 alpha 1.0
    if felszereliaszurot == True:
        show szuroazedenyben onlayer hatso:
            alpha 1.0
            linear 1.0 alpha 0.0
        if kaveahejen == True:
            show zacosszuroazedenyben onlayer hatso1:
                alpha 1.0
                linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label felszereliaszurot:
    $ felszereliaszurot = True
    $ kavefozoheztettel = True
    hide kavefozoosszeszerelesszurolent onlayer hatso
    show kavefozoosszeszerelesszurolent onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    if kaveahejen == True:
        show kavefozoosszeszerelesszurolentkave onlayer hatso1:
            alpha 1.0
            linear 1.0 alpha 0.0
    show szuroazedenyben onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    if kaveahejen == True:
        show zacosszuroazedenyben onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0


$ renpy. pause(hard=True)
label felszereliakupakot:
    $ felszereliakupakot = True
    $ kavefozoheztettel = True
    hide kavefozoosszeszereleskupaklent
    hide kavefozoosszeszereleskupakfent
    show kavefozoosszeszereleskupaklent:
        alpha 1.0
        linear 1.0 alpha 0.0
    show kavefozoosszeszereleskupakfent:
        alpha 0.0
        linear 1.0 alpha 1.0


$ renpy. pause(hard=True)
label szetszedkavefozo:
    $ kavefozoheztettel = False
    if felszerelszurotarto == True:
        $ felszerelszurotarto = False
        hide kavefozoosszeszerelesszorotartolent
        hide kavefozoosszeszerelesszorotartofent
        show kavefozoosszeszerelesszorotartolent:
            alpha 0.0
            linear 1.0 alpha 1.0
        show kavefozoosszeszerelesszorotartofent:
            alpha 1.0
            linear 1.0 alpha 0.0
    if felszereliaszurot == True:
        if kaveahejen == True:
            show kavefozoosszeszerelesszurolentkave onlayer hatso1:
                alpha 0.0
                linear 1.0 alpha 1.0
        $ felszereliaszurot = False
        hide kavefozoosszeszerelesszurolent onlayer hatso
        show kavefozoosszeszerelesszurolent onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 1.0
        show szuroazedenyben onlayer hatso:
            alpha 1.0
            linear 1.0 alpha 0.0
        if kaveahejen == True:
            show zacosszuroazedenyben onlayer hatso1:
                alpha 1.0
                linear 1.0 alpha 0.0

    if felszereliakupakot == True:
        $ felszereliakupakot = False
        hide kavefozoosszeszereleskupaklent
        hide kavefozoosszeszereleskupakfent
        show kavefozoosszeszereleskupaklent:
            alpha 0.0
            linear 1.0 alpha 1.0
        show kavefozoosszeszereleskupakfent:
            alpha 1.0
            linear 1.0 alpha 0.0
    if akavekiontohejen == True:
        $ akavekiontohejen = False
        show kavefozoosszeszereleskionto2:
            zoom 1.1
            ypos 0.25
            alpha 0.0
            linear 1.0 alpha 1.0
        show kavefozoosszeszereleskionto:
            alpha 1.0
            linear 1.0 alpha 0.0

$ renpy. pause(hard=True)
label kiontotahejere:
    $ akavekiontohejen = True
    show kavefozoosszeszereleskionto2:
        zoom 1.1
        ypos 0.25
        alpha 1.0
        linear 1.0 alpha 0.0
    show kavefozoosszeszereleskionto:
        alpha 0.0
        linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
label zacotasurobe:
    $ kaveahejen = True
    if felszereliaszurot == False:
        show kavefozoosszeszerelesszurolentkave onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
    if felszereliaszurot == True:
        show zacosszuroazedenyben onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
label bekapcsol1:
    $ kavefozobekapcsolva = True
    if megkaptadavizeskancsot == False:
        show kavejelalap onlayer hatso
        show kavejelalaposzetett onlayer hatso
        show kavejelalapfredk11 onlayer hatso1
        if hanyadiknapvan == 3:
            show kavejelalapdebrak10 onlayer hatso
        pause 1.0
        f "Le tus push this button and it will be ready in no time!"
        d "Let us see!"
        pause 5.0
        d "Nothing happened… we should have the sound at least!"
        f "The water should boil... Well I did not put in water! That is it!"
        d "Try again genius!"
        d "I will give you water now. If you need more go and bring some yourself!"
        hide kavejelalap onlayer hatso
        hide kavejelalaposzetett onlayer hatso
        hide kavejelalapfredk11 onlayer hatso1
        hide kavejelalapdebrak10 onlayer hatso
        $ kavefozobekapcsolva = False
        $ vizeskancsovizes = True
        $ megkaptadavizeskancsot = True
        show kavefozoosszeszerelesvizeskocsog:
            zoom 0.65
            xpos 0.38
            ypos 0.15
        show kavefozoosszeszerelesvizeskocsogvize:
            zoom 0.65
            xpos 0.38
            ypos 0.15
        $ renpy. pause(hard=True)
    if megkaptadavizeskancsot == True:
        show kavejelalap onlayer hatso
        show kavejelalaposzetett onlayer hatso
        show kavejelalapfredk11 onlayer hatso1
        if hanyadiknapvan == 3:
            show kavejelalapdebrak10 onlayer hatso
        pause 1.0
        f "I forgot to put water in it again…"
        hide kavejelalap onlayer hatso
        hide kavejelalaposzetett onlayer hatso
        hide kavejelalapfredk11 onlayer hatso1
        hide kavejelalapdebrak10 onlayer hatso
        $ kavefozobekapcsolva = False

$ renpy. pause(hard=True)
label kaveviszetbetolteni:
    if felszereliakupakot == True:
        f "The bottle cap is on, I can not fill the machine with water this way. I need to take it down first."
        $ renpy. pause(hard=True)
    $ vizakavefozoben = True
    $ vizeskancsovizes = False
    show kavefozoosszeszerelesvizeskocsogvize:
        alpha 1.0
        linear 1.0 alpha 0.0


$ renpy. pause(hard=True)
label bekapcsol2:
    $ kavefozobekapcsolva = True
    if megkaptadakavekiontott == True:
        if akavekiontohejen == False:
            show kavejelalap onlayer hatso
            show kavejelalaposzetett onlayer hatso
            show kavejelalapfredk11 onlayer hatso1
            if hanyadiknapvan == 3:
                show kavejelalapdebrak10 onlayer hatso
            pause 1.0
            play sound "audio/coffee.wav"
            show screen s3
            u ""
            play sound "audio/vizkicsap.wav"
            show kavejelalapfredk11 onlayer hatso1:
                alpha 1.0
                linear 0.5 alpha 0.0
            show kavejelalapfredk13 onlayer hatso1:
                alpha 0.0
                linear 0.5 alpha 1.0
            with vpunch
            f "ARGHHH!!! HOOOOOOT!!!"
            show kavejelalapfredk11 onlayer hatso1:
                alpha 0.0
                linear 0.5 alpha 1.0
            show kavejelalapfredk13 onlayer hatso1:
                alpha 1.0
                linear 0.5 alpha 0.0
            pause 1.0
            hide kavejelalap onlayer hatso
            hide kavejelalapdebrak10 onlayer hatso
            hide kavejelalaposzetett onlayer hatso
            hide kavejelalapfredk11 onlayer hatso1
            hide kavejelalapfredk11 onlayer hatso1
            hide kavejelalapfredk13 onlayer hatso1
            $ kavefozobekapcsolva = False
            $ vizakavefozoben = False
            $ renpy. pause(hard=True)
    if megkaptadakavekiontott == False:
        show kavejelalap onlayer hatso
        show kavejelalaposzetett onlayer hatso
        show kavejelalapfredk11 onlayer hatso1
        if hanyadiknapvan == 3:
            show kavejelalapdebrak10 onlayer hatso
        pause 1.0
        f "Let us push this button and it will be ready in no time!"
        d "Let us see!"
        play sound "audio/coffee.wav"
        show screen s3
        u ""
        play sound "audio/vizkicsap.wav"
        show kavejelalapfredk11 onlayer hatso1:
            alpha 1.0
            linear 0.5 alpha 0.0
        show kavejelalapfredk13 onlayer hatso1:
            alpha 0.0
            linear 0.5 alpha 1.0
        with vpunch
        f "ARGHHH!!! HOOOOOOT!!!"
        show kavejelalapfredk11 onlayer hatso1:
            alpha 0.0
            linear 0.5 alpha 1.0
        show kavejelalapfredk13 onlayer hatso1:
            alpha 1.0
            linear 0.5 alpha 0.0
        pause 1.0
        d "You should put a bowl under first, idiot!"
        f "Ok… where is it?"
        d "I saw some on the top of the kitchen cabinet. Come, help me, I will get it down."
        d "You are too short. I will climb up and take it. Hold me safe!"
        f "Ok!"
        show fekete onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.0
        show kavejelalapfredk21 onlayer hatso1
        hide fekete onlayer hatso1
        show fekete onlayer hatso1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s2
        u ""
        play music "audio/baszosalap.ogg" fadeout 1
        hide kavejelalap onlayer hatso
        hide kavejelalaposzetett onlayer hatso
        hide kavejelalapfredk11 onlayer hatso1
        hide kavejelalapdebrak10 onlayer hatso
        hide kavejelalapfredk11 onlayer hatso1
        hide kavejelalapfredk13 onlayer hatso1
        show kavesegtapik20 onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 2.0
        d "Could you please stop tickling my thighs? "
        f "I thought you were afraid and I only wanted to reassure you."
        d "I am not afraid. Catch me if I fall! What an asshole you are!"
        $ megkaptadakavekiontott = True
        hide kavejelalapfredk21 onlayer hatso1
        show fredszomorutapiz3resz onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        hide kavesegtapik20 onlayer hatso1
        show kavefozoosszeszereleskionto2:
            zoom 1.1
            ypos 0.25
        show fredszomorutapiz3resz onlayer hatso1:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        play music "audio/banyabolt.ogg" fadeout 1
        hide fekete onlayer hatso1
        hide kavesegtapik20 onlayer hatso1
    $ kavefozobekapcsolva = False
    $ vizakavefozoben = False

$ renpy. pause(hard=True)
label bekapcsol3:
    $ kavefozobekapcsolva = True
    if lefottaviz == True:
        show kavejelalap onlayer hatso
        show kavejelalaposzetett onlayer hatso
        show kavejelalapfredk11 onlayer hatso1
        show kavejelalapkionto onlayer hatso
        if hanyadiknapvan == 3:
            show kavejelalapdebrak10 onlayer hatso
        pause 1.0
        play sound "audio/coffee.wav"
        f "Now we get a tasty coffee for sure…"
        show screen s3
        u ""
        show kavejelalapkiontoviz onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 2.0
        show kavejelalapkiontoviz onlayer hatso:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        f "I will get rid of the clear water first."
        hide kavejelalap onlayer hatso
        hide kavejelalaposzetett onlayer hatso
        hide kavejelalapfredk11 onlayer hatso1
        hide kavejelalapkionto onlayer hatso
        hide kavejelalapdebrak10 onlayer hatso
        hide kavejelalapkiontoviz onlayer hatso
        hide kavejelalapkiontoviz onlayer hatso
    if lefottaviz == False:
        show kavejelalap onlayer hatso
        show kavejelalaposzetett onlayer hatso
        show kavejelalapfredk11 onlayer hatso1
        show kavejelalapkionto onlayer hatso
        if hanyadiknapvan == 3:
            show kavejelalapdebrak10 onlayer hatso
        pause 1.0
        f "Now we get a tasty coffee for sure…"
        d "Let us see! Let us see my genius."
        play sound "audio/coffee.wav"
        show screen s3
        u ""
        show kavejelalapkiontoviz onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 2.0
        d "Call me a bitch, but i think coffee is black…."
        f "Yeah,I forgot something... The ground coffee!"
        d "Do not look at me. I don't know where it is. Grandma puts coffee somewhere every time and she yells at me to take it away…"
        f "I will look for it now."
        show kavejelalapkiontoviz onlayer hatso:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        f "I will get rid of the clear water first."
        hide kavejelalap onlayer hatso
        hide kavejelalaposzetett onlayer hatso
        hide kavejelalapfredk11 onlayer hatso1
        hide kavejelalapkionto onlayer hatso
        hide kavejelalapdebrak10 onlayer hatso
        hide kavejelalapkiontoviz onlayer hatso
        hide kavejelalapkiontoviz onlayer hatso
        $ lefottaviz = True

    $ kavefozobekapcsolva = False
    $ vizakavefozoben = False

$ renpy. pause(hard=True)
label bekapcsol4:
    $ kavefozobekapcsolva = True
    show kavejelalap onlayer hatso
    show kavejelalaposzetett onlayer hatso
    show kavejelalapfredk11 onlayer hatso1
    show kavejelalapkionto onlayer hatso
    if hanyadiknapvan == 3:
        show kavejelalapdebrak10 onlayer hatso
    pause 1.0
    f "Now we get a tasty coffee for sure…"
    if hanyadiknapvan == 3:
        d "Let us see! Let us see my genius."
    play sound "audio/coffee.wav"
    show screen s3
    u ""
    show kavejelalapkiontokave onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    f "Now nothing is missing to make a great coffee!"
    if hanyadiknapvan == 3:
        d "Yeah, you are Fantastic… I will get you a cup and you should give the coffee to Grandma."
    show kavejelalapkiontokave onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 2.0
    $ kaveazasztalon2 = True
    $ kaveamamanakkesz = True
    if hanyadiknapvan == 3:
        $ debraholcsinal = "dolgozo"
    show konyhakave
    hide kavejelalapkiontokave onlayer hatso
    hide kavejelalap onlayer hatso
    hide kavejelalaposzetett onlayer hatso
    hide kavejelalapfredk11 onlayer hatso1
    hide kavejelalapkionto onlayer hatso
    hide kavejelalapdebrak10 onlayer hatso
    hide kavejelalapkiontoviz onlayer hatso
    hide kavejelalapkiontoviz onlayer hatso
    $ kavefozobekapcsolva = False
    $ vizakavefozoben = False
    if hanyadiknapvan == 4:
        $ mamakave = 2
    hide screen kavefozo
    jump kavefozoki
$ renpy. pause(hard=True)
label kavefozoki:

    hide kavefozoosszeszereles
    hide kavefozoosszeszereleshasznal
    hide kavefozoosszeszerelesszorotartolent
    hide kavefozoosszeszerelesszedo onlayer hatso
    hide kavefozoosszeszereleskupaklent
    hide kavefozoosszeszerelesszurolent onlayer hatso
    hide kavefozoosszeszerelesvizeskocsog
    hide kavefozoosszeszerelesvizeskocsogvize
    hide kavefozoosszeszerelesszorotartofent
    hide kavefozoosszeszerelesszurolentkave onlayer hatso1
    hide kavefozoosszeszereleskave
    hide kavefozoosszeszereleshasznal
    hide kavefozoosszeszereleskionto
    hide kavefozoosszeszereleskionto2
    hide kavefozoosszeszereleskupakfent
    hide szuroazedenyben onlayer hatso
    hide zacosszuroazedenyben onlayer hatso1
    if felszereliaszurot == True:
        if akavekiontohejen == False:
            show konyhaalapgepalatetnekul
    if akavekiontohejen == True:
        show konyhaalapgepkesz

    if debraholcsinal == "konyhaeszik":
        show debrakonyhabaneszikanim onlayer hatso
        show debrakonyhabaneszikalap onlayer hatso

    show konyhazoldelol onlayer elotte
    hide konyhazoldelol

    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek


$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
