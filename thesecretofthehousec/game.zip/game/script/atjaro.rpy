label kezd:
    play music "audio/banyabolt.ogg" fadeout 1
label atjaro:
    $ holvagyok = "atjaro"
    jump tiltasok
label atjaroszov:

    show atjaro
    if agynemuhejen == True:
        show agynemu
    show poszteresdoboz:
        xpos 0.0
        ypos 0.76
    if szobakipakolas == True:
        show boritek:
            alpha 1.0
        show konyv:
            alpha 1.0
            xpos -0.02
        show ruha:
            alpha 1.0
            xpos -0.017
        if boritekmizeria == 1:
            hide boritek
            show boritek:
                zoom 0.9
                xpos -0.01
                ypos -0.115
        if boritekazinvertoriba == True:
            hide boritek
        if boritekmizeria == 2:
            hide boritek
    if hanyadiknapvan <= 3:
        if szenyeskimosva == True:
            $ szenyeskimosvaahejen = True
            $ szenyeseltakaritasa = 2
            show fiutisztaruha:
                xpos -0.02
    if hanyadiknapvan == 11:
        if egyetemenvoltal11resz == 1:
            $ taskafel = 3
    if hanyadiknapvan == 12:
        if egyetemenvoltal12resz == 1:
            $ taskafel = 3
    if hanyadiknapvan >= 4:
        if taskafel == 1:
            show fredtaska:
                zoom 1.2
                ypos -0.07
                xpos -0.13
        if taskafel == 3:
            show fredtaska:
                zoom 1.2
                ypos -0.07
                xpos -0.13
        if szenyeskimosva == True:
            $ szenyeskimosvaahejen = True
            if isztaruhafel == 1:
                show fredruhatiszta
    show atjarovirag
    if hanyadiknapvan == 2:
        if szenyesafoldon == True:
            show fiuszenyes
    if hanyadiknapvan == 2:
        if alvas == 1:
            if boritekmizeria == 0:
                $ atjarosecialisengedej = 1
                show screen poszterekkepei
                hide agynemu
                show alvashozparna
                show fiualszik
                show fifiszagol:
                    zoom 0.7
                    xpos 0.53
                    ypos 0.7
                show fifiszagolpislog:
                    zoom 0.7
                    xpos 0.53
                    ypos 0.7
                hide fekete onlayer screens
                show fekete onlayer screens:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                pause 5.0
                show agynemu:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                show alvashozparna:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                show fiualszik:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                pause 2.0
                f "I think I should not leave the puppy next to those papers."
        if atjarosecialisengedej == 2:
            if boritekmizeriamegoldva == True:
                show screen poszterekkepei
                hide fekete onlayer screens
                show fekete onlayer screens:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                $ fekete = True
                m "Fred! Please come! I would like to show you something!"
                f "I am right on my way!"
                $ mamasolit = 1
    if hanyadiknapvan == 3:
        if szenyesafoldon == True:
            show fiuszenyes
        if isztaruhafel == 1:
            show fredruhatiszta
        if taskafel == 1:
            show fredtaska
        if harmadikreszvegehez == True:
            jump harmadigreszvege
    if hanyadiknapvan == 4:
        if szenyesafoldon == True:
            show fiuszenyes
    if hanyadiknapvan == 5:
        if kakialatpisi <= 1:
            show hugy:
                xpos 0.37
                ypos 0.88
            if dolgozoltakaritelteltido >= 10:
                show hugy:
                    alpha 0.66
            if dolgozoltakaritelteltido >= 20:
                show hugy:
                    alpha 0.33
        if kakitfeltakaritanikersz == False:
            show szaraatjaroban
    if hanyadiknapvan == 6:
        if lizakertjekesz == 2:
            show screen invertori2
            show invertori onlayer elotte6:
                yalign 0.0
            jump alszik6nap
    if hanyadiknapvan == 7:
        if oblitosuveg == 3:
            show screen invertori2
            show invertori onlayer elotte6:
                yalign 0.0
            jump alszik7nap
    if hanyadiknapvan == 9:
        if resz9jelenet2 == False:
            $ resz9jelenet2 = True
            jump alszikjelenet9
    if hanyadiknapvan == 10:

        if alhat10reszvegen == 1:
            show screen alvas
        if festekoldonalad == 0:
            show festekoldoazinvertoriban:
                xpos 0.55
                ypos 0.62
        if debraholcsinal == "atjarobantorolkozoben":
            show debraazarjarobanazagyon
            jump jelenetdebraval10reszatjaroban


    if hanyadiknapvan == 12:
        if egyetemenvoltal12resz == 1:
            if taskafel == 3:
                if lizafehiv12nap == False:
                    $ lizafehiv12nap = True
                    jump lizafehiv12nap



    jump engedejek
$ renpy. pause(hard=True)
label atjaroszov2:
    $ szobakipakolas = True
    $ agynemu = True
    hide screen kipakolandodoboz
    hide atjarovirag
    show doboz:
        xalign 0.26
        yalign 0.8
        alpha 1.0
        linear 2.0 alpha 0.0
    show boritek:
        alpha 0.0
        linear 2.0 alpha 1.0
    show konyv:
        xpos -0.02
        alpha 0.0
        linear 2.0 alpha 1.0
    show ruha:
        xpos -0.017
        alpha 0.0
        linear 2.0 alpha 1.0
    show atjarovirag
    f "Wonderful, I do not have any bedsheets. I need to ask for it."
$ renpy. pause(hard=True)
label atjaroszov3:
    f "I need to pack out first."
$ renpy. pause(hard=True)
label locsolatjaro1:
    if locsolokannaviz >= 1:
        play sound "audio/viz13.wav"
        $ locsolokannaviz -= 1
        $ viragokmegontozve += 1
        $ atjarovirag = True
        if furdovirag == True:
            if fojasoballvirag == True:
                if fojasojobbvirag == True:
                    if napalivirag == True:
                        if atjarovirag == True:
                            if atjarovirag2 == True:
                                if furdovirag == True:
                                    if atjarovirag3 == True:
                                        $ viragokmegontozese = True
    else:
        f "I need to go back to the bathroom to fill the can with water."
$ renpy. pause(hard=True)
label locsolatjaro2:
    if locsolokannaviz >= 1:
        play sound "audio/viz13.wav"
        $ locsolokannaviz -= 1
        $ viragokmegontozve += 1
        $ atjarovirag2 = True
        if furdovirag == True:
            if fojasoballvirag == True:
                if fojasojobbvirag == True:
                    if napalivirag == True:
                        if atjarovirag == True:
                            if atjarovirag2 == True:
                                if furdovirag == True:
                                    if atjarovirag3 == True:
                                        $ viragokmegontozese = True
    else:
        f "I need to go back to the bathroom to fill the can with water."
$ renpy. pause(hard=True)
label locsolatjaro3:
    if locsolokannaviz >= 1:
        play sound "audio/viz13.wav"
        $ locsolokannaviz -= 1
        $ viragokmegontozve += 1
        $ atjarovirag3 = True
        if furdovirag == True:
            if fojasoballvirag == True:
                if fojasojobbvirag == True:
                    if napalivirag == True:
                        if atjarovirag == True:
                            if atjarovirag2 == True:
                                if furdovirag == True:
                                    if atjarovirag3 == True:
                                        $ viragokmegontozese = True
    else:
        f "I need to go back to the bathroom to fill the can with water."
$ renpy. pause(hard=True)
label atjaroszov4:
    show screen poszterekkepei
    $ fekete = True
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    d "This is our getaway room.Our maid sleeps here usually, but we can not make an effort now to have a maid.This room will be yours."
    d "My husband was the best friend of your father, so he offered to take care of you…"
    d "He told me he will finance your university. Which grade are you in?"
    f "I am a second grade student at the university."
    show debrapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Wonderful. You stay 4 years here and we need to take care of you. I warn you! I am not your mother! I won't treat you like my own."
    f "No problem. I learned how to take care of myself. I cleaned the house when I lived with my dad.I won't make any trouble."
    d "Good to know, but I think it is troublesome you live here from now on."
    d "Well, I need to get used to it.. Pack out your stuff, look around!"
    d "If you see the newspaper, bring it to the living room and throw out the trash. You will find a rubbish bag. Throw it out, too!"
    d "You need to water the plants as well. I need to clean up."
    f "Alright."
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    hide doboz
    jump engedejek
$ renpy. pause(hard=True)
label Beagyazas:
    if parnanalad == True:
        if agynemukosos == True:
            $ agynemuhejen = True
            $ wcremehetek = True
            show agynemu:
                alpha 0.0
                linear 2.0 alpha 1.0
            f "I need to go pee before I sleep."
            $ renpy. pause(hard=True)
        f "I need a clean bed sheet."
    else:
        f "I need a pillow."
    if agynemukosos == False:
        f "I need to wash the bed sheet."
$ renpy. pause(hard=True)
label alszomegyet:
    $ screentiltas = True
    $ atjaroszov = 1
    jump tiltasok
label alszomegyetszov:
    $ alvas += 1
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    jump engedejek
$ renpy. pause(hard=True)
label boritekelteszfifitol:
    hide screen fifiboritekpiszkal
    show fifiszagol:
        zoom 0.7
        xpos 0.53
        ypos 0.7
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifiszagolpislog:
        zoom 0.7
        xpos 0.53
        ypos 0.7
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifimorog:
        zoom 0.7
        xpos 0.53
        ypos 0.7
        alpha 0.0
        linear 1.0 alpha 1.0
    show boritek:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    hide boritek
    show boritek:
        zoom 0.9
        xpos -0.01
        ypos -0.115
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    show fifimorog:
        zoom 0.7
        xpos 0.53
        ypos 0.7
        alpha 1.0
        linear 1.0 alpha 0.0
    show fififelfeleszagol:
        zoom 0.6
        xpos 0.46
        ypos 0.66
        alpha 0.0
        linear 1.0 alpha 1.0
    show fififelfeleszagolpislog:
        zoom 0.6
        xpos 0.46
        ypos 0.66
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    f "This is not good. She can put this in pieces. I should ask Debra to put these papers in a safe place."
    $ fekete = True
    $ boritekmizeria = 1
    jump engedejek
$ renpy. pause(hard=True)
label fififelvesz:
    if fifiholcsinal == "atjaro":
        $ fificsinalido = 60
        $ fifiholcsinal = "sehol"
        $ fifitfelvetem = True
        hide screen fifiboritekpiszkal
        show fififelfeleszagol:
            zoom 0.6
            xpos 0.46
            ypos 0.66
            alpha 1.0
            linear 1.0 alpha 0.0
        show fififelfeleszagolpislog:
            zoom 0.6
            xpos 0.46
            ypos 0.66
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        $ renpy. pause(hard=True)
    $ atjarosecialisengedej = 2
    $ fifitfelvetem = True
    hide screen fifiboritekpiszkal
    show fififelfeleszagol:
        zoom 0.6
        xpos 0.46
        ypos 0.66
        alpha 1.0
        linear 1.0 alpha 0.0
    show fififelfeleszagolpislog:
        zoom 0.6
        xpos 0.46
        ypos 0.66
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    $ fekete = True
    jump engedejek
$ renpy. pause(hard=True)
label szenyesfelvesz:
    if fifitfelvetem == True:
        f "I got Fifi in my pocket, I can not take up anything while she is here."
        $ renpy. pause(hard=True)
    hide screen szennyesfoldon
    $ szenyesafoldon = False
    $ szenyesnalad = True
    $ mosnivalodvan = True
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ mijenszenyesvannalad = "sajatom"
    show fiuszenyes:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label boritekazinvertoriba:
    hide boritek
    show boritek:
        zoom 0.9
        xpos -0.01
        ypos -0.115
        alpha 1.0
        linear 1.0 alpha 0.0
    $ boritekazinvertoriba = True
$ renpy. pause(hard=True)
label alvaselotidontes:
    hide screen atjaro
    hide screen invertori
    show screen invertori2
    hide screen alvas
    show screen kiverjemvagyne
    if hanyadiknapvan == 9:
        hide screen poszterekgomjai
        hide screen poszterekkepei
        hide screen invertori2
        hide screen kiverjemvagyne
        if poszterafalon1 == False:
            show poszterbal:
                xpos 0.0
                ypos 0.76
        if poszterafalon2 == False:
            show poszterkozep:
                xpos 0.0
                ypos 0.76
        if poszterafalon3 == False:
            show poszterjobb:
                xpos 0.0
                ypos 0.76
        if poszterafalon1 == True:
            show fauna2falon:
                xpos 0.225
                ypos 0.3
        if poszterafalon2 == True:
            show faunafalon:
                xpos 0.56
                ypos 0.158
        if poszterafalon3 == True:
            show petykafalon:
                xpos 0.08
                ypos 0.3
        jump alszik9nap
$ renpy. pause(hard=True)
label kiveri2pan:
    $ magazinraveri = False
    hide screen atjaro
    play music "audio/szexy.ogg" fadeout 1
    hide screen kiverjemvagyne
    hide screen poszterekgomjai
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    play sound "audio/fitymahang.ogg"
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
        linear 4.0 alpha 1.0
        linear 1.0 alpha 0.0
    pause 5.0
    show ferdkiverte onlayer screens
    if hanyadiknapvan == 3:
        show ferdkiverteujkep1 onlayer screens:
            xpos 0.1
    pause 1.0
    hide fekete onlayer screens
    stop sound
    hide screen poszterekkepei
    hide ferdkiverteujkep1 onlayer screens
    hide ferdkiverte onlayer screens
    show ferdkiverte
    if hanyadiknapvan == 3:
        show ferdkiverteujkep1:
            xpos 0.1
    show screen debrafotoi
$ renpy. pause(hard=True)
label kiveri3pan:
    hide screen atjaro
    play music "audio/szexy.ogg" fadeout 1
    hide screen kiverjemvagyne
    hide screen poszterekgomjai
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    play sound "audio/fitymahang.ogg"
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
        linear 4.0 alpha 1.0
        linear 1.0 alpha 0.0
    pause 5.0
    show ferdkiverte onlayer screens
    show ferdkivertemagazin onlayer screens
    $ magazinraveri = True
    pause 1.0
    hide fekete onlayer screens
    stop sound
    hide screen poszterekkepei
    hide ferdkiverte onlayer screens
    hide ferdkivertemagazin onlayer screens
    show ferdkiverte
    show ferdkivertemagazin
    show screen debrafotoi
$ renpy. pause(hard=True)
label alszik2nap:
    play music "audio/banyabolt.ogg" fadeout 1
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    hide screen invertori
    show screen poszterekkepei
    hide screen alvas
    hide screen kiverjemvagyne
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    show fekete onlayer screens:
        alpha 0.0
        linear 2.0 alpha 1.0
    show text "{b}{size=+10}End Of Day 2" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    pause 3.0
    hide text onlayer screens
    $ hanyadiknapvan += 1
    hide screen vege
    show screen poszterekkepei
    hide fekete onlayer screens
    show screen invertori2
    show fekete onlayer screens:
        alpha 1.0
        linear 2.0 alpha 0.0
    pause 5.0
    show fiualszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna:
        alpha 1.0
        linear 1.0 alpha 0.0
    show agynemu:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    hide alvashozparna
    $ debraholcsinal = "sehol"
    $ esteighatralevoido = 50000
    $ wczett = 0
    $ fekete = True
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ fifitfelvetem = False
    hide szenyovaj
    hide szenyokenyer2
    hide szenyoketchu
    hide szenyomajonez
    hide szenyomustar
    hide szenyoparizel
    hide szenyosalata
    hide szenyoszalami
    f "What time is it? My lessons will start in a few hours! I need to pee first and I should prepare some food. I need something to drink, too."
    hide screen poszterekkepei

    jump engedejek
$ renpy. pause(hard=True)
label alszik3nap:
    play music "audio/banyabolt.ogg" fadeout 1
    hide screen invertori2
    hide screen invertori
    hide invertori onlayer elotte6
    show screen poszterekkepei
    hide screen alvas
    hide screen kiverjemvagyne
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    show fekete onlayer screens:
        alpha 0.0
        linear 2.0 alpha 1.0
    show text "{b}{size=+10}End Of Day 3" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    pause 3.0
    hide text onlayer screens
    $ hanyadiknapvan += 1
    hide screen vege
    show screen poszterekkepei
    hide fekete onlayer screens
    $ taskafel = 1
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    show fiuszenyes
    hide fiutisztaruha
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    show fekete onlayer screens:
        alpha 1.0
        linear 2.0 alpha 0.0
    pause 5.0
    show fiualszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna:
        alpha 1.0
        linear 1.0 alpha 0.0
    show agynemu:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    hide alvashozparna
    $ debraholcsinal = "sehol"
    $ esteighatralevoido = 50000
    $ wczett = 0
    $ fekete = True
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ szenyesafoldon = True
    $ poharnalad = False
    $ fifitfelvetem = False
    $ baloldaliszomszed = 0
    $ jobboldaliszomszed = 0

    hide szenyovaj
    hide szenyokenyer2
    hide szenyoketchu
    hide szenyomajonez
    hide szenyomustar
    hide szenyoparizel
    hide szenyosalata
    hide szenyoszalami
    hide screen poszterekkepei
    jump engedejek
$ renpy. pause(hard=True)
label alszik6nap:
    show screen poszterekkepei
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    show screen s3
    u ""
    show fekete onlayer screens:
        alpha 0.0
        linear 2.0 alpha 1.0
    show screen s2
    u ""
    hide screen vege
    show text "{b}{size=+10}End Of Day 6" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s3
    u ""
    hide agynemu
    show mamalabal1080:
        zoom 0.7
        xpos 0.39
        ypos 0.25
    show agynemu
    hide alvashozparna
    hide fiualszik
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    hide text onlayer screens
    show screen s1
    u ""
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ debraholcsinal = "dolgozo"
    $ esteighatralevoido = 50000
    $ fekete = True
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ szenyesafoldon = True
    $ poharnalad = False
    $ fifitfelvetem = False
    $ baloldaliszomszed = 0
    $ jobboldaliszomszed = 0
    $ hanyadiknapvan += 1
    $ wczett = 0
    $ gerebjefej = 2
    $ csavarhuzo6resz = 2
    $ penz = 0
    $ atjarosecialisengedej = 0
    $ teremjelenetek = 0
    pause 1.0

    hide fekete onlayer screens
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori2
    hide screen poszterekkepei
    if poszterafalon1 == False:
        show poszterbal:
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        show poszterkozep:
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        show poszterjobb:
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        show fauna2falon:
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        show faunafalon:
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        show petykafalon:
            xpos 0.08
            ypos 0.3
    pause 2.0
    show mamalabal1080:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mamapoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    m "Did I wake you up Freddy?"
    f "Not really... I have to wake up now. I have some easy lessons at the university."
    show fiupoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "I am searching for my money... I can not find it… "
    m "Stop searching Freddy! Grandma lost a lot of money yesterday… Grandma took your money away to pay the debt..."
    m "Grandma spent all your money Freddy…"
    f "When will you give my money back?"
    m "It is really dangerous to owe someone Fred... You should be really thankful because I let you live here…"
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Well… Forget it. I will get some money from Liza today."
    m "Who is this Liza bitch?"
    show fiupoz4:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "She was my neighbour. I cleaned her yard yesterday."
    m "I should go now. Grandma needs to find more money…"
    show mamapoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide poszterbal
    hide poszterkozep
    hide poszterjobb
    hide fauna2falon
    hide faunafalon
    hide petykafalon
    jump engedejek
$ renpy. pause(hard=True)
label alszik7nap:
    show screen poszterekkepei
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    show screen s3
    u ""
    show fekete onlayer screens:
        alpha 0.0
        linear 2.0 alpha 1.0
    show screen s2
    u ""
    hide screen vege
    show text "{b}{size=+10}End Of Day 7" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s3
    u ""
    hide agynemu
    show agynemu
    hide alvashozparna
    hide fiualszik
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    hide text onlayer screens
    show text "{b}{size=+10}Next morning...." onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s3
    u ""
    hide screen invertori2
    hide screen poszterekkepei
    hide invertori onlayer elotte6
    hide text onlayer screens
    show debraszagolhater
    show debraszagol
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    dg "The rinse aid does not smell like semen at all."
    dg "How can this be?"
    dg "The only answer is…. Did Fred cum on my ass and waist yesterday?"
    dg "That idiot! He will pay for this!"
    show debraszagol:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debraszagol2:
        alpha 0.0
        linear 1.0 alpha 1.0
    dg "How could I take revenge? That is all very well, but what if he had pretended to sleep? "
    dg "What if he thinks now, he can do anything to me? He will remain silent unless I do something wrong…"
    dg "Let us think a bit! What should I do now? I have to keep my distance from Fred."
    dg "He can bring me to shame easily. I am a married woman."
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0

    play sound "audio/telofelvesz.wav"
    show screen s3
    u ""
    hide debraszagolhater
    hide debraszagol
    hide debraszagol2
    show atjarohomajos
    show fredtelefonal:
        xpos 0.2
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    f "Hallo!"
    l "Hy Fred! It is me! I am Liza!"
    l "I ran into some problem… Can you help me please?"
    l "Please come!"
    show pulialszikleegettelefonoshatter:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Sure... but how do you know my phone number? I bought a mobile phone only yesterday."
    l "You did not give me your address, so I asked Zoli about your…"
    f "Ok, now I understand. I am there in a few minutes! Hold on!"
    l "Oh! Thank you Fred! I need you! Bye bye!"
    show pulialszikleegettelefonoshatter:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show atjarohomajos:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fredtelefonal:
        xpos 0.2
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen invertori
    show screen poszterekkepei
    show invertori onlayer elotte6:
        yalign 0.0
    $ debraholcsinal = "konyhatorol"
    $ mamaholvan = "napaliban"
    $ holvanliza = "tornazik"
    $ debrakertjekomposztladafu1 = 0
    $ debrakertjekomposztladafu2 = 0
    $ uditosmagamhozveni = 0
    $ ruhakosarnalad = False
    $ szemeteszsaknalad = False
    $ szemeteszak = 1
    $ esteighatralevoido = 50000
    $ fekete = True
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ szenyesafoldon = True
    $ poharnalad = False
    $ fifitfelvetem = False
    $ baloldaliszomszed = 0
    $ jobboldaliszomszed = 0
    $ hanyadiknapvan += 1
    $ wczett = 0
    $ gerebjefej = 2
    $ csavarhuzo6resz = 2
    $ penz = 0
    $ atjarosecialisengedej = 0
    $ teremjelenetek = 0
    pause 1.0

    hide fekete onlayer screens

    jump engedejek
$ renpy. pause(hard=True)
label debrafotokozelebrol2resz:
    if hanyadiknapvan == 2:
        hide screen debrafotoi

        show fatodebrarol:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        u ""
        hide fatodebrarol
        hide ferdkiverte
        jump alszik2nap
    if hanyadiknapvan == 3:
        hide screen debrafotoi
        if magazinraveri == True:
            show pornomagazin:
                alpha 0.0
                linear 1.0 alpha 1.0
        if magazinraveri == False:
            show fatodebrarol2:
                alpha 0.0
                linear 1.0 alpha 1.0
            u ""
            show fatodebrarol:
                alpha 0.0
                linear 1.0 alpha 1.0
        show screen s1
        u ""
        u ""
        hide pornomagazin
        hide ferdkiverteujkep1
        hide ferdkivertemagazin
        hide fatodebrarol
        hide fatodebrarol2
        hide ferdkiverte
        jump alszik3nap
    if hanyadiknapvan == 8:
        hide screen debrafotoi
        if magazinraveri == True:
            show pornomagazin:
                alpha 0.0
                linear 1.0 alpha 1.0
        if magazinraveri == False:
            show fatodebrarol2:
                alpha 0.0
                linear 1.0 alpha 1.0
            u ""
            show fatodebrarol:
                alpha 0.0
                linear 1.0 alpha 1.0
        show screen s1
        u ""
        u ""
        hide pornomagazin
        hide ferdkiverteujkep1
        hide ferdkivertemagazin
        hide fatodebrarol
        hide fatodebrarol2
        hide ferdkiverte
        jump alszik8nap
    if hanyadiknapvan == 10:
        hide screen debrafotoi
        if magazinraveri == True:
            show pornomagazin:
                alpha 0.0
                linear 1.0 alpha 1.0
        if magazinraveri == False:
            show fatodebrarol2:
                alpha 0.0
                linear 1.0 alpha 1.0
            u ""
            show fatodebrarol:
                alpha 0.0
                linear 1.0 alpha 1.0
        show screen s1
        u ""
        u ""
        hide pornomagazin
        hide ferdkiverteujkep1
        hide ferdkivertemagazin
        hide fatodebrarol
        hide fatodebrarol2
        hide ferdkiverte
        jump alszik10nap
$ renpy. pause(hard=True)
label debrafotokozelebrol:
    $ debratmegnezed = "foton"
    jump tiltasok
$ renpy. pause(hard=True)
label debrafotokozelebrolszov:
    hide screen invertori2
    hide invertori onlayer elotte6
    $ debratmegnezed = "sehol"
    $ fekete = True
    hide screen debrafotoi
    show fatodebrarol onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    u ""
    if hanyadiknapvan >= 4:
        show fatodebrarol2 onlayer screens:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
    u ""
    show fatodebrarol onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    if hanyadiknapvan >= 4:
        show fatodebrarol2 onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
    pause 1.0
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    hide fatodebrarol onlayer screens
    hide fatodebrarol2 onlayer screens
    jump engedejek
$ renpy. pause(hard=True)
label tisztaruhafel:
    $ isztaruhafel = 2
    $ szenyesafoldon = True
    show fredruhatiszta:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiuszenyes:
        alpha 0.0
        linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
label taskaazinvertoriba:
    $ taskafel = 2
    show fredtaska:
        alpha 1.0
        linear 1.0 alpha 0.0
    if hanyadiknapvan == 10:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    if hanyadiknapvan == 11:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    if hanyadiknapvan == 12:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
$ renpy. pause(hard=True)
label harmadigreszvege:
    $ fekete = True
    show screen poszterekkepei
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen poszterekgomjai
    show screen alvas
$ renpy. pause(hard=True)
label magazinbabelenezek:
    $ pornomagazint = "nezed"
    jump tiltasok
$ renpy. pause(hard=True)
label magazinbabelenezekszov:
    $ pornomagazint = "semi"
    hide screen invertori2
    hide invertori onlayer elotte6
    $ fekete = True
    hide screen debrafotoi
    show pornomagazin onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    u ""
    show pornomagazin onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    hide pornomagazin onlayer screens
    jump engedejek
$ renpy. pause(hard=True)
label kakittakarit:
    hide screen atjaro
    hide screen poszterekgomjai
    hide screen atjaroszov
    show screen invertori2
    hide screen invertori
    if kakitfeltakaritani == 1:
        if debratolkerniszivacs == 0:
            $ debratolkerniszivacs = 1
        if zsacskonalad == 1:
            if torloszivacsnalad == False:
                f "I need a sponge and a trash bag to clean up the shit."
        if torloszivacsnalad == False:
            if felvetedaszivacsot == 0:
                $ felvetedaszivacsot = 1
            if felvetedaszivacsot == 1:
                f "The sponge is under the sink in the bathroom. I will ask Debra to give me the sponge. She is bathing now."
            if felvetedaszivacsot == 2:
                f "I should buy a new sponge. Debra will not let me in the bathroom."
        if zsacskonalad == 1:
            f "The trash bag is under the sink in the kitchen."
        if zsacskonalad == 2:
            if torloszivacsnalad == True:
                $ kakitfeltakaritanikersz = True
                $ zsacskonalad = 3
                $ kakialatpisi = 1
                $ szivacskoszoslett = 11
                show szaraatjaroban:
                    alpha 1.0
                    linear 2.0 alpha 0.

        show screen atjaro
        show screen poszterekgomjai
        show screen invertori
        hide screen invertori2
        show screen atjaroszov





        $ renpy. pause(hard=True)
$ renpy. pause(hard=True)
label debraatjaro:
    hide screen atjaro
    hide screen poszterekgomjai
    hide screen atjaroszov
    show screen invertori2
    hide screen invertori
    f "What are you looking at?"
    d "I am watching the painting. Do not disturb me with your damn questions!"
    show screen atjaro
    show screen poszterekgomjai
    show screen invertori
    hide screen invertori2
    show screen atjaroszov
$ renpy. pause(hard=True)
label alszik8nap:
    show screen poszterekkepei
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
label alszik8nap2:
    show screen invertori2
    hide screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    hide screen poszterekgomjai
    show screen poszterekkepei
    show screen poszterekkepei
    show screen s1
    u ""
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    show screen s3
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide screen vege
    show screen s1
    u ""
    show text "{b}{size=+10}End Of Day 8" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s3
    u ""
    $ metszoollonalad = 0
    $ gerebjenalad = 0
    $ szemeteszsaknalad = False
    $ szemeteszak = 1
    hide text onlayer screens
    show text "{b}{size=+10}Around midnight...." onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    play sound "audio/telofelvesz.wav"
    show screen s3
    u ""
    if poszterafalon1 == False:
        show poszterbal:
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        show poszterkozep:
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        show poszterjobb:
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        show fauna2falon:
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        show faunafalon:
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        show petykafalon:
            xpos 0.08
            ypos 0.3
    hide agynemu
    show agynemu
    hide alvashozparna
    hide fiualszik
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    show atjaroeste
    hide screen poszterekkepei
    show fredtelefonalsotetben:
        xpos 0.2
        ypos 0.1
    hide text onlayer screens
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1e5
    u ""
    f "Who can this be?"
    z "It is me man, Zoli. You asked me to call you when I notice the strange lame guy again."
    f "Ok, Thank you! I am right on the way. I should take a look at him..."
    z "Super man! Now I'm going to sleep. Call me if you need me Bro!"
    $ debrakertjekomposztladafu1 = 0
    $ debrakertjekomposztladafu2 = 0
    $ uditosmagamhozveni = 0
    $ ruhakosarnalad = False
    $ esteighatralevoido = 0
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ szenyesafoldon = True
    $ baloldaliszomszed = 0
    $ jobboldaliszomszed = 0
    $ hanyadiknapvan += 1
    $ wczett = 0
    $ atjarosecialisengedej = 0
    $ teremjelenetek = 0
    $ kutyatalakonyhaban = False
    $ svetlana = "sehol"
    $ mrpuliholvan = "napozoagy"
    $ kittyholvan = "sehol"

    jump temeto
$ renpy. pause(hard=True)
label alszikjelenet9:
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    if poszterafalon1 == False:
        show poszterbal:
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        show poszterkozep:
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        show poszterjobb:
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        show fauna2falon:
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        show faunafalon:
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        show petykafalon:
            xpos 0.08
            ypos 0.3
    show atjaroeste onlayer hatso
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    hide poszterbal
    hide poszterkozep
    hide poszterjobb
    hide fauna2falon
    hide faunafalon
    hide petykafalon
    if poszterafalon1 == False:
        show poszterbal:
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        show poszterkozep:
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        show poszterjobb:
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        show fauna2falon:
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        show faunafalon:
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        show petykafalon:
            xpos 0.08
            ypos 0.3
    show screen s2
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    hide atjaroeste onlayer hatso
    hide agynemu
    show agynemu
    hide alvashozparna
    hide fiualszik
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    hide poszterbal
    hide poszterkozep
    hide poszterjobb
    hide fauna2falon
    hide faunafalon
    hide petykafalon
    if poszterafalon1 == False:
        show poszterbal:
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        show poszterkozep:
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        show poszterjobb:
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        show fauna2falon:
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        show faunafalon:
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        show petykafalon:
            xpos 0.08
            ypos 0.3
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show fiutavolabipoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapozhaloruha1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    f "Good morning!"
    d "Why would this morning be good at all? Idiot! Someone made the corridor dirty. There are muddy footprints everywhere..."
    f "I think Grandma made it..."
    d "Of course with your shoes?"
    d "We have to clean the pool now. Go! I will catch you up later. I have a lot to do now..."
    f "Ok…"
    $ tiltjaaterkepet = True
    show fiutavolabipoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapozhaloruha1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    $ fekete = True
    $ debraholcsinal = "dolgozo"
    $ medencetkitakaritanidebramondja = True
    $ tiltjaatereketszomszedok = False
    $ tiltjaatereketpark = False
    $ tiltjaatereketbolt = False
    $ tiltjaatereketegyetem = False
    $ tiltjaatereketsritbar = False
    $ tiltjaadebrakertjet = False
    hide poszterbal
    hide poszterkozep
    hide poszterjobb
    hide fauna2falon
    hide faunafalon
    hide petykafalon
    jump engedejek
$ renpy. pause(hard=True)
label alszik9nap:
    show screen invertori2
    hide screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    hide screen poszterekgomjai
    hide screen poszterekkepei
    show screen s1
    u ""
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    show screen s3
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show text "{b}{size=+10}Around midnight…" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s2
    u ""
    hide text onlayer screens
    hide screen invertori2
    hide invertori onlayer elotte6
    show atjaroeste
    show csillagok6resz:
        xpos 0.0
        yzoom -1.0
        ypos 1.2
        pause 1.0
        linear 10.0 ypos -3.7
    show debrapan9resz:
        zoom 0.9
        xpos 0.1
        ypos -0.8
        pause 1.0
        linear 8.0 ypos -0.02
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen s1e5
    u ""
    play sound "audio/csillag.ogg"
    show screen s8e5
    u ""
    show debraalvajar9reszvegjelenet2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "Fuck! Debra! You scared me! What are you doing here?"
    dalva "I am still missing something... I am searching here…"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    hide screen vege
    show screen s1
    u ""
    show text "{b}{size=+10}End Of Day 9" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s3
    u ""
    play music "audio/baszosalap.ogg" fadeout 1
    hide text onlayer screens
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    fg "She is still sleepwalking. What does she want in my room in the middle of the night?"
    dalva "I can feel it. The thing I am searching for is in my near…"
    show debraalvajar10resza1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraalvajar10resza1csillog1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show debraalvajar10resza1csillog2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 1.0
        linear 1.0 alpha 0.0
        pause 2.0
        repeat
    show debraalvajar10resza1csillog1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 2.0
        linear 1.0 alpha 1.0
        pause 1.0
        repeat
    dalva "It is near, I can smell it. I am almost there…"
    f "This is fine Debra, but... I might be dead, if you woke up."
    u ""
    show debraalvajar10resza2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraalvajar10resza2csillog1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show debraalvajar10resza2csillog2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 1.0
        linear 1.0 alpha 0.0
        pause 2.0
        repeat
    show debraalvajar10resza2csillog1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 2.0
        linear 1.0 alpha 1.0
        pause 1.0
        repeat
    dalva "I will find it here, I know it…"
    dalva "I have to get a little closer to …"
    u ""
    show debraalvajar10resza3 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "She smells so good…"
    fg "I can feel her soft boobs pushing against my chest. This is worth all the money... I do not care about what will happen to me…"
    f "Search for it, do what you want…"
    u ""
    show debraalvajar10resza4 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    dalva "Quiet! Be quiet! Do not wake the others! This is our secret!"
    f "{size=-10}Fine, but what are you searching for?"
    u ""
    show debraalvajar10resza5 onlayer elotte
    with vpunch
    show screen s1
    u ""
    dalva "I got it! It is here in my hand! I lost this a long time ago…"
    f "{size=-10}WOW! I am hard as rock. "
    u ""
    show debraalvajar10resza7v1 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "This must be a dream, or I might be dead."
    show debraalvajar10resza6megjeleno onlayer elotte
    show debraalvajar10resza6arnymindenfelet onlayer elotte2
    show debraalvajar10resza7v1 onlayer elotte3:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide debraalvajar10resza6megjeleno onlayer elotte
    show debraalvajar10resza6hater onlayer elotte
    show debraalvajar10resza6moz1alap onlayer elotte
    show debraalvajar10resza6moz1szaj1 onlayer elotte
    show debraalvajar10resza6faszanim onlayer elotte3
    show screen s4
    u ""
    hide debraalvajar10resza6moz1alap onlayer elotte
    hide debraalvajar10resza6moz1szaj1 onlayer elotte
    show debraalvajar10resza6animfel onlayer elotte
    show screen s06
    u ""
    show debraalvajar10resza6moz3alap onlayer elotte
    show debraalvajar10resza6moz3szajanim onlayer elotte
    hide debraalvajar10resza6animfel onlayer elotte
    dalva "How I missed this! We did not meet a long time ago…"
    hide debraalvajar10resza6moz3szajanim onlayer elotte
    show debraalvajar10resza6moz3szaj1 onlayer elotte
    f "{size=-10}I am happy for you! But… Did you lose my …"
    show screen s4
    u ""
    hide debraalvajar10resza6moz3alap onlayer elotte
    hide debraalvajar10resza6moz3szaj1 onlayer elotte
    show debraalvajar10resza6animle onlayer elotte
    show screen s06
    u ""
    show debraalvajar10resza6moz1alap onlayer elotte
    show debraalvajar10resza6moz1szajanim onlayer elotte
    hide debraalvajar10resza6animle onlayer elotte
    dalva "Yeah. Noone cares about me anymore. I got old and uggly…"
    dalva "But you find me sexy, I noticed it and so I think of you all night long..."
    show debraalvajar10resza6moz1szaj1 onlayer elotte
    hide debraalvajar10resza6moz1szajanim onlayer elotte
    f "{size=-10}Yes, I find you very attractive… Why does Bertalan not like you anymore?"
    show screen s4
    u ""
    hide debraalvajar10resza6moz1szaj1 onlayer elotte
    show debraalvajar10resza6moz1szajanim onlayer elotte
    dalva "Who the fuck knows? He is bored... or he is homosexual… I do not know…"
    show debraalvajar10resza6moz1szaj1 onlayer elotte
    hide debraalvajar10resza6moz1szajanim onlayer elotte
    show screen s4
    u ""
    hide debraalvajar10resza6moz1alap onlayer elotte
    hide debraalvajar10resza6moz1szaj1 onlayer elotte
    show debraalvajar10resza6animfel onlayer elotte
    show screen s06
    u ""
    show debraalvajar10resza6moz3alap onlayer elotte
    show debraalvajar10resza6moz3szajanim onlayer elotte
    hide debraalvajar10resza6animfel onlayer elotte
    dalva "Let us stop talking about my husband. Put it in me! I want it!"
    hide debraalvajar10resza6moz3alap onlayer elotte
    hide debraalvajar10resza6moz3szaj1 onlayer elotte
    hide debraalvajar10resza6moz3szajanim onlayer elotte
    show debraalvajar10resza6moz3 onlayer elotte
    show screen s1
    u ""
    hide debraalvajar10resza7v1 onlayer elotte3
    show debraalvajar10resza7v1 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "She might kill me if she woke up."
    show debraalvajar10resza7v2 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "Who the hell cares? I am going to cum in my pants. My penis is pulsing like crazy! I never felt something like this before…"
    f "{size=+10}ARRGGGGHHHH!!!!!!"
    hide debraalvajar10resza6faszanim onlayer elotte3
    hide debraalvajar10resza7v1 onlayer elotte3
    show debraalvajar10resza8hater onlayer elotte
    show debraalvajar10resza8moz1 onlayer elotte
    show debraalvajar10resza7v2 onlayer elotte3:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide debraalvajar10resza8moz1 onlayer elotte
    show debraalvajar10resza8animle onlayer elotte
    show screen s1
    u ""
    hide debraalvajar10resza8animle onlayer elotte
    show debraalvajar10resza8moz3alap onlayer elotte
    show debraalvajar10resza8moz3szemanim onlayer elotte
    show screen s1
    u ""
    dg "What the… Where am I?"
    show screen s1
    u ""
    show debraalvajar10resza9v1 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    d "Oh Gosh! What am I doing here?!"
    hide debraalvajar10resza6hater onlayer elotte
    hide debraalvajar10resza6moz3 onlayer elotte
    hide debraalvajar10resza9v1 onlayer elotte3
    hide debraalvajar10resza8faszanim onlayer elotte2
    hide debraalvajar10resza6arnymindenfelet onlayer elotte2
    hide debraalvajar10resza8hater onlayer elotte
    hide debraalvajar10resza8moz3alap onlayer elotte
    hide debraalvajar10resza8moz3szemanim onlayer elotte
    show debraalvajar10resza9anim onlayer elotte
    show screen s04
    u ""
    play sound "audio/fiuelesik.wav"
    with vpunch
    show screen s1
    u ""
    show debraalvajar10resza10 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    dg "What should I do now?"
    dg "How did I end up here? Did I sleepwalk again? Let us think... I should use sleepwalking to get out of this trouble…"
    hide debraalvajar10resza1 onlayer elotte
    hide debraalvajar10resza2 onlayer elotte
    hide debraalvajar10resza3 onlayer elotte
    hide debraalvajar10resza4 onlayer elotte
    hide debraalvajar10resza5 onlayer elotte
    hide debraalvajar10resza1csillog1 onlayer elotte
    hide debraalvajar10resza1csillog2 onlayer elotte
    hide debraalvajar10resza2csillog1 onlayer elotte
    hide debraalvajar10resza2csillog2 onlayer elotte
    hide debraalvajar10resza6 onlayer elotte
    hide debraalvajar10resza7v1 onlayer elotte3
    hide debraalvajar10resza7v2 onlayer elotte3
    hide debraalvajar10resza8 onlayer elotte
    hide debraalvajar10resza9v1 onlayer elotte
    hide debraalvajar10resza9anim onlayer elotte
    hide debraalvajar9reszvegjelenet2
    hide debrapan9resz
    hide agynemu
    show agynemu
    hide alvashozparna
    hide fiualszik
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    show debrapoz2estiruha onlayer elotte
    show fiupoz1 onlayer elotte
    show fiupoz1pir onlayer elotte2
    show fiupoz1arny onlayer elotte2
    hide debraalvajar10resza10 onlayer elotte
    show debraalvajar10resza10 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    f "Debra! Are you ok? Did it hurt?"
    show fiupoz1sokkolt onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Debra is sleepwalking…"
    f "What? Really? You are sleeping after this big fall?"
    show fiupoz1sokkolt onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1sokkoltjobra onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "I thought you woke up before you fell…"
    d "I did not… I am still sleeping…"
    f "Fine. I hope you won’t remember this tomorrow..."
    show debrapoz2estiruha onlayer elotte:
        pause 1.2
        alpha 0.0
    show debrapoz1estiruha onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Debra is going to bed…"
    show fiupoz1sokkoltjobra onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "Fred will follow you to be sure."
    d "Fred should only shut up and never talk about this night or he might get hurt really baaaaad…."
    show fiupoz1sokkolt onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Well… ok... Good night!"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide fiupoz1 onlayer elotte
    hide fiupoz1pir onlayer elotte2
    hide fiupoz1arny onlayer elotte2
    hide debraalvajar10resza10 onlayer elotte
    hide debrapoz1estiruha onlayer elotte
    hide fiupoz1sokkoltjobra onlayer elotte
    hide fiupoz1sokkolt onlayer elotte
    $ tiltjaaterkepet = False
    $ tiltjaadebrakertjet = False
    $ debrakertjekomposztladafu1 = 0
    $ debrakertjekomposztladafu2 = 0
    $ uditosmagamhozveni = 0
    $ ruhakosarnalad = False
    $ esteighatralevoido = 500000
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ szenyesafoldon = True
    $ baloldaliszomszed = 0
    $ jobboldaliszomszed = 0
    $ hanyadiknapvan += 1
    $ wczett = 0
    $ atjarosecialisengedej = 0
    $ teremjelenetek = 0
    $ fifitfelvetem = False
    $ szedvisz1 = True
    $ szedvisz2 = True
    $ taskafel = 1
    $ vanszedvicsed2 = 0
    $ tiltjaaterkepet = True
    $ kittyholvan = "sehol"
    $ Edwardsholvan = "sehol"
    $ holvanliza = "tornazik"
    $ svetlana = "sehol"
    $ annaholvan = "parktonal2"
    $ mamaholvan = "napozikkert2ben"
    $ festekoldonalad = 0
    $ metszoollonalad = 0
    play music "audio/banyabolt.ogg" fadeout 1
    hide poszterbal
    hide poszterkozep
    hide poszterjobb
    hide fauna2falon
    hide faunafalon
    hide petykafalon
    show screen poszterekkepei
    hide atjaroeste
    show festekoldoazinvertoriban:
        xpos 0.55
        ypos 0.62
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori2
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    $ fekete = True

    jump engedejek
$ renpy. pause(hard=True)
label alszik10nap:
    hide screen poszterekgomjai
    hide screen poszterekkepei
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    if poszterafalon1 == False:
        show poszterbal:
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        show poszterkozep:
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        show poszterjobb:
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        show fauna2falon:
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        show faunafalon:
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        show petykafalon:
            xpos 0.08
            ypos 0.3
    show atjaroeste onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s3
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    hide screen vege
    hide screen poszterekgomjai
    hide screen poszterekkepei
    show text "{b}{size=+10}End Of Day 10" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s3
    u ""
    hide text onlayer screens
    hide screen invertori2
    hide invertori onlayer elotte6
    show agynemu:
        alpha 1.0
    hide alvashozparna
    hide fiualszik
    hide atjaroeste onlayer hatso
    play sound "audio/telofelvesz.wav"
    show screen s3
    u ""
    show fredtelefonal:
        xpos 0.2
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    f "Who is it?"
    s "How much would you pay for this information?"
    f "Svetlana… Where did you get my phone number from?"
    s "Your little friend, Puffy, gave it to me."
    f "Great! Why are you calling?"
    show svetlanatelefon onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    s "I have a job for you… Are you interested?"
    f "Yes, I am. I can visit you after I finish the lessons at the university. Good so? "
    s "Fine for me! My place is near the university."
    f "Will you pay me for the work?"
    s "Money first? Huh? Of course I will pay. How about 3500 Forints?"
    f "Sounds good! What should I do?"
    s "I have to move from my old place to my new home and I have some heavy stuff to carry for you."
    f "Fine. Tell me the location!"
    s "There is a forest next to the university. Go behind it from the other side."
    f "I will. Do you want anything else?"
    s "Not really. Calling you is costing me a lot of money, I hang on! Bye!"
    hide fredtelefonal
    show svetlanatelefon onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    $ tiltjaadebrakertjet = False
    $ tiltjaaterkepet = False
    $ debrakertjekomposztladafu1 = 0
    $ debrakertjekomposztladafu2 = 0
    $ uditosmagamhozveni = 0
    $ ruhakosarnalad = False
    $ esteighatralevoido = 500000
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ szenyesafoldon = True
    $ baloldaliszomszed = 0
    $ jobboldaliszomszed = 0
    $ hanyadiknapvan += 1
    $ wczett = 0
    $ atjarosecialisengedej = 0
    $ teremjelenetek = 0
    $ fifitfelvetem = False
    $ szedvisz1 = True
    $ szedvisz2 = True
    $ ruhakosarnaladtelemijenruhaval = "semijen"
    $ taskafel = 1
    $ vanszedvicsed2 = 0
    $ tiltjaaterkepet = True
    $ kittyholvan = "sehol"
    $ Edwardsholvan = "sehol"
    $ mrpuliholvan = "lizanapaliban"
    $ holvanliza = "hazelotgyomlal"
    $ svetlana = "sehol"
    $ annaholvan = "sehol"
    $ mamaholvan = "napozikkert2ben"
    $ debraholcsinal = "sehol"
    $ fodoholvan = "sehol"
    $ ciliholvan = "cilinapaliaban"
    $ festekoldonalad = 0
    $ metszoollonalad = 0
    hide poszterbal
    hide poszterkozep
    hide poszterjobb
    hide fauna2falon
    hide faunafalon
    hide petykafalon
    $ tiltjaatereketnyomortanya = True
    $ fekete = True
    show screen poszterekgomjai
    show screen poszterekkepei
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
$ renpy. pause(hard=True)
label festekoldofel:
    show festekoldoazinvertoriban:
        xpos 0.55
        ypos 0.62
        alpha 1.0
        linear 1.0 alpha 0.0
    $ festekoldonalad = 1
$ renpy. pause(hard=True)
label jelenetdebraval10reszatjaroban:
    $ fekete = True
    $ invertorialapjelenyenmeg = True
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    hide screen poszterekkepei
    if poszterafalon1 == False:
        show poszterbal:
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        show poszterkozep:
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        show poszterjobb:
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        show fauna2falon:
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        show faunafalon:
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        show petykafalon:
            xpos 0.08
            ypos 0.3
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show csillagok6resz onlayer elotte:
        xpos 0.0
        yzoom -1.0
        ypos 1.3
        linear 10.0 ypos -2.2
    show debrapan10resz onlayer elotte:
        xpos 0.0
        ypos -2.1
        linear 10.0 ypos 0.0
    show screen s1e5
    u ""
    play sound "audio/csillag.ogg"
    show screen s8e5
    u ""
    show debraagyonbeszel onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    hide debraagyonbeszel onlayer elotte
    show debraagyonbeszelalap onlayer elotte
    show debraagyonbeszel1alap onlayer elotte
    show debraagyonbeszel1szaj1 onlayer elotte
    f "Hy! What are you doing here?"
    hide debraagyonbeszel1szaj1 onlayer elotte
    show debraagyonbeszel1szajanim onlayer elotte
    d "I had a hot shower and I thought I could drink and I walked to the kitchen, I felt dizzy so I sat down."
    d "This is nothing special. I was just silly a bit to walk out so fast..."
    hide debraagyonbeszel1alap onlayer elotte
    hide debraagyonbeszel1szaj1 onlayer elotte
    show debraagyonbeszelmozfel onlayer elotte
    f "Can I bring you a glass of water?"
    hide debraagyonbeszelmozfel onlayer elotte
    show debraagyonbeszel3alap onlayer elotte
    show debraagyonbeszel3szajanim onlayer elotte
    d "No, I am fine now. I just sat down a bit."
    show debraagyonbeszel3alap onlayer elotte
    hide debraagyonbeszel3szajanim onlayer elotte
    show debraagyonbeszel3szaj1 onlayer elotte
    f "Ok… Call me if you need anything!"
    hide csillagok6resz onlayer elotte
    hide debrapan10resz onlayer elotte
    hide debraazarjarobanazagyon
    hide debraagyonbeszel3alap onlayer elotte
    show debraagyonbeszelmozle onlayer elotte
    hide debraagyonbeszel3szaj1 onlayer elotte
    show screen s05
    u ""
    hide debraagyonbeszelmozle onlayer elotte
    hide debraagyonbeszel1szajanim onlayer elotte
    show debraagyonbeszel1alap onlayer elotte
    show debraagyonbeszel1szajanim onlayer elotte
    d "Thanks Idiot! I do not need anything from you now. I have a lot to do, I should go."
    hide debraagyonbeszel1szajanim onlayer elotte
    hide debraagyonbeszel1szaj1 onlayer elotte
    hide debraagyonbeszel1alap onlayer elotte
    hide debraagyonbeszelalap onlayer elotte
    $ debraholcsinal = "dolgozo"
    show debraagyonbeszel onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1e5
    u ""
    hide poszterbal
    hide poszterkozep
    hide poszterjobb
    hide fauna2falon
    hide faunafalon
    hide petykafalon
    show screen poszterekkepei
    jump engedejek
$ renpy. pause(hard=True)
label lizafehiv12nap:
    hide fekete onlayer screens
    show fekete onlayer screens
    $ fekete = True
    $ invertorialapjelenyenmeg = True
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen invertori2
    show atjarohomajos onlayer elotte
    show fredtelefonal onlayer elotte:
        xpos 0.2
    play sound "audio/telofelvesz.wav"
    show screen s3
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    f "Hy Liza!"
    l "Hy Fred! Do you have some time for me?"
    f "Of course! What can I help you with?"
    l "I would like to ask you a favor. Can you please deliver a tool for Cili? She ordered it yesterday and the tool has arrived."
    f "Ok! do you know Where she lives?"
    show lizanapaliboltelefonal onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    l "Visit me and I will tell you! You should pick up the package as well..."
    f "Ok! I am on my way right now!"
    l "Super! You can find me in the garden honey! Byebye!"
    $ amandaholvan = "lizaekelott"
    $ ancikaholvan = "boltnal"
    hide atjarohomajos onlayer elotte
    hide fredtelefonal onlayer elotte
    show lizanapaliboltelefonal onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    jump engedejek
$ renpy. pause(hard=True)
label alszomegyet12napnem:
    hide screen atjaro
    if lizavalszexeltel == False:
        f "I do not feel like sleeping now. I would like to go back to the Stripbar."
    if cilinekjelenteni == False:
        f "I have to call Cili and tell her I delivered the packages."
    show screen atjaro
$ renpy. pause(hard=True)
label alszomegyet12napigen:
    hide screen atjaro
    hide screen invertori
    hide invertori onlayer elotte6
    hide screen poszterekgomjai
    show screen s1
    u ""
    show agynemu:
        alpha 1.0
        linear 1.0 alpha 0.0
    show alvashozparna
    show fiualszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide fredtaska
    show fredtaska:
        zoom 1.2
        ypos -0.07
        xpos -0.13
    hide screen poszterekkepei
    if poszterafalon1 == False:
        show poszterbal:
            xpos 0.0
            ypos 0.76
    if poszterafalon2 == False:
        show poszterkozep:
            xpos 0.0
            ypos 0.76
    if poszterafalon3 == False:
        show poszterjobb:
            xpos 0.0
            ypos 0.76
    if poszterafalon1 == True:
        show fauna2falon:
            xpos 0.225
            ypos 0.3
    if poszterafalon2 == True:
        show faunafalon:
            xpos 0.56
            ypos 0.158
    if poszterafalon3 == True:
        show petykafalon:
            xpos 0.08
            ypos 0.3
    show screen s3
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show atjarokozeli2arny onlayer elotte
    show debraalvajarpoz1 onlayer elotte:
        xzoom -1.0
        xpos 0.1
    show frednagybanelolarny onlayer elotte2:
        xpos -0.1
    show debraleveszi12nap onlayer elotte3
    play music "audio/szexy.ogg" fadeout 1
    dalva "Fred…."
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    f "Aghhh…."
    dalva "I still miss something…"
    f "Fine… But Grandma is in the living room. She might hear us."
    show debraleveszi12nap onlayer elotte3:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    play sound "audio/ajto2.wav"
    show mama12napvegenarny onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    m "What are you doing here Debra?"
    dalva "I am searching for something…"
    f "She usually goes into the kitchen and prepares some sandwiches…"
    m "Interesting… I didn't even notice, she is sleepwalking again…"
    f "Yeap. She is sleepwalking for a while… She usually goes to the kitchen."
    m "Well, ok. Debar! Prepare a sandwich for me, please! Thank you!"
    dalva "Ok. I will do it."
    show debraalvajarpoz1 onlayer elotte:
        xzoom -1.0
        xpos 0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show debraalvajarmoz1 onlayer elotte:
        xzoom -1.0
        xpos 0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    hide debraalvajarmoz1 onlayer elotte
    show debraalvajaranimokos onlayer elotte:
        xzoom -1.0
        xpos 0.1
        linear 10.0 xpos 1.5
    show screen s5
    u ""
    m "Now I am here, let us have some fun Freddy!"
    f "Well…. Uggghhhh…"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show screen vege



$ renpy. pause(hard=True)
label hivodcilit:
    $ telefonalsz = True
    $ fekete = True
    jump tiltasok

label telefonnalfed:
    show fredtelefonal onlayer elotte5:
        xpos 0.2
        ypos 0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    $ cilinekjelenteni = True
    f "This is me, Fred."
    c "Alright my little birdy… Have a nice dream!"
    f "Good night!"
    show fredtelefonal onlayer elotte5:
        xpos 0.2
        ypos 0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide fredtelefonal onlayer elotte5
    jump engedejek

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
