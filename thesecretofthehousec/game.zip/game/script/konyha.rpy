label konyha:
    if hanyadiknapvan == 1:
        hide screen atjaro
        hide screen poszterekgomjai
        hide screen atjaroszov
        f "Here is the kitchen. I have nothing to do here."
        show screen poszterekgomjai
        show screen atjaroszov
        show screen atjaro
        $ renpy. pause(hard=True)
    if hanyadiknapvan == 2:
        $ holvagyok = "konyha"
        jump tiltasok

    $ holvagyok = "konyha"
    jump tiltasok
label konyhaszov:
    show konyha
    if esteighatralevoido == 0:
        show konyhaeste
    show konyhavirag
    if dolgozolmosogatas == 1:
        show konyhamosatlan
    if dolgozolmosogatas == 2:
        show konyhamosotedeny
    if tvtaviranyitonalad == False:
        show taviranyitokonyhaban
    if poharnalad == False:
        show konyhapohar
    show konyhaszendvicskendo
    show konyhazoldelol onlayer elotte
    if debraholcsinal == "konyha2":
        show debrafelmos:
            zoom 0.4
            xpos 0.15
            ypos 0.55
    if hanyadiknapvan == 3:
        show konyhaalapgep
        if kaveazasztalon2 == False:
            hide konyhamosatlan
            show debraregelkonyha3resz
        if kaveamamanakkesz == True:
            if kaveazasztalrolinvertoriba == False:
                show konyhakave
        if kutyatalakonyhaban == False:
            show fifikeesziktalures:
                xpos 0.53
                ypos 0.61
        if harmadikreszkonyha == 0:
            $ harmadikreszkonyha = 1
            jump beszedderaval3resz
        if harmadikreszkonyha == 4:
            show debrafoz
            jump beszedderaval3resz
        if beszeljaszomszedokkal == 2:
            if tejetvetem == True:
                show debrafoz
                if debraeszik == 1:
                    hide debrafoz
                    show debrakonyhabaneszikanim
                    show debrakonyhabaneszikalap
    if hanyadiknapvan >= 3:
        if felszereliaszurot == True:
            if akavekiontohejen == False:
                show konyhaalapgepalatetnekul
        if akavekiontohejen == True:
            show konyhaalapgepkesz
    if hanyadiknapvan == 4:
        if regell4resz == True:
            if mamanakteritve >= 1:
                if kaveamamanakkesz == True:
                    show konyhakave
            if mamanakkonyhaszedvics == True:
                show konyhatanyerszendvics
            if mamanakmegteritvakonyha == True:
                show mamakavezikanim
        if regell4resz == False:
            show konyhamosatlan
            show fifikeesziktalures:
                zoom 0.6
                xpos 0.25
                ypos 0.6
        if fifipoziciok == 1:
            if fifienikap == False:
                show fifiszagol:
                    zoom 0.6
                    xpos 0.25
                    ypos 0.6
                    alpha 1.0
                    pause 10.0
                    linear 1.0 alpha 0.0
                    pause 10.0
                    linear 1.0 alpha 1.0
                show fifiszagolpislog:
                    zoom 0.6
                    xpos 0.25
                    ypos 0.6
                    alpha 1.0
                    pause 10.0
                    linear 1.0 alpha 0.0
                    pause 10.0
                    linear 1.0 alpha 1.0
                show fifimorog:
                    zoom 0.6
                    xpos 0.25
                    ypos 0.6
                    alpha 0.0
                    pause 10.0
                    linear 1.0 alpha 1.0
                    pause 10.0
                    linear 1.0 alpha 0.0
        if fifipoziciok == 2:
            show fifikeesziktaltele:
                zoom 0.6
                xpos 0.25
                ypos 0.6
            show fifikeeszik:
                zoom 0.6
                xpos 0.25
                ypos 0.6
        if debraholcsinal == "konyhaeszik":
            show debrakonyhabaneszikanim onlayer hatso
            show debrakonyhabaneszikalap onlayer hatso
    if hanyadiknapvan == 5:
        show fifikeesziktalures:
            zoom 0.6
            xpos 0.25
            ypos 0.6
        if dolgozolmosogatas <= 1:
            show konyhamosatlan
        if dolgozolmosogatas == 2:
            show konyhamosotedeny
        if szedvisz1 == True:
            show konyhatanyerszendvicskep2:
                xpos 0.58
                ypos 0.48
        if szedvisz2 == True:
            show konyhatanyerszendvicskep3:
                xpos 0.52
                ypos 0.47
        if uditosmagamhozveni == 0:
            show teremkola3:
                xpos 0.65
                ypos 0.38
    if hanyadiknapvan >= 6:
        show konyhaszonyeg
    if hanyadiknapvan == 6:
        if debraholcsinal == "konyhatorol":
            show debrakonyhabantorolgetanim
        if mamanyaklanc == 0:
            show keresztnyaklanc:
                xpos 0.45
                ypos 0.9
        if debrafulbevalotmegkeresni1 == 1:
            show csillogaskicsianim:
                xpos 0.46
                ypos 0.94
        if regell6resz == True:
            if mamaholvan == "Konyha":
                show konyhabanmamahattal
    if hanyadiknapvan == 7:
        if szenyesmizeria == 0:
            show mamalabal1080:
                zoom 0.8
                xpos 0.1
                ypos 0.13
    if hanyadiknapvan == 8:
        if dolgozolmosogatas == 0:
            show konyhamosatlan
        if dolgozolmosogatas == 2:
            show konyhamosotedeny
        if debraholcsinal == "konyhatorol":
            show debrakonyhabantorolgetanim
        if mamaholvan == "konyha":
            show mamalabal2r11080:
                zoom 0.8
                xpos 0.17
                ypos 0.13
        if mozsarazasztalon == 1:
            show mozsarazinvertoriban:
                xpos 0.53
                ypos 0.43
    if hanyadiknapvan == 9:
        if poharnalad2 == 1:
            if poharbanban == "semmi":
                if adriananakvizkell == False:
                    $ poharnalad == True
                    show konyhapohar
                    $ poharnalad2 = 2
        if kutyatalakonyhaban == False:
            show fifikeesziktalures:
                xpos 0.53
                ypos 0.61
    if hanyadiknapvan == 10:
        if szedvisz1 == True:
            show konyhatanyerszendvicskep2:
                xpos 0.58
                ypos 0.48
        if szedvisz2 == True:
            show konyhatanyerszendvicskep3:
                xpos 0.52
                ypos 0.47
        if uditosmagamhozveni == 0:
            show teremkola3:
                xpos 0.65
                ypos 0.38
        if mamaholvan == "konyha":
            show mamalabal2r11080:
                zoom 0.8
                xpos 0.17
                ypos 0.13
    if hanyadiknapvan == 11:
        if szedvisz1 == True:
            show konyhatanyerszendvicskep2:
                xpos 0.58
                ypos 0.48
        if szedvisz2 == True:
            show konyhatanyerszendvicskep3:
                xpos 0.52
                ypos 0.47
        if uditosmagamhozveni == 0:
            show teremkola3:
                xpos 0.65
                ypos 0.38
    if hanyadiknapvan == 12:
        if szedvisz1 == True:
            show konyhatanyerszendvicskep2:
                xpos 0.58
                ypos 0.48
        if szedvisz2 == True:
            show konyhatanyerszendvicskep3:
                xpos 0.52
                ypos 0.47
        if uditosmagamhozveni == 0:
            show teremkola3:
                xpos 0.65
                ypos 0.38
        if debraholcsinal == "konyhatorol":
            show debrakonyhabantorolgetanim



    if debraholcsinal == "mosogat":
        show debramosogatanim
    if debraholcsinal == "foz":
        show debrafoz









    jump engedejek



$ renpy. pause(hard=True)
label uditomagamhozvenni:
    $ uditosmagamhozveni += 1
    $ beszedvalamivelkapcsolatban = "udito"
    jump tiltasok
$ renpy. pause(hard=True)
label uditomagamhozvenniszov:
    $ beszedvalamivelkapcsolatban = "semi"
    if kaveazasztalon == False:
        f "Debra! Is there something else to drink?"
        d "We have this! Shut up and take it! I will buy some other kind of drinks in the shop today."
        f "This juice is 100 percent... I do not like it…"
        d "Put water in a bottle if you do not like 100 percent juice... Asshole!"
        f "No... this is... ok..."
    jump engedejek
$ renpy. pause(hard=True)
label debrakanyhavissza:
    $ debrakonyhaban = False
    hide debrafoz
    show debrafoz:
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label debrakanyhavissza2:
    $ debrakonyhaban = False
    hide debrapultottorolanim
    show debrapultottorolanim:
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label poharudito:
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    $ kivelbeszelsz = "pohar"
    jump tiltasok
$ renpy. pause(hard=True)
label poharuditoszov:
    show screen udito
$ renpy. pause(hard=True)
label uditokesz2:
    hide screen udito
    $ poharnalad = True
    $ fekete = True
    show konyhapohar:
        alpha 1.0
        linear 2.0 alpha 0.0
    jump engedejek
$ renpy. pause(hard=True)
label raesosjelenet2nap:
    $ debratmegnezed = "raesve"
    jump tiltasok
$ renpy. pause(hard=True)
label raesosjelenet2napszov:
    play music "audio/szexy.ogg" fadeout 1
    hide screen invertori2
    hide invertori onlayer elotte6
    hide konyhazoldelol onlayer elotte
    show konyhazoldelol
    show fredelesik:
        alpha 0.0
        linear 0.5 alpha 1.0
    show screen s2
    f "aaaaaaa"
    show debrararaesnek1:
        alpha 0.0
        linear 1.0 alpha 1.0
    play sound "audio/fiuelesik.wav"
    with vpunch
    d "What are you thinking?"
    show debrararaesnek2:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Sorry! I slipped and fell. I did not want to. The floor is slippery."
    d "Your little dick is slippery! Pervert!"
    show megkemenyedopenis2nap1:
        alpha 0.0
        linear 0.5 alpha 1.0
    show megkemenyedopenis2nap2:
        alpha 0.0
        pause 1.0
        alpha 0.0
        linear 0.5 alpha 1.0
    show megkemenyedopenis2nap3:
        alpha 0.0
        pause 1.6
        alpha 0.0
        linear 0.5 alpha 1.0
    show megkemenyedopenis2nap4:
        alpha 0.0
        pause 2.0
        alpha 0.0
        linear 0.5 alpha 1.0
    show megkemenyedopenis2nap5:
        alpha 0.0
        pause 2.4
        alpha 0.0
        linear 0.5 alpha 1.0
    pause 4.0
    d "Get off me!"
    show raesoshater:
        alpha 0.0
        linear 0.5 alpha 1.0
    show segbebasosjelenet:
        alpha 0.0
        linear 0.5 alpha 1.0
    pause 5.0
    f "I wish to, but it is still slippery."
    hide segbebasosjelenet
    show segbebasosjelenet2 onlayer hatso
    pause 10.0
    d "Take your belt buckle out of my ass! It hurts a lot!"
    show ferdallofaszszem1
    hide fredelesik
    hide debrararaesnek1
    hide debrararaesnek2
    hide megkemenyedopenis2nap1
    hide megkemenyedopenis2nap2
    hide megkemenyedopenis2nap3
    hide megkemenyedopenis2nap4
    hide megkemenyedopenis2nap5
    hide debrafelmos
    hide debrapoz2meltartoval
    show debrapoz2meltartoval
    show raesoshater:
        alpha 1.0
        linear 1.0 alpha 0.0
    show segbebasosjelenet2 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    f "I am so sorry, The floor is extremely slippery. I do not want to molestate you!"
    f "I am sorry again!"
    d "I do not accept your apologies! I washed the floor just now but it is NOT SLIPPERY AT ALL!"
    d "Your belt buckle pushed my ass, it hurts still!"
    show debrapoz2meltartoval:
        alpha 1.0
        linear 0.5 alpha 0.0
    show debrapozelpirul:
        alpha 0.0
        linear 0.5 alpha 1.0
    f "I do not have any belt buckles... I would like to apologise for this as well. Your ass touched my... pepe… and…"
    hide debrapozelpirul
    show konyhazoldelol onlayer elotte
    hide konyhazoldelol
    show debrapozelcsuszik:
        zoom 0.9
        yalign 1.0
        xalign 1.0
        pause 0.75
        alpha 0.0
    show suhanle:
        zoom 0.9
        yalign 1.0
        xalign 1.0
        alpha 0.0
        pause 0.75
        alpha 1.0
        pause 0.1
        alpha 0.0
    show suhanle2:
        zoom 0.9
        yalign 1.0
        xalign 1.0
        alpha 0.0
        pause 0.85
        alpha 1.0
        pause 0.1
        alpha 0.0
    show screen s1
    d "I have to go now..."
    hide suhanle
    hide suhanle2
    hide debrapozelcsuszik
    hide ferdallofaszszem1
    show ferdallofaszszem2
    queue sound "audio/elesik.wav"
    with vpunch
    f "I told you! The floor is really slippery.."
    show debrafelmutatt1:
        alpha 0.0
        linear 0.5 alpha 1.0
    d "No! It is not slippery at all!"
    show debrafelmutatt1:
        alpha 1.0
        linear 0.5 alpha 0.0
    show debrafelmutatt2:
        alpha 0.0
        linear 0.5 alpha 1.0
    d "Go to your room!"
    $ debratmegnezed = "nemnezed"
    $ atjarosecialisengedej = 2
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    play music "audio/banyabolt.ogg" fadeout 1
    jump atjaro
$ renpy. pause(hard=True)
label beszedderaval3resz:
    $ fekete = True
    show konyhamosatlan
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    if harmadikreszkonyha == 4:
        hide screen invertori2
        $ harmadikreszkonyha = 5
        $ hoztejet = 1
        $ neznyomozosfilmet = 1
        $ beszeljaszomszedokkal = 1
        $ dolgozolmosogatas = 1
        $ szenyeseltakaritasa = 1
        $ penz += 1000
        $ dolgozolmosogatasido = 60
        pause 2.0
        show debrafoz:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz2:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "I have some job for you! Do you have time?"
        f "Yeah, of course!"
        d "Go to the shop and buy some milk."
        d "Wash the dishes please. You made it cool yesterday..."
        d "I give you money to buy milk. I have only a 1000 Forint banknote. Take it and buy something for the remaining money. Spend it on yourself!"
        f "Ok, but can I ask you something first?"
        show debrapoz2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Sure! Tell me!"
        f "I heard a rumor in the school. Some people tell, my dad did not commit suicide..."
        f "Did you hear something about this?"
        show debrapoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz4:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "I did not hear this kind of stuff. All i know is his business did not run well…"
        d "Some say he did not have money, some say he was rich..."
        show fiupoz2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "As I know, he lost some money but he sold some jewelry and got better financially."
        show debrapoz4:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz2:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "What are you thinking? Did he not commit suicide? Did someone kill him?"
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I do not. These rumors make me think."
        show debrapoz2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz4:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "It is hard to accept suicide and a lot of people can not understand why people do that."
        d "Maybe you try to find a way which is more acceptable."
        d "Were you two close to each other?"
        f "Not really. He was never at home. I didn't see him so often. Losing him is something I still can not feel."
        show debrapoz4:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "I understand. These rumors are strange, it is natural you want to know more."
        d "People talk shit, but maybe there can be something."
        d "I think you should ask around like a detective. I like detective stories, they have a lot of cool tricks. You should watch some films to learn a bit!"
        f "Do you think i should watch TV?"
        show debrapoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz2:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Well, you are slow… ask around asshole! Ask the neighbors! Did they see something?"
        show fiupoz2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Thank you for your advice. I will buy the Milk and will come back shortly!"
        show debrapoz2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapozelpirul:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Allright. I have to go now!"
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapozelpirul:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrafoz:
            alpha 0.0
            linear 1.0 alpha 1.0
    if harmadikreszkonyha == 1:

        show screen s3
        u ""
        hide screen invertori2
        hide invertori onlayer elotte6
        show hajigazitsexy2 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        u ""
        show hajigazitsexy2 onlayer elotte6:
            alpha 1.0
            linear 1.0 alpha 0.0
        hide debraregelkonyha3resz
        show debraregelkonyha3reszk3
        show fred3reszk5
        pause 2.0
        hide debraregelkonyha3resz
        d "Hey, Fred. Are you clever?"
        hide hajigazitsexy2 onlayer elotte6
        f "I do not know. Why do you ask?"
        d "My man bought me a coffee machine but i can not put the pieces together. I need to make a coffee."
        f "Do you like coffee? I see, you seem too tired."
        d "No, I do not drink coffee. Grandma asked for one. I just did not sleep so well."
        d "Why? Do I look bad?"
        f "No, just your hair is strange..."
        show debraregelkonyha3reszk3:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debraregelkonyha3reszk4:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 3.0
        show hajigazitsexy onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        u ""
        show hajigazitsexy onlayer elotte6:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        d "Is it better now?"
        hide hajigazitsexy onlayer elotte6
        show fred3reszk5:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fred3reszk6:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.0
        f "Yeah for sure... it is better and better!"
        d "Now prepare the coffee machine and show me how to make coffee!"
        f "{size=-10}Sure! You showed them to me, I will show it to you… "
        show debraregelkonyha3reszk3:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debraregelkonyha3reszk4:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        d "What did you say?"
        f "Nothing, I was just talking to myself..."
        d "Never mind..."
        show debraregelkonyha3resz:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debraregelkonyha3reszk3:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fred3reszk6:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
$ renpy. pause(hard=True)
label debraval3reszkonyhareggel:
    $ beszedvalamivelkapcsolatban = "konyhadebra"
    jump tiltasok
$ renpy. pause(hard=True)
label debraval3reszkonyhareggelszov:
    if debravalbeszeltel3resz == 3:
        $ debravalbeszeltel3resz = 0
    if debravalbeszeltel3resz == 2:
        $ debravalbeszeltel3resz = 3
        f "Does Grandma wake up early in the morning every day?"
        d "Not really. She missed an episode of Scary cunts yesterday and she woke up to watch the repetition."
        f "She looks scary!"
    if debravalbeszeltel3resz == 1:
        $ debravalbeszeltel3resz = 2
        d "Do you have so much time? You will get late!"
        f "I have some hours before my lessons begin..."
    if debravalbeszeltel3resz == 0:
        $ debravalbeszeltel3resz = 1
        f "Do you wake early every day?"
        d "Yes, but today I am tired."
    jump engedejek
$ renpy. pause(hard=True)
label kutyatalfelvesz:
    $ kutyatalakonyhaban = True
    show fifikeesziktalures:
        alpha 1.0
        linear 1.0 alpha 0.0
    if hanyadiknapvan == 9:
        $ kutyatalnalad = 1
        $ kutyatalban = "semmi"
    pause 1.0
    hide fifikeesziktalures
$ renpy. pause(hard=True)
label kutyakajatkiveszed:
    hide screen konyha
    if hanyadiknapvan == 3:
        $ kutyatalaltelenalad = True
        f "It is tasty!"
    if hanyadiknapvan == 4:
        if debrakutyatapboltban < 4:
            if kutyatapotkernidebratol == False:
                $ debrakutyatapboltban = 1
                $ kutyatapotkernidebratol = True
                f "I can not find dog food. I should ask Debra."
        if debrakutyatapboltban == 5:
            $ kutyatalaltelenalad = True
            $ kutyatapkibontva = True
            f "It is tasty!"
    if hanyadiknapvan == 9:
        if macskanakkinaltadakutyakajat == True:
            if vetelkiamacskanakkajatahutobol == 1:
                f "No milk in there. This is strange, I bought milk a few days ago…"
        if vetelkiamacskanakkajatahutobol == 0:
            $ vetelkiamacskanakkajatahutobol = 1
            $ kutyatalban = "kutyakaja"
    show screen konyha
$ renpy. pause(hard=True)
label kaveazasztalrolinvertoriba:
    $ kaveazasztalrolinvertoriba = True
    show konyhakave:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label mamavalbeszelniakonyhaban:
    $ beszedvalamivelkapcsolatban = "konyhamama"
    jump tiltasok
$ renpy. pause(hard=True)
label mamavalbeszelniakonyhabanszov:
    jump engedejek
$ renpy. pause(hard=True)
label letortakonzervnit:
    hide screen konyha
    $ debrakutyatapboltban = 3
    show eltortakonzevnyito onlayer kozep:
        alpha 0.0
        linear 0.5 alpha 1.0
    f "I can not believe this! I broke the can opener!I can not open it!"
    f "No problem... I will ask Debra for a can opener machine."
    show eltortakonzevnyito onlayer kozep:
        alpha 1.0
        linear 0.5 alpha 0.0
    show screen konyha
$ renpy. pause(hard=True)
label kutyatalfifinek:
    $ fifienikap = True
    $ fifipoziciok = 2
    $ fifitregeliztetni = 2
    hide fifimorog
    hide fifiszagol
    hide fifiszagolpislog
    show fifimorog:
        zoom 0.6
        xpos 0.25
        ypos 0.6
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifiszagol:
        zoom 0.6
        xpos 0.25
        ypos 0.6
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifikeesziktaltele:
        zoom 0.6
        xpos 0.25
        ypos 0.6
        alpha 0.0
        linear 1.0 alpha 1.0
    show fifiszagolpislog:
        zoom 0.6
        xpos 0.25
        ypos 0.6
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifikeeszik:
        zoom 0.6
        xpos 0.25
        ypos 0.6
        alpha 0.0
        pause 5.0
        linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
label zsacsitfelvesz:
    $ zsacskonalad = 2
    f "Fuck! Only one left!"
$ renpy. pause(hard=True)
label szedvisz1fel:
    $ ennivini += 1
    $ vanszedvicsed2 += 1
    $ szedvisz1 = False
    show konyhatanyerszendvicskep2:
        alpha 1.0
        linear 1.0 alpha 0.0
    if hanyadiknapvan == 10:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    if hanyadiknapvan == 11:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    if hanyadiknapvan == 12:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
$ renpy. pause(hard=True)
label szedvisz2fel:
    hide screen konyha
    $ ennivini += 1
    $ vanszedvicsed2 += 1
    $ szedvisz2 = False
    show konyhatanyerszendvicskep3:
        alpha 1.0
        linear 1.0 alpha 0.0
    if csiposzenyo == 1:
        f "Not really…"
    if hanyadiknapvan == 10:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    if hanyadiknapvan == 11:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    if hanyadiknapvan == 12:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    show screen konyha
$ renpy. pause(hard=True)
label teremkola3fel:
    $ uditosmagamhozveni += 1
    show teremkola3:
        alpha 1.0
        linear 1.0 alpha 0.0
    if hanyadiknapvan == 10:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    if hanyadiknapvan == 11:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
    if hanyadiknapvan == 12:
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if taskafel == 2:
                    $ tiltjaaterkepet = False
$ renpy. pause(hard=True)
label debrakanyhatorolget:
    $ debratmegnezed = "pultotorol"
    $ fekete = True
    jump tiltasok
label debrakanyhatorolgetszov:
    hide screen invertori2
    hide invertori onlayer elotte6
    hide konyhazoldelol onlayer elotte
    show konyhazoldelol
    show debramelle6resz:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    if hanyadiknapvan == 12:
        d "Leave me alon!"
        jump ugrik12napdebratorol
    if kerdezkorbe8resz == True:
        if receptnalad == 0:
            f "Do you know any recipe to heal sunburn?"
            dg "Cum on yourself you bastard… It might help you…"
            d "No. Go and buy some kind of ointment. I heard about some kind of tomato cream, but I do not know the recipe..."
            f "I need a lot of tomatoes to prepare such a cream. I have no money to buy tomatoes."
            d "I have no money! Go away! You disturb my concentration."
            f "What is your problem with me?"
            d "…Nothing…"
            f "…Ok…"
            $ debratkerdezted8resz = True
            if boltostkerdezted8resz == True:
                if debratkerdezted8resz == True:
                    if mamatkerdezted8resz == True:
                        $ fodoholvan = "boltelott"
            show debramelle6resz:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            hide debramelle6resz
            $ debratmegnezed = "nemnezed"
            hide konyhazoldelol
            show konyhazoldelol onlayer elotte
            show screen invertori2
            show invertori onlayer elotte6:
                yalign 0.0
            jump engedejek
    if receptnalad == 1:
        if lizanakmegmutatadareceptet == False:
            f "Can you read me this recipe?"
            d "Your writing is bullshit. Noone can read this!"
            f "Someone else wrote this, I have to find a way to read it."
            d "Ask someone else, Idiot!"
            f "Are you mad at me?"
            d "Agh…Noooo…"
            show debramelle6resz:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            hide debramelle6resz
            $ debratmegnezed = "nemnezed"
            hide konyhazoldelol
            show konyhazoldelol onlayer elotte
            show screen invertori2
            show invertori onlayer elotte6:
                yalign 0.0
            jump engedejek
    if debravalbeszed >= 4:
        $ debravalbeszed = 1
    if debravalbeszed == 3:
        $ debravalbeszed = 4
        d "Did you finish with the clean up?"
        f "Not yet…"
        d "In this case, you should harass the vacuum cleaner instead of me!"
    if debravalbeszed == 2:
        $ debravalbeszed = 3
        f "Why do you clean up every day?"
        d "Why do you NOT clean up every day?"
        f "I think I should go now…"
    if debravalbeszed == 1:
        $ debravalbeszed = 2
        f "I found the counter clean..."
        d "Who the fuck cares? I am cleaning it up!"
label ugrik12napdebratorol:
    show debramelle6resz:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    hide debramelle6resz
    $ debratmegnezed = "nemnezed"
    hide konyhazoldelol
    show konyhazoldelol onlayer elotte
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
$ renpy. pause(hard=True)
label keresztnyaklancfel:
    $ mamanyaklanc = 1
    show keresztnyaklanc:
        alpha 1.0
        linear 1.0 alpha 0.0
    show csillogaskicsianim:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label beszedmamavalkonyhaban6resz:
    $ beszedmamavalkonyhaban6resz = True
    hide kavejelalapfredk1kep1
    hide kavejelalapfredk11
    hide kavejelalapfredk1kep2
    hide screen invertori
    hide invertori onlayer elotte6
    hide konyhazoldelol onlayer elotte
    hide screen konyha
    hide kavejelalap
    hide mamapoz1
    show konyhazoldelol
    show kavejelalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show kavejelalapfredk1kep1:
        xpos -0.3
        ypos 0.15
        alpha 0.0
        linear 1.0 alpha 0.5
    show kavejelalapfredk11:
        xpos -0.3
        ypos 0.15
        alpha 0.0
        linear 1.0 alpha 1.0
    show kavejelalapfredk1kep2:
        xpos -0.3
        ypos 0.15
        alpha 0.0
        linear 1.0 alpha 0.5
    show mamapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    queue sound "audio/reszeg.ogg"
    show kavejelalapfredk1kep1:
        xpos -0.3
        ypos 0.15
        alpha 0.5
        linear 3.0 xpos -0.25
        linear 3.0 xpos -0.3
        repeat
    show kavejelalapfredk11:
        xpos -0.3
        ypos 0.15
        alpha 0.0
        linear 1.0 alpha 1.0
    show kavejelalapfredk1kep2:
        xpos -0.3
        ypos 0.15
        alpha 0.5
        linear 3.0 xpos -0.35
        linear 3.0 xpos -0.3
        repeat

    pause 2.0
    if mamavalbeszed >= 4:
        $ mamavalbeszed = 1
    if mamavalbeszed == 3:
        $ mamavalbeszed = 4
        m "I am drunk… it seems. I see a lot… of little assholes... Hiccup!"
    if mamavalbeszed == 2:
        $ mamavalbeszed = 3
        f "Who am I?"
        m "You are a sloppy vision... Leave me alone. Grandmother feels awful. She needs her coffee…"
    if mamavalbeszed == 1:
        $ mamavalbeszed = 2
        f "What are you doing Grandma? Are you making coffee?"
        m "Who the hell are you?"
        f "I am Fred! Do you not remember me?"
        m "You seem very suspicious, kid! I do not remember you! To be honest I do not remember my own name either…"
        f "I should go now. I have a lot to do. Get well soon Grandma!"
    show kavejelalap:
        alpha 1.0
        linear 1.0 alpha 0.0
    show kavejelalapfredk1kep1:
        xpos -0.25
        ypos 0.15
        alpha 0.5
        linear 1.0 alpha 0.0
    show kavejelalapfredk11:
        xpos -0.3
        ypos 0.15
        alpha 1.0
        linear 1.0 alpha 0.0
    show kavejelalapfredk1kep2:
        xpos -0.35
        ypos 0.15
        alpha 0.5
        linear 1.0 alpha 0.0
    show mamapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0

    hide konyhazoldelol
    show konyhazoldelol onlayer elotte
    show screen invertori
    show screen konyha
    show invertori onlayer elotte6:
        yalign 0.0
    $ fekete = True
    $ beszedmamavalkonyhaban6resz = False
    stop sound
    jump engedejek
$ renpy. pause(hard=True)
label beszedmamavalkonyhaban7resz:
    hide screen konyha
    hide konyhazoldelol onlayer elotte
    hide mamapoz2
    hide konyhakozeli
    hide fiupoz1
    show konyhazoldelol
    show konyhakozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamapoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    if vaszon1 == 0:
        if pulinapozoagya == 1:
            f "Grandma! Can I ask you something?"
            m "I have no money!"
            f "I need no money. I need some kind of linen fabric."
            m "Why should I own such a thing?"
            show fiupoz2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1:
                alpha 1.0
                linear 1.0 alpha 0.0
            f "I think Grandma is an old lady and old ladies usually sew and knit…"
            m "Your mother is old! I usually drink and play cardgames. Now I remember. I got some kind of linen fabric as a present. My grandchild gave it to me."
            m "I wanted to prepare a costume for the costume ball…"
            show fiupoz1:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz2:
                alpha 1.0
                linear 1.0 alpha 0.0
            m "Let me look after."
            show mamapoz2:
                alpha 1.0
                linear 1.0 alpha 0.0
                pause 1.0
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s3
            u ""
            $ vaszon1 = 1
            m "Is this what you need?"
            f "Yeah! This is perfect!"
            m "Fred! I warn you! If you call me OLD ever again, I will kill you…"
            f "Sorry!"
            show konyhakozeli:
                alpha 1.0
                linear 1.0 alpha 0.0
            show mamapoz2:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            show konyhazoldelol onlayer elotte
            hide konyhazoldelol
            show screen konyha
            $ renpy. pause(hard=True)
    f "What is for lunch?"
    m "Who the fuck cares? I am searching for alcohol! I have a terrible headache!"
    f "Ok, I have to go now…"
    show konyhakozeli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mamapoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show konyhazoldelol onlayer elotte
    hide konyhazoldelol
    show screen konyha
$ renpy. pause(hard=True)
label mosogatoalatireszkonyha:
    if hanyadiknapvan == 7:
        if parkbanjarsz >= 1:
            if szemeteszsaknalad == False:
                if szemeteszedtel < 8:
                    $ szemeteszsaknalad = True
                    f "I picked up a stronger bag."
                    $ renpy. pause(hard=True)
    if hanyadiknapvan == 8:
        if szemeteszsaknalad == False:
            if parktotiszta == False:
                if mehetszaparktohoz == True:
                    $ szemeteszak = 1
                    $ szemeteszedtel = 0
                    $ szemeteszsaknalad = True
                    f "I picked up a stronger bag."
                    $ renpy. pause(hard=True)
    if hanyadiknapvan == 9:
        if debraszivacsotestisztitoszertker9resz == True:
            if tisztitoszernalad == 0:
                $ tisztitoszernalad = 1
                f "Fine. I have the detergent."
                $ renpy. pause(hard=True)
    hide screen konyha
    f "Debra puts the bag and garbage bag here."
    show screen konyha
$ renpy. pause(hard=True)
label huto:
    if hanyadiknapvan == 8:
        if lizanakmegmutatadareceptet == True:
            if tojasnalad == 0:
                $ tojasnalad = 1
                $ targyazinvertoriban += 1
                $ renpy. pause(hard=True)
    hide screen konyha
    f "Refrigerator."
    show screen konyha
$ renpy. pause(hard=True)
label beszedmamavalkonyhaban8resz:
    hide screen konyha
    hide konyhazoldelol onlayer elotte
    hide mamapoz3r1
    hide konyhakozeli
    hide fiupoz1
    show konyhazoldelol
    show konyhakozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamapoz3r1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    if hanyadiknapvan == 8:
        if pokfelvetel == 1:
            if pokel == True:
                if rovarirtonalad == 0:
                    $ rovarirtokukaban = 1
                    m "Freddy! Go and buy me some insecticide!"
                    f "I have no money for that! You took all my money!"
                    m "I do not care! Bugs are all around in the garden. I want to kill them all."
                    f "I will try my best to find you an insecticide spray."
                    m "Ok! I am waiting for you here."
        if pokfelvetel == 1:
            if pokel == True:
                if rovarirtonalad == 1:
                    $ mamaholvan = "kertben."
                    $ pokel = False
                    $ rovarirtonalad = 2
                    $ targyazinvertoriban -= 1
                    f "I got an insecticide spray for you."
                    m "Thank you Freddy! Grandma goes and kills someone…Hahhahhha…"
                    hide mamalabal2r11080
    if hanyadiknapvan == 10:
        if cottonnalad == 0:
            $ mama10reszcotton = 1
            f "Grandma! Do you have a condom?"
            m "What do you need a condom for?"
            f "I… I wish to use it…"
            m "Tough so… I am an old Lady you little asshole. I do not need any protection anymore. I am not afraid of illnesses either. I lived a happy, full and long life. I could die in piece…"
            m "Sometimes I am surprised I live. I drink so much alcohol I could die any minute from alcohol poisoning…"
            f "Ahha… undersood. I will look for a condom somewhere else…"
            if mama10reszcotton == 1:
                if fodo10reszcotton == 1:
                    if eszter10reszcotton == 1:
                        $ zoliholvan = "othon"
        if cottonnalad >= 1:
            m "Did you find a condom Freddy?"
            f "Yeap! I got it!"
            m "I am happy. Keep safe! You do not want to become a father at the age of 21, do you?"
    show konyhakozeli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mamapoz3r1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show konyhazoldelol onlayer elotte
    hide konyhazoldelol
    show screen konyha
$ renpy. pause(hard=True)
label debrakonyhabanfoz2:
    hide screen konyha
    hide konyhazoldelol onlayer elotte
    show konyhazoldelol
    hide screen invertori
    hide invertori onlayer elotte6
    hide debrafozkemenyen
    show debrafozkemenyen:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "I put the bowl on the table. Leave me alone!"
    show debrafozkemenyen:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show konyhazoldelol onlayer elotte
    hide konyhazoldelol
    show screen konyha
$ renpy. pause(hard=True)
label mozsarhasznal:
    hide screen konyha
    $ invertorieszkozszam = 0
    $ receptnalad = 2
    $ tojasnalad = 2
    $ tulipannalad = 2
    $ lizaviragnalad = 2
    $ gyongyviragnalad = 2
    $ elesztonalad = 2
    $ poknalad = 2
    $ gombanalad = 2
    $ uditosmagamhozveni = 2
    hide screen ujraszamolinvertori

    show screen receptelkeszitese
    show screen s5
    u ""
    show debrafoz:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrakonyhabaneszikanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrakonyhabaneszikalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s10
    u ""
    show debrakonyhabaneszikanim:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrakonyhabaneszikalap:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debramosogatanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    $ debraholcsinal = "mosogat"
    show screen s5
    u ""
    $ mozsarazasztalon = 2
    show mozsarazinvertoriban:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen konyha
$ renpy. pause(hard=True)
label poharfel:
    $ poharnalad2 = 1
    $ poharnalad = True
    show konyhapohar:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label vizapoharba:
    play sound "audio/viz13.wav"
    $ poharbanban = "vizes"
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
