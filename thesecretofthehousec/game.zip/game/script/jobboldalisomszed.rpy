label jobboldaliszomszed:
    $ invertorikep = False
    if hanyadiknapvan == 3:
        $ jobboldaliszomszed = 1
        if baloldaliszomszed == 1:
            if jobboldaliszomszed == 1:
                $ beszeljaszomszedokkal = 2
        f "Noone is home!"
    if hanyadiknapvan == 4:
        if regell4resz == True:
            f "I have no time to visit the neighbors."
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 5:
        if zolivalbeszeltel == 1:
            if holvagyok == "terkep":
                f "Zoli is sleeping now. I check the street."
                jump baloldaliszomszed
            if holvagyok == "baloldaliszomszed":
                f "Zoli is sleeping, I can not disturb him."
                show screen baloldalisomszed
                $ renpy. pause(hard=True)
        if regell5resz == True:
            f "I have no time to visit the neighbors."
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 6:
        if holvagyok == "terkep":
            f "Zoli is sleeping now. I check the street."
            jump baloldaliszomszed
        if holvagyok == "baloldaliszomszed":
            f "Zoli is sleeping, I can not disturb him."
            show screen baloldalisomszed
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 7:
        if szerezegymobilt == 3:
            if holvagyok == "terkep":
                f "Zoli is sleeping, I can not disturb him."
                jump baloldaliszomszed
                $ renpy. pause(hard=True)
        if szerezegymobilt == 3:
            if holvagyok == "baloldaliszomszed":
                f "Zoli is sleeping, I can not disturb him."
                show screen baloldalisomszed
            $ renpy. pause(hard=True)
        $ holvagyok = "jobboldaliszomszed"
        jump tiltasok
    if hanyadiknapvan == 8:
        if holvagyok == "terkep":
            f "Zoli is sleeping, I can not disturb him."
            jump baloldaliszomszed
            $ renpy. pause(hard=True)
        if holvagyok == "baloldaliszomszed":
            f "Zoli is sleeping, I can not disturb him."
            show screen baloldalisomszed
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 9:
        if holvagyok == "terkep":
            f "Zoli is sleeping, I can not disturb him."
            jump baloldaliszomszed
            $ renpy. pause(hard=True)
        if holvagyok == "baloldaliszomszed":
            f "Zoli is sleeping, I can not disturb him."
            show screen baloldalisomszed
            $ renpy. pause(hard=True)
    if hanyadiknapvan >= 10:
        if cottonnalad >= 1:
            $ zoliholvan = "sehol"
        if zoliholvan == "othon":
            $ holvagyok = "jobboldaliszomszed"
            $ invertorinejelenyenmeg = True
            jump tiltasok
        else:
            if holvagyok == "terkep":
                f "Zoli is sleeping, I can not disturb him."
                jump baloldaliszomszed
                $ renpy. pause(hard=True)
            if holvagyok == "baloldaliszomszed":
                f "Zoli is sleeping, I can not disturb him."
                show screen baloldalisomszed
                $ renpy. pause(hard=True)
    if hanyadiknapvan >= 4:
        $ holvagyok = "jobboldaliszomszed"
        $ invertorinejelenyenmeg = True
        jump tiltasok


$ renpy. pause(hard=True)
label jobboldaliszomszedszov:
    if hanyadiknapvan == 4:
        $ invertorinejelenyenmeg = True
        show zolibeszed4resz
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        $ jobboldaliszomszed = 1
        $ debraholcsinal = "napaliban2"
        $ fifipoziciok = 4
        $ esteighatralevoido = 0
        f "Hy Zoli! Do you have time for me now?"
        z "Hell... yeah… i have time now man!"
        f "I would like to ask, did you see something strange before my home burned down?"
        z "Well... yeah... I saw fire and fire men..."
        f "I did not mind this of course! Did you see anybody before you noticed the fire?"
        z "Well... yeah... I saw someone i guess…"
        z "I talked about this to the cops… but i do not know for sure... I was drunk…"
        f "Ok, so you are not so sure…"
        z "I was drunk... I really do not know. The policemen did not believe me..."
        f "I thank you for your information. I should go now..."
        z "Hell! Man! Wait! I did not tell you the biggest thing yet! A stranger guy is searching between the ruins every night."
        f "A stranger? What does he look like?"
        z "Hell! Ask my penis! It is totally dark at night…"
        f "… Did you see his form?"
        z "It must be a big guy. He is wearing a coat..."
        f "Any more information?"
        z "I wake up every night. I am hearing a strange humming... I can not remember the title..."
        z "Hell! Wait a bit! Something like this…” himm him... himm.. hihihimm ... himminiim... hiimmnl..."
        z "Or something similar... It is a bit like the Oh Tannenbaum song... oh Man! He is humming this shit always... It is like the disk is stuck and plays the song again and again…"
        f "Why did you not call the police?"
        z "I had vomited on the shoes of the police captain… he doesn't like me I guess.. I leave it... I do not want to get into trouble again…"
        f "Do you have anything more to say?"
        z "Yeah man! He moved really slow, I think he limped... but I am not sure... he had a big coat…"
        f "Thank you Zoli! You helped a lot! Now i have something in my hand to find him! I have to go now!"
        z "Hell! Yeah! Go man! I have to sleep a bit. I have to go to work soon…"
        f "I am off now bro!"
        z "Bye man!"
        jump terkep
    if hanyadiknapvan == 5:
        hide screen invertori2
        hide screen invertori
        hide invertori onlayer elotte6
        show zolibeszed4resz
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        if zolivalbeszeltel == 2:
            $ zolivalbeszeltel = 1
            $ zoliinfo = True
            z "Why did you wake me man?"
            f "I have a question for you! This is really important."
            f "What kind of skin color did the stranger have? Balck or white?"
            z "Whoooahh... I think… he was black... I am sure he was black…"
            f "Thank you! I think I am on the right track now!"
            z "I am happy! I'm going to sleep a bit. Bye!"
            f "Bye! Thank you Bro! I need to go to the strip bar to check the black man for sure."
            $ invertorinejelenyenmeg = True
            jump terkep


        if lizanaljatal == 1:
            f "Hy Zoli! Did you not see Liza?"
            z "Hell... I do not know. She is in the supermarket I guess..."
            if zolivalbeszeltel == 1:
                f "Thank you! I will check the market."
                z "Hell... ok, bye bye!"
        if zolivalbeszeltel == 0:
            $ zolivalbeszeltel = 1
            if lizanaljatal == 0:
                f "Hello Zoli!"
                z "What is up?"
            f "I heard about a homeless guy. He is living around here somewhere."
            z "Yeah, he is the old Lightskin Fodo."
            f "Is he lame?"
            z "Yeah, he is lame."
            f "Was he searching around the ruins yesterday night?"
            z "How should I know this? You should ask him."
            f "Thank you for your help! I will come back later!"
            z "Ok! Chauuu!"
    if hanyadiknapvan == 7:
        hide screen invertori2
        hide screen invertori
        hide invertori onlayer elotte6
        show zolibeszed4resz
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        if szerezegymobilt == 2:
            $ beszeljzolival = 2
            $ szerezegymobilt = 3
            f "Here is my phone number: + 36……."
            z "Ok Bro! I will call you when I notice the guy between the ruins."
            f "Thank you! Bye!"
        if szerezegymobilt < 2:
            $ beszeljzolival = 1
            $ szerezegymobilt = 1
            f "Hello Zoli! Can I ask you a favor?"
            z "Spit it out Bro!"
            f "Can you call me if you see the lame guy again?"
            z "Sure man! Just give me your phone number. I can not just run around at night you know…"
            f "Oh shit! I have no mobile phone. Debra has a landline phone in her office room but she will be angry if you call us in the middle of the night…"
            z "Buy a phone man!"
            f "I have to solve this problem. Thank you! I will come back soon!"
            z "Bye!"
    if hanyadiknapvan == 10:
        hide screen invertori2
        hide screen invertori
        hide invertori onlayer elotte6
        show zolibeszed4resz
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        $ zoli10reszcotton = 1
        f "Hy Zoli. I am sorry to wake you up, but can you lend me a condom?"
        z "What? Lend you a condom? Will you give the condom back after you use it? Oh man!"
        f "Oh well! Do not play with me! I am in a hurry!"
        z "Ok Bro! I will tell you a big secret. Do not tell this to anybody!"
        z "There is an emergency box in the old cemetery. It lies next to the gate. There is a condom in there."
        z "If you did not find any in there, it sucks. Someone forgot to put back a new condom."
        f "I tried to open the box. It is closed."
        z "Nope! It is hard to open."
        f "Ok... but why is there a condom? Why do people put a new one inside the box?"
        z "It has a good reason, man! The condom box is cursed. You take the condom and you have to put a new one back in the box."
        z "If you forget to put a new condom back, the girl you fucked will get pregnant for sure."
        f "I do not believe in such curses, but well… Ok. I will take the condom and I will put it back tomorrow."
        z "Yeah… put it back for sure man! I might need it…"
        f "Ok, thank you! I should go now. I am in a hurry."
    if hanyadiknapvan == 12:
        hide screen invertori2
        hide screen invertori
        hide invertori onlayer elotte6
        show zolibeszed4resz
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        $ kokonalad -= 1
        $ zoliholvan = "sehol"
        $ zolinakadtalkokot = True
        z "Hy Fred! What is new?"
        f "Well… You are the only person I know called Zoli."
        z "Did the Zolis die out from MariaCity? Do I belong to the endangered species?"
        f "Do you know Cili?"
        z "Yeah! She is a sexy bitch. It is impossible to reach her… Why?"
        f "Are you waiting for a package from Cili?"
        z "What the fuck!? Are you a policeman or what?"
        f "No. Do not worry. Are You waiting for a package with white powder in it or not?"
        z "Are you the new delivery-boy? Give me that bag! Brother! I need it!"
        f "I deliver the stuff, but only this time."
        z "Yeah, of course…"
        f "Here you are. I have to go now."
        z "Oh and Fred! You do not know anything about this, ok?"
        f "Believe me, I want to forget all about this."
        z "Bye!"
        if kokonalad == 1:
            $ lidiaholvan = "cukrazdabanszamlazik"
            $ debraholcsinal = "napaliban3"



    $ invertorinejelenyenmeg = True
    jump baloldaliszomszed






$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
