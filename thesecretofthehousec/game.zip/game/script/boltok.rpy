label bolttok:
    $ holvagyok = "boltoknal"
    jump tiltasok


$ renpy. pause(hard=True)
label bolttokszov:
    show boltokhatere
    show boltokhatereauto
    if hanyadiknapvan == 12:
        if esteighatralevoido == 0:
            hide boltokhatere
            show boltokhatereeste
    if hanyadiknapvan == 5:
        if regell5resz == False:
            if kolduskulacsa < 2:
                hide boltokhatereauto
                show taska5resz:
                    zoom 0.5
                    xpos 0.73
                    ypos 0.84
                show koldoskurvamagas490:
                    zoom 0.9
                    xpos 0.69
                    ypos 0.558
        if lizanaljatal >= 1:
            if lizagyurulye < 4:
                $ lizanaljatal = 2
                show lizapoz1540ngy:
                    xzoom -1.0
                    zoom 1.1
                    xpos 0.12
                    ypos 0.48
                show lizazacsija540:
                    xzoom -1.0
                    zoom 1.1
                    xpos 0.12
                    ypos 0.48
    if hanyadiknapvan == 6:
        if mamanyaklanc < 2:
            show taska5resz:
                zoom 0.5
                xpos 0.73
                ypos 0.84
            show koldoskurvamagas490:
                zoom 0.9
                xpos 0.69
                ypos 0.558
        show kitty540:
            zoom 1.12
            xpos 0.455
            ypos 0.496
        show rita540:
            zoom 0.93
            xpos 0.53
            ypos 0.56
        if anikafodomellet6resz == False:
            show anikalabbal540:
                zoom 0.9
                xpos 0.1
                ypos 0.52
        show csovesfodo540:
            zoom 1.1
            xpos 0.22
            ypos 0.51
    if hanyadiknapvan == 7:
        if adrianahazaakarmenni == True:
            if svetlanaermeje < 2:
                show taska5resz:
                    zoom 0.5
                    xpos 0.73
                    ypos 0.84
                show koldoskurvamagas490:
                    zoom 0.9
                    xpos 0.69
                    ypos 0.558
        if vaszon2 == 0:
            show vaszon2azinvertoriban:
                zoom 0.6
                xpos 0.96
                ypos 0.78
            hide boltokhatereauto
            if parkadriana < 2:
                show boltokhatereauto
        if adrianahazaakarmenniszojbramnak == False:
            show rozsa540:
                zoom 0.8
                xpos 0.25
                ypos 0.58
        if gyulaelmegy == False:
            show gyula540:
                zoom 0.9
                xpos 0.18
                ypos 0.55
    if hanyadiknapvan == 8:
        if fodoholvan == "boltelott":
            show csovesfodo540:
                zoom 1.1
                xpos 0.22
                ypos 0.51
        if svetlana == "boltnal":
            show taska5resz:
                zoom 0.5
                xpos 0.73
                ypos 0.84
            show svetlana540:
                zoom 0.8
                xpos 0.71
                ypos 0.558
    if hanyadiknapvan == 9:
        if puffyholvan == "boltnal":
            show dagi540allas1:
                zoom 0.7
                xpos 0.65
                ypos 0.6
        if svetlana == "boltnal":
            show taska5resz:
                zoom 0.5
                xpos 0.73
                ypos 0.84
            show svetlana540:
                zoom 0.8
                xpos 0.71
                ypos 0.558
        if pulikutyaholvan == "boltoknal":
            $ Edwardsholvan = "parkban"
            show boltokhaterepuli
    if hanyadiknapvan == 10:
        if svetlana == "boltnal":
            show taska5resz:
                zoom 0.5
                xpos 0.73
                ypos 0.84
            show svetlana540:
                zoom 0.8
                xpos 0.71
                ypos 0.558
    if hanyadiknapvan >= 11:
        if fodoholvan == "boltelott":
            show csovesfodo540:
                zoom 1.1
                xpos 0.22
                ypos 0.51
        if rozsaholvan == "boltoknal":
            show rozsa540:
                zoom 0.7
                xpos 0.55
                ypos 0.55
    show screen invertori
    show screen invertoriszov
    show invertori onlayer elotte6:
        yalign 0.0
    if hanyadiknapvan == 8:
        if svetlana == "boltnal":
            if svetlanapan == 0:
                hide screen invertori
                hide invertori onlayer elotte6
    if hanyadiknapvan >= 9:
        if sanyiholvan == "boltnal":
            show sanyialap540:
                zoom 0.8
                xpos 0.22
                ypos 0.57
        if bandiholvan == "boltnal":
            show banditopoganim:
                zoom 0.8
                xpos 0.52
                ypos 0.52
    if hanyadiknapvan == 12:
        if eszterholvan == "boltelott":
            show eszterall540:
                zoom 0.8
                xpos 0.55
                ypos 0.55
        if ancikaholvan == "boltnal":
            show ancika2540:
                xzoom -1.0
                zoom 0.8
                xpos 0.46
                ypos 0.55
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    if hanyadiknapvan == 8:
        if svetlana == "boltnal":
            if svetlanapan == 0:
                $ svetlanapan = 1
                show csillagok6resz onlayer elotte:
                    xpos 0.1
                    ypos -3.5
                    linear 10.0 ypos 1.2
                show svetlanapan onlayer elotte:
                    xpos 0.1
                    ypos 1.2
                    linear 10.0 ypos -3.5
                show screen s1e5
                u ""
                play sound "audio/csillag.ogg"
                show screen s8e5
                u ""
                show screen invertori
                show invertori onlayer elotte6:
                    yalign 0.0
                hide svetlanapan onlayer elotte
                hide csillagok6resz onlayer elotte
    if hanyadiknapvan == 12:
        if esteighatralevoido > 0:
            if esztercsilogot == False:
                $ esztercsilogot = True
                show csillagok6resz onlayer elotte:
                    xpos 0.1
                    ypos -3.5
                    linear 10.0 ypos 1.2
                show eszterpan onlayer elotte:
                    xpos 0.1
                    ypos 1.0
                    linear 10.0 ypos -2.0
                show screen s1e5
                u ""
                play sound "audio/csillag.ogg"
                show screen s8e5
                u ""

    show screen bolt









$ renpy. pause(hard=True)
label toolshop:
    $ ladabanvanvalamiszamodra = False
    if hanyadiknapvan <= 4:
        f "I have nothing to do there."
        $ renpy. pause(hard=True)
    if hanyadiknapvan == 5:
        if felmosotvenni == 2:
            if kolduskulacsa >= 2:
                if barkacsboltosalbeszelni == 2:
                    f "I have nothing to do there."
                    $ renpy. pause(hard=True)
    hide screen bolt
    hide screen invertori
    show screen invertori2
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    show barkacsbolt:
        ypos 0.12
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    if hanyadiknapvan == 7:
        if parkadriana == 1:
            show brambarkacsboltban
    if hanyadiknapvan >= 11:
        if bramholvan == "barkacsboltban":
            show brambarkacsboltban
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    p "Welcome! Look around!"
    hide screen invertori2
    show screen invertoriszov
    show screen invertori
    show screen toolshop
$ renpy. pause(hard=True)
label sindyclothingstore:
    f "I have nothing to do there."
$ renpy. pause(hard=True)
label supermarket:
    $ ladabanvanvalamiszamodra = False
    hide screen bolt
    hide screen invertori
    show screen invertori2
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    show boltbelulrol1
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    e "Welcome! Look around!"
    hide screen invertori2
    show screen invertoriszov
    show screen invertori
    show screen vegyesboltaru
$ renpy. pause(hard=True)
label supermarketki:
    $ ladabanvanvalamiszamodra = True
    hide screen invertori
    show screen invertori2
    hide screen vegyesboltaru
    e "Goodbye! See you soon!"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    hide screen invertoriszov
    hide boltbelulrol1
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen invertori
    hide screen invertori2
    show screen invertoriszov
    show screen bolt
$ renpy. pause(hard=True)
label toolshopki:
    $ ladabanvanvalamiszamodra = True
    hide screen invertori
    show screen invertori2
    hide screen toolshop
    p "Goodbye! See you soon!"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    hide brambarkacsboltban
    hide screen invertoriszov
    hide barkacsbolt
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    if hanyadiknapvan == 7:
        hide brambarkacsboltban
        if szoltalbramnakadrianarol == True:
            hide boltokhatereauto
    show screen invertori
    hide screen invertori2
    show screen invertoriszov
    show screen bolt
$ renpy. pause(hard=True)
label toolshoppiribeszed:
    hide screen toolshop
    hide screen invertori
    show screen invertori2
    if hanyadiknapvan == 5:
        if barkacsboltosalbeszelni == 1:
            $ barkacsboltosalbeszelni = 2
            f "I am sorry! Can I ask you something?"
            p "Of course! What can I help you with?"
            f "Do you know any lame customers?"
            p "I can not tell you about any personal information of my costumer. Sorry!"
            f "Oh no… It is really important."
            p "Sorry, I have rules to follow."
            f "I found a crutch and I would like to give it back to its owner."
            p "Give it to the police."
            f "Thank you for your help!"
            p "You are welcome! Byebye!"
        if kolduskulacsa == 1:
            f "Do you have any lamps?"
            p "Not really. I sell screwdrivers, hammers,screws…. The lamp shop is closed today."
            f "Thank you!"
    if hanyadiknapvan == 6:
        if gerebjekell == 1:
            f "Do you sell any rakes?"
            p "Not really, I am sorry!"
            f "Nice as fuck… thank you…"
            p "Nothing happened... Bullshit!"
        if lizakertjemadarhaza == 2:
            if csavarhuzo6resz == 0:
                $ kerdeztedabarkacsboltostol6resz = True
                f "Do you have any screwdrivers?"
                p "I sold the last one in the morning. You have no luck…"
                p "I can order you a screwdriver if you like. 2 weeks and you will have it."
                f "Thank You! I will look for it somewhere else…"
    if hanyadiknapvan == 7:
        if vaszon2 == 0:
            f "Do you have sewing kit to sell? Do you sell linen fabric?"
            p "Of course and if you need sailcloth for your ship, just visit us and we will help!"
            f "Ehm…Understood…Thank you!"
    if hanyadiknapvan == 8:
        if receptnalad == 1:
            if lizanakmegmutatadareceptet == False:
                f "Can you read this recipe?"
                p "No…"
    if hanyadiknapvan == 10:
        if kerjmunkatkerhec == True:
            if ladatmegtalalhatod == 0:
                f "Do you have any job offers for me?"
                p "Not really. Do you have a curriculum vitae?"
                p "Give me a CV and I will put you on the list."
                f "No need for that. Thank you!"
                p "In this case, I can not help you…"
    if hanyadiknapvan == 11:
        if beszeltelbrammalabajusrol == False:
            f "Hello! Do you have any artificial mustaches in your tool shop?"
            p "What are you thinking of? This is a tool shop."
            f "Sorry. I only asked it to be sure. Do you know any place where I could get an artificial mustache?"
            p "I have no clue. I do not need any artificial mustaches… I am a lady…"
            f "Still… Thank you!"
        if beszeltelbrammalabajusrol == True:
            f "Hy Piri. Sorry to disturb you but I learned that this shop was a costume rental in the past."
            p "It is possible. I really do not know…"
            f "Could you please look around in the storage. Maybe there is an old box left. I am searching for an artificial mustache."
            p "Well… I saw an old dirty box in the corner... I do not know what it contains."
            p "I will check it for you, but do not expect too much! We threw out everything when we moved in..."
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            p "This is your lucky day boy! I found some old costumes in the box and a few artificial mustaches. This one is similar to your hair color."
            f "Super! Can I please have it? I see the price: 400 Forints."
            $ penz -= 400
            $ mubajuszkell = 2
            f "I am so happy now. You saved me! I had no idea where I could find an artificial mustache..."
            p "Never mind..."
            if oroszkonyvnalad == 1:
                if mubajuszkell == 2:
                    if nyomortanyadoboz1nalad == 2:
                        $ hazamehetc = True
    hide screen invertori2
    show screen invertori
    show screen toolshop
$ renpy. pause(hard=True)
label boltosalesterbeszed:
    hide screen vegyesboltaru
    hide screen invertori
    show screen invertori2
    if hanyadiknapvan == 5:
        if boltosalbeszelni == 1:
            $ boltosalbeszelni = 2
            f "Can I ask you something?"
            e "Of course you can! Tell me!"
            f "Do you know any lame, customers?"
            e "Yeah we have a lame guy. Mr.Lightskin."
            f "Is he a huge guy?"
            e "Well... yeah!"
            f "Is he humming?"
            e "I do not know, but he is drinking a lot of alcohol."
            e "We call him Mr. Lightskin Fodo. His skin color gets really light while he is vomiting."
            f "Is he dark skinned?"
            e "No. He is white skinned."
            f "Thank you for your help."
            e "Why do you ask?"
            f "A lame guy is searching under the ruins every night. I would like to know who he can be."
            e "I understand. I will keep an eye on the ruins. I will call you if I see him."
            f "Thank you very much!"
            e "Come and buy something every day!"
            f "I will try my best! Goodbye!"
        if kolduskulacsa == 1:
            f "Can I buy a lamp in your shop?"
            e "We do not sell any electronic items. You should visit the Tool shop."
            f "Thank you! I will go there."
    if hanyadiknapvan == 6:
        if gerebjekell == 1:
            f "Do you sell any rakes?"
            e "Sure, you can find a rake next to the tractors. Go to the toy section and pick up a nice sandplay set. "
            f "I thought of a rake for adults."
            e "In this case I can not help you. We are in a supermarket. I sell food the most."
            f "Thank you Ester! I will look around somewhere else!"
            e "You are welcome!"
        if lizakertjemadarhaza == 2:
            if csavarhuzo6resz == 0:
                f "Do you sell any screwdriver?"
                e "Nope!"
            if csavar6resz == 0:
                f "Do you sell screws?"
                e "No…"
    if hanyadiknapvan == 7:
        if vaszon2 == 0:
            f "Do you have sewing kit to sell? Do you sell linen fabric?"
            e "I am sorry, but no…"
    if hanyadiknapvan == 8:
        if kerdezkorbe8resz == True:
            if receptnalad == 0:
                f "Do you have any tricks to heal sunburn fast?"
                e "Never heard of any working recipes, but I heard about butter. Maybe it helps."
                f "I think it does not help at all..."
                e "I will pass. Come and buy the ingredients here if you find a good recipe!"
                f "Alright Bye!"
                $ boltostkerdezted8resz = True
                if boltostkerdezted8resz == True:
                    if debratkerdezted8resz == True:
                        if mamatkerdezted8resz == True:
                            $ fodoholvan = "boltelott"
            if receptnalad == 1:
                if lizanakmegmutatadareceptet == False:
                    f "Can you read this recipe?"
                    e "Nope!"
    if hanyadiknapvan == 10:
        if kerjmunkatkerhec == True:
            if ladatmegtalalhatod == 0:
                f "Hello! Do you have any job offers for me?"
                e "I am sorry, but no. We do not have so much work nowadays. We have just a few customers."
                e "We had some problems with the taxing office last year, so…"
                f "I totally understand. Thank you!"
                e "I am so sorry!"
        if fagylaltoknalad == 2:
            if cottonnalad == 0:
                $ eszter10reszcotton = 1
                f "Do you sell condoms?"
                e "Yeah, but we ran out of it. I sold the last one on Friday. "
                f "SHIT! No condom?"
                e "We receive such merchandise only on Tuesday."
                f "I should find someone who owns some…"
                e "Good luck!"
                f "Do you use condoms?"
                e "Nice try! I have a new boyfriend. I need it. Sorry!"
                f "Fuck! Thanks…"
                if mama10reszcotton == 1:
                    if fodo10reszcotton == 1:
                        if eszter10reszcotton == 1:
                            $ zoliholvan = "othon"
    if hanyadiknapvan == 11:
        if cottonkell11nap == 1:
            $ eszterrelbeszeltel11nap = True
            f "Hy! Do you have any condoms?"
            e "Are you kidding me? We received a shipment early in the morning, but all condoms were sold. A large rural buyer came and bought every single piece."
            f "But I need a condom!"
            e "I understand... Maybe you can ask the buyer to sell you one."
            f "Ok. Where can I find him? What does he look like?"
            e "I do not know. He is traveling with a donkey..."
    hide screen invertori2
    show screen invertori
    show screen vegyesboltaru
$ renpy. pause(hard=True)
label lizabeszedboltnal:
    hide screen bolt
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    show anikamomngy:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    if lizanalbeszeltel == 0:
        $ lizanalbeszeltel = 1
        $ lizagyurulye = 1
        f "Hy Liza!"
        l "Will you visit me today in the Strip bar? You promised!"
        f "Yeah, I wanted to tell you about that."
        l "Cool, but I am in big trouble! I lost my wedding ring. I need to wear it in the srtip bar. My customers love it!"
        f "Where have you been?"
        l "I do not know. I was home... I came to the supermarket…"
        f "I will help you to find the ring."
        l "Thank you Honey!"
        f "Stay here and look around. I will go and check the street and the yard around your house."
        l "Ok, I'm waiting for you here."
        jump lizabeszedboltnalki
    if lizagyurulyesvetlanatol == 2:
        $ lizagyurulyesvetlanatol = 3
        $ lizavalbeszeltelapenzrol = True
        $ penzemhianyzik = 10000 - penz
        f "I need a lamp. Can you lend me some?"
        l "I can lend you a lamp tomorrow, but now I am quite busy."
        f "This is sad. I found your ring but I need to give a lamp to a person… this person gives me another thing and… I just run around like crazy…"
        f "Everyone needs something... and I do not have enough money to buy a lamp..."
        l "I spent all my money in the supermarket as well. I can not help you but to be honest… I do not understand a single word you say!"
        f "No problem! I will make it! I should ask Debra about the lamp."
        l "Ok Honey. I wait for you here!"
        jump lizabeszedboltnalki
    if lizagyurulye == 3:
        $ lizagyurulye = 4
        l "Did you find the ring? I need to go to work now…"
        f "Yeah, I found it."
        f "I will give it back, but first... let me touch your boobs in the name of Lightskin Fodo."
        l "I do not mind, but give me my ring back first!"
        hide anikamomngy
        show anikamom:
            xzoom -1.0
        f "Here you are!"
        l "My breasts are here! What are you waiting for?"
        $ zolivalbeszeltel = 2
        show screen lizaboltnal

        $ renpy. pause(hard=True)
        label lizaboltnalfogdos:
            hide fiupoz1
            show ferdallofaszszem1:
                xzoom -1.0
            show nagyonkozelibolt
            show lizafogdosas5reszalap
            show lizafogdosas5reszanim
            show lizafogdosas5reszszemanim
            show lizafogdosas5reszszemanim
            show lizafogdosas5reszszaj4
            pause 5.0
            hide lizafogdosas5reszszaj4
            show lizafogdosas5reszszajanim
            l "You are so shameless. You started to rub my boobs on the street and in daylight. Your hormones are working well. I do not care! Touch my boobs!"
            show lizafogdosas5reszszaj4
            hide lizafogdosas5reszszajanim
            f "Your breasts are wonderful!"
            pause 5.0
            show nagyonkozelibolt:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizafogdosas5reszalap:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizafogdosas5reszanim:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizafogdosas5reszszemanim:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizafogdosas5reszszemanim:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizafogdosas5reszszaj4:
                alpha 1.0
                linear 1.0 alpha 0.0
            jump beszedugrik5resz4

        label beszedugrik5resz3:
            hide fiupoz1
            show fiupoz1szem2:
                xzoom -1.0
            f "I am just kidding…"
            l "I really don't mind it… maybe next time…"
            show fiupoz1:
                xzoom -1.0
            hide fiupoz1szem2
        label beszedugrik5resz4:
            l "Did you talk to Zoli?"
            hide ferdallofaszszem1
            show fiupoz1:
                xzoom -1.0
            f "Yeah, he gave some information about the guy. He is a strange big man, he limps and he is humming a strange melody..."
            l "This is quite interesting."
            f "What?"
            l "I have a similar costumer, He is usually humming while we are fucking. He is a huge black guy."
            l "I don't really know if he is lame or not. He is sitting… I hope you know what I mean…"
            f "Now I have a black guy.He is humming, and I have another man.Fodo is huge, he is lame and maybe he lies to me.I need to find out more about these guys… "
            hide lizapoz1540ngy
            hide lizazacsija540
            l "Good for you! I need to go now! I am late!"
            show shopelotbeszedhater:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                alpha 1.0
                linear 1.0 alpha 0.0
            show anikamom:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            hide shopelotbeszedhater
            hide anikamom
            hide fiupoz1
            show screen invertori
            show invertori onlayer elotte6:
                yalign 0.0
            show screen bolt



        $ renpy. pause(hard=True)
    if lizanalbeszeltel == 4:
        $ lizanalbeszeltel = 1
    if lizanalbeszeltel == 3:
        $ lizanalbeszeltel = 4
        f "Oh, yeah! I am searching for your ring!"
        jump lizabeszedboltnalki
    if lizanalbeszeltel == 2:
        $ lizanalbeszeltel = 3
        l "Any news?"
        f "I knew I forgot something! I'm going to search for it!"
        jump lizabeszedboltnalki
    if lizanalbeszeltel == 1:
        $ lizanalbeszeltel = 2
        l "Did you find the ring?"
        f "Not yet! I am searching."
        jump lizabeszedboltnalki
label lizabeszedboltnalki:
    show shopelotbeszedhater:
        alpha 1.0
        linear 1.0 alpha 0.0
    show anikamomngy:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    hide shopelotbeszedhater
    hide anikamomngy
    hide fiupoz1
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen bolt
$ renpy. pause(hard=True)
label kittiesritabeszedboltnal6resz:
    hide screen bolt
    hide shopelotbeszedhater
    hide kittyelolbeszed1
    hide ritabeszed
    hide fiupoz1
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    show kittyelolbeszed1:
        xpos -0.05
        alpha 0.0
        linear 1.0 alpha 1.0
    show ritabeszed:
        xpos 0.15
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    f "Hy girls! Did the strong wind blow you here?"
    k "You need a really strong wind to let me move... You talk about strange things…"
    r "We came early to see the new collection."
    f "Why did you not go inside the dress shop?"
    k "The collection will arrive only tomorrow around 7 AM. We will stand before the door after they close the shop. This way we will be the first costuners."
    r "We will be the first customers and we can look around first…"
    f "This sounds fucking amazing, really! I can understand your excitement now fully."
    r "Oh Fred! You are so nice!"
    show shopelotbeszedhater:
        alpha 1.0
        linear 1.0 alpha 0.0
    show kittyelolbeszed1:
        xpos -0.05
        alpha 1.0
        linear 1.0 alpha 0.0
    show ritabeszed:
        xpos 0.15
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen bolt
$ renpy. pause(hard=True)
label anikaesfodobeszedboltnal6resz:
    hide screen bolt
    hide shopelotbeszedhater
    hide anikaelolbeszed1
    hide csovesfodobeszed
    hide fiupoz1
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    if anikafodomellet6resz == False:
        show anikaelolbeszed1:
            xpos -0.05
            alpha 0.0
            linear 1.0 alpha 1.0
    show csovesfodobeszed:
        xpos 0.15
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    if anikafodomellet6resz == False:
        f "Byebye!"
        a "Hy! What is your name again?"
        f "Fred..."
        fr "Does this bastard persecute you Anika?"
        a "He wishes to only… Take it easy Fodo. He is fine. We visit the same classes I guess. He is below my level and so we do not talk a lot…"
        f "You just said you do not know any lame guys…"
        a "I do not know any lame homeless nobody. I know only the total cool faces."
        a "Let us take an example. If someone asks about YOU, I will totally deny the fact I know you…"
        f "This is sooo… nice from you…"
        a "Do not take this seriously! I have nothing against you, but you are gammy."
        f "Is Fodo a good „ face” ?"
        a "Are you kidding me? He is the top guy on the road!"
        fr "Yeah! I am strong, handsome and well situated…"
        f "...I should go now..."
        a "I should go, too. Peter will pick me up and we will go to the beach… I have my bikini on…"
        fr "I stay here and watch the shop. Ester gave me some drinks… I have to protect the shop..."
        f "Ok, bye bye!"
        show screen anikaelmegyfodomellol6resz
    if anikafodomellet6resz == True:
        hide anikalabbal540
        fr "Go away! I am on a mission."
    show shopelotbeszedhater:
        alpha 1.0
        linear 1.0 alpha 0.0
    if anikafodomellet6resz == False:
        show anikaelolbeszed1:
            xpos -0.05
            alpha 1.0
            linear 1.0 alpha 0.0
    show csovesfodobeszed:
        xpos 0.15
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen bolt
$ renpy. pause(hard=True)
label fodobeszedboltnal8resz:
    hide screen bolt
    hide shopelotbeszedhater
    hide anikaelolbeszed1
    hide csovesfodobeszed
    hide fiupoz1
    hide fiupoz1kep1
    hide fiupoz1kep2
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    show csovesfodobeszed:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    if receptnalad == 0:
        f "Hy Fodo!"
        fr "You are very kind again. What do you want?"
        f "Well, yeah! Do you know any kind of tricks to heal the sunburn fast?"
        fr "Sunburn you say?"
        f "Yeah."
        fr "I know a good, working recipe. I worked as a lifeguard on the beach. The chicks got sunburned all the time and they cried nonstop."
        fr "I rubbed the cream on their bodies and…"
        f "Do you remember the recipe?"
        fr "Of course! I keep all the important things. I put them in my safe pocket."
        f "In your pocket? How the fuck?"
        fr "I write it on a piece of paper Idiot…"
        f "That is cool! Can you lend me the recipe?"
        fr "I could… but why should I? Do you have something for exchange?"
        f "I have no money, but I can copy!"
        fr "Can you imagine how many asses i could fuck becasue I had this fantastic recipe?"
        f "No… what do you want for this?"
        fr "I have some work to do but I am just not in the mood to work now…I would make my clothes dirty and you know, I do not like any dirt…"
        f "Tell me more about the work!"
        fr "I should clean the lake in the park. Clean the lake and I will give you the recipe boy!"
        f "Alright. I will do it, because Mr. Puli is suffering in big pain."
        fr "Here is the recipe, but do not forget to clean the lake! Remember! I will find you everywhere boy!"
        $ receptnalad = 1
        $ targyazinvertoriban += 1
        f "Thank you! I will do the cleaning! Do not worry!"
        f "I can not read this! "
        fr "That’s your problem…Hehhheheheh!!!"
        f "Please help me a bit! What is the first thing?"
        fr "Sorry boy, but I promised to stop reading 15 years ago! I only read percent of alcohol on the bottle… I will never change this habbit…"
        f "I will solve the problem… Thank you!"
    if pillangokaparktoban == False:
        fr "Can you give me a small change, boy?"
        f "I have no money, sorry!"
        fr "Do you have a bottle of beer?"
        f "I do not drink alcohol, I am an idiot without getting drunk anyway..."
        fr "True! You waste my time boy! Get out of my way now!"
        f "Ok…"
    label elorebb8resz:
    if fodobealt == True:
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        show fiupoz1kep1:
            xpos -0.1
            alpha 0.5
            linear 3.0 xpos -0.05
            linear 3.0 xpos -0.1
            repeat
        show fiupoz1:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1kep2:
            xpos -0.1
            alpha 0.5
            linear 3.0 xpos -0.15
            linear 3.0 xpos -0.1
            repeat
        if hanyadiknapvan >= 11:
            f "Are you alright Fodo?"
            fr "Of course Kid! Everything is fine, because I am drunk…"
            f "I didn't even notice..."
            fr "I thought I drank enough to make it noticeable. I should go back and get drunk, trustworthy... Do you have money?"
            f "I am sorry, I have no money for you, but you look ass drunk already."
            fr "Every fine morning should start in the detoxification center. If you do not have money, just leave now!"

        u ""
    if pillangokaparktoban == True:
        if fodobealt == False:
            $ fodobealt = True
            if penz == 0:
                if elesztonalad == 1:
                    f "I finished the cleaning in the park."
                    fr "Why do you tell me about this?"
                    f "Don’t you remember? I had to clean the lake in exchange for a recipe…"
                    fr "Well… Hiccupp! Hiccupp! I do not remember this boy… a man came and gave me some money and I bought a few bottles… maybe… I got a bit drunk… Hiccupp!"
                    f "Fucking amazing! Can you lend me 250 Forints, I have to buy dry yeaster…"
                    fr "My throat is dry like the desert… It must be watered… I have no money left… I spent all…"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    queue sound "audio/reszeg.ogg"
                    show fiupoz1kep1:
                        xpos -0.1
                        alpha 0.5
                        linear 3.0 xpos -0.05
                        linear 3.0 xpos -0.1
                        repeat
                    show fiupoz1:
                        xpos -0.1
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    show fiupoz1kep2:
                        xpos -0.1
                        alpha 0.5
                        linear 3.0 xpos -0.15
                        linear 3.0 xpos -0.1
                        repeat
                    f "Still, thank you for everything! You are really cool!"
                    fr "You are welcome, but who the fuck are You??? Hiccuppppp!"
                    f "Never mind, I think you drank to much…"
                else:
                    jump elorebb8resz
            else:
                jump elorebb8resz
    show shopelotbeszedhater:
        alpha 1.0
        linear 1.0 alpha 0.0
    show csovesfodobeszed:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    if fodobealt == True:
        show fiupoz1kep1:
            xpos -0.05
            alpha 0.5
            linear 1.0 alpha 0.0
        show fiupoz1kep2:
            xpos -0.15
            alpha 0.5
            linear 1.0 alpha 0.0
    pause 1.0
    stop sound
    show screen bolt
$ renpy. pause(hard=True)
label boltnalbelehalgatgyulaesrozsibeszed:
    hide screen bolt
    hide shopelotbeszedhater
    hide gyulapoz1
    hide rozsapoz1
    hide rozsapoz1szem2
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    show gyulapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show rozsapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show rozsapoz1szem2:
        alpha 0.0
        linear 1.0 alpha 1.0
    r "Hy Honey!"
    gy "Did you miss me?"
    hide rozsapoz1szem2
    r "Who knows?"
    gy "We should find a quiet place to be all alone and…"
    show rozsapoz1szem2
    r "When will your wife have a trip again?"
    gy "In the near future I hope. I can not hold it much longer…"
    r "Maybe next time then…"

    show shopelotbeszedhater:
        alpha 1.0
        linear 1.0 alpha 0.0
    show gyulapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show rozsapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show rozsapoz1szem2:
        alpha 1.0
        linear 1.0 alpha 0.0

    show screen bolt
$ renpy. pause(hard=True)
label boltnalgyulabeszed:
    hide screen bolt
    hide shopelotbeszedhater
    hide gyulapoz1
    hide fiupoz1
    hide fiupoz2
    hide fiupoz4
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    show gyulapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    if parkadriana < 2:
        f "Excuse me Sir!"
        gy "Call me Gyula!"
        f "Do you have a wife? Is her name Adriana?"
        gy "No, but why do you ask me? What is your name?"
        show fiupoz1:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        f "My name is Fred. I met a woman in the park. She is searching for her husband. He is hanging around here…"
        gy "I am not the right person, look around man!"
        show fiupoz2:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz4:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I am sorry…"
        show shopelotbeszedhater:
            alpha 1.0
            linear 1.0 alpha 0.0
        show gyulapoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz4:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
    if parkadriana == 2:
        $ gyulaelmegy = True
        gy "What do you want?"
        f "I just hang around... I just wanted to chat…"
        gy "Call your mother for a chat!"
        show fiupoz1:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        f "He died a long time ago..."
        gy "Call your father then!"
        f "He is death."
        show fiupoz2:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        gy "Well… I have no time… Scram you asshole!"
        f "Ok…"
        hide gyula540

        show shopelotbeszedhater:
            alpha 1.0
            linear 1.0 alpha 0.0
        show gyulapoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen bolt
$ renpy. pause(hard=True)
label beszedbrammalboltban:
    hide screen toolshop
    hide fiupoz1
    hide barkacsboltkozeli
    hide brampoz1forditott
    show barkacsboltkozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show brampoz1forditott:
        xzoom -1
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    if hanyadiknapvan == 7:
        if adrianahazaakarmenniszojbramnak == True:
            $ parkadriana = 2
            f "I am sorry, but may I ask you something? Do you have a wife called Adriana?"
            i "Yes I have, but why do you ask? Are you a Public opinion researcher? Or what?"
            f "No… I am glad to find you. Your wife is searching for you. She could not reach you on the phone."
            f "She is tired and she would like to go home now."
            hide brambarkacsboltban
            hide boltokhatereauto
            br "Thank you pal! My name is Bram. I should go now… "
        if adrianahazaakarmenniszojbramnak == False:
            f "Would you like to pay?"
            i "No, I am just looking around to make the time pass..."
    if hanyadiknapvan == 11:
        if mubajuszkell == 0:
            f "Hy Bram! How does Adriana feel today?"
            br "She is fine. The baby was not born yet. A few weeks and the baby will be born."
            f "Congratulations!"
            br "I should go now. I am looking for some tools. The kids’s room is not ready yet."
            f "Ok!"
        if mubajuszkell == 1:
            $ beszeltelbrammalabajusrol = True
            f "Sorry for disturbing you, but can you please help me? I am searching for some kind of an artificial mustache."
            br "Well... I really do not know, but I remember this place was a costume rental in the past. It became a toolshop…"
            br "Ask Piri about the artificial mustache. Maybe she can find you some in the old boxes."
            f "Thank you for your useful tip! I will!"
        if mubajuszkell >= 2:
            br "I am sorry! I am quite busy now…"

    show barkacsboltkozeli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show brampoz1forditott:
        xzoom -1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen toolshop
$ renpy. pause(hard=True)
label vaszon2fel:
    show vaszon2azinvertoriban:
        zoom 0.6
        xpos 0.96
        ypos 0.78
        alpha 1.0
        linear 1.0 alpha 0.0
    $ vaszon2 = 1
$ renpy. pause(hard=True)
label metszoollotoolshopban:
    hide screen toolshop
    f "Tell me Piri, Can I have the secateurs and pay you later?"
    p "I am sorry, but we do not give loans to any customer."
    f "Understood. I will come back later."
    show screen toolshop
$ renpy. pause(hard=True)
label ruhaszaritomadzag7nap:
    hide screen toolshop
    f "I am sorry, but can I get the clothesline for 200 Forint? I have only so much money left..."
    p "Yes. This is a special time and this product has low interest."
    f "Thank you very much!"
    $ penz = 0
    $ madzagveheto = 2
    show screen toolshop
$ renpy. pause(hard=True)
label nincsrapenzem:
    hide screen vegyesboltaru
    f "I have no money."
    show screen vegyesboltaru
$ renpy. pause(hard=True)
label svetlanabeszedboltnalpuffyval:
    hide screen bolt
    hide fiupoz1
    $ ritaholvan = "lizautcajaban"
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    show svetlanapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show puffypoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    da "… Are you ok with this?"
    $ beszeljpuffyval9resz = 2
    s "Yeah! I will buy it."
    s "Now I have to go. I am happy for your business..."
    da "Me, too..."
    $ svetlana = "temetoben"
    show svetlanapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show fiupoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "What is up Puffy? What kind of business do you have with Svetlana?"
    da "Nothing special. I sold a few things..."
    show fiupoz1:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz5:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Did you check the prices?"
    da "Of course I did! Noone can trick me man! Is there any idiot who does not look after the prices before selling old stuffs?"
    show fiupoz5:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Yeah, there is an idiot standing next to you…"
    da "Give me your tools and I will sell them. Believe me! I am great in such businesses!"
    show fiupoz4:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    da "Svetlana asked me about the price of an old coin. You won't believe me! An asshole gave her a really expensive special coin a few days ago. She gave her a pawnshop ticket in exchange."
    show fiupoz2:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1sokkolt:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Puffy… I am the asshole..."
    da "Sorry man! I never thought you could be such an idiot! You lose a fortune!"
    show fiupoz1sokkolt:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    f "Well... let us change the subject. How much did you get?"
    da "Not so much. i sold her old clothes and a dirty ashtray…"
    f "Ahha. Did you figure out the present for Grandma?"
    da "Not yet. I am still thinking."
    f "I have something for you. She would be happy to get that thing back."
    da "Cool! What is it?"
    show fiupoz1:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "It is her necklace. I still have the pawnshop ticket. I can give it to you if you like."
    da "Will you Bro?"
    f "Of course! We are friends!"
    da "How should I thank you for this?"
    f "Let Us be friends forever Puffy!"
    show fiupoz2:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    $ mamanyaklanczalogjegy = 3
    da "I... I will cry bro… SHIT! This necklace is expensive! I have no money for this."
    f "Do not worry! Take your time! Will you visit us today?"
    da "No Bro. I have to work and sample money for the necklace."
    f "I understand! Good luck!"
    da "Welcome Diana on my behalff."
    f "Of yourse! See you tomorrow!"
    hide dagi540allas1
    hide taska5resz
    hide svetlana540
    show fiupoz1:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    $ puffyholvan = "sehol"
    show shopelotbeszedhater:
        alpha 1.0
        linear 1.0 alpha 0.0
    show puffypoz1:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen bolt
$ renpy. pause(hard=True)
label pulimegesziamitamacskameghagyott:
    hide screen bolt
    if kutyatalban == "semmi":
        f "He is looking hungry..."
        show screen bolt
        $ renpy. pause(hard=True)
    $ kutyatalnalad = 2

    show boltokhaterepuli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show boltokhaterepulieszik:
        alpha 0.0
        linear 1.0 alpha 1.0

    if kutyatalban == "kutyakaja":
        show boltokhaterepulikutyakaja:
            alpha 0.0
            linear 1.0 alpha 1.0
    if kutyatalban == "tej":
        show boltokhaterepulitej:
            alpha 0.0
            linear 1.0 alpha 1.0
    show screen s3
    u ""
    if kutyatalban == "kutyakaja":

        show boltokhaterepulikutyakaja:
            alpha 1.0
            linear 1.0 alpha 0.0

    if kutyatalban == "tej":
        $ pulikutyaholvan = "sehol"
        show boltokhaterepulitej:
            alpha 1.0
            linear 1.0 alpha 0.0


    show boltokhaterepuli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show boltokhaterepulieszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    if kutyatalban == "kutyakaja":
        f "Good boy!"
    if kutyatalban == "tej":
        f "Good boy!"
    $ kutyatalnalad = 1
    $ kutyatalban = "semmi"
    show screen bolt
$ renpy. pause(hard=True)
label sanyiboltnal:
    hide screen bolt
    hide nagyonkozelibolt
    hide sanyipoz1
    hide fiupoz1
    show nagyonkozelibolt:
        alpha 0.0
        linear 1.0 alpha 1.0
    show sanyipoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    if hanyadiknapvan == 9:
        if keresedjet == True:
            f "Excuse me! Is your name J?"
            sa "No. Noone calls me like this. Never heard of anyone called „J”…"
            f "Thank you for the information!"
        if keresedjet == False:
            f "Hy, my name is Fred."
            sa "My name is Alexander."
            f "Are you a student? I do not remind you."
            sa "No, I am not. I am working as a Factotum."
            f "Ok, bye!"
    if hanyadiknapvan == 11:
        f "Hy Alexander!"
        sa "Hy!"
        f "I am Fred. Could you please repair our drying machine?"
        sa "Sorry, I am waiting for someone..."
        f "Cili asked you to help me."
        sa "Ok, let us go!"
        f "Alright, but I have only 3000 Forints to pay you. "
        sa "No problem! The money is enough!"
        f "Cool! The address is……. Go there and I will go after you!"
        hide sanyialap540
        $ sanyiholvan = "furdoben"
    show nagyonkozelibolt:
        alpha 1.0
        linear 1.0 alpha 0.0
    show sanyipoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen bolt
$ renpy. pause(hard=True)
label bandiboltnal:
    hide screen bolt
    hide shopelotbeszedhater
    hide bandipoz1
    hide fiupoz1
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    show bandipoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    if keresedjet == True:
        f "Excuse me! Is your name J?"
        play sound "audio/morog2.wav"
        f "I am sorry to disturb you."
    if keresedjet == False:
        f "Hy, I am Fred!"
        play sound "audio/morog2.wav"
        f "Goodbye!"
    show shopelotbeszedhater:
        alpha 1.0
        linear 1.0 alpha 0.0
    show bandipoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen bolt
$ renpy. pause(hard=True)
label rozsaboltnal:
    hide screen bolt
    hide shopelotbeszedhater onlayer elotte
    hide rozsapoz1 onlayer elotte
    hide rozsapoz1szem2 onlayer elotte
    hide fiupoz1 onlayer elotte
    hide fiupoz2 onlayer elotte
    show shopelotbeszedhater onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show rozsapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show rozsapoz1szem2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    ro "Hy Loverboy!"
    f "Hy! What is your name?"
    ro "Call me Rose!"
    f "Ok. What are you doing here Rose?"
    ro "I am working here."
    show ferdpoz1szemlefelenez onlayer elotte
    f "What are you working on now? I can see nothing in your hands."
    hide rozsapoz1szem2 onlayer elotte
    ro "I am selling something..."
    hide ferdpoz1szemlefelenez onlayer elotte
    f "What are you selling?"
    show rozsapoz1szem2 onlayer elotte
    ro "I am selling myself Honey... Are you interested?"
    show fiupoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "Huh? I have no money for that now and I think you never could make love in the way I like?"
    hide rozsapoz1szem2 onlayer elotte
    ro "How would you like to make „love” Dear?"
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "Free. Without money..."
    show rozsapoz1szem2 onlayer elotte
    ro "You are a nice and funny guy but... Scram now! Do not disturb my customers! Hahha! He is telling „Free”…."
    show shopelotbeszedhater onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show rozsapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show rozsapoz1szem2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen bolt
$ renpy. pause(hard=True)
label eszterboltnal:
    hide screen bolt
    show shopelotbeszedhater onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show eszterpoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    f "Hy Estre. Why are you standing outside?"
    e "I have to sweep up around the shop sometimes. Our customers do not like dirt."
    f "Who is serving in the shop now?"
    e "Noone is inside. I will serve if needed."
    f "Interesting. I have to go now. Bye Bye!"
    e "Take care!"

    show shopelotbeszedhater onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show eszterpoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen bolt
$ renpy. pause(hard=True)
label eszterboltnalancikaval:
    hide screen bolt
    show boltelotbeszeleszteresancika onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    anc "Could you please prepare my order?"
    e "I just did. Your name stands on the box. It is the dark brown box in the middle."
    anc "Thank you so much! You saved a lot of time for me!"
    e "Never mind. How are your children?"
    anc "My big son is in school and my little princess is in kindergarten."
    e "What about Gyula?"
    anc "Everything is ok. He is working hard and he loves the children."
    anc "What about you?"
    e "Business first, you know. I wish to reach a level before I get married…"
    anc "I thought the same way and suddenly I got pregnant and…"
    f "This conversation will take so long. I do not feel like listening to it anymore."
    show boltelotbeszeleszteresancika onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""

    show screen bolt
$ renpy. pause(hard=True)
label boltbanemmehetek:
    hide screen bolt
    f "Closed."
    show screen bolt
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
