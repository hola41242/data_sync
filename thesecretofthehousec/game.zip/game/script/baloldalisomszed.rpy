label baloldaliszomszed:
    if hanyadiknapvan == 3:
        if baloldaliszomszed == 1:
            if baloldaliszomszed == 1:
                if jobboldaliszomszed == 1:
                    $ beszeljaszomszedokkal = 2
            f "She did not see anything. I will come back here to work a bit."
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 4:
        if regell4resz == True:
            f "I have no time to visit the neighbors."
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 5:
        if regell5resz == True:
            f "I have no time to visit the neighbors."
            $ renpy. pause(hard=True)

    $ holvagyok = "baloldaliszomszed"
    jump tiltasok
$ renpy. pause(hard=True)
label baloldaliszomszedszov:


    if hanyadiknapvan == 3:
        if baloldaliszomszed == 0:
            show lize3reszk58
            $ baloldaliszomszed = 1
            if baloldaliszomszed == 1:
                if jobboldaliszomszed == 1:
                    $ beszeljaszomszedokkal = 2
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            l "Are you Fred? You grew up! I did not see you for ages!"
            f "Hello, Liza! Yeah! Can I disturb you for a few moments?"
            l "Of course! Come in!"
            show utcaihazak:
                alpha 0.0
                linear 1.0 alpha 1.0
            show anikamom:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Thank you, but i do not have so much time. Can I ask you some questions? Did you see someone around our home before the suicide?"
            hide lize3reszk58
            l "I did not see anything. I noticed only when firemen came.I work all the night long so i sleep all day long..."
            f "I know. I heard a rumor about an unknown person… I try to figure out who it could be."
            f "Someone saw him walk away..."
            l "Yeah I heard that rumor, too. But i heard you have financial problems. Is this true?"
            f "Well, I am not rich for sure, but I am fine!"
            l "I have some work for you if you like! My garden is a mess, and someone should cut the grass... I ask for help and I pay well. Are you interested?"
            f "Yeah! Of course! I will come in a few days after school!"
            f "It is getting late, I should go now. Thank You for your help!"
            l "Take care of yourself Honey! "
            jump terkep
    if hanyadiknapvan == 4:
        $ invertorinejelenyenmeg = True
        show lizahaza
        show lizagyomlalkicsianim:
            xpos 0.38
            ypos 0.637
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        show screen baloldalisomszed
        $ renpy. pause(hard=True)
    if hanyadiknapvan >= 5:
        show screen invertori2
        show screen invertoriszov
        show invertori onlayer elotte6:
            yalign 0.0
        show utcaihazak
    if hanyadiknapvan == 5:
        if lizagyurulye >=1:
            if kolduskulacsa < 3:
                show csovesfodo540:
                    zoom 0.62
                    xpos 0.408
                    ypos 0.59
                show csovesfodogyuru540:
                    zoom 0.62
                    xpos 0.408
                    ypos 0.59
                show csovesfodo540cilanim:
                    zoom 0.62
                    xpos 0.408
                    ypos 0.59
        show ircsajmeretutcan
    if hanyadiknapvan == 6:
        show ircsajmeretutcan
        if lizakertjemadarhaza <= 1:
            show madarhazazinvertoriban:
                xpos 0.0
                ypos 0.75
        show kukanagyzold
    if hanyadiknapvan == 7:
        show ircsajmeretutcan
    if hanyadiknapvan == 8:
        show ircsajmeretutcan
    if hanyadiknapvan == 9:
        if salgcsonalad == 0:
            show slagcsoazinvertoriban:
                zoom 1.5
                xpos 0.0
                ypos 0.75
        show kukanagyzold
        if beszeltelannaval9resz == False:
            show annahaterenbetekeredett
        if beszeltelannaval9resz == True:
            if leengedocsofelveheted == False:
                show ircsajmeretutcan
            if leengedonalad == 0:
                show leengedocsoazinvertoriban:
                    xpos 0.8
                    ypos 0.75
        if ritaholvan == "lizautcajaban":
            show utcaihazakritahattal
    if hanyadiknapvan == 11:
        if holvanliza == "hazelotgyomlal":
            show lizagyomlalkicsianim:
                zoom 0.8
                xpos 0.375
                ypos 0.66
    if izomcavoholvan == "lizahazaelot":
        show alfonzall540:
            zoom 0.6
            xpos 0.5
            ypos 0.59
    if amandaholvan == "lizaekelott":
        show amandakosztumben540:
            zoom 0.8
            xpos 0.2
            ypos 0.55







    jump engedejek

$ renpy. pause(hard=True)
label lizavalbeszelsz:
    hide screen baloldalisomszed
    if hanyadiknapvan == 4:
        $ baloldaliszomszed = 1
        show lizakozelisegmozgashatter onlayer hatso:
            alpha 0.0
            linear 0.5 alpha 1.0
        show lizagyomlalanim onlayer hatso:
            alpha 0.0
            linear 0.5 alpha 1.0
        show screen s1
        u ""
        hide lizagyomlalkicsianim
        show fiupoz1
        show anikamom
        u ""
        show lizakozelisegmozgashatter onlayer hatso:
            alpha 1.0
            linear 0.5 alpha 0.0
        show lizagyomlalanim onlayer hatso:
            alpha 1.0
            linear 0.5 alpha 0.0
        pause 1.0
        hide lizakozelisegmozgashatter onlayer hatso
        hide lizagyomlalanim onlayer hatso
        pause 1.0
        l "Hy Fred!"
        f "Hello Liza!"
        l "Why are you here? Do you have time now to clean my garden?"
        f "I have no time right now, but I did not forget it! I would like to talk to Zoli. I did not find him yesterday."
        if jobboldaliszomszed == 0:
            f "I hope I can find him home now..."
            l "He is at home! I saw him arrive ten minutes ago."
        if jobboldaliszomszed == 1:
            f "I could talk with Zoli today. He gave me a starge description of a man..."
            f "Zoli saw this man searchin between the ruins..."
        l "Do you have any more questions? I should hurry to clean the foregarden. I need to go to work in an hour."
        l "Visit me in the Strip Club some days!"
        f "I have no time now. I would like to meet Bertalan. I had no option to talk with him since... that happened..."
        f "I will check in tomorrow for sure!"
        l "Super! See Ya tomorrow!"
        show lizagyomlalkicsianim:
            xpos 0.38
            ypos 0.637
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show anikamom:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        hide fiupoz1
        hide anikamom
    if hanyadiknapvan == 5:
        if lizanincsothon == True:
            $ lizanaljatal = 1
            f "Liza is not at home.I do not know where she is."
    if hanyadiknapvan == 11:
        hide invertori onlayer elotte6
        hide screen invertori
        hide screen invertori2
        show lizakozelisegmozgashatter onlayer hatso:
            alpha 0.0
            linear 0.5 alpha 1.0
        show lizagyomlalanim onlayer hatso:
            alpha 0.0
            linear 0.5 alpha 1.0
        show screen s1
        u ""
        hide lizagyomlalkicsianim
        show lizahazakozelibeszedhez
        show fiupoz1
        show anikamom
        u ""
        show lizakozelisegmozgashatter onlayer hatso:
            alpha 1.0
            linear 0.5 alpha 0.0
        show lizagyomlalanim onlayer hatso:
            alpha 1.0
            linear 0.5 alpha 0.0
        pause 1.0
        hide lizakozelisegmozgashatter onlayer hatso
        hide lizagyomlalanim onlayer hatso
        pause 1.0
        if egyetemenvoltal11resz == 0:
            l "Are you visiting me?"
            f "No, I have something to do around here and I saw you and I wanted to say „Hello”..."
            l "I knew it! You missed me. Would you like to come in?"
            f "I have a lot to do now, but I will come back after my lessons."
            l "You are such a hardworking student. Stay a diligent guy! I love it!"
            f "I have to go now. Byebye!"
        if egyetemenvoltal11resz == 1:
            f "Are you still here? Why are you not practicing in the garden?"
            l "Why should I practice all day long? I am waiting for Cili, we planned to go out together..."
            f "Cool! Where are you going?"
            l "I do not know. I will start dressing as soon as she arrives…"
            f "I tough, women dress up early before they go out..."
            l "Yeap, but I do not know where we will go this time so I can not prepare well forward."
            f "How about waiting for Cili naked?"
            l "She is not a lesbian… We are just friends."
            f "Still it would be interesting..."
            l "Maybe in the future you wil… Hahha!"
            f "That is a promise! Do not forget! I have to go now! Bye!"
            l "Bye bye!"

        show lizagyomlalkicsianim:
            xpos 0.38
            ypos 0.637
            alpha 0.0
            linear 1.0 alpha 1.0
        show lizahazakozelibeszedhez:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show anikamom:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        hide fiupoz1
        hide anikamom
        hide lizahazakozelibeszedhez
        show invertori onlayer elotte6:
            ypos 0.0
        show screen invertori





    show screen baloldalisomszed
$ renpy. pause(hard=True)
label koldusalbeszed:
    hide screen baloldalisomszed
    hide screen invertori
    hide invertori onlayer elotte6
    show lizahazakozelibeszedhez:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show csovesfodobeszed:
        xpos -0.05
        alpha 0.0
        linear 1.0 alpha 1.0
    show csovesfodobeszedgyuru:
        xpos -0.05
        alpha 0.0
        linear 1.0 alpha 1.0
    show csovesfodobeszedgyurucsilanim:
        xpos -0.05
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    hide lizahazakozelibeszedhez
    hide fiupoz1
    hide csovesfodobeszed
    hide csovesfodobeszedgyuru
    hide csovesfodobeszedgyurucsilanim
    show lizahazakozelibeszedhez
    show fiupoz1
    show csovesfodobeszed:
        xpos -0.05
    show csovesfodobeszedgyuru:
        xpos -0.05
    show csovesfodobeszedgyurucsilanim:
        xpos -0.05
    if koldussalbeszeltel == 0:
        $ koldussalbeszeltel = 1
        $ santakolduszolieknal = 2
        $ lizagyurulye = 2
        f "Excuse me Sir!"
        fr "What about the greeting: „Hello stinky homeless!” ??? What do you want, boy? Call me Fodo!"
        f "Hello Fodo! How did you find out that I need something?"
        fr "The way of your greeting helped me a bit. Usually people talk this way if they want something."
        f "True! I have a question. Were you searching in my house all night?"
        fr "Where do you live boy?"
        f "I had lived here before my home burned down. These ruins are my home."
        fr "Pure boy! You are even poorer than me! But no! I do not like to search in such a mess. I do not want to make my dress all dirty."
        fr "You know… I hate to wash my dress..."
        f "So I did not find that person."
        show fiupoz1szem2
        hide fiupoz1
        f "But who knows…"
        fr "You can find me in the underpass. I am begging there every day!"
        f "You have a great ring. Where did you get it from?"
        fr "I found it!"
        show fiupoz1
        hide fiupoz1szem2
        f "Do you want to give it back to its owner?"
        fr "What is your name, boy?"
        show fiupoz2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        f "My name is Fred, and I know someone who is searching for her ring right now."
        fr "Really? Who is it? I know her as well!"
        f "The owner is Liza. She is searching for the ring around the shop now."
        f "She sent me to look around here. Will you give it back?"
        fr "You have no luck! I lost my brandy bottle.How shall I quench my thirst?"
        show fiupoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz2:
            alpha 1.0
            linear 1.0 alpha 0.0
        fr "Let us make a deal Fodo!"
        f "What kind of deal?"
        fr "Someone stole my brandy bottle! I want it back!"
        fr "Give me my brandy bottle and I will give you the ring."
        f "Where could you lose it?"
        fr "What are you thinking? If I would know this I would have my bottle!"
        if lizagyurulyesvetlanatol == 1:
            f "I have an idea. I will look around!"
            jump beszedugrik5resz2
        if lizagyurulyesvetlanatol == 0:
            f "I will go now and I will look around a bit. Stay here so I can find you easily!"
            jump beszedugrik5resz2
    if kolduskulacsa == 2:
        $ kolduskulacsa = 3
        $ lizagyurulye = 3
        fr "Alright Boy! This is my old brandy bottle!"
        f "Can I have the ring Fodo?"
        fr "What kind of ring?"
        f "The ring which is hanging in your neck…"
        fr "Oh, I totally forgot this."
        hide csovesfodogyuru540
        hide csovesfodo540cilanim
        hide csovesfodo540
        show csovesfodobeszedgyuru:
            alpha 1.0
            linear 1.0 alpha 0.0
        show csovesfodobeszedgyurucsilanim:
            alpha 1.0
            linear 1.0 alpha 0.0
        fr "Take it! And rub Lisa’s big boobs! Make it in my name!"
        f "Ok! Goodbye old Fodo!"
        fr "Your grandmother is old! I am young! Scram crippled!"
        show lizahazakozelibeszedhez:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show csovesfodobeszed:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        hide lizahazakozelibeszedhez
        hide fiupoz1
        hide fiupoz2
        hide csovesfodobeszed
        hide csovesfodobeszedgyuru
        hide csovesfodobeszedgyurucsilanim
        show screen invertori
        show invertori onlayer elotte6:
            yalign 0.0
        show screen baloldalisomszed
        $ renpy. pause(hard=True)
    if koldussalbeszeltel == 1:
        if koldussalbeszeltel == 4:
            $ koldussalbeszeltel = 1
        if koldussalbeszeltel == 3:
            $ koldussalbeszeltel = 4
            f "I can make you a new one."
            fr "No! I want my own brandy bottle back! I do not need any other shit!"
        if koldussalbeszeltel == 2:
            $ koldussalbeszeltel = 3
            f "Why is this bottle so special?"
            fr "Are you kidding me? This brandy bottle was the treasure of my grandfather and my father and now it is my treasure!"
            fr "This is why I need it back!"
        if koldussalbeszeltel == 1:
            $ koldussalbeszeltel = 2
            f "Can I have the ring?"
            fr "Give me the brandy bottle and I will give the ring to you!"
label beszedugrik5resz2:
    show lizahazakozelibeszedhez:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show csovesfodobeszed:
        alpha 1.0
        linear 1.0 alpha 0.0
    show csovesfodobeszedgyuru:
        alpha 1.0
        linear 1.0 alpha 0.0
    show csovesfodobeszedgyurucsilanim:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 2.0
    hide lizahazakozelibeszedhez
    hide fiupoz1
    hide fiupoz2
    hide csovesfodobeszed
    hide csovesfodobeszedgyuru
    hide csovesfodobeszedgyurucsilanim
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen baloldalisomszed
$ renpy. pause(hard=True)
label beszedannaval5resz:
    hide screen baloldalisomszed
    hide screen invertori
    hide invertori onlayer elotte6
    if hanyadiknapvan >= 7:
        hide ircsajhd
        show ircsajhd:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 2.0
        if annabesze == 3:
            $ annabesze = 0
        if annabesze == 2:
            $ annabesze = 3
            f "May I disturb you?"
            an "Do not disturb a young lady with dreams and hopes! You could ruin her improvement."
        if annabesze == 1:
            $ annabesze = 2
            f "Do you have a boyfriend?"
            an "No… Why do you ask me?"
            f "I have time and I was curiouse…"
            an "Spend your time with something else!"
        if annabesze == 0:
            $ annabesze = 1
            f "Do you stay here all night long?"
            an "Of course not. I rent a small room nearby."
        show ircsajhd:
            alpha 1.0
            linear 1.0 alpha 0.0
    if hanyadiknapvan == 6:
        hide annahaterkozeli
        show annahaterkozeli:
            alpha 0.0
            linear 1.0 alpha 1.0
        hide annakozelifej6resz
        hide annakozelifej6resz2
        show annakozelifej6resz:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 2.0
        if annabesze == 3:
            $ annabesze = 0
        if annabesze == 2:
            $ annabesze = 3
            f "You will burn in the sun. Are you not afraid? You will get more and more freckled this way..."
            show annakozelifej6resz:
                alpha 1.0
                linear 1.0 alpha 0.0
            show annakozelifej6resz2:
                alpha 0.0
                linear 1.0 alpha 1.0
            an "How you dare to talk about my…my freckles. Those are all kisses from an angel you know!..."
            an "Go away now! I can not bear your company!"
        if annabesze == 1:
            $ annabesze = 2
            f "Do you have something to drink or eat?"
            show annakozelifej6resz:
                alpha 1.0
                linear 1.0 alpha 0.0
            show annakozelifej6resz2:
                alpha 0.0
                linear 1.0 alpha 1.0
            an "I have but I won’t give you any!"
        if annabesze == 0:
            $ annabesze = 1
            f "Are you still waiting here?"
            an "This is not your business!"
            f "Of course.. Can I help you?"
            show annakozelifej6resz:
                alpha 1.0
                linear 1.0 alpha 0.0
            show annakozelifej6resz2:
                alpha 0.0
                linear 1.0 alpha 1.0
            an "I do not need your help. Fates wanted it this way."
        show annahaterkozeli:
            alpha 1.0
            linear 1.0 alpha 0.0
        show annakozelifej6resz2:
            alpha 1.0
            linear 1.0 alpha 0.0
    if hanyadiknapvan == 5:
        hide ircsajhd
        show ircsajhd:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 2.0
        if annabesze == 3:
            $ annabesze = 0
        if annabesze == 2:
            $ annabesze = 3
            f "Are you waiting for someone?"
            an "Yeah!"
            f "Why did you not call him?"
            an "How should I? I lost the phone number. It was written on a piece of paper and the wind took it away. The paper is free now, like a bird…"
            an "This is fate! This had to be done like this and i forgot to recharge my phone yesterday... This is my fate..."
            f "Can I help you?"
            an "You can not help me! The universe calls me. Fate is giving me problems to make my mind stronger."
        if annabesze == 1:
            $ annabesze = 2
            an "Where are you? How long should I wait for you JI?"
            f "Are you sure? I can help!"
            an "How could you help me? I don't even know you. Leave me alone in my romantic melancholy please!"
        if annabesze == 0:
            $ annabesze = 1
            an "Oh! My small body can not take this heat anymore…"
            f "Hy! Can I help you?"
            an "I do not need any help from a stranger. I am waiting for someone. Thank you!"
        show ircsajhd:
            alpha 1.0
            linear 1.0 alpha 0.0

    pause 2.0
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen baloldalisomszed
$ renpy. pause(hard=True)
label romkutatasa:
    if hanyadiknapvan == 6:
        hide screen invertori
        show screen invertori2
        hide screen baloldalisomszed
        f "I should try to find the red silk bag. I have better chances by the daylight."
        show screen kutatromok
    if hanyadiknapvan == 10:
        if kerjmunkatkerhec == True:
            if ladatmegtalalhatod == 0:
                hide invertori onlayer elotte6
                hide screen invertori
                hide screen baloldalisomszed
                $ fredkutatromokelteltido = 0
                $ fredkutatromokido = 30
                f "I should look around here. Maybe I will find something useful."
                show screen kutatromok2
                show screen s3
                u ""
                show lizahazakozelibeszedhez2 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show lizanagybeszelelomoz1 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s2
                u ""
                hide lizanagybeszelelomoz1 onlayer elotte
                show lizanagybeszelelolalap onlayer elotte
                show lizanagybeszeleloszajanim onlayer elotte
                show lizanagybeszeleloszemanim onlayer elotte
                show screen s2
                l "What are you doing here Dear?"
                hide lizanagybeszelelolalap onlayer elotte
                hide lizanagybeszeleloszajanim onlayer elotte
                hide lizanagybeszeleloszemanim onlayer elotte
                show lizanagybeszeleloanim onlayer elotte
                show screen s3
                f "I am searching for something. I should sell something to get some money."
                hide lizanagybeszeleloanim onlayer elotte
                show lizanagybeszelelolalap onlayer elotte
                show lizanagybeszeleloszajanim onlayer elotte
                show lizanagybeszeleloszemanim onlayer elotte
                show screen s3
                l "Ok… I am fixing my dress. I should do my daily jogging now… See you later! "
                hide lizanagybeszelelolalap onlayer elotte
                hide lizanagybeszeleloszajanim onlayer elotte
                hide lizanagybeszeleloszemanim onlayer elotte
                show lizahazakozelibeszedhez2 onlayer elotte:
                    pause 10.0
                    linear 1.0 alpha 0.0
                show lizanagybeszeleloanim onlayer elotte:
                    pause 10.0
                    linear 1.0 alpha 0.0
                show screen s11
                u ""
                $ holvanliza = "fut"
                show invertori onlayer elotte6:
                    ypos 0.0
                show screen invertori








                $ renpy. pause(hard=True)
    if hanyadiknapvan >= 7:
        f "I have no reason to look around here!"
$ renpy. pause(hard=True)
label romkutatasaabbahagy:
    if gerebjefej == 1:
        if gerebjenyel == 0:
            f "I did not find the bag, but I found a rake head. Maybe I can use it later.The haft burned in the fire."
        if gerebjenyel == 1:
            f "I did not find the bag, but I found a rake head. I have a full rake now. I can use it!"
    if gerebjenyel == 1:
        if gerebjefej == 1:
            $ gerebjekell = 2
    hide screen kutatromok
    hide screen invertori2
    show screen invertori
    show screen baloldalisomszed
$ renpy. pause(hard=True)
label szemeteskontener6resz:
    play sound "audio/elvesz2.wav"
    $ lizaszemeteszakja = 1
$ renpy. pause(hard=True)
label madarhazfel6resz:
    show madarhazazinvertoriban:
        xpos 0.0
        ypos 0.75
        alpha 1.0
        linear 1.0 alpha 0.0
    $ lizakertjemadarhaza = 2
$ renpy. pause(hard=True)
label beszedannaval9resz:
    hide screen baloldalisomszed
    hide screen invertori
    hide invertori onlayer elotte6
    if beszeltelannaval9resz == True:
        hide ircsajhd
        show ircsajhd:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        f "What is the name?"
        an "J."
        f "How could I forget it? I will go and I will look after him..."
    if beszeltelannaval9resz == False:
        $ beszeltelannaval9resz = True
        $ keresedjet = True
        $ debraholcsinal = "debragyomlalkert2ben"
        $ mamaholvan = "kert2ben"
        hide annabetekeredett
        show annabetekeredett:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "What happened to you?"
        an "Hmmmpfff…"
        f "Wait a minute! I will fry you."
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        show text "{b}{size=+10}10 minutes later." onlayer screens:
            xpos 0.5
            xalign 0.5
            yalign 0.475
        show screen s3
        u ""
        hide annabetekeredett
        hide annahaterenbetekeredett
        show ircsajmeretutcan
        show leengedocsoazinvertoriban:
            xpos 0.8
            ypos 0.75
        show ircsajhd
        hide text onlayer screens
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s2
        u ""
        f "Much better. Now explain to me please, what happened!?"
        an "I saw a tall snake charmer. She threw out two dead snakes in the trash."
        an "I wanted to take a closer look at those sneaks. You know it is really romantic to die with your beloved one. I thought it would be beautiful to see them next to each other dead..."
        an "I stepped closer and all for a sudden one of those snakes attacked me. The snake wrapped my legs around and I fell. We started to fight and I won. It was an incredible fight... At the end I made it, I killed the big snake..."
        f "It seems to me to be a thick stem tube, not a big snake..."
        an "It is a big snake! I killed it!"
        f "Ok… But i need this „snake” now. Can you lend it?"
        an "NO! I hunted down this prey."
        f "Do you want anything for exchange?"
        an "Well... I am bored now... I have been waiting for my nephew since days now... His name is J. Can you search for J?"
        f "Who the fuck is J?"
        an "His name is J. Do you not know him? He is called J."
        f "Never heard of him. Does he have a longer name? Do you know where he lives?"
        an "I call hime J. To be honest I forgot his original name, I have been calling him J for a long time now... Search for him and bring him to me and I will give you the snake."
        f "Oh fuck... Ok, I will look after „J” now…"
    show ircsajhd:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen baloldalisomszed
$ renpy. pause(hard=True)
label salgcsofell:
    $ salgcsonalad = 1
    show slagcsoazinvertoriban:
        zoom 1.5
        xpos 0.0
        ypos 0.75
        alpha 1.0
        linear 1.0 alpha 0.0
    if salgcsonalad == 1:
        if leengedonalad == 1:
            $ csovekkelenek9resz = 2
$ renpy. pause(hard=True)
label leengedocsofel:
    $ leengedonalad = 1
    $ adrianaholvan = "parkban"
    show leengedocsoazinvertoriban:
        xpos 0.8
        ypos 0.75
        alpha 1.0
        linear 1.0 alpha 0.0
    if salgcsonalad == 1:
        if leengedonalad == 1:
            $ csovekkelenek9resz = 2
$ renpy. pause(hard=True)
label ritavalbeszelniutcakepen:
    hide screen baloldalisomszed
    show lizahazakozelibeszedhez:
        alpha 0.0
        linear 1.0 alpha 1.0
    show ritabeszedfestekes:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    if macskaholvan == "parktonal":
        r "Did you find Pepper?"
        f "Not yet."
    if macskaholvan == "sehol":
        r "I am glad you are here. I have a big problem."
        $ ritamacskaja = 1
        f "Did someone pain on you?"
        r "Nope, it was me.This is ott he problem."
        r "I lose my cat, Pepper. He ran away."
        r "I am searching for him all around but I cna not find him."
        f "I did not see any cat around."
        r "Can you please help me?"
        show fiupoz2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        f "Well… I have a lot to do. I have homework and I have to learn…"
        r "What about a date with me? Will you help me for such a reward?"
        show fiupoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz2:
            alpha 1.0
            linear 1.0 alpha 0.0
        f "Where did you see him last time? How does he look like?"
        r "He was here a moment ago… but now I can not see him anymore. He is a black big cat."
        f "Ok, I will look around."
        $ macskaholvan = "parktonal"

    if macskaholvan == "parknal":
        if macskanakkinaltadatejet == True:
            $ fogjhalat = 1
            $ pecabotkell = True
            f "Why did this fucking cat not drinking the milk?"
            r "Oh you are such a dummy! Pepper eats only fish."
            f "Do you have any fish?"
            r "No, I do not have any. I would catch him easy if would have some…"
            f "Shit. Does Pepper like the canned fish?"
            r "Not really. He eats fresh fish only."
            f "Ok, now I go and I will catch him a fish… Do you have a fishing rod?"
            r "Nope..."
            f "Just as I tough… fine, I have to build a fishing rod…"
            $ annaholvan = "parktonal"
            show lizahazakozelibeszedhez:
                alpha 1.0
                linear 1.0 alpha 0.0
            show ritabeszedfestekes:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            show screen baloldalisomszed
            $ renpy. pause(hard=True)
        r "Did you find Pepper?"
        f "Yes, but I can not catch him."
        r "Try to give him food, maybe you can catch him that way."
        f "Why do you not go and catch your cat?"
        r "Pepper was here a few moments ago but I could not catch him either."
        f "Ok, so we need some kind of food..."
    if macskaholvan == "temeto":
        if macskanalad == 0:
            f "I will be right back."
            r "I am so glad! I will wait for you here!"
        if macskanalad == 1:
            $ macskanalad = 2
            $ ritaholvan = "sehol"
            $ ritamacskaja = 2
            hide utcaihazakritahattal
            f "Here you are! Pepper is here for you!"
            r "Thank you! I am so glad you found him! Here you are! Take this paint remover! This is the only thing I can give you now."
            f "Thank you! What should I do with this?"
            r "I do not know. I am so happy you found Pepper. How should I thank you for this?"
            $ festekoldonalad = 1
            $ neztvt9resz = 1
            f "What about a date?"
            r "Sounds great! Let us meet in the pastry shop tomorrow ,after university."
            f "Ok, tomorrow..."
            r "I should go now! Byebye!"

    show lizahazakozelibeszedhez:
        alpha 1.0
        linear 1.0 alpha 0.0
    show ritabeszedfestekes:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen baloldalisomszed
$ renpy. pause(hard=True)
label alfonzalbeszelni:
    hide screen baloldalisomszed
    hide alfonzpoz1 onlayer elotte
    hide alfonzpoz2 onlayer elotte
    hide fiupoz1 onlayer elotte
    hide lizahazakozelibeszedhez onlayer elotte
    show lizahazakozelibeszedhez onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show alfonzpoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    if ismeretlenakadtalkokot == True:
        if kokonalad == 1:
            f "I am sorry. I can not find a person called Buzzy. Do you know where he might be?"
            al "I know it. He is the guard in the stripbar. He usually stands next to the backdoor."
            f "Thank you for your information."
            show alfonzpoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show alfonzpoz2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            al "I never told you any info, ok?"
            show fiupoz1 onlayer elotte:
                xpos -0.1
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz8 onlayer elotte:
                xpos -0.1
                alpha 0.0
                linear 1.0 alpha 1.0
            f "…Ok…"
            show alfonzpoz2 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show alfonzpoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            al "Scram!"
            show fiupoz8 onlayer elotte:
                xpos -0.1
                alpha 1.0
                linear 0.5 alpha 0.0
            show fiupoz1 onlayer elotte:
                xpos -0.1
                alpha 0.0
                linear 0.5 alpha 1.0
            show screen s05
            u ""
        else:
            al "I do not care! Just scram!"
            f "Alright."

    if ismeretlenakadtalkokot == False:
        $ ismeretlenakadtalkokot = True
        f "Hello!"
        f "I am sorry Sir…"
        show alfonzpoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show alfonzpoz2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        al "What? What do you want, little flea? Do you speak to me? "
        show fiupoz1 onlayer elotte:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2 onlayer elotte:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Yes… I am Sir… Can I?"
        al "Do you know me?"
        f "No. I hope you will tell me. My name is Fred. Nice to meet you!"
        al "Who cares about your name?"
        f "... Do you know any person called Buzzy or Alfonz? Cili sent me and…"
        show alfonzpoz2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show alfonzpoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        al "Such a worm will be our new co-worker?"
        f "What kind of co-worker? Oh no! No! I don’t want to have anything to do with Cili’s business. This is a one time job only."
        al "Do not play the top guy! My name is Alfonz. You are looking for me."
        show fiupoz2 onlayer elotte:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Are you sure I am searching for you?"
        show alfonzpoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show alfonzpoz2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        al "Do you tell me I am a liar? Jerk! I'll hit your beak chicken!"
        al "You will get in big trouble when Cili finds out you did not deliver the drug in time… Decide! Chicken!"
        show fiupoz1 onlayer elotte:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz4 onlayer elotte:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        $ kokonalad -= 1
        f "This bird analogy again... Here is your bad! No problem! Keep it easy!"
        show alfonzpoz2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show alfonzpoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        al "That is what I like. You start to become a real team-member… I like it."
        f "I have to go now. I hope we will never meet again…"
        al "Carefully with your wishes little thrush..."
        if kokonalad == 1:
            $ lidiaholvan = "cukrazdabanszamlazik"
            $ debraholcsinal = "napaliban3"
        show lizahazakozelibeszedhez onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz4 onlayer elotte:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show alfonzpoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        show screen baloldalisomszed
        $ renpy. pause(hard=True)

    show lizahazakozelibeszedhez onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show alfonzpoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen baloldalisomszed
$ renpy. pause(hard=True)
label amandavalbeszelnilizaelott:
    hide screen baloldalisomszed
    hide invertori onlayer elotte6
    hide screen invertori2
    hide screen invertori
    show lizahazakozelibeszedhez onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show amandapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    am "Who do I see around?"
    f "Hy! What is up?"
    am "Nothing special. I have a performance today."
    f "Did you get any letter?"
    am "Not yet. I am watching my brother. He did not go out at night."
    am "I hope he will get a letter soon. I wish this shady business to end, but fast."
    f "Ok. I thought you forgot about me."
    am "Do not worry. I won’t."
    f "I have to go now! Bye!"
    am "I am still waiting for my ride…"
    show lizahazakozelibeszedhez onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori
    show screen baloldalisomszed
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
