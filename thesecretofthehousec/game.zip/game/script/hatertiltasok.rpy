label tiltasok:
    if kezd == False:
        jump ugrik
    if invertorinejelenyenmeg == False:
        show screen invertori2
    $ invertorinejelenyenmeg = False
    label ugrik:
    hide screen alvas
    hide screen kiverjemvagyne
    hide screen lizamejzozbanvan
    hide screen debrakert2pozbanvan
    hide screen mamakert2pozbanvan
    hide screen kipakolandodoboz
    hide screen poszterekgomjai
    hide screen atjaroszov
    hide screen invertoriszov
    hide screen invertori
    hide screen nappali
    hide screen furdo
    hide screen atjaro
    hide screen fojasoball
    hide screen fojasojobb
    hide screen konyha
    hide screen debramitcsinaljon
    hide screen atjarosecial
    hide screen szennyesfoldon
    hide screen fifimozog
    hide screen fifiodapisilt
    hide screen tvvisszakerul
    hide screen megintcsengetnek
    hide screen fifiboritekpiszkal
    hide screen terkep
    hide screen tanterem
    hide screen bolt
    hide screen lizanapalia
    hide screen lizafurdoje
    hide screen lizaatjaroja
    hide screen lizakertje
    hide screen baloldalisomszed
    hide screen fajasokertfele
    hide screen debrakertje
    hide screen debrakertje2
    hide screen park
    hide screen parkto
    hide screen temetokapu
    hide screen temeto
    hide screen parkpad
    hide screen cukrazda
    hide screen nyomortanya
    hide screen svetlanahaza
    hide screen lakotomb1emelet
    hide screen ciliszoba
    hide screen stripbar

    if telefonalsz == True:
        $ telefonalsz = False
        jump telefonnalfed




    if ladabanvagyok == True:
        $ ladabanvagyok = False
        jump ladaazinvertoribanszov

    if screentiltas == True:
        $ screentiltas = False
        hide fekete onlayer screens
        if holvagyok == "atjaro":
            if atjaroszov == 1:
                jump alszomegyetszov
        if holvagyok == "napaliban":
            jump nappaliszov
        if holvagyok == "furdo":
            $ fekete = True
            if hanyadiknapvan >= 4:
                show furdomosogep
                hide furdomosogep onlayer elotte
            if furdoszov == 1:
                jump wczekszov
            if furdoszov == 2:
                jump debratmegtapizod5reszszov

        if holvagyok == "fojasoball":
            jump fojasoballszov
        if holvagyok == "fojasojobb":
            jump fojasojobbszov

    if pornomagazint == "nezed":
        jump magazinbabelenezekszov
    if debratmegnezed == "ablakottoroljobboldalt":
        jump debrajobbfojasonablakottorolszov
    if debratmegnezed == "pultotorol":
        jump debrakanyhatorolgetszov
    if debratmegnezed == "budittakaritani":
        jump debrafurdobenbudittakaritszov
    if debratmegnezed == "foton":
        jump debrafotokozelebrolszov
    if debratmegnezed == "raesve":
        jump raesosjelenet2napszov
    if debratmegnezed == "gondolkodik":
        jump debratolkerdezelszov
    if debratmegnezed == "alanez":
        jump felsoelemektiltasa
    if debratmegnezed == "olvasni":
        jump felsoelemektiltasa
    if debratmegnezed == "foz":
        if hanyadiknapvan == 3:
            jump felsoelemeknemtiltasa
        jump felsoelemektiltasa
    if debratmegnezed == "felmos":
        jump felsoelemektiltasa
    if csinalszvalamit == "porszivoz":
        jump porszivozszov
    if csinalszvalamit == "sulibamensz":
        $ csinalszvalamit = "semit"
        jump mamaelkoszon3reszregelszov
    if csinalszvalamit == "kavet":
        $ csinalszvalamit = "semit"
        jump kavetkeszitszov
    if csinalszvalamit == "szendvics":
        jump szedvicskeszitesszov
    if csinalszvalamit == "takarit":
        show screen debramitcsinaljon
        jump fifipisifeltakaritszov
    if csinalszvalamit == "takarit2":
        show screen debramitcsinaljon
        jump fifipisifeltakarit2szov
    if csinalszvalamit == "takarit3":
        show screen debramitcsinaljon
        jump fifipisifeltakarit3szov
    if csinalszvalamit == "takarit4":
        show screen debramitcsinaljon
        jump fifipisifeltakarit4szov
    if csinalszvalamit == "mosogat2":
        show screen invertori2
        jump kimosniaszivacsotszov
    if csinalszvalamit == "mosogat":
        show screen invertori2
        if hanyadiknapvan == 2:
            show screen fifimozog
            show screen debramitcsinaljon
        jump mosogasszov
    if csinalszvalamit == "tvprogramoz":
        show screen fifimozog
        jump tvprogramozasszov
    if csinalszvalamit == "Tanul":
        $ csinalszvalamit = "semit"
        show screen fifimozog
        show screen debramitcsinaljon
        jump ferdtanuljonszov
    if kivelbeszelsz == "wcajto":
        $ kivelbeszelsz = "senki"
        jump elsonapvegefele
    if kivelbeszelsz == "pohar":
        $ kivelbeszelsz = "senki"
        jump poharuditoszov
    if kivelbeszelsz == "szedvics":
        $ kivelbeszelsz = "senki"
        jump szedvicselszov
    if kivelbeszelsz == "debra":
        $ kivelbeszelsz = "senki"
        jump debratolkerdezelszov
    if kivelbeszelsz == "mama":
        $ kivelbeszelsz = "senki"
        jump mamavalbeszelszov
    if kivelbeszelsz == "debraesik":
        $ kivelbeszelsz = "senki"
        jump debralevesziaszedvicsetszov
    if beszedvalamivelkapcsolatban == "udito":
        $ fekete = True
        jump uditomagamhozvenniszov
    if beszedvalamivelkapcsolatban == "konyhadebra":
        $ beszedvalamivelkapcsolatban = "semi"
        $ fekete = True
        jump debraval3reszkonyhareggelszov
    if beszedvalamivelkapcsolatban == "konyhamama":
        $ beszedvalamivelkapcsolatban = "semi"
        $ fekete = True
        jump mamavalbeszelniakonyhabanszov
    if fekete == False:
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.0
    if hanyadiknapvan >= 9:
        $ fekete = False
    hide screen netunnyonelatjaro
    hide screen poszterekkepei

label tiltzar1:
    hide kezdjel1
    hide kezdjel2
    hide kezdjel3
    hide kezdjel4
    hide kezdjel5
    hide doboz
    hide haznappali
    hide furdo
    hide atjaro
    hide fajasoball
    hide fajasojobb
    hide poszteresdoboz
    hide boritek
    hide konyv
    hide ruha
    hide szemeteszsak
    hide ujsagkicsi
    hide debrasopor
    hide debraul
    hide debraujsaggal
    hide nappali ujsag
    hide haznappalitanyer
    hide nappalisedvics
    hide fiupoz1
    hide agynemu
    hide szemeteszsak
    hide ujsagkicsi
    hide debrapoz5
    hide atjarovirag
    hide locsolokanna
    hide fajasojobbvirag
    hide debrafotelpislog
    hide debrapoz4sepru
    hide debrapoz2
    hide debrapoz4
label tiltzar2:
    hide fifiszagol
    hide fifiszagolpislog
    hide alvashozparna
    hide fiualszik
    hide fifimorog
    hide nagyikanapenalap
    hide mamakanapenpislog
    hide nagyikanapenszemoldok1
    hide konyha
    hide konyhavirag
    hide konyhamosatlan
    hide konyhapohar
    hide konyhaszendvicskendo
    hide konyhazoldelol
    hide debrafoz
    hide debrafelmos
    hide fiutanul
    hide fiuszenyes
    hide fiutisztaruha
    hide ferdmosogat
    hide konyhamosotedeny
    hide fifisetaszembe onlayer hatsominus1
    hide fifioldalseta onlayer hatsominus1
    hide fifisetahatra onlayer hatsominus1
    hide fifipisil
    hide fifipisil onlayer hatso
    hide hugy
    hide hugy1
    hide felsurolfiu onlayer hatso
    hide invertoritaviranyito
    hide mamaszenyo onlayer elotte6
    hide arcbaszenyo3 onlayer elotte6
    hide arcbaszenyo2 onlayer elotte6
    hide arcbaszenyo1 onlayer elotte6
    hide arcbaszenyoalap onlayer elotte6
    hide debraeszik1
    hide debraeszik2
    hide debratvnezalap
    hide debratvnezpislog
    hide konyhaeste
    hide furdoeste
    hide fajasojob2beste
    hide fajasoball2este
    hide bubi1anim
    hide bubi2anim
    hide bubi3anim
    hide nappalitv onlayer elotte6
    hide nappalitv onlayer elotte
    hide nappalitv
    hide taviranyitokonyhaban
    hide fredprogramoz onlayer hatso
    hide fifimorog1
    hide ferdallofaszszem1
    hide ferdallofaszszem2
    hide debrafelmutatt1
    hide debrafelmutatt2
    hide raesoshater
    hide segbebasosjelenet
    hide segbebasosjelenet2 onlayer hatso
    hide fotokosszevissza
    hide fotokosszevissza2
    hide fotokosszevissza
    hide debrapoz2meltartoval
    hide fifigameover onlayer screens
    hide suhanle
    hide suhanle2
label tiltzar3:
    hide fredpisil onlayer screens
    hide reggelimama3resz
    hide debraregelkonyha3resz
    hide debraregelkonyha3reszk3
    hide debraregelkonyha3reszk4
    hide fred3reszk5
    hide fred3reszk6
    hide hajigazitsexy onlayer elotte6
    hide hajigazitsexy2 onlayer elotte6
    hide konyhaalapgep
    hide konyhaalapgepalatetnekul
    hide konyhaalapgepkesz
    hide konyhakave
    hide boltbelulrol1
    hide tanterem
    hide terkep
    hide kavefozoosszeszereles
    hide kavefozoosszeszereleshasznal
    hide kavefozoosszeszerelesszorotartolent
    hide kavefozoosszeszerelesszedo onlayer hatso
    hide kavefozoosszeszereleskupaklent
    hide kavefozoosszeszerelesszurolent onlayer hatso
    hide kavejelalap onlayer hatso
    hide kavejelalapfredk9 onlayer hatso
    hide kavejelalapdebrak8 onlayer hatso
    hide kavejelalapdebrak10 onlayer hatso
    hide kavejelalapdebrak8 onlayer hatso
    hide kavefozoosszeszereleskionto2
    hide fifimorog
    hide kavefozoosszeszereleskave
    hide fifikeesziktaltele
    hide fifikeeszik
    hide fifikeesziktalures
    hide kavefozoosszeszerelesszurolentkave onlayer hatso1
    hide kavejelalapkiontokave onlayer hatso
    hide konyhakave
    hide konyhaalapgepalatetnekul
    hide konyhaalapgepkesz
    hide fredruhatiszta
    hide fredtaska
    hide terkepalap
    hide kocsimegy1terkep
    hide kocsimegy5terkep
    hide kocsiparkolterkep
    hide terkephazak
    hide tanterem
    hide sirosfiu3resz
    hide teremdagi
    hide teremfred
    hide teremanika1
    hide teremanika2
    hide teremjim1 onlayer hatso
    hide teremjim2 onlayer hatso
    hide teremrita onlayer hatso
    hide teremdagiiszik
    hide teremfrediszik
    hide teremkola1
    hide teremgyum1
    hide teremkola2 onlayer hatso
    hide teremgyum2 onlayer hatso
    hide teremdagifullad
    hide debrapoz1
    hide dagiallas1
    hide mamakanapenalap onlayer hatso
    hide dagianapenalap onlayer hatso
    hide fredkapen onlayer hatso1
    hide dagianapenarc1 onlayer hatso
    hide mamakanapenkar1 onlayer hatso
    hide mamapank53 onlayer hatso1
    hide mamapank54 onlayer hatso1
    hide dagianapenarc1 onlayer hatso
    hide dagianapenarc2 onlayer hatso
    hide mamakanapenkar1 onlayer hatso
    hide mamakanapenkar2 onlayer hatso
    hide dagianapenfelall onlayer hatso
    hide dagianapenosszegornyedl onlayer hatso
    hide fiupoz2
    hide lize3reszk58
    hide utcaihazak
    hide anikamom
    hide fiupoz1
    hide boltbelulrol1
    hide boltokhatere
    hide boltokhatereauto
    hide debraiszik3resz
    hide szexjelenet1jelalap
    hide szexjelenet1jeldebranez
    hide szexjelenet1jelfrednez1
    hide szexjelenet1jelfrednez2
    hide szexjelenet1jelfrednez1
    hide szexjelenet1jeldebranyal
    hide nyalokazikdebra3resz
    hide szexjelenet1jelfrednyal
    hide szexjelenet2jelalap
    hide szexjelenet2jelfrednez1
    hide szexjelenet3jelalap
    hide szexjelenet3jelfrednez2
    hide fekvo3resz
    hide fredverinez
    hide szexjelenetkozeli onlayer hatso
    hide debranyulkal3reszanim8
    hide debraelveziamitcsinal3reszanim
    hide fredveri
    hide debranyulkal3reszanim12
    hide gatyabaverifred3resz
    hide szexjelenet4jelalap
    hide szexjelenet4jeldebra1
    hide szexjelenet4jelfred1
    hide szexjelenet4jeldebra2
    hide szexjelenet4jelfred2
    hide szuroazedenyben onlayer hatso
    hide zacosszuroazedenyben onlayer hatso1
    hide debrakonyhabaneszikanim
    hide debrakonyhabaneszikalap
    hide ferdkiverteujkep1
label tiltzar4:
    hide mamakonyhabanzombi
    hide konyhatanyerszendvics
    hide debranapalibanolvassa onlayer elotte6
    hide debrakonyhabaneszikanim onlayer hatso
    hide debrakonyhabaneszikalap onlayer hatso
    hide teremanika2 onlayer hatso2
    hide teremkitty onlayer hatso
    hide teremjim3 onlayer hatso
    hide teremrita onlayer hatso3
    hide fajasoballvirag onlayer hatso
    hide dagibelesakulcsjukon onlayer elotte6
    hide mamavetkozik4resz1 onlayer elotte6
    hide mamavetkozik4resz2alap onlayer elotte6
    hide mamavetkozi4reszlegzesanim onlayer elotte6
    hide mamavetkozi4reszszemanim onlayer elotte6
    hide mamavetkozi4reszszajanim onlayer elotte6
    hide mamavetkozik4resz2kulcsjuk onlayer elotte6
    hide mamavetkozik4resz3 onlayer elotte6
    hide dagibelesakulcsjukonszem2 onlayer elotte6
    hide dagiallas1 onlayer elotte6
    hide fiupoz1szem2 onlayer elotte6
    hide dagilabver
    hide dagiallas1
    hide fajasojobbvirag onlayer kozep
    hide debraablakotmosanim
    hide debraablakotmos onlayer elotte6
    hide fiupoz2 onlayer hatso
    hide dagilabkotes
    hide teremkola2
    hide teremgyum2
    hide dagilabkotes
    hide fredverihater
    hide lizahaza
    hide lizagyomlalkicsianim
    hide lizakozelisegmozgashatter onlayer hatso
    hide lizagyomlalanim onlayer hatso
    hide furdomosogep
    hide furdomosogep onlayer elotte
    hide felmosodebramogott
    hide fiupoz3 onlayer elotte
    hide fiupoz2 onlayer elotte
    hide final4reszdebraraesnek1 onlayer elotte
    hide final4reszdebraraesnek2alap onlayer elotte
    hide final4reszdebraraesnek2csicsianim onlayer elotte
    hide final4reszdebraraesnek2dszaj1 onlayer elotte
    hide final4reszdebraraesnek2dszemanim onlayer elotte
    hide final4reszdebraraesnek2fszaj1 onlayer elotte
    hide final4reszdebraraesnek2fszemanim onlayer elotte
    hide final4reszdebraraesnek2alap onlayer elotte
    hide final4reszdebraraesnek2csicsianim onlayer elotte2
    hide final4reszdebraraesnek2dszaj1 onlayer elotte
    hide final4reszdebraraesnek2dszemanim onlayer elotte
    hide final4reszdebraraesnek2fszemanim onlayer elotte
    hide final4reszdebraraesnek2dszajanim onlayer elotte
    hide final4reszdebraraesnek2dszaj1 onlayer elotte
    hide final4reszdebraraesnek2dszajanim onlayer elotte
    hide final4reszdebraraesnek2fszaj1 onlayer elotte
    hide final4reszdebraraesnek2fszajanim onlayer elotte
    hide final4reszdebraraesnek3alap onlayer elotte2
    hide final4reszdebraraesnek3dszemanim onlayer elotte2
    hide final4reszdebraraesnek3dszaj1 onlayer elotte2
    hide final4reszdebraraesnek3csecse onlayer elotte3
    hide final4reszdebraraesnek3dorzsianim onlayer elotte3
    hide final4reszdebraraesnek3dszaj1 onlayer elotte2
    hide final4reszdebraraesnek3dszajanim onlayer elotte2
    hide final4reszdebraraesnek3dszaj1 onlayer elotte2
    hide final4reszdebraraesnek3dszajanim onlayer elotte2
    hide final4reszdebraraesnek4alap onlayer elotte3
    hide final4reszdebraraesnek4szemanim onlayer elotte3
    hide final4reszdebraraesnek4szajanim onlayer elotte3
    hide final4reszdebraraesnek4fiuanim onlayer elotte3
    hide final4reszanim1 onlayer elotte3
    hide final4reszanim2 onlayer elotte3
    hide final4reszanim3 onlayer elotte3
    hide eltortakonzevnyito onlayer kozep
    hide mamakavezikanim
    hide fredanapalibanpoz1bszem2
    hide fredanapalibanpoz1bszem1
    hide fredanapalibanpoz1jszem2
    hide fredanapalibanpoz1jszem1
    hide fredanapalibanpoz2b
    hide fredanapalibanpoz2j
    hide konyhazoldelol onlayer elotte
    hide dagiallas1 sir onlayer elotte6
    hide dagiallas1 sir
label tiltzar5:
    hide debraafurdoben5resz
    hide ferdkezejobb
    hide debramergesenhatranez
    hide ferdkiutveafurdoben5resz
    hide feketefeher
    hide szaraatjaroban
    hide kakikidobasa onlayer elotte6
    hide konyhamosatlan2
    hide bubi3anim onlayer hatso
    hide konyhatanyerszendvicskep2
    hide konyhatanyerszendvicskep3
    hide teremkola3
    hide lampa5resz
    hide teremjim4 onlayer hatso
    hide tanteremkozeli onlayer kozep
    hide kittyelolbeszed1 onlayer kozep
    hide fiupoz1 onlayer kozep
    hide fiupoz2 onlayer kozep
    hide anikaelolbeszed1 onlayer kozep
    hide anikaelolbeszed2 onlayer kozep
    hide teremrita onlayer kozep
    hide jimelolbeszed1 onlayer kozep
    hide jimelolbeszed2 onlayer kozep
    hide konyhatanyerszendvics2 onlayer hatso
    hide szedvicsjelenet5resz1 onlayer kozep
    hide szedvicsjelenet5resz2 onlayer kozep
    hide szedvicsjelenet5resz3 onlayer kozep
    hide koldoskurvamagas490
    hide taska5resz
    hide lizapoz1
    hide lizazacsija
    hide lizapoz1540
    hide lizapoz1540ngy
    hide lizazacsija540
    hide csovesfodo540
    hide csovesfodo540cilanim
    hide csovesfodogyuru540
    hide csovesfodobeszed
    hide csovesfodobeszedgyuru
    hide csovesfodobeszedgyurucsilanim
    hide nagyonkozelibolt
    hide lizafogdosas5reszalap
    hide lizafogdosas5reszanim
    hide lizafogdosas5reszszemanim
    hide lizafogdosas5reszszemanim
    hide lizafogdosas5reszszaj4
    hide anikamomngy
    hide terkepstrip
    hide zolibeszed4resz
    hide ritabeszed onlayer kozep
    hide ircsajhd
    hide ircsajmeretutcan
label tiltzar6:
    hide ferdporszivozikmagas490
    hide ferdporszivozikmagas1080
    hide debrapozelpirul
    hide debrabudittakaritanim
    hide debrasegge6resz
    hide debrapultottorolanim
    hide debramelle6resz
    hide debrapan6resz1 onlayer elotte
    hide debrapucban1
    hide debrapucban2
    hide debrapozpuc1
    hide debrapozpuc2
    hide debrapozpuc2fulbe1
    hide debrapozpuc2fulbe2
    hide debrapucban2fulbe1
    hide debrapucban2fulbe2
    hide anyakereszt1
    hide csillogaskicsianim
    hide keresztnyaklanc
    hide ruhaszalito
    hide ruhaszalitoruha
    hide ancik
    hide ancikpoz1
    hide konyhabanmamahattal
    hide mamapoz1
    hide mamalabal1080
    hide mamalabal540
    hide konyhabanmamahattal
    hide mamalabal540
    hide mamapoz1
    hide lizanappalia
    hide lizaatjaroja
    hide lizafurdo
    hide cili
    hide lizanappaliakozeli
    hide lizakertje
    hide kertidudva1
    hide kertidudva2
    hide kertidudva3
    hide kertidudva4
    hide kertigomba
    hide kertiszemet1
    hide kertiszemet2
    hide kertiszemet3
    hide kertiszemet4
    hide levelekossze
    hide levelekszet
    hide madarhaza
    hide kavejelalap
    hide haznappalikozeli
    hide lizakertbentornazikanim
    hide kukanagyzold
    hide madarhazazinvertoriban
    hide rita540
    hide kitty540
    hide anikalabbal540
    hide shopelotbeszedhater
    hide anikaelolbeszed1
    hide lizacicikozelrolnez6resz
    hide lizaarcahozkozelpeni6resz
    hide debrahattallomolfojasojobbanim
    hide mamahattalall
    hide fajasoballvirag
    hide fajasoballkozeli
    hide kavejelalapfredk11
    hide kavejelalapfredk1kep2
    hide kavejelalapfredk1kep1
    hide mamanappalihattal
    hide debrabudittakaritanim
    hide debrabudittakaritmozanim
    hide debrahatta6resz onlayer screens
    hide debrakonyhabantorolgetanim
    hide konyhaszonyeg
    hide mamahattalallszexi6resz
    hide mamahattalallszexifelsoruha6resz
    hide felsurolfiu2
    hide lizatornazbeszedalap
    hide lizakertbentornazik1080anim
    hide lizatornazszonyeg
    hide fred6reszk5
    hide lizacicikozelrolnez6reszv2hat
    hide lizacicikozelrolnez6reszv2alap
    hide lizacicikozelrolnez6reszv2ciciszopanim
    hide lizacicikozelrolnez6reszv2cicifoganim
    hide lizacicikozelrolnez6reszv2szaj1
    hide lizacicikozelrolnez6reszv2ele
    hide lizaarcahozkozelpeni6resz
    hide lizaarcahozkozelpeni6reszv2hat
    hide lizaarcahozkozelpeni6reszv2alap
    hide lizaarcahozkozelpeni6reszv2mozanim
    hide mrpuli540
    hide lizaarcahozkozelpeni6reszv2hat
    hide mrpulipoz
    hide stripbarjelenet10
    hide stripbarjelenet14anim
    hide stripbarjelenet14animgeci
    hide stripbarjelenet14animgeciremeg
    hide stripbarjelenet13
    hide stripbarjelenet13v1
    hide szexanim5reszlizaanim
    hide stripbarjelenet12
    hide stripbarjelenet11
    hide lizafogdosas5reszszaj5
    hide vegsojelenet6resz8
    hide debrapironkodik6reszv2
    hide pilango6reszanim
    hide pilango6reszanim2
    hide pilango6reszanim3
    hide pilango6reszanim4
    hide pilango6reszanim5
    hide pilangoszal6reszanim6
    hide pilangoszal6reszanim
    hide pilangoszal6reszanim2
    hide pilangoszal6reszanim3
    hide pilangoszal6reszanim4
    hide pilangoszal6reszanim5
    hide vegsojelenet6resz7gecianim
    hide vegsojelenet6resz7anim
label tiltzar7:
    hide fajasokertfele
    hide debrakertje
    hide debrakertjedudvak1
    hide debrakertjedudvak2
    hide debrakertjedudvak3
    hide debrakertjedudvak4
    hide debrakertjedudvak5
    hide debrakertjegombak
    hide debrakertjegombakelveheto
    hide debrakertjekivagnivalobokor
    hide debrakertjekomposztlada
    hide debrakertjekomposztladafu1
    hide debrakertjekomposztladafu2
    hide debrapironkodik6resz
    hide debrakertje2bokorgaz onlayer hatso1
    hide debrakertje2 onlayer hatso1
    hide debrakertje2erme onlayer hatso1
    hide debrakertje2foldturas onlayer hatso1
    hide debrakertje2foldturasazermen onlayer hatso1
    hide debrakertje2jomadzag onlayer hatso1
    hide debrakertje2leerestocso onlayer hatso1
    hide debrakertje2leerestocsohejen onlayer hatso1
    hide debrakertje2medencealap onlayer hatso2
    hide debrakertje2medencekosz onlayer hatso3
    hide debrakertje2medencekoszosviz onlayer hatso2
    hide debrakertje2medenceteto onlayer hatso3
    hide debrakertje2medencetisztaviz onlayer hatso2
    hide debrakertje2medencealap onlayer kozep
    hide debrakertje2medencekosz onlayer kozep2
    hide debrakertje2medencekoszosviz onlayer kozep
    hide debrakertje2medenceteto onlayer kozep2
    hide debrakertje2medencetisztaviz onlayer kozep
    hide debrakertje2medencekoszosvizanim onlayer kozep
    hide debrakertje2medencetisztavizanim onlayer kozep
    hide debrakertje2roszmadzag onlayer hatso1
    hide debrakertje2ruhafent onlayer hatso1
    hide debrakertje2ruhalent onlayer hatso1
    hide debrakertje2salgcso onlayer hatso1
    hide debrakertje2salgcsofoltok onlayer hatso1
    hide debrakertje2sokdudva onlayer kozep
    hide debrakertje2vetemenyes onlayer hatso1
    hide debrakertje2vetemenyesdudva onlayer hatso1
    hide debrakertje2
    hide madzag
    hide parkalap
    hide parkhatsobokor
    hide parkhatsobokorelotifa onlayer hatso1
    hide parkkozepsoresz onlayer hatso2
    hide parklegfelsoresz onlayer hatso3
    hide parkwcelotiresz onlayer hatso1
    hide terkeppark
    hide parkadriana onlayer kozep
    hide parkszemet1 onlayer kozep
    hide parkszemet2 onlayer kozep
    hide parkszemet3 onlayer kozep
    hide parkszemet4 onlayer kozep
    hide parkszemet5 onlayer kozep
    hide parkszemet6 onlayer kozep
    hide parkszemet7 onlayer kozep
    hide parkszemet8 onlayer kozep
    hide fiupoz4 onlayer screens
    hide fiupoz5 onlayer screens
    hide fiupoz2 onlayer screens
    hide fiupoz1 onlayer screens
    hide mamapoz2 onlayer screens
    hide teremanika1 onlayer hatso2
    hide teremanika2 onlayer hatso2
    hide rozsa
    hide rozsa540
    hide gyula540
    hide rozsapoz1
    hide rozsapoz1szem2
    hide gyula
    hide gyulapoz1
    hide nap7napozokeret
    hide nap7napozovaszon
    hide nap7napozopuli
    hide tuazinvertoriban
    hide kitty onlayer kozep
    hide kittyelolbeszed1 onlayer kozep
    hide parkkozelei onlayer kozep
    hide kitty270szemetettszedanim onlayer hatso
    hide kitty270szemetettszedanim2 onlayer hatso1
    hide kitty270szemetettszedanim3 onlayer hatso2
    hide nap7kittysexy onlayer elotte
    hide adriana onlayer elotte
    hide brambarkacsboltban
    hide barkacsboltkozeli
    hide brampoz1forditott
    hide vaszon2azinvertoriban
    hide nap7napozokozeli
    hide lizacicibasz7reszanim
    hide lizacicibasz7reszszembanim
    hide lizacicibasz7reszszembroljanim
    hide lizacicibasz7reszszemjanim
    hide lizacicibasz7reszszemjanim2
    hide lizacicibasz7reszszemjrolbanim
    hide lizacicibasz7reszszajanim
    hide lizacicibasz7reszszemjanim3
    hide nap7f1alap
    hide nap7f1szaj1
    hide nap7f1szaj4
    hide parkadriana
    hide lizatornazbeszedalap
    hide nap7f3
    hide nap7f3g
    hide nap7f32
    hide nap7f3g2
    hide lizafurdokiskendo
    hide debrapoz7
    hide debrapoz7v2
    hide mamapoz2
    hide mamapoz1 onlayer kozep2
    hide debrapoz4 onlayer kozep
    hide lizacicibasz7reszbanim
    hide nap7a29
    hide nap7a30
    hide nap7a31v1
    hide nap7a31v2
    hide nap7a33
    hide nap7a34
    hide nap7a35hatter
    hide debrakertbentanulanim
    hide nap7a32mozanim
    hide nap7a35mosogep
    hide nap7a35seggfeje
    hide nap7a36
    hide nap7a37alap
    hide nap7a37gep
    hide nap7a38
    hide nap7a39
    hide nap7a35segganim
    hide nap7a35segganim
    hide nap7a37szemanim
    hide nap7a35szemanim
    hide nap7a35szajanim
    hide nap7f5alap
    hide nap7f5debramozanim
    hide nap7f5debraszemanim
    hide nap7f5debraszajanim
    hide nap7f5fredszajanim
    hide debraalappoz2v2
    hide viragcserepazinvertoriban
    hide fajasokertfelekozeli
    hide debrapoz9
    hide debrakertbentanulkonyv
    hide debrakertbentanulcserep
    hide debraolvaskertben
    hide nap7a19
    hide csillagok6resz
    hide csillagok6resz onlayer elotte
    hide nap7a21
    hide mamakeresmozanim
    hide maminezelodikanim
    hide mami540nezelodikanim
    hide mama540keresmozanim
    hide debrakertkozelei
    hide debrakert2kozelei
    hide debrakertje2soveny onlayer hatso
    hide debrakertkozelei onlayer kozep
    hide mamabikinibenpoz1 onlayer kozep
    hide debrakertkozelei onlayer kozep
    hide mamabikinibenpoz1 onlayer kozep
    hide mama540keresmozanim2
    hide mama540keresmozanim onlayer hatso1
    hide fifimorog onlayer kozep2
    hide fifiszagol onlayer kozep2
    hide fifiszagolpislog onlayer kozep2
    hide fifipisil onlayer hatso
    hide fifiszagol2 onlayer kozep2
    hide fifiszagolpislog2 onlayer kozep2
    hide nap7f5fredszaj2
    hide nap7f5debraszaj5
    hide nap7a37gep onlayer hatso
    hide nap7a37segg1 onlayer hatso
    hide nap7a37segg1 onlayer hatso
    hide nap7a37segganim onlayer hatso
    hide nap7a38 onlayer hatso
    hide nap7a38spermaanim onlayer hatso
    hide nap7a31v2 onlayer hatso
    hide nap7a31v1 onlayer hatso
    hide nap7a39 onlayer hatso
    hide debrakert2kozelei onlayer kozep2
    hide fiupoz1 onlayer kozep2
    hide mamabikinibenpoz1 onlayer kozep2
    hide poszterbal
    hide poszterkozep
    hide poszterjobb
    hide fauna2falon
    hide faunafalon
    hide petykafalon
    hide fiupoz4
    hide fiupoz5
    hide mami540nezelodikanim2 onlayer kozep
    hide mami540nezelodikanim2 onlayer elotte
    hide mami540nezelodikanim2
    hide mama540keresmozanim2 onlayer kozep
    hide lizacicibaszpan7reszanim
    hide lizacicibaszpangeci7reszanim
    hide debrakertje2medencekoszosvizanim onlayer hatso2
    hide debrakertje2medencetisztavizanim onlayer hatso2
    hide nap7f5ferd1
    hide nap7f5ferd2
    hide lizaszexjelenet7nappulival
    hide pilango6reszanim onlayer kozep
    hide pilango6reszanim5 onlayer kozep
    hide pilangoszal6reszanim onlayer kozep
    hide pilangoszal6reszanim2 onlayer kozep
    hide pilangoszal6reszanim5 onlayer kozep
    hide fojasoballoljel1 onlayer elotte
    hide fojasoballoljel2 onlayer elotte
label tiltzar8:
    hide lizaszexresz8jel4alap
    hide lizaszexresz8jel4anim
    hide debraszagolhater
    hide debraszagol
    hide debraszagol2
    hide pulialszikleegettelefonoshatter
    hide atjarokozeli
    hide fredtelefonal
    hide mamalabal2r2540
    hide mamalabal2r1540
    hide mamalabal2r21080
    hide mamalabal2r11080
    hide mamapoz3r1
    hide mamapoz3r2
    hide pulialszikleegett
    hide parktoalap
    hide parktopadok
    hide parktohatsofa
    hide parktoelsofa onlayer hatso
    hide parktobokrokelol onlayer hatso2
    hide parktoszemet1 onlayer hatso3
    hide parktoszemet2
    hide parktoszemet3 onlayer hatso3
    hide parktoszemet4 onlayer hatso3
    hide parktoszemet5 onlayer hatso3
    hide parktoszemet6
    hide parktoszemet7 onlayer hatso3
    hide parktoszemet8 onlayer hatso3
    hide parktohalak
    hide pokhalo
    hide pok
    hide pokhalott
    hide lizacicibasz7reszbanimv2
    hide tulipanazinvertoriban
    hide gyongyviragazinvertoriban onlayer kozep
    hide lizagyomlalanim
    hide lizagyomlalanim2
    hide lizakeresanim1
    hide lizakeresalap1
    hide lizakeresanim2
    hide lizakeresalap2
    hide lizaseggeparktonal onlayer elotte
    hide kittykedvesazrc onlayer kozep2
    hide parktokozeli onlayer kozep
    hide kitty onlayer kozep
    hide kittypuszitad onlayer kozep2
    hide fiupoz1pir
    hide fiupoz1pir onlayer kozep
    hide lizamergespoz onlayer kozep
    hide lizakedvespoz onlayer kozep
    hide kittymérgesazrc onlayer kozep2
    hide pilango6reszanim onlayer hatso3
    hide pilango6reszanim2 onlayer hatso3
    hide pilango6reszanim3 onlayer hatso3
    hide pilango6reszanim4 onlayer hatso3
    hide pilango6reszanim5 onlayer hatso3
    hide pilangoszal6reszanim6 onlayer hatso3
    hide pilangoszal6reszanim onlayer hatso3
    hide pilangoszal6reszanim2 onlayer hatso3
    hide pilangoszal6reszanim3 onlayer hatso3
    hide pilangoszal6reszanim4 onlayer hatso3
    hide pilangoszal6reszanim5 onlayer hatso3
    hide fiupoz1kep1
    hide fiupoz1kep2
    hide svetlana540
    hide svetlana540szem2
    hide svetlana1080
    hide svetlana1080szem2
    hide svetlanapan
    hide svetlanapoz1
    hide svetlanapoz1s2
    hide svetlanapoz2
    hide shopelotbeszednagyonkozeli
    hide final4resz2-5
    hide debramosogatanim
    hide mozsarazinvertoriban
    hide lizaszexresz8jel0
    hide lizaszexresz8jel0szaj1
    hide lizaszexresz8jel0szemanim
    hide lizaszexresz8jel2lizafejeanim
    hide lizaszexresz8jel2lizafejeanimv2
    hide lizaszexresz8jel6gecisalap
    hide lizaszexresz8jel6gecisszemanim
    hide lizaszexresz8jel6gecianim
    hide lizaszexresz8jel6gecisszaj1
    hide lizaszexresz8jel7
    hide lizaszexresz8jel6remeg
    hide lizaszexresz8jel5alap
    hide lizaszexresz8jel5fiuanim
    hide lizaszexresz8jel5noanim
    hide lizaszexresz8jel3
    hide lizaszexresz8jel2lizafejeelotalap
    hide lizaszexresz8jel2lizafaszanim
    hide lizaszexresz8jel2
    hide lizaszexresz8jel2lizafejeanimfojamatos
    hide lizaszexresz8jel4pulimoz1
    hide debrakertje2sokdudvafelszed1 onlayer kozep
    hide debrakertje2sokdudvafelszed2 onlayer kozep
    hide debrakertje2sokdudvafelszed1 onlayer kozep3
    hide debrakertje2sokdudvafelszed2 onlayer kozep3
    hide debrakertje2sokdudvafelszed3 onlayer kozep
    hide debrakertje2sokdudvafelszed4 onlayer kozep
    hide debrakertje2sokdudvafelszed5 onlayer kozep
    hide debrakertje2sokdudvafelszed6 onlayer kozep
    hide debrakertje2sokdudvafelszed7 onlayer kozep
    hide debrakertje2sokdudvafelszed8 onlayer kozep
    hide debrakertje2sokdudvafelszed9 onlayer kozep
    hide debrakertje2sokdudvafelszed10 onlayer kozep
    hide debrakertje2sokdudvafelszed11 onlayer kozep
    hide debrakertje2sokdudvafelszed12 onlayer kozep
    hide debraall onlayer kozep
    hide fiupoz1 onlayer elotte
    hide fiupoz2 onlayer elotte
    hide fiupoz4 onlayer elotte
    hide debrapoz4 onlayer elotte
    hide debrapoz1 onlayer elotte
    hide debrapoz2 onlayer elotte
    hide mama540keresmozanim onlayer hatso2
    hide debrakertje2sovenyelol onlayer kozep4
    hide debragyomlalanim onlayer hatso1
    hide debragyomlalanim onlayer hatso
    hide debragyomlalanim2 onlayer kozep2
    hide debrakertje2vetemenyes onlayer hatso3
    hide debrakertje2vetemenyesdudva onlayer hatso3
    hide mamadebrabeszel onlayer hatso1
    hide debrakertje2debraesmamahaterbenkososak onlayer hatso3
    hide 1dm onlayer elotte
    hide harmasbeszedpoz1ferd onlayer elotte
    hide harmasbeszedpoz1mama onlayer elotte
    hide harmasbeszedpoz1debra onlayer elotte
    hide 2dm onlayer elotte
    hide harmasbeszedpoz3ferd onlayer elotte1
    hide harmasbeszedpoz2mama onlayer elotte
    hide harmasbeszedpoz2debra onlayer elotte
    hide 3dm onlayer elotte
    hide harmasbeszedpoz3mama1 onlayer elotte
    hide harmasbeszedpoz3debra1 onlayer elotte
    hide harmasbeszedpoz3mama2 onlayer elotte
    hide harmasbeszedpoz3debra2 onlayer elotte
    hide harmasbeszedpoz3mama3 onlayer elotte
    hide harmasbeszedpoz3debra3 onlayer elotte
    hide debraesmamaasasutan onlayer elotte2
    hide harmasbeszedpoz3ferdcsepp onlayer elotte1
    hide debrakertje2asasutan onlayer hatso3
    hide lizaszexresz8jel2mindenfole onlayer hatso
    hide lizaszexresz8jel5mindenfele
    hide lizaszexresz8jel4pulianim onlayer hatso
    hide lizaszexresz8jel4pulianim2 onlayer hatso
    hide lizaszexresz8jel5alapmegjelenik onlayer hatso
    hide lizaszexresz8jel5alapmegjelenik
    hide lizaszexresz8jel4leteszanim onlayer hatso
    hide lizaszexresz8jel4fojtattanim onlayer hatso
    hide atjarohomajos
    hide harmasbeszedpoz1ferdszem2
    stop sound
label tiltzar9:
    hide temetokepu
    hide temetokepuelott onlayer kozep4
    hide temetokapuszemet1 onlayer hatso
    hide temetokapuszemet2 onlayer hatso
    hide temetokapuszemet3 onlayer hatso
    hide temetokapuszemet4 onlayer hatso
    hide temetokapuszemet5 onlayer hatso
    hide temetokapuszemet6 onlayer hatso
    hide temetokapuszemet7 onlayer hatso
    hide temetokapuszemet8 onlayer hatso
    hide temetokapuszemet9 onlayer hatso
    hide temetokapuszemet10 onlayer hatso
    hide temetokapuszemet11 onlayer hatso
    hide temetokapuszemet12 onlayer hatso
    hide temetokapuszemet13 onlayer hatso
    hide temetokapuszemet14 onlayer hatso
    hide temetokapuszemet15 onlayer hatso
    hide temetokapuszemet16 onlayer hatso
    hide temetokapuszemet17 onlayer hatso
    hide temetokapuszemet18 onlayer hatso
    hide temetokapuszemet19 onlayer hatso
    hide temetokapuszemet20 onlayer hatso
    hide temetokapuszemet21 onlayer hatso
    hide temetokapuszemet22 onlayer hatso
    hide temetokapuszemet23 onlayer hatso
    hide temeto
    hide temetoelott onlayer kozep4
    hide temetosirkosz1 onlayer hatso
    hide temetosirkosz2 onlayer hatso
    hide temetosirkosz3 onlayer hatso
    hide temetoigyufa onlayer hatso
    hide temetosirok onlayer hatso
    hide oregaparkban onlayer kozep
    hide parkpadoshater
    hide parkpadoshaterbokor onlayer kozep
    hide parkpadoshatermredwards
    hide parkpadoshaterfaag
    hide parkpadoshaterlevel
    hide parkpadoshaterszedvics
    hide parkpadoshatertaska
    hide parkpadoshatertej
    hide parkpadoshaterzsepi
    hide atjaroeste
    hide fredtelefonalsotetben
    hide haznallesed
    hide megleskapunal
    hide temetonelllesed
    hide elkapbaby
    hide temetoihazalaphatter
    hide amandapoz1
    hide babypoz1
    hide amandapoz2
    hide babypoz2
    hide temetoihazasztala onlayer hatso
    hide temetoihazafiupoz1 onlayer kozep
    hide temetoihazafiupoz2 onlayer kozep
    hide temetoihazmindenelott onlayer kozep2
    hide haznappalibanvan
    hide hazalapeste
    hide haznappalialvajarasnal
    hide debraalvajar540moz1
    hide debraalvajarmoz1
    hide haznappalibanvansotetben
    hide debraalvajar540anim
    hide debraalvajaranim
    hide amandapoztemetoben1
    hide amandapoztemetoben2
    hide fiupoz1csakszemanimkovetidebrat
    hide annabetekeredett
    hide slagcsoazinvertoriban
    hide annahaterenbetekeredett
    hide leengedocsoazinvertoriban
    hide jimelolbeszed2 onlayer hatso1
    hide jimelolbeszed2 onlayer hatso2
    hide csovesfodo540 onlayer kozep
    hide anikalabbal540 onlayer kozep
    hide parkkozelei onlayer elotte
    hide anikaelolbeszed1 onlayer elotte
    hide csovesfodobeszed onlayer elotte
    hide fiupoz1 onlayer elotte
    hide parkkozelei2 onlayer elotte
    hide jimelolbeszed2 onlayer elotte
    hide fiupoz2 onlayer elotte
    hide jimelolbeszed1 onlayer elotte
    hide adrianajelenetek9rasz1 onlayer elotte
    hide adrianabeszedfreddel onlayer kozep2
    hide adrianajelenetek9rasz2megjeleno onlayer elotte
    hide adrianajelenetek9rasz2alap onlayer elotte
    hide adrianajelenetek9rasz2szaj1 onlayer elotte
    hide adrianajelenetek9rasz2anim onlayer elotte
    hide adrianajelenetek9rasz2szaj onlayer elotte
    hide adrianajelenetek9rasz2elotte onlayer elotte2
    hide debrakertje2leerestocsohejen onlayer kozep4
    hide harmasbeszedpoz3ferd2 onlayer elotte2
    hide debrakertje2leengedocso1 onlayer kozep4
    hide debrakertje2leengedocso1 onlayer kozep
    hide harmasbeszedpoz1ferdszem2 onlayer elotte
    hide medemcetakarit1hater onlayer elotte
    hide medemcetakarit1debraanim onlayer elotte
    hide medemcetakarit1mamaanim onlayer elotte
    hide medemcetakarit1ferd onlayer elotte
    hide medemcetakarit2 onlayer elotte
    hide medemcetakarit3 onlayer elotte
    hide medemcetakarit3cseppek onlayer elotte
    hide debrafelengedanim onlayer kozep4
    hide debrakertje2mamanapozikanim onlayer kozep
    hide debrafelengedpinup onlayer elotte
    hide mamanapozik9reszpinap onlayer elotte
    hide mamanapozik9reszpinapszaj1 onlayer elotte
    hide mamanapozik9reszpinapszajanim onlayer elotte
    hide fredundor onlayer elotte
    hide mamanapozik9reszmozalap onlayer elotte
    hide mamanapozik9reszseganim onlayer elotte
    hide mamanapozik9reszfejmoz1 onlayer elotte2
    hide mamanapozik9reszfejszajanim onlayer elotte2
    hide mamanapozik9reszfejanim1 onlayer elotte2
    hide mamanapozik9reszfejanim2 onlayer elotte2
    hide mamanapozik9reszseganimferdbeszel onlayer elotte
    hide mamanapozik9reszsegmoz1 onlayer elotte2
    hide dagi540allas1
    hide puffypoz1
    hide utcaihazakritahattal
    hide ritabeszedfestekes
    hide macskaszalad
    hide macska-10
    hide macska-11
    hide macskatalhalas
    hide macska-10 onlayer kozep
    hide macskaszalad onlayer kozep
    hide macska-10 onlayer hatso2
    hide macskaszalad onlayer hatso2
    if hanyadiknapvan == 9:
        $ macskaelszaladt = False
    hide lizahazakozelibeszedhez
    hide macskatalkutyakajas
    hide macskatalkutyakajas onlayer hatso2
    hide boltokhaterepuli
    hide boltokhaterepulieszik
    hide boltokhaterepulikutyakaja
    hide boltokhaterepulitej
    hide macskataltejes onlayer hatso2
    hide terkeptemeto
    hide annaatonal2kampo onlayer elotte
    hide annaatonal1 onlayer elotte
    hide annaatonal2 onlayer elotte
    hide annaatonalajultmegjelenik onlayer elotte
    hide annaatonalhaterben onlayer hatso3
    hide annaatonalajultszemmoz onlayer elotte
    hide annaatonalajultcsombfogdosasanim onlayer elotte
    hide annaatonalajultpinadorzianim onlayer elotte
    hide annaatonalajultcicitapianim onlayer elotte
    hide annaatonalajultcicitapianim2 onlayer elotte
    hide annaatonalajultszemkinyit onlayer elotte
    hide annaatonalajultszajanim onlayer elotte
    hide annaatonalajultszem8 onlayer elotte
    hide annaatonalajultalap onlayer elotte
    hide annaatonalajultmelle onlayer elotte
    hide annaatonalajultszaj2 onlayer elotte
    hide fredperverz onlayer elotte
    hide annaatonal2szem2 onlayer elotte
    hide annalabaverzikanim onlayer elotte
    hide annalabaverzikanim2 onlayer elotte
    hide debrakertjegiliszta
    hide parkgiliszta onlayer kozep
    hide csillogaskicsi3
    hide csillogaskicsi3 onlayer kozep
    hide csillogaskicsianim onlayer kozep
    hide annaatobananimseta
    hide kittylizaveszekszik9resz onlayer elotte
    hide parkbanliza onlayer hatso2
    hide nappalitvtaviranyito
    hide debramasztijelenet1megjeleno onlayer elotte
    hide debramasztijelenet1alap onlayer elotte
    hide debramasztijelenet1anim onlayer elotte
    hide debramasztijelenet1szemanim onlayer elotte
    hide debramasztijelenet1szajanim onlayer elotte
    hide debramasztijelenet6megjeleno onlayer elotte
    hide debramasztijelenet6alap onlayer elotte
    hide debramasztijelenet6anim onlayer elotte
    hide debramasztijelenet6szemanim onlayer elotte
    hide debramasztijelenet2megjeleno onlayer elotte
    hide debramasztijelenet2anim8 onlayer elotte
    hide debramasztijelenet2szaj1anim8 onlayer elotte
    hide debramasztijelenet2szem1anim8 onlayer elotte
    hide debramasztijelenet2anim10 onlayer elotte
    hide debramasztijelenet2szaj1anim10 onlayer elotte
    hide debramasztijelenet2szem1anim10 onlayer elotte
    hide debramasztijelenet2szaj2anim10 onlayer elotte
    hide debramasztijelenet2szem2anim10 onlayer elotte
    hide debramasztijelenet3alap onlayer elotte
    hide debramasztijelenet3remeg1 onlayer elotte
    hide debramasztijelenet3anim onlayer elotte
    hide debramasztijelenet3labelol onlayer elotte2
    hide debramasztijelenet3remeg onlayer elotte
    hide debramasztijelenet3animatall onlayer elotte
    hide debramasztijelenet3anim2 onlayer elotte
    hide debramasztijelenet4alap onlayer elotte
    hide debramasztijelenet4nyalkaanim onlayer elotte
    hide debramasztijelenet4szemanim onlayer elotte
    hide debramasztijelenet4szaj1 onlayer elotte
    hide debramasztijelenet4szajanim onlayer elotte
    hide debramasztijelenet3nyalkaanim onlayer elotte
    hide debramasztijelenet3megjelenik onlayer elotte
    hide fiupoz4arny
    hide fiupoz1arny
    hide fiupoz2arny
    hide bandialap540
    hide sanyialap540
    hide boboalap425
    hide banditopoganim
    hide fiupoz1szem2 onlayer elotte
    hide bobopoz1 onlayer elotte
    hide parkosjelenetanikafordoesferd onlayer elotte
    hide debrakert2kozelei onlayer elotte
    hide mamabikinibenpoz1 onlayer elotte
    hide fiupoz1sokkolt
    hide temetokozeli onlayer elotte
    hide svetlanapoz1 onlayer elotte
    hide svetlanapoz2 onlayer elotte
    hide fiupoz1sokkolt onlayer elotte
    hide debramasztijelenet4nyalka-1 onlayer elotte
    hide debramasztijelenet3nyalkaanim2 onlayer elotte
    hide debrapan9resz
    hide debraalvajar9reszvegjelenet2
label tiltzar10:
    hide terkepcukrazda
    hide parkalap
    hide etteremasztal1 onlayer hatso
    hide etteremfotel2 onlayer hatso
    hide etteremszekekk3 onlayer hatso2
    hide etteremszekekk4 onlayer hatso3
    hide etteremszekekk5 onlayer hatso3
    hide etteremszekekk6 onlayer kozep
    hide etteremszekekk7 onlayer kozep2
    hide etteremvirag8 onlayer kozep
    hide etteremvirag9 onlayer elotte
    hide etterembencetli onlayer hatso
    hide etterembencsoka onlayer hatso
    hide etterembenkendo onlayer kozep
    hide etterembenmenufuzet onlayer hatso
    hide etterembenmenufuzet2 onlayer kozep2
    hide etterembenmrpuli onlayer kozep2
    hide etterembenpohar onlayer hatso2
    hide etterembenrita onlayer hatso2
    hide etterembensoszoro onlayer hatso3
    hide etterembensoszoro2 onlayer hatso2
    hide etterembenzacsi onlayer hatso3
    hide etteremkozeli onlayer elotte
    hide mrpulipoz onlayer elotte
    hide mrpulipozsalja onlayer elotte
    hide fiupoz1sokkoltjobra onlayer elotte
    hide ritabeszed onlayer elotte
    hide etteremkozeli2 onlayer elotte
    hide etterembenbeszedlidiapuniferd onlayer elotte
    hide etterempult onlayer hatso
    hide ritaaparkban onlayer kozep
    hide pucernoaparkbananim onlayer hatso
    hide parktoszokenovisszahuzanim onlayer hatso
    hide ritafaszszopasjelenetf1megjeleno onlayer elotte2
    hide fagyiznakaparkbanferd1 onlayer elotte2
    hide fagyiznakaparkbanferd2 onlayer elotte2
    hide fagyiznakaparkbanferd3 onlayer elotte2
    hide fagyiznakaparkbanrita1 onlayer elotte
    hide fagyiznakaparkbanrita2 onlayer elotte
    hide fagyiznakaparkbanrita3 onlayer elotte
    hide fagyiznakaparkbanrita5 onlayer elotte
    hide fagyiznakaparkbanrita4 onlayer elotte
    hide fagyiznakaparkbanhatter onlayer elotte
    hide ritafaszszopasjelenetf1alap onlayer elotte
    hide ritafaszszopasjelenetf1fiu onlayer elotte
    hide ritafaszszopasjelenetf1ritaanim onlayer elotte
    hide ritafaszszopasjelenetf1fiulaba onlayer elotte2
    hide ritafaszszopasjelenetf1karfa onlayer elotte2
    hide ritafaszszopasjelenetf2kozeliszopasanim onlayer elotte2
    hide ritafaszszopasjelenetf3alap onlayer elotte2
    hide ritafaszszopasjelenetf3ritafejeanim onlayer elotte2
    hide ritafaszszopasjelenetf3ritafejeanim2 onlayer elotte2
    hide ritafaszszopasjelenet1megjeleno onlayer elotte2
    hide ritafaszszopasjelenet1alap onlayer elotte2
    hide ritafaszszopasjelenet1szemanim onlayer elotte2
    hide ritafaszszopasjelenet1szaj1 onlayer elotte2
    hide ritaesferdcsokja onlayer elotte2
    hide ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
    hide csovesfodo
    hide ritabaszjelenet10reszm1megjeleno onlayer elotte
    hide ritabaszjelenet10reszm1alap onlayer elotte
    hide ritabaszjelenet10reszm1szaj2 onlayer elotte
    hide ritabaszjelenet10reszm1szemanim onlayer elotte
    hide ritabaszjelenet10reszm1kezanim onlayer elotte
    hide ritabaszjelenet10reszm1kezanim2 onlayer elotte
    hide ritabaszjelenet10reszm1arny onlayer elotte2
    hide ritabaszjelenet10reszm1szajanim onlayer elotte
    hide ritabaszjelenet10reszm1kezmoz5 onlayer elotte
    hide ritabaszjelenet10reszm2alap onlayer elotte
    hide ritabaszjelenet10reszm2rita1 onlayer elotte
    hide ritabaszjelenet10reszm2rita1arny onlayer elotte2
    hide ritabaszjelenet10reszm2ritaszaj2 onlayer elotte
    hide ritabaszjelenet10reszm2ritaszemanim onlayer elotte
    hide ritabaszjelenet10reszm2fiumoz1 onlayer elotte3
    hide ritabaszjelenet10reszm2ritaszajanim onlayer elotte
    hide ritabaszjelenet10reszm5kihuzza1 onlayer elotte2
    hide ritabaszjelenet10reszm5kihuzza2 onlayer elotte2
    hide ritabaszjelenet10reszm4ritaanim1 onlayer elotte2
    hide ritabaszjelenet10reszm4ritaanim2 onlayer elotte2
    hide ritabaszjelenet10reszm4ritaanim3 onlayer elotte2
    hide ritabaszjelenet10reszm4ritaanim4 onlayer elotte2
    hide ritabaszjelenet10reszm4ritaranim onlayer elotte
    hide ritabaszjelenet10reszm4alap onlayer elotte
    hide ritabaszjelenet10reszm4ritar1 onlayer elotte
    hide ritabaszjelenet10reszm4ritaanim onlayer elotte2
    hide ritabaszjelenet10reszm4fiulabaanim onlayer elotte2
    hide ritabaszjelenet10reszm2ritaszemanim2 onlayer elotte
    hide ritabaszjelenet10reszm2ritaanim onlayer elotte
    hide ritabaszjelenet10reszm2rita7 onlayer elotte
    hide ritabaszjelenet10reszm2rita7szajanim onlayer elotte
    hide ritabaszjelenet10reszm2alap onlayer elotte
    hide ritaszexutan10reszn1 onlayer elotte
    hide ritabaszjelenet10reszm1kezanim onlayer elotte
    hide ritabaszjelenet10reszm1kezanim2 onlayer elotte
    hide ritabaszjelenet10reszm1kezanim3 onlayer elotte
    hide ritaszexutan10reszn6 onlayer elotte
    hide fateralap
    hide faterpislognapaliban
    hide debrapironkodik6reszv2 onlayer elotte
    hide debrapironkodik6resz onlayer elotte
    hide talaltlada9resz onlayer elotte6
    hide talaltlada9reszlakat onlayer elotte6
    hide talaltlada9reszbelurrolalap onlayer elotte6
    hide talaltlada9reszbelurrolkarkoto onlayer elotte6
    hide talaltlada9reszbelurrolkarkotoresz1 onlayer elotte6
    hide talaltlada9reszbelurrolkarkotoresz2 onlayer elotte6
    hide talaltlada9reszbelurrolkarkotoresz3 onlayer elotte6
    hide talaltlada9reszbelurrolkarkotoresz4 onlayer elotte6
    hide talaltlada9reszbelurrolkarkotoresz5 onlayer elotte6
    hide talaltlada9reszbelurrolkarkotoresz6 onlayer elotte6
    hide festekoldoazinvertoriban
    hide puffypoz1 onlayer elotte
    hide debraalvajar10resza1 onlayer elotte
    hide debraalvajar10resza2 onlayer elotte
    hide debraalvajar10resza3 onlayer elotte
    hide debraalvajar10resza4 onlayer elotte
    hide debraalvajar10resza5 onlayer elotte
    hide debraalvajar10resza6 onlayer elotte
    hide debraalvajar10resza7v1 onlayer elotte3
    hide debraalvajar10resza7v2 onlayer elotte3
    hide debraalvajar10resza8 onlayer elotte
    hide debraalvajar10resza9v1 onlayer elotte
    hide debraalvajar10resza10 onlayer elotte
    hide fiupoz1sokkolt onlayer elotte
    hide fiupoz1pir onlayer elotte2
    hide debraalvajar10resza9anim onlayer elotte
    hide fiupoz1arny onlayer elotte2
    hide debraalvajar10resza1csillog1 onlayer elotte
    hide debraalvajar10resza1csillog2 onlayer elotte
    hide debraalvajar10resza2csillog1 onlayer elotte
    hide debraalvajar10resza2csillog2 onlayer elotte
    hide debraagyonbeszel onlayer elotte
    hide debrapan10resz onlayer elotte
    hide debraazarjarobanazagyon
    hide temetolevagotrozsak onlayer hatso2
    hide csovesfodo onlayer hatso3
    hide fredbabybeszel10resz
    hide parktobokrokelol onlayer hatso3
    hide kutyasarga10reszanim onlayer hatso2
    hide mamaametszoollonal onlayer elotte
    hide toesannafekszik onlayer hatso3
label tiltzar11:
    hide svetlanatelefon onlayer elotte
    hide nyomortanyaalap
    hide nyomortanyabago1
    hide nyomortanyabago2
    hide nyomortanyabago3
    hide nyomortanyabago4
    hide nyomortanyabago5
    hide nyomortanyabago6
    hide nyomortanyabago7
    hide nyomortanyadoboz1
    hide nyomortanyadoboz2
    hide nyomortanyadoboz3
    hide nyomortanyakoszosruha
    hide nyomortanyamama
    hide nyomortanyakod onlayer elotte
    hide terkepnyomortanya
    hide terkepsvetlanahaza
    hide teremrita2 onlayer hatso
    hide oroszszotarazinvertoriban
    hide etteremeszkoz1 onlayer hatso2
    hide etteremeszkoz2 onlayer hatso2
    hide etteremeszkoz3 onlayer hatso3
    hide ferdpoz1szemlefelenez onlayer elotte
    hide rozsapoz1szem2 onlayer elotte
    hide rozsapoz1 onlayer elotte
    hide shopelotbeszedhater onlayer elotte
    hide nyomortanyaalapkozeli onlayer elotte
    hide editpoz1 onlayer elotte
    hide svetlanapoz1 onlayer elotte
    hide svetlanapoz2 onlayer elotte
    hide svetlanapoz1s2 onlayer elotte
    hide svetlanaeloter
    hide etteremalap
    hide lidiapoz1540
    hide svetlanaeloterdoboz1
    hide svetlanaeloterdoboz2
    hide svetlanaeloterdoboz3
    hide svetlanaelotermama
    hide amandakosztumben onlayer elotte
    hide amandapoz1 onlayer elotte
    hide lidia1080 onlayer hatso2
    hide amandakintiruha onlayer elotte
    hide amandakintiruha1080 onlayer hatso2
    hide lidiapoz1 onlayer elotte
    hide vazabanrozsakazinvertoriban onlayer hatso3
    hide amandakintiruha1080 onlayer hatso3
    hide lidia1080 onlayer hatso3
    hide nyomortanyaalapkozeli
    hide editpoz1
    hide ferdpoz1szemlefelenez
    hide ferdboriszruha
    hide ferdarcpirmelegtol
    hide svetlana11napjelenet0 onlayer elotte
    hide svetlana11napjelenet1 onlayer elotte
    hide svetlana11napjelenet2 onlayer elotte
    hide debraall
    hide letra
    hide letra onlayer kozep
    hide csacsi1 onlayer kozep
    hide csacsi2 onlayer kozep
    hide csacsigazdaja onlayer kozep
    hide csacsimotyo onlayer hatso3
    hide csacsikalap onlayer kozep
    hide csacsikalapjafoldon
    hide lidiapoztvalt1 onlayer elotte
    hide lidiapoztvalt2 onlayer elotte
    hide lizanappaliakozeli onlayer elotte
    hide cilipoz1 onlayer elotte
    hide anikamom onlayer elotte
    hide fiupoz1 onlayer elotte
    hide cilikozelibeszed1 onlayer elotte
    hide cilikozelibeszed2 onlayer elotte
    hide cilikozelibeszed3 onlayer elotte
    hide furdokozeli onlayer elotte
    hide sanyipoz1 onlayer elotte
    hide debrakosztumbenanimfel onlayer elotte
    hide debrakosztumbenanimle onlayer elotte
    hide debrakosztumbenmoz1pislog onlayer elotte
    hide debrakosztumbenmoz1beszed onlayer elotte
    hide debrakosztumbenmoz5beszed onlayer elotte
    hide fiupoz5 onlayer elotte
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime2 onlayer elotte
    hide debracicibaszi11napjelenet7anime onlayer elotte
    hide debracicibaszi11napjelenet5anim onlayer elotte
    hide debracicibaszi11napjelenet4anim onlayer elotte
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
    hide debracicibaszi11napjelenet9anim onlayer elotte
    hide debracicibaszi11napjelenet9szajanim onlayer elotte
    hide debracicibaszi11napjelenet8anim onlayer elotte
    hide debracicibaszi11napjelenet3anim onlayer elotte
    hide harmasbeszedpoz3ferd onlayer elotte
    hide debracicibaszi11napjelenet8moz13 onlayer elotte
    hide lidia2v1080 onlayer hatso3
    hide frednagybanelol onlayer elotte
    hide debramaszti11nap onlayer elotte
label tiltzar12:
    hide lakotombb
    hide lakotomb1emelet
    hide pilango animated
    hide pilango1 animated
    hide pilango2 animated
    hide pilango3 animated
    hide pilango4 animated
    hide pilango5 animated
    hide pilango6 animated
    hide pilango7 animated
    hide pilango8 animated
    hide naptar9
    hide naptar5
    hide naptar1
    hide kanaviz animated
    hide kana animated
    hide novekvovirag8 onlayer kozep
    hide novekvovirag8f onlayer kozep
    hide novekvovirag8k onlayer kozep
    hide novekvovirag8p onlayer kozep
    hide novekvovirag8s onlayer kozep
    hide szarazviragf animated onlayer kozep
    hide szarazviragff animated onlayer kozep
    hide szarazviragk animated onlayer kozep
    hide szarazviragp animated onlayer kozep
    hide szarazvirags animated onlayer kozep
    hide novekvovirag7s onlayer kozep
    hide novekvovirag7p onlayer kozep
    hide novekvovirag7k onlayer kozep
    hide novekvovirag7f onlayer kozep
    hide novekvovirag7ff onlayer kozep
    hide novekvoviragf4 animated onlayer kozep
    hide novekvoviragff4 animated onlayer kozep
    hide novekvoviragk4 animated onlayer kozep
    hide novekvoviragp4 animated onlayer kozep
    hide novekvovirags4 animated onlayer kozep
    hide novekvovirag5 onlayer kozep
    hide novekvovirag5f onlayer kozep
    hide novekvovirag5k onlayer kozep
    hide novekvovirag5p onlayer kozep
    hide novekvovirag5s onlayer kozep
    hide novekvoviragf3 animated onlayer kozep
    hide novekvoviragff3 animated onlayer kozep
    hide novekvoviragk3 animated onlayer kozep
    hide novekvoviragp3 animated onlayer kozep
    hide novekvovirags3 animated onlayer kozep
    hide novekvovirag3 onlayer kozep
    hide novekvovirag3f onlayer kozep
    hide novekvovirag3k onlayer kozep
    hide novekvovirag3p onlayer kozep
    hide novekvovirag3s onlayer kozep
    hide novekvoviragf2 animated onlayer kozep
    hide novekvoviragff2 animated onlayer kozep
    hide novekvoviragk2 animated onlayer kozep
    hide novekvoviragp2 animated onlayer kozep
    hide novekvovirags2 animated onlayer kozep
    hide novekvovirag1 onlayer kozep
    hide novekvovirag1f onlayer kozep
    hide novekvovirag1k onlayer kozep
    hide novekvovirag1p onlayer kozep
    hide novekvovirag1s onlayer kozep
    hide novekvoviragf animated onlayer kozep
    hide novekvoviragff animated onlayer kozep
    hide novekvoviragk animated onlayer kozep
    hide novekvoviragp animated onlayer kozep
    hide novekvovirags animated onlayer kozep
    hide szarazviragf2 animated onlayer kozep
    hide szarazviragff2 animated onlayer kozep
    hide szarazviragk2 animated onlayer kozep
    hide szarazviragp2 animated onlayer kozep
    hide szarazvirags2 animated onlayer kozep
    hide kana1
    hide ladafolyson onlayer hatso
    hide sabrina
    hide sabrinakozeliemelet1gyen onlayer elotte
    hide cilinappalia
    hide egyetemenritatanulmoz1
    hide egyetemenkittytanul
    hide egyetemenjoetanulanim onlayer hatso
    hide egyetemenritatanulanimfel
    hide egyetemenritatanulanimle
    hide egyetemtanar onlayer elotte
    hide sujzoklizalan
    hide lizanapaliboltelefonal onlayer elotte
    hide atjarohomajos onlayer elotte
    hide fredtelefonal onlayer elotte
    hide cilinappaliakozeli onlayer elotte
    hide ciliulnapaliban
    hide cilicsokolfred onlayer elotte
    hide cilikozelibeszedcilinapaliban1 onlayer elotte
    hide cilikozelibeszedcilinapaliban2 onlayer elotte
    hide cilikozelibeszedcilinapaliban3 onlayer elotte
    hide cilijelenetmoz1 onlayer elotte
    hide cilijelenetmoz2 onlayer elotte
    hide cilijelenetmoz3 onlayer elotte
    hide cilijelenetmoz4 onlayer elotte
    hide cilijelenetmoz5 onlayer elotte
    hide cilijelenetmoz6 onlayer elotte
    hide cilijelenetmoz7 onlayer elotte
    hide cilijelenetmoz8 onlayer elotte
    hide cilijelenetmoz9 onlayer elotte
    hide cilijelenetmoz10 onlayer elotte
    hide cilijelenetmoz11 onlayer elotte
    hide boboalap
    hide alfonzall540
    hide alfonzpoz1 onlayer elotte
    hide lizahazakozelibeszedhez onlayer elotte
    hide eszterall540
    hide eszterpan onlayer elotte
    hide shopelotbeszedhater onlayer elotte
    hide eszterpoz1 onlayer elotte
    hide ancikpoz2 onlayer elotte
    hide amandakosztumben540
    hide ancika2540
    hide etteremlidiaelolul onlayer kozep2
    hide mamalabal3r3540 onlayer kozep2
    hide mamapoz1r3 onlayer elotte
    hide mamapoz1r4 onlayer elotte
    hide mamapoz1r5 onlayer elotte
    hide fiupoz7 onlayer elotte
    hide fiupoz6 onlayer elotte
    hide fiupoz8 onlayer elotte
    hide asoaparkban onlayer hatso2
    hide fekete onlayer elotte
    hide mamakenocse
    hide beultetetviragazinvertoriban
    hide haznappalidebrabedol
    hide szemet2azinvertoriban
    hide kitty12napjelenet onlayer elotte
    hide svetlanapoz3 onlayer elotte
    hide svetlana1080poz2
    hide almaktalban
    hide borisznaploja
    hide fogasallo
    hide fogasallorajtaruha
    hide szakadtmedve
    hide szakadtmedvekulcsa
    hide boriszfotokeretben
    hide svetlanakereskozelianim onlayer elotte
    hide svetlanakereskozeliszemanim onlayer elotte
    hide svetlanakereskozeliszaj1 onlayer elotte
    hide felsurolfiu2
    hide svetlanakereskozelimoz1
    hide svetlanakerestavolianim
    hide svetlanakerestavoliszemanim
    hide svetlanakerestavolimoz1
    hide ritaszex12napjel1 onlayer elotte
    hide ritaszex12napjel2 onlayer elotte
    hide ritaszex12napjel3 onlayer elotte
    hide boltelotbeszeleszteresancika onlayer elotte
    hide hazalapdebrahatulrolsimogatmoz1 onlayer elotte
    hide hazalapdebrahatulrolbaszmoz1 onlayer elotte
    hide lidiav31080 onlayer hatso3
    hide polip1080 onlayer hatso3
    hide lidiapoz2giros onlayer elotte
    hide lidiapoz2polip onlayer elotte
    hide lidiapoz2 onlayer elotte
    hide adrianhater12napalap onlayer elotte2
    hide sipbarhatuljaalap
    hide sipbarhatuljabuzzy
    hide sipbarhatuljakorlat onlayer hatso
    hide sipbarhatuljaszemet onlayer hatso
    hide sipbarhatuljaeloter onlayer kozep
    hide sipbarkozeeli onlayer elotte
    hide buzzypoz1 onlayer elotte
    hide fiupoz1 onlayer elotte
    hide sipbarhatuljakorlatkozeli onlayer elotte2
    hide rozsa onlayer hatso2
    hide sipbarkozeeli2 onlayer elotte
    hide rozsapoz1 onlayer elotte
    hide fiupoz1 onlayer elotte
    hide boltokhatereeste

    $ csinalszvalamit = "semit"
    if hanyadiknapvan == 2:
        if mamakeresei >= 4:
            play music "audio/banyabolt.ogg" fadeout 1



    if wcremehetek == True:
        $ debraholcsinal == "Furdik"
    if holvagyok == "beoltozikfred11nap":
        jump beoltozikfred11napszov
    if holvagyok == "lakotombcilinapali":
        jump ciliszobaszov
    if holvagyok == "lakotomb1emelet":
        if zenenincsismetles == 10:
            jump lakotomb1emeletszov
        else:
            $ zenenincsismetles = 10
            play music "audio/stipbarkint.ogg" fadeout 1
        jump lakotomb1emeletszov
    if holvagyok == "nyomortanya":
        jump nyomortanyaszov
    if holvagyok == "svetlanahaza":
        if zenenincsismetles == 9:
            jump svetlanahazaszov
        else:
            $ zenenincsismetles = 9
            play music "audio/svetlanahazaalap.ogg" fadeout 1
        jump svetlanahazaszov
    if holvagyok == "cukrazda":
        if zenenincsismetles == 8:
            jump cukrazdaszov
        else:
            $ zenenincsismetles = 8
            play music "audio/cukrazda.ogg" fadeout 1
        jump cukrazdaszov
    if holvagyok == "parkpad":
        jump parkpadszov
    if holvagyok == "bebyeknel":
        jump bebyeknelszov
    if holvagyok == "temeto":
        jump temetoszov
    if holvagyok == "temetokapu":
        if zenenincsismetles == 7:
            jump temetokapuszov
        else:
            $ zenenincsismetles = 7
            play music "audio/temeto.ogg" fadeout 1
        jump temetokapuszov
    if holvagyok == "parkto":
        jump parktoszov
    if holvagyok == "park":
        if zenenincsismetles == 6:
            jump parkszov
        else:
            $ zenenincsismetles = 6
            play music "audio/park.ogg" fadeout 1
        jump parkszov
    if holvagyok == "debrakertje2":
        jump debrakertje2szov
    if holvagyok == "debrakertje":
        jump debrakertjeszov
    if holvagyok == "fajasokertfele":
        jump fajasokertfeleszov
    if holvagyok == "lizakertje":
        jump lizakertjeszov
    if holvagyok == "lizaatjaroja":
        jump lizaatjarojaszov
    if holvagyok == "lizafurdoje":
        jump lizafurdojeszov
    if holvagyok == "lizanapalia":
        if zenenincsismetles == 1:
            jump lizanapaliaszov
        else:
            $ zenenincsismetles = 1
            play music "audio/lizakertje.ogg" fadeout 1
        jump lizanapaliaszov
    if holvagyok == "stripbar":
        if hanyadiknapvan == 12:
            jump stripbarszov2
        jump stripbarszov
    if holvagyok == "tvnezek":
        jump tvnezosjelenetszov

    if holvagyok == "boltoknal":
        if zenenincsismetles == 2:
            jump bolttokszov
        else:
            $ zenenincsismetles = 2
            play music "audio/bolt.ogg" fadeout 1
        jump bolttokszov
    if holvagyok == "baloldaliszomszed":
        if zenenincsismetles == 3:
            jump baloldaliszomszedszov
        else:
            $ zenenincsismetles = 3
            play music "audio/hazakesrom.ogg" fadeout 1
        jump baloldaliszomszedszov
    if holvagyok == "jobboldaliszomszed":
        if zenenincsismetles == 3:
            jump jobboldaliszomszedszov
        else:
            $ zenenincsismetles = 3
            play music "audio/hazakesrom.ogg" fadeout 1
        jump jobboldaliszomszedszov
    if holvagyok == "tanterem":
        if zenenincsismetles == 4:
            jump tanteremszov
        else:
            $ zenenincsismetles = 4
            play music "audio/suli.ogg" fadeout 1
        $ invertorinejelenyenmeg = False
        jump tanteremszov
    if holvagyok == "terkep":
        $ terkeproljovet = True
        $ terkeproljovet2 = True
        $ terkeproljovet = True
        $ invertorinejelenyenmeg = True
        if zenenincsismetles == 5:
            jump terkepszov
        else:
            $ zenenincsismetles = 5
            play music "audio/iskolaesterkep.ogg" fadeout 1
        jump terkepszov
    if holvagyok == "napaliban":
        jump nappaliszov
    if holvagyok == "furdo":
        jump furdoszov
    if holvagyok == "atjaro":
        jump atjaroszov
    if holvagyok == "fojasoball":
        jump fojasoballszov
    if holvagyok == "fojasojobb":
        $ invertorinejelenyenmeg = False
        jump fojasojobbszov
    if holvagyok == "konyha":
        jump konyhaszov
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
