label engedejek:
    if kezd == False:
        show doboz:
            xalign 0.26
            yalign 0.8
        show debrapoz1
        show fiupoz1
        show screen invertori2
        show invertori onlayer elotte6:
            yalign 0.0
        $ kezd = True
        jump atjaroszov4

    if hanyadiknapvan == 2:
        if debraholcsinal == "furdo":
            hide screen leskelodes
    if holvagyok == "tanterem":
        show screen tanterem
    if holvagyok == "napaliban":
        show screen nappali
        if fekete == False:
            if hanyadiknapvan == 1:
                if agynemuhejen == False:
                    if debraholcsinal == "napaliban":
                        if debranapaliban == True:
                            $ debranapaliban = False
                        show debrasopor:
                            xpos 0.6
                            ypos 0.2
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
                    if debraholcsinal == "napaliban2":
                        if debranapaliban == True:
                            $ debranapaliban = False
                        show debraujsaggal:
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
                        show debrafotelpislog:
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
            if hanyadiknapvan == 2:
                if konyhafelmos == False:
                    if debraholcsinal == "napaliban2":
                        if debranapaliban == True:
                            $ debranapaliban = False
                        show debraujsaggal:
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
                        show debrafotelpislog:
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
                    if debraholcsinal == "napaliban3":
                        $ debranapaliban = False
                        show debratvnezalap:
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
                        show debratvnezpislog:
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
            if hanyadiknapvan == 5:
                if debraholcsinal == "napaliban3":
                    show debratvnezalap
                    show debratvnezpislog
    if holvagyok == "furdo":
        if hanyadiknapvan == 1:
            if fekete == False:
                if agynemuhejen == False:
                    if debraholcsinal == "furdo":
                        if debrafurdoban == True:
                            $ debrafurdoban = False
                        show debrasopor:
                            zoom 0.8
                            xalign 0.52
                            yalign 0.65
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
            if locsolokannafel == True:
                $ locsolokannaviz = 2
        if hanyadiknapvan == 2:
            if debraholcsinal == "furdo2":
                if debrafurdoban == True:
                    $ debrafurdoban = False
                show debrafelmos:
                    zoom 0.4
                    xpos 0.33
                    ypos 0.55
                    pause (debravalamitcsinalido)
                    alpha 1.0
                    linear 2.0 alpha 0.0
            if torloszivacsnalad == True:
                if szivacskoszoslett > 0:
                    play sound "audio/viz13.wav"
                $ szivacskoszoslett = 0
        if hanyadiknapvan >= 4:
            hide furdomosogep
            show furdomosogep onlayer elotte
        show screen furdo
    if holvagyok == "atjaro":
        if atjarosecialisengedej == 0:
            show screen atjaro
            show screen poszterekgomjai
            show screen poszterekkepei
            show screen atjaroszov
            if szenyesafoldon == True:
                show screen szennyesfoldon
            if szobakipakolas == False:
                show screen kipakolandodoboz
            if fifiholcsinal == "atjaro":
                show screen fifiboritekpiszkal
                $ fifiatjaroban = False
                hide fififelfeleszagol
                hide fififelfeleszagolpislog
                show fififelfeleszagol:
                    zoom 0.6
                    xpos 0.46
                    ypos 0.66
                show fififelfeleszagolpislog:
                    zoom 0.6
                    xpos 0.46
                    ypos 0.66

        if atjarosecialisengedej == 1:
            show screen poszterekkepei
            show screen fifiboritekpiszkal
        if atjarosecialisengedej == 2:
            show screen atjarosecial
            show screen poszterekkepei
        if atjarosecialisengedej == 3:
            $ atjarosecialisengedej = 0
            show screen poszterekkepei
            show screen alvas
        if hanyadiknapvan == 6:
            if debraholcsinal == "atjaro":
                show debrahatta6resz onlayer screens
        if hanyadiknapvan == 8:
            if vegea8resznek == True:
                show screen alvas
        if hanyadiknapvan == 9:
            if debraholcsinal == "szobajaban":
                show screen alvas
    if holvagyok == "fojasoball":
        show screen fojasoball
        if fekete == False:
            if hanyadiknapvan == 1:
                if agynemuhejen == False:
                    if debraholcsinal == "fojasoball":
                        if debraballfoban == True:
                            $ debraballfoban = False
                        show debrasopor:
                            zoom 0.4
                            xalign 0.56
                            yalign 0.47
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
            if hanyadiknapvan == 2:
                if debraholcsinal == "fojasoball":
                    if debraballfoban == True:
                        $ debraballfoban = False
                    show debrasopor:
                        zoom 0.4
                        xalign 0.56
                        yalign 0.47
                        alpha 1.0
                        pause (debravalamitcsinalido)
                        alpha 1.0
                        linear 2.0 alpha 0.0
                if fifiholcsinal == "fojasoball":
                    $ fifiballfoban = False
                    show fifipisil:
                        zoom 0.6
                        xpos 0.5
                        ypos 0.6
                        alpha 1.0
                        pause (fificsinalido)
                        alpha 1.0
                        linear 2.0 alpha 0.0
                    show hugy:
                        alpha 0.0
                        pause (fificsinalido)
                        zoom 0.55
                        xpos 0.55
                        ypos 0.79
                        alpha 0.0
                        linear 2.0 alpha 1.0
    if holvagyok == "fojasojobb":
        show screen fojasojobb
        if fekete == False:
            if hanyadiknapvan == 1:
                if agynemuhejen == False:
                    if debraholcsinal == "fojasojobb":
                        if debrajobbfoban == True:
                            $ debrajobbfoban = False
                        show debrasopor:
                            xpos 0.5
                            ypos 0.3
                            alpha 1.0
                            pause (debravalamitcsinalido)
                            alpha 1.0
                            linear 2.0 alpha 0.0
            if hanyadiknapvan == 2:
                if debraholcsinal == "fojasojobb":
                    if debrajobbfoban == True:
                        $ debrajobbfoban = False
                    show debrasopor:
                        xpos 0.5
                        ypos 0.3
                        alpha 1.0
                        pause (debravalamitcsinalido)
                        alpha 1.0
                        linear 2.0 alpha 0.0
            if hanyadiknapvan == 6:
                $ debrajobbfoban = False
    if holvagyok == "fajasokertfele":
        show screen fajasokertfele
    if holvagyok == "debrakertje":
        show screen debrakertje
    if holvagyok == "debrakertje2":
        show screen debrakertje2
    if holvagyok == "konyha":
        show screen konyha
        if debraholcsinal == "konyha":
            $ debrakonyhaban = False
            show debrafoz:
                alpha 1.0
                pause (debravalamitcsinalido)
                alpha 1.0
                linear 2.0 alpha 0.0
    if holvagyok == "baloldaliszomszed":
        show screen baloldalisomszed
    if holvagyok == "lizanapalia":
        show screen lizanapalia
    if holvagyok == "lizafurdoje":
        show screen lizafurdoje
    if holvagyok == "lizaatjaroja":
        show screen lizaatjaroja
    if holvagyok == "lizakertje":
        show screen lizakertje
        if lizakertjekesz == 0:
            show screen lizakertjetiszta
    if holvagyok == "park":
        show screen park
    if holvagyok == "parkto":
        show screen parkto
    if holvagyok == "temetokapu":
        show screen temetokapu
    if holvagyok == "temeto":
        show screen temeto
    if holvagyok == "parkpad":
        show screen parkpad
    if holvagyok == "cukrazda":
        show screen cukrazda
    if holvagyok == "boltoknal":
        show screen bolt
    if holvagyok == "nyomortanya":
        show screen nyomortanya
    if holvagyok == "svetlanahaza":
        show screen svetlanahaza
    if holvagyok == "lakotomb1emelet":
        show screen lakotomb1emelet
    if holvagyok == "lakotombcilinapali":
        show screen ciliszoba
    if holvagyok == "stripbar":
        show screen stripbar

    if fekete == True:
        show invertori onlayer elotte6:
            yalign 0.0
    if fekete == False:
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
    hide fekete onlayer screens
    hide fekete onlayer over_screens
    $ fekete = False

    hide nyilafojason
    if hanyadiknapvan == 1:
        if wcremehetek == False:
            show screen debramitcsinaljon
    if hanyadiknapvan == 2:
        show screen debramitcsinaljon
        if boritekazinvertoriba == True:
            if boritekmizeriamegoldva == False:
                $ debraholcsinal = "napaliban3"
            if boritekmizeriamegoldva == True:
                hide screen debramitcsinaljon
                $ debraholcsinal = "konyha2"
        if csengettek == False:
            show screen tvvisszakerul
        if fifitletettem == True:
            show screen fifimozog
        if csengettek == True:
            if tvhoztak == False:
                show screen megintcsengetnek
        show screen fifiodapisilt
        show screen reszkezelo
    if hanyadiknapvan == 3:
        $ fifitfelvetem = False
    if hanyadiknapvan == 4:
        if debraholcsinal == "konyhaeszik":
            show screen debramitcsinaljon
    if hanyadiknapvan == 6:
        if debraholcsinal == "napalikusztum":
            $ debraeddigmozgott = True

    hide screen invertori2
    if invertorialapjelenyenmeg == True:
        show invertori onlayer elotte6:
            yalign 0.0
    $ invertorialapjelenyenmeg = False
    if invertorijelenyenmeg == True:
        show screen invertori
        show screen invertoriszov
        show screen estkezelo
    $ invertorijelenyenmeg = True
    if mozsarnalad == 0:
        show screen ujraszamolinvertori
    hide screen mutat
































































$ renpy. pause(hard=True)
$ renpy. pause(hard=True)
$ renpy. pause(hard=True)
$ renpy. pause(hard=True)

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
