label szuloszoba:

    hide screen fojasoball
    if hanyadiknapvan == 9:
        if debraholcsinal == "szobajabanmaszturbal9resz":
            f "I should look through the keyhole first. Maybe she is sleeping already…"
            hide screen invertori
            hide screen invertori2
            hide invertori onlayer elotte6
            play music "audio/szexy.ogg" fadeout 1
            show debramasztijelenet1megjeleno onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide debramasztijelenet1megjeleno onlayer elotte
            show debramasztijelenet1alap onlayer elotte
            show debramasztijelenet1anim onlayer elotte
            show debramasztijelenet1szemanim onlayer elotte
            show debramasztijelenet1szajanim onlayer elotte
            show screen s2
            u ""
            fg "What a luck! I am happy I did not disturb her."
            u ""
            show debramasztijelenet6megjeleno onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide debramasztijelenet6megjeleno onlayer elotte
            show debramasztijelenet6alap onlayer elotte
            show debramasztijelenet6anim onlayer elotte
            show debramasztijelenet6szemanim onlayer elotte
            show screen s1
            u ""
            dg "It was so long ago I felt something in my pussy…"
            f "I am glad I can watch this…"
            show screen s3
            u ""
            dg "I am so lonely and abandoned. I have a reason for what happened last time."
            show screen s4
            u ""
            dg "I can feel the taste of the semen still. I am ashamed but it felt so good…"
            u ""
            show debramasztijelenet2megjeleno onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide debramasztijelenet2megjeleno onlayer elotte
            show debramasztijelenet2anim8 onlayer elotte
            show debramasztijelenet2szaj1anim8 onlayer elotte
            show debramasztijelenet2szem1anim8 onlayer elotte
            show screen s1
            u ""
            f "That bich! She is fingering herself! I am hard as rock!"
            dg "I want a penis in my pussy… I need it so much! I miss it…"
            show screen s3
            u ""
            dg "Fred slipped and fell on me in the kitchen a few days ago. He rubbed his penis on my pussy... it felt great..."
            show screen s2
            u ""
            dg "He made it in the bathroom as well. I noticed… He finds me sexy... A young man..."
            show screen s3
            u ""
            dg "Oh no! How can I think of him now? I am married…"
            u ""
            hide debramasztijelenet1megjeleno onlayer elotte
            hide debramasztijelenet1alap onlayer elotte
            hide debramasztijelenet1anim onlayer elotte
            hide debramasztijelenet1szemanim onlayer elotte
            hide debramasztijelenet1szajanim onlayer elotte
            hide debramasztijelenet6megjeleno onlayer elotte
            hide debramasztijelenet6alap onlayer elotte
            hide debramasztijelenet6anim onlayer elotte
            hide debramasztijelenet6szemanim onlayer elotte
            hide debramasztijelenet2megjeleno onlayer elotte
            hide debramasztijelenet2anim8 onlayer elotte
            hide debramasztijelenet2szaj1anim8 onlayer elotte
            hide debramasztijelenet2szem1anim8 onlayer elotte
            show debramasztijelenet2anim10 onlayer elotte
            show debramasztijelenet2szaj1anim10 onlayer elotte
            show debramasztijelenet2szem1anim10 onlayer elotte
            dg "Oh, if I could call him in my room now… we could have sex all night long… Hm…"
            show screen s2
            u ""
            dg "My husband doesn't love me anymore. We do not live together..."
            show screen s3
            u ""
            dg "Just the thinking of cheating Bertalan makes me horny… I am bad… because..."
            u ""
            hide debramasztijelenet2szaj1anim10 onlayer elotte
            hide debramasztijelenet2szem1anim10 onlayer elotte
            hide debramasztijelenet2anim10 onlayer elotte
            show debramasztijelenet2anim10 onlayer elotte
            show debramasztijelenet2szaj2anim10 onlayer elotte
            show debramasztijelenet2szem2anim10 onlayer elotte
            show screen s3
            u ""
            dg "I am so horny... It will be good..."
            show screen s2
            u ""
            show debramasztijelenet3megjelenik onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide debramasztijelenet2anim10 onlayer elotte
            hide debramasztijelenet2szaj2anim10 onlayer elotte
            hide debramasztijelenet2szem2anim10 onlayer elotte
            show debramasztijelenet3alap onlayer elotte
            show debramasztijelenet3remeg1 onlayer elotte
            show debramasztijelenet3anim onlayer elotte
            show debramasztijelenet3labelol onlayer elotte2
            show screen s2
            u ""
            dg "Oh I wish someone would touch me… I am going to cum!!! AGGGH!!! Freeed!!!"
            show screen s3
            u ""
            f "Rub your fingers on your pussy! I am going to cum!"
            u ""
            hide debramasztijelenet3remeg1 onlayer elotte
            show debramasztijelenet3remeg onlayer elotte
            hide debramasztijelenet3anim onlayer elotte
            show debramasztijelenet3animatall onlayer elotte
            d "Oh, I am cummining!"
            show screen s1e8
            u ""
            hide debramasztijelenet3animatall onlayer elotte
            show debramasztijelenet3anim2 onlayer elotte
            show debramasztijelenet3nyalkaanim onlayer elotte
            show screen s1
            u ""
            hide debramasztijelenet3nyalkaanim onlayer elotte
            show debramasztijelenet3nyalkaanim2 onlayer elotte
            u ""
            hide debramasztijelenet3labelol onlayer elotte2
            show debramasztijelenet4alap onlayer elotte
            show debramasztijelenet4szemanim onlayer elotte
            show debramasztijelenet4szaj1 onlayer elotte
            show debramasztijelenet4nyalka-1 onlayer elotte
            show screen s05
            u ""
            hide debramasztijelenet4nyalka-1 onlayer elotte
            show debramasztijelenet4nyalkaanim onlayer elotte
            show screen s2
            u ""
            u ""
            dg "That felt good, but enough of this nonsense! I am married and I can not cheat on my husband…"
            dg "Now I feel much better."
            hide debramasztijelenet4szaj1 onlayer elotte
            show debramasztijelenet4szajanim onlayer elotte
            d "I will sleep like a baby after this."
            show debramasztijelenet4szaj1 onlayer elotte
            hide debramasztijelenet4szajanim onlayer elotte
            u ""
            f "Good for you Debra! Now i can not sleep well. I cam but I want to put my penis in you… you biths…. aghh!"
            $ debraholcsinal = "szobajaban"
            $ invertorinejelenyenmeg = True
            $ invertorialapjelenyenmeg = True
            play music "audio/banyabolt.ogg" fadeout 1
            jump fojasoball
            $ renpy. pause(hard=True)
        if debraholcsinal == "szobajaban":
            f "Debra sleeps inside."
            show screen fojasoball
        jump szuloszoba9resz

        $ renpy. pause(hard=True)

    label szuloszoba9resz:
    if debraholcsinal == "sulosoba":
        f "Debra is sleeping."
        show screen fojasoball
        $ renpy. pause(hard=True)
    f "This is the bedroom of Debra, I can not go in."
    show screen fojasoball

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
