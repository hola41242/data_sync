label fajasokertfele:
    if hanyadiknapvan < 7:
        hide screen fojasojobb
        f "Debra’s daughter's room. She is not home. I can not enter her room."
        show screen fojasojobb
    if hanyadiknapvan >= 7:
        if fojasokertfelemehtesz == False:
            hide screen fojasojobb
            f "Debra’s daughter's room. She is not home. I can not enter her room."
            show screen fojasojobb
            $ renpy. pause(hard=True)
        $ holvagyok = "fajasokertfele"
        jump tiltasok
$ renpy. pause(hard=True)
label fajasokertfeleszov:
    show fajasokertfele
    if hanyadiknapvan == 7:
        if debraholcsinal == "viragcsereprekermeg":
            show debraalappoz2v2:
                xzoom -1.0
                zoom 0.8
                xpos 0.52
                ypos 0.2
            show viragcserepazinvertoriban:
                xpos 0.58
                ypos 0.8
            jump debramegker7nap
        if debraviragcserepe == 0:
            show viragcserepazinvertoriban:
                xpos 0.58
                ypos 0.8
    if hanyadiknapvan == 12:
        if viragcserepnalad2 == 2:
            show beultetetviragazinvertoriban:
                xpos 0.65
                ypos 0.8
    jump engedejek



$ renpy. pause(hard=True)
label debramegker7nap:
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    $ fekete = True
    show screen s1
    u ""
    show fajasokertfelekozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraalappoz2v2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz9:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    d "Fred. Take the flowerpot and put it in the garden. Thank you!Asshole!I have to find my book."
    f "What kind of book?"
    d "This is not your business! Move!"
    f "Ok…"
    $ debraholcsinal = "dolgozo"
    show fajasokertfelekozeli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz9:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    jump engedejek
$ renpy. pause(hard=True)
label viragcserepfel:
    $ debraviragcserepe = 1
    show viragcserepazinvertoriban:
        xpos 0.58
        ypos 0.8
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label viragcserepbeultetett:
    hide screen fajasokertfele
    f "Planted flower pot."
    show screen fajasokertfele
$ renpy. pause(hard=True)
label viragcserepledebrakertjefele:
    $ amandaholvan = "sehol"
    $ setalodagatnoholvan = "sehol"
    $ lidiaraer12nap = True
    $ adrianaholvan = "parkban"
    $ debraholcsinal = "taviranyitotkeres"
    $ svetlanajelenet12nap = 1
    $ svetlanajelenet12nap = 1
    $ kittyszemetetfelveheted = True
    $ ritaszex12nap = 1
    $ viragcserepnalad2 = 2
    $ debrafeladatotad12nap = 2
    $ nyomortanyadoboz1nalad = 3
    $ nyomortanyadoboz2nalad = 3
    show beultetetviragazinvertoriban:
        xpos 0.65
        ypos 0.8
        alpha 0.0
        linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
