label lomosszoba:
    hide screen fojasojobb
    if hanyadiknapvan == 11:
        if debra11napfeladatotad == 1:
            if izzoknalad == 0:
                $ izzotkiveszido = 5
                $ izzotkiveszelteltido = 0
                show screen izzotkivetel
                show screen s3
                f "The bulbs must be here somewhere, but where?..."
                show screen s3
                u ""
                hide invertori onlayer elotte6
                hide screen invertori
                hide screen invertori2
                show mamacicikiesik1 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1e5
                u ""
                show mamacicikiesik1szajanim onlayer elotte
                m "Freddy! We need money! Grandma is in big trouble! I sold everything. I sold my necklace. Puffy gave it back to me today..."
                m "Grandma has no money to buy new dresses. I have to pay the loan shark tomorrow."
                hide mamacicikiesik1szajanim onlayer elotte
                f "Why are you holding your hands like that?"
                show mamacicikiesik1szajanim onlayer elotte
                m "Because those dirty things fall out every time I do not hold the dress. Like this!"
                hide mamacicikiesik1szajanim onlayer elotte
                show screen s1
                u ""
                hide mamacicikiesik1 onlayer elotte
                show mamacicikiesikanim onlayer elotte
                show screen s1e5
                u ""
                f "Oh Grandma! I did not ask for any demonsttation…"
                show mamacicikiesik7szajanim onlayer elotte
                m "But Fredd! I have to thank you so much! You sent more young men to me today..."
                hide mamacicikiesik7szajanim onlayer elotte
                f "What?"
                show mamacicikiesik7szajanim onlayer elotte
                m "You sent Puffy to me in the morning and later the handsome factotum visited me…"
                hide mamacicikiesik7szajanim onlayer elotte
                f "I did not send Alexander to you. He had to repair the drying machine."
                show mamacicikiesik7szajanim onlayer elotte
                m "Never mind! Grandma felt good!!"
                hide mamacicikiesik7szajanim onlayer elotte
                f "Could you please put your boobs back in the dress?"
                show mamacicikiesik7szajanim onlayer elotte
                m "Let them hang around. Would you like to play with them?"
                hide mamacicikiesik7szajanim onlayer elotte
                f "I think NOT!"
                show mamacicikiesik7szajanim onlayer elotte
                m "Who cares. Grandma had her fun today… "
                hide mamacicikiesik7szajanim onlayer elotte
                hide mamacicikiesikanim onlayer elotte
                show mamacicikiesik7 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1e5
                u ""
                show invertori onlayer elotte6:
                    ypos 0.0
                show screen invertori
                show screen fojasojobb
                show screen invertoriszov
                $ renpy. pause(hard=True)
        if debra11napfeladatotad == 2:
            if letranalad == 1:
                hide screen fojasojobb
                $ letranalad = 2
                $ cottonkell11nap = 1
                f "I am lucky! She did not notice that I came…"
                f "I should put something on my penis. I should not shoot my semen everywhere, I might get in big trouble …"
                f "Oh shit! Now I remember! The condom!! I totally forgot!"
                f "I have to put the condom back in the emergency box next to the graveyard gate."




                show screen fojasojobb

                $ renpy. pause(hard=True)
    if hanyadiknapvan == 10:
        if sirrozashezkell == True:
            if metszoollonalad == 0:
                $ metszoollokiveszido = 5
                $ metszoollokiveszelteltido = 0
                show screen metszoollokivetel
                show screen s3
                f "I pick up the secateurs. I put it here yesterday."
                show screen s3
                u ""
                hide invertori onlayer elotte6
                hide screen invertori
                hide screen invertori2
                show mamaametszoollonal onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1e5
                u ""
                m "Are you searching for Grandma in the storage room?"
                f "No… I am searching for the secateurs."
                m "Investigate me! Maybe I hid the secateurs somewhere…"
                f "Oh, I found it already. I have to go now. I have a lot to do..."
                m "What a shame. Maybe next time Freddy…"
                show mamaametszoollonal onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1e5
                u ""
                show invertori onlayer elotte6:
                    ypos 0.0
                show screen invertori
                show screen fojasojobb
                show screen invertoriszov
                $ renpy. pause(hard=True)
    if hanyadiknapvan == 9:
        if pecabotkell == True:
            if metszoollonalad == 0:
                if metszoollofelveheted == True:
                    $ metszoollokiveszido = 5
                    $ metszoollokiveszelteltido = 0
                    show screen metszoollokivetel
                    show screen s3
                    f "I pick up the secateurs. I put it here yesterday."
                    show screen s3
                    u ""
                    show screen fojasojobb
                    $ renpy. pause(hard=True)
    if hanyadiknapvan == 8:
        if gerebjekell8resz == True:
            if gerebjenalad == 0:
                show screen gerebjekivetel
                show screen s3
                f "I pick up the rake. I put it here yesterday."
                show screen s3
                u ""
                show screen fojasojobb
                $ renpy. pause(hard=True)
        if debrautasit8reszkertben == True:
            if debrakertje2bokorgaz == 1:
                if metszoollonalad == 0:
                    show screen metszoollokivetel
                    show screen s3
                    f "I pick up the secateurs. I put it here yesterday."
                    show screen s3
                    u ""
                    show screen fojasojobb
                    $ renpy. pause(hard=True)
    if hanyadiknapvan == 7:
        if metszoollo == 1:
            show screen metszoollo
            show screen s5
            u ""
            show mamalabal540:
                xpos 0.4
                ypos 0.3
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 1.0
            m "Freddy! Can I ask you something?"
            f "Of course but I would like to look around in the storage room first. I need a secateurs."
            m "Alright."
            $ renpy. pause(hard=True)
        if debrakertje2roszmadzag == 1:
            if madzagkerestemlomosszoba == 0:
                $ madzagkerestemlomosszoba = 1
                f "Maybe I can find some clothesline here."
                show screen madzagkereses
                $ renpy. pause(hard=True)
    if hanyadiknapvan == 6:
        if gerebjekell == 1:
            if gerebjenyel == 0:
                show screen invertori2
                hide screen invertori
                hide screen fojasojobb
                if gerebjefej == 0:
                    f "Maybe I can find a rake in the storage room..."
                if gerebjefej == 1:
                    f "Maybe I can find a rake handle in the storage room."
                show mamalabal540:
                    xpos 0.4
                    ypos 0.3
                    alpha 0.0
                    pause 5.0
                    linear 1.0 alpha 1.0
                show screen gerebjetkeres
                pause 5.0
                $ mamalatszik = True
                pause 2.0
                m "Where am I? I remember this house… let us see…"
                $ renpy. pause(hard=True)
        if feleslegesenkeres6resz == False:
            if lizakertjemadarhaza == 2:
                show screen invertori2
                hide screen invertori
                hide screen fojasojobb
                if csavar6resz == 0:
                    if csavarhuzo6resz == 0:
                        f "I search a bit to find some useful tools."
                        show screen feleslegesenkeres6resz
                        $ renpy. pause(hard=True)
                if csavar6resz == 0:
                    if csavarhuzo6resz == 1:
                        f "Let Us see. Maybe I can find here some srews…"
                        show screen feleslegesenkeres6resz
                        $ renpy. pause(hard=True)
                if csavarhuzo6resz == 0:
                    if csavar6resz == 1:
                        f "I should take a look. Maybe I can find a screwdriver here."
                        show screen feleslegesenkeres6resz
                        $ renpy. pause(hard=True)
                show screen invertori
                hide screen invertori2



        if porszivofelveni == 0:
            show screen invertori2
            hide screen invertori
            hide screen fojasojobb

            show debrahattallomolfojasojobbanim:
                alpha 0.0
                linear 1.0 alpha 1.0
            if debraholcsinal == "lomolgatfojasojobb":
                hide debrahattallomolfojasojobbanim
                show debrahattallomolfojasojobbanim
            $ debraholcsinal = "lomolgatfojasojobb"

            show screen porszivotkutatt
            $ porszivotkeres = True
            pause 3.0
            d "Oh fuck! I can not find it! It must be somewhere around…"
            $ renpy. pause(hard=True)
        if porszivofeladet == 2:
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 1.0
            $ porszivofelveni = 2
            $ porszivofeladet = 3
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            hide fekete onlayer screens
            show screen fojasojobb
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 5:
        if felmosotvenni == 2:
            hide screen invertori
            hide screen invertori2
            $ felmosotvenni = 3
            hide invertori onlayer elotte6
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 1.0
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            hide fekete onlayer screens
            show screen invertori
            show invertori onlayer elotte6:
                yalign 0.0
            show screen fojasojobb
            $ renpy. pause(hard=True)
    f "A Storage room.The room for all the stuff we do not need regularry. I almost landed here as well."
    show screen fojasojobb
$ renpy. pause(hard=True)
label porszivokutattabahagy:
    $ porszivotkeres = False
    show screen invertori
    hide screen invertori2
    hide screen porszivotkutatt
    show screen fojasojobb
$ renpy. pause(hard=True)
label gerebjetkeresabahagy:
    if gerebjenyel == 1:
        if gerebjefej == 0:
            f "Oh man! I found a fine rake handle. I need a rake head now."
        if gerebjefej == 1:
            f "Super! I found a rake handle. I have a full rake now."
    if gerebjenyel == 1:
        if gerebjefej == 1:
            $ gerebjekell = 2
    show screen invertori
    hide screen invertori2
    hide screen gerebjetkeres
    show screen fojasojobb
    if mamalatszik == True:
        show mamalabal540:
            xpos 0.4
            ypos 0.3
            alpha 1.0
            linear 1.0 alpha 0.0
    $ mamalatszik = False
$ renpy. pause(hard=True)
label feleslegesenkeres6reszabahagy:
    if feleslegesenkeres6resz == True:
        f "I did not find anything useful."
    show screen invertori
    hide screen invertori2
    hide screen feleslegesenkeres6resz
    show screen fojasojobb

$ renpy. pause(hard=True)
label nemtalalmadzagot:
    f "I did not find any."
    show screen fojasojobb
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
