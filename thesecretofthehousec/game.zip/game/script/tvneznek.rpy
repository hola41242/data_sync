label tvnezosjelenet:
    if hanyadiknapvan == 3:
        d "The detective story starts now, let us watch it together!"
    $ holvagyok = "tvnezek"
    jump tiltasok

label tvnezosjelenetszov:
    play music "audio/film.ogg" fadeout 1
    if hanyadiknapvan == 3:
        hide screen invertori2
        hide invertori onlayer elotte6
    show szexjelenet1jelalap

    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    f "What is this serie?"
    show szexjelenet1jeldebranez
    d "The old guy with the balloon jacket. He walks around and asks the killer hundreds of questions..."
    show szexjelenet1jelfrednez1
    f "So this is the Malambo serie..."
    hide szexjelenet1jeldebranez
    d "Yeah, I always forget the name!"
    hide szexjelenet1jelfrednez1
    d "And, did you ask around?"
    show szexjelenet1jelfrednez2
    f "Not yet."
    hide szexjelenet1jelfrednez2
    f "Will Bertalan come home today?"
    show szexjelenet1jeldebranez
    d "I do not know. Sometimes he comes home.."
    hide szexjelenet1jeldebranez
    f "I would like to ask him, too. I hope he will come home soon."
    d "He will come home maybe tomorrow in the afternoon."
    show szexjelenet1jelfrednez1
    f "This part is cool. Here he…"
    show szexjelenet1jeldebranez
    d "Shut up! I want to see it! Do not tell!"
    hide szexjelenet1jeldebranez
    f "Ok. I am quiet!"
    if nyalokavetem == False:
        jump ugrik3resz2
    show screen kerdesnyaloka
    $ renpy. pause(hard=True)
label ferednemmegeszi3resz:
    $ nyalokatodaadtam = True
    show szexjelenet1jeldebranez
    show szexjelenet1jeldebranyal:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Thank you!"
    show nyalokazikdebra3resz:
        alpha 0.0
        linear 1.0 alpha 1.0
    u ""
    jump ugrik3resz
label feredmegeszi3resz:
    $ nyalokatodaadtam = True
    pause 1.0
    show szexjelenet1jelfrednyal:
        alpha 0.0
        linear 1.0 alpha 1.0
    show szexjelenet1jeldebranez
    pause 2.0
    d "Asshole!"
    hide szexjelenet1jeldebranez
    hide szexjelenet1jelfrednez1
    f "Why?"
    d "You could offer me the lollipop..."
    f "Sorry…"
    pause 2.0
    jump ugrik3resz2
label ugrik3resz:
    hide szexjelenet1jelalap
    show szexjelenet1jelalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
label ugrik3resz2:
    play music "audio/baszosalap.ogg" fadeout 1
    u ""
    show szexjelenet2jelalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show szexjelenet2jelfrednez1
    show screen s1
    u ""
    show szexjelenet3jelalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    f "She fell asleep..."
    show szexjelenet3jelfrednez2
    show screen s2
    u ""
    show fekvo3resz:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    f "Her panties are on the side."
    show fredverihater:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fredverinez:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    f "Gosh! I can see her pussy!"
    show szexjelenetkozeli onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Zzzzzz.... Zzzzz....."
    u ""
    show debranyulkal3reszanim8
    show szexjelenetkozeli onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    hide szexjelenet1jelalap
    hide szexjelenet1jeldebranez
    hide szexjelenet1jelfrednez1
    hide szexjelenet1jelfrednez2
    hide szexjelenet1jelfrednez1
    hide szexjelenet1jeldebranyal
    hide nyalokazikdebra3resz
    hide szexjelenet1jelfrednyal
    hide szexjelenet2jelalap
    hide szexjelenet2jelfrednez1
    hide szexjelenet3jelalap
    hide szexjelenet3jelfrednez2
    hide fekvo3resz
    hide fredverinez
    hide szexjelenetkozeli onlayer hatso
    u ""
    f "Is this serious? She is… touching herself!"
    hide fredverinez
    show fredveri
    hide debranyulkal3reszanim8
    show debranyulkal3reszanim8:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "I can not take this anymore, I need to fap!"
    show debraelveziamitcsinal3reszanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    u ""
    f "I am gonna cum!"
    show debranyulkal3reszanim12:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    u ""
    show gatyabaverifred3resz:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Oh boy! I came in my pants!I should go now!"
    hide debranyulkal3reszanim8
    hide debraelveziamitcsinal3reszanim
    hide fredveri
    hide debranyulkal3reszanim12
    show szexjelenet4jelalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show szexjelenet4jeldebra1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show szexjelenet4jelfred1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "Do not wake up! Do not wake up!"
    show szexjelenet4jeldebra1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show szexjelenet4jelfred1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show szexjelenet4jeldebra2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show szexjelenet4jelfred2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    d "What is it? Did the film end?"
    f "N... no... I just got tired and i need to go to the university tomorrow…. and..."
    d "Ok, I fell asleep, I should go to rest, too."
    play music "audio/banyabolt.ogg" fadeout 1
    jump atjaro



$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
