label tanterem:
    $ holvagyok = "tanterem"
    jump tiltasok
$ renpy. pause(hard=True)
label tanteremszov:
    show tanterem
    if hanyadiknapvan == 3:
        show sirosfiu3resz
    show teremdagi
    show teremfred
    if hanyadiknapvan == 3:
        show teremgyum1
        show teremkola1
        show teremanika1
        show teremjim2 onlayer hatso
        show teremrita onlayer hatso
    if hanyadiknapvan == 4:
        show teremgyum2
        show teremkola2
        show teremanika2 onlayer hatso2
        show teremkitty onlayer hatso
        show teremjim3 onlayer hatso
        show teremrita onlayer hatso3
    if hanyadiknapvan == 5:
        $ vanszedvicsed2 = 0
        $ uditosmagamhozveni = 2
        show sirosfiu3resz
        show teremgyum2
        show teremkola2
        show teremkitty onlayer hatso
        show teremanika2
        show teremjim2 onlayer hatso
        show teremrita onlayer hatso
        show konyhatanyerszendvics2 onlayer hatso:
            zoom 0.8
            xpos 0.34
            ypos 0.62
    if hanyadiknapvan == 7:
        show invertori onlayer elotte6:
            yalign 0.0
        show screen invertori2
        $ fekete = True
        show teremanika1 onlayer hatso2:
            alpha 0.0
            pause 10.0
            alpha 0.0
            linear 1.0 alpha 1.0
            pause 5.0
            alpha 1.0
            linear 1.0 alpha 0.0
            repeat
        show teremanika2 onlayer hatso2:
            pause 10.0
            alpha 1.0
            linear 1.0 alpha 0.0
            pause 5.0
            alpha 0.0
            linear 1.0 alpha 1.0
            repeat
        if kittyparkotenged == False:
            show teremkitty onlayer hatso
        show teremjim3 onlayer hatso
        show teremrita onlayer hatso3
        if dagivalbeszeltel7resz >= 2:
            hide teremdagi
            hide teremfred
    if hanyadiknapvan == 8:
        show invertori onlayer elotte6:
            yalign 0.0
        show screen invertori2
        $ fekete = True
        hide teremdagi
        hide teremfred
        if uditosmagamhozveni == 0:
            show teremgyum1:
                zoom 0.6
                xpos 0.4
                ypos 0.13
    if hanyadiknapvan >= 9:
        show invertori onlayer elotte6:
            yalign 0.0
        show screen invertori2
        hide teremdagi
        hide teremfred
        $ fekete = True
    if hanyadiknapvan == 10:
        show sirosfiu3resz
        if egyetemenvoltal10resz == 0:
            $ egyetemenvoltal10resz = 1
            show screen anikahogyall
            show teremdagi
            show teremfred
            show teremgyum2
            show teremkola2
            show teremanika1 onlayer hatso2:
                alpha 0.0
                pause 10.0
                alpha 0.0
                linear 1.0 alpha 1.0
                pause 5.0
                alpha 1.0
                linear 1.0 alpha 0.0
                repeat
            show teremanika2 onlayer hatso2:
                pause 10.0
                alpha 1.0
                linear 1.0 alpha 0.0
                pause 5.0
                alpha 0.0
                linear 1.0 alpha 1.0
                repeat
            show teremrita onlayer hatso3
            show konyhatanyerszendvics2 onlayer hatso:
                zoom 0.8
                xpos 0.34
                ypos 0.62
            jump tanterem10jelenet
    if hanyadiknapvan == 11:
        if oroszkonyvnalad == 0:
            show oroszszotarazinvertoriban:
                xalign 0.0
                ypos 0.63
        if egyetemenvoltal11resz == 0:
            $ egyetemenvoltal11resz = 1
            hide invertori onlayer elotte6
            hide screen invertori
            hide screen invertori2
            show teremdagi
            show teremfred
            show teremkitty onlayer hatso
            show teremjim3 onlayer hatso
            show teremrita2 onlayer hatso
            jump tanterem11jelenet
    if hanyadiknapvan == 12:
        $ oroszkonyvnalad = 0
        $ vanszedvicsed2 = 0
        $ uditosmagamhozveni = 2
        if oroszkonyvnalad == 0:
            show oroszszotarazinvertoriban:
                xalign 0.0
                ypos 0.63
        if egyetemenvoltal12resz == 0:
            jump tanterem12jelenet
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    if hanyadiknapvan == 3:
        if teremjelenetek == 0:
            $ teremjelenetek = 1
            $ resz3hazamegy = True
            jump teremjelenetek1
    if hanyadiknapvan == 4:
        if teremjelenetek == 0:
            $ teremjelenetek = 1
            $ resz3hazamegy = True
            jump teremjelenetek2
    if hanyadiknapvan == 5:
        if teremjelenetek == 0:
            $ regell5resz = False
            $ teremjelenetek = 1
            jump teremjelenetek3
    jump engedejek
$ renpy. pause(hard=True)
label teremjelenetek1:
    da "Do you want to have a swap?"
    f "Sorry, I didn't listen! What did you ask?"
    da "Do you want my Cola?"
    f "Sure, but do you like 100 percent juice? I have only that shit."
    da "I love it! I know you hate juice, that is why I ask!"
    f "I never saw you drink piss like this, but here you are!"
    da "I really love it! … Really! Really!"
    show teremkola1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremgyum1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremdagi:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremfred:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremdagiiszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremfrediszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    a "Rita! Your hair is fantastic! What shampoo do you use?"
    r "I do not know. I just take a bottle totally blind and put it on my hair."
    j "Your hair is the most beautiful thing I saw in my life! It smells like fresh flowers and flows with the wind…"
    a "You are sycophantic, but keep it coming!"
    j "You are so smart and your dresses…"
    a "Enough for now. I want to talk to my girlfriend."
    show teremanika1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremjim2 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    hide teremanika2
    show teremanika2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremjim1 onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    a "Did you see the house on Lime Street? The police told us it was suicide, but i think it was a murder!"
    j "What? I hearded it was only a suicide!"
    a "I heard someone hated that guy and killed him..."
    a "A neighbor saw a strange unknown person coming out of the house not long before the house blew up."
    a "But who knows, maybe the neighbor dreamed..."
    show teremdagiiszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremdagifullad:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremgyum2 onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    dag "This tastes like fucking snot! But Fred needs my support now!"
    show teremjim1 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremjim2 onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    r "This is getting exciting! Like a crimi!"
    show teremkola2 onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremfred:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremfrediszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremdagiiszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremdagifullad:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremgyum2 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    a "I do not like to spread rumors, you are the only one I tell this!"
    show teremkola2 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremfred:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremfrediszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    j "Yeah, because you are such a brave kind person and you have no negative attributions…"
    a "I know, I know, but tell it again!"
    j "I are a Goddess..."
    a "Yeah, and I can thank this only to myself!"
    show teremanika1:
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
        repeat
    show teremjim2 onlayer hatso:
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        repeat
    show teremanika2:
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 5.0
        alpha 0.0
        linear 1.0 alpha 1.0
        repeat
    show teremjim1 onlayer hatso:
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        repeat
    show teremkola2 onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremgyum2 onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremdagi:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremfred:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremdagiiszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremfrediszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "Puffy! Did you hear this?"
    da "Yes, I hear him, but i do not agree. She is only a sexy slut, nothing special."
    f "I didn't think of this part! But about that rumor!"
    da "No... I did not."
    f "They talked about a burned house, about suicude... they talked about murder!"
    da "This is strange. Burned house, suicude... This happened to your father, too!"
    f "You are clever Puffy! This is why you are my best friend! Yeah... it is strange!"
    da "Hey Fred! All our lessons ended, should we not go home now?"
    f "Yeah, we should go now!"
    show teremkola2 onlayer hatso:
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremgyum2 onlayer hatso:
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremdagi:
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremfred:
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremdagiiszik:
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremfrediszik:
        pause 5.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
    $ fekete = True
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    $ vanszedvicsed2 = 0
    $ uditosmagamhozveni = 2
    jump engedejek
$ renpy. pause(hard=True)
label teremjelenetek2:
    hide teremdagi
    hide teremfred
    hide teremdagiiszik
    hide teremfrediszik
    hide teremkola2
    hide teremgyum2
    show teremkola2 onlayer hatso:
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        repeat
    show teremgyum2 onlayer hatso:
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        repeat
    show teremdagi:
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        repeat
    show teremfred:
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        repeat
    show teremdagiiszik:
        alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        repeat
    show teremfrediszik:
        alpha 0.0
        pause 5.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        repeat
    j "Kitty! I know why they asked me to stay away!"
    k "Why?"
    j "Because they are talking about me. They say, I am cool!"
    k "Bullshit!"
    j "I am not surprised you can not believe this! I have such a charm!"
    k "In your dreams!"
    a "It was fantastic! The party! Peter..."
    r "Tell me more!"
    a "A lot of people came to the party. I missed you!"
    a "The music was loud. We swimmed in our panties. I could drink a lot a beer…"
    r "I feel so bad now... I wish i could go…"
    hide teremkola2 onlayer hatso
    hide teremgyum2 onlayer hatso
    hide teremdagi
    hide teremfred
    hide teremdagiiszik
    hide teremfrediszik
    show teremdagi
    show teremfred
    show teremkola2
    show teremgyum2
    da "Fred! I think Grandma loves me!"
    f "What?"
    da "She flirted with me yesterday, but she got afraid. I was too pushy..."
    f "I knew this! You are a Don Juan deep in your heart!"
    da "Do you not believe me?"
    f "I believe you. But.. you get red all time a girl tries to talk to you…"
    da "Puffy changed man! Puffy improved to be a real man yesterday!"
    f "Cool! Where is Mark?"
    da "Tamara had closed Mark in the cabinet. They had a fight again… She closed him so he can now follow."
    f "She won only 10 minutes to escape.. He knows how to get out of the closed cabinet already…"
    da "You are not up to date! 9 minute 28 seconds is the new record! I made a bet and I won 1000 Ft last week."
    f "What did you spend on this terrible big amount of money?"
    da "I wanted to win more and I bet again, how much time it cost him to reach to Tamara…And I lost it all..."
    f "You can never stop in time my Friend!"
    da "This is in my genetics man!"
    da "Ok, let us go now!"
    $ invertorinejelenyenmeg = True
    $ vanszedvicsed2 = 0
    $ uditosmagamhozveni = 2
    jump tanterembolki
$ renpy. pause(hard=True)
label teremjelenetek3:
    $ regell5resz = False
    $ debraholcsinal = "dolgozo"
    show teremanika1:
        alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
        repeat
    show teremanika2:
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 5.0
        alpha 0.0
        linear 1.0 alpha 1.0
        repeat
    show teremjim2 onlayer hatso:
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 20.0
        alpha 0.0
        linear 1.0 alpha 1.0
        repeat
    show teremjim1 onlayer hatso:
        alpha 0.0
        pause 10.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 10.0
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 10.0
        repeat
    show teremjim4 onlayer hatso:
        alpha 0.0
        pause 21.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 9.0
        alpha 1.0
        linear 1.0 alpha 0.0
        repeat
    da "I would like to say thank you again. Yesterday you saved my life Bro!"
    f "You are overreacting this."
    f "I talked to Zoli yesterday. He gave me some information and I think I am on the right track..."
    f "Tell me Puffy! Do you know any lame guys? A big guy?"
    da "Sure man!"
    f "Really? Is he humming?"
    da "You know the guy! I don't know if he is humming or not…"
    f "I know him? Who could this be?"
    da "Hephaistos! The God… you know…"
    f "Oh man! Do not joke around! I am searching for a real person! I do not search for any mythology characters!"
    da "Well... in this case I will pass! Ask around! Maybe someone can help you here in the classroom!"
    f "Ok. I will ask around."
    da "Ok, but hurry! I want to go home with you! I want to see Grandma!"
    show teremdagi:
        alpha 1.0
        linear 1.0 alpha 0.0
    hide teremgyum2
    show teremgyum2 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremdagiiszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "This won't work Buddy! She is not home."
    show teremgyum2 onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    show teremdagiiszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremdagifullad:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Are you ok? Should I help you?"
    show teremdagifullad:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremdagi:
        alpha 0.0
        linear 1.0 alpha 1.0
    da "No. I just feel bad now. I will miss my beauty..."
    f "Do not take it so seriously. If you want to cry, sit next to Mark."
    da "Nothing can help me. I am planning to go home and eat all the stuff from the fridge."
    f "Alright! I go and ask around before I head home."
    da "See Ya tomorrow!"
    show teremgyum2 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremdagi:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremfred:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "Bye!"
    show invertori onlayer elotte6:
        yalign 0.0
    show screen tanterem
    show screen invertori
    show screen invertoriszov
$ renpy. pause(hard=True)
label dagivalbeszed:
    hide screen tanterem
    if hanyadiknapvan <= 4:
        hide teremkola2 onlayer hatso
        hide teremgyum2 onlayer hatso
        hide teremdagi
        hide teremfred
        hide teremdagiiszik
        hide teremfrediszik
        show teremkola2 onlayer hatso:
            alpha 1.0
        show teremgyum2 onlayer hatso:
            alpha 1.0
        show teremdagi:
            alpha 1.0
        show teremfred:
            alpha 1.0
        hide teremdagiiszik
        hide teremfrediszik
        if dagivalbeszed == 2:
            $ dagivalbeszed = 0
        if dagivalbeszed == 1:
            $ dagivalbeszed = 2
            da "Now I remember Fred! I heard some rumors last week."
            f "What about?"
            da "I heard the maffia killed your father and you will be the next Shogun…"
            f "This is strange! What is this shogun thing?"
            da "I think a chinese boy band..but i really do not know!"
        if dagivalbeszed == 0:
            $ dagivalbeszed = 1
            da "And how do you like the new place?"
            f "The family is really nice to me. I can stay until I finish the university!"
            da "What is the name of the wife of Bertalan?"
            f "She is Debra. Why?"
            da "Some people say she is fat and a terrible monster!"
            f "I think she is not fat and that she does not act like a monster either!"
            f "I have a lot to do around the house but this is natural. I am only a guest."
        hide teremdagi
        hide teremfred
        hide teremdagiiszik
        hide teremfrediszik
        show teremkola2 onlayer hatso:
            pause 5.0
            alpha 1.0
            linear 1.0 alpha 0.0
            pause 10.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show teremgyum2 onlayer hatso:
            pause 10.0
            alpha 1.0
            linear 1.0 alpha 0.0
            pause 10.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show teremdagi:
            pause 10.0
            alpha 1.0
            linear 1.0 alpha 0.0
            pause 10.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show teremfred:
            pause 5.0
            alpha 1.0
            linear 1.0 alpha 0.0
            pause 10.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show teremdagiiszik:
            alpha 0.0
            pause 10.0
            alpha 0.0
            linear 1.0 alpha 1.0
            pause 10.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show teremfrediszik:
            alpha 0.0
            pause 5.0
            alpha 0.0
            linear 1.0 alpha 1.0
            pause 10.0
            alpha 1.0
            linear 1.0 alpha 0.0
    if hanyadiknapvan == 7:
        if penztkaszlizatol7resz == False:
            f "Where is Mark?"
            da "Who the hell knows? Maybe he chases her love again…"
            if szerezegymobilt == 1:
                $ dagivalbeszeltel7resz = 1
                f "Puffy! Can you lend me your phone for a few days?"
                da "I love you bro, but my mother will kill me if I do not answer the phone…"
                da "Do not worry! I know a cheap place. You can buy used mobile phones for no money!"
                f "I have no money. Grandma took it all away…"
                da "Bad for you. Tell me if you get some cash and I will help you to buy a phone. I am poor as well…"
                f "Thank you my friend! I will try to earn some money."
        if penztkaszlizatol7resz == True:
            if dagivalbeszeltel7resz == 0:
                f "Puffy! Can you lend me a mobile phone?"
                da "No, but I can get you one cheap."
            if szerezegymobilt == 1:
                $ dagivalbeszeltel7resz = 2
                $ szerezegymobilt = 2
                f "I have [penz]. Can you buy me a working phone?"
                da "For this amount? Well… you are really poor my friend."
                $ penz = 0
                da "Nah, give me the money. I will buy you the best phone I can!"
                f "Ok. I will wait here."
                show teremdagi:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s2
                u ""
                show teremdagi:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                pause 1.0
                f "Gosh! You are fast!"
                da "Yeah. I had limits to choose…"
                da "Anyway! I bought you this mobile phone."
                $ szerezegymobilt = 2
                $ mobil = True
                f "Wow, is it working?"
                da "Of course! There are some extras in it! You find a calculator in it. You can save 25 names in the list with numbers, and you get a calendar."
                da "And the best thing is: you got 200 Forint back!"
                $ penz += 200
                f "Super! What should I spend this on?"
                da "I know… I know… Just keep it man, you will need it!"
                f "Thank you! You are a lifesaver!"
                da "Tell me! How does my Diana feel today?"
                f "She feels ok. She got drunk and she has headache now, but she is fine."
                da "Great! I will visit her soon, but I need to find her a nice present."
                f "She will be happy for sure."
                f "When will you visit her?"
                da "I have to help out with housework. Mom will give me money and after that I should search for a job to get some more cash. I will try to visit you on the weekend."
                f "Ok, just push the doorbell or… call me on!"
                da "I better push the doorbell. Ringing you on the phone costs 27 Forint. I need to spare now."
                da "I have to go now. I have a lot to do. Bye!"
                f "Ok! See you soon!"
                show teremdagi:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show teremfred:
                    alpha 1.0
                    linear 1.0 alpha 0.0
    show screen tanterem
$ renpy. pause(hard=True)
label markvalbeszed:
    hide screen tanterem
    if hanyadiknapvan == 3:
        if markvalbeszed == 2:
            $ markvalbeszed = 0
        if markvalbeszed == 1:
            $ markvalbeszed = 2
            mk "She told me, she will never kiss me or talk to me again!"
            f "You will be together in the afternoon for sure..."
            mk "You do not understand! She leaved me! She hates me!"
        if markvalbeszed == 0:
            $ markvalbeszed = 1
            mk "She is gone forever!"
            f "They broke up again…"
            da "Yeah, last week they broke up 4 times. This is monday and this is the secound time! They will reach a new record this week I guess!"
    if hanyadiknapvan == 5:
        $ beszedmarkkal = 1
        show teremfred:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I am sorry for disturbing you during your big suffering project, but I have some questions."
        mk "No problem! Ask me anything! My life is over."
        f "Do you know a big lame guy?"
        mk "No, I do not."
        f "Thank you for your info!"
        mk "No problem! I'm going now. I want to visit my love. I will stay before her house and watch her. Maybe I can see her for a moment…"
        f "Have a nice time!"
        show teremfred:
            alpha 1.0
            linear 1.0 alpha 0.0
        show sirosfiu3resz:
            alpha 1.0
            linear 1.0 alpha 0.0
        if beszedmarkkal == 1:
            if beszedritakal == 1:
                if beszedanikakal == 1:
                    if beszedjimkal == 1:
                        if beszedkittykal == 1:
                            $ kerdezkorbe = True
    if hanyadiknapvan == 10:
        f "He is sleeping."
    show screen tanterem
$ renpy. pause(hard=True)
label anikavalbeszed:
    hide screen tanterem
    if hanyadiknapvan == 3:
        hide teremanika1
        hide teremjim2 onlayer hatso
        hide teremanika2
        hide teremjim1 onlayer hatso
        if anikavalbeszed == 2:
            $ anikavalbeszed = 0
        if anikavalbeszed == 1:
            $ anikavalbeszed = 2
            show teremanika2
            show teremjim1 onlayer hatso
            a "By the way. Can you take my bag home again? I need to meet Peter at the Horny lake today..."
            j "Of course my Princess!"
            a "Super, but tell my parents I learn at the library again!"
            show teremanika1:
                alpha 0.0
                linear 1.0 alpha 1.0
            show teremjim2 onlayer hatso:
                alpha 0.0
                linear 1.0 alpha 1.0
            show teremanika2:
                alpha 1.0
                linear 1.0 alpha 0.0
            show teremjim1 onlayer hatso:
                alpha 1.0
                linear 1.0 alpha 0.0
            r "The library is closed because of disinsection..."
            a "Who cares! They do not know this! Just lie them! That is all! In the face without blinking!"
            j "If you would like to read a book, my room is full with great books and..."
            a "You are so cute, maybe next time!"
            show teremanika1:
                pause 10.0
                alpha 0.0
                linear 1.0 alpha 1.0
                pause 5.0
                alpha 1.0
                linear 1.0 alpha 0.0
                repeat
            show teremjim2 onlayer hatso:
                pause 10.0
                alpha 1.0
                linear 1.0 alpha 0.0
                pause 10.0
                alpha 0.0
                linear 1.0 alpha 1.0
                repeat
            show teremanika2:
                pause 10.0
                alpha 1.0
                linear 1.0 alpha 0.0
                pause 5.0
                alpha 0.0
                linear 1.0 alpha 1.0
                repeat
            show teremjim1 onlayer hatso:
                pause 10.0
                alpha 0.0
                linear 1.0 alpha 1.0
                pause 10.0
                alpha 1.0
                linear 1.0 alpha 0.0
                repeat
        if anikavalbeszed == 0:
            $ anikavalbeszed = 1
            show teremanika2
            show teremjim1 onlayer hatso
            r " Did you see the last episode of the Enthusiastic hearts series?"
            a "Nope, I saw only the Fire and water film, starring my uncle and aunt."
            a "He drank a lot of alcohol and aunty yelled at him all night long..."
            j "Next time I will take my camera and we will record a film. You will be the actress…"
            a "Thank You for your offer. You are such a nice puppy!"
            show teremanika2:
                pause 10.0
                alpha 1.0
                linear 1.0 alpha 0.0
                pause 5.0
                alpha 0.0
                linear 1.0 alpha 1.0
                repeat
            show teremjim1 onlayer hatso:
                pause 10.0
                alpha 1.0
                linear 1.0 alpha 0.0
                pause 10.0
                alpha 0.0
                linear 1.0 alpha 1.0
                repeat
            show teremanika1:
                alpha 0.0
                pause 10.0
                alpha 0.0
                linear 1.0 alpha 1.0
                pause 5.0
                alpha 1.0
                linear 1.0 alpha 0.0
                repeat
            show teremjim2 onlayer hatso:
                alpha 0.0
                pause 10.0
                alpha 0.0
                linear 1.0 alpha 1.0
                pause 10.0
                alpha 1.0
                linear 1.0 alpha 0.0
                repeat
    if hanyadiknapvan == 5:
        $ beszedanikakal = 1
        $ santakolduszolieknal = 1
        show tanteremkozeli onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show anikaelolbeszed1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Anika! Can I ask you something?"
        a "Do not even bother. You are not my type!"
        f "What? No, I did not mean such a question..."
        a "I know... I know! Mark is following me, he is hiding and watching me. I know. Do not worry!"
        f "Just let me ask you my question, ok?"
        hide fiupoz1 onlayer kozep
        show fiupoz1szem2 onlayer kozep
        a "My breasts are natural! I did not have any surgery!"
        f "Thank you for your information! Do you know any big lame guys?"
        show fiupoz1szem2 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show anikaelolbeszed1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show anikaelolbeszed2 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        a "You have a strange taste!"
        show anikaelolbeszed2 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show anikaelolbeszed1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I search for a lame man, but not for sexual reasons..."
        a "Do you owe him money?"
        f "Not really!"
        a "I do not know any and I do not want to get to know any poor guys. Do not waste my time!"
        a "But I saw a homeless, lame man on our street yesterday..."
        show anikaelolbeszed1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        f "Thank You for your information!"
        show tanteremkozeli onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 0.0
        show fiupoz2 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        if beszedmarkkal == 1:
            if beszedritakal == 1:
                if beszedanikakal == 1:
                    if beszedjimkal == 1:
                        if beszedkittykal == 1:
                            $ kerdezkorbe = True
    if hanyadiknapvan == 7:
        if anikavalbeszed == 2:
            $ anikavalbeszed = 0
        if anikavalbeszed == 1:
            $ anikavalbeszed = 2
            a "Yesterday was wonderful!"
            r "Tell me more!"
            a "I never saw so many shining showcases in my life…"
            r "Were the prices low?"
            a "Are you kidding me? My mother could work for 4 months, but her payment wouldn't be enough for a single dress…"
        if anikavalbeszed == 0:
            $ anikavalbeszed = 1
            show tanteremkozeli onlayer kozep:
                alpha 0.0
                linear 1.0 alpha 1.0
            show anikaelolbeszed1 onlayer kozep:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1 onlayer kozep:
                alpha 0.0
                linear 1.0 alpha 1.0
            a "I am sorry Fred. I have no time for you! I am checking the new rumors now."
            f "Oh sorry…"
            show anikaelolbeszed1 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            show tanteremkozeli onlayer kozep:
                alpha 0.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
    show screen tanterem
$ renpy. pause(hard=True)
label ritavalbeszed:
    hide screen tanterem
    if hanyadiknapvan == 5:
        $ beszedritakal = 1
        show tanteremkozeli onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show ritabeszed onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Hello! Can I ask you something?"
        r "I hope your question is not about studying. If so, I can not help you."
        f "No… Do you know any lame, big guys?"
        r "Do you mean lame style guys?"
        f "No, lame like…his leg hurts, so he can not walk well."
        r "No, but my aunty has a wheelchair. Do you want to meet her?"
        f "Not really. Thank you for your help! I won't bother you anymore."
        r "You never bother me. You are so sweet! We could have a date sometime."
        f "Sure... I will call you."
        r "Ok, I won't forget."
        show tanteremkozeli onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show ritabeszed onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        if beszedmarkkal == 1:
            if beszedritakal == 1:
                if beszedanikakal == 1:
                    if beszedjimkal == 1:
                        if beszedkittykal == 1:
                            $ kerdezkorbe = True
    if hanyadiknapvan == 7:
        show tanteremkozeli onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show ritabeszed onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Hello Rita. Can I ask you something."
        r "Do you want to call me on a date?"
        f "No… I have no time for such things now. I will call you when I have enough money and freetime for a date, I swear."
        r "I have no money to lend you Fred. My Mobilephone broke and…"
        r "I sample money to buy a new one and…"
        f "Understand. Let us chat a bit later!"
        r "See ya!"
        show tanteremkozeli onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show ritabeszed onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
    show screen tanterem
$ renpy. pause(hard=True)
label jimvalbeszed:
    hide screen tanterem
    if hanyadiknapvan == 5:
        $ beszedjimkal = 1
        show tanteremkozeli onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show jimelolbeszed2 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        j "What do you want? I should go home to learn."
        hide teremjim2 onlayer hatso
        hide teremjim1 onlayer hatso
        hide teremjim4 onlayer hatso
        f "Do you know any lame, big guys?"
        show jimelolbeszed2 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show jimelolbeszed1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        j "Let me see. I search in memory."
        f "Take your time."
        j "Nothing found. I never met any."
        j "But I read a study about our city population. 0,4 percent of people use walkers. 0,6 percent of people have difficult to walk."
        f "Is it too much?"
        j "No, there are only a few people who limp in this city. You will have difficulties finding some."
        show jimelolbeszed2 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show jimelolbeszed1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        if beszedanikakal == 1:
            show fiupoz1 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz2 onlayer kozep:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Some people say, they saw a lame, big guy yestreday…"
            j "Are these people truthful?"
            j "What did they see yesterday? Did they see someone in the bushes?"
            f "You mean... YOU?"
            j "Well... I guess…"
            f "Agh… Noone saw you fapping in the bushes."
            show jimelolbeszed2 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            show jimelolbeszed1 onlayer kozep:
                alpha 0.0
                linear 1.0 alpha 1.0
            j "I am the master of concealment."
            show fiupoz2 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer kozep:
                alpha 0.0
                linear 1.0 alpha 1.0
        j "I should go now. Bye!"
        show jimelolbeszed2 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show jimelolbeszed1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Goodbye Jim!"
        show tanteremkozeli onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show jimelolbeszed1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        if beszedmarkkal == 1:
            if beszedritakal == 1:
                if beszedanikakal == 1:
                    if beszedjimkal == 1:
                        if beszedkittykal == 1:
                            $ kerdezkorbe = True
    if hanyadiknapvan == 7:
        show tanteremkozeli onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show jimelolbeszed2 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        if dagivalbeszeltel7resz < 2:
            j "What is up? Can you not see I am busy right now? I am watching the creatures of beautiful nature…"
            f "I can see… I won’t disturb you for a long time… Can you lend me a needless mobile phone?"
            j "I don't even own an unnecessary pencil. I have as many pieces of tools as I need."
            f "Ok, thank you!"
        if dagivalbeszeltel7resz >= 2:
            j "Do not disturb me! I am enjoying the view…"
        show tanteremkozeli onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show jimelolbeszed2 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
    show screen tanterem
$ renpy. pause(hard=True)
label kittyvalbeszed:
    hide screen tanterem
    if hanyadiknapvan == 5:
        $ beszedkittykal = 1
        $ boltosalbeszelni = 1
        $ barkacsboltosalbeszelni = 1
        show tanteremkozeli onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show kittyelolbeszed1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Can I ask you something?"
        hide teremkitty onlayer hatso
        k "Of course!"
        f "Do you know any lame, big guys in the city?"
        k "I cannot remember any. Why do you ask?"
        f "I heard a rumor of a lame guy. He is searching around my house every night."
        k "Oh yeah! Your father commited suicide last week and your home burned down. What a shame!"
        f "Yes, I am searching for that guy."
        k " Do you know what he looks like? What did he wear?What is his hair color? What is his skin color?"
        f "I know some information but I did not ask about his skin color… I do not know... where could I …"
        k "I understand. I advise you to ask around in the shops nearby."
        k "The sellers know a lot of people. Maybe they can tell you where he lives."
        f "A great idea! Thank you!"
        k "I have to go. Would you like to come with me?"
        if beszedmarkkal == 0:
            f "Sorry, I can not. I need ot ask around."
            jump beszedugrik5resz
        if beszedritakal == 0:
            f "Sorry, I can not. I need ot ask around."
            jump beszedugrik5resz
        if beszedanikakal == 0:
            f "Sorry, I can not. I need ot ask around."
            jump beszedugrik5resz
        f "Sure. I talked to everyone. Let us go!"
        $ kerdezkorbe = True
        jump terkep
        label beszedugrik5resz:
            k "I am off now!"
            f "Byebye!"
            show tanteremkozeli onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            show kittyelolbeszed1 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen tanterem
        if beszedmarkkal == 1:
            if beszedritakal == 1:
                if beszedanikakal == 1:
                    if beszedjimkal == 1:
                        if beszedkittykal == 1:
                            $ kerdezkorbe = True
    if hanyadiknapvan == 7:
        show tanteremkozeli onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show kittyelolbeszed1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        if pulinapozoagya == 0:
            f "Hello Kitty! Can I ask you a favor?"
            k "Let me know more about this favor first!"
            f "Can you lend me your mobile phone? Just for a few days!"
            k "I am sorry Fred! I can not lend you my phone. "
            f "Yeah, I understand."
        if pulinapozoagya == 1:
            $ kittyparkotenged = True
            f "Do you have a sewing kit?"
            k "Not realy…"
            f "Thank you for your answer! "
            k "Wait a minute! Now I remember. I usually find this kind of stuff in the park. "
            k "You know, I clean the park every week and people throw trash all around... Maybe we can find a sewing kit between the trash..."
            f "Where is the park?"
            k "The park is nearby. The labyrinths park..."
            f "Ah, now I remember!"
            k "Now i need to head in that way. Come and maybe we will find you something useful."
            f "Ok! Let's meet there!"
            hide teremkitty onlayer hatso
        show tanteremkozeli onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show kittyelolbeszed1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen tanterem
    show screen tanterem
$ renpy. pause(hard=True)
label csiposzenyo:
    $ csiposzenyo = 1
    hide screen tanterem
    hide screen invertori
    hide invertori onlayer elotte6
    show teremfred:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    f "I didn't eat my second sandwich. Debra prepared them for me."
    show szedvicsjelenet5resz1 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    play sound "audio/tuzes.wav"
    show szedvicsjelenet5resz2 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    f "What the fuck!!! HOOOT!!"
    hide teremkola2
    hide konyhatanyerszendvics2 onlayer hatso
    hide teremfred
    show teremfrediszik
    show szedvicsjelenet5resz3 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s4
    f "...Debra!..."
    hide szedvicsjelenet5resz1 onlayer kozep
    hide szedvicsjelenet5resz2 onlayer kozep
    show szedvicsjelenet5resz3 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    fg "You will pay for this!"
    show teremfrediszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen tanterem
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
$ renpy. pause(hard=True)
label tanterembolki:
    if hanyadiknapvan == 3:
        hide screen tanterem
        f "We should go now Puffy!"
        da "Can I check your new home Fred?"
        f "Of course. Grandma told me to bring a strong and handsome boy home. She will be happy!"
        da "Who is Grandma?"
        f "Bertalan’s mother."
        da "Ahha... but..."
        f "We talked about something before I left...."
    if hanyadiknapvan == 5:
        $ teremjelenetek = 1
    if hanyadiknapvan == 12:
        if egyetemenvoltal12resz == 0:
            if kimehecaterembol12nap == False:
                f "The lesson is not over yet. Do not go anywhere!"
                $ renpy. pause(hard=True)
            if kimehecaterembol12nap == True:
                hide screen tanterem
                hide invertori onlayer elotte6
                hide screen invertori
                hide screen invertori2
                $ egyetemenvoltal12resz = 1
                $ jimholvan = "sehol"
                $ ritaholvan = "sehol"
                $ kittyholvan = "parkban"
                $ puffyholvan = "temeto"
                $ markholvan = "sehol"
                show egyetemtanar onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s2
                u ""
                sam "Now we are done. You can leave."
                sam "And to be extra polite... I wish you a nice day!"






    jump terkep
$ renpy. pause(hard=True)
label naracslefel8resz:
    show teremgyum1:
        zoom 0.6
        xpos 0.4
        ypos 0.13
        alpha 1.0
        linear 1.0 alpha 0.0
    $ uditosmagamhozveni = 1
    $ targyazinvertoriban += 1
$ renpy. pause(hard=True)
label tanterem10jelenet:
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    f "Did you collect the money to buy the necklace?"
    da "Shit! No… I tried everything, but I still miss some money…"
    f "What should we do?"
    da "Could you lend me 2000 Forints Brother? It could help me out. I will give it back soon."
    f "I wish to, but I have no money. Let me think… That is it! I will ask around, search for a job and sample money for you."
    da "Are you serious? You are the best friend!"
    f "You can trust me, I can trust you. We are friends… You would help me out. Wouldn’t you?"
    da "In your dreams Bro!"
    f "Hahhahha! Funny…"
    da "You know me! I would sell my leg to save you… And tell me… Will you eat that sandwich?"
    if csiposzenyo == 1:
        f "I am afraid. The last time Debra prepared a sandwich for me, she put so much chilli in it I cried 20 minutes long."
    f "Are you hungry?"
    da "Yeap! I am hungry like a wolf. I made blood donations in the last days to sample money."
    f "You can have it!"
    show konyhatanyerszendvics2 onlayer hatso:
        zoom 0.8
        xpos 0.34
        ypos 0.62
        alpha 1.0
        linear 1.0 alpha 0.0
    da "Thank you! I will eat the sandwich on the road to the cemetery."
    f "But... Why did you make a blood donation? Do you need the money to buy the necklace?"
    da "Yes, I am making it for Diana. They pay me 1000 Forints per donation."
    f "You are a hero Puffy! You offer your blood for your love… "
    da "It is really romantic... Diana is special to me."
    da "I have to go now! See you later!"
    f "Ok! I will call you, as soon as I get the money."
    show teremdagi:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremgyum2:
        alpha 1.0
        linear 1.0 alpha 0.0
    fg "Well… I can not call anyone on my phone. I have no money on my account… Never mind… I will drink my cola and go…"
    show teremfred:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremkola2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show teremfrediszik:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide teremanika1 onlayer hatso2
    hide teremanika2 onlayer hatso2
    if anikahogyall == 1:
        show teremanika1 onlayer hatso2:
            alpha 1.0
            linear 1.0 alpha 0.0
    if anikahogyall == 2:
        show teremanika2 onlayer hatso2:
            alpha 1.0
            linear 1.0 alpha 0.0
    show screen s3
    u ""
    hide screen anikahogyall
    show teremfrediszik:
        alpha 1.0
        linear 1.0 alpha 0.0
    show tanteremkozeli onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show ritabeszed onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    r "Can we go now Fred?"
    f "I have something to do. I have no time for you, sorry. I have to help out a friend."
    r "Oh, you are so wonderful!"
    f "After I finish, we can meet somewhere."
    r "Lovely. I will go home now. I have a volleyball workout in a few hours. "
    r "After the training I will go to the confectionery. "
    f "I do not know when I will finish…"
    r "No problem. I will stay in the confectionery and learn. The confectionery has a nice atmosphere."
    f "Let us meet there! Goodbye!"
    hide teremrita onlayer hatso3
    show tanteremkozeli onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show ritabeszed onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ teremjelenetek = 2
    $ vanszedvicsed2 = 0
    $ uditosmagamhozveni = 2
    $ kerjmunkatkerhec = True
    $ debraholcsinal = "ablakotpucolballfojason"
    $ kittyholvan = "parkban"
    $ svetlana = "boltnal"
    hide screen invertori2
    show screen invertori
    show screen invertoriszov
    show screen tanterem
$ renpy. pause(hard=True)
label tanterem11jelenet:
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    f "Did you get the necklace?"
    da "Nope! The pawnshop was closed yesterday…"
    f "Really sad, because Grandma is at home alone and she really likes you…"
    da "Why are you telling this just now? What am I doing here? "
    f "You have important lessons…"
    da "Those are not so important! I'm leaving now!"
    show teremdagi:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show text "After the lessons." onlayer screens
    show screen s2
    u ""
    hide text onlayer screens
    hide teremfred
    hide teremkitty onlayer hatso
    hide teremjim3 onlayer hatso
    hide teremrita2 onlayer hatso
    $ tiltjaatereketnyomortanya = False
    $ vanszedvicsed2 = 0
    $ uditosmagamhozveni = 2
    $ kittyholvan = "parkban"
    $ mrpuliholvan = "napozoagy"
    $ svetlana = "nyomortanya"
    $ mamaholvan = "szobajaban"
    $ fodoholvan = "boltelott"
    $ boboholvan = "parkban"
    $ ritaholvan = "cukrazda"
    $ annaholvan = "parktonal2"
    $ rozsaholvan = "boltoknal"
    $ bramholvan = "barkacsboltban"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    $ fekete = True
    $ invertorialapjelenyenmeg = True
    jump engedejek
$ renpy. pause(hard=True)
label oroszkonyvfel:
    hide screen tanterem
    if hanyadiknapvan == 11:
        if oroszkonyvetfelveheted == False:
            f "Someone left his Russian dictionary on the table. Never mind. He will pick it up tomorrow."
            show screen tanterem
            $ renpy. pause(hard=True)
        f "Russian dictionary. I will take it. I will bring it back tomorrow. Noone will steal it this way."
        $ oroszkonyvnalad = 1
        show oroszszotarazinvertoriban:
            xalign 0.0
            ypos 0.63
            alpha 1.0
            linear 1.0 alpha 0.0
        if oroszkonyvnalad == 1:
            if mubajuszkell == 2:
                if nyomortanyadoboz1nalad == 2:
                    $ hazamehetc = True
    if hanyadiknapvan == 12:
        f "Someone left his Russian dictionary on the table. Never mind. He will pick it up tomorrow."

    show screen tanterem
$ renpy. pause(hard=True)
label modernkepalkotastanteremben:
    hide screen tanterem
    f "A modern painting. This belongs to the university."
    f "The painter must be blind... Are those boobs?"
    show screen tanterem
$ renpy. pause(hard=True)
label kepegyepuletroltanteremben:
    hide screen tanterem
    f "An image of a building. Some olds students made this model in the early 80’s."
    show screen tanterem
$ renpy. pause(hard=True)
label kepmariakiralynoroltanteremben:
    hide screen tanterem
    f "A painting of Queen Maria. She had a castle around here…."
    show screen tanterem
$ renpy. pause(hard=True)
label vegzosoktanteremben:
    hide screen tanterem
    f "A board image of the students from 1936…"
    show screen tanterem
$ renpy. pause(hard=True)
label konyvajalotanteremben:
    hide screen tanterem
    f "A book recommendation. It says: The love of Alice."
    show screen tanterem
$ renpy. pause(hard=True)
label ablaktanteremben:
    hide screen tanterem
    f "A window. I do not want to look out now."
    show screen tanterem
$ renpy. pause(hard=True)
label tanterem12jelenet:
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen invertori2
    show sirosfiu3resz
    show teremdagi
    show teremfred
    show egyetemenritatanulmoz1
    show egyetemenkittytanul
    show egyetemenjoetanulanim onlayer hatso
    show egyetemtanar onlayer elotte
    $ jimholvan = "iskola"
    $ ritaholvan = "iskola"
    $ kittyholvan = "iskola"
    $ puffyholvan = "iskola"
    $ markholvan = "iskola"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    sam "So let us talk about the conquests of Alexander the Great…"
    da "Why do we have to learn such bullshit?"
    sam "How should I know? I have only to teach you this lesson."
    f "Could we learn something useful?"
    sam "This is useful. I will ask you about the conquests of Alexander the Great in the next test, so it is useful to know this..."
    sam "Oh and who did draw on the chalkboard?"
    j "We had an artistic lesson and we had to draw in the theme of our interst…"
    sam "Why did you not clean the chalkboard after the class? Why did you not use normal paper to draw?"
    r "We used all of it in the origami lesson."
    sam "Fine... Let us focus on our lesson! You will write a test on Friday."
    da "Will this be the theme of the test?"
    sam "As I said before, yes. I also asked you to clean the chalkboard…"
    k "I tried it but an idiot fixed the drawings with lacquer. I can not remove it with water and sponge."
    sam "I do not care. Make these drawings disappear before the next class..Joe! Stop moving! Watch your book at least!"
    sam "Can we continue now?"
    show egyetemtanar onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""

    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori
    show screen tanterem

$ renpy. pause(hard=True)
label jimvalbeszed12nap:
    hide screen tanterem
    $ tanterembenbeszelteljim = True
    j "I am listening to Mrs. Teacher!"
    sam "Everyone can see you „listening” Joe!"
    j "I love the lessons and the knowledge…"
    sam "The cleaning lady does not really like you because you make the desk and floor dirty every day…"
    j "I am sorry! It is my Allergy…"
    sam "Sure,! It is your allergy... Let us continue!"
    if tanterembenbeszeltelpuffy == True:
        if tanterembenbeszeltelmark == True:
            if tanterembenbeszeltelkitty == True:
                if tanterembenbeszelteljim == True:
                    if tanterembenbeszeltelrita == True:
                        $ kimehecaterembol12nap = True
    show screen tanterem
$ renpy. pause(hard=True)
label ritavalbeszed12nap:
    hide screen tanterem
    $ tanterembenbeszeltelrita = True
    sam "Rita! Are you listening?"
    hide egyetemenritatanulmoz1
    hide egyetemenritatanulanimle
    show egyetemenritatanulanimfel
    show screen s1
    u ""
    r "Yes! I am a Dear Teacher! I can concentrate better in this position."
    sam "Ok… Just continue like that. I will continue with Alexander the Great…"
    hide egyetemenritatanulanimfel
    show egyetemenritatanulanimle
    play sound "audio/ut.wav"
    show screen s25
    u ""
    with vpunch
    if tanterembenbeszeltelpuffy == True:
        if tanterembenbeszeltelmark == True:
            if tanterembenbeszeltelkitty == True:
                if tanterembenbeszelteljim == True:
                    if tanterembenbeszeltelrita == True:
                        $ kimehecaterembol12nap = True
    show screen tanterem
$ renpy. pause(hard=True)
label kittyvalbeszed12nap:
    hide screen tanterem
    $ tanterembenbeszeltelkitty = True
    sam "What is the theme you are learning now Kitty?"
    k "Alexander the Great."
    sam "Do you know where I was before we stopped?"
    k "Page 123, line 23 in the middle. ….„The huge conquest”…."
    sam "Thank you! Now I remember! So the huge conquest…"
    if tanterembenbeszeltelpuffy == True:
        if tanterembenbeszeltelmark == True:
            if tanterembenbeszeltelkitty == True:
                if tanterembenbeszelteljim == True:
                    if tanterembenbeszeltelrita == True:
                        $ kimehecaterembol12nap = True
    show screen tanterem
$ renpy. pause(hard=True)
label puffyvalbeszed12nap:
    hide screen tanterem
    $ tanterembenbeszeltelpuffy = True
    da "You will never figure out what happened yesterday to me…"
    f "Let me guess!"
    da "You have three chances."
    f "You triggered the necklace from the pawnshop yesterday and you gave it to Grandma."
    da "Well yeah! But what happened after that?"
    f "You gave it to her and she placed it on a place…"
    da "Well yeah, but what happened after that?"
    f "This belongs to your private lyfe Puffy…"
    da "No problem! I will tell you later so you can get really jealous."
    f "Fine... I can not wait to hear the details."
    da "You have to wait a bit longer. I have to work in the afternoon. I need money."
    f "Ok."
    da "What do you have to eat?"
    f "I ate it. I have nothing left."
    da "Oh, that is bad. I am still hungry."
    f "I will bring you a sandwich tomorrow."
    da "Hahha. You will have no lessons tomorrow. Did you forget?"
    f "Oh, I forgot, sorry!"
    if tanterembenbeszeltelpuffy == True:
        if tanterembenbeszeltelmark == True:
            if tanterembenbeszeltelkitty == True:
                if tanterembenbeszelteljim == True:
                    if tanterembenbeszeltelrita == True:
                        $ kimehecaterembol12nap = True
    show screen tanterem
$ renpy. pause(hard=True)
label markvalbeszed12nap:
    hide screen tanterem
    $ tanterembenbeszeltelmark = True
    mk "My life is ruined!"
    sam "Mark’s life is ruined just like the reign of Alexander the Great.. Could you suffer more quietly? Thank you!"
    if tanterembenbeszeltelpuffy == True:
        if tanterembenbeszeltelmark == True:
            if tanterembenbeszeltelkitty == True:
                if tanterembenbeszelteljim == True:
                    if tanterembenbeszeltelrita == True:
                        $ kimehecaterembol12nap = True
    show screen tanterem
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
