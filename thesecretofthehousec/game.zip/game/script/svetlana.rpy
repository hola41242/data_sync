label svetlanabeszedboltnal:
    hide screen bolt
    hide fiupoz1
    $ ladabanvanvalamiszamodra = False
    $ fiupoz = 1
    show shopelotbeszedhater:
        alpha 0.0
        linear 1.0 alpha 1.0
    if hanyadiknapvan < 8:
        show koldoskurvakozelibeszed:
            alpha 0.0
            linear 1.0 alpha 1.0
    if hanyadiknapvan >= 8:
        show svetlanapoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    show shopelotbeszedhater:
        alpha 1.0
    if hanyadiknapvan < 8:
        show koldoskurvakozelibeszed:
            alpha 1.0
    if hanyadiknapvan >= 8:
        show svetlanapoz1:
            alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 1.0
    if hanyadiknapvan == 5:
        if koldussalbeszeltel == 0:
            if lizagyurulye == 0:
                if svetlananakatalpenzt < 250:
                    jump svetlanabeszedboltnalsantarol

    if hanyadiknapvan == 8:
        if svetlanabeszetelmikorgazdag == 0:
            jump elsotalalkozasgazdagon


    show screen svetlenaback
$ renpy. pause(hard=True)
label svetlanabeszedboltnalsantarol:
    hide screen svetlenaback
    f "Hy! Can I ask you something?"
    s "Not really… What is it?"
    f "Do you know any lame guys?"
    s "What will I get for this information?"
    f "I don't know... What do you want to get?"
    s "Make me an offer!"
    show screen ajalatoksvetlananak
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    $ fiupoz = 2
$ renpy. pause(hard=True)
label ajalat1resz5:
    if svetlananakatalpenzt >= 250:
        jump ajalat2resz5
    if svetlananakatalpenzt >= 500:
        jump ajalat3resz5
    if svetlanavalbeszed == 4:
        $ svetlanavalbeszed = 0
    if svetlanavalbeszed == 3:
        $ svetlanavalbeszed = 4
        s "Give me 50 extra and I will tell you."
    if svetlanavalbeszed == 2:
        $ svetlanavalbeszed = 3
        s "This is not enough…"
    if svetlanavalbeszed == 1:
        $ svetlanavalbeszed = 2
        s "Give me more!"
    if svetlanavalbeszed == 0:
        $ svetlanavalbeszed = 1
        s "Try to give a bit more!"
    show screen ajalatoksvetlananak
$ renpy. pause(hard=True)
label ajalat2resz5:
    $ fiupoz = 1
    s "This will be enough. I will tell you what I know now."
    show fiupoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    s "I am new here, I don't know anybody in this city."
    f "Give me my money back bitch!"
    s "You can eat your shit, but i won't give the money back."
    f "Oh shit…"
    s "Be happy to help a human being!"
    show screen ajalatoksvetlananak
$ renpy. pause(hard=True)
label ajalat3resz5:
    $ fiupoz = 1
    s "You are really kind. I am new here. I do not know any people in this city."
    show fiupoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "I want my money back."
    s "Sorry, but I can’t."
    show screen ajalatoksvetlananak
$ renpy. pause(hard=True)
label bunkovalaszsvetlananak:
    $ svetlanakedvel -= 5
    f "I hope you will spend the money on some medicines."
    s "Scram Bastard!"
    jump svetlanaki
$ renpy. pause(hard=True)
label kedvesvalaszsvetlananak:
    $ svetlanakedvel += 5
    f "I am happy we met. Welcome to the city!"
    s "Thank you! You are really kind."
    f "I will help you if I have more money."
    s "Do not worry. I can stand on my own."
    show screen svetlenaback
$ renpy. pause(hard=True)
label kedves250valaszsvetlananak:
    $ svetlanakedvel += 3
    f "Take this! Buy some nice dresses. You can not wear these trashes forever!"
    s "What should I buy for [svetlananakatalpenzt] FT? Thong panties?"
    f "You are right! See you soon!"
    s "Thanky! Bye!"
    show screen svetlenaback
$ renpy. pause(hard=True)
label svetlanavalbeszed:
    if hanyadiknapvan == 10:
        hide svetlanapoz2
        hide fiupoz2
        hide fiupoz4
        if kerjmunkatkerhec == True:
            if ladatmegtalalhatod == 0:
                f "Do you have a job for me?"
                s "Do I look like a millionaire business woman?"
                f "Well… yeah…"
                show svetlanapoz1:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show svetlanapoz2:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                s "Oh sure! I forgat! I am a millionaire business woman!"
                show fiupoz1:
                    xpos -0.1
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz2:
                    xpos -0.1
                    alpha 0.0
                    linear 1.0 alpha 1.0
                f "So do you have a job for me?"
                s "Sorry Fred. Puffy was faster than you."
                show svetlanapoz2:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show svetlanapoz1:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                f "What does Puffy need to do now for you?"
                s "I sent him to sample the candlesticks in the old cemetery."
                $ dagiholvan = "temeto"
                show fiupoz2:
                    xpos -0.1
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz4:
                    xpos -0.1
                    alpha 0.0
                    linear 1.0 alpha 1.0
                f "I am not even surprised…"
                s "Maybe next time, loser!"
                show fiupoz4:
                    xpos -0.1
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz1:
                    xpos -0.1
                    alpha 0.0
                    linear 1.0 alpha 1.0
                f "I would never accept sucha job."
                s "Sometimes you need to accept the things you hate… Sometimes your need is bigger than your ego…"
                f "Sure... I have to go now."
                s "Search me if you find some old coins again!"
                show screen svetlenaback
                $ renpy. pause(hard=True)
        if ladatmegtalalhatod == 1:
            if karkotonalad == 0:
                $ dagiholvan = "temeto"
                f "I found an old box. Will you buy it?"
                s "What is inside?"
                f "I do not know. I could not open it."
                s "I will give you 200 Forints for the box."
                f "Are you kidding me? I will not sell it so cheap."
                s "Maybe there are only rocks inside… Open the box and we can have a deal!"
                f "Ok."
                show screen svetlenaback
                $ renpy. pause(hard=True)
        if karkotonalad == 1:
            s "Did you find something for me?"
            f "I found a bracelet. How much money is it worth?"
            s "Show it to me… ehm… It is shiny and it is not gold…"
            s "I will give you 5000 Forints for this one."
            show fiupoz1:
                xpos -0.1
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz2:
                xpos -0.1
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Are you tricking me again?"
            s "I would never do that! What do you think?"
            f "I really do not know… I will sell it. I need the money fast."
            $ karkotonalad = 2
            $ penz = 5000
            $ dagiholvan = "temeto"
            show fiupoz2:
                xpos -0.1
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                xpos -0.1
                alpha 0.0
                linear 1.0 alpha 1.0
            f "I have to go now! Bye!"
            s "Come back if you have any more offers! I spend my time here."
            show screen svetlenaback
            $ renpy. pause(hard=True)




    if svetlanavalbeszed == 4:
        $ svetlanavalbeszed = 0
    if svetlanavalbeszed == 3:
        $ svetlanavalbeszed = 4
        s "Do you have any place to go? Do you like to talk to homeless people?"
        f "I like to talk to homeless people..."
    if svetlanavalbeszed == 2:
        $ svetlanavalbeszed = 3
        f "You have a great dress!"
        s "This is new, but I washed it with a pitbull.."
    if svetlanavalbeszed == 1:
        $ svetlanavalbeszed = 2
        f "Did you always live on the street? Or did the moving made you look like this?"
        s "Are you always like that? Why do you try to get on other people's nerves?"
    if svetlanavalbeszed == 0:
        $ svetlanavalbeszed = 1
        f "Tell me your story!"
        s "How much money do you have?"
        f "Nothing."
        s "Then scream! Idiot!"

    show screen svetlenaback
$ renpy. pause(hard=True)
label svetlanabeszedboltnalgyururol:
    $ lizagyurulyesvetlanatol = 1
    s "I did not find any rings. If I find some, it will land in the pawnshop in no time! Hahha!"
    hide fiupoz1
    show fiupoz1szem2:
        xpos -0.1
    f "I undertsand… what do you have in your bag?"
    s "Some stuff to sell."
    f "What do you have?"
    s "A… vibrator… a brandy bottle… etc…"
    show fiupoz1:
        xpos -0.1
    hide fiupoz1szem2
    f "I am not interested."
    show fiupoz2:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    s "I accept the exchange as well!"
    f "Ok."
    show fiupoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen svetlenaback
$ renpy. pause(hard=True)
label svetlanabeszedboltnalkulacsrol:
    $ kolduskulacsa = 1
    if lizagyurulyesvetlanatol < 2:
        if lizagyurulyesvetlanatol == 0:
            f "Did you find any brandy bottles in this city? I am interested in the brandy bottles."
            $ lizagyurulyesvetlanatol = 2
        if lizagyurulyesvetlanatol == 1:
            f "I came back. I need the brandy bottle."
            $ lizagyurulyesvetlanatol = 2
        s "I found a bottle. It is in cool condition."
        show fiupoz1:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        f "What do you charge for this one?"
        s "I want a lamp in exchange."
        f "A lamp?"
        s "Well yeah! I can not see in the dark at night, so..."
        f "Understand! I will bring you a lamp."
        s "Ok. You find me here..."
        show fiupoz2:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
    if lizagyurulyesvetlanatol >= 2:
        s "Do you have the lamp?"
        f "Not yet."
        s "Go and find me a lamp."


    show screen svetlenaback
$ renpy. pause(hard=True)
label svetlanabeszedboltnallampacsere:
    $ lizagyurulyesvetlanatol = 6
    $ lampatkidobni5resz = 3
    f "Here you are! Do you like this?"
    s "Yeah! We have the same style!"
    f "Give me the brandy bottle."
    $ kolduskulacsa = 2
    s "Here you go!"
    s "I have to go now! Goodbye!"
    f "Alright! Goodbye!"
    hide taska5resz
    hide koldoskurvamagas490
    jump svetlanaki
$ renpy. pause(hard=True)
label svetlanabeszedboltnalnapozo:
    s "What are you talking about?"
    f "Well I need: sewing needle, canvas, thread…"
    s "If I would have such things. I would have repaired my dresses…"
    show screen svetlenaback
$ renpy. pause(hard=True)
label svetlanaki:
    show shopelotbeszedhater:
        alpha 1.0
        linear 1.0 alpha 0.0
    if hanyadiknapvan < 8:
        show koldoskurvakozelibeszed:
            alpha 1.0
            linear 1.0 alpha 0.0
    if hanyadiknapvan >= 8:
        show svetlanapoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
    if fiupoz == 1:
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
    if fiupoz == 2:
        show fiupoz2:
            alpha 1.0
            linear 1.0 alpha 0.0
    pause 1.0
    hide shopelotbeszedhater
    hide koldoskurvakozelibeszed
    hide svetlanapoz1
    hide svetlanapoz2
    hide fiupoz1
    hide fiupoz2
    $ ladabanvanvalamiszamodra = True
    show screen bolt
$ renpy. pause(hard=True)
label svetlanabeszedboltnalgerebje:
    $ svetlanagerebjekerdes = True
    s "Of course I have! I brush my hair with a rake head and I am carrying the handle in my ass…"
    f "Ok, do you have a rake or not?"
    s "Should I answer this ridiculous question? Can you see any?"
    f "Ok... understood…"
    show screen svetlenaback
$ renpy. pause(hard=True)
label svetlanabeszedboltnalcsavarhuzo:
    s "I have a screwdriver."
    f "How much is it?"
    s "How much do you have?"
    f "I have [penz] Ft."
    s "Well, let us say… 10000 Ft."
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    f "This is really expensive for a screwdriver."
    s "You need a screwdriver, I have one… this is the business…"
    f "I don't have much money."
    show fiupoz2:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    s "Do you have something for exchange?"
    $ mamanyaklanc = 2
    f "Well, I have a gold necklace... Is it worth 10000 Ft?"
    $ csavarhuzo6resz = 1
    s "Offer accepted! I will take it to the pawnshop. Let us see how much it is worth!"
    hide taska5resz
    hide koldoskurvamagas490
    jump svetlanaki
$ renpy. pause(hard=True)
label megkerdezedanyaklancot:
    if svetlanaermeje == 0:
        $ mamanyaklanczalogjegy = 1
        f "Hy Svetlana! Give me back the necklace please!"
        s "I can give you only the pawnshop ticket..."
        f "How much do I have to pay for the necklace to get it back?"
        hide fiupoz2
        hide fiupoz1
        hide fiupoz4
        hide fiupoz5
        show fiupoz1:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz5:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        s "It cost 15.000 Forint."
        show fiupoz5:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Oh Shit! Will you give me the pawnshop ticket?"
        s "What do you offer as an exchange?"
        show fiupoz2:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        f "But… I have to pay 15.000 Ft for the necklace…"
        s "Sure… but I have the ticket and you need it. So tell me, what do you offer?"
        f "I have [penz] Forint."
        s "Not enough! Offer me something else!"
        show fiupoz1:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz4:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I have nothing now…"
        show fiupoz4:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        s "In this case, come back later and bring me something nice…"
        f "Ok, I will try my best!"
        s "Hurry! I have a lot to do…"
    if svetlanaermeje == 1:

        hide taska5resz
        hide koldoskurvamagas490
        f "tI found an old coin. I do not know the value of it, but can we have a deal?"
        $ svetlanaermeje = 2
        s "Hmmmm… maybe this is worthless…"
        f "Well... I don’t know…"
        $ mamanyaklanczalogjegy = 2
        s "Oh well! Give me the coin! This will not cost me any Forints. Here you are, the pawnshop ticket! Be happy with it!"
        s "I have to go now! Bye!"
        f "Bye! I have to go now, too…"
    jump svetlanaki
$ renpy. pause(hard=True)
label elsotalalkozasgazdagon:
    $ svetlanabeszetelmikorgazdag = 1
    s "Hy Fred!"
    f "Excuse me! Who are you?"
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    s "How much can you pay for this information?"
    f "S… Svetlana? But… how… I thought you have nothing…"
    show svetlanapoz1s2
    s "Well, you are right. I did not have anything… until yesterday. You gave me an old coin yesterday and it changed my life…"
    s "The coin was really expensive."
    hide svetlanapoz1s2
    show fiupoz2:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Expensive? How much was it worth? 10.000 Forints or 20.000 Forints?"
    show fiupoz4:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    s "To be honest a significant amount hit my grip…"
    f "…How much?"
    hide screen invertori
    hide invertori onlayer elotte6
    show svetlanapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show svetlanapoz2:
        alpha 0.0
        pause 1.0
        alpha 1.0
    show svetlanapinap8resz:
        alpha 0.0
        linear 1.0 alpha 1.0
    s "Well… I will tell you, because you gave the coin to me…"
    s "With taxes a rich guy paid me 100.000.000 Forints for the coin. We had a really great exchange!!! Do you not think so? Hahhha!"
    f "This must be a lie!"
    s "I never lie asshole! I got rich like a bitch and I feel some kind of gratitude…"
    show shopelotbeszednagyonkozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fredperverz:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    f "So you are thankful now and will you do anything I wish??..."
    show final4reszanim1
    play sound "audio/ut.wav"
    show screen s2
    u ""
    show final4resz2-5:
        alpha 1.0
        linear 1.0 alpha 0.0
    hide final4reszanim1
    hide fiupoz1
    hide shopelotbeszednagyonkozeli
    hide fredperverz
    hide svetlanapinap8resz
    show screen s1
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    s "I am just a BIT thankful and I am not a whore. Keep your distance!"
    hide final4resz2-5
    f "Ok… Ok, I believe you…"
    s "Do you need anything else?"
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    f "I would like to buy dry yeast, but I do not have money."
    s "I will give you… 250 Forints."
    f "1.000 Forints?"
    s "Nope! I do not throw money out the window!"
    $ penz += 250
    f "You have a lot of money!"
    s "Yeah I have a lot of money, not you!"
    show svetlanapoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show svetlanapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    f "I gave you the coint… and ."
    s "Prove it!"
    show fiupoz2:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz5:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Oh shit! I fucked it up! Still, thank you for the 250 Forints! I need it now."
    show fiupoz5:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    f "But… can we be friends?"
    show svetlanapoz1s2:
        alpha 1.0
        pause 1.5
        alpha 0.0
    s "I do not mind it. Let us be friends, I think I like you in…a way now... But never try to touch me again!"
    hide svetlanapoz1s2
    f "Of course… I will only try the next time... Goodbye!"
    jump svetlanaki








$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
