label fojasojobb:
    if korbenezni == False:
        $ fojasojobb = True
        if fojasojobb and furdo == True:
            $ korbenezni = True
    if terkeproljovet2 == True:
        $ terkeproljovet2 = False
        play music "audio/banyabolt.ogg" fadeout 1
    if hanyadiknapvan == 6:
        if lizakertjekesz == 2:
            $ debraholcsinal = "ablakotpucolballfojason"
            $ esteighatralevoido = 0

    if hanyadiknapvan == 5:
        if regell5resz == False:
            if debraafurdoben5resz == 0:
                if kerdezkorbe == True:
                    $ debraholcsinal = "dolgozo"
        if regell5resz == False:
            if debraafurdoben5resz == 0:
                if lizagyurulyesvetlanatol >= 2:
                    $ debraholcsinal = "napalijelenet5resz"
                    $ debraafurdoben5resz = 2
                    $ szemetettkidobni5resz = 1
                    $ lampatkidobni5resz = 1
            if debraafurdoben5resz == 0:
                if kolduskulacsa == 1:
                    $ debraholcsinal = "napalijelenet5resz"
                    $ debraafurdoben5resz = 2
                    $ szemetettkidobni5resz = 1
                    $ lampatkidobni5resz = 1
            if lampatkidobni5resz == 3:
                if lizajelenetvege5resz == False:
                    $ debraholcsinal = "napaliban3"
    if hanyadiknapvan == 4:
        if regell4resz == True:
            if kenyeretvetetem == True:
                if kutyatap  == True:
                    if konzevnyito == True:
                        $ debrareggel4resznapaliben = False
                        $ debraholcsinal = "konyhaeszik"
        if uditosmagamhozveni == 2:
            if regell4resz == True:
                $ fifipoziciok = 0
                $ debraholcsinal = "fojasoballpisi"
                $ regell4resz = False



    $ holvagyok = "fojasojobb"
    jump tiltasok
label fojasojobbszov:
    if terkeproljovet == True:
        show screen invertori2
        show invertori onlayer elotte6:
            yalign 0.0
    show fajasojobb
    if esteighatralevoido == 0:
        show fajasojob2beste
    if semeteszsakafoldon == False:
        show szemeteszsak:
            xalign 0.40
            yalign 0.68
    if ujsagafoldon == False:
        show ujsagkicsi:
            xalign 0.475
            yalign 0.565
    show nyilafojason:
        xalign 0.45
        yalign 0.98
    if hanyadiknapvan < 4:
        show fajasojobbvirag
    if hanyadiknapvan >= 4:
        show fajasojobbvirag onlayer kozep
    if hanyadiknapvan == 3:
        if harmadikreszkonyha < 3:
            if fifienikap == True:
                show fifikeesziktaltele:
                    zoom 0.4
                    xpos 0.34
                    ypos 0.5
                show fifikeeszik:
                    zoom 0.4
                    xpos 0.34
                    ypos 0.5
            if fifienikap == False:
                if kavefifinel == False:
                    show kavefozoosszeszereleskave:
                        zoom 0.1
                        xpos 0.355
                        ypos 0.57
                show fifimorog:
                    zoom 0.4
                    xpos 0.34
                    ypos 0.5
        if harmadikreszkonyha >= 3:
            show fifikeesziktalures:
                zoom 0.4
                xpos 0.34
                ypos 0.5
        if harmadikreszkonyha == 3:
            jump hazajovbeszed
    if hanyadiknapvan == 4:
        if kutyatalfojasojobb == True:
            show fifikeesziktalures:
                zoom 0.4
                xpos 0.34
                ypos 0.5
    if hanyadiknapvan == 5:
        if szemetettkidobni5resz < 2:
            show szemeteszsak:
                xalign 0.40
                yalign 0.68
        if lampatkidobni5resz < 2:
            show lampa5resz:
                xalign 0.3
                yalign 0.72
    if hanyadiknapvan == 6:
        if debraholcsinal == "ablakotpucoljobbfojason":
            show debraablakotmosanim:
                zoom 0.95
                xzoom -1.0
                xpos 0.02
                ypos 0.05
        if debraholcsinal == "lomolgatfojasojobb":
            show debrahattallomolfojasojobbanim
    if hanyadiknapvan == 7:
        if debraholcsinal == "ablakotpucoljobbfojason":
            show debraablakotmosanim:
                zoom 0.95
                xzoom -1.0
                xpos 0.02
                ypos 0.05
        if fifiazutban == 1:
            if fifitfelvetem == False:
                show fifimorog:
                    xpos 0.42
                    ypos 0.45
                    zoom 0.3





    jump engedejek
$ renpy. pause(hard=True)
label debrafojjobbvissza:
    $ debrajobbfoban = False
    hide debrasopor
    show debrasopor:
        xpos 0.5
        ypos 0.3
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label debrafojjobbvissza2:
    $ debrajobbfoban = False
    hide debraablakotmosanim
    show debraablakotmosanim:
        zoom 0.95
        xzoom -1.0
        xpos 0.02
        ypos 0.05
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label szemeteszsakfel:
    if hanyadiknapvan == 5:
        $ szemetettkidobni5resz = 2
    $ semeteszsakafoldon = True
    show szemeteszsak:
        xalign 0.40
        yalign 0.68
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label ujsagkicsifel:
    $ ujsagafoldon = True
    show ujsagkicsi:
        xalign 0.475
        yalign 0.565
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
$ renpy. pause(hard=True)
label locsolfojjobb:
    if locsolokannaviz >= 1:
        play sound "audio/viz13.wav"
        $ locsolokannaviz -= 1
        $ viragokmegontozve += 1
        $ fojasojobbvirag = True
        if furdovirag == True:
            if fojasoballvirag == True:
                if fojasojobbvirag == True:
                    if napalivirag == True:
                        if atjarovirag == True:
                            if atjarovirag2 == True:
                                if furdovirag == True:
                                    if atjarovirag3 == True:
                                        $ viragokmegontozese = True
    else:
        f "I need to go back to the bathroom to fill the can with water."
$ renpy. pause(hard=True)
label fifivediakavet:
    $ fifieniker = True
    play sound "audio/morog.wav"
    f "I can not take the coffee bokx. Fifi will bite me for sure!"
$ renpy. pause(hard=True)
label fifiengedikavet:
    $ kavefifinel = True
    $ kavefrednel = True
    $ fifienikap = True
    show kavefozoosszeszereleskave:
        zoom 0.1
        xpos 0.355
        ypos 0.57
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifimorog:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifiszagol:
        zoom 0.4
        xpos 0.34
        ypos 0.5
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifikeesziktaltele:
        zoom 0.4
        xpos 0.34
        ypos 0.5
        alpha 0.0
        linear 1.0 alpha 1.0
    show fifiszagolpislog:
        zoom 0.4
        xpos 0.34
        ypos 0.5
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifikeeszik:
        zoom 0.4
        xpos 0.34
        ypos 0.5
        alpha 0.0
        pause 5.0
        linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
label hazajovbeszed:
    $ fekete = True
    $ harmadikreszkonyha = 4
    show fiupoz1
    show debrapoz1
    show dagiallas1:
        zoom 1.2
        xpos -0.05
        ypos 0.27
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    d "Oh you found back home Genius! Did someone help you?"
    f "Well… yeah. He is Puffy. He is my best friend! He is David."
    da "Yeah, everyone calls me Puffy Ma’m."
    d "I hope Puffy does not want to move in, too."
    f "Not really, he is visiting us."
    d "I will be in the kitchen. Go to the living room and talk to Grandma. I have a lot to do."
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show dagiallas1:
        zoom 1.2
        xpos -0.05
        ypos 0.27
        alpha 1.0
        linear 1.0 alpha 0.0
    jump engedejek
$ renpy. pause(hard=True)
label kutyatalfelfojasojobb:
    $ kutyatalfojasojobb = False
    $ kutyatalaltelenalad = False
    $ fifienikap = False
    $ fifipoziciok = 1
    show fifikeesziktalures:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label lampafel:
    $ lampatkidobni5resz = 2
    $ lizagyurulyesvetlanatol = 4
    show lampa5resz:
        xalign 0.3
        yalign 0.72
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label debrajobbfojasonablakottorol:
    $ debratmegnezed = "ablakottoroljobboldalt"
    $ fekete = True
    jump tiltasok
label debrajobbfojasonablakottorolszov:
    show debraablakotmosanim:
        zoom 0.95
        xzoom -1.0
        xpos 0.02
        ypos 0.05
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz2meltartoval onlayer kozep:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer kozep:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    if ruhakosarnaladtelemijenruhaval == "vizes":
        $ debraholcsinal = "viragcsereprekermeg"
        $ fojasokertfelemehtesz = True
        f "Debra! I have a problem."
        d "I knew it! What did you break again?"
        show fiupoz2 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        f "I do not think I broke anything. The dry function of the washing machine is not working now."
        show debrapoz2meltartoval onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz1 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        d "This is soooo interesting. Yesterday I used the dry function and it worked fine... You used it and it is broken now…"
        show fiupoz1 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz2 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        f "I made it all the same way as usual. It is old I guess and…"
        show mamapoz1 onlayer kozep2:
            xpos 0.15
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapoz1 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz4 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        d "I do not believe you! You fucked it up! Idiot!"
        show fiupoz2 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        f "In this case I will pay…"
        m "What are you talking about Freddy? Do you have more money?"
        f "Not really, I have [penz] forint, That is all. Grandma took my money away..."
        show debrapoz2meltartoval onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapoz4 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        d "Just shut up Grandma!"
        m "Why should I? You cried yesterday because the dry machine broke again and you can not repair it…"
        show fiupoz1 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz2 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        f "What?"
        show debrapoz8 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapoz2meltartoval onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        d "Oh shit! Grandma! He almost believed me! He almost paid the repair!Why can you not just shut up?"
        show mamapoz1 onlayer kozep2:
            xpos 0.15
            alpha 1.0
            linear 1.0 alpha 0.0
        f "You wanted to mislead me?"
        show debrapoz1 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapoz8 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        d "Yes, of course! It was going well until this old heg came and ruined it…"
        d "Anyway… Go to the backyard, there is an old clothes dryer. Spread out the clothes there!"
        show debrapoz4 onlayer kozep:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapoz1 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        d "A big bush grew in the way. I can not pass through the entrance of the backyard."
        d "You should remove the big bush and free the way."
        d "The door which leads you to the garden is the first door right from the entrance."
        f "Ok, I will do my duty…"
        show debrapoz4 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer kozep:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        $ debratmegnezed = "nemnezed"
        jump engedejek


    if debravalbeszed >= 4:
        $ debravalbeszed = 1
    if debravalbeszed == 3:
        $ debravalbeszed = 4
        d "Did you finish with the clean up?"
        f "Almost…"
        d "You should take care of the vacuum cleaner now!"
    if debravalbeszed == 2:
        $ debravalbeszed = 3
        f "Why are you cleaning the house now?"
        d "Time passes faster with work. You should try this out sometimes..."
        f "You just cleaned up yesterday…"
        d "This is your opinion, but your opinion is not important to me at the moment."
    if debravalbeszed == 1:
        $ debravalbeszed = 2
        f "Can I go after I clean up?"
        d "Let me see. Maybe I can find you another mission."
    show debrapoz2meltartoval onlayer kozep:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer kozep:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    hide debraablakotmosanim
    show debraablakotmosanim:
        zoom 0.95
        xzoom -1.0
        xpos 0.02
        ypos 0.05
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    hide debrapoz2meltartoval onlayer kozep
    hide fiupoz1 onlayer kozep
    $ debratmegnezed = "nemnezed"
    jump engedejek
$ renpy. pause(hard=True)

label debrajobbfojasonallomol:
    hide screen fojasojobb
    f "Can I… for a moment..."
    d "Nope!"
    show screen fojasojobb
$ renpy. pause(hard=True)
label mamakerdeztoled7nap:
    play music "audio/szexy.ogg" fadeout 1
    hide fajasojobbvirag onlayer kozep
    show fajasojobbvirag
    show fajasoballkozeli:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamapoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    m "Fred? Did you find my necklace?"
    f "How does it look?"
    m "It is a necklace of gold with a big cross medal."
    f "…I didn’t see it…"
    m "I will look around in the garden. I came across the garden yesterday..."
    m "But Grandma needs to change dress first. It is really hot outside!"
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    show nap7a19:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Do you want to change your dress here?"
    hide fajasoballkozeli
    hide mamapoz2
    hide fiupoz1
    hide mamalabal540
    m "Of course!"
    f "Ehm…"
    show nap7a19:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show csillagok6resz:
        xpos 0.1
        yzoom -1.0
        ypos 1.2
        pause 1.0
        linear 4.0 ypos -3.8
    show nap7a21:
        ypos -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
        ypos -1.0
        linear 4.0 ypos 0.0
    show screen s1e5
    u ""
    play sound "audio/csillag.ogg"
    show screen s4
    u ""
    m "What did you expect? You thought I would dress nude? Grandma is a bitch but not a whore."
    m "Grandma goes now… She has to find her special necklace… She can sell it…She can sample more money…"
    $ mamanyaklanc = 3
    show nap7a21:
        ypos 0.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide fajasojobbvirag
    show fajasojobbvirag onlayer kozep
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    play music "audio/banyabolt.ogg" fadeout 1
    show screen fojasojobb
$ renpy. pause(hard=True)
label fifitfelvenni7nap:
    $ fifitfelvetem = True
    show fifimorog:
        xpos 0.42
        ypos 0.45
        zoom 0.3
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
