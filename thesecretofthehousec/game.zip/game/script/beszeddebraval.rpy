label debratolkerdezel:
    $ kivelbeszelsz = "debra"
    $ fekete = True
    jump tiltasok
label debratolkerdezelszov:
    if hanyadiknapvan == 2:
        if holvagyok == "fojasojobb":
            show debrasopor:
                alpha 1.0
                linear 1.0 alpha 0.0
            hide fiupoz2
            hide debrapoz6
            show debrapoz6:
                alpha 0.0
                linear 2.0 alpha 1.0
            show fiupoz2:
                alpha 0.0
                linear 2.0 alpha 1.0
            pause 2.0
            f "You have a nice red bra."
            d "This is new."
            d "I just do not care ,what you looked at so you noticed this.."
            show fiupoz2:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Well...it has a bright color..."
            show debrasopor:
                alpha 0.0
                linear 1.0 alpha 1.0
                pause (debravalamitcsinalido)
                alpha 1.0
                linear 2.0 alpha 0.0
            show fiupoz1:
                alpha 1.0
                linear 2.0 alpha 0.0
            show debrapoz6:
                alpha 1.0
                linear 2.0 alpha 0.0
            pause 2.0

    if hanyadiknapvan == 1:
        if debratmertkeresed == "sedvics":
            jump sedvi
        if debraholcsinal == "napaliban2":
            show debraujsaggal:
                alpha 1.0
                linear 1.0 alpha 0.0
            show nappali ujsag:
                alpha 0.0
                linear 2.0 alpha 1.0
            hide debrafotelpislog
        else:
            show debrasopor:
                alpha 1.0
                linear 1.0 alpha 0.0
        hide debrapoz4
        hide debrapoz4sepru
        hide fiupoz2
        if debratmegnezed == "gondolkodik":
            $ debratmegnezed = "nemnezed"
            if menyiharomgyokalat >= 3:
                $ menyiharomgyokalat = 4
                hide debrapoz5
                show debrapoz5:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                show fiupoz1:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                f "The N-th root of 3 is 1,73."
                d "Do you not have anything else to do?"
                f "...I am right on my way M.am…."
                show debrapoz5:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                show fiupoz1:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                show debrasopor:
                    xpos 0.6
                    ypos 0.2
                    alpha 0.0
                    linear 1.0 alpha 1.0
                    pause (debravalamitcsinalido)
                    linear 1.0 alpha 0.0
                jump engedejek
            if menyiharomgyokalat == 1:
                $ menyiharomgyokalat = 2
                show debrapoz5:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                show fiupoz1:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                d "What is the N-th root of 3?"
                f "I do not know."
                d "Who asked you?"
                show fiupoz1:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                show fiupoz2:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                pause 1.0
                f "Why is this so important now?"
                d "I do not know, I am just interested…"
                show debrapoz5:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                show fiupoz2:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                show debrasopor:
                    xpos 0.6
                    ypos 0.2
                    alpha 0.0
                    linear 1.0 alpha 1.0
                    pause (debravalamitcsinalido)
                    linear 1.0 alpha 0.0
                jump engedejek
        label sedvi:
        if debratmertkeresed == "sedvics":
            $ debratmertkeresed = "nemkeresem"
            if debraholcsinal == "napaliban2":
                hide debraujsaggal
                hide debrafotelpislog
                hide nappali ujsag
                show nappali ujsag:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                show debraujsaggal:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                hide debrafotelpislog
            if debraholcsinal == "napaliban2":
                show debrapoz4:
                    alpha 0.0
                    linear 2.0 alpha 1.0
            else:
                show debrapoz4sepru:
                    alpha 0.0
                    linear 2.0 alpha 1.0
            show fiupoz1:
                alpha 0.0
                linear 2.0 alpha 1.0
            pause 2.0
            d "Take the sandwich and give it to Grandma."
            f "Ok, just a minute…"
            if debraholcsinal == "napaliban2":
                show debrapoz4:
                    alpha 1.0
                    linear 2.0 alpha 0.0
            else:
                show debrapoz4sepru:
                    alpha 1.0
                    linear 2.0 alpha 0.0
            show fiupoz1:
                alpha 1.0
                linear 2.0 alpha 0.0
            if debraholcsinal == "napaliban":
                show debrasopor:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                    pause (debravalamitcsinalido)
                    linear 1.0 alpha 0.0
            if debraholcsinal == "napaliban2":
                hide debraujsaggal
                hide debrafotelpislog
                hide nappali ujsag
                show nappali ujsag:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                    pause (debravalamitcsinalido)
                    linear 2.0 alpha 1.0
                show debraujsaggal:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                    pause (debravalamitcsinalido)
                    linear 2.0 alpha 0.0
                show debrafotelpislog:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                    alpha 1.0
                    pause (debravalamitcsinalido)
                    alpha 1.0
                    linear 2.0 alpha 0.0
            pause 2.0
            jump engedejek

        if hozdbeazujsagot == True:
            if szoveguresdobozkidobva == True:
                if szemetafojason == True:
                    if viragokmegontozese == True:
                        if agynemu == True:
                            if agynemukaptal == False:
                                if holvagyok == "fojasojobb":
                                    if debraholcsinal == "napaliban2":
                                        show debrapoz4:
                                            alpha 0.0
                                            linear 2.0 alpha 1.0
                                    else:
                                        show debrapoz4sepru:
                                            alpha 0.0
                                            linear 2.0 alpha 1.0
                                    show fiupoz2:
                                        alpha 0.0
                                        linear 2.0 alpha 1.0
                                    pause 2.0
                                    f "I need bedsheets."
                                    d "Of course! Make me orders... but still, this is better than searching around…"
                                    if debraholcsinal == "napaliban2":
                                        show debrapoz4:
                                            alpha 1.0
                                            linear 2.0 alpha 0.0
                                    else:
                                        show debrapoz4sepru:
                                            alpha 1.0
                                            linear 2.0 alpha 0.0
                                    show fiupoz2:
                                        alpha 1.0
                                        linear 2.0 alpha 0.0
                                    show fiupoz3:
                                        alpha 0.0
                                        linear 2.0 alpha 1.0
                                    show debrapoz3:
                                        alpha 0.0
                                        linear 2.0 alpha 1.0
                                    pause 2.0
                                    d "Here you are, but you should clean it. You will find a pillow in the living room, in the cabinet."
                                    f "Thank you! I will wash it in the washing machine. I know how it works."
                                    $ agynemukaptal = True
                                    show fiupoz3:
                                        alpha 1.0
                                        linear 2.0 alpha 0.0
                                    show debrapoz3:
                                        alpha 1.0
                                        linear 2.0 alpha 0.0
                                    pause 2.0
                                else:
                                    if debraholcsinal == "napaliban2":
                                        show debrapoz4:
                                            alpha 0.0
                                            linear 2.0 alpha 1.0
                                    else:
                                        show debrapoz4sepru:
                                            alpha 0.0
                                            linear 2.0 alpha 1.0
                                    show fiupoz2:
                                        alpha 0.0
                                        linear 2.0 alpha 1.0
                                    pause 2.0
                                    f "I would like to ask for a bedsheet."
                                    d "Ask me for the bedsheet when I clean the corridor and near the warehouse room."
                                    if debraholcsinal == "napaliban2":
                                        show debrapoz4:
                                            alpha 1.0
                                            linear 2.0 alpha 0.0
                                    else:
                                        show debrapoz4sepru:
                                            alpha 1.0
                                            linear 2.0 alpha 0.0
                                    show fiupoz2:
                                        alpha 1.0
                                        linear 2.0 alpha 0.0
                                    pause 2.0
                    else:
                        if debraholcsinal == "napaliban2":
                            show debrapoz4:
                                alpha 0.0
                                linear 2.0 alpha 1.0
                        else:
                            show debrapoz4sepru:
                                alpha 0.0
                                linear 2.0 alpha 1.0
                        show fiupoz2:
                            alpha 0.0
                            linear 2.0 alpha 1.0
                        pause 2.0
                        f "I would like to ask for a bedsheet."
                        d "If you fulfill all my orders I will give you a bedsheet. Ask me for the bedsheet when I clean the corridor and near the warehouse room."
                        if debraholcsinal == "napaliban2":
                            show debrapoz4:
                                alpha 1.0
                                linear 2.0 alpha 0.0
                        else:
                            show debrapoz4sepru:
                                alpha 1.0
                                linear 2.0 alpha 0.0
                        show fiupoz2:
                            alpha 1.0
                            linear 2.0 alpha 0.0
                        pause 2.0
                else:
                    if debraholcsinal == "napaliban2":
                        show debrapoz4:
                            alpha 0.0
                            linear 2.0 alpha 1.0
                    else:
                        show debrapoz4sepru:
                            alpha 0.0
                            linear 2.0 alpha 1.0
                    show fiupoz2:
                        alpha 0.0
                        linear 2.0 alpha 1.0
                    pause 2.0
                    f "I would like to ask for a bedsheet."
                    d "If you fulfill all my orders I will give you a bedsheet. Ask me for the bedsheet when I clean the corridor and near the warehouse room."
                    if debraholcsinal == "napaliban2":
                        show debrapoz4:
                            alpha 1.0
                            linear 2.0 alpha 0.0
                    else:
                        show debrapoz4sepru:
                            alpha 1.0
                            linear 2.0 alpha 0.0
                    show fiupoz2:
                        alpha 1.0
                        linear 2.0 alpha 0.0
                    pause 2.0
            else:
                if debraholcsinal == "napaliban2":
                    show debrapoz4:
                        alpha 0.0
                        linear 2.0 alpha 1.0
                else:
                    show debrapoz4sepru:
                        alpha 0.0
                        linear 2.0 alpha 1.0
                show fiupoz2:
                    alpha 0.0
                    linear 2.0 alpha 1.0
                pause 2.0
                f "I would like to ask for a bedsheet."
                d "If you fulfill all my orders I will give you a bedsheet. Ask me for the bedsheet when I clean the corridor and near the warehouse room."
                if debraholcsinal == "napaliban2":
                    show debrapoz4:
                        alpha 1.0
                        linear 2.0 alpha 0.0
                else:
                    show debrapoz4sepru:
                        alpha 1.0
                        linear 2.0 alpha 0.0
                show fiupoz2:
                    alpha 1.0
                    linear 2.0 alpha 0.0
                pause 2.0
        else:
            if debraholcsinal == "napaliban2":
                show debrapoz4:
                    alpha 0.0
                    linear 2.0 alpha 1.0
            else:
                show debrapoz4sepru:
                    alpha 0.0
                    linear 2.0 alpha 1.0
            show fiupoz2:
                alpha 0.0
                linear 2.0 alpha 1.0
            pause 2.0
            f "I would like to ask for a bedsheet."
            d "If you fulfill all my orders I will give you a bedsheet. Ask me for the bedsheet when I clean the corridor and near the warehouse room."
            if debraholcsinal == "napaliban2":
                show debrapoz4:
                    alpha 1.0
                    linear 2.0 alpha 0.0
            else:
                show debrapoz4sepru:
                    alpha 1.0
                    linear 2.0 alpha 0.0
            show fiupoz2:
                alpha 1.0
                linear 2.0 alpha 0.0
            pause 2.0
        if debraholcsinal == "napaliban2":
            show debraujsaggal:
                alpha 0.0
                linear 1.0 alpha 1.0
                pause (debravalamitcsinalido)
                linear 1.0 alpha 0.0
            show debrafotelpislog:
                alpha 0.0
                linear 2.0 alpha 1.0
                alpha 1.0
                pause (debravalamitcsinalido)
                alpha 1.0
                linear 2.0 alpha 0.0
            show nappali ujsag:
                alpha 1.0
                linear 2.0 alpha 0.0
        else:
            show debrasopor:
                alpha 0.0
                linear 1.0 alpha 1.0
                pause (debravalamitcsinalido)
                linear 1.0 alpha 0.0
    jump engedejek
$ renpy. pause(hard=True)
label debraanapaliolvas:
    $ debratmegnezed = "olvasni"
    $ fekete = True
    jump tiltasok
label debrafojasonalanez:
    $ debratmegnezed = "alanez"
    $ fekete = True
    jump tiltasok
label debranapalibanelgondolkodva:
    $ debratmegnezed = "gondolkodik"
    $ fekete = True
    jump tiltasok
label debrakonyhabanfoz:
    $ debratmegnezed = "foz"
    $ fekete = True
    jump tiltasok
label debrafurdobenfelmos:
    $ debratmegnezed = "felmos"
    $ fekete = True
    jump tiltasok


label felsoelemektiltasa:
    hide screen invertori2
    hide invertori onlayer elotte6
label felsoelemeknemtiltasa:
    if debratmegnezed == "felmos":
        show debrafurdobenfelmos
        d "I really do not have time now. Ask me later."
        hide debrafurdobenfelmos

    if debratmegnezed == "foz":
        if hanyadiknapvan == 2:
            show debrafozkemenyen
            if mitfozol == 3:
                $ mitfozol = 0
            if mitfozol == 2:
                $ mitfozol = 3
                f "Are you tired? Is cooking tiring?"
                d "You are tiring Fred! Scram you little shit!"
            if mitfozol == 1:
                $ mitfozol = 2
                d "I am cooking lunch for tomorrow, Take your eyes off this!"
                f "Ok, but what should i eat? I am hungry!"
                d "Eat a sandwich. I do not care! Just do not touch this!"
            if mitfozol == 0:
                $ mitfozol = 1
                f "What are you cooking now?"
                d "Can you not tell? Chili beans..."
                f "I love it!"
            hide debrafozkemenyen
        if hanyadiknapvan == 3:
            $ tejetlerektam = True
            $ hoztejet = 2
            d "Thank you!"
    if debratmegnezed == "alanez":
        hide fajasoballvirag onlayer hatso
        show fojasoballoljel1 onlayer elotte
        pause 2.0
        d "What are you doing here?"
        f "I just try to fix my shoes."
        show fojasoballoljel2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.0
        d "Fix your shoes in another place or I will kick your ass!"
        hide fojasoballoljel1 onlayer elotte
        hide fojasoballoljel2 onlayer elotte
        show fajasoballvirag onlayer hatso
        show debrasopor:
            alpha 1.0
            pause (debravalamitcsinalido)
            alpha 1.0
            linear 2.0 alpha 0.0
    if debratmegnezed == "olvasni":
        hide nappalitv onlayer elotte6
        if hanyadiknapvan == 1:
            show debranapalibanolvassa
            if olvasdebra == 4:
                $ olvasdebra = 1
            if olvasdebra == 3:
                $ olvasdebra = 4
                f "Can you tell me my horoscope?"
                d "Leave people alone and try to be invisible…"
            if olvasdebra == 2:
                $ olvasdebra = 3
                f "What is so good about reading a newspaper?"
                d "The best thing is: I can not see you from the newspaper."
            if olvasdebra == 1:
                $ olvasdebra = 2
                f "What are you reading now?"
                d "I read an article” How should i lose a guy in 10 days”…"
            hide debranapalibanolvassa
            hide debraujsaggal
            hide debrafotelpislog
            show debraujsaggal:
                alpha 1.0
                pause (debravalamitcsinalido)
                linear 1.0 alpha 0.0
            show debrafotelpislog:
                alpha 1.0
                pause (debravalamitcsinalido)
                alpha 1.0
                linear 2.0 alpha 0.0
        if hanyadiknapvan == 2:
            if debraholcsinal == "napaliban2":
                if boritekazinvertoriba == True:
                    $ boritekmizeriamegoldva = True
                    show screen invertori2
                    show invertori onlayer elotte6:
                        yalign 0.0
                    d "it's okay i'll put it in my safe."
                    show debraujsaggal:
                        alpha 1.0
                        linear 2.0 alpha 0.0
                    show debrafotelpislog:
                        alpha 1.0
                        linear 2.0 alpha 0.0
                    show nappali ujsag:
                        alpha 1.0
                        linear 2.0 alpha 0.0
                    $ debratmegnezed = "nemnezed"
                    $ enneegyszedvicset = 1
                    f "I am hungry. I eat a sandwich..."
                    jump engedejek
                show debranapalibanolvassa onlayer elotte6
                if masodiknapfeladatokdebratol == True:
                    d "Do not disturb! I am reading!"
            if debraholcsinal == "napaliban3":
                show screen invertori2
                show invertori onlayer elotte6:
                    yalign 0.0
                if boritekazinvertoriba == True:
                    $ boritekmizeriamegoldva = True
                    d "it's okay i'll put it in my safe."
                    if debraholcsinal == "napaliban3":
                        show debratvnezalap:
                            alpha 1.0
                            linear 2.0 alpha 0.0
                        show debratvnezpislog:
                            alpha 1.0
                            linear 2.0 alpha 0.0
                    $ debratmegnezed = "nemnezed"
                    $ enneegyszedvicset = 1
                    f "I am hungry. I eat a sandwich.."
                    jump engedejek
                d "Do not disturb! I watch my series!"
            if masodiknapfeladatokdebratol == False:
                $ masodiknapfeladatokdebratol = True
                $ mosogasfel = 1
                $ dolgozolmosogatas = 1
                $ szenyeseltakaritasa = 1
                $ mamavalfoglalkoz = 1
                $ kutyapisok = 1
                $ debraindulhat2resz = True
                f "Can I ask you a favor?"
                d "What is it?"
                f "You should put my papers in a safe place. I can not open it yet."
                d "Ahha…"
                d "This is a big favor, it is not cheap…"
                d "Wash the dishes, wash your laundry, do not put your dirty dresses on the floor."
                d "You will take care about Grandma today. If Fifi make anything dirty, You should clean it up..."
                d "When you are done with all of these, I will put your papers in a safe place!"
            hide debranapalibanolvassa onlayer elotte6
            hide debraujsaggal
            hide debrafotelpislog
            hide debratvnezalap
            hide debratvnezpislog
            if debraholcsinal == "napaliban3":
                show debratvnezalap:
                    pause (debravalamitcsinalido)
                    alpha 1.0
                    linear 2.0 alpha 0.0
                show debratvnezpislog:
                    pause (debravalamitcsinalido)
                    alpha 1.0
                    linear 2.0 alpha 0.0

            if debraholcsinal == "napaliban2":
                show debraujsaggal:
                    alpha 1.0
                    pause (debravalamitcsinalido)
                    linear 1.0 alpha 0.0
                show debrafotelpislog:
                    alpha 1.0
                    pause (debravalamitcsinalido)
                    alpha 1.0
                    linear 2.0 alpha 0.0
        if hanyadiknapvan == 4:
            show debranapalibanolvassa onlayer elotte6
            if debrakutyatapboltban == 1:
                $ debrakutyatapboltban = 2
                f "I can not find any dog food. I did not find it in the fridge. Have you piled up dogfood somewhere else in the house?"
                d "No. I forgot to buy her something yesterday. Can you buy her pasty?"
                d "Oh! And to be sure! Fred! The puppies sall eat in the kitchen only. It is easier to clean up the tiles..."
                f "Ok, I will go to the shop now."
            if debrakutyatapboltban == 3:
                $ debrakutyatapboltban = 4
                f "Debra?"
                d "Yeah? What is it?"
                f "Do we have a can opener?"
                d "Why should we? The can has an original opener…"
                f "Yeah… but I broke it…"
                d "Can you see? This happened because you are a unfortunate idiot..."
                d "I can not remmeber of any can opener machine… but do not try to open the can with a knife genius!"
                d "Go to the shop and buy the can opener! Leave me alone! I want to read!"
                f "Understand! I go now!"
            if debratolkerdeznikenyer == True:
                if debratolkenyeretkerni == 0:
                    $ penz += 1000
                    $ debratolkenyeretkerni = 1

                    f "Debra I can not find bread in the fridge."
                    d "We were eating the bread yesterday. Here is the money! Go and buy bread!"
                    d "I gave you all my money. Do not come again for more!"
                    f "This will be enough! Do not worry!"
                    d "You are welcome! Wretched boy…"
                    if beszeljamamaval == 0:
                        d "Take care of Grandma please!"
                    if beszeljamamaval == 0:
                        $ beszeljamamaval = 1
            if olvasdebra == 4:
                $ olvasdebra = 1
            if olvasdebra == 3:
                $ olvasdebra = 4
                f "Why are you not reading the news on the internet?"
                d "Just imagine: I run out of toilet paper… I can not wipe my bottom with the internet."
            if olvasdebra == 2:
                $ olvasdebra = 3
                f "Are there any news of my home? Of my father?"
                d "I do not know, I am only reading the tabloid news."
            if olvasdebra == 1:
                $ olvasdebra = 2
                f "How can you read the newspaper? It is under the table!"
                d "It is the old one. I am holding a new one in my hand! Idiot!"
            hide debranapalibanolvassa onlayer elotte6
            hide debraujsaggal
            hide debrafotelpislog
            show debraujsaggal:
                alpha 1.0
                pause (debravalamitcsinalido)
                linear 1.0 alpha 0.0
            show debrafotelpislog:
                alpha 1.0
                pause (debravalamitcsinalido)
                alpha 1.0
                linear 2.0 alpha 0.0
            if hanyadiknapvan == 4:
                hide debraujsaggal
                hide debrafotelpislog
                show debraujsaggal
                show debrafotelpislog
$ debratmegnezed = "nemnezed"
if holvagyok == "napaliban":
    show nappalitv onlayer elotte6
show screen invertori2
show invertori onlayer elotte6:
    yalign 0.0
jump engedejek






$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
