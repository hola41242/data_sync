label stripbar:
    if hanyadiknapvan == 12:
        play music "audio/stripbar2.ogg" fadeout 1
        $ holvagyok = "stripbar"
        jump tiltasok
    if hanyadiknapvan >= 7:
        hide screen terkep
        f "It is closed."
        show screen terkep
        $ renpy. pause(hard=True)
    if felmosotvenni < 3:
        f "I have something to do before I enter the building."
        $ renpy. pause(hard=True)
    if zolivalbeszeltel == 2:
        f "I need to talk to Zoli before I do this."
        $ renpy. pause(hard=True)
    play music "audio/stripbar2.ogg" fadeout 1
    $ holvagyok = "stripbar"
    jump tiltasok
label stripbarszov:
    $ lizavalmunkabameni = True
    show fekete onlayer screens:
        alpha 1.0
    show stripbarjelenet1:
        xpos 0.0
    show screen s3
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show stripbarjelenet1:
        xpos 0.0
        linear 1.5 xpos -0.665
    show screen s1e5
    u ""
    show screen s1e2
    u ""
    show stripbarjelenet2alap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show stripbarjelenet2fred:
        alpha 0.0
        linear 1.0 alpha 1.0
    show stripbarjelenet2ele:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    $ lizajelenetvege5resz = True
    $ regell5resz = True
    f "A lot of bitches move around… I never tough so many girls are working here…"
    show stripbarjelenet2fredszemjobb
    f "She is sucking him…"
    hide stripbarjelenet2fredszemjobb
    show stripbarjelenet2fredszemkozep
    f "There… he is Fucking her by the table…"
    hide stripbarjelenet2fredszemkozep
    f "I think this place is getting nice… and comfortable..."
    show stripbaranimsegseta onlayer kozep
    show stripbarjelenet2fredpenisz:
        alpha 0.0
        pause 2.5
        alpha 1.0
    show stripbarjelenet2fredszemjobb:
        alpha 0.0
        pause 2.5
        alpha 1.0
    show stripbarjelenet2liza:
        alpha 0.0
        pause 2.5
        linear 0.5 alpha 1.0
    show screen s4
    u ""
    l "Hy Honey! You came!"
    f "Yeah… this is an interesting place..."
    l "My customer will arrive around 10 PM today..."
    f "The black guy?"
    l "Yeah, the black guy, but you are not really focusing..."
    show stripbarjelenet3:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.5
    f "I am sorry… A lot of naked women run around here and I am a man and my hormones…"
    hide stripbarjelenet1
    hide fekete onlayer screens
    hide stripbarjelenet2alap
    hide stripbarjelenet2fred
    hide stripbarjelenet2ele
    hide stripbarjelenet2fredszemjobb
    hide stripbarjelenet2fredszemkozep
    hide stripbaranimsegseta onlayer kozep
    hide stripbarjelenet2fredpenisz
    hide stripbarjelenet2liza
    show stripbarjelenet4:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.5
    l "This is natural! I see you got pretty nervous... Let me handle this!"
    show stripbarjelenet5:
        ypos -1.0
        xpos -0.15
        alpha 0.0
        linear 1.0 alpha 1.0
        parallel:
            ypos -1.0
            linear 1.5 ypos 0.0
        parallel:
            xpos -0.15
            linear 1.5 xpos -0.8
    show stripbarjelenet5szemanim:
        ypos -1.0
        xpos -0.15
        alpha 0.0
        linear 1.0 alpha 1.0
        parallel:
            ypos -1.0
            linear 1.5 ypos 0.0
        parallel:
            xpos -0.15
            linear 1.5 xpos -0.8
    show screen s2e5
    u ""
    l "I have a trick to get you relaxed…"
    show stripbarjelenet6mozanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show stripbarjelenet6szemanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show stripbarjelenet6szaj1:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    hide stripbarjelenet6szaj1
    show stripbarjelenet6szajanim
    l "When you are in Rome, behave like Romans do."
    show stripbarjelenet6szaj1
    hide stripbarjelenet6szajanim
    f "Someone might see us!"
    hide stripbarjelenet6szaj1
    show stripbarjelenet6szajanim
    l "Do not care about this. You see them as well!"
    show stripbarjelenet6szaj1
    hide stripbarjelenet6szajanim
    f "Aghhh!"
    u ""
    show stripbarjelenet3:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0

    hide stripbarjelenet4
    hide stripbarjelenet5
    hide stripbarjelenet5szemanim
    hide stripbarjelenet6mozanim
    hide stripbarjelenet6szemanim
    hide stripbarjelenet6szaj1
    show stripbarjelenet3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "Liza… We shouldn't do this…"
    show stripbarjelenet7:
        alpha 0.0
        linear 1.0 alpha 1.0
    l "Why not! This feels good!"
    f "Agh! I am going to cum!"
    show stripbarjelenet8:
        alpha 0.0
        linear 1.0 alpha 1.0
    mo "{size=-10}Liza! Your customer arrived!"
    l "I am almost there!"
    show stripbarjelenet9:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    l "Come on! Let us hurry before he enters the room!"
    f "Ok…"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    hide stripbarjelenet3
    hide stripbarjelenet7
    hide stripbarjelenet8
    hide stripbarjelenet9
    show stripbarjelenet10
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.5
    l "Hide down there! I will try to ask him about the details."
    f "Ok, but what if he notices me?"
    l "Do not worry! I have customers who pay to hide here as well. "
    l "If he notices you, I will explain: you are a pervert and you like to watch others."
    f "I hope he will believe you..."
    l "He won’t focus on you while I do my job. I am good!"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    play music "audio/stripbar1.ogg" fadeout 1
    show stripbarjelenet11
    queue sound "audio/tannenbaum.ogg"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    lg "He is lame for sure..."
    b "Hello Baby! Did Ya miss me?"
    pause 1.5
    show stripbarjelenet12:
        alpha 0.0
        linear 1.0 alpha 1.0
    stop sound
    queue sound "audio/nyog.ogg"
    queue sound "audio/nyog.ogg"
    queue sound "audio/nyog.ogg"
    queue sound "audio/nyog.ogg"
    pause 1.5
    l "Let me sit on your cock! AHHH…"
    show stripbarjelenet13v1:
        zoom 1.2
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    b "What is up Baby?"
    l "Nothing special… My neighborhood burned down…"
    b "I know! I have a business there."
    fg "He is it!"
    show szexanim5reszlizaanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    l "What kind of business?"
    l "Did you get a mission or you make your own business?"
    b "There is a guy. He gives me orders. I do not know him."
    u ""
    stop sound
    queue sound "audio/nyogrugo.ogg"
    queue sound "audio/nyogrugo.ogg"
    show stripbarjelenet13:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    show screen s2
    u ""
    b "I am searching for a red silk bag. It contains a sample of crystals."
    b "This man lent the sample to the dead guy.He wants it back now."
    show screen s2
    u ""
    stop sound
    queue sound "audio/nyog.ogg"
    queue sound "audio/nyog.ogg"
    queue sound "audio/nyog.ogg"
    show stripbarjelenet14anim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    show stripbarjelenet14animgeci:
        alpha 1.0
        pause 1.1
        alpha 0.0
    show stripbarjelenet14animgeciremeg:
        alpha 0.0
        pause 1.1
        alpha 1.0
    show screen s1e5
    u ""
    b "Aghhh! This felt good!"
    l "I am happy Honey!"
    stop sound
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    hide stripbarjelenet10
    show stripbarjelenet10
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen s1
    u ""
    l "Come out! Did you hear him?"
    f "Yeah, how can I thank you for this?"
    f "I…"
    l "I have an appointment at 11 Pm... You have to go now!"
    $ esteighatralevoido = 0
    $ lizajelenetvege5resz = True
    play music "audio/banyabolt.ogg" fadeout 1
    $ invertorinejelenyenmeg = True
    jump fojasojobb
$ renpy. pause(hard=True)
label stripbarszov2:
    $ invertorijelenyenmeg = False
    show sipbarhatuljaalap
    show sipbarhatuljabuzzy
    show sipbarhatuljakorlat onlayer hatso
    show sipbarhatuljaszemet onlayer hatso
    show sipbarhatuljaeloter onlayer kozep
    if rozsaholvan == "stripbar":
        show rozsa onlayer hatso2:
            xzoom -1.0
            zoom 0.6
            xpos 0.3
            ypos 0.37

    jump engedejek

$ renpy. pause(hard=True)
label stripbarkidobaltlimlom:
    hide screen stripbar
    f "This seems to be trash."
    show screen stripbar
$ renpy. pause(hard=True)
label buzzyvalbeszelni:
    hide screen stripbar
    show sipbarkozeeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show buzzypoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show sipbarhatuljakorlatkozeli onlayer elotte2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    if kokonalad == 0:
        if lizavalszexeltel == True:
            bu "What do you want?"
            f "Nothing at all. I am going home."
        if lizavalszexeltel == False:
            f "I know someone called Liza. She works here."
            bu "And?"
            f "Could you call her please? I have to talk to her."
            bu "I will call her, but if you tricked me, you will get in trouble, brave!"
            show buzzypoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s4
            u ""
            show anikamom onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            l "Hy Ferd! Buzzy told me, you are here."
            f "Hy! Could you help me to get inside the stripbar?"
            l "Not now. We have a closed event. They would notice you."
            show fiupoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz4 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Never mind. I have to fap at home… Not a big problem…"
            l "Wait a minute! I could find some time for you if you like…"
            show fiupoz4 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz7 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Ok, but where?"
            l "We could go behind the building… Oh it was a long time ago I had a romance there… It brings back memories…"
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide sipbarkozeeli onlayer elotte
            hide buzzypoz1 onlayer elotte
            hide fiupoz1 onlayer elotte
            hide sipbarhatuljakorlatkozeli onlayer elotte2
            hide anikamom onlayer elotte
            show lizaszex12napjelenet1 onlayer elotte
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            l "Those beautiful old times… What are you waiting for? Come on!"
            show lizaszex12napjelenet2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            l "Let us play a bit and bring back some memories! Imagine this is our first time! …Do it gently! I am a virgin! Hihihi, just kidding!"
            f "Do not worry, I will pull it out in time."
            l "Ok, I trust you. Do it!"
            show lizaszex12napjelenet3 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            l "Oh no! You did not put on any condom! Is it safe?"
            f "Do not worry! I will pull it out!"
            l "I am yours!"
            show lizaszex12napjelenet4lizav1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show lizaszex12napjelenet4fredv1 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide lizaszex12napjelenet4lizav1 onlayer elotte
            hide lizaszex12napjelenet4fredv1 onlayer elotte2
            show lizaszex12napjelenet4lizav1szajalap onlayer elotte
            show lizaszex12napjelenet4lizav1szemanim onlayer elotte
            show lizaszex12napjelenet4lizav1szaj1 onlayer elotte
            show lizaszex12napjelenet4fredgyors onlayer elotte2
            show screen s3
            u ""
            hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
            show lizaszex12napjelenet4lizav1szajanim onlayer elotte
            l "This feels nice! You do it great!"
            show lizaszex12napjelenet4lizav1szaj1 onlayer elotte
            hide lizaszex12napjelenet4lizav1szajanim onlayer elotte
            show screen s3
            u ""
            $ milyensebesegelcsinalodlizaval12napgombmelyik1 = 1
            $ milyensebesegelcsinalodlizaval12napgombmelyik2 = 0
            $ milyensebesegelcsinalodlizaval12napgombmelyik3 = 1
            show screen lizasexvaltas
            $ renpy. pause(hard=True)
            label lizaszex12naplassu:
                $ milyensebesegelcsinalodlizaval12napgombmelyik1 = 0
                $ milyensebesegelcsinalodlizaval12napgombmelyik2 = 1
                $ milyensebesegelcsinalodlizaval12napgombmelyik3 = 1
                $ milyensebesegelcsinalodlizaval12napelelvezhec = 0
                hide lizaszex12napjelenet4fredgyors onlayer elotte2
                hide lizaszex12napjelenet4fredlassub onlayer elotte2
                hide lizaszex12napjelenet4fredgyorsabb onlayer elotte2
                show lizaszex12napjelenet4fredlassub onlayer elotte2
                if milyensebesegelcsinalodlizaval12naplassu == 0:
                    $ milyensebesegelcsinalodlizaval12naplassu = 1
                    hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    show lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    l "My pussy is inexperienced. Teach it a lesson!"
                    show lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    hide lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    show screen s3
                    u ""
                    hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    show lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    l "So nice! This feels fantastic!"
                    show lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    hide lizaszex12napjelenet4lizav1szajanim onlayer elotte
                show screen s3
                u ""
                show screen lizasexvaltas
                $ renpy. pause(hard=True)
            label lizaszex12napgyors:
                $ milyensebesegelcsinalodlizaval12napgombmelyik1 = 1
                $ milyensebesegelcsinalodlizaval12napgombmelyik2 = 0
                $ milyensebesegelcsinalodlizaval12napgombmelyik3 = 1
                $ milyensebesegelcsinalodlizaval12napelelvezhec = 0
                hide lizaszex12napjelenet4fredgyors onlayer elotte2
                hide lizaszex12napjelenet4fredlassub onlayer elotte2
                hide lizaszex12napjelenet4fredgyorsabb onlayer elotte2
                show lizaszex12napjelenet4fredgyors onlayer elotte2
                if milyensebesegelcsinalodlizaval12napgors == 0:
                    $ milyensebesegelcsinalodlizaval12napgors = 1
                    hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    show lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    l "You make it great! Am I doing it right?"
                    show lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    hide lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    f "Yeah! You make all good!"
                    show screen s3
                    u ""
                    hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    show lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    l "But… This is my first time…"
                    show lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    hide lizaszex12napjelenet4lizav1szajanim onlayer elotte
                show screen s3
                u ""
                show screen lizasexvaltas
                $ renpy. pause(hard=True)
            label lizaszex12napgyorssabb:
                $ milyensebesegelcsinalodlizaval12napgombmelyik1 = 1
                $ milyensebesegelcsinalodlizaval12napgombmelyik2 = 1
                $ milyensebesegelcsinalodlizaval12napgombmelyik3 = 0
                $ milyensebesegelcsinalodlizaval12napelelvezhec = 1
                hide lizaszex12napjelenet4fredgyors onlayer elotte2
                hide lizaszex12napjelenet4fredlassub onlayer elotte2
                hide lizaszex12napjelenet4fredgyorsabb onlayer elotte2
                show lizaszex12napjelenet4fredgyorsabb onlayer elotte2
                if milyensebesegelcsinalodlizaval12napgorsabb == 0:
                    $ milyensebesegelcsinalodlizaval12napgorsabb = 1
                    hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    show lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    l "Oh yeah! That is it! Do it like that!"
                    show lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    hide lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    show screen s3
                    u ""
                    hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    show lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    l "Be careful! Hihihi!"
                    show lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                    hide lizaszex12napjelenet4lizav1szajanim onlayer elotte
                    f "Do not worry! I will pull it out in time…"
                show screen s3
                u ""
                show screen lizasexvaltas
                $ renpy. pause(hard=True)
            label lizaszex12napelevez:
                $ lizavalszexeltel = True
                show screen s2
                u ""
                show lizaszex12napjelenet6lizav1 onlayer elotte2:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show lizaszex12napjelenet6fredvgyorsabb onlayer elotte3:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1
                u ""
                hide lizaszex12napjelenet6lizav1 onlayer elotte2
                show lizaszex12napjelenet6lizav1alap onlayer elotte2
                show lizaszex12napjelenet6lizav1szemanim onlayer elotte2
                show lizaszex12napjelenet6lizav1szaj1 onlayer elotte2
                show screen s1
                u ""
                hide lizaszex12napjelenet6lizav1szaj1 onlayer elotte2
                show lizaszex12napjelenet6lizav1szajanim onlayer elotte2
                l "You are getting wild! You can not cum inside! I will get pregnant! Watch out!"
                show lizaszex12napjelenet6lizav1szaj1 onlayer elotte2
                hide lizaszex12napjelenet6lizav1szajanim onlayer elotte2
                f "There is nothing to be afraid of!"
                show screen s3
                u ""
                hide lizaszex12napjelenet6lizav1szaj1 onlayer elotte2
                show lizaszex12napjelenet6lizav1szajanim onlayer elotte2
                l "My mom will hit me if I get pregnant some way…"
                show lizaszex12napjelenet6lizav1szaj1 onlayer elotte2
                hide lizaszex12napjelenet6lizav1szajanim onlayer elotte2
                f "Just let me do it!"
                show screen s3
                u ""
                hide lizaszex12napjelenet6lizav1alap onlayer elotte2
                hide lizaszex12napjelenet6lizav1szemanim onlayer elotte2
                hide lizaszex12napjelenet6lizav1szaj1 onlayer elotte2
                show lizaszex12napjelenet6lizavfel onlayer elotte2
                show screen s2
                u ""
                hide lizaszex12napjelenet6lizavfel onlayer elotte2
                show lizaszex12napjelenet6lizav6szajalap onlayer elotte2
                show lizaszex12napjelenet6lizav6szaj1 onlayer elotte2
                show screen s2
                u ""
                hide lizaszex12napjelenet6fredvgyorsabb onlayer elotte3
                show lizaszex12napjelenet6fredvgyorsabb2 onlayer elotte3
                hide lizaszex12napjelenet6lizav6szaj1 onlayer elotte2
                show lizaszex12napjelenet6lizav6szajanim onlayer elotte2
                l "I am so scared! It is so hard! Try to stop in time!"
                show lizaszex12napjelenet6lizav6szaj1 onlayer elotte2
                hide lizaszex12napjelenet6lizav6szajanim onlayer elotte2
                f "Almost there…"
                show screen s3
                u ""
                show lizaszex12napjelenet4lizav6 onlayer elotte3:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show lizaszex12napjelenet4fredgyorsabb2 onlayer elotte4:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s3
                u ""
                hide sipbarkozeeli onlayer elotte
                hide buzzypoz1 onlayer elotte
                hide fiupoz1 onlayer elotte
                hide sipbarhatuljakorlatkozeli onlayer elotte2
                hide anikamom onlayer elotte
                hide lizaszex12napjelenet1 onlayer elotte
                hide lizaszex12napjelenet2 onlayer elotte
                hide lizaszex12napjelenet3 onlayer elotte
                show lizaszex12napjelenet4fredv1 onlayer elotte2
                hide lizaszex12napjelenet4lizav1 onlayer elotte
                hide lizaszex12napjelenet4fredv1 onlayer elotte2
                hide lizaszex12napjelenet4lizav1szajalap onlayer elotte
                hide lizaszex12napjelenet4lizav1szemanim onlayer elotte
                hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                hide lizaszex12napjelenet4fredgyors onlayer elotte2
                hide lizaszex12napjelenet4fredgyors onlayer elotte2
                hide lizaszex12napjelenet4fredlassub onlayer elotte2
                hide lizaszex12napjelenet4fredgyorsabb onlayer elotte2
                hide lizaszex12napjelenet4lizav1szaj1 onlayer elotte
                hide lizaszex12napjelenet4lizav1szajanim onlayer elotte
                hide lizaszex12napjelenet6lizav1 onlayer elotte2
                hide lizaszex12napjelenet6fredvgyorsabb onlayer elotte3
                hide lizaszex12napjelenet6lizav1szaj1 onlayer elotte2
                hide lizaszex12napjelenet6lizav1szajanim onlayer elotte2
                hide lizaszex12napjelenet6lizav1alap onlayer elotte2
                hide lizaszex12napjelenet6lizav1szemanim onlayer elotte2
                hide lizaszex12napjelenet6lizav1szaj1 onlayer elotte2
                hide lizaszex12napjelenet6lizavfel onlayer elotte2
                hide lizaszex12napjelenet6lizavfel onlayer elotte2
                hide lizaszex12napjelenet6lizav6szajalap onlayer elotte2
                hide lizaszex12napjelenet6lizav6szaj1 onlayer elotte2
                f "I can not take it anymore! I will…"
                hide lizaszex12napjelenet4lizav6 onlayer elotte3
                show lizaszex12napjelenet4lizav6szajalap onlayer elotte3
                show lizaszex12napjelenet4lizav6szajanim onlayer elotte3
                l "Oh no! Not inside!!!"
                hide lizaszex12napjelenet4lizav6szajanim onlayer elotte3
                show lizaszex12napjelenet4lizav6szaj1 onlayer elotte3
                show screen s1
                u ""
                hide lizaszex12napjelenet4fredgyorsabb2 onlayer elotte4
                show lizaszex12napjelenetremeg onlayer elotte4
                show screen s1
                u ""
                show lizaszex12napjelenet5v1 onlayer elotte4:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show lizaszex12napjelenet5szemanim onlayer elotte5:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show lizaszex12napjelenet5szaj1 onlayer elotte5:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1
                u ""
                hide lizaszex12napjelenet5v1 onlayer elotte4
                show lizaszex12napjelenet5vanim onlayer elotte4
                show screen s2
                u ""
                show lizaszex12napjelenet5vanimgeci onlayer elotte4
                show screen s2
                u ""
                hide lizaszex12napjelenet4fredv2 onlayer elotte4
                hide lizaszex12napjelenet4lizav6szajanim onlayer elotte4
                hide lizaszex12napjelenet4lizav6szaj1 onlayer elotte4
                hide lizaszex12napjelenetremeg onlayer elotte4
                hide lizaszex12napjelenet5szaj1 onlayer elotte5
                show lizaszex12napjelenet5szajanim onlayer elotte5
                l "Your penis got much thicker."
                show lizaszex12napjelenet5szaj1 onlayer elotte5
                hide lizaszex12napjelenet5szajanim onlayer elotte5
                f "Yes, I enjoyed this so much, it got biger."
                hide lizaszex12napjelenet5szaj1 onlayer elotte5
                show lizaszex12napjelenet5szajanim onlayer elotte5
                l "The first time it was the same…"
                l "This is how I got pregnant with Lidia..."
                l "I never regretted that moment. I still feel proud."
                l "Thank you Fred! You helped me to bring back old memories. I owe you one..."
                show lizaszex12napjelenet5szaj1 onlayer elotte5
                hide lizaszex12napjelenet5szajanim onlayer elotte5
                f "It was a pleasure for me."
                show sipbarkozeeli onlayer elotte5:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show anikamom onlayer elotte5:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show fiupoz6 onlayer elotte5:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show sipbarhatuljakorlatkozeli onlayer elotte6:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s2
                u ""
                l "I have to go! bye!"
                f "Bye!"
                hide lizaszex12napjelenet6fredvgyorsabb onlayer elotte3
                hide lizaszex12napjelenet6fredvgyorsabb2 onlayer elotte3
                hide lizaszex12napjelenet6lizav6szaj1 onlayer elotte2
                hide lizaszex12napjelenet6lizav6szajanim onlayer elotte2
                hide lizaszex12napjelenet4lizav6 onlayer elotte3
                hide lizaszex12napjelenet4fredgyorsabb2 onlayer elotte4
                hide lizaszex12napjelenet4lizav6 onlayer elotte3
                hide lizaszex12napjelenet4lizav6szajalap onlayer elotte3
                hide lizaszex12napjelenet4lizav6szajanim onlayer elotte3
                hide lizaszex12napjelenet4lizav6szajanim onlayer elotte3
                hide lizaszex12napjelenet4lizav6szaj1 onlayer elotte3
                hide lizaszex12napjelenet4fredgyorsabb2 onlayer elotte4
                hide lizaszex12napjelenetremeg onlayer elotte4
                hide lizaszex12napjelenet5v1 onlayer elotte4
                hide lizaszex12napjelenet5szemanim onlayer elotte5
                hide lizaszex12napjelenet5szaj1 onlayer elotte5
                hide lizaszex12napjelenet5vanim onlayer elotte4
                hide lizaszex12napjelenet5vanimgeci onlayer elotte4
                hide lizaszex12napjelenet5szaj1 onlayer elotte5
                hide lizaszex12napjelenet5szajanim onlayer elotte5
                show anikamom onlayer elotte5:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1
                u ""
                show buzzypoz1 onlayer elotte5:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1
                u ""
                bu "Go away kid!"
                f "I am leaving now! Take it easy!"
                hide fiupoz7 onlayer elotte
                show sipbarkozeeli onlayer elotte5:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz6 onlayer elotte5:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show sipbarhatuljakorlatkozeli onlayer elotte6:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show buzzypoz1 onlayer elotte5:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1
                u ""
                show screen stripbar
                hide anikamom onlayer elotte5
                hide sipbarkozeeli onlayer elotte5
                hide fiupoz6 onlayer elotte5
                hide sipbarhatuljakorlatkozeli onlayer elotte6
                hide buzzypoz1 onlayer elotte5

                $ renpy. pause(hard=True)



    if kokonalad == 1:
        $ kokonalad = 0
        f "Hy! I am Fred. What is your name?"
        bu "Tickets please! Did you bring me something? Who cares about names at all?"
        f "What is your name?"
        bu "I am Buzzy. We have gay porn night only on next Friday. Are you a dancer? You seem to be too fat…"
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I am not homosexual. I brought something for you."
        bu "Fine! Give it to me and go away!Do not hold the line!"
        show fiupoz2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        show fiupoz1csakszemanimkovetidebrat2 onlayer elotte
        show screen s1
        u ""
        f "What kind of line? I see nobody here…"
        hide fiupoz1csakszemanimkovetidebrat2 onlayer elotte
        bu "Just go away!"
        f "Could you let me in please?"
        bu "Ticket please! Do you have money?"
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz6 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "Nope. I know someone inside, her name is L…."
        bu "Scram, kid!"
        $ rozsaholvan = "stripbar"
        show rozsa onlayer hatso2:
            xzoom -1.0
            zoom 0.6
            xpos 0.3
            ypos 0.37
        show sipbarkozeeli onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show buzzypoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz6 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show sipbarhatuljakorlatkozeli onlayer elotte2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        show screen stripbar
        $ renpy. pause(hard=True)





    show sipbarkozeeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show buzzypoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show sipbarhatuljakorlatkozeli onlayer elotte2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen stripbar
$ renpy. pause(hard=True)

label rozsivalbeszelnistripbar:
    hide screen stripbar
    hide fiupoz1 onlayer elotte
    show sipbarkozeeli2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show rozsapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "Hy! Why are you here?"
    ro "This is a nice club, you know. It is hard to get inside..."
    f "Ok… but why are you by the backdoor?"
    ro "I am waiting for the admission test here. They will call me..."
    ro "Please stop talking to me. I have to concentrate and repeat the exam items..."
    f "…Ok…"
    $ debraholcsinal = "sulosoba"
    show sipbarkozeeli2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show rozsapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide sipbarkozeeli2 onlayer elotte
    hide rozsapoz1 onlayer elotte
    hide fiupoz1 onlayer elotte
    show screen stripbar
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
