label leegethaz:
    f "I can not go there! The police closed the place..."
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
