label furdo:
    if korbenezni == False:
        $ furdo = True
        if fojasojobb and furdo == True:
            $ korbenezni = True
    if hanyadiknapvan == 1:
        if wcremehetek == True:
            $ fekete = True
            $ kivelbeszelsz = "wcajto"
            jump tiltasok
    if hanyadiknapvan == 2:
        if debraholcsinal == "furdo":
            $ fekete = True
            $ kivelbeszelsz = "wcajto"
            jump tiltasok
    if hanyadiknapvan == 4:
        if dagitmegharaptafifi == 1:
            f "Grandma is inside, I can not go in!"
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 5:
        if regell5resz == True:
            $ fekete = True
            $ kivelbeszelsz = "wcajto"
            jump tiltasok

    if hanyadiknapvan == 7:
        if debraholcsinal == "furdobenbenyitolra7nap":
            jump furdobenbenyitolra7nap
    if hanyadiknapvan == 8:
        if debraholcsinal == "furdo":
            $ fekete = True
            $ kivelbeszelsz = "wcajto"
            jump tiltasok



    $ holvagyok = "furdo"
    jump tiltasok
label furdoszov:
    show furdo
    show furdomosogep
    if esteighatralevoido == 0:
        show furdoeste
    if locsolokannafel == True:
        play sound "audio/csepp.wav"
    if locsolokannafel == False:
        show locsolokanna
    if viragokmegontozese == True:
        show locsolokanna
    if hanyadiknapvan == 4:
        if jobboldaliszomszed == 1:
            jump negyediknapvegefurdo
    if hanyadiknapvan == 5:
        hide locsolokanna
        if debraafurdoben5resz == 0:
            show debraafurdoben5resz
    if hanyadiknapvan == 6:
        if debraholcsinal == "furdo2":
            show debrabudittakaritmozanim
            show debrabudittakaritanim
        if debrafulbevalo1 == 0:
            show anyakereszt1:
                zoom 0.5
                xpos 0.34
                ypos 0.46
            if debrafulbevalotmegkeresni1 == 1:
                show csillogaskicsianim:
                    xpos 0.337
                    ypos 0.455
    if hanyadiknapvan == 7:
        if debraholcsinal == "nap7vegjelenetafurdoben":
            show nap7a32mozanim
            hide furdomosogep onlayer elotte
            show furdomosogep

    if sanyiholvan == "furdoben":
        show sanyialap:
            xzoom -1.0
            xpos 0.35
            ypos 0.22
        if hanyadiknapvan == 11:
            $ fekete = True
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            show furdokozeli onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show sanyipoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            f "Did you arrive now?"
            sa "Nope. I am finished."
            f "Did you repair it?"
            sa "Yes. I had to clean it only. Nothing special. You have a nice Grandmother.She let me in, she was really kind to me."
            f "She is nice to every single young man... She is not my Grandmother, but I call her that way..."
            sa "This is not my business. I have to go now."
            f "Here is your money."
            $ penz -= 3000
            sa "See you later!"
            $ holvanliza = "sehol"
            $ ciliholvan = "sehol"
            hide sanyialap
            $ sanyiholvan = "sehol"
            $ mosogepjo = True
            show furdokozeli onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show sanyipoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
    jump engedejek
$ renpy. pause(hard=True)
label debrafurdobevissza:
    $ debrafurdoban = False
    hide debrasopor
    show debrasopor:
        zoom 0.8
        xalign 0.52
        yalign 0.65
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label debrafurdobevissza2:
    $ debrafurdoban = False
    hide debrafelmos
    show debrafelmos:
        zoom 0.4
        xpos 0.33
        ypos 0.55
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label mosogepszov:
    if hanyadiknapvan >= 7:
        if ruhakosarnaladtelemijenruhaval == "vizes":
            jump mosolvalami2
    if hanyadiknapvan == 11:
        if oroszruha == "koszos":
            f "I need washing powder."
            $ renpy. pause(hard=True)
        if oroszruha == "vizes":
            if mosogepjo == False:
                f "The drying machine should be repaired. It does not dry the clothes."
            if mosogepjo == True:
                hide screen furdo
                $ oroszruha = "tiszta"
                play sound "audio/mos.wav"
                f "I can use it now."
                if oroszultanultal == True:
                    if oroszruha == "tiszta":
                        if ragasztonalad == 1:
                            $ invertorinejelenyenmeg = True
                            f "I can dress in now. I will do it."
                            jump beoltozikfred11nap

                show screen furdo
            $ renpy. pause(hard=True)

    f "A nice washing machine. I can use it easily."
$ renpy. pause(hard=True)
label mosodazagynemut:
    if mosopor == True:
        play sound "audio/mos.wav"
        $ agynemukosos = True
        f "I love this washing machine! I just started the wash and it is ready asap!"
    else:
        f "I need washing powder."
$ renpy. pause(hard=True)
label mosolvalami:
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    if mosopor == True:
        if mijenszenyesvannalad == "sajatom":
            play sound "audio/mos.wav"
            $ mijenszenyesvannalad = "semilyen"
            $ mosopor = False
            $ szenyeskimosva = True
            f "I love this washing machine! I just started the wash and it is ready asap!"
        if mijenszenyesvannalad == "debrajeke":
            if hanyadiknapvan == 7:
                label mosolvalami2:
                if ruhakosarnaladtelemijenruhaval == "vizes":
                    f "This won’t work. The dryer is broken."
                if ruhakosarnaladtelemijenruhaval == "koszos":
                    play sound "audio/mos.wav"
                    $ mijenszenyesvannalad = "semilyen"
                    $ mosopor = False
                    $ szenyesnalad = False
                    $ szaritojo = False
                    $ ruhakosarnaladtelemijenruhaval = "vizes"
                    if kiteritesiproba == 0:
                        f "The clothes are full of water. The machine did not dry them out."
                    if kiteritesiproba == 3:
                        f "The clothes are clean. I can spread out the clothes now."
    else:
        f "I need washing powder."

    if hanyadiknapvan == 11:
        if oroszruha == "koszos":
            $ oroszruha = "vizes"
            $ mosopor = False
            $ szenyesnalad = False
            $ mosogepetmegkeljavitani = 1
            hide screen furdo
            play sound "audio/mos.wav"
            f "It is clean but still wet. I can not dress in it yet."
            f "I should dry the dress, but fast. No time to use the clothes dryer..."
            show screen furdo
$ renpy. pause(hard=True)
label furdoszekreny:
    if hanyadiknapvan == 9:
        if debraszivacsotestisztitoszertker9resz == True:
            if szivacsnalad == 0:
                $ szivacsnalad = 1
                f "Oh cool! I have the sponge."
                $ renpy. pause(hard=True)
    if hanyadiknapvan == 7:
        if oblitosuveg == 1:
            $ oblitosuveg = 2
            f "The rinse aid will do. It is ropy and slippery enough."
            $ renpy. pause(hard=True)
    if hanyadiknapvan >= 3:
        if szenyesnalad == True:
            if szenyeskimosva == False:
                if mosopor == False:
                    $ mosopor = True
    if agynemukaptal == True:
        if agynemukosos == False:
            if mosopor == False:
                $ mosopor = True
            else:
                f "Washing powder and cleaning stuff are stored here."
        else:
            f "Washing powder and cleaning stuff are stored here."
    else:
        f "Washing powder and cleaning stuff are stored here."
$ renpy. pause(hard=True)
label furdoszekreny2:
    if hanyadiknapvan == 2:
        if fifitfelvetem == True:
            f "I got Fifi in my pocket, I can not take up anything while she is here."
            f "Washing powder and cleaning stuff are stored here."
            $ renpy. pause(hard=True)
        $ torloszivacsnalad = True
        $ mosopor = True
    if hanyadiknapvan == 5:
        $ torloszivacsnalad = True
        f "I pick up the sponge before I leave."
        d "Ok, just hurry a bit!"
$ renpy. pause(hard=True)
label locsolokannafel:
    $ locsolokannafel = True
    show locsolokanna:
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label locsolfurdo:
    play sound "audio/viz13.wav"
    $ locsolokannaviz -= 1
    $ viragokmegontozve += 1
    $ furdovirag = True
    if furdovirag == True:
        if fojasoballvirag == True:
            if fojasojobbvirag == True:
                if napalivirag == True:
                    if atjarovirag == True:
                        if atjarovirag2 == True:
                            if furdovirag == True:
                                if atjarovirag3 == True:
                                    $ viragokmegontozese = True
$ renpy. pause(hard=True)
label elsonapvegefele:
    hide invertori onlayer elotte6
    hide screen invertori2
    if hanyadiknapvan == 5:
        if felvetedaszivacsot == 1:
            jump wcbeles3
    if hanyadiknapvan == 8:
        jump wcbeles3
    show screen leskelodes
$ renpy. pause(hard=True)
label wcbenyit:
    play music "audio/szexy.ogg" fadeout 1
    hide screen leskelodes
    hide screen invertori2
    hide invertori onlayer elotte6
    play sound "audio/ajto4.wav"
    show benyitjel1
    pause 0.5
    show benyitjel2:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    show benyitpan1:
        alpha 0.0
        linear 0.5 alpha 1.0
    pause 0.84
    show benyitpan2:
        alpha 0.0
        linear 0.5 alpha 1.0
    pause 0.84
    show benyitjel5:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    d "What are you doing?"
    f "I am sorry!!!"
    hide benyitjel1
    hide benyitjel2
    hide benyitpan1
    hide benyitpan2
    show benyitjel5:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen invertori2
    show invertori onlayer elotte6:
        ypos 0.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    play sound "audio/ajto4.wav"
    pause 2.0
    f "This was worth it… but i need to pee, still."
    hide screen invertori2
    hide invertori onlayer elotte6
    play music "audio/banyabolt.ogg" fadeout 1
    $ hanyadiknapvan = 2
    $ alvas += 1
    $ locsolokannafel = False
    $ szendvicsinvertoriba = False
    $ debraholcsinal = "napaliban2"
    $ debravalamitcsinalido = 60
    $ esteighatralevoido = 800
    $ mosopor = False
    $ fekete = True
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show text "{b}{size=+10}End Of Day 1" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    pause 3.0
    hide text onlayer screens
    hide screen vege
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    jump atjaro
$ renpy. pause(hard=True)
label wcbeles:
    play music "audio/szexy.ogg" fadeout 1
    hide screen leskelodes
    hide screen invertori2
    hide invertori onlayer elotte6
    if kukucska == 5:
        $ kukucska = 1
    if kukucska == 4:
        $ kukucska = 5
        show debrakadbanpislog
        show debrakadbanpislogcsepeg
        u ""
        hide debrakadbanpislog
        hide debrakadbanpislogcsepeg
    if kukucska == 3:
        $ kukucska = 4
        show kukucskamosamagat
        u ""
        hide kukucskamosamagat
    if kukucska == 2:
        $ kukucska = 3
        show kulcsjukseg
        show kukucskasegcsepeg
        u ""
        hide kulcsjukseg
        hide kukucskasegcsepeg
    if kukucska == 1:
        $ kukucska = 2
        show furdikmemoz
        u ""
        hide furdikmemoz
    show screen leskelodes
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    play music "audio/banyabolt.ogg" fadeout 1
$ renpy. pause(hard=True)
label wcbeles2:
    play music "audio/szexy.ogg" fadeout 1
    hide screen leskelodes
    hide screen invertori2
    hide invertori onlayer elotte6
    show furdos onlayer elotte6
    show furdobubi1anim onlayer elotte6
    show furdobubi2anim onlayer elotte6
    show furdobubi3anim onlayer elotte6
    show kulcsjuk2 onlayer elotte6
    show screen s2
    u ""
    queue sound "audio/paff.wav"
    hide furdos onlayer elotte6
    hide furdobubi1anim onlayer elotte6
    hide furdobubi2anim onlayer elotte6
    hide furdobubi3anim onlayer elotte6
    hide kulcsjuk2 onlayer elotte6
    show fiuparnavalmegdobjelenet3 onlayer elotte6
    with vpunch
    show screen s2
    m "What are you doing there?"
    hide fiuparnavalmegdobjelenet3 onlayer elotte6
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    play music "audio/banyabolt.ogg" fadeout 1
    jump engedejek
$ renpy. pause(hard=True)
label wcbeles3:
    play music "audio/szexy.ogg" fadeout 1
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    hide nappalitv onlayer elotte6
    show nappalitv
    if debrafurdik == True:
        if kukucska == 5:
            $ kukucska = 1
        if kukucska == 4:
            $ kukucska = 5
            show debrakadbanpislog
            show debrakadbanpislogcsepeg
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            u ""
            hide debrakadbanpislog
            hide debrakadbanpislogcsepeg
        if kukucska == 3:
            $ kukucska = 4
            show kukucskamosamagat
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            u ""
            hide kukucskamosamagat
        if kukucska == 2:
            $ kukucska = 3
            show kulcsjukseg
            show kukucskasegcsepeg
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            u ""
            hide kulcsjukseg
            hide kukucskasegcsepeg
        if kukucska == 1:
            $ kukucska = 2
            show furdikmemoz
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            u ""
            hide furdikmemoz
        show nappalitv onlayer elotte6
        show screen invertori
        show invertori onlayer elotte6:
            yalign 0.0
        play music "audio/banyabolt.ogg" fadeout 1
        jump engedejek
    show debrafurdoben5reszbelesanim
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    if felvetedaszivacsot == 1:
        $ felvetedaszivacsot = 2
        $ debrafurdik = True
        f "Let me in! I forgot to take the sponge. I need it to clean up the dirt."
        d "Lick it up! Stupid! I won't let you in! I am naked!"
        f "Just throw it out!"
        d "I won't!"
        f "But I need it!"
        d "Go and buy a new one!"
        f "Ok, but I did not get my pocket money today."
        d "My husband gave you money! Do not try to trick me! You are rich!"
        f "Well... ok, I will go now."
        hide debrafurdoben5reszbelesanim
        show screen invertori2
        show invertori onlayer elotte6:
            yalign 0.0
        jump engedejek
    u ""
    if felvetedaszivacsot == 0:
        if debrafurdik == False:
            show screen debrafurdenikezd
    hide debrafurdoben5reszbelesanim
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    show nappalitv onlayer elotte6
    hide nappalitv
    play music "audio/banyabolt.ogg" fadeout 1
    jump engedejek
$ renpy. pause(hard=True)
label wczek:
    $ screentiltas = True
    $ furdoszov = 1
    jump tiltasok
label wczekszov:
    $ wczett += 1
    if hanyadiknapvan == 3:
        $ isztaruhafel = 1
        $ taskafel = 1
    play sound "audio/hugy.wav"
    show fredpisil onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    f "Oh this felt good!"
    $ fekete = True
    show fredpisil onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    if hanyadiknapvan == 3:
        f "I should change my dresses and pick up my bag before i leave!"
    stop sound
    jump engedejek
$ renpy. pause(hard=True)
label negyediknapvegefurdo:
    play music "audio/szexy.ogg" fadeout 1
    show felmosodebramogott:
        zoom 0.8
        xpos 0.13
        ypos 0.15
    show debraall:
        zoom 0.8
        xpos 0.13
        ypos 0.15
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 2.0
    show felmosodebramogott:
        zoom 0.8
        xpos 0.13
        ypos 0.15
        alpha 1.0
        linear 0.5 alpha 0.0
    show debraall:
        zoom 0.8
        xpos 0.13
        ypos 0.15
        alpha 1.0
        linear 1.0 alpha 0.0
    hide debrapoz4
    show debrapoz4:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz2 onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "I am here! What do you wish?"
    d "Do you have any idea, who peed next to the toilet?"
    f "I think ...... it was ...... Puffy!"
    d "Nice try! Catch the ragged mop and clean it! Do not make any dirt!"
    d "Watch out! I had washed the tiles just now."
    f "Ok, I will watch out..."
    pause 1.0
    show final4reszdebraraesnek1 onlayer elotte:
        alpha 0.0
        linear 0.5 alpha 1.0
    play sound "audio/paff.wav"
    show screen s1
    f "Aghhh!!!"
    play sound "audio/paff.wav"
    show final4reszdebraraesnek2alap onlayer elotte:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek2csicsianim onlayer elotte2:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek2dszaj1 onlayer elotte:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek2dszemanim onlayer elotte:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek2fszaj1 onlayer elotte:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek2fszemanim onlayer elotte:
        alpha 0.0
        linear 0.5 alpha 1.0
    with vpunch
    pause 2.0
    hide final4reszdebraraesnek2dszaj1 onlayer elotte
    show final4reszdebraraesnek2dszajanim onlayer elotte
    d "What are you doing?"
    show final4reszdebraraesnek2dszaj1 onlayer elotte
    hide final4reszdebraraesnek2dszajanim onlayer elotte
    hide final4reszdebraraesnek2fszaj1 onlayer elotte
    show final4reszdebraraesnek2fszajanim onlayer elotte
    f "I slipped and fell. I try to get up now..."
    show final4reszdebraraesnek2fszaj1 onlayer elotte
    hide final4reszdebraraesnek2fszajanim onlayer elotte
    u ""
    hide final4reszdebraraesnek2dszaj1 onlayer elotte
    show final4reszdebraraesnek2dszajanim onlayer elotte
    d "Ok, But could you stop grabbing my boobs? Get off me! Pervert!"
    show final4reszdebraraesnek3alap onlayer elotte2:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek3dszemanim onlayer elotte2:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek3dszaj1 onlayer elotte2:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek3csecse onlayer elotte3:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek3dorzsianim onlayer elotte3:
        alpha 0.0
        linear 0.5 alpha 1.0
    pause 1.0
    f "I try but I slip again and again!"
    hide final4reszdebraraesnek1 onlayer elotte
    hide final4reszdebraraesnek2alap onlayer elotte
    hide final4reszdebraraesnek2csicsianim onlayer elotte
    hide final4reszdebraraesnek2dszaj1 onlayer elotte
    hide final4reszdebraraesnek2dszemanim onlayer elotte
    hide final4reszdebraraesnek2fszaj1 onlayer elotte
    hide final4reszdebraraesnek2fszemanim onlayer elotte
    hide final4reszdebraraesnek2alap onlayer elotte
    hide final4reszdebraraesnek2csicsianim onlayer elotte2
    hide final4reszdebraraesnek2dszaj1 onlayer elotte
    hide final4reszdebraraesnek2dszemanim onlayer elotte
    hide final4reszdebraraesnek2fszemanim onlayer elotte
    hide final4reszdebraraesnek2dszajanim onlayer elotte
    hide final4reszdebraraesnek2dszaj1 onlayer elotte
    hide final4reszdebraraesnek2dszajanim onlayer elotte
    hide final4reszdebraraesnek2fszaj1 onlayer elotte
    hide final4reszdebraraesnek2fszajanim onlayer elotte
    hide final4reszdebraraesnek3dszaj1 onlayer elotte2
    show final4reszdebraraesnek3dszajanim onlayer elotte2
    d "Get off! This is getting uncomfortable!"
    show final4reszdebraraesnek3dszaj1 onlayer elotte2
    hide final4reszdebraraesnek3dszajanim onlayer elotte2
    f "For me as well. Sorry! Just a little bit more…"
    u ""
    show final4reszdebraraesnek4alap onlayer elotte3:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek4szemanim onlayer elotte3:
        alpha 0.0
        linear 0.5 alpha 1.0
    show final4reszdebraraesnek4szajanim onlayer elotte3
    show final4reszdebraraesnek4fiuanim onlayer elotte3
    show screen s3
    u ""
    dg "He is rubbing his penis... It is getting hard... I think he knows what he is doing... He is playing with me! This is enough!"
    show final4reszanim1 onlayer elotte3
    show screen s25
    u ""
    play sound "audio/ut.wav"
    show screen s1
    d "Pervert!"
    show final4reszanim2 onlayer elotte3
    play sound "audio/ut2.wav"
    show screen s1
    d "Pig!"
    show screen s05
    u ""
    queue sound "audio/ut.wav"
    queue sound "audio/ut3.wav"
    show final4reszanim3 onlayer elotte3
    show screen s1
    d "Here you go!"
    queue sound "audio/elesik.wav"
    play music "audio/banyabolt.ogg" fadeout 1
    pause 1.0
    show fredkiutve4resz onlayer elotte3:
        yalign 1.0
        xalign 0.5
        zoom 0.8
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    hide locsolokanna
    hide screen vege
    show screen s1
    u ""
    show text "{b}{size=+10}End Of Day 4" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    pause 3.0
    hide text onlayer screens
    hide final4reszanim1 onlayer elotte3
    hide final4reszanim2 onlayer elotte3
    hide final4reszanim3 onlayer elotte3
    hide final4reszdebraraesnek4alap onlayer elotte3
    hide final4reszdebraraesnek4szemanim onlayer elotte3
    hide final4reszdebraraesnek4szajanim onlayer elotte3
    hide final4reszdebraraesnek4fiuanim onlayer elotte3
    hide final4reszdebraraesnek3alap onlayer elotte2
    hide final4reszdebraraesnek3dszemanim onlayer elotte2
    hide final4reszdebraraesnek3dszaj1 onlayer elotte2
    hide final4reszdebraraesnek3csecse onlayer elotte3
    hide final4reszdebraraesnek3dorzsianim onlayer elotte3
    hide felmosodebramogott
    hide debraall
    hide debrapoz4
    hide fiupoz2 onlayer elotte
    hide furdoeste
    show fekete onlayer elotte
    hide furdomosogep onlayer elotte
    show debraafurdoben5resz
    show furdomosogep
    show otodiknapregele
    show fredkiutve4resz onlayer elotte3:
        yalign 1.0
        xalign 0.5
        zoom 0.8
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show fekete onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ debraholcsinal = "sehol"
    $ esteighatralevoido = 50000
    $ fekete = True
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ szenyesafoldon = True
    $ poharnalad = False
    $ fifitfelvetem = False
    $ baloldaliszomszed = 0
    $ jobboldaliszomszed = 0
    $ hanyadiknapvan += 1
    $ taskafel = 1
    $ torloszivacsnalad = False
    $ dolgozolmosogatasido = 30
    $ dolgozoltakaritido = 20
    $ dolgozoltakaritelteltido = 0
    $ szivacskoszoslett = 0
    pause 1.0
    hide fekete onlayer elotte
    d "Wake up! I want to take a shower! Get out of here!"
    d "Fifi had left a surprise package in your room."
    d "You find the trash bag under the kitchen sink."
    d "Grandma and Fifi went to the club. They have card party every Wednesday. "
    d "I made your food and bought you a bottle of cola. Just pick them up in the kitchen."
    d "Do not forget to buy me a new mop! The old one broke yesterday."
    d "Get up and get out!"
    show otodiknapregele:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
$ renpy. pause(hard=True)
label debratmegtapizod5resz:
    $ furdoszov = 2
    $ screentiltas = True
    jump tiltasok
label debratmegtapizod5reszszov:
    show screen leskelodes
    $ renpy. pause(hard=True)
label megfogdosoddebrat5resz:
    hide screen invertori2
    hide invertori onlayer elotte6
    play music "audio/baszosalap.ogg" fadeout 1
    hide ferdkezebal
    hide ferdkezejobb
    hide debramergesenhatranez
    hide ferdkiutveafurdoben5resz
    show ferdkiutveafurdoben5resz:
        alpha 0.0
        xpos 0.05
        pause 2.0
        alpha 1.0
    hide furdomosogep
    show furdomosogep:
        alpha 0.0
        pause 2.0
        alpha 1.0
    show debramergesenhatranez:
        alpha 0.0
        linear 1.0 alpha 1.0
    show ferdkezebal:
        alpha 0.0
        pause 1.0
        alpha 1.0
        parallel:
            xpos -0.25
            linear 4.0 xpos 0.0
        parallel:
            ypos -0.2
            linear 4.0 ypos 0.0
    show ferdkezejobb:
        alpha 0.0
        pause 1.0
        alpha 1.0
        parallel:
            xpos 0.15
            linear 4.0 xpos 0.0
        parallel:
            ypos 0.4
            linear 4.0 ypos 0.0
    show screen s5
    u ""
    queue sound "audio/paff.wav"
    hide feketefeher
    show feketefeher:
        pause 1.0
        alpha 1.0
        pause 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    play music "audio/banyabolt.ogg" fadeout 1
    hide ferdkezebal
    hide ferdkezejobb
    hide debramergesenhatranez
    pause 3.0
    if debratprobalodmegfogdosni == 4:
        $ debratprobalodmegfogdosni = 1
    if debratprobalodmegfogdosni == 3:
        $ debratprobalodmegfogdosni = 4
        d "I like the way you never learn things!"
        f "HGGGGGGGGRRRR......."
    if debratprobalodmegfogdosni == 2:
        $ debratprobalodmegfogdosni = 3
        d "Don't you dare to try this again!"
        f "Aaaaaaah....."
    if debratprobalodmegfogdosni == 1:
        $ debratprobalodmegfogdosni = 2
        d "What did you want to do?"
        f "HHHOOOOOGGGG....."
    show ferdkiutveafurdoben5resz:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
label beszelszdebraval5reszfurdo:
    if debravalbeszed == 4:
        $ debravalbeszed = 1
    if debravalbeszed == 3:
        $ debravalbeszed = 4
        f "What is the surprise?"
        d "Go and check it!"
    if debravalbeszed == 2:
        $ debravalbeszed = 3
        d "Get out. I won't dress off while you are looking at me."
        f "I do not mind! I saw women naked!"
        d "Get out of here, or I will kick your ass!"
    if debravalbeszed == 1:
        $ debravalbeszed = 2
        f "What happened yesterday?"
        d "Go away! Nothing happened!"
    jump engedejek
$ renpy. pause(hard=True)
label debrafurdobenbudittakarit:
    $ debratmegnezed = "budittakaritani"
    $ fekete = True
    jump tiltasok
$ renpy. pause(hard=True)
label debrafurdobenbudittakaritszov:
    hide screen invertori2
    hide invertori onlayer elotte6
    hide furdomosogep onlayer elotte
    show furdomosogep
    show debrasegge6resz:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    if debravalbeszed >= 4:
        $ debravalbeszed = 1
    if debravalbeszed == 3:
        $ debravalbeszed = 4
        d "I do not have time for you. I need to hurry."
    if debravalbeszed == 2:
        $ debravalbeszed = 3
        d "I don't have time. Scram!"
    if debravalbeszed == 1:
        $ debravalbeszed = 2
        d "Do you have any work to do?"
    show debrasegge6resz:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    hide debrasegge6resz
    $ debratmegnezed = "nemnezed"
    hide furdomosogep
    show furdomosogep onlayer elotte
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
$ renpy. pause(hard=True)
label anyakereszt1fel:
    $ debrafulbevalo1 = 1
    show anyakereszt1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show csillogaskicsianim:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label nap7szexjelenetdebra:
    hide screen furdo
    if oblitosuveg == 1:
        f "I have to find something slippery to put it on Debra's waist."
    if oblitosuveg == 0:
        play music "audio/szexy.ogg" fadeout 1
        hide furdomosogep onlayer elotte
        show furdomosogep
        hide screen invertori
        hide invertori onlayer elotte6
        show nap7a29:
            alpha 0.0
            linear 1.0 alpha 1.0
        $ oblitosuveg = 1
        show screen s1
        u ""
        f "What are you doing in the washing machine Debra?"
        d "I am stuck! Oh fuck!"
        f "Did you try to repair the machine?"
        d "Sure, idiot!"
        show nap7a30:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "What are you doing there?"
        d "The bra holder iron got stuck there and I crept in to take it off…"
        d "I could creep in, but when I tried to creep out, I got stuck. The rubber ring holds me tight. Fuck that damn washing machine!"
        show nap7a30:
            alpha 1.0
            linear 1.0 alpha 0.0
        f "I will help you! I will try to pull you out! "
        show nap7a31v1:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I will count … 1…2….3….!!!"
        f "Oh Shit! It does not move…"
        show nap7a31v2:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I can not pull you out."
        hide nap7a30
        show nap7a30:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Go and find something to make my waist slippery! Hurry! I have no air in here!"
        hide nap7a29
        hide nap7a31v1
        hide nap7a31v2
        show nap7a30:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        show screen invertori
        show invertori onlayer elotte6:
            yalign 0.0
    if oblitosuveg == 2:
        play music "audio/szexy.ogg" fadeout 1
        $ oblitosuveg = 3
        hide furdomosogep onlayer elotte
        show furdomosogep
        hide screen invertori
        hide invertori onlayer elotte6
        show nap7a33:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "I am putting rinse aid on you."
        d "That is good, just hurry! I get claustrophobic!"
        fg "Ok, just a little bit more on side… I get really horny from this... Will she notice if I just put my dick here?"
        hide nap7a30
        show nap7a30:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Hurry!"
        show nap7a34:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        d "Start pulling me!"
        f "Just a minute, my hands got all slippery…"
        fg "She did not notice my cock between her ass!"
        show nap7a35hatter:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7a35segg1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7a35mosogep onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 0.8
        show nap7a35seggfeje onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7a35seggszaj1 onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7a35szemanim onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        show nap7a35segganim
        hide nap7a35segg1
        show screen s1
        u ""
        f "Ok, let us go!"
        hide nap7a35seggszaj1 onlayer hatso1
        show nap7a35szajanim onlayer hatso1
        d "Yeah! Hurry! I get no air!"
        show nap7a35seggszaj1 onlayer hatso1
        hide nap7a35szajanim onlayer hatso1
        f "I will try my best! Your body got all ropy and slippery."
        hide nap7a35seggszaj1 onlayer hatso1
        show nap7a35szajanim onlayer hatso1
        d "Why are you not holding me with your hands?"
        show nap7a35seggszaj1 onlayer hatso1
        hide nap7a35szajanim onlayer hatso1
        f "I need to wipe my hands a bit. I can not hold you strong enough."
        hide nap7a35seggszaj1 onlayer hatso1
        show nap7a35szajanim onlayer hatso1
        d "I do not care! Just pull me out! It feels like shit here!"
        show nap7a35seggszaj1 onlayer hatso1
        hide nap7a35szajanim onlayer hatso1
        u ""
        show nap7a36 onlayer hatso1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        hide nap7a36 onlayer hatso1
        show nap7a36
        hide nap7a33
        hide nap7a34
        hide nap7a35hatter
        hide nap7a35segg1
        hide nap7a35mosogep onlayer hatso
        hide nap7a35seggfeje onlayer hatso1
        hide nap7a35seggszaj1 onlayer hatso1
        hide nap7a35szemanim onlayer hatso1
        f "I should find the perfect place to grab you..."
        u ""
        show nap7a37alap:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7a37szemanim:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7a37gep onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7a37segg1 onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "Let us try this way…"
        hide nap7a37segg1 onlayer hatso
        show nap7a37segganim onlayer hatso
        u ""
        dg "What is he doing? Is he pulling me? "
        u ""
        dg "I have to get out of here! Fast!"
        u ""
        f "We need a bit more rinse aid… Oh yeah! That is it!"
        u ""
        show nap7a38 onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        show nap7a38spermaanim onlayer hatso
        show screen s3
        u ""
        show nap7a31v2 onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "It should work now!"
        show nap7a31v1 onlayer hatso:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "Huuummmppp…"
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        queue sound "audio/kicsuppan.wav"
        queue sound "audio/elesik2.ogg"
        show screen s1
        u ""
        show nap7a39 onlayer hatso
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        with vpunch
        show screen s1
        u ""
        d "At least! I thought I had to stay there all night long."
        f "I made it at the end."
        d "What kind of an end?"
        f "Theee… end of the day… I guess…"
        d "I have to clean my clothes and my body. The rinse aid is all around… Strange... This rinse aid smells like… Semen…"
        f "I have to go now! Bye bye!"
        $ invertorinejelenyenmeg = True
        play music "audio/banyabolt.ogg" fadeout 1
        jump atjaro
        $ renpy. pause(hard=True)
    play music "audio/banyabolt.ogg" fadeout 1
    show screen furdo
$ renpy. pause(hard=True)
label furdobenbenyitolra7nap:
    $ debraholcsinal = "napaliban3"
    play music "audio/szexy.ogg" fadeout 1
    hide screen nappali
    hide screen invertori
    hide invertori onlayer elotte6
    hide nappalitv onlayer elotte6
    show nappalitv
    show nap7f5alap
    show nap7f5debraszaj1
    show nap7f5debraszemanim
    show nap7f5debramozanim
    show nap7f5ferd1
    show screen s1
    u ""
    show nap7f5ferd1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show nap7f5ferd2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show nap7f5fredszaj1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide nap7f5fredszaj1
    show nap7f5fredszajanim
    f "Why did you not close the door?"
    show nap7f5fredszaj2
    hide nap7f5fredszajanim
    show nap7f5debraszajanim
    hide nap7f5debraszaj1
    d "Why did you not knock on the door?"
    hide nap7f5fredszaj2
    show nap7f5fredszajanim
    hide nap7f5debraszajanim
    show nap7f5debraszaj5
    f "I was in a hurry… I need to wash the clothes again…"
    show nap7f5fredszaj2
    hide nap7f5fredszajanim
    show nap7f5debraszajanim
    hide nap7f5debraszaj5
    d "Shut up and go out! Do not explain to me your whole life now!"
    hide nap7f5debraszajanim
    show nap7f5debraszaj5
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    show screen s2
    u ""
    hide nap7f5alap
    hide nap7f5debraszaj1
    hide nap7f5debraszemanim
    hide nap7f5fredszaj1
    hide nap7f5debramozanim
    hide nap7f5debraszaj1
    hide nap7f5fredszaj2
    hide nap7f5fredszajanim
    hide nap7f5debraszajanim
    hide nap7f5debraszaj5
    hide nap7f5ferd2
    show debratvnezalap
    show debratvnezpislog
    show screen perc10
    show screen s2
    u ""
    hide screen perc10
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show nappalitv onlayer elotte6
    hide nappalitv
    play music "audio/banyabolt.ogg" fadeout 1
    show screen nappali
$ renpy. pause(hard=True)
label debratorolkozofurdo:
    hide screen furdo
    f "A towel. I do not need it."
    if hanyadiknapvan == 7:
        if pulinapozoagya >= 1:
            if pulinapozoagya < 3:
                f "A towel. I can not use it as a canvas. It is weak and small."
    show screen furdo
$ renpy. pause(hard=True)
label beoltozikfred11nap:
    $ holvagyok = "beoltozikfred11nap"
    $ fekete = False
    jump tiltasok
$ renpy. pause(hard=True)
label beoltozikfred11napszov:
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen invertori2
    show furdokozeli
    show fiupoz1:
        xpos -0.2
        xzoom -1.0
    show ferdboriszruha:
        xpos -0.2
        xzoom -1.0
    show ferdarcpirmelegtol:
        xpos -0.2
        xzoom -1.0
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    f "This dress is really hot and heavy. I should hurry and bring Mom to Svetlana."
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide furdokozeli
    hide fiupoz1
    hide ferdboriszruha
    hide ferdarcpirmelegtol
    show nyomortanyaalapkozeli
    show editpoz1
    show fiupoz1:
        xzoom -1.0
    show ferdpoz1szemlefelenez:
        xzoom -1.0
    show ferdboriszruha:
        xzoom -1.0
    show ferdarcpirmelegtol:
        xzoom -1.0
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    f "Hy Mom! I mean….Добрый день! Моя мама!"
    ed "You came! I missed you so much! Мой сын!"
    fg "Oh fuck! It works! I could trick her! She believes I am her son!"
    ed "The wore spent all your money. We landed here..."
    fg "Huh? I should fix the relationship between Svetlana and Edit. She suffered enough in the past..."
    f "No Mom! It was not Svetlana's fault. Everything is alright!"
    ed "Alright. Where is she? Why is she not greeting you?"
    f "She is waiting for us in our new home! Мамочка!"
    ed "Let us go!"
    $ svetlanajelnet11nap = 1
    $ nyomortanyamama = 0
    $ invertorinejelenyenmeg = True
    jump svetlanahaza




$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
