label terkep:
    if invertorikep == True:
        show screen invertori2
    $ invertorikep = False
    $ holvagyok = "terkep"
    jump tiltasok
$ renpy. pause(hard=True)
label terkepszov:
    hide screen invertori2
    hide invertori onlayer elotte6
    show terkepalap
    show kocsimegy1terkep:
        alpha 1.0
        parallel:
            xpos 0.6
            linear 8.0 xpos -0.06
        parallel:
            ypos 0.98
            linear 8.0 ypos 0.29
        alpha 0.0
        pause 6.0
        repeat
    show kocsimegy5terkep:
        alpha 0.0
        pause 2.0
        alpha 1.0
        parallel:
            xpos 0.6
            linear 6.0 xpos 0.995
        parallel:
            ypos -0.05
            linear 6.0 ypos 0.36
        alpha 0.0
        pause 4.0
        repeat
    show kocsiparkolterkep:
        xpos 0.15
        ypos 0.88
    show terkephazak
    if hanyadiknapvan >= 5:
        if lizagyurulye >= 4:
            show terkepstrip
    if hanyadiknapvan >= 7:
        if kittyparkotenged == True:
            show terkeppark
    if hanyadiknapvan >= 9:
        show terkeptemeto
    if hanyadiknapvan >= 10:
        if cukrazdalathato == True:
            show terkepcukrazda
    if hanyadiknapvan >= 11:
        show terkepnyomortanya
        if svetlanahaza == True:
            show terkepsvetlanahaza
    if hanyadiknapvan >= 12:
        if lakotombaterkepen == True:
            hide terkepsvetlanahaza
            show lakotombb
            show terkepsvetlanahaza
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen terkep




$ renpy. pause(hard=True)
label nemengedodaaterkepen:
    f "I can not go there."
$ renpy. pause(hard=True)
label nemengedodaaterkepen2:
    f "I can not go home now. I have something to do."
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
