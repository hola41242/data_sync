
label nappali:
    if hanyadiknapvan == 3:
        if regell3resz == True:
            if isztaruhafel == 2:
                if taskafel == 2:
                    if mamaelkoszont == True:
                        if harmadikreszkonyha == 2:
                            f "I can not go back. I am late!"
                            $ renpy. pause(hard=True)
    if hanyadiknapvan == 2:
        if atjarosecialisengedej == 2:
            $ atjarosecialisengedej = 0
    if hanyadiknapvan == 5:
        if regell5resz == True:
            $ furdobenvagy = 2
            $ debraholcsinal = "furdo"
    if hanyadiknapvan == 7:
        if kiteritesiproba == 4:
            if mamanyaklanczalogjegy == 2:
                $ debraholcsinal = "nap7vegjelenetafurdoben"
    $ holvagyok = "napaliban"
    jump tiltasok
label nappaliszov:
    show haznappali
    if hanyadiknapvan == 1:
        if furdo == True:
            if szendvicsmilesz == False:
                show haznappalitanyer
                show nappalisedvics
    if ujsagafoldon == True:
        $ ujsagafoldonkidobva = True
        $ hozdbeazujsagot = True
        if debraholcsinal == "napaliban2":
            hide nappali ujsag
        else:
            show nappali ujsag
    if tvnapaliban == True:
        show nappalitv onlayer elotte6

    if hanyadiknapvan == 2:
        if mamakeresei >= 4:
            if tvkivankapcsolva == False:
                play music "audio/tvadas.ogg" fadeout 1

        show nagyikanapenalap
        show nagyikanapenszemoldok1
        show mamakanapenpislog
        if fifipisi2 == False:
            if fifipisilt >= 2:
                show hugy:
                    zoom 0.7
                    xpos 0.16
                    ypos 0.76
        if fifipisi3 == False:
            if fifipisilt >= 3:
                show hugy1:
                    zoom 0.8
                    xpos 0.64
                    ypos 0.78
        if fifiholcsinal == "napaliban":
            $ fifinapaliban = False
            show fifisetaszembe onlayer hatsominus1:
                parallel:
                    alpha 1.0
                    pause 10.0 alpha 0.0
                    pause 30.0 alpha 1.0
                    repeat
                parallel:
                    xpos 0.12
                    linear 10.0 xpos 0.12
                    repeat
                parallel:
                    ypos 0.55
                    linear 10.0 ypos 0.65
                    repeat
                parallel:
                    zoom 0.25
                    linear 10.0 zoom 0.26
                    repeat
            show fifioldalseta onlayer hatsominus1:
                parallel:
                    ypos 0.7
                    pause 10.0
                    linear 10.0 ypos 0.68
                    linear 10.0 ypos 0.7
                    pause 10.0
                    repeat
                parallel:
                    alpha 0.0
                    pause 10.0 alpha 1.0
                    pause 20.0 alpha 0.0
                    pause 10.0 alpha 0.0
                    repeat
                parallel:
                    xpos 0.16
                    pause 10.0
                    linear 10.0 xpos 0.6
                    linear 10.0 xpos 0.16
                    pause 10.0
                    repeat
                parallel:
                    zoom 0.2
                    pause 10.0
                    linear 10.0 zoom 0.18
                    linear 10.0 zoom 0.2
                    pause 10.0
                    repeat
                parallel:
                    xzoom 1.0
                    pause 10.0
                    pause 10.0 xzoom -1.0
                    pause 10.0 xzoom 1.0
                    pause 10.0
                    repeat
            show fifisetahatra onlayer hatsominus1:
                parallel:
                    alpha 0.0
                    pause 30.0 alpha 1.0
                    pause 10.0 alpha 0.0
                    repeat
                parallel:
                    xpos 0.12
                    linear 10.0 xpos 0.12
                    repeat
                parallel:
                    ypos 0.65
                    linear 10.0 ypos 0.55
                    repeat
                parallel:
                    zoom 0.25
                    linear 10.0 zoom 0.25
                    repeat
        if fifiholcsinal == "napaliban3":
            $ fifinapaliban = False
            show fifisetaszembe onlayer hatsominus1:
                parallel:
                    alpha 1.0
                    pause 10.0 alpha 0.0
                    pause 30.0 alpha 1.0
                    repeat
                parallel:
                    xpos 0.12
                    linear 10.0 xpos 0.12
                    repeat
                parallel:
                    ypos 0.55
                    linear 10.0 ypos 0.65
                    repeat
                parallel:
                    zoom 0.25
                    linear 10.0 zoom 0.26
                    repeat
            show fifioldalseta onlayer hatsominus1:
                parallel:
                    ypos 0.7
                    pause 10.0
                    linear 10.0 ypos 0.68
                    linear 10.0 ypos 0.7
                    pause 10.0
                    repeat
                parallel:
                    alpha 0.0
                    pause 10.0 alpha 1.0
                    pause 20.0 alpha 0.0
                    pause 10.0 alpha 0.0
                    repeat
                parallel:
                    xpos 0.16
                    pause 10.0
                    linear 10.0 xpos 0.6
                    linear 10.0 xpos 0.16
                    pause 10.0
                    repeat
                parallel:
                    zoom 0.2
                    pause 10.0
                    linear 10.0 zoom 0.18
                    linear 10.0 zoom 0.2
                    pause 10.0
                    repeat
                parallel:
                    xzoom 1.0
                    pause 10.0
                    pause 10.0 xzoom -1.0
                    pause 10.0 xzoom 1.0
                    pause 10.0
                    repeat
            show fifisetahatra onlayer hatsominus1:
                parallel:
                    alpha 0.0
                    pause 30.0 alpha 1.0
                    pause 10.0 alpha 0.0
                    repeat
                parallel:
                    xpos 0.12
                    linear 10.0 xpos 0.12
                    repeat
                parallel:
                    ypos 0.65
                    linear 10.0 ypos 0.55
                    repeat
                parallel:
                    zoom 0.25
                    linear 10.0 zoom 0.25
                    repeat
        if fifiholcsinal == "napaliban2":
            $ fifinapaliban = False
            hide fifipisil
            show fifipisil:
                zoom 0.7
                xpos 0.1
                ypos 0.54
                pause (fificsinalido)
                alpha 1.0
                linear 2.0 alpha 0.0
            show hugy:
                alpha 0.0
                pause (fificsinalido)
                zoom 0.7
                xpos 0.16
                ypos 0.76
                alpha 0.0
                linear 2.0 alpha 1.0
        if fifiholcsinal == "napaliban4":
            $ fifinapaliban = False
            hide fifipisil onlayer hatso
            show fifipisil onlayer hatso:
                zoom 0.7
                xpos 0.6
                ypos 0.56
                alpha 1.0
                pause (fificsinalido)
                alpha 1.0
                linear 2.0 alpha 0.0
            show hugy1:
                alpha 0.0
                pause (fificsinalido)
                zoom 0.8
                xpos 0.64
                ypos 0.78
                alpha 0.0
                linear 2.0 alpha 1.0
        if fifiholcsinal == "napaliban5":
            $ fifinapaliban = False
            show fifisetaszembe onlayer hatsominus1:
                parallel:
                    alpha 1.0
                    pause 10.0 alpha 0.0
                    pause 30.0 alpha 1.0
                    repeat
                parallel:
                    xpos 0.12
                    linear 10.0 xpos 0.12
                    repeat
                parallel:
                    ypos 0.55
                    linear 10.0 ypos 0.65
                    repeat
                parallel:
                    zoom 0.25
                    linear 10.0 zoom 0.26
                    repeat
            show fifioldalseta onlayer hatsominus1:
                parallel:
                    ypos 0.7
                    pause 10.0
                    linear 10.0 ypos 0.68
                    linear 10.0 ypos 0.7
                    pause 10.0
                    repeat
                parallel:
                    alpha 0.0
                    pause 10.0 alpha 1.0
                    pause 20.0 alpha 0.0
                    pause 10.0 alpha 0.0
                    repeat
                parallel:
                    xpos 0.16
                    pause 10.0
                    linear 10.0 xpos 0.6
                    linear 10.0 xpos 0.16
                    pause 10.0
                    repeat
                parallel:
                    zoom 0.2
                    pause 10.0
                    linear 10.0 zoom 0.18
                    linear 10.0 zoom 0.2
                    pause 10.0
                    repeat
                parallel:
                    xzoom 1.0
                    pause 10.0
                    pause 10.0 xzoom -1.0
                    pause 10.0 xzoom 1.0
                    pause 10.0
                    repeat
            show fifisetahatra onlayer hatsominus1:
                parallel:
                    alpha 0.0
                    pause 30.0 alpha 1.0
                    pause 10.0 alpha 0.0
                    repeat
                parallel:
                    xpos 0.12
                    linear 10.0 xpos 0.12
                    repeat
                parallel:
                    ypos 0.65
                    linear 10.0 ypos 0.55
                    repeat
                parallel:
                    zoom 0.25
                    linear 10.0 zoom 0.25
                    repeat
        if tvhoztak == True:
            if tvnapaliban == False:
                $ tvnapaliban = True
                show fekete onlayer screens:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                pause 1.0
                $ fekete = True
                $ mamakeresei = 2
                show nappalitv onlayer elotte6:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                m "I can not find the controller. Find it for Grandma!"
        if tvtaviranyitonalad == True:
            if tvtaviranyitomamanal == False:
                if mamakeresei == 2:
                    show fekete onlayer screens:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    pause 1.0
                    $ fekete = True
                    $ mamakeresei = 3
                    m "All channels are gone. Can you program them in Freddy?"
                    f "Of course. Just A few minutes..."
        if mamabeszeldebraval == False:
            jump mamabeszeldebraval
        if mamasolit == 1:
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fotokosszevissza
            show fotokosszevissza2
            m "Look at these! A lot of photos! I searched for them so I can show them to you!"
            f "This is really exciting! I will take a look!"
            show screen lopolfenykep
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 3:
        if mamanemkapotkavet == False:
            show reggelimama3resz
        if mamanemkapotkavet == True:
            if beszeljaszomszedokkal < 2:
                show nagyikanapenalap
                show nagyikanapenszemoldok1
                show mamakanapenpislog
        if harmadikreszkonyha == 4:
            jump beszeddagimamaval
        if harmadikreszkonyha == 5:
            jump beszeddagimamaval
    if hanyadiknapvan >= 3:
        if lopotfotokat == False:
            show fotokosszevissza2
    if hanyadiknapvan == 4:
        if mamanapalibanregel4resz == True:
            show reggelimama3resz
        if debrareggel4resznapaliben == True:
            show debraujsaggal
        if fifipoziciok == 0:
            show fifisetaszembe onlayer hatsominus1:
                parallel:
                    alpha 1.0
                    pause 10.0 alpha 0.0
                    pause 30.0 alpha 1.0
                    repeat
                parallel:
                    xpos 0.12
                    linear 10.0 xpos 0.12
                    repeat
                parallel:
                    ypos 0.55
                    linear 10.0 ypos 0.65
                    repeat
                parallel:
                    zoom 0.25
                    linear 10.0 zoom 0.26
                    repeat
            show fifioldalseta onlayer hatsominus1:
                parallel:
                    ypos 0.7
                    pause 10.0
                    linear 10.0 ypos 0.68
                    linear 10.0 ypos 0.7
                    pause 10.0
                    repeat
                parallel:
                    alpha 0.0
                    pause 10.0 alpha 1.0
                    pause 20.0 alpha 0.0
                    pause 10.0 alpha 0.0
                    repeat
                parallel:
                    xpos 0.16
                    pause 10.0
                    linear 10.0 xpos 0.6
                    linear 10.0 xpos 0.16
                    pause 10.0
                    repeat
                parallel:
                    zoom 0.2
                    pause 10.0
                    linear 10.0 zoom 0.18
                    linear 10.0 zoom 0.2
                    pause 10.0
                    repeat
                parallel:
                    xzoom 1.0
                    pause 10.0
                    pause 10.0 xzoom -1.0
                    pause 10.0 xzoom 1.0
                    pause 10.0
                    repeat
            show fifisetahatra onlayer hatsominus1:
                parallel:
                    alpha 0.0
                    pause 30.0 alpha 1.0
                    pause 10.0 alpha 0.0
                    repeat
                parallel:
                    xpos 0.12
                    linear 10.0 xpos 0.12
                    repeat
                parallel:
                    ypos 0.65
                    linear 10.0 ypos 0.55
                    repeat
                parallel:
                    zoom 0.25
                    linear 10.0 zoom 0.25
                    repeat
        if dagitmegharaptafifi == 1:
            show dagiallas1 sir:
                xzoom -1.0
                zoom 0.6
                xpos 0.2
                ypos 0.2
            show dagilabver:
                xzoom -1.0
                zoom 0.6
                xpos 0.2
                ypos 0.2
        if fifipoziciok == 3:
            show fifimorog:
                xpos 0.12
                ypos 0.5
                zoom 0.7
        if uditosmagamhozveni == 2:
            if dagimama4resz == False:
                show nagyikanapenalap
                show nagyikanapenszemoldok1
                show mamakanapenpislog
                show dagiallas1:
                    xzoom -1.0
                    zoom 0.6
                    xpos 0.2
                    ypos 0.2
                jump beszeddagimamaval
        if debraholcsinal == "napaliban2":
            hide screen invertori2
            hide invertori onlayer elotte6
            show debraujsaggal
            show fateralap
            show faterpislognapaliban
            show fredanapalibanpoz1bszem2
            jump negyedigszervegejelenet
    if hanyadiknapvan == 5:
        if debraholcsinal == "napalijelenet5resz":
            if lizajelenetvege5resz == False:
                jump napalijelenet5resz
        if lizajelenetvege5resz == True:
            jump napalijelenet5reszv2
    if hanyadiknapvan == 6:
        if mamaholvan == "nappali":
            show mamanappalihattal
        if debraholcsinal == "napalikusztum":
            $ debranapaliban = False
            show debrapucban1
            if debravegigpan >= 2:
                if debrafulbevalo2 < 2:
                    hide debrapucban1
                    show debrapucban1:
                        alpha 1.0
                        pause 5.0
                        linear 1.0 alpha 0.0
                        pause 5.0
                        linear 1.0 alpha 1.0
                        repeat
                    show debrapucban2:
                        alpha 0.0
                        pause 5.0
                        linear 1.0 alpha 1.0
                        pause 5.0
                        linear 1.0 alpha 0.0
                        repeat
                    if debrafulbevalo1 >= 2:
                        show debrapucban2fulbe2:
                            alpha 0.0
                            pause 5.0
                            linear 1.0 alpha 1.0
                            pause 5.0
                            linear 1.0 alpha 0.0
                            repeat
            if debravegigpan == 1:
                jump napalijelenet6resz
    if hanyadiknapvan == 7:
        if debraholcsinal == "napaliban3":
            show debratvnezalap
            show debratvnezpislog
    if debraholcsinal == "napaliban3":
        show debratvnezalap
        show debratvnezpislog
    if hanyadiknapvan == 8:
        if mamaholvan == "napaliban":
            show mamalabal2r11080:
                zoom 0.7
                xpos 0.6
                ypos 0.15
    if hanyadiknapvan == 9:
        if resz9jelenet2 == False:
            $ esteighatralevoido = 50000
            hide screen invertori2
            hide invertori onlayer elotte6
            hide nappalitv onlayer elotte6
            show hazalapeste
            show nappalitv
            show haznappalibanvansotetben
            show screen s4
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            u ""
            f "Debra! What are you doing here in the dark?"
            show haznappalialvajarasnal:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1arny:
                alpha 0.0
                linear 1.0 alpha 1.0
            show debraalvajarmoz1:
                xpos 0.2
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            f "Debra! Are you OK?"
            dalva "Sure…"
            f "What are you doing here now?"
            dalva "I am searching…"
            show fiupoz1:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1arny:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz2arny:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "What are you searching for?"
            dalva "I miss something… I am searching for it…"
            show fiupoz2:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz4:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz2arny:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz4arny:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Hey! Are you sleepwalking?"
            dalva "I miss it... I have to find it…I can smell it…"
            show fiupoz4:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz4arny:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1arny:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Go to sleep! We will search for it tomorrow together."
            dalva "You have the right... I should lie down... we will find it by daylight easier..."
            $ invertorinejelenyenmeg = True
            show fiupoz1csakszemanimkovetidebrat:
                alpha 0.0
                pause 1.0
                alpha 1.0
            hide fiupoz1arny
            show fiupoz1arny
            hide debraalvajarmoz1
            show debraalvajaranim:
                xpos 0.2
                linear 9.0 xpos -0.9
            show screen s10
            u ""
            jump atjaro
        if taviranyito == 0:
            show nappalitvtaviranyito
    if hanyadiknapvan == 10:
        if bertalanholvan == "napaliban":
            show fateralap
            show faterpislognapaliban
            show fredanapalibanpoz1bszem2
            jump bertalannalbeszelsz10resz
    if hanyadiknapvan >= 11:
        if debraholcsinal == "napalibanallva":
            show debraall:
                xzoom -1.0
                zoom 0.65
                xpos 0.32
                ypos 0.17
            if debra11napfeladatotad == 0:
                jump izzocseremegkeres11nap
        if debraholcsinal == "ujsagotolvas":
            show debraujsaggal
            show debrafotelpislog
            hide nappali ujsag
            if cottonkell11nap == 3:
                jump nap11vege
    if hanyadiknapvan == 12:
        if mamakenocsenalad == 0:
            show mamakenocse
        if debraholcsinal == "taviranyitotkeres":
            show haznappalidebrabedol
        if mamaholvan == "mamakanapenanapaliban":
            show nagyikanapenalap
            show mamakanapenpislog
            show nagyikanapenszemoldok1







    jump engedejek
label locsolnapali1:
    if locsolokannaviz >= 1:
        play sound "audio/viz13.wav"
        $ locsolokannaviz -= 1
        $ viragokmegontozve += 1
        $ napalivirag = True
        if furdovirag == True:
            if fojasoballvirag == True:
                if fojasojobbvirag == True:
                    if napalivirag == True:
                        if atjarovirag == True:
                            if atjarovirag2 == True:
                                if furdovirag == True:
                                    if atjarovirag3 == True:
                                        $ viragokmegontozese = True
    else:
        f "I need to go back to the bathroom to fill the can with water."
$ renpy. pause(hard=True)
label locsolnapali2:
    if locsolokannaviz >= 1:
        play sound "audio/viz13.wav"
        $ locsolokannaviz -= 1
        $ viragokmegontozve += 1
        $ napalivirag2 = True
        if furdovirag == True:
            if fojasoballvirag == True:
                if fojasojobbvirag == True:
                    if napalivirag == True:
                        if atjarovirag == True:
                            if atjarovirag2 == True:
                                if furdovirag == True:
                                    if atjarovirag3 == True:
                                        $ viragokmegontozese = True
    else:
        f "I need to go back to the bathroom to fill the can with water."
$ renpy. pause(hard=True)
label debraanapalibavissza:
    $ debranapaliban = False
    hide debrasopor
    if debraholcsinal == "napaliban3":
        show debratvnezalap:
            alpha 0.0
            linear 2.0 alpha 1.0
            pause (debravalamitcsinalido)
            alpha 1.0
            linear 2.0 alpha 0.0
        show debratvnezpislog:
            alpha 0.0
            linear 2.0 alpha 1.0
            pause (debravalamitcsinalido)
            alpha 1.0
            linear 2.0 alpha 0.0
        $ renpy. pause(hard=True)
    if debraholcsinal == "napaliban2":
        hide debraujsaggal
        hide debrafotelpislog
        hide nappali ujsag
        show nappali ujsag:
            alpha 1.0
            linear 2.0 alpha 0.0
            pause (debravalamitcsinalido)
            linear 2.0 alpha 1.0
        show debraujsaggal:
            alpha 0.0
            linear 2.0 alpha 1.0
            pause (debravalamitcsinalido)
            linear 2.0 alpha 0.0
        show debrafotelpislog:
            alpha 0.0
            linear 2.0 alpha 1.0
            alpha 1.0
            pause (debravalamitcsinalido)
            alpha 1.0
            linear 2.0 alpha 0.0
        $ renpy. pause(hard=True)
    if ujsagafoldon == True:
        hide nappali ujsag
        show nappali ujsag:
            alpha 0.0
            linear 2.0 alpha 1.0
    show debrasopor:
        xpos 0.6
        ypos 0.2
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label debraanapalibavissza2:
    $ debraeddigmozgott = True
    $ debranapaliban = False
    $ fekete = True
    hide screen nappali
    hide screen invertori
    show screen invertori2
    show debrapucban1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    jump napalijelenet6resz
$ renpy. pause(hard=True)
label mamabeszeldebraval:
    $ mamabeszeldebraval = True
    if debranapaliban == True:
        $ debranapaliban = False
    show debraujsaggal:
        alpha 1.0
    show debrafotelpislog:
        alpha 1.0
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 2.0
    m "Did my son not fuck you yesterday either? And Honey! When will my Television fixed?"
    d "I see you are in a nice mood…no… The television will be ready At the moment they fix it Grandma..."
    m "You got fat, this is why he does not want to have sex with you…My favorite film serie will continue in the afternoon. I do not want to miss it!"
    d "…Thanks Grandma…You should watch it in your room..."
    m "And you got old and you have wrinkles around your eyes… I do not want to stay in my room all day long. Here is more life!"
    d "I hope they will repair the television for a long time so you need to watch Tv in your room for a looong time..."
    m "You will lose your husband if you act like this. He needs a better woman..Did you not see my little Fifi?"
    d "Super!...Not yet, but i hope she won't pee all around and make dirt."
    m "You should not eat so much…She can not hold it. This is not her fault."
    d "Let it be, i want to read. I should go to work soon."
    $ debraindul = True
    show debraujsaggal:
        alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
    show debrafotelpislog:
        alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
    $ fekete = True
    show screen debramitcsinaljon
    jump engedejek
$ renpy. pause(hard=True)
label mamavalbeszel:
    $ kivelbeszelsz = "mama"
    $ fekete = True
    jump tiltasok
label mamavalbeszelszov:
    if hanyadiknapvan == 2:
        if mamakeresei == 0:
            $ mamakeresei = 1
        if mamakeresei == 1:
            m "Hello Freddy, I am Bertalans Mother, Diana, but call me Grandma.Debra told me, you will grant my wishes today. You will be my slave.."
            f "Nice to meet You Grandma, I ma happy to serve you."
            m "Someone will bring me the television.Bring it back to me when it arrives!"
            f "Got it. I iwll."
            m "So long go and make zour own business, i will be fine here."
        if mamakeresei == 2:
            m "Controller?"
            f "I have not found it yet."
            m "Search for it Freddy, I want to see my series..."
        if mamakeresei == 3:
            m "Make the programming! Do not talk to me!"
        if mamakeresei == 4:
            m "Where is my sandwich?"
            if szendvicsinvertoriba == True:
                hide mamaszenyo onlayer elotte6
                hide screen invertori2
                hide invertori onlayer elotte6
                show mamaszenyo onlayer elotte6:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s3
                u ""
                if szedvicbenvaj == True:
                    if szedvicbenszalami == True:
                        if szedvicbensalata == True:
                            if szedvicbenmajonez == True:
                                show mamaszenyo onlayer elotte6:
                                    alpha 1.0
                                    linear 1.0 alpha 0.0
                                $ mamakeresei = 5
                                $ szendvicsinvertoriba = False
                                m "I wish to drink something."
                                show screen invertori2
                                show invertori onlayer elotte6:
                                    yalign 0.0
                                jump engedejek
                            if szedvicbenkecsap == True:
                                m "Debra likes ketchup! I do not!"
                            if szedvicbenmustar == True:
                                m "The mustard is too strong for my weak soul…"
                        else:
                            m "No salat?"
                    else:
                        m "I hate Parisian slices!"
                else:
                    m "I won't eat it without butter!"
                hide arcbaszenyo3 onlayer elotte6
                hide arcbaszenyo2 onlayer elotte6
                hide arcbaszenyo1 onlayer elotte6
                hide arcbaszenyoalap onlayer elotte6
                show arcbaszenyoalap onlayer elotte6
                if nemjoszendvics == 3:
                    $ nemjoszendvics = 0
                if nemjoszendvics == 2:
                    $ nemjoszendvics = 3
                    show arcbaszenyo3 onlayer elotte6
                    with vpunch
                if nemjoszendvics == 1:
                    $ nemjoszendvics = 2
                    show arcbaszenyo2 onlayer elotte6
                    with vpunch
                if nemjoszendvics == 0:
                    $ nemjoszendvics = 1
                    show arcbaszenyo1 onlayer elotte6
                    with vpunch
                queue sound "audio/paff.wav"
                show screen s2
                u ""
                $ szedvicskesz = False
                $ vanszedvicsed = False
                $ szedvicbenvaj = False
                $ szedvicbenkecsap = False
                $ szedvicbenmajonez = False
                $ szedvicbenmustar = False
                $ szedvicbensalata = False
                $ szedvicbenparizsi = False
                $ szedvicbenszalami = False
                $ szendvicsinvertoriba = False
                hide mamaszenyo onlayer elotte6
                if nemjoszendvics == 3:
                    show arcbaszenyo3 onlayer elotte6:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                if nemjoszendvics == 2:
                    show arcbaszenyo2 onlayer elotte6:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                if nemjoszendvics == 1:
                    show arcbaszenyo1 onlayer elotte6:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                show arcbaszenyoalap onlayer elotte6:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen invertori2
                show invertori onlayer elotte6:
                    yalign 0.0
        if mamakeresei == 5:
            if poharnalad == True:
                $ mamakeresei = 6
                $ urespoharnalad = True
                $ mamavalfoglalkoz = 2
                m "Thank you it was delicious."
                jump engedejek
            m "I am thirsty Freddy!"
        if mamakeresei == 6:
            m "I am happy with your service! Go now!"
    if hanyadiknapvan == 3:
        if mamanemkapotkavet == False:
            if mamavalbeszeltel == 3:
                $ mamavalbeszeltel = 0
            if mamavalbeszeltel == 2:
                $ mamavalbeszeltel = 3
                m "No coffee... no Grandma... Bring Grandma a coffee…."
            if mamavalbeszeltel == 1:
                $ mamavalbeszeltel = 2
                m "hhhhhhggggggggnnnnnnn......"
            if mamavalbeszeltel == 0:
                $ mamavalbeszeltel = 1
                m "Coffee…"
        if mamanemkapotkavet == True:
            if mamavalbeszeltel == 3:
                $ mamavalbeszeltel = 0
            if mamavalbeszeltel == 2:
                $ mamavalbeszeltel = 3
                m "I do not want to talk to you!"
            if mamavalbeszeltel == 1:
                $ mamavalbeszeltel = 2
                m "You should go to the university instead of molesting me!"
            if mamavalbeszeltel == 0:
                $ mamavalbeszeltel = 1
                m "Do you not have anything to do? What do you want from me?"
        if kaveazasztalrolinvertoriba == True:
            if mamanemkapotkavet == False:
                if harmadikreszkonyha == 1:
                    $ harmadikreszkonyha = 2
                    $ mamanemkapotkavet = True
                    f "Here you go Grandma! The coffee!"
                    m "Thank you! I needed this so much!"
                    show reggelimama3resz:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    show nagyikanapenalap:
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    show nagyikanapenszemoldok1:
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    show mamakanapenpislog:
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    with vpunch
                    m "This was good, but you should have put in more sugar, less milk and more coffee grounds… Maybe next time it will be better!"
                    m "Next time make it better! Without coffee mom is a zombie!"
    if hanyadiknapvan == 4:
        if mamabeszednapali == 1:
            if mamanakkonyhaszedvics == True:
                if kaveamamanakkesz == True:
                    $ mamanakmegteritvakonyha = True
                    $ mamanapalibanregel4resz = False
                    $ mamanakteritve = 2
                    f "Grandma I set the table."
                    m "You should make it faster next time. I do not want to hurt your feelings but you are a sloth."
                    f "Ok, next time!"
                    show reggelimama3resz:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    jump engedejek
        if mamabeszednapali == 1:
            if mamavalbeszeltel == 3:
                $ mamavalbeszeltel = 0
            if mamavalbeszeltel == 2:
                $ mamavalbeszeltel = 3
                m "No coffee... no Grandma... Bring Grandma a coffee…."
            if mamavalbeszeltel == 1:
                $ mamavalbeszeltel = 2
                m "hhhhhhggggggggnnnnnnn......"
            if mamavalbeszeltel == 0:
                $ mamavalbeszeltel = 1
                m "Coffee…"
        if mamabeszednapali == 0:
            $ mamabeszednapali = 1
            $ mamaszedvicsetker = True
            $ mamanemkapotkavet = False
            $ kaveamamanakkesz = False
            $ kaveahejen = False
            $ mamaszedvics = 1
            $ mamakave = 1
            $ fifitregeliztetni = 1
            $ mamanakteritve = 1
            $ megkaptadavizeskancsot = False
            $ beszeljamamaval = 2
            f "What is it? Did you wake up early to watch the new episode of the Lovely lovers series?"
            m "Just shut up and make me a sandwich and a coffee!"
            m "One sandwich for breakfast is perfect! And do not forget about my little Fifi!"
            f "Ok, I have time for this before I leave!"
            m "I give you orders. I am not interested in your plans!"
            f "Yeah, alright!"
    jump engedejek
$ renpy. pause(hard=True)
label fifitmamanak:
    hide fifimorog
    hide fifiszagol
    hide fifiszagolpislog
    $ fifitfelvetem = False
    $ fifitletettem = True
    $ fifinapaliban = False
    $ fifiholcsinal = "napaliban"
    show fifimorog:
        xpos 0.12
        ypos 0.5
        zoom 0.7
        alpha 0.0
        linear 2.0 alpha 1.0
        pause 2.0
        linear 1.0 alpha 0.0
    show fifiszagol:
        xpos 0.12
        ypos 0.5
        zoom 0.7
        alpha 0.0
        linear 2.0 alpha 0.0
        pause 2.0
        linear 1.0 alpha 1.0
    show fifiszagolpislog:
        xpos 0.12
        ypos 0.5
        zoom 0.7
        alpha 0.0
        linear 2.0 alpha 0.0
        pause 2.0
        linear 1.0 alpha 1.0
    pause 7.0
    hide fifimorog
    hide fifiszagol
    hide fifiszagolpislog
    show fifisetaszembe onlayer hatsominus1:
        parallel:
            alpha 1.0
            pause 10.0 alpha 0.0
            pause 30.0 alpha 1.0
            repeat
        parallel:
            xpos 0.12
            linear 10.0 xpos 0.12
            repeat
        parallel:
            ypos 0.55
            linear 10.0 ypos 0.65
            repeat
        parallel:
            zoom 0.25
            linear 10.0 zoom 0.26
            repeat
    show fifioldalseta onlayer hatsominus1:
        parallel:
            ypos 0.7
            pause 10.0
            linear 10.0 ypos 0.68
            linear 10.0 ypos 0.7
            pause 10.0
            repeat
        parallel:
            alpha 0.0
            pause 10.0 alpha 1.0
            pause 20.0 alpha 0.0
            pause 10.0 alpha 0.0
            repeat
        parallel:
            xpos 0.16
            pause 10.0
            linear 10.0 xpos 0.6
            linear 10.0 xpos 0.16
            pause 10.0
            repeat
        parallel:
            zoom 0.2
            pause 10.0
            linear 10.0 zoom 0.18
            linear 10.0 zoom 0.2
            pause 10.0
            repeat
        parallel:
            xzoom 1.0
            pause 10.0
            pause 10.0 xzoom -1.0
            pause 10.0 xzoom 1.0
            pause 10.0
            repeat
    show fifisetahatra onlayer hatsominus1:
        parallel:
            alpha 0.0
            pause 30.0 alpha 1.0
            pause 10.0 alpha 0.0
            repeat
        parallel:
            xpos 0.12
            linear 10.0 xpos 0.12
            repeat
        parallel:
            ypos 0.65
            linear 10.0 ypos 0.55
            repeat
        parallel:
            zoom 0.25
            linear 10.0 zoom 0.25
            repeat
$ renpy. pause(hard=True)
label nemlopfotott:
    $ atjarosecialisengedej = 3
    $ alvasmasodikreszvege = 1
    hide screen lopolfenykep
    f "It is getting latre, I should sleep now."
    jump atjaro
$ renpy. pause(hard=True)
label lopfotott:
    if hanyadiknapvan == 2:
        $ alvasmasodikreszvege = 1
        $ atjarosecialisengedej = 3
        hide screen lopolfenykep
    $ lopotfotokat = True
    show fotokosszevissza2:
        alpha 1.0
        linear 1.0 alpha 0.0
    if hanyadiknapvan == 2:
        f "It is getting latre, I should sleep now."
        jump atjaro
$ renpy. pause(hard=True)
label mamaelkoszon3reszregel:
    $ csinalszvalamit = "sulibamensz"
    jump tiltasok
$ renpy. pause(hard=True)
label mamaelkoszon3reszregelszov:
    $ mamaelkoszont = True
    m "Take care of yourself Freddy! You are so weak and thin. If you meet a strong and muscular big guy..."
    m "A wild, handsome man with a lot of energy… bring him home, i will take care of him!"
    f "Ok, I will try my best!"
    jump fojasoball
$ renpy. pause(hard=True)
label beszeddagimamaval:
    hide screen invertori2
    hide invertori onlayer elotte6
    show dagiallas1:
        xzoom -1.0
        zoom 0.6
        xpos 0.2
        ypos 0.2
    show fredanapalibanpoz1bszem2
    $ fekete = True
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    if hanyadiknapvan == 3:
        if harmadikreszkonyha == 5:
            $ harmadikreszkonyha = 6
            f "I need to go now to the shop. Do you wan tto come with me Puffy?"
            da "N... No... I should go home now... It is getting late… I will leave when you do..."
            da "Grandma, I will come back to you and we will talk more about the menopause next time! I really enjoyed our conversation!"
            m "Come back any time you want! Handsome!"
            jump kijaratiajto
        if harmadikreszkonyha == 4:
            m "Oh I see! You brought me a man! Let me see!"
            f "David! She is Diana, everyone calls her Grandma.Grandma! He is David, everyone calls him Puffy."
            m "Sit down here Puffy! Let us have a nice chat!"
            da "Ok, Grandma!"
            hide fekete onlayer screens
            hide nappalitv onlayer elotte6
            hide screen invertori2
            hide invertori onlayer elotte6
            show fekete onlayer screens:
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 1.0
            show mamakanapenalap onlayer hatso
            show dagianapenalap onlayer hatso
            show fredkapen onlayer hatso1
            show dagianapenarc1 onlayer hatso
            show mamakanapenkar1 onlayer hatso
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            da "What should we talk about Freddy?"
            f "I heard a strange rumor at the university. Someone told my dad did not commit a suicide."
            da "I really do not know, I never saw your dad laugh..."
            f "Yeah, he was not such a happy person, but... this is so strange... Why is there a rumor?"
            m "Tell me more about the rumor please!"
            f "A man came out of the house not so long before dad committed suicide.."
            m "You should not take seriously these kinds of rumors Freddy... Let it be!"
            f "I will try, but I will ask Debra about it first."
            play music "audio/baszosalap.ogg" fadeout 1
            show fredkapen onlayer hatso1:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            show mamapank53 onlayer hatso1:
                parallel:
                    xpos 0.0
                    linear 5.0 xpos -0.1
                parallel:
                    ypos -0.9
                    linear 5.0 ypos 0.0
                parallel:
                    alpha 0.0
                    linear 1.0 alpha 1.0
            m "Puffy! Why did you choose the university?"
            da "Well, Fred wanted to go there and I just followed him."
            m "What do you learn?"
            da "I want to major in architecture. I really like what I learn!"
            m "Would you build a house total free for me?"
            show mamapank53 onlayer hatso1:
                alpha 1.0
                linear 1.0 alpha 0.0
            m "What is your favorite TV serie?"
            da "I like Fat to thin. People try to lose weight in 6 months. The more weight you lose the more money you earn…"
            da "And I like Thin to fat, This serie is the opposite of the other one."
            m "Yeah! I like it, too! The presenter has really a big boner!"
            show mamapank54 onlayer hatso1:
                alpha 0.0
                linear 1.0 alpha 1.0
            m "Look Puffy! Do you think I have cellulite?"
            da "Oh well… what should I say…"
            m "I think this is cellulite. I did not have it a week ago..."
            show mamapank54 onlayer hatso1:
                alpha 1.0
                linear 1.0 alpha 0.0
            m "And tell me Puffy! Did you fuck someone from behind?"
            show dagianapenarc1 onlayer hatso:
                alpha 1.0
                linear 1.0 alpha 0.0
            show dagianapenarc2 onlayer hatso:
                alpha 0.0
                linear 1.0 alpha 1.0
            da "N… Not yet.."
            m "Are you a virgin?"
            da "Y… yes Grandma…"
            show mamakanapenkar1 onlayer hatso:
                alpha 1.0
                linear 1.0 alpha 0.0
            show mamakanapenkar2 onlayer hatso:
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 2.0
            m "Do you want to have sex?"
            show dagianapenfelall onlayer hatso:
                alpha 0.0
                linear 1.0 alpha 1.0
            da "WHoooaaaa…"
            show dagianapenarc2 onlayer hatso:
                alpha 1.0
                linear 1.0 alpha 0.0
            show dagianapenfelall onlayer hatso:
                alpha 1.0
                linear 1.0 alpha 0.0
            show dagianapenalap onlayer hatso:
                alpha 1.0
                linear 1.0 alpha 0.0
            show dagianapenosszegornyedl onlayer hatso:
                alpha 0.0
                linear 1.0 alpha 1.0
            da "This is to fast… but…"
            u ""
            play music "audio/banyabolt.ogg" fadeout 1
            jump konyha
    if hanyadiknapvan == 4:
        m "Hello Puffy-baby! Did you come back to Mama?"
        da "Yes Grandma. I am back to have a nice chat again."
        m "Come on! Sit down!"
        da "I better stay here. It is comfortable now to stand here..."
        m "I think you want to stand in a different way… down…"
        f "Now I need to change my dress and put my bag down."
        da "Do not hurry!"
        play sound "audio/ajto2.wav"
        show fredanapalibanpoz1bszem2:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        m "Tell me Puffy! Did you think about yesterday?"
        da "I thought of it all night long…"
        m "I am happy, but you look shy.. I have an idea!"
        m "I go to the bathroom and fix my dresses and do not dare to peek on me!"
        da "Huuuu...."
        show nagyikanapenalap:
            alpha 1.0
            linear 1.0 alpha 0.0
        show nagyikanapenszemoldok1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show mamakanapenpislog:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        play music "audio/szexy.ogg" fadeout 1
        hide screen invertori2
        hide invertori onlayer elotte6
        show dagibelesakulcsjukon onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        da "Let us see!"
        show mamavetkozik4resz1 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s3
        u ""
        da "Wow! Sexy!"
        show dagififi1 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s3
        u ""
        hide dagibelesakulcsjukon onlayer elotte6
        show dagibelesakulcsjukon onlayer elotte6:
            alpha 0.0
            linear 0.5 alpha 1.0
        show dagibelesakulcsjukonszem2 onlayer elotte6:
            alpha 0.0
            linear 0.5 alpha 1.0
        da "Go away puppy!"
        show dagibelesakulcsjukonszem2 onlayer elotte6:
            alpha 1.0
            linear 0.5 alpha 0.0
        pause 1.5
        show mamavetkozik4resz2alap onlayer elotte6:
            alpha 0.0
            linear 0.5 alpha 1.0
        show mamavetkozi4reszlegzesanim onlayer elotte6:
            alpha 0.0
            linear 0.5 alpha 1.0
        show mamavetkozi4reszszemanim onlayer elotte6:
            alpha 0.0
            linear 0.5 alpha 1.0
        show mamavetkozi4reszszajanim onlayer elotte6:
            alpha 0.0
            linear 0.5 alpha 1.0
        show mamavetkozik4resz2kulcsjuk onlayer elotte6:
            alpha 0.0
            linear 0.5 alpha 1.0
        show screen s3
        u ""
        show screen s3
        u ""
        da "She knows it! She knows I am watching!"
        show screen s3
        u ""
        show mamavetkozik4resz3 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s3
        u ""
        u ""
        hide mamavetkozik4resz1 onlayer elotte6
        hide mamavetkozik4resz2alap onlayer elotte6
        hide mamavetkozi4reszlegzesanim onlayer elotte6
        hide mamavetkozi4reszszemanim onlayer elotte6
        hide mamavetkozi4reszszajanim onlayer elotte6
        hide mamavetkozik4resz2kulcsjuk onlayer elotte6
        hide dagififi1 onlayer elotte6
        show dagififi1 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 2.0
        da "Leave me alone!"
        hide mamavetkozik4resz3 onlayer elotte6
        play sound "audio/harap puffyval.wav"
        show screen s05
        u ""
        show dagififi2 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        show dagififi3 onlayer elotte6:
            alpha 0.0
            pause 1.5
            linear 0.75 alpha 1.0
        show dagiraeszmelhogymegharaptak onlayer elotte6:
            alpha 0.0
            pause 3.0
            linear 0.75 alpha 1.0
        show dagififi4 onlayer elotte6:
            alpha 0.0
            pause 4.5
            linear 0.75 alpha 1.0
        show dagififi5 onlayer elotte6:
            alpha 0.0
            pause 6.0
            linear 0.75 alpha 1.0

        hide fifipoziciok
        hide fifisetaszembe onlayer hatsominus1
        hide fifioldalseta onlayer hatsominus1
        hide fifisetahatra onlayer hatsominus1
        show fifimorog:
            xpos 0.12
            ypos 0.5
            zoom 0.7
        hide dagiallas1
        show dagiallas1:
            xzoom -1.0
            xpos 0.2
            ypos 0.2
        $ dagitmegharaptafifi = 1
        $ taskafel = 3
        $ debraholcsinal = "ablakotpucolballfojason"
        $ debratolelsosegej = 1
        $ fifipoziciok = 3
        $ dagimama4resz = True
        show screen s8
        u ""
        hide dagibelesakulcsjukon onlayer elotte6
        hide dagififi1 onlayer elotte6
        hide dagififi2 onlayer elotte6
        hide dagififi3 onlayer elotte6
        hide dagiraeszmelhogymegharaptak onlayer elotte6
        hide dagififi4 onlayer elotte6
        hide dagiallas1
        show dagiallas1 sir onlayer elotte6:
            zoom 1.1
            xzoom -1.0
            xpos -0.2
            ypos 0.25
        show fiupoz1szem2 onlayer elotte6
        hide dagififi5 onlayer elotte6
        show dagififi5 onlayer elotte6:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        show screen invertori2
        show invertori onlayer elotte6:
            yalign 0.0
        play sound "audio/ajto2.wav"
        play music "audio/banyabolt.ogg" fadeout 1
        f "What is it? Did Grandma bite you?"
        da "That evil dog made this! Can you help me? I am bleeding!"
        f "Well done soldier! Rest a bit! I will ask for bandage. I should look for Debra now."
        da "Hurry man! I am bleeding!"
        f "You shall not die from this injury."
        play sound "audio/morog.wav"
        show dagiallas1 sir onlayer elotte6:
            zoom 1.1
            xzoom -1.0
            xpos -0.2
            ypos 0.25
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1szem2 onlayer elotte6:
            alpha 1.0
            linear 1.0 alpha 0.0
        hide dagiallas1
        hide dagilabver
        show dagiallas1 sir:
            xzoom -1.0
            zoom 0.6
            xpos 0.2
            ypos 0.2
            alpha 0.0
            linear 1.0 alpha 1.0
        show dagilabver:
            xzoom -1.0
            zoom 0.6
            xpos 0.2
            ypos 0.2
            alpha 0.0
            linear 1.0 alpha 1.0
        jump engedejek
$ renpy. pause(hard=True)
label dagivalbeszelszanapaliban:
    hide screen nappali
    if dagiszovege == 4:
        $ dagiszovege = 1
    if dagiszovege == 3:
        $ dagiszovege = 4
        da "Farewell cruel world! "
    if dagiszovege == 2:
        $ dagiszovege = 3
        da "The world is getting dark."
    if dagiszovege == 1:
        $ dagiszovege = 2
        da "Hurry man! I am bleeding!"
    if debratolelsosegej == 2:
        $ dagitmegharaptafifi = 2
        show dagilabkotes:
            xzoom -1.0
            zoom 0.6
            xpos 0.2
            ypos 0.2
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I will help you to go home, ok? I have to ask Zoli about the rumors anyway. It is in the same direction."
        da "Thank you Fred! You saved my life!"
        f "Let us go!"
        da "Yeah! Goodbye my wonderful Senyorita!"
        f "Are you talking to the dog?"
        da "Asshole! I talked to Grandma!"
        jump terkep
    show screen nappali
$ renpy. pause(hard=True)
label negyedigszervegejelenet:
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 2.0
    be "Hey Fred!I was not seeing you for a long time!"
    f "Yeah. We did not meet for years!"
    d "Do not even bother to notice me! You do not have to deliver me a greeting…"
    show fredanapalibanpoz1bszem2:
        alpha 1.0
        linear 0.5 alpha 0.0
    show fredanapalibanpoz2j:
        alpha 0.0
        linear 0.5 alpha 1.0
    f "Hello Debra!"
    d "Welcome Fred! I am happy I did not see you for a few hours. This newspaper is helping me to not see you often.."
    be "I heared from Debra, you are worriing about something. "
    show fredanapalibanpoz1bszem2:
        alpha 0.0
        linear 0.5 alpha 1.0
    show fredanapalibanpoz2j:
        alpha 1.0
        linear 0.5 alpha 0.0
    f "To be honest, I heared some rumors about the death of my father. I must go after the truth."
    be "What kind of rumors? Your father committed suicide. Do not believe those crazy rumors!"
    be "You should not worry about such things!"
    f "Maybe you have right, but I need to know…"
    be "These rumors are irrational! You should learn and have fun now! You are so young."
    f "But someone had seen a stranger around the ruins last night."
    be "It was only a homeless man for sure... He has been searching for items he can sell. Do not worry about this!"
    be "You should go out and have some fun instead! Here you are! I give you 5000 Ft. Go! Enjoy life!"
    $ penz += 5000
    f "Thank you! Still, I will be looking around."
    be "Ok, but do not forget to relax sometimes!"
    d "I want ot go out! Do you have money for me?"
    be "I have thought you were reading your newspapers and you were not listening to us."
    show debranapalibanolvassa onlayer elotte6
    d "Next time, when you come home, bring your sexual arousal home instead of your jerk behavior..."
    hide debranapalibanolvassa onlayer elotte6
    be "Oh Honey! We did not do it a long time ago!"
    hide fredanapalibanpoz1bszem2
    show fredanapalibanpoz1bszem1
    d "Yeah! Not so long ago! Last week? Last month? Last year?"
    be "You should better watch the television Honey…"
    d "I better go to clean the bathroom… You had come home only to sleep. You will leave tomorrow allready…"
    show nappali ujsag:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraujsaggal:
        alpha 1.0
        linear 1.0 alpha 0.0
    be "Well... well... Where did we stop our conversation Fred?"
    hide fredanapalibanpoz1bszem1
    show fredanapalibanpoz1bszem2
    f "You asked me to learn and have fun instead of searching around. "
    be "That is it boy! Have fun! Enjoy life!"
    be "I should go now. I should sleep a bit. I will be traveling all day long tomorrow to reach a great business meeting."
    f "Ok! Have a nice trip! And good luck!"
    show fateralap:
        alpha 1.0
        linear 1.0 alpha 0.0
    show faterpislognapaliban:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fredanapalibanpoz1bszem2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fredprogramoz onlayer hatso:
        zoom 0.7
        xpos 0.1
        ypos 0.5
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 2.0
    play music "audio/tvadas.ogg" fadeout 1
    pause 10.0
    d "{size=-10}Fred! Please come! I am in the bathroom!"
    f "I am on my way! I need to turn off the television first!"
    stop music
    $ invertorinejelenyenmeg = True
    jump furdo
$ renpy. pause(hard=True)
label napalijelenet5resz:
    $ fekete = True
    $ debraholcsinal = "napaliban3"
    $ lizagyurulyesvetlanatol = 5
    $ porszivofelveni = 1
    show hugy:
        zoom 0.3
        alpha 0.5
        xpos 0.63
        ypos 0.77
    show konyhapohar:
        xpos 0.32
        ypos 0.14
    show debrafelmos:
        zoom 0.4
        xpos 0.4
        ypos 0.52
    show fredanapalibanpoz1jszem2
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    f "Hello Debra! Had Fifi peed on the floor again?"
    d "Nope. It was an accident. I knocked down the glass..."
    f "I would like to ask you a favor."
    d "Just a minute…"
    show hugy:
        alpha 0.5
        linear 4.0 alpha 0.0
    show screen s4
    u ""
    hide nappalitv onlayer elotte6
    show nappalitv
    hide hugy
    show debrafelmos:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fredanapalibanpoz1jszem2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "What kind of favor?"
    if lampatkidobni5resz == 1:
        f "Can you lend me a lamp?"
    if lampatkidobni5resz == 2:
        f "I found a lamp in the corridor. Can I have it?"
    d "Do you need a lamp? Can you not sleep in the dark? Are you afraid?"
    f "No, It is not for me! I need Liza's ring so I need…."
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show screen perc10
    pause 2.0
    hide screen perc10
    show debrapoz4
    hide debrapoz2
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    f "…. And Svetlana found it and ……"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show screen perc25
    pause 2.0
    hide screen perc25
    show debrapoz1
    hide debrapoz4
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    d "Ok… I understood this well... You search for a lamp to buy the water bottle…"
    f "Brandy bottle. Yeah!"
    d "Ok, But tell me, did you like the sandwiches?"
    show fiupoz1szem2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    if csiposzenyo == 0:
        f "Yeap. It was tasty."
    if csiposzenyo == 1:
        f "The secound one was a bit spicy tough…"
    show debrapoz4:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    if csiposzenyo == 1:
        d "Oh... It was an accident!"
    hide fiupoz1szem2
    show fiupoz1
    if csiposzenyo == 1:
        f "Sure…"
    if lampatkidobni5resz == 1:
        d "Now, take the lamp. I wanted to throw it in the trash anyway…"
    if lampatkidobni5resz == 2:
        d "I do not care about it anymore."
    f "Thank you! You are so kind to me!"
    show debrapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz4:
        alpha 1.0
        linear 1.0 alpha 0.0
    d "Just shut up!"
    f "Ok."
    if lampatkidobni5resz == 1:
        d "Please throw out the rubbish bag when you go out!"
    if lampatkidobni5resz == 2:
        d "If that is all…"
    d "I want to watch the Television. Bye!"
    show fiupoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "I am off now!"
    d "Just go away!"
    show fiupoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debratvnezalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debratvnezpislog:
        alpha 0.0
        linear 1.0 alpha 1.0
    jump engedejek
$ renpy. pause(hard=True)
label napalijelenet5reszv2:
    play music "audio/tv5reszvege.ogg" fadeout 1
    hide debratvnezalap
    hide debratvnezpislog
    hide screen invertori2
    hide invertori onlayer elotte6
    show fredanapalibanpoz1bszem2:
        zoom 0.85
        ypos 0.058
        xpos 0.075
    show debraakanapenulnapali5resz

    $ fekete = True
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    d "Where have you been?"
    f "Are you still awake?"
    d "I asked you first!"
    f "I just visited a friend in the Strip Bar…"
    d "What a lie! The guardians would not let you inside. Next time you should tell me, if you stay out late."
    d "I thought you had an accident and I was happy. I tought i will get my gateway room back."
    f "No, I am fine. What are you watching now?"
    d "I do not know. I almost fell asleep. This is some kind of a fucking rality show..."
    f "I love it! Can I watch the show with you?"
    d "I do not care, just shut up!"
    hide nappalitv onlayer elotte6
    show nappalitv
    show vegsojelenet5resz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    f "How did you spend your day?"
    d "Shut Up!... I get tired of your questions!"
    f "Alright!"
    pause 5.0
    show vegsojelenet5resz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    d "That little shit. He can't even stay awake until midnight. Did he visit a strip bar? Nonsense!"
    pause 3.0
    show vegsojelenet5resz3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show vegsojelenet5resz4:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show vegsojelenet5resz5:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s3
    u ""
    show vegsojelenet5resz6:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    dg "{size=-10}What Is this smell?... Hm…. Penis... It smells like penis… How long I have been missing this smell..."
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 4.0 alpha 1.0
    show screen s4
    u ""
    hide vegsojelenet5resz6
    hide fredanapalibanpoz1bszem2
    hide debraakanapenulnapali5resz
    hide vegsojelenet5resz1
    hide vegsojelenet5resz2
    hide vegsojelenet5resz3
    hide vegsojelenet5resz4
    hide vegsojelenet5resz5
    hide screen vege
    show text "{b}{size=+10}End Of Day 5" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    pause 3.0
    hide text onlayer screens
    show screen s1
    u ""
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ debraholcsinal = "sehol"
    $ esteighatralevoido = 50000
    $ fekete = True
    $ megetedvanszedvicsed = 0
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ dolgozolmosogatas = 0
    $ szenyeseltakaritasa = 0
    $ szenyeskimosva = False
    $ szenyeskimosvaahejen = False
    $ dolgozolmosogataselteltido = 0
    $ Tanulnimatematikaido = 60
    $ Tanulnimatematikaeltetido = 0
    $ Tanulniepiteszetido = 60
    $ Tanulniepiteszeteltetido = 0
    $ Tanulnitortenelemido = 60
    $ Tanulnitortenelemeltetido = 0
    $ szenyesnalad = False
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ szenyesafoldon = True
    $ poharnalad = False
    $ fifitfelvetem = False
    $ baloldaliszomszed = 0
    $ jobboldaliszomszed = 0
    $ hanyadiknapvan += 1
    $ taskafel = 3
    $ torloszivacsnalad = False
    $ dolgozolmosogatasido = 30
    $ dolgozoltakaritido = 20
    $ dolgozoltakaritelteltido = 0
    $ porszivofelveni = 0
    $ porszivofeladet = 1
    $ wczett = 0
    $ debravalamitcsinalido = 60
    $ debraholcsinal = "furdo2"
    pause 1.0
    hide fekete onlayer screens
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori2
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide debrapozelpirul
    show debrapozelpirul:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Did you wake up?"
    f "Yeah but I was sleeping on the couch all night long."
    show debrapozelpirul:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Really?"
    f "Well... yeah. Did something happen?"
    show debrapozelpirul:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    d "No, I just wonder, how can you sleep so deep anyway?"
    f "I was tired. I have luck. We don’t have any lessons today at the university. I have my day off."
    d "Cool. Pick up the vacuum cleaner and clean all the carpets in the house! I have to go out."
    f "Where are you going?"
    show debrapoz2meltartoval:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapozelpirul:
        alpha 1.0
        linear 1.0 alpha 0.0
    d "This is not your business."
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Sure, I was just interested..."
    d "I will go out with my Girlfriend. We will look around the city and we will eat in a restaurant."
    show debrapoz2meltartoval:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapozelpirul:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Sounds great! Where can I find the vacuum cleaner?"
    d "You will find the vacuum cleaner in the storage room. I have to go now. I have something to do before I leave."
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapozelpirul:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ debraholcsinal = "dolgozo"
    $ mamaholvan = "Konyha"
    jump engedejek
$ renpy. pause(hard=True)
label napalijelenet6resz:
    $ debravegigpan = 2
    hide nappalitv onlayer elotte6
    show nappalitv
    if fekete == False:
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
    $ fekete = True

    show csillagok6resz onlayer elotte:
        xpos 0.1
        ypos -3.5
        linear 10.0 ypos 1.2
    show debrapan6resz1 onlayer elotte:
        xpos 0.1
        ypos 1.2
        linear 10.0 ypos -3.5
    show screen s1e5
    u ""
    play sound "audio/csillag.ogg"
    show screen s8e5
    u ""
    show debrapucban1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapozpuc1:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "You look fantastic Debra!"
    d "Thank you, but I am feeling ashamed when I am dressing like this."
    d "I think my tummy is just big… and it shows."
    show debrapozpuc1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapozpuc2:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Do you think so?"
    show fiupoz1szem2
    hide fiupoz1
    f "Not really! Believe me!"
    show debrapozpuc2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapozpuc1:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Well, fine. I have to fix my shoes and my hair. My girlfriend can arrive any minute."
    show ferdallofaszszem2:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Good for you!"
    d "The only problem is, I can not find my earrings. I wear those special earrings every time I go out. I lose them every time... Can you find the earrings for me? I will fix my hair now..."
    show ferdallofaszszem2:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "Of course!"
    $ debrafulbevalotmegkeresni1 = 1
    show debrapucban1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapozpuc1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1szem2:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    hide debrapucban1
    show debrapucban1:
        alpha 1.0
        pause 5.0
        linear 1.0 alpha 0.0
        pause 5.0
        linear 1.0 alpha 1.0
        repeat
    show debrapucban2:
        alpha 0.0
        pause 5.0
        linear 1.0 alpha 1.0
        pause 5.0
        linear 1.0 alpha 0.0
        repeat
    show nappalitv onlayer elotte6
    hide nappalitv
    jump engedejek
$ renpy. pause(hard=True)
label debrabeszelni6resznapali:
    hide screen nappali
    hide screen invertori
    show screen invertori2
    hide haznappalikozeli
    $ fekete = True
    if debrafulbevalo2 == 1:
        $ debrafulbevalo2 = 2
        $ debrafulbevalotmegkeresni1 = 3
        show nappalitv
        hide nappalitv onlayer elotte6
        hide debrapucban2
        hide debrapucban1
        hide debrapucban2fulbe2
        show debrapucban1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show haznappalikozeli:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapozpuc1:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.0
        hide debrapozpuc1
        show debrapozpuc1:
            alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            repeat
        show debrapozpuc2:
            alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            repeat
        show debrapozpuc2fulbe1:
            alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            repeat
        show debrapozpuc2fulbe2:
            alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            repeat
        f "Here you have the earring! I found it between the laundry."
        d "Who cares... I have it now. I hope Ancika arrives shortly!"
        hide debrapozpuc1
        hide debrapozpuc2
        hide debrapozpuc2fulbe2
        hide debrapozpuc2fulbe1
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapozpuc2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show haznappalikozeli:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapozpuc2fulbe1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapozpuc2fulbe2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapucban2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapucban2fulbe2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapucban2fulbe1:
            alpha 0.0
            linear 1.0 alpha 1.0
        play sound "audio/cseng.ogg"
        pause 2.0
        d "{size=+20}Come in Ancika!"
        stop sound
        play sound "audio/ajto2.wav"
        show ancik:
            zoom 0.65
            xzoom -1.0
            xpos 0.45
            ypos 0.22
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        show haznappalikozeli:
            alpha 0.0
            linear 1.0 alpha 1.0
        show ancik:
            zoom 0.65
            xzoom -1.0
            xpos 0.45
            ypos 0.22
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapucban2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapucban2fulbe2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapucban2fulbe1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            xpos -0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapozpuc2:
            xpos 0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapozpuc2fulbe1:
            xpos 0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapozpuc2fulbe2:
            xpos 0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        show ancikpoz1:
            xzoom -1.0
            xpos 0.25
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        anc "Are you ready Debra?"
        d "Of course! Let Us go! Let's have some fun!"
        show fiupoz1:
            xpos -0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapozpuc2:
            xpos 0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapozpuc2fulbe1:
            xpos 0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapozpuc2fulbe2:
            xpos 0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show ancikpoz1:
            xzoom -1.0
            xpos 0.25
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        $ debraholcsinal = "tavolvan"
        show nappalitv onlayer elotte6
        hide nappalitv
        show haznappalikozeli:
            alpha 1.0
            linear 1.0 alpha 0.0
        jump engedejek
    if debrafulbevalo1 == 2:
        hide fiupoz1
        hide debrapozpuc1
        show nappalitv
        hide nappalitv onlayer elotte6
        hide debrapucban2
        hide debrapucban1
        hide debrapucban2fulbe2
        show debrapucban1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show haznappalikozeli:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapozpuc1:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.0
        hide debrapozpuc1
        show debrapozpuc1:
            alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            repeat
        show debrapozpuc2:
            alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            repeat
        show debrapozpuc2fulbe2:
            alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            repeat
        f "What did you say? Where could you lose it?"
        d "Between the laundry! Idiot!"
        hide debrapozpuc2fulbe2
        hide debrapozpuc1
        hide debrapozpuc2
        show debrapozpuc1:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        show debrapucban1:
            alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            repeat
        show debrapucban2:
            alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
            pause 5.0
            linear 1.0 alpha 0.0
            repeat
        if debrafulbevalo1 >= 2:
            show debrapucban2fulbe2:
                alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                repeat
        show nappalitv onlayer elotte6
        hide nappalitv
        show haznappalikozeli:
            alpha 1.0
            linear 1.0 alpha 0.0
        jump engedejek
    if debrafulbevalo1 == 1:
        if mamanyaklanc == 1:
            show nappalitv
            hide nappalitv onlayer elotte6
            $ debrafulbevalotmegkeresni2 = 1
            $ debrafulbevalo1 = 2
            hide debrapucban2
            hide debrapucban1
            hide debrapucban2fulbe2
            show debrapucban1:
                alpha 1.0
                linear 1.0 alpha 0.0
            show haznappalikozeli:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1:
                alpha 0.0
                linear 1.0 alpha 1.0
            show debrapozpuc1:
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 1.0
            hide debrapozpuc1
            show debrapozpuc1:
                alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                repeat
            show debrapozpuc2:
                alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                repeat
            show debrapozpuc2fulbe2:
                alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                repeat
            f "I found two types of jewellery. One of these does not look like an earring."
            d "Yeah, because it is a necklace... smart eyes..."
            f "Ok, but I can not find the other earring. What did you do today?"
            d "Let us see. I picked up the earrings. I had a bath and I picked up the laundry... I washed some dishes.. ."
            f "Who does this necklace belong to?"
            d "This is Grandmother’s necklace. Keep it. She loses this old necklace every time and she never misses it really. I pick it up every time and give it back but she loses it in 5 minutes..."
            f "Ok, I will keep it now. I will look around the house. Maybe I can find the other earring for you."
            hide debrapozpuc1
            hide debrapozpuc2
            hide debrapozpuc2fulbe2
            show debrapozpuc1:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            show debrapucban1:
                alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                repeat
            show debrapucban2:
                alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                repeat
            if debrafulbevalo1 >= 2:
                show debrapucban2fulbe2:
                    alpha 0.0
                    pause 5.0
                    linear 1.0 alpha 1.0
                    pause 5.0
                    linear 1.0 alpha 0.0
                    repeat
            show nappalitv onlayer elotte6
            hide nappalitv
            show haznappalikozeli:
                alpha 1.0
                linear 1.0 alpha 0.0
            jump engedejek


    f "I did not find her earring. I can not disturb her."
    jump engedejek
$ renpy. pause(hard=True)
label mamabeszelni6resznapali:
    hide screen nappali
    hide screen invertori
    show screen invertori2
    f "She seems to be very bussy now.I won't disturb her."
    show screen nappali
    hide screen invertori2
    show screen invertori
$ renpy. pause(hard=True)
label mamabeszelni8resznapali:
    hide screen nappali
    hide screen invertori
    show screen invertori2
    hide haznappalikozeli
    hide mamapoz3r1
    hide fiupoz1
    hide nappalitv onlayer elotte6
    show nappalitv
    show haznappalikozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamapoz3r1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    if kerdezkorbe8resz == True:
        if mamatkerdezted8resz == False:
            if receptnalad == 0:
                f "Grandma! Can you please help me?"
                m "Grandma has no money. If there were some money in my pocket, Grandma might spend it all on alcohol.."
                f "I do not need money now. Do you know any kind of trick to heal sunburn?"
                m "Drink a lot of egg liqueur. You will forget the pain for sure."
                f "I am not suffering from sunburn. Will Mr. Puli like this idea? I do not know."
                m "Who the hell is Mr. Puli? Is he rich? Is he handsome? Does he have money?"
                f "You asked about the money two times…"
                m "Grandma knows all the serious things. Is he rich?"
                f "I do not think so. He is Liza’s husband. He is a big, fat guy, He is the type you would love Grandma."
                m "I do not need any more fat partners. Your best friend is a stallion. I only have to make him wild a bit."
                m "Did he ask about me?"
                f "Of course he did. He will visit us shortly. He did not want to come without any present."
                m "Fucking alright! Tell him, I miss him and I send him a biiigggg kiss!"
                f "I will. I have to go now."
                $ mamatkerdezted8resz = True
                if boltostkerdezted8resz == True:
                    if debratkerdezted8resz == True:
                        if mamatkerdezted8resz == True:
                            $ fodoholvan = "boltelott"
                show haznappalikozeli:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show mamapoz3r1:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz1:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1
                u ""
                show nappalitv onlayer elotte6
                hide nappalitv
                show screen nappali
                hide screen invertori2
                show screen invertori
            $ renpy. pause(hard=True)
    if receptnalad == 1:
        if lizanakmegmutatadareceptet == False:
            f "Can you read me this recipe?"
            m "Whta the fuck is this?"
            f "A recipe."
            m "Grandma can not read this shit!"
            show haznappalikozeli:
                alpha 1.0
                linear 1.0 alpha 0.0
            show mamapoz3r1:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            show nappalitv onlayer elotte6
            hide nappalitv
            show screen nappali
            hide screen invertori2
            show screen invertori
            $ renpy. pause(hard=True)
    if mamavalbeszeltel == 3:
        $ mamavalbeszeltel = 0
    if mamavalbeszeltel == 2:
        $ mamavalbeszeltel = 3
        f "What are you doing here Grandma?"
        m "Nothing at all, I am practicing to stand."
        f "…Have a nice time!"
    if mamavalbeszeltel == 1:
        $ mamavalbeszeltel = 2
        m "Are you sexually harassing me? I am in!"
        f "No, I am just hanging around here."
    if mamavalbeszeltel == 0:
        $ mamavalbeszeltel = 1
        f "I saw you in this dress a long time ago."
        m "The mornings are cold. I have to dress warmly. Don’t you have something better to do?"
        f "I have… Goodbye!"
    show haznappalikozeli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mamapoz3r1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show nappalitv onlayer elotte6
    hide nappalitv
    show screen nappali
    hide screen invertori2
    show screen invertori
$ renpy. pause(hard=True)
label ferdtvnezzen:
    hide screen nappali
    show nappalitvtaviranyito:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ esteighatralevoido = 0
    $ tiltjaadebrakertjet = True
    $ neztvt9resz = 2
    $ tiltjaaterkepet = True
    $ mamaholvan = "szobajaban"
    $ debraholcsinal = "szobajabanmaszturbal9resz"
    hide fredprogramoz onlayer hatso
    show fredprogramoz onlayer hatso:
        zoom 0.7
        xpos 0.1
        ypos 0.5
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    f "Let us see the TV program."
    f "This is borring…"
    f "I saw this..."
    f "I do not care about the news..."
    f "Someone is searching for the stars again... The detected stars just disappeared... Maybe there is a big black hole, which swallows them all... Hehhe…."
    f "A fucking reality show again. The characters are all actors and actresses…"
    f "Another fake quiz show..."
    f "This is a Malambo episode. I am surprised they play this series now... I should call Debra. "
    show fredprogramoz onlayer hatso:
        zoom 0.7
        xpos 0.1
        ypos 0.5
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen nappali
$ renpy. pause(hard=True)
label bertalannalbeszelsz10resz:
    hide screen invertori2
    hide invertori onlayer elotte6
    $ fekete = True
    $ tiltjaaterkepet = True
    $ tiltjaadebrakertjet = True
    $ bertalanholvan = "sehol"
    $ mamaholvan = "szobajaban"
    $ debraholcsinal = "dolgozo"
    $ esteighatralevoido = 0
    $ alhat10reszvegen = 1
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    f "Hy Bertalan!"
    be "Hy! What is up? How are you?"
    f "I am fine. Has your business trip ended?"
    f "Will you stay longer this time?"
    be "No kid. I came only to give some money to Debra. I need to continue my trip tomorrow."
    be "Debra went to sleep. I am watching television and I wanted to talk with you. How do you feel?"
    f "I am ok. I still miss Dad, but I get used to being alone. He traveled a lot, too."
    be "Yeap. Our work is really hard. Now I have to do all the trips. I was left alone in our firm. I miss your father a lot."
    f "Can I help you?"
    be "No Fred! Learn and enjoy the freedom and your freetime. You have to forget about all the terrible things!"
    be "Are you still worried about those crazy rumors?"
    f "Not anymore."
    be "Very well. I am proud of you. Do not listen to those rumors. They are all lies."
    be "Now I have to go."
    f "Realy?"
    be "This is business. I go to bed early so I can wake up early. The business is running, it will never wait for you to catch up boy!"
    f "Well. Goodnight and goodbye if we won't meet tomorrow morning."
    be "Take care of yourself kid! Take care of my family!"
    show faterpislognapaliban:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fateralap:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "I will."
    show fredanapalibanpoz1bszem2:
        alpha 1.0
        linear 1.0 alpha 0.0
    jump engedejek
$ renpy. pause(hard=True)
label izzocseremegkeres11nap:
    $ debra11napfeladatotad = 1
    $ fekete = True
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    d "Fred! Nice to see you!"
    hide nappalitv onlayer elotte6
    show nappalitv
    show haznappalikozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz4 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "W-what is it? Are you drunk?"
    d "Haha… Funny! First of all! Stand like a human and stop scratching while you speak to me! Do you have fleas?"
    show fiupoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Sorry! What do you wish for?"
    d "Some bulbs burned out. Could you change them to some new bulbs?"
    f "Of course, but I can not reach the lamp. It is too high."
    d "I know, Idiot!"
    d "The Ladder is in the backyard, and our neighbor gave it back in the morning... Bring it here."
    d "You find the bulbs in the storage room."
    f "Can I ask you something?"
    show debrapoz4 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Spit it out and go! Do what I said!"
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Do people turn on the lights by sleepwalking?"
    f "If not… How do they not step on something and why do they not fall?"
    d "Let me think a bit before I answer…"
    show screen s2
    u ""
    show debrapoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Hey! Fred! Would you like to clean your bleeding nose with your broken hand or not?"
    show fiupoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "If I understand this well… I should go now and change the bulbs, but fast before I get …hurt…"
    d "It will turn out, you are not such a big Idiot in the end… Such a surprise…"
    d "Now… Move! You have to change those bulbs before it gets dark!"
    $ debraholcsinal = "napaliban3"
    show debratvnezalap
    show debratvnezpislog
    hide debraall
    show haznappalikozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    jump engedejek
$ renpy. pause(hard=True)
label napalijelenet11nap:
    hide screen nappali
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen invertori2
    $ debra11napfeladatotad = 2
    $ izzoknalad = 2
    $ letranalad = 2
    show letraraahejen:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    hide nappalitv onlayer elotte6
    show nappalitv
    show haznappalikozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz4 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    f "Here is the ladder. Now you can change the bulbs."
    d "Are you insane? I will definitely not climb on the ladder!"
    f "Who would climb it on?"
    show debrapoz4 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Guess one!"
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Grandma?"
    d "Nope! Guess another!"
    f "Where is Fifi? I did not see her for a while…"
    d "Do not worry, she is fine. The usurer took her. She got used to it."
    d "Do not change the subject!"
    f "Super! What is for dinner?"
    show debrapoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Listen carefully!"
    show fiupoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Sure…"
    d "Climb on that ladder and change the bulbs before I hit you!"
    f "Do not shake the ladder! I am afraid of the heigh!"
    d "Are you kidding me?"
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    hide fiupoz5 onlayer elotte
    show fiupoz5 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "No! I am afraid!"
    show debrapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapozelpirul onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "This is so cute and disgusting."
    show fiupoz5 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Can I climb down?"
    show debrapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapozelpirul onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    d "Now move as long as I talk nicely and softly! I will hold the ladder so you feel safer, Idiot!"
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "I can not do anything else… Let us get this over with!"
    d "As you saied… Climb!"
    show letrarafel
    hide nappalitv
    show nappalitv
    hide debratvnezalap
    hide debratvnezpislog
    hide letraraahejen
    hide haznappalikozeli onlayer elotte
    hide debrapoz1 onlayer elotte
    hide fiupoz4 onlayer elotte
    show haznappalikozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s3
    u ""
    d "Are you afraid?"
    f "Well… I don't feel safe now..."
    with vpunch
    show screen s05
    d "Watch out!"
    hide debrapoz4 onlayer elotte
    hide debrapoz2 onlayer elotte
    hide fiupoz2 onlayer elotte
    hide debrapoz8 onlayer elotte
    hide fiupoz5 onlayer elotte
    hide debrapozelpirul onlayer elotte
    hide haznappalikozeli onlayer elotte
    hide debrapoz1 onlayer elotte
    hide fiupoz4 onlayer elotte
    show debracicibaszi11napjelenet2arc1 onlayer elotte
    f "Stop it! I am afraid!"
    show debracicibaszi11napjelenet1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    play music "audio/szexy.ogg" fadeout 1
    d "I did not do anything, the ladder slipped a bit…"
    d "I am holding it tight. Climb up!"
    f "No need for it! I can reach the bulbs from here."
    d "Just do it and shut up!"
    fg "Oh shit! My penis is touching her boobs! I did not cum today... I am afraid my penis will get hard..."
    dg2 "Is his penis pushing my boobs?"
    dg2 "Should I feel pleased or should I shake him down from the ladder? He is getting a hard on..."
    f "Let me continue this…"
    d "Do it…"
    show debracicibaszi11napjelenet3moz1 onlayer elotte
    show debracicibaszi11napjelenet3szaj1 onlayer elotte
    show debracicibaszi11napjelenet3szemanim onlayer elotte
    hide debracicibaszi11napjelenet1 onlayer elotte
    show debracicibaszi11napjelenet1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1e5
    u ""
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    show debracicibaszi11napjelenet3szajanim onlayer elotte
    d "Would you like to change places? Should I climb up?"
    show debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szajanim onlayer elotte
    f "No! I will make it..."
    dg2 "How hard his penis became… He does not even want to climb down anymore..."
    hide debracicibaszi11napjelenet2arc1 onlayer elotte
    show debracicibaszi11napjelenet2arc1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "Shit! It is hard as rock! Did Debra notice it? I hope she will not find it out..."
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
    show debracicibaszi11napjelenet3anim onlayer elotte
    show debracicibaszi11napjelenet3szaj1 onlayer elotte
    show debracicibaszi11napjelenet3szemanim onlayer elotte
    hide debracicibaszi11napjelenet2arc1 onlayer elotte
    show debracicibaszi11napjelenet2arc1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    fg "Oh Fuck! My hips are moving from themselves!"
    dg2 "How should I handle this? Should I ask him? What will he answer?"
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    show debracicibaszi11napjelenet3szajanim onlayer elotte
    d "Fred! What are you doing with your legs?"
    show debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szajanim onlayer elotte
    fg "Oh Shit! Stop! Do not move! I should tell her something… something clever…"
    f "My legs are shaking a bit… Never mind!"
    dg2 "What a clever answer… He is good. Why did he not tell: I am fucking your boobs..."
    dg2 "Why do I allow him to do this to me? I should just step way back and he would not reach my boobs anymore..."
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    show debracicibaszi11napjelenet3szajanim onlayer elotte
    d "Understood. Change the bulbs!"
    show debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szajanim onlayer elotte
    dg2 "I should say: Stop being a pervert! Or I will hit you!..."
    f "I have to put the lampshades down first…"
    dg2 "This will take for a while it seems…"
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    show debracicibaszi11napjelenet3szajanim onlayer elotte
    d "Just do it!"
    show debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szajanim onlayer elotte
    hide debracicibaszi11napjelenet2arc2 onlayer elotte
    show debracicibaszi11napjelenet2arc2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "She did not notice me or… she allowed it? …What should I do now?"
    show debracicibaszi11napjelenet4anim onlayer elotte
    hide debracicibaszi11napjelenet2arc2 onlayer elotte
    show debracicibaszi11napjelenet2arc2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    dg2 "How would someone not notice what he is doing? …This feels good in some way…"
    show screen s3
    u ""
    dg2 "I feel sexy and confident... I felt this a long time ago..."
    show screen s3
    u ""
    dg2 "His penis so hard and it is hard for me…"
    show screen s3
    u ""
    dg2 "I love it… I will allow him to finish it..."
    show screen s3
    u ""
    show debracicibaszi11napjelenet5anim onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    dg2 "Who is the bad guy here? The one who makes it or the one who allows it?"
    show screen s3
    u ""
    dg2 "He is a young man with urges… but I am an old housewife... Why did I get so excited?"
    show screen s3
    u ""
    dg2 "I should stop this... I am married…"
    show screen s3
    u ""
    dg2 "I shoudl disturb him a bit..."
    d "Why does it take so long? Hurry!"
    show debracicibaszi11napjelenet2arc2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "I am doing it! I am doing it! I am almost done…"
    fg "This feels fantastic! Her boobs are so soft!"
    show debracicibaszi11napjelenet2arc2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s3
    u ""
    show debracicibaszi11napjelenet6 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    dg2 "Alright! I am satisfied with this work..."
    dg2 "He seems to forget his agoraphobia…"
    show debracicibaszi11napjelenet6 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen debracicibaszi11nap
$ renpy. pause(hard=True)
label debracicibaszi11napgyengen:
    if debracicibaszi11nap == "sehogy":
        $ debracicibaszi11nap = "ot"
        show debracicibaszi11napjelenet7moze1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        show debracicibaszi11napjelenet7animgy onlayer elotte
        hide debracicibaszi11napjelenet7moze1 onlayer elotte
        show debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
        show debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
        show screen s2
        u ""
        hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
        show debracicibaszi11napjelenet7mozgyszajanim onlayer elotte
        d "How long will this take?"
        show debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
        hide debracicibaszi11napjelenet7mozgyszajanim onlayer elotte
        f "It won't take so long!My legs are Shaking a bit more, I am sorry…"
        hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
        show debracicibaszi11napjelenet7mozgyszajanim onlayer elotte
        d "I noticed it… Tell me if you are finished!"
        show debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
        hide debracicibaszi11napjelenet7mozgyszajanim onlayer elotte
    else:



        hide debracicibaszi11napjelenet7anime onlayer elotte
        hide debracicibaszi11napjelenet7anime2 onlayer elotte
        hide debracicibaszi11napjelenet7animgy onlayer elotte
        hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
        hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
        show debracicibaszi11napjelenet7animgy onlayer elotte
        show debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
        show debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
        if debracicibaszi11naperoseg == "vissza3":
            hide debracicibaszi11napjelenet3anim onlayer elotte
            hide debracicibaszi11napjelenet3szaj1 onlayer elotte
            hide debracicibaszi11napjelenet3szemanim onlayer elotte
            show debracicibaszi11napjelenet3anim onlayer elotte:
                alpha 1.0
                linear 0.5 alpha 0.0
            show debracicibaszi11napjelenet3szaj1 onlayer elotte:
                alpha 1.0
                linear 0.5 alpha 0.0
            show debracicibaszi11napjelenet3szemanim onlayer elotte:
                alpha 1.0
                linear 0.5 alpha 0.0
        if debracicibaszi11naperoseg == "vissza2":
            hide debracicibaszi11napjelenet4anim onlayer elotte
            show debracicibaszi11napjelenet4anim onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
        if debracicibaszi11naperoseg == "vissza":
            hide debracicibaszi11napjelenet5anim onlayer elotte
            show debracicibaszi11napjelenet5anim onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
    show screen s1
    u ""
    $ debracicibaszi11naperoseg = "lassu"
    hide debracicibaszi11napjelenet7anime2 onlayer elotte
    hide debracicibaszi11napjelenet7anime onlayer elotte
    hide debracicibaszi11napjelenet5anim onlayer elotte
    hide debracicibaszi11napjelenet4anim onlayer elotte
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
    show screen s6
    u ""
    show screen debracicibaszi11nap
$ renpy. pause(hard=True)
label debracicibaszi11naperosen:
    if debracicibaszi11nap == "sehogy":
        $ debracicibaszi11nap = "ot"
        show debracicibaszi11napjelenet7anime onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime onlayer elotte
    show debracicibaszi11napjelenet7anime onlayer elotte
    $ debracicibaszi11naperoseg = "gyors"
    show screen s6
    u ""
    show screen debracicibaszi11nap
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime2 onlayer elotte
    hide debracicibaszi11napjelenet5anim onlayer elotte
    hide debracicibaszi11napjelenet4anim onlayer elotte
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
$ renpy. pause(hard=True)
label debracicibaszi11napmegerosebben:
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime2 onlayer elotte
    show debracicibaszi11napjelenet7anime2 onlayer elotte
    $ debracicibaszi11naperoseg = "gyorsabb"
    show screen s6
    u ""
    show screen debracicibaszi11nap
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime onlayer elotte
    hide debracicibaszi11napjelenet5anim onlayer elotte
    hide debracicibaszi11napjelenet4anim onlayer elotte
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
$ renpy. pause(hard=True)
label debracicibaszi11napvissza:
    hide debracicibaszi11napjelenet5anim onlayer elotte
    show debracicibaszi11napjelenet5anim onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s6
    u ""
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime2 onlayer elotte
    hide debracicibaszi11napjelenet7anime onlayer elotte
    hide debracicibaszi11napjelenet4anim onlayer elotte
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
    $ debracicibaszi11naperoseg = "vissza"
    show screen debracicibaszi11nap
$ renpy. pause(hard=True)
label debracicibaszi11napvissza2:
    hide debracicibaszi11napjelenet4anim onlayer elotte
    show debracicibaszi11napjelenet4anim onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s6
    u ""
    $ debracicibaszi11naperoseg = "vissza2"
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime2 onlayer elotte
    hide debracicibaszi11napjelenet7anime onlayer elotte
    hide debracicibaszi11napjelenet5anim onlayer elotte
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
    show screen debracicibaszi11nap
$ renpy. pause(hard=True)
label debracicibaszi11napvissza3:
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
    show debracicibaszi11napjelenet3anim onlayer elotte
    show debracicibaszi11napjelenet3szaj1 onlayer elotte
    show debracicibaszi11napjelenet3szemanim onlayer elotte
    hide debracicibaszi11napjelenet4anim onlayer elotte
    show debracicibaszi11napjelenet4anim onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s6
    u ""
    $ debracicibaszi11naperoseg = "vissza3"
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime2 onlayer elotte
    hide debracicibaszi11napjelenet7anime onlayer elotte
    hide debracicibaszi11napjelenet5anim onlayer elotte
    hide debracicibaszi11napjelenet4anim onlayer elotte
    show screen debracicibaszi11nap
$ renpy. pause(hard=True)
label debracicibaszi11napjelenetvege:
    show debracicibaszi11napjelenet8anim onlayer elotte:
        alpha 0.0
        linear 0.5 alpha 1.0
    show screen s2
    u ""
    u ""
    hide debracicibaszi11napjelenet7animgy onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszemanim onlayer elotte
    hide debracicibaszi11napjelenet7mozgyszaj1 onlayer elotte
    hide debracicibaszi11napjelenet7anime2 onlayer elotte
    hide debracicibaszi11napjelenet7anime onlayer elotte
    hide debracicibaszi11napjelenet5anim onlayer elotte
    hide debracicibaszi11napjelenet4anim onlayer elotte
    hide debracicibaszi11napjelenet3anim onlayer elotte
    hide debracicibaszi11napjelenet3moz1 onlayer elotte
    hide debracicibaszi11napjelenet3szaj1 onlayer elotte
    hide debracicibaszi11napjelenet3szemanim onlayer elotte
    show debracicibaszi11napjelenet9anim onlayer elotte:
        alpha 0.0
        linear 0.5 alpha 1.0
    show screen s1
    u ""
    fg "Oh shit! I hope she did not notice it..What should I say now?"
    show debracicibaszi11napjelenet9szajanim onlayer elotte
    f "I am done!"
    hide debracicibaszi11napjelenet9szajanim onlayer elotte
    hide debracicibaszi11napjelenet8anim onlayer elotte
    hide fiupoz1 onlayer elotte
    show debraujsaggal
    show debrafotelpislog
    hide nappali ujsag
    hide letrarafel
    show haznappalikozeli onlayer elotte
    show debrapozelpirul onlayer elotte
    show debrapozelpirulgecis1 onlayer elotte
    show fiupoz1 onlayer elotte
    show fiupoz1sokkoltjobra onlayer elotte
    show fiupoz1pir onlayer elotte
    show debracicibaszi11napjelenet8moz13 onlayer elotte
    hide debracicibaszi11napjelenet9anim onlayer elotte
    show debracicibaszi11napjelenet9anim onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    dg2 "I see..."
    show debracicibaszi11napjelenet8moz13 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    d "I see… It did not take so long…"
    d "Put the ladder in the storage room…"
    f "Ok..."
    play music "audio/banyabolt.ogg" fadeout 1
    show haznappalikozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapozelpirul onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapozelpirulgecis1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1sokkoltjobra onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1pir onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0

    $ letranalad = 1
    $ debraholcsinal = "ujsagotolvas"


    show screen nappali
    show invertori onlayer elotte6:
        ypos 0.0
    show screen invertori
$ renpy. pause(hard=True)
label nap11vege:
    hide nappalitv onlayer elotte6
    show nappalitv
    show fredanapalibanpoz1jszem2
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    d "Where have you been?"
    f "I put the ladder in the storage room."
    d "It took a really long time for you…"
    f "Yeap, I got tired. I should go to sleep now."
    d "Good night! I hope it won’t disturb you if I read here a bit."
    f "Of course not."
    show fredanapalibanpoz1jszem2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen invertori2
    dg "This Idiot! Did he not notice I saw him? He thinks I could not see he ejaculated?"
    dg "Where is this sperm smell coming from?"
    dg "Oh fuck! He made my t-shirt dirty with semen!"
    show debramaszti11nap onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    dg "This smell makes me horny! I will sleepwalk tonight, it seems…"
    dg "I will teach this pervert a lesson today at night…"
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 2.0 alpha 1.0
    show screen s3
    u ""
    hide screen vege
    show text "{b}{size=+10}End Of Day 11" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s3
    u ""
    hide text onlayer screens
    show debraszex12napjelenet1 onlayer elotte
    d "Fred! wake up!"
    play music "audio/szexy.ogg" fadeout 1
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    f "Debra! What are you doing here?"
    d "This is my home. I can be here."
    f "You are sleepwalking again. It shall hurt if you have woken up."
    show debraszex12napjelenet2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "Why are you coming near?"
    d "Why are you escaping? Do you think I did not notice what you do near?"
    f "D…Did you notice?"
    d "Only a blind person would not notice it..."
    f "Some way you talk is just normal now. Are you really sleeping?"
    d "Do you want me only during the day?"
    show debraszex12napjelenet3 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    d "Do you not like me at night? Can your penis not get hard again today?"
    f "It is already hard… but what if you wake up? You will kill me for sure!"
    d "You should think after and you should decide cleverly!"
    f "How should I think cleverly while you climb on me like that?"
    d "In this case let me decide and enjoy myself! I want sex!"
    f "…. Ok! Let us do it!"
    d "Oh no! Do not move! I can move only! Carefully! I might wake up..."
    f "Are you sure you are sleeping?"
    d "Yes! Idiot!"
    show debraszex12napjelenet4moz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show debraszex12napjelenet4anim6 onlayer elotte
    show screen s1
    u ""
    d "I will cum now and you will not notice it… Do not move!"
    show screen debra12napszexjel4sebesegvalt
    $ debraszex12napjel4holvagy1 = 1
    $ debraszex12napjel4holvagy2 = 0
    $ debraszex12napjel4holvagy3 = 0
    $ renpy. pause(hard=True)
label debra12napszexjel4lassu:
    hide debraszex12napjelenet4anim6 onlayer elotte
    show debraszex12napjelenet4anim6 onlayer elotte
    show screen s3
    u ""
    if debraszex12napjel4gyors == 1:
        if debraszex12napjel4gyorsabb == 1:
            $ debraszex12napjel4tovabb = 1
    $ debraszex12napjel4holvagy1 = 1
    $ debraszex12napjel4holvagy2 = 0
    $ debraszex12napjel4holvagy3 = 0
    show screen debra12napszexjel4sebesegvalt
$ renpy. pause(hard=True)
label debra12napszexjel4gyors:
    hide debraszex12napjelenet4anim8 onlayer elotte
    show debraszex12napjelenet4anim8 onlayer elotte
    show screen s3
    u ""
    if debraszex12napjel4gyors == 0:
        d "Oh yeah! nice!"
        f "Gulp…"
    $ debraszex12napjel4gyors = 1
    if debraszex12napjel4gyors == 1:
        if debraszex12napjel4gyorsabb == 1:
            $ debraszex12napjel4tovabb = 1
    $ debraszex12napjel4holvagy1 = 0
    $ debraszex12napjel4holvagy2 = 1
    $ debraszex12napjel4holvagy3 = 0
    show screen debra12napszexjel4sebesegvalt
$ renpy. pause(hard=True)
label debra12napszexjel4gyorsabb:
    hide debraszex12napjelenet4anim10 onlayer elotte
    show debraszex12napjelenet4anim10 onlayer elotte
    show screen s3
    u ""
    if debraszex12napjel4gyors == 0:
        d "This is not enough! I want more!"
    $ debraszex12napjel4gyorsabb = 1
    if debraszex12napjel4gyors == 1:
        if debraszex12napjel4gyorsabb == 1:
            $ debraszex12napjel4tovabb = 1
    $ debraszex12napjel4holvagy1 = 0
    $ debraszex12napjel4holvagy2 = 0
    $ debraszex12napjel4holvagy3 = 1
    show screen debra12napszexjel4sebesegvalt
$ renpy. pause(hard=True)
label debra12napszexjel5:
    show debraszex12napjelenet5v1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    d "Oh! I found something hard here…"
    u ""
    show debraszex12napjelenet5v2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    d "Why did this get hard?"
    u ""
    show debraszex12napjelenet5v3 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    d "I think I found the thing I lost so long ago…"
    u ""
    show debraszex12napjelenet3zoomolt onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "What does she want? Will she put my penis in her pussy?"
    fg "I am hard as a rock already. I shall cum if she has put my penis inside."
    dg2 "His boner is so big. I can barely hold it in my hand…"
    dg2 "I will play with you a bit so you get crazy…"
    d "Do not move! Let it happen!"
    show debraszex12napjelenet6v2moz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraszex12napjelenet6szemanim onlayer elotte2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraszex12napjelenet6szaj1 onlayer elotte2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show debraszex12napjelenet6v2anim6 onlayer elotte
    show screen s3
    u ""
    hide debraszex12napjelenet6szaj1 onlayer elotte2
    show debraszex12napjelenet6szajanim onlayer elotte2
    f "Do not make me suffer! Let it go inside! I am too hard!"
    show debraszex12napjelenet6szaj1 onlayer elotte2
    hide debraszex12napjelenet6szajanim onlayer elotte2
    show debraszex12napjelenet6v2anim8 onlayer elotte
    show screen s2
    u ""
    d "Do not move! Do you want me to wake up?"
    show screen s2
    u ""
    hide debraszex12napjelenet6szaj1 onlayer elotte2
    show debraszex12napjelenet6szajanim onlayer elotte2
    f "I will not move! Just do what you want!"
    show debraszex12napjelenet6szaj1 onlayer elotte2
    hide debraszex12napjelenet6szajanim onlayer elotte2
    show screen s2
    u ""
    show debraszex12napjelenet6v2anim8valt onlayer elotte
    show screen s3
    u ""
    fg "Her panties are getting wet... Why did she not pull it on the side already?"
    show debraszex12napjelenet6v2anim8valt2 onlayer elotte
    d "Do not wake me up! Lie quietly!"
    show screen s2
    u ""
    show debraszex12napjelenet6v1anim onlayer elotte
    hide debraszex12napjelenet6szaj1 onlayer elotte2
    show debraszex12napjelenet6szajanim onlayer elotte2
    f "Only the tip! Let me put the tip inside!"
    show debraszex12napjelenet6szaj1 onlayer elotte2
    hide debraszex12napjelenet6szajanim onlayer elotte2
    show screen s2
    u ""
    d "Your tip is already inside…"
    show screen s2
    u ""
    hide debraszex12napjelenet6szaj1 onlayer elotte2
    show debraszex12napjelenet6szajanim onlayer elotte2
    f "You wear those panties… I can not feel your pussy so well…"
    show debraszex12napjelenet6szaj1 onlayer elotte2
    hide debraszex12napjelenet6szajanim onlayer elotte2
    d "The panties are staying."
    hide debraszex12napjelenet6szemanim onlayer elotte2
    show debraszex12napjelenet6szemanimbecsuk onlayer elotte2
    show screen s2
    u ""
    u ""
    show debraszex12napjelenet9moz1 onlayer elotte2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraszex12napjelenet9szaj1 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraszex12napjelenet9szem1 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show debraszex12napjelenet9anim6 onlayer elotte2
    dg2 "I can not pull my panties on the side. I am married..."
    show screen s2
    u ""
    dg2 "I am an abandoned housewife… My husband never touches me…"
    show screen s2
    u ""
    dg2 "I can not have sex with Fred… But I want to feel his hard penis in my pussy…"
    show screen s2
    u ""
    u ""
    show debraszex12napjelenet9anim8 onlayer elotte2
    hide debraszex12napjelenet9szem1 onlayer elotte3
    show debraszex12napjelenet9szemanimkinyit onlayer elotte3
    show screen s2
    u ""
    hide debraszex12napjelenet9szemanimkinyit onlayer elotte3
    hide debraszex12napjelenet9szaj1 onlayer elotte3
    show debraszex12napjelenet9szajbecsuk onlayer elotte3
    show debraszex12napjelenet9szemanim onlayer elotte3
    dg2 "This feels so good... Oh yeah!"
    show screen s2
    u ""
    f "Aghhhh!!!"
    show screen s2
    u ""
    dg2 "He seems to like the situation..."
    show screen s2
    u ""
    u ""
    show debraszex12napjelenet9anim10 onlayer elotte2
    hide debraszex12napjelenet9szemanim onlayer elotte3
    show debraszex12napjelenet9szemanimbecsuk onlayer elotte3
    show screen s2
    u ""
    dg2 "Hey girl! You should stop this! You are getting too much into it! You should change the pose before the penis slips in along with the panties..."
    show screen s2
    u ""
    show debraszex12napjelenet6v1animv2 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraszex12napjelenet6szem3 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    hide debraszex12napjelenet6szaj1 onlayer elotte3
    show debraszex12napjelenet6szaj1 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    dg2 "Just a little bit more…"
    show screen s2
    u ""
    hide debraszex12napjelenet6v1animv2 onlayer elotte3
    hide debraszex12napjelenet6szem3 onlayer elotte3
    show debraszex12napjelenet12v1 onlayer elotte3
    hide debraszex12napjelenet6szem3 onlayer elotte3
    show debraszex12napjelenet6szemanimkinyit onlayer elotte3
    hide debraszex12napjelenet6szaj1 onlayer elotte3
    show debraszex12napjelenet6szaj1 onlayer elotte3
    show screen s1
    u ""
    show debraszex12napjelenet12v2 onlayer elotte3
    show screen s2
    u ""
    show debraszex12napjelenet7moz1 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show debraszex12napjelenet7mozanim onlayer elotte3
    hide debraszex12napjelenet12v1 onlayer elotte3
    hide debraszex12napjelenet12v2 onlayer elotte3
    hide debraszex12napjelenet6szemanimkinyit onlayer elotte3
    hide debraszex12napjelenet1 onlayer elotte
    hide debraszex12napjelenet2 onlayer elotte
    hide debraszex12napjelenet3 onlayer elotte
    hide debraszex12napjelenet3v2 onlayer elotte
    hide debraszex12napjelenet4anim6 onlayer elotte
    hide debraszex12napjelenet4anim8 onlayer elotte
    hide debraszex12napjelenet4anim10 onlayer elotte
    hide debraszex12napjelenet5v1 onlayer elotte
    hide debraszex12napjelenet5v2 onlayer elotte
    hide debraszex12napjelenet5v3 onlayer elotte
    hide debraszex12napjelenet3zoomolt onlayer elotte
    hide debraszex12napjelenet3zoomolt onlayer elotte
    hide debraszex12napjelenet6v2anim onlayer elotte
    hide debraszex12napjelenet6szemanim onlayer elotte2
    hide debraszex12napjelenet6v1anim onlayer elotte
    hide debraszex12napjelenet6szajanim onlayer elotte2
    hide debraszex12napjelenet6szaj1 onlayer elotte2
    hide debraszex12napjelenet9anim6 onlayer elotte2
    hide debraszex12napjelenet9anim8 onlayer elotte2
    hide debraszex12napjelenet9anim10 onlayer elotte2
    hide debraszex12napjelenet6v1animv2 onlayer elotte3
    hide debraszex12napjelenet6szem3 onlayer elotte3
    hide debraszex12napjelenet6szaj1 onlayer elotte3
    hide debraszex12napjelenet9szajbecsuk onlayer elotte3
    hide debraszex12napjelenet9szemanimbecsuk onlayer elotte3
    dg2 "Oh Yeah! Touch my clitoris with your hard cock!"
    show debraszex12napjelenet7mozanimv2 onlayer elotte3
    show screen s2
    u ""

    dg2 "I need just a little bit more! Oh yeah! Just a little bit more!"
    show screen s2
    u ""
    dg2 "Oh yeah! Faster! Faster!"
    show debraszex12napjelenet7mozanimv3 onlayer elotte3
    show screen s2
    u ""
    u ""
    show debraszex12napjelenet8v3 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show debraszex12napjelenet8v1 onlayer elotte3:
        alpha 0.0
        linear 2.0 alpha 1.0
    show screen s2
    u ""
    show debraszex12napjelenet8anim onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    d "Oh yeah! That is it! Finally! ….AAAAAAAHHHHHGGGGG……"
    f "This is too much for me!"
    show 12napfinalanim onlayer elotte3
    show screen s2
    u ""
    u ""
    show debraszex12napjelenet11 onlayer elotte3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    d "I did not get dirty at least…Hahha…Good night Fred!"
    u ""
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    play music "audio/banyabolt.ogg" fadeout 1
    $ tiltjaadebrakertjet = False
    $ tiltjaaterkepet = True
    $ esteighatralevoido = 500000
    $ ennivini = 0
    $ uditosmagamhozveni = 0
    $ isztaruhafel = 1
    $ hanyadiknapvan += 1
    $ wczett = 0
    $ taskafel = 1
    $ szedvisz1 = True
    $ szedvisz2 = True
    $ invertorialapjelenyenmeg = True
    $ nyomortanyamama = 0
    $ editholvan = "sehol"
    $ ciliholvan = "sehol"
    $ debraholcsinal = "kertbentanul"
    $ kittyholvan = "sehol"
    $ Edwardsholvan = "sehol"
    $ mrpuliholvan = "napozoagy"
    $ svetlana = "sehol"
    $ annaholvan = "sehol"
    $ fodoholvan = "sehol"
    $ ritaholvan = "sehol"
    $ amandaholvan = "sehol"
    $ lidiaholvan = "pultnal"
    $ csacsiholvan = "sehol"
    $ rozsaholvan = "sehol"
    $ holvanliza = "tornazik"
    $ eszterholvan = "boltelott"
    $ fodoholvan = "parkto"
    $ sabrinaholvan = "lakotombemelet1"
    $ tiltjaatereketsritbar = True
    hide debraszex12napjelenet11 onlayer elotte3
    hide debraszex12napjelenet8v3 onlayer elotte3
    hide debraszex12napjelenet8v1 onlayer elotte3
    hide debraszex12napjelenet4moz1 onlayer elotte
    hide debraszex12napjelenet6v2anim8valt2 onlayer elotte
    hide debraszex12napjelenet6v2anim8valt onlayer elotte
    hide debraszex12napjelenet6v2anim8 onlayer elotte
    hide debraszex12napjelenet6v2anim6 onlayer elotte
    hide debraszex12napjelenet6v2moz1 onlayer elotte
    hide debraszex12napjelenet6szemanimbecsuk onlayer elotte2
    hide debraszex12napjelenet9moz1 onlayer elotte2
    hide debraszex12napjelenet7moz1 onlayer elotte3
    hide debraszex12napjelenet7mozanim onlayer elotte3
    hide debraszex12napjelenet7mozanimv2 onlayer elotte3
    hide debraszex12napjelenet7mozanimv3 onlayer elotte3
    hide debraszex12napjelenet8anim onlayer elotte3
    hide 12napfinalanim onlayer elotte3
    $ invertorinejelenyenmeg = True
    $ invertorialapjelenyenmeg = True
    $ fekete = True

    jump atjaro
$ renpy. pause(hard=True)
label debrafeladatotad12nap:
    hide screen nappali
    if debrafeladatotad12nap == 1:
        f "What should I do?"
        d "Plant a flower onion in the flower plot and clean the kitchen garden."
    if debrafeladatotad12nap == 0:
        $ debrafeladatotad12nap = 1
        show debratvnezalap:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debratvnezpislog:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debraall:
            xzoom -1.0
            zoom 0.65
            xpos 0.32
            ypos 0.17
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        hide nappalitv onlayer elotte6
        show nappalitv
        show haznappalikozeli onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrapoz4 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        d "I am so glad you came, Idiot."
        f "What did I do again?"
        d "Nothing in general. Or did I miss something?"
        show debrapoz4 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Never mind. I learned something interesting from the book."
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "What is it?"
        d "The book says, we need good quality soil, a flowerpot and a flower onion to make a nice flower."
        f "This is the basics, yes."
        show debrapoz2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Did you know this? Well... why are you standing here like that? Why do you play the dump? Go to the garden, fill the flowerpot with the good quality flower soil and plant a flower in it!"
        show fiupoz2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I thought you wanted to practice gardening…"
        d "Sure. I am the main gardener and you are the jerk."
        d "Put compost soil in the pot and clean the kitchen garden!"
        d "You will find a flower onion in the garden. I planted several flowers in the garden last year. They should be still there."
        f "Why do you not do all these?"
        show debrapoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Because it is dirty stuff. I do not want to get dirty and I hate worms."
        d "Also could you answer me? Who is living in someone's house totally free?"
        d "Bring the flower pot in the corridor and put it down if you are done!"
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz4 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Understood. I have to plant a flower and clean the kitchen garden."
        d "Your perception has improved since you are living with us."
        show fiupoz4 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Do we have a spade?"
        d "I do not think so. If I had a spade ,I might bury Grandma a long time ago."
        f "No worries. I will borrow a spade…"
        show debrapoz2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Do as you wish. I have to go now. My series starts at any minute…"
        hide debratvnezalap
        hide debratvnezpislog
        hide debraall
        show debratvnezalap
        show debratvnezpislog
        show haznappalikozeli onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrapoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
    show screen nappali
$ renpy. pause(hard=True)
label mamakenocsefel:
    hide screen nappali
    if mamahatatbekellkeni12nap == 0:
        f "A boksz of some kind of a cream. Someone forgot it here. I do not mind."
    if mamahatatbekellkeni12nap == 1:
        $ mamakenocsenalad = 1
        show mamakenocse:
            alpha 1.0
            linear 1.0 alpha 0.0
    show screen nappali
$ renpy. pause(hard=True)
label debrataviranyitotkeres12nap:
    hide screen nappali
    hide nappalitv onlayer elotte6
    show nappalitv
    hide invertori onlayer elotte6
    hide screen invertori
    show hazalapdebrahatulrolnez onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show screen dontes12napdebrarol
    $ renpy. pause(hard=True)
label beszelekdebraval12nap:
    $ debraseggenelbeszeltem = True
    f "What are you doing?"
    d "I am searching for the fucking controller. I put it here somewhere..."
    f "Did you not have it a minute before?"
    d "Yes, I did, but I lost it. I want to turn it off."
    f "Why do you not push the button down on the television?"
    d "Leave me alone!"
    f "Ok!"
    show screen dontes12napdebrarol
$ renpy. pause(hard=True)
label seggetsimogatok12nap:
    fg "Did she really sleepwalk last night?"
    fg "I should try out something to prove it…"
    $ hogyanutdebra = 0
    show hazalapdebrahatulrolsimogatmoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "What if I do this? How will she react?"
    show hazalapdebrahatulrolsimogatanim onlayer elotte
    show screen s3
    u ""
    u ""
    jump nap12ugrikdebraval
label dorgolok12nap:
    fg "Did she really sleepwalk last night? "
    fg "I should try out something to prove it…"
    $ hogyanutdebra = 1
    show hazalapdebrahatulrolbaszmoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    fg "What if I do this? How will she react?"
    show hazalapdebrahatulrolbaszanim onlayer elotte
    show screen s3
    u ""
    u ""

label nap12ugrikdebraval:
    $ nap12estelegyen += 1
    show hazalapdebrahatulroligedeslesz onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s3
    u ""
    dg2 "Is he kidding me? Did he dare to touch me like that?"
    hide hazalapdebrahatulrolsimogatanim onlayer elotte
    hide hazalapdebrahatulrolnez onlayer elotte
    hide hazalapdebrahatulrolsimogatmoz1 onlayer elotte
    hide hazalapdebrahatulrolbaszmoz1 onlayer elotte
    hide hazalapdebrahatulrolbaszanim onlayer elotte
    if hogyanutdebra == 0:
        show final4reszanim2 onlayer elotte
        queue sound "audio/paff.wav"
        with vpunch
    if hogyanutdebra == 1:
        show final4reszanim1 onlayer elotte
        queue sound "audio/ut.wav"
        with vpunch
    hide fekete onlayer elotte
    show fekete onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    $ debraholcsinal = "konyhatorol"
    hide haznappalidebrabedol
    hide hazalapdebrahatulroligedeslesz onlayer elotte
    hide final4reszanim2 onlayer elotte
    hide final4reszanim1 onlayer elotte
    hide haznappalidebrabedol onlayer elotte
    show ferdkiutveafurdoben5resz:
        xpos -0.2
        ypos -0.1
    show nappalitv onlayer elotte
    hide nappalitv
    hide fekete onlayer elotte
    show fekete onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show invertori onlayer elotte6:
        ypos 0.0
    show screen invertori
    show screen s1
    u ""
    show ferdkiutveafurdoben5resz:
        xpos -0.2
        ypos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    if nap12estelegyen == 5:
        $ ancikaholvan = "sehol"
        $ eszterholvan = "sehol"
        $ mamaholvan = "mamakanapenanapaliban"
        $ tiltjaatereketsetlanahaza = True
        $ tiltjaatereketnyomortanya = True
        $ tiltjaatereketlakotomb = True
        $ tiltjaatereketcukrazda = True
        $ tiltjaatereketszomszedok = True
        $ esteighatralevoido = 0
        $ tiltjaatereketegyetem = True
        $ tiltjaatereketpark = True
        $ tiltjaatereketsritbar = False
        $ boltbanemmehetek = True
        $ tiltjaadebrakertjet = True
    show screen nappali
$ renpy. pause(hard=True)
label mama12napbeszel:
    hide screen nappali
    m "I do not feel like having a chat with Freddy. Grandma needs rest."
    show screen nappali
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
