label dolgozoszoba:
    hide screen fojasojobb
    if debraholcsinal == "dolgozo":
        f "Debra is inside, I cannot disturb her. She is working."
    else:
        f "The working office from Debra. Noone can enter this room."

    show screen fojasojobb
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
