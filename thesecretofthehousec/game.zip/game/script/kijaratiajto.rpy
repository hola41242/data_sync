label kijaratiajto:
    hide screen fojasojobb
    if hanyadiknapvan == 13:
        if tiltjaaterkepet == False:
            jump terkep
    if hanyadiknapvan == 12:
        if tiltjaaterkepet == False:
            jump terkep
    if hanyadiknapvan == 11:
        if tiltjaaterkepet == False:
            jump terkep
    if hanyadiknapvan == 10:
        if tiltjaaterkepet == False:
            jump terkep
    if hanyadiknapvan == 9:
        if tiltjaaterkepet == False:
            jump terkep
    if hanyadiknapvan == 8:
        jump terkep
    if hanyadiknapvan == 7:
        if fifitfelvetem == True:
            f "I can not carry Fifi all around. I should put her down."
            f "I better pick her up and put her down in the backyard."
            show screen fojasojobb
            $ renpy. pause(hard=True)
        if fifiazutban == 1:
            f "I can not leave the house. Fifi is in my way. She needs to pee. I cannot let her out on the street."
            f "I better pick her up and put her down in the backyard."
            show screen fojasojobb
            $ renpy. pause(hard=True)
        jump terkep
    if hanyadiknapvan == 6:
        if porszivofeladet == 3:
            if debraholcsinal == "tavolvan":
                $ regell6resz = False
                jump terkep


    if hanyadiknapvan == 5:
        if lizajelenetvege5resz == False:
            if szemetettkidobni5resz == 2:
                f "I will throw out the trash as well."
                $ szemetettkidobni5resz = 3
            if kakitfeltakaritani == 1:
                if kakitfeltakaritanikersz == True:
                    hide screen invertori
                    hide invertori onlayer elotte6
                    $ kakitfeltakaritani = 2
                    play sound "audio/budos.wav"
                    show kakikidobasa onlayer elotte6:
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    show screen s2
                    u ""
                    f "It smells awful! UUUGHHH!!!"
                    if ennivini == 2:
                        if uditosmagamhozveni == 1:
                            if taskafel == 2:
                                if kakialatpisi == 2:
                                    if regell5resz == True:
                                        if kakitfeltakaritanikersz == True:
                                            if lizajelenetvege5resz == False:
                                                $ teremjelenetek = 0
                                                jump terkep

                    show kakikidobasa onlayer elotte6:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    pause 1.0
                    show screen invertori
                    show invertori onlayer elotte6:
                        yalign 0.0
                    f "I need to pick up my tools for the university."
                    show screen fojasojobb
                    $ renpy. pause(hard=True)
            if felmosotvenni == 1:
                jump terkep
            if ennivini == 2:
                if uditosmagamhozveni == 1:
                    if taskafel == 2:
                        if kakialatpisi == 2:
                            if regell5resz == True:
                                if kakitfeltakaritanikersz == True:
                                    if lizajelenetvege5resz == False:
                                        $ teremjelenetek = 0
                                        jump terkep
            if felvetedaszivacsot == 2:
                jump terkep
        if regell5resz == False:
            jump terkep
    if hanyadiknapvan == 4:
        if debratolkenyeretkerni == 1:
            jump terkep
        if debrakutyatapboltban == 2:
            jump terkep
        if debrakutyatapboltban == 4:
            jump terkep
        if ennivini == 2:
            if uditosmagamhozveni == 1:
                if isztaruhafel == 2:
                    if taskafel == 2:
                        if mamanakteritve == 2:
                            if fifitregeliztetni == 2:
                                $ teremjelenetek = 0
                                jump terkep
        if uditosmagamhozveni == 2:
            if taskafel == 2:
                f "I need to put my bag down first."
                show screen fojasojobb
                $ renpy. pause(hard=True)
        if dagitmegharaptafifi == 1:
            f "I need to help Puffy! He is bleeding!"
            show screen fojasojobb
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 3:
        if regell3resz == True:
            if isztaruhafel == 2:
                if taskafel == 2:
                    if harmadikreszkonyha == 2:
                        $ harmadikreszkonyha = 3
                        d "{size=-5}Fred, if you won't find back to us i will give your room to another person..."
                        f "Do not worry, I will come back!"
                        d "{size=-5}Be careful on the road to the university, You are an idiot!"
                        f "Ok..."
                        f "Debra, did you buy me the new dress?"
                        d "{size=-5}What did you think? Your fairy godmother?"
                        f "Well, thank you! Goodbye!"
                        jump terkep
        if harmadikreszkonyha >= 6:
            if esteighatralevoido > 1:
                jump terkep
    if hanyadiknapvan == 2:
        if fifitfelvetem == True:
            f "I got Fifi in my pocket, I can not take up anything while she is here."
            show screen fojasojobb
            $ renpy. pause(hard=True)
        if csengettek == True:
            if tvhoztak == False:
                hide screen megintcsengetnek
                play sound "audio/ajto2.wav"
                show pack onlayer screens:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                pause 1.0
                fu "Here is your package!"
                f "Thank You! We waited for this!"
                fu "I will go now! Byebye!"
                $ tvhoztak = True
                show pack onlayer screens:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                pause 1.0
                hide pack onlayer screens
                show screen fojasojobb
                $ renpy. pause(hard=True)
    f " I really do not feel like going out now.. outside i can find the trash can. I can throw my trash inside."
    $ szoveguresdobozkidobva = True
    if semeteszsakafoldon == True:
        $ szemetafojason = True
        $ semeteszsakafoldonkidobva = True
    show screen fojasojobb
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
