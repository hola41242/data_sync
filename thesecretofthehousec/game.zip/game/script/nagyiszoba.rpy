label nagyiszoba:
    hide screen fojasoball
    if hanyadiknapvan == 1:
        if szendvicsinvertoriba == True:
            if szendviamamanal == False:
                f "I brought you a sandwich Grandma. I place it before the door here."
                $ szendviamamanal = True
                show haznappalitanyer:
                    xpos 0.32
                    ypos 0.38
                    alpha 0.0
                    linear 2.0 alpha 1.0
                show nappalisedvics:
                    xpos 0.32
                    ypos 0.38
                    alpha 0.0
                    linear 2.0 alpha 1.0
                show screen fojasoball
                $ renpy. pause(hard=True)
    if hanyadiknapvan == 1:
        f "Grandma lives here, I should not disturb her. She is resting."
    if hanyadiknapvan == 2:
        f "Grandma's room is locked"
    if hanyadiknapvan == 3:
        if beszeljaszomszedokkal < 2:
            f "Grandma rests now. I do not want to disturb her."
        else:
            f "Grandma's room is locked"
    if hanyadiknapvan == 4:
        if jobboldaliszomszed == 1:
            f "Grandma rests now. I do not want to disturb her."
        else:
            f "Grandma's room is locked"
    if hanyadiknapvan == 5:
        f "Grandma's room is locked"
    if hanyadiknapvan == 6:
        if mamaholvan == "szobajaban":
            f "Grandma must have a terrible headache. I can not disturb her."
        else:
            f "Grandma's room is locked"
    if hanyadiknapvan == 7:
        f "Grandma's room is locked"
    if mamaholvan == "szobajaban":
        f "Grandma must have a terrible headache. I can not disturb her."
    else:
        f "Grandma's room is locked"
    show screen fojasoball

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
