label fojasoball:
    if hanyadiknapvan == 7:
        if mobil == True:
            if szerezegymobilt == 3:
                if szenyesmizeria == 0:
                    $ debraholcsinal = "fojasoneszik"
                    $ szenyesmizeria = 1
    $ holvagyok = "fojasoball"
    jump tiltasok
label fojasoballszov:
    show fajasoball
    if esteighatralevoido == 0:
        show fajasoball2este
    show fajasoballvirag onlayer hatso
    show nyilafojason:
        xalign 0.55
        yalign 0.98
    if fifipisi1 == False:
        if fifipisilt >= 1:
            show hugy:
                zoom 0.55
                xpos 0.55
                ypos 0.79
    if hanyadiknapvan == 3:
        if beszeljaszomszedokkal == 2:
            if tejetvetem == True:
                $ debraholcsinal == "konyha"
        if beszeljaszomszedokkal == 2:
            if tejetvetem == True:
                if nyalokavetem == True:
                    if magazinvetem == True:
                        $ esteighatralevoido = 0
    if hanyadiknapvan == 4:
        if debraholcsinal == "fojasoballpisi":
            show hugy:
                zoom 0.55
                xpos 0.55
                ypos 0.79
            show debrafelmos:
                zoom 0.4
                xpos 0.35
                ypos 0.55
            jump debrapanasz
        if debraholcsinal == "ablakotpucolballfojason":
            show debraablakotmosanim:
                zoom 0.95
                xpos 0.03
                ypos 0.05
    if hanyadiknapvan == 6:
        if lizakertjekesz < 2:
            show ruhaszalito:
                zoom 0.7
                xpos 0.2
                ypos 0.2
            show ruhaszalitoruha:
                zoom 0.7
                xpos 0.2
                ypos 0.2
        if debraholcsinal == "ablakotpucolballfojason":
            show debraablakotmosanim:
                zoom 0.95
                xpos 0.03
                ypos 0.05
        if mamaholvan == "fojasoball":
            show mamahattalall:
                xpos -0.15
                ypos 0.08
    if hanyadiknapvan == 7:
        if szenyesmizeria == 1:
            show ruhaszalito:
                zoom 0.7
                xpos 0.2
                ypos 0.2
            show ruhaszalitoruha:
                zoom 0.7
                xpos 0.2
                ypos 0.2
        if debraholcsinal == "fojasoneszik":
            show debraeszik1:
                zoom 0.7
                xpos 0.4
                ypos 0.2
            jump szenyesmizeriakezdete
    if hanyadiknapvan == 9:
        if ruhakosarnalad == True:
            if ruhakosarnaladtele == True:
                $ ruhaszalitonalad = 2
                $ ruhakosarnalad = False
        if ruhaszalitonalad == 0:
            show ruhaszalito:
                zoom 0.7
                xpos 0.2
                ypos 0.2
        if ruhaszalitonalad == 2:
            show ruhaszalito:
                zoom 0.7
                xpos 0.2
                ypos 0.2
            show ruhaszalitoruha:
                zoom 0.7
                xpos 0.2
                ypos 0.2
    if hanyadiknapvan == 10:
        if debraholcsinal == "ablakotpucolballfojason":
            show debraablakotmosanim:
                zoom 0.95
                xpos 0.03
                ypos 0.05





    jump engedejek
$ renpy. pause(hard=True)
label locsolfojball:
    if locsolokannaviz >= 1:
        play sound "audio/viz13.wav"
        $ locsolokannaviz -= 1
        $ viragokmegontozve += 1
        $ fojasoballvirag = True
        if furdovirag == True:
            if fojasoballvirag == True:
                if fojasojobbvirag == True:
                    if napalivirag == True:
                        if atjarovirag == True:
                            if atjarovirag2 == True:
                                if furdovirag == True:
                                    if atjarovirag3 == True:
                                        $ viragokmegontozese = True
    else:
        f "I need to go back to the bathroom to fill the can with water."
$ renpy. pause(hard=True)
label debrafojballvissza:
    $ debraballfoban = False
    hide debrasopor
    show debrasopor:
        zoom 0.4
        xalign 0.56
        yalign 0.47
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (debravalamitcsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label fififojasoballbanmozog:
    $ fifiballfoban = False
    hide fifipisil
    show fifipisil:
        zoom 0.6
        xpos 0.5
        ypos 0.6
        alpha 0.0
        linear 2.0 alpha 1.0
        pause (fificsinalido)
        alpha 1.0
        linear 2.0 alpha 0.0
    show hugy:
        alpha 0.0
        pause (fificsinalido)
        zoom 0.55
        xpos 0.55
        ypos 0.79
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label debrapanasz:
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    $ fekete = True
    if debrapanasz == 0:
        $ debrapanasz = 1
        d "That fucking dog had been peeing all around!"
    jump engedejek
$ renpy. pause(hard=True)
label debrapisittorol:
    hide screen invertori
    hide invertori onlayer elotte6
    hide screen fojasoball
    show debrapisitmos onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    u ""
    d "Look somewhere else!"
    show debrapisitmos onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen fojasoball
$ renpy. pause(hard=True)
label debraablakotpucolballoldalt:
    hide screen fojasoball
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    if hanyadiknapvan == 10:
        if ladatmegtalalhatod >= 1:
            show debrapironkodik6resz onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            d "Go away!"
            show debrapironkodik6resz onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
        if ladatmegtalalhatod == 0:
            show debrapironkodik6resz onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            f "Can you lend me some money?"
            d "I have not received my payment yet."
            f "I have to sample 2000 Forints. I will look for a job."
            d "Sure… tell me! Did I start to sleepwalk again?"
            f "Yeah. You came to my room last night… Or did I only dream it?"
            show debrapironkodik6reszv2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            d "Forget it! Scram! I ha lot to do now! Gosh!"
            hide debrapironkodik6resz onlayer elotte
            show debrapironkodik6reszv2 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0




    if hanyadiknapvan == 6:
        show fajasoballvirag
        hide fajasoballvirag onlayer hatso
        show debrapironkodik6resz:
            alpha 0.0
            linear 1.0 alpha 1.0
        d "IFred! I would like to ask you something. Answer me seriously!"
        f "Ok! What is your question?"
        d "Were you sleeping on the couch?"
        f "Yes, I was so tired. Did I do something wrong?"
        d "Not really. So you do not remember what happened?"
        f "I have no clue! Did I fart again?"
        d "Wel... no..."
        dg "It seems he can not remember anything. He fell asleep and I fell asleep and…"
        play music "audio/baszosalap.ogg" fadeout 1
        show vegsojelenet5resz6:
            alpha 0.0
            linear 3.0 alpha 1.0
        show screen s3
        u ""
        dg "I want to feel the taste in my mouth…"
        show vegsojelenet6resz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.5
        dg "It was so long ago… Just a little bite…"
        u ""
        show vegsojelenet6resz2:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.5
        dg "Oh it tastes so good! How I missed this!"
        u ""
        show vegsojelenet6resz3alap:
            alpha 0.0
            linear 1.0 alpha 1.0
        show vegsojelenet6resz3mozanim:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        dg "It is pulsing in my mouth... What a nice feeling…"
        u ""
        dg "It is cumming soon…"
        u ""
        show vegsojelenet6resz4anim:
            parallel:
                alpha 0.0
                linear 1.0 alpha 1.0
            parallel:
                ypos 0.0
                linear 2.5 ypos -1.0
        show screen s2e5
        u ""
        dg "I can feel the cum in my mouth… Gosh!"
        show vegsojelenet6resz4gecianim:
            ypos -1.0
        show screen s1e5
        u ""
        show vegsojelenet6resz5:
            alpha 0.0
            linear 1.0 alpha 1.0
        show vegsojelenet6resz5szemanim:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.5
        dg "What the Fuck? What am I doing?"
        hide vegsojelenet6resz5szemanim
        show vegsojelenet6resz5szemanim2
        show screen s1
        u ""
        queue sound "audio/horkol.ogg"
        queue sound "audio/horkol.ogg"
        queue sound "audio/horkol.ogg"
        show vegsojelenet6resz6:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1e5
        u ""
        dg "This… this is… Fred!!!"
        show vegsojelenet6resz6:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1e5
        u ""
        stop sound
        dg "What should I do now?"
        hide vegsojelenet6resz5szemanim2
        show vegsojelenet6resz5szemanim5
        pause 1.0
        dg "He is asleep. I can not spit it out. He will wake up for sure…"
        hide vegsojelenet6resz5szemanim5
        show vegsojelenet6resz5szemanim2
        show screen s1
        u ""
        hide vegsojelenet6resz5szemanim2
        show vegsojelenet6resz5szemanim3
        show screen s1
        u ""
        dg "I need something... a handkerchief… or something?"
        dg "I can not see anything nearby… not even a damn towel…"
        hide vegsojelenet6resz5szemanim3
        show vegsojelenet6resz5szemanim6
        show screen s1
        u ""
        dg "I can not put his penis back in this condition…"
        hide vegsojelenet6resz5szemanim6
        show vegsojelenet6resz5szemanim5
        show screen s1
        u ""
        dg "It is wet from the cum and he will wake up… "
        show vegsojelenet6resz7v1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show vegsojelenet6resz7geci1:
            alpha 0.0
            linear 1.0 alpha 1.0
        dg "This is the only way... Ok Debra… you can do this... Just…"
        hide vegsojelenet6resz7v1
        hide vegsojelenet6resz7geci1
        show vegsojelenet6resz7anim
        show vegsojelenet6resz7gecianim
        show screen s2e5
        u ""
        show vegsojelenet6resz8:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 1.0
        dg "Oh Gosh! What did I do? I sucked him off…"
        hide vegsojelenet5resz6
        hide vegsojelenet6resz1
        hide vegsojelenet6resz2
        hide vegsojelenet6resz3alap
        hide vegsojelenet6resz3mozanim
        hide vegsojelenet6resz4anim
        hide vegsojelenet6resz4gecianim
        hide vegsojelenet6resz5
        hide vegsojelenet6resz5szemanim
        hide vegsojelenet6resz5szemanim2
        hide vegsojelenet6resz6
        hide vegsojelenet6resz5szemanim3
        hide vegsojelenet6resz5szemanim4
        hide vegsojelenet6resz7anim
        hide vegsojelenet6resz5szemanim5
        hide vegsojelenet6resz5szemanim6
        hide vegsojelenet6resz7gecianim
        dg "He came in my mouth and I swallowed it all! How could this happen? It was an…accident... How couId I look in his eyes?"
        dg "How could I look in my own eyes after this? He is still sleeping. I should go, but fast!Just let us forget this…"
        show debrapironkodik6reszv2
        hide vegsojelenet6resz8
        show vegsojelenet6resz8:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 2.0
        play music "audio/banyabolt.ogg" fadeout 1
        dg "Oh Gosh! Oh Gosh! What did I do?"
        f "Debra! Hello? Are you listening to me?"
        show debrapironkodik6reszv2:
            alpha 1.0
            linear 1.0 alpha 0.0
        d "What? What is it? I just... I was thinking..."
        f "Is this all you wanted to ask? Can I go now?"
        d "Sure.yeah... go now... I need to rest, too…"
        f "Good night!"
        d "Good… night… "
        $ atjarosecialisengedej = 3
        $ invertorinejelenyenmeg = True
        jump atjaro
        $ renpy. pause(hard=True)
    if hanyadiknapvan == 4:
        hide debraablakotmos onlayer elotte6
        show debraablakotmos onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
        if debratolelsosegej >= 2:
            d "You are watching only the panorama, right? Scram!"
        if debratolelsosegej == 1:
            $ debratolelsosegej = 2
            f "Debra! I need bandage and wound disinfectant."
            d "Do I look like a pharmacist?"
            f "No... I hope you can help..."
            d "Sure... Why do you need it?"
            f "Fifi had bitten Puffy..."
            d "I am happy! You have luck. If Grandma would bite him we would get in trouble. She has no vaccination against rabies!"
            d "Wait here! I will bring it for you!"
            hide debraablakotmosanim
            show fiupoz2 onlayer hatso
            show debraablakotmos onlayer elotte6:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 2.0
            show debrapoz2:
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 2.0
            d "Here you are, now leave me alone idiot!"
            show fiupoz2 onlayer hatso:
                alpha 1.0
                linear 1.0 alpha 0.0
            show debrapoz2:
                alpha 1.0
                linear 1.0 alpha 0.0
            show debraablakotmosanim:
                zoom 0.95
                xpos 0.03
                ypos 0.05
                alpha 0.0
                linear 1.0 alpha 1.0
    show screen fojasoball
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
$ renpy. pause(hard=True)
label anyakereszt2fel:
    hide screen invertori
    hide screen fojasoball
    show screen invertori2
    show screen fredkutatszennyes
    show felsurolfiu2:
        zoom 0.5
        xzoom -1.0
        xpos 0.55
        ypos 0.62
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamahattalallszexi6resz:
        ypos 0.1
        alpha 0.0
        pause 5.0
        linear 1.0 alpha 1.0
    show mamahattalallszexifelsoruha6resz:
        ypos 0.1
        alpha 0.0
        pause 5.0
        linear 1.0 alpha 1.0
    pause 5.0
    $ mamalatszik = True
    pause 2.0
    m "Where am I? What do I wear?"
$ renpy. pause(hard=True)
label anyakereszt2abahagy:
    show screen invertori
    show screen fojasoball
    hide screen invertori2
    hide screen fredkutatszennyes
    show felsurolfiu2:
        zoom 0.5
        xzoom -1.0
        xpos 0.55
        ypos 0.62
        alpha 1.0
        linear 1.0 alpha 0.0
    if mamalatszik == True:
        show mamahattalallszexi6resz:
            ypos 0.1
            alpha 1.0
            linear 1.0 alpha 0.0
        show mamahattalallszexifelsoruha6resz:
            ypos 0.1
            alpha 1.0
            linear 1.0 alpha 0.0
    $ mamalatszik = False
$ renpy. pause(hard=True)
label mamafojasoball:
    hide screen fojasoball
    show screen invertori2
    hide screen invertori
    hide fajasoballvirag onlayer hatso
    show fajasoballvirag
    if hanyadiknapvan == 6:
        hide fajasoballkozeli
        hide kavejelalapfredk11
        hide kavejelalapfredk1kep2
        hide kavejelalapfredk1kep1
        hide mamapoz1
        show fajasoballkozeli:
            alpha 0.0
            linear 1.0 alpha 1.0
        show mamapoz1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show kavejelalapfredk1kep1:
            xpos -0.3
            ypos 0.15
            alpha 0.0
            linear 1.0 alpha 0.5
        show kavejelalapfredk11:
            xpos -0.3
            ypos 0.15
            alpha 0.0
            linear 1.0 alpha 1.0
        show kavejelalapfredk1kep2:
            xpos -0.3
            ypos 0.15
            alpha 0.0
            linear 1.0 alpha 0.5
        pause 1.0
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        queue sound "audio/reszeg.ogg"
        show kavejelalapfredk1kep1:
            xpos -0.3
            ypos 0.15
            alpha 0.5
            linear 3.0 xpos -0.25
            linear 3.0 xpos -0.3
            repeat
        show kavejelalapfredk11:
            xpos -0.3
            ypos 0.15
            alpha 0.0
            linear 1.0 alpha 1.0
        show kavejelalapfredk1kep2:
            xpos -0.3
            ypos 0.15
            alpha 0.5
            linear 3.0 xpos -0.35
            linear 3.0 xpos -0.3
            repeat
        pause 2.0
        if mamavalbeszed >= 4:
            $ mamavalbeszed = 1
        if mamavalbeszed == 3:
            $ mamavalbeszed = 4
            m "I am the white rabbit and I have to go now…"
        if mamavalbeszed == 2:
            $ mamavalbeszed = 3
            f "Are you feeling better Grandma?"
            m "Who knows?... Everything is relative… everything is rotating around Grandma... The world rotates around Grandma… she is the center of the universe… "
        if mamavalbeszed == 1:
            $ mamavalbeszed = 2
            f "What are you looking at? Is there something interesting?"
            m "Who the fuck are you?"
            f "I am Fred…"
            m "Did you come from Kalocsa? Did you buy me the porcelain dish?"
            f "Well… I should go now... I have a lot to do…"
        show fajasoballkozeli:
            alpha 1.0
            linear 1.0 alpha 0.0
        show kavejelalapfredk1kep1:
            xpos -0.25
            ypos 0.15
            alpha 0.5
            linear 1.0 alpha 0.0
        show kavejelalapfredk11:
            xpos -0.3
            ypos 0.15
            alpha 1.0
            linear 1.0 alpha 0.0
        show kavejelalapfredk1kep2:
            xpos -0.35
            ypos 0.15
            alpha 0.5
            linear 1.0 alpha 0.0
        show mamapoz1:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
    stop sound
    hide fajasoballvirag
    show fajasoballvirag onlayer hatso
    show screen fojasoball
    show screen invertori
    hide screen invertori2
$ renpy. pause(hard=True)
label szenyesmizeriakezdete:
    $ fekete = True
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen s1
    u ""
    hide fajasoballvirag onlayer hatso
    show fajasoballvirag
    show fajasoballkozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debraeszik1:
        zoom 0.7
        xpos 0.4
        ypos 0.2
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz7:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    d "Hy Fred! Do you have any more plans for the afternoon?"
    f "No, I have not. I have nothing to do and I think I will just stay home…"
    show debrapoz7v2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz7:
        alpha 1.0
        linear 1.0 alpha 0.0
    d "This is not your home…"
    show fiupoz1:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz5:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Agh! Sorry... Yeah... This is your home..."
    show fiupoz5:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Good boy!"
    f "Why do you ask me?"
    d "I have a lot of work now and I do not have time to wash out the laundry. Can you help me?"
    show fiupoz2:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Sure..."
    show debrapoz7:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz7v2:
        alpha 1.0
        linear 1.0 alpha 0.0
    d "Fine... wash out the laundry and do not smell any dirty underwear you pervert!"
    f "Why would I?"
    d "Because you are a disgusting pervert creature from a nasty village…"
    show fiupoz1:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    hide fiupoz4
    show fiupoz4:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Thank You for the nice nickname… I will try my best to behave myself..."
    show debrapoz7v2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz7:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Alright. I should go now. I have a lot to do. Call me if you need any help!"
    f "Why?"
    show debrapoz7:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz7v2:
        alpha 1.0
        linear 1.0 alpha 0.0
    d "Who knows? You are not clever at all!"
    show fajasoballkozeli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz7:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ debraholcsinal = "ablakotpucoljobbfojason"
    show screen s1
    u ""
    hide fajasoballvirag
    show fajasoballvirag onlayer hatso
    jump engedejek
$ renpy. pause(hard=True)
label balfojasoszennyesfel:
    $ ruhakosarnalad = True
    $ ruhakosarnaladtelemijenruhaval = "koszos"
    $ szenyesmizeria = 2
    $ szenyeskimosva = False
    $ szenyesnalad = True
    $ mijenszenyesvannalad = "debrajeke"
    show ruhaszalito:
        zoom 0.7
        xpos 0.2
        ypos 0.2
        alpha 1.0
        linear 1.0 alpha 0.0
    show ruhaszalitoruha:
        zoom 0.7
        xpos 0.2
        ypos 0.2
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label balfojasoszennyesfel9resz:
    $ ruhakosarnalad = True
    $ ruhakosarnaladtele = False
    $ ruhaszalitonalad = 1
    show ruhaszalito:
        zoom 0.7
        xpos 0.2
        ypos 0.2
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
