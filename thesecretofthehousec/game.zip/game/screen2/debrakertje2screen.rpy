screen debrakertje2:
    imagebutton:
        idle "ajtok/hosszuajto2z.png"
        xalign 1.0
        yalign 1.0
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje")
    imagebutton:
        idle "ajtok/hosszuajto2z.png"
        xalign 1.0
        yalign 0.9
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.5
        yalign 0.55
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje2nincsutmeg")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 1.0
        yalign 0.65
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje2nincsutmeg")
    imagebutton:
        idle "ajtok/debpor2z.png"
        xalign 0.2
        yalign 0.57
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje2ruhaszarito")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.03
        yalign 0.91
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje2medence")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.21
        yalign 0.91
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje2medence")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.75
        yalign 0.65
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje2vetemenyes")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 1.0
        yalign 0.8
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertje2kerticsap")
    if hanyadiknapvan == 7:
        if mamakert2benholvan == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.6
                ypos 0.47
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kert2benmamavalbeszed")
        if mamakert2benholvan == 2:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.38
                ypos 0.54
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kert2benmamavalbeszed")
        if mamakert2benholvan == 3:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.02
                ypos 0.41
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kert2benmamavalbeszed")
        if debrakertje2ruhalent == 1:
            imagebutton:
                idle "ajtok/hosszuajto2z.png"
                xpos 0.18
                ypos 0.63
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kert2benruhatfelszedni")
        if debrakertje2erme == 1:
            imagebutton:
                idle "ajtok/minuszz.png"
                xpos 0.44
                ypos 0.87
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("ermetfelveszed")
    if hanyadiknapvan == 8:
        if lizanakmegmutatadareceptet == True:
            if tulipannalad == 0:
                imagebutton:
                    idle "invertori/semmi.png"
                    xpos 0.48
                    ypos 0.68
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("tulipanfel")
        if pulilevanegve == False:
            if debraholcsinal == "debrakertje2":
                if debrautasit8reszkertben == False:
                    imagebutton:
                        idle "ajtok/ruhazz.png"
                        xpos 0.75
                        ypos 0.45
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("debrautasit8reszkertben")
        if debrautasit8reszkertben == True:
            if debrakertje2bokorgaz == 1:
                imagebutton:
                    idle "ajtok/hosszuajtoz.png"
                    xpos 0.5
                    ypos 0.48
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2bokorgazlevag")
            if debrakertje2sokdudvafelszed1 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.0
                    ypos 0.86
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed1fel")
            if debrakertje2sokdudvafelszed2 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.34
                    ypos 0.85
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed2fel")
            if debrakertje2sokdudvafelszed3 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.4
                    ypos 0.6
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed3fel")
            if debrakertje2sokdudvafelszed4 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.47
                    ypos 0.72
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed4fel")
            if debrakertje2sokdudvafelszed5 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.51
                    ypos 0.59
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed5fel")
            if debrakertje2sokdudvafelszed6 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.6
                    ypos 0.7
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed6fel")
            if debrakertje2sokdudvafelszed7 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.52
                    ypos 0.86
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed7fel")
            if debrakertje2sokdudvafelszed8 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.67
                    ypos 0.81
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed8fel")
            if debrakertje2sokdudvafelszed9 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.71
                    ypos 0.7
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed9fel")
            if debrakertje2sokdudvafelszed11 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.85
                    ypos 0.65
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed11fel")
            if debrakertje2sokdudvafelszed10 == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.78
                    ypos 0.66
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2sokdudvafelszed10fel")
            if szemeteszsaknalad == True:
                if szemeteszak < 4:
                    if debrakertje2sokdudvafelszed12 == 1:
                        imagebutton:
                            idle "ajtok/ruhaz.png"
                            xpos 0.79
                            ypos 0.84
                            mouse "aktion"
                            activate_sound "audio/click.wav"
                            action Jump ("debrakertje2sokdudvafelszed12fel")
            if debrakertje2bokorgaz == 1:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.0
                    ypos 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2bokorgazlevag")
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.35
                    ypos 0.52
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("debrakertje2bokorgazlevag")

        if debraholcsinal == "mamadebrabeszelkert2":
            if mamaholvan == "mamadebrabeszelkert2":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.4
                    ypos 0.48
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mamadebrabeszel8resz")
        if debraholcsinal == "furdo":
            if debrakertje2foldturas == 1:
                imagebutton:
                    idle "ajtok/hosszuajtoz.png"
                    xpos 0.4
                    ypos 0.55
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("foldeltuntetese")
                imagebutton:
                    idle "ajtok/hosszuajtoz.png"
                    xpos 0.4
                    ypos 0.7
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("foldeltuntetese")
                imagebutton:
                    idle "ajtok/hosszuajtoz.png"
                    xpos 0.4
                    ypos 0.85
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("foldeltuntetese")
    if hanyadiknapvan == 9:
        if debraholcsinal == "mamadebrabeszelkert2":
            if mamaholvan == "mamadebrabeszelkert2":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.4
                    ypos 0.48
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("mamadebrabeszel9resz")
        if debraholcsinal == "debrafelengediamedencet":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.27
                ypos 0.52
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debravalbeszed9reszfelenged")
        if mamaholvan == "napozikkert2ben":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.44
                ypos 0.58
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mamavalbeszed9reszbeken")
    if hanyadiknapvan >= 10:
        if mamaholvan == "napozikkert2ben":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.44
                ypos 0.58
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mamavalbeszed9reszbeken")
    if hanyadiknapvan >= 10:
        if leengedocsoafoldon == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.51
                ypos 0.78
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("leengedocsoszoveg")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.57
                ypos 0.78
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("leengedocsoszoveg")
    if hanyadiknapvan == 11:
        if letranalad == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.67
                ypos 0.45
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("letratfelvenni")
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.66
                ypos 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("letratfelvenni")
    if hanyadiknapvan == 12:
        if mamaholvan == "kertbenkenocsrevar":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.44
                ypos 0.46
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mamacibzarfel")

screen mamakermje9resz:
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.57
        ypos 0.69
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Hide ('mamakermje9resz'), Jump ("mama9reszbeken")

screen ruhateregetes:
    if hanyadiknapvan == 7:
        timer 1.0 repeat True action If(ruhaszaritoido <= 0,
        true=[SetVariable('kiteritesiproba', kiteritesiproba + 1),
        Hide('ruhateregetes'),
        Jump('ruhafentaraszriton')],
        false=[SetVariable('ruhaszaritoido', ruhaszaritoido - 1),
        SetVariable('ruhaszaritoelteltido', ruhaszaritoelteltido + 1)])
        if kiteritesiproba == 1:
            bar:
                left_bar "#f00"
                if ruhaszaritoido <= 5:
                    left_bar "#0ff"
                if ruhaszaritoido <= 0:
                    left_bar "#0f0"
                value StaticValue(ruhaszaritoelteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
        else:
            bar:
                left_bar "#f00"
                if ruhaszaritoido <= 10:
                    left_bar "#0ff"
                if ruhaszaritoido <= 0:
                    left_bar "#0f0"
                value StaticValue(ruhaszaritoelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if hanyadiknapvan == 9:
        timer 1.0 repeat True action If(ruhaszaritoido <= 0,
        true=[Hide('ruhateregetes')],
        false=[SetVariable('ruhaszaritoido', ruhaszaritoido - 1),
        SetVariable('ruhaszaritoelteltido', ruhaszaritoelteltido + 1)])
        bar:
            left_bar "#f00"
            if ruhaszaritoido <= 5:
                left_bar "#0ff"
            if ruhaszaritoido <= 0:
                left_bar "#0f0"
            value StaticValue(ruhaszaritoelteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen bokornyiras8resz:
    timer 1.0 repeat True action If(bokornyiras8reszido <= 0,
    true=[Hide('bokornyiras8resz')],
    false=[SetVariable('bokornyiras8reszido', bokornyiras8reszido - 1),
    SetVariable('bokornyiras8reszelteltido', bokornyiras8reszelteltido + 1)])
    bar:
        left_bar "#f00"
        if bokornyiras8reszido <= 10:
            left_bar "#0ff"
        if bokornyiras8reszido <= 0:
            left_bar "#0f0"
        value StaticValue(bokornyiras8reszelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen debrakert2pozbanvan:
    if debrakert2pozbanvan == 1:
        timer 24.0 repeat True action SetVariable('debrakert2pozbanvan', 2)
    if debrakert2pozbanvan == 2:
        timer 24.0 repeat True action SetVariable('debrakert2pozbanvan', 1)
    if hanyadiknapvan == 9:
        if csinalszvalamit == "semit":
            if debrakert2pozbanvan == 1:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.51
                    ypos 0.72
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kert2bendebravalbeszed")
            if debrakert2pozbanvan == 2:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.65
                    ypos 0.53
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kert2bendebravalbeszed")
screen mamakert2pozbanvan:
    if mamakert2pozbanvan == 1:
        timer 6.0 repeat True action SetVariable('mamakert2pozbanvan', 2)
    if mamakert2pozbanvan == 2:
        timer 6.0 repeat True action SetVariable('mamakert2pozbanvan', 3)
    if mamakert2pozbanvan == 3:
        timer 6.0 repeat True action SetVariable('mamakert2pozbanvan', 1)
    if hanyadiknapvan == 9:
        if csinalszvalamit == "semit":
            if mamakert2pozbanvan == 1:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.6
                    ypos 0.47
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kert2benmamavalbeszed")
            if mamakert2pozbanvan == 2:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.38
                    ypos 0.54
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kert2benmamavalbeszed")
            if mamakert2pozbanvan == 3:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.02
                    ypos 0.41
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kert2benmamavalbeszed")
screen foldeltuntetese:
    timer 1.0 repeat True action If(sokfol8reszido <= 0,
    true=[Hide('foldeltuntetese')],
    false=[SetVariable('sokfol8reszido', sokfol8reszido - 1),
    SetVariable('sokfol8reszelteltido', sokfol8reszelteltido + 1)])
    bar:
        left_bar "#f00"
        if sokfol8reszido <= 10:
            left_bar "#0ff"
        if sokfol8reszido <= 0:
            left_bar "#0f0"
        value StaticValue(sokfol8reszelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen medenceleengedodik:
    timer 1.0 repeat True action If(medenceleengedido <= 0,
    true=[Hide('medenceleengedodik')],
    false=[SetVariable('medenceleengedido', medenceleengedido - 1),
    SetVariable('medenceleengedelteltido', medenceleengedelteltido + 1)])
    bar:
        left_bar "#f00"
        if medenceleengedido <= 10:
            left_bar "#0ff"
        if medenceleengedido <= 0:
            left_bar "#0f0"
        value StaticValue(medenceleengedelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen kertfelas:
    timer 1.0 repeat True action If(konyhakertido <= 0,
    true=[Hide('kertfelas')],
    false=[SetVariable('konyhakertido', konyhakertido - 1),
    SetVariable('konyhakertelteltido', konyhakertelteltido + 1)])
    bar:
        left_bar "#f00"
        if konyhakertido <= 5:
            left_bar "#0ff"
        if konyhakertido <= 0:
            left_bar "#0f0"
        value StaticValue(konyhakertelteltido, 10) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
