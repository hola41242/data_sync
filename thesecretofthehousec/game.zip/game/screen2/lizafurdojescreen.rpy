screen lizafurdoje:
    imagebutton:
        idle "ajtok/furdoajtoz1z.png"
        xalign 0.00
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("lizanapalia")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.67
        ypos 0.38
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("lizatorolkozofurdo")
    if hanyadiknapvan == 7:
        if kiskendofurdoben == True:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.67
                ypos 0.38
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizatorlokendofurdofel")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
