screen lizakertje:
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.3
        yalign 0.3
        mouse "aktion"
        activate_sound "audio/click.wav"
        if hanyadiknapvan == 6:
            if lizakertjekesz >= 1:
                action Jump ("lizaketbenbeszedvege3")
        action Jump ("lizaatjaroja")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.55
        yalign 0.45
        if holvanliza == "tornazik":
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizaketbenbeszed")
    if pulinapozoagya == 3:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.55
            yalign 0.45
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lizaszex7nap")
    if hanyadiknapvan == 6:
        if lizakertjeszemet1 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.33
                yalign 0.95
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjeszemet1")
        if lizakertjeszemet2 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.43
                yalign 0.85
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjeszemet2")
        if lizakertjeszemet3 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.405
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjeszemet3")
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.51
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjeszemet3")
        if lizakertjeszemet4 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.25
                yalign 0.53
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjeszemet4")
        if lizakertjedudva1 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.66
                yalign 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjedudva1")
        if lizakertjedudva2 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.85
                yalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjedudva2")
        if lizakertjedudva3 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.8
                yalign 0.83
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjedudva3")
        if lizakertjedudva4 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.96
                yalign 0.83
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjedudva4")
        if lizakertjelevelek == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.05
                yalign 0.8
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjelevelekossze")
        if lizakertjelevelek == 2:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.03
                yalign 0.68
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjelevelekfel")
        if lizakertjemadarhazaahejen == False:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.135
                yalign 0.32
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("lizakertjemadarhaz")
    if hanyadiknapvan == 7:
        if pulinapozoagya >= 1:
            imagebutton:
                idle "ajtok/debporz.png"
                xalign 0.85
                yalign 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("pulinapozoagya")
    if hanyadiknapvan == 8:
        imagebutton:
            idle "ajtok/debporz.png"
            xalign 0.85
            yalign 0.75
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("pulinapozoagya")
    if hanyadiknapvan >= 9:
        if mrpuliholvan == "napozoagy":
            imagebutton:
                idle "ajtok/debporz.png"
                xalign 0.85
                yalign 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("pulinapozoagya")
screen lizabeszed:
    if hanyadiknapvan == 6:
        if lizakertjekesz == 0:
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.9
                xalign 0.5
                textbutton "Back":
                    mouse "aktion"
                    action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege")
                    text_style "fegeteszov"
        if lizakertjekesz == 1:
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.9
                xalign 0.5
                textbutton "Back":
                    mouse "aktion"
                    action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege2")
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.9
                ypos 0.1
                xalign 0.5
                textbutton "Touch her":
                    mouse "aktion"
                    action Hide ('lizabeszed'), Jump ("lizaketbenfogdos")
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.9
                ypos 0.25
                xalign 0.5
                textbutton "Take out penis":
                    mouse "aktion"
                    action Hide ('lizabeszed'), Jump ("lizaketbenszopat")
                    text_style "fegeteszov"
    if hanyadiknapvan == 7:
        if pulinapozoagya < 2:
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.9
                xalign 0.5
                textbutton "Back":
                    mouse "aktion"
                    action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege")
                    text_style "fegeteszov"
        if pulinapozoagya == 2:
            frame:
                background ('fram')
                xpos 0.9
                ypos 0.1
                xalign 0.5
                textbutton "Touch her":
                    mouse "aktion"
                    action Hide ('lizabeszed'), Jump ("lizaketbenfogdos")
                    text_style "fegeteszov"
            frame:
                background ('fram')
                xpos 0.9
                ypos 0.25
                xalign 0.5
                textbutton "Take out penis":
                    mouse "aktion"
                    action Hide ('lizabeszed'), Jump ("lizaketbenszopat")
                    text_style "fegeteszov"
        if pulinapozoagya >= 3:
            if pulinapozoagya < 4:
                frame:
                    background ('fram')
                    xpos 0.075
                    ypos 0.9
                    xalign 0.5
                    textbutton "Back":
                        mouse "aktion"
                        action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege4")
                        text_style "fegeteszov"
        if pulinapozoagya == 4:
            frame:
                background ('fram')
                xpos 0.075
                ypos 0.9
                xalign 0.5
                textbutton "Back":
                    mouse "aktion"
                    action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege")
                    text_style "fegeteszov"
    if hanyadiknapvan == 8:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege")
                text_style "fegeteszov"
    if hanyadiknapvan == 9:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege")
                text_style "fegeteszov"
    if hanyadiknapvan == 10:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege")
                text_style "fegeteszov"
    if hanyadiknapvan == 11:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege")
                text_style "fegeteszov"
    if hanyadiknapvan == 12:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege")
                text_style "fegeteszov"
screen lizabeszed2:
    frame:
        background ('fram')
        xpos 0.9
        ypos 0.1
        xalign 0.5
        textbutton "Stop":
            mouse "aktion"
            action Hide ('lizabeszed'), Jump ("lizaketbenbeszedvege2")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.9
        ypos 0.25
        xalign 0.5
        textbutton "Such her nipple":
            mouse "aktion"
            action Hide ('lizabeszed'), Jump ("lizaketbenfogdos2")
            text_style "fegeteszov"
screen szemetosszesed1:
    timer 1.0 repeat True action If(lizakertjeszemet1ido <= 0,
    true=[SetVariable('lizaszemeteszakja', lizaszemeteszakja + 2),
    SetVariable('lizakertjeszemet1', lizakertjeszemet1 - 1),
    Hide('szemetosszesed1'),Hide('invertori2'),
    Show('invertori'),
    Show('lizakertje'),
    Jump ('lizakertjeszemet1fel')],
    false=[SetVariable('lizakertjeszemet1ido', lizakertjeszemet1ido - 1),
    SetVariable('lizakertjeszemet1elteltido', lizakertjeszemet1elteltido + 1)])
    bar:
        left_bar "#f00"
        if lizakertjeszemet1ido <= 3:
            left_bar "#0ff"
        if lizakertjeszemet1ido <= 0:
            left_bar "#0f0"
        value StaticValue(lizakertjeszemet1elteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen szemetosszesed2:
    timer 1.0 repeat True action If(lizakertjeszemet2ido <= 0,
    true=[SetVariable('lizaszemeteszakja', lizaszemeteszakja + 2),
    SetVariable('lizakertjeszemet2', lizakertjeszemet2 - 1),
    Hide('szemetosszesed2'),Hide('invertori2'),
    Show('invertori'),
    Show('lizakertje'),
    Jump ('lizakertjeszemet2fel')],
    false=[SetVariable('lizakertjeszemet2ido', lizakertjeszemet2ido - 1),
    SetVariable('lizakertjeszemet2elteltido', lizakertjeszemet2elteltido + 1)])
    bar:
        left_bar "#f00"
        if lizakertjeszemet2ido <= 3:
            left_bar "#0ff"
        if lizakertjeszemet2ido <= 0:
            left_bar "#0f0"
        value StaticValue(lizakertjeszemet2elteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen szemetosszesed3:
    timer 1.0 repeat True action If(lizakertjeszemet3ido <= 0,
    true=[SetVariable('lizaszemeteszakja', lizaszemeteszakja + 3),
    SetVariable('lizakertjeszemet3', lizakertjeszemet3 - 1),
    Hide('szemetosszesed3'),Hide('invertori2'),
    Show('invertori'),
    Show('lizakertje'),
    Jump ('lizakertjeszemet3fel')],
    false=[SetVariable('lizakertjeszemet3ido', lizakertjeszemet3ido - 1),
    SetVariable('lizakertjeszemet3elteltido', lizakertjeszemet3elteltido + 1)])
    bar:
        left_bar "#f00"
        if lizakertjeszemet3ido <= 3:
            left_bar "#0ff"
        if lizakertjeszemet3ido <= 0:
            left_bar "#0f0"
        value StaticValue(lizakertjeszemet3elteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen szemetosszesed4:
    timer 1.0 repeat True action If(lizakertjeszemet4ido <= 0,
    true=[SetVariable('lizaszemeteszakja', lizaszemeteszakja + 2),
    SetVariable('lizakertjeszemet4', lizakertjeszemet4 - 1),
    Hide('szemetosszesed4'),Hide('invertori2'),
    Show('invertori'),
    Show('lizakertje'),
    Jump ('lizakertjeszemet4fel')],
    false=[SetVariable('lizakertjeszemet4ido', lizakertjeszemet4ido - 1),
    SetVariable('lizakertjeszemet4elteltido', lizakertjeszemet4elteltido + 1)])
    bar:
        left_bar "#f00"
        if lizakertjeszemet4ido <= 3:
            left_bar "#0ff"
        if lizakertjeszemet4ido <= 0:
            left_bar "#0f0"
        value StaticValue(lizakertjeszemet4elteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen lizakertjetiszta:
    if holvagyok == "lizakertje":
        if lizakertjekesz == 0:
            if lizakertjedudvafelszedve == True:
                if lizakertjeszemetosszeszedve == True:
                    if lizakertjelevelekosszeszedve == True:
                        if lizakertjemadarhazaahejen == True:
                            timer 0.1 repeat True action SetVariable('lizakertjekesz', lizakertjekesz + 1)
screen napozoagy:
    timer 1.0 repeat True action If(pulinapozoagyaido <= 0,
    true=[SetVariable('pulinapozoagya', pulinapozoagya + 1),
    SetVariable('pulinapozoagyakesz', True),
    Hide('napozoagy'),
    Jump('pulinapozojakesz')],
    false=[SetVariable('pulinapozoagyaido', pulinapozoagyaido - 1),
    SetVariable('pulinapozoagyaelteltido', pulinapozoagyaelteltido + 1)])
    bar:
        left_bar "#f00"
        if pulinapozoagyaido <= 10:
            left_bar "#0ff"
        if pulinapozoagyaido <= 0:
            left_bar "#0f0"
        value StaticValue(pulinapozoagyaelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen vigyazliza8resz:
    timer 1.0 repeat True action If(pulimegfordulido <= 0,
    true=[Hide('vigyazliza8resz'),
    Jump ('lizaszexjel8reszabahagy')],
    false=[SetVariable('pulimegfordulido', pulimegfordulido - 1)])
    if pulimegfordulido < 5:
        timer 1.0 repeat True action SetVariable('pulimegfordulelteltido', pulimegfordulelteltido + 1)
        bar:
            left_bar "#f00"
            if pulimegfordulido > 2:
                left_bar "#0f0"
            if pulimegfordulido > 4:
                left_bar "#0ff"
            value StaticValue(pulimegfordulelteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if pulimegfordulvigyazgomb == 0:
        if pulimegfordulido < 6:
            timer 0.1 repeat True action SetVariable('pulimegfordulvigyazgomb', pulimegfordulvigyazgomb + 1)
    if pulimegfordulvigyazgomb == 1:
        if vigyazgombholvan == "1":
            frame:
                background ('fram')
                xpos 0.1
                ypos 0.1
                xalign 0.5
                textbutton "Stop!":
                    mouse "aktion"
                    action SetVariable('pulimegfordulvigyazgomb', pulimegfordulvigyazgomb - 1), Hide ('vigyazliza8resz'), Jump ('pulimegfordulbisztonsagosan')
                    text_style "fegeteszov"
        if vigyazgombholvan == "2":
            frame:
                background ('fram')
                xpos 0.1
                ypos 0.9
                xalign 0.5
                textbutton "Stop!":
                    mouse "aktion"
                    action SetVariable('pulimegfordulvigyazgomb', pulimegfordulvigyazgomb - 1), Hide ('vigyazliza8resz'), Jump ('pulimegfordulbisztonsagosan')
                    text_style "fegeteszov"
        if vigyazgombholvan == "3":
            frame:
                background ('fram')
                xpos 0.9
                ypos 0.1
                xalign 0.5
                textbutton "Stop!":
                    mouse "aktion"
                    action SetVariable('pulimegfordulvigyazgomb', pulimegfordulvigyazgomb - 1), Hide ('vigyazliza8resz'), Jump ('pulimegfordulbisztonsagosan')
                    text_style "fegeteszov"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
