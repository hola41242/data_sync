screen temeto:
    imagebutton:
        idle "ajtok/hosszuajtoz.png"
        xalign 0.0
        yalign 1.0
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetokapu")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.0
        ypos 0.71
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetokapu")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.0
        ypos 0.65
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetokapu")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xpos 0.46
        ypos 0.25
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("bebyeknel")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.69
        ypos 0.56
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("segisir")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.81
        ypos 0.5
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ismeretlensir")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.08
        ypos 0.5
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("megegetsir")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xpos 0.25
        ypos 0.44
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetohatsoresz")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.18
        ypos 0.56
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetosirkosz1")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.41
        ypos 0.57
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetosirkosz2")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.55
        ypos 0.59
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetosirkosz3")
    if temetolevagotrozsak == 1:
        imagebutton:
            idle "ajtok/hosszuajto2z.png"
            xpos 0.49
            yalign 0.97
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("levagottrozsak")
    if kittykeriagyufat == True:
        if gyufanalad == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.08
                ypos 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("gyufatfelveszedtemetobol")
    if macskaholvan == "temeto":
        if macskaelszaladt == False:
            if macskanalad == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.28
                    ypos 0.68
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("macskafelvesztemeto")
    if svetlana == "temetoben":
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.23
            ypos 0.35
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("svetlanaatemetoben")
    if dagiholvan == "temeto":
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.21
            ypos 0.37
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("dagiatemetoben")

screen rozsatfelszedni:
    timer 1.0 repeat True action If(rozsatfelveszido <= 0,
    true=[Hide('rozsatfelszedni')],
    false=[SetVariable('rozsatfelveszido', rozsatfelveszido - 1),
    SetVariable('rozsatfelveszidoelteltido', rozsatfelveszidoelteltido + 1)])
    bar:
        left_bar "#f00"
        if rozsatfelveszido <= 10:
            left_bar "#0ff"
        if rozsatfelveszido <= 0:
            left_bar "#0f0"
        value StaticValue(rozsatfelveszidoelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
