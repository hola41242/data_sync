screen lizanapalia:
    imagebutton:
        idle "ajtok/nszaballz.png"
        xalign 0.0
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("baloldaliszomszed")
    imagebutton:
        idle "ajtok/nszajobbz.png"
        xalign 0.575
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("lizaatjaroja")
    imagebutton:
        idle "ajtok/nszakozzepz.png"
        xalign 0.46
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("lizafurdoje")
    if hanyadiknapvan == 7:
        if pulinapozoagya >= 1:
            if tu == 0:
                imagebutton:
                    idle "ajtok/minuszz.png"
                    xpos 0.35
                    ypos 0.75
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("tutfelvenni")
    if hanyadiknapvan >= 11:
        if mrpuliholvan == "lizanapaliban":
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.55
                ypos 0.25
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("mrpulivalbeszelnilizanapaliban")
        if holvanliza == "lizanapaliaban":
            if ciliholvan == "lizanapaliaban":
                imagebutton:
                    idle "ajtok/debporz.png"
                    xpos 0.55
                    ypos 0.25
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("lizacilibeszelnapaliban")
        else:
            if ciliholvan == "lizanapaliaban":
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.55
                    ypos 0.25
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("cilibeszelnapaliban")
    if hanyadiknapvan == 12:
        if sujzonalad == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.53
                ypos 0.71
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("sujzofel")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
