screen lizaatjaroja:
    imagebutton:
        idle "ajtok/aszhaz.png"
        xalign 0.19
        yalign 0.57
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("lizanapalia")
    imagebutton:
        idle "ajtok/aszeaz.png"
        xalign 0.89
        ypos 0.18
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("lizakertje")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
