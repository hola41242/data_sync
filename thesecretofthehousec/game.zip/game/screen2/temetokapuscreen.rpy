screen temetokapu:
    imagebutton:
        idle "ajtok/hosszuajtoz.png"
        xalign 0.3
        yalign 1.0
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("terkep")
    imagebutton:
        idle "ajtok/debporz.png"
        xpos 0.4
        ypos 0.2
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temeto")
    imagebutton:
        idle "ajtok/debporz.png"
        xpos 0.58
        ypos 0.2
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temeto")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.02
        ypos 0.6
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetokapulomok")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.14
        ypos 0.52
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetokapuelsosegejlada")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.2
        ypos 0.65
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetokapudoboz")
    if kellegyagfuresz == True:
        if agfuresznalad == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.74
                ypos 0.67
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("temetokapuagvagofel")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.9
        ypos 0.68
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("temetokapuharang")
    if regiegernalad == 0:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.3
            ypos 0.68
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("szamitogepegerfell")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
