screen park:
    imagebutton:
        idle "ajtok/hosszuajtoz.png"
        xalign 0.2
        yalign 1.0
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("terkep")
    imagebutton:
        idle "ajtok/kijaratz.png"
        xalign 0.02
        yalign 0.23
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("labirintus")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.22
        yalign 0.39
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("sakkasztal")
    imagebutton:
        idle "ajtok/minuszz.png"
        xalign 0.33
        yalign 0.39
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("parkkisto")
    if parkadriana == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.43
            yalign 0.34
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkadriana")
    imagebutton:
        idle "ajtok/minuszz.png"
        xalign 0.48
        yalign 0.49
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("parkszemetes")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 1.0
        yalign 0.25
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("parkwc")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.89
        yalign 0.54
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("parkviragok")
    if parkszemet6 == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.61
            yalign 0.54
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkszemet6")
    if parkszemet4 == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.65
            yalign 0.65
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkszemet4")
    if parkszemet8 == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.81
            yalign 0.7
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkszemet8")
    if parkszemet3 == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.76
            yalign 0.91
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkszemet3")
    if parkszemet7 == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.56
            yalign 0.82
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkszemet7")
    if parkszemet1 == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.42
            yalign 0.82
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkszemet1")
    if parkszemet2 == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.32
            yalign 0.57
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkszemet2")
    if parkszemet5 == 1:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.06
            yalign 0.68
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkszemet5")
    if kittyholvan == "parkban":
        if kittyholtakarit == "1":
            imagebutton:
                idle "ajtok/minuszz.png"
                xpos 0.6
                ypos 0.3
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kittyparkbanszexy")
        if kittyholtakarit == "2":
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.85
                ypos 0.28
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kittyparkbanszexy")
        if kittyholtakarit == "3":
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.125
                ypos 0.27
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kittyparkbanszexy")
    if hanyadiknapvan == 8:
        if lizanakmegmutatadareceptet == True:
            if gyongyviragnalad == 0:
                imagebutton:
                    idle "invertori/semmi.png"
                    xpos 0.71
                    ypos 0.44
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("gyongyviragfel")
    if hanyadiknapvan == 9:
        if boboholvan == "parkban":
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.04
                yalign 0.36
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("bobovalbeszelszaparkban")
        if Edwardsholvan == "parkban":
            imagebutton:
                idle "ajtok/minuszz.png"
                xalign 0.51
                yalign 0.34
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parkpad")
        if beszeltelannaval9resz == True:
            if leengedocsofelveheted == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.85
                    yalign 0.4
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("jimmelbeszelniparkban")
            if leengedonalad == 0:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.73
                    yalign 0.4
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("fodoesanikabeszelgetparkban")
        if macskaholvan == "parknal":
            if macskaelszaladt == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xpos 0.7
                    ypos 0.52
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("macskaelszaladparknal")
        if giliszta == 1:
            if fogjhalat == 1:
                imagebutton:
                    idle "ajtok/minuszz.png"
                    xpos 0.53
                    ypos 0.62
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("gilisztafel")
    if holvanliza == "sertegetikittyaparkban":
        if kittyholvan == "sertegetikittyaparkban":
            imagebutton:
                idle "ajtok/furdoszekrenyz.png"
                xpos 0.15
                ypos 0.21
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kittyeslizaparkbanvitatkozik")
    if adrianaholvan == "parkban":
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.43
            yalign 0.34
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkadriana")
    if hanyadiknapvan >= 11:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.51
            yalign 0.34
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkpad")
        if boboholvan == "parkban":
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.04
                yalign 0.36
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("bobovalbeszelszaparkban")
        if csacsiholvan == "parkban":
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.85
                yalign 0.6
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("csacsigazdajaparkban")
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.67
                yalign 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("csacsiparkban")
    if hanyadiknapvan == 12:
        if asonallad == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.78
                yalign 0.45
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parkbanasofel")
        if kittyszemetenalad == 0:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.65
                ypos 0.7
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("kittyszemetetfelveszed")
    if ritaholvan == "parkbanpadon":
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.52
            yalign 0.34
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkrita")

screen fedvalaszaadriananak9resz:
    frame:
        background ('fram')
        xpos 0.2
        ypos 0.2
        xalign 0.5
        textbutton "Because I will let Bram{p}know about your affair{p}with the Dr.":
            mouse "aktion"
            action Jump ("adriananemhadja")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.2
        ypos 0.4
        xalign 0.5
        textbutton "I find you and your{p}boobs very sexy.":
            mouse "aktion"
            action Jump ("adriananemhadja")
            text_style "fegeteszov"
    frame:
        background ('fram')
        xpos 0.2
        ypos 0.6
        xalign 0.5
        textbutton "I did not have{p}a mother and…":
            mouse "aktion"
            action Jump ("adrianahadja9resz")
            text_style "fegeteszov"
screen elevezesrevaltani:
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Harder!":
            mouse "aktion"
            action Hide ('elevezesrevaltani'), Jump ("elelvezni10reszrita")
            text_style "fegeteszov"
screen elevezesrevaltani2:
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "CUM!":
            mouse "aktion"
            action Hide ('elevezesrevaltani2'), Jump ("elelvezni10reszrita2")
            text_style "fegeteszov"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
