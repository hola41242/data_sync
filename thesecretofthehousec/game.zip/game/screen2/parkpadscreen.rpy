screen parkpad:
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Hide ('parkpad'), Jump ("park")
            text_style "fegeteszov"

    if Edwardsholvan == "parkban":
        imagebutton:
            idle "ajtok/ruhazz.png"
            xpos 0.2
            ypos 0.5
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkpadborond")
        imagebutton:
            idle "ajtok/debporz.png"
            xpos 0.53
            ypos 0.1
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parkpadedwards")
        if parkpadoshatertej == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.44
                ypos 0.53
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parkpadtej")
        if parkpadoshaterzsepi == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.38
                ypos 0.55
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parkpadzsepi")
        if parkpadoshaterszedvics == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.44
                ypos 0.58
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parkpadszendvics")
        if parkpadoshaterlevel == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.73
                ypos 0.59
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parkpadlevel")
    if pecabotkell == True:
        if faagnalad == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.02
                ypos 0.2
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("faagfel")
    if hanyadiknapvan >= 11:
        if csacsikalapjanalad == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                yalign 1.0
                xalign 1.0
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("csacsikalapfel")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
