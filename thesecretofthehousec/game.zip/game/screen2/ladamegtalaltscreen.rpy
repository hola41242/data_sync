screen lada:
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Hide ('lada'), Jump ("ladaazinvertoribanki")
            text_style "fegeteszov"
    imagebutton:
        idle "ajtok/nagyajtoz.png"
        xalign 0.5
        yalign 0.5
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ladarolalaptudnivalo")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.53
        yalign 0.3
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ladanlevomariferirat")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.55
        yalign 0.6
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ladanlevomariferirat")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.7
        yalign 0.6
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ladanlevomariferirat")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.4
        yalign 0.9
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ladanlevomariferirat")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.2
        yalign 0.87
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ladanlevomariferirat")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.59
        yalign 0.87
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("ladanlevolakat")
screen ladabelseje:
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.97
        yalign 0.93
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("muanygkorte")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.07
        yalign 0.95
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("muanygalma")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.33
        yalign 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("feketekavics")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.69
        yalign 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("feherkavics")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xalign 0.12
        yalign 0.3
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("regiragtapasz")
    imagebutton:
        idle "ajtok/debpor2z.png"
        xalign 0.7
        yalign 0.9
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("papircetlik")
    imagebutton:
        idle "ajtok/debpor2z.png"
        xalign 0.4
        yalign 0.9
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("papircetlik")
    if talaltlada9reszbelurrolkarkotoresz1 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.82
            yalign 0.26
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("talaltlada9reszbelurrolkarkotoresz1fel")
    if talaltlada9reszbelurrolkarkotoresz2 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.48
            yalign 0.47
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("talaltlada9reszbelurrolkarkotoresz2fel")
    if talaltlada9reszbelurrolkarkotoresz3 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.03
            yalign 0.57
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("talaltlada9reszbelurrolkarkotoresz3fel")
    if talaltlada9reszbelurrolkarkotoresz4 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.43
            yalign 0.24
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("talaltlada9reszbelurrolkarkotoresz4fel")
    if talaltlada9reszbelurrolkarkotoresz5 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.93
            yalign 0.55
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("talaltlada9reszbelurrolkarkotoresz5fel")
    if talaltlada9reszbelurrolkarkotoresz6 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xalign 0.18
            yalign 0.7
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("talaltlada9reszbelurrolkarkotoresz6fel")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
