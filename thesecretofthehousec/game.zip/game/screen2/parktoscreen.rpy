screen parkto:
    imagebutton:
        idle "ajtok/hosszuajtoz.png"
        xalign 0.0
        yalign 1.0
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("park")
    if hanyadiknapvan == 8:
        if parktoszemet6 == 1:
            imagebutton:
                idle "ajtok/hosszuajtoz.png"
                xpos 0.1
                ypos 0.4
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parktoszemet6")
        if parktoszemet2 == 1:
            imagebutton:
                idle "ajtok/hosszuajtoz.png"
                xpos 0.45
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parktoszemet2")
        if parktoszemet1 == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.04
                ypos 0.46
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parktoszemet1")
        if parktoszemet3 == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.25
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parktoszemet3")
        if parktoszemet4 == 1:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.66
                ypos 0.68
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parktoszemet4")
        if parktoszemet5 == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.02
                ypos 0.73
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parktoszemet5")
        if parktoszemet7 == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.75
                ypos 0.85
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parktoszemet7")
        if parktoszemet8 == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xpos 0.3
                ypos 0.85
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("parktoszemet8")
        if holvanliza == "parktonalviragotkutata1":
            if lizamekpozbanvan == 2:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.55
                    ypos 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("lizaseggeparkban")
    if hanyadiknapvan == 9:
        if macskaholvan == "parktonal":
            imagebutton:
                idle "ajtok/ruhaz.png"
                xpos 0.42
                ypos 0.45
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("macskaelszaladparktonal")
        if fogjhalat == 1:
            if halnalad == 0:
                imagebutton:
                    idle "ajtok/hosszuajtoz.png"
                    xpos 0.35
                    ypos 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("horgaszparktonal")
                imagebutton:
                    idle "ajtok/furdoszekrenyz.png"
                    xpos 0.85
                    ypos 0.5
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("horgaszparktonal")
        if annaholvan == "parktonal":
            imagebutton:
                idle "ajtok/debpor2z.png"
                xpos 0.5
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("annavalbeszelniatonal")
    if hanyadiknapvan == 10:
        if fodoholvan == "parkto":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.56
                ypos 0.3
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("fodovalbeszelniatonal")
        if annaholvan == "parktonal2":
            imagebutton:
                idle "ajtok/debpor2z.png"
                xpos 0.5
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("annavalbeszelniatonal2")
    if hanyadiknapvan >= 11:
        imagebutton:
            idle "ajtok/hosszuajtoz.png"
            xpos 0.35
            ypos 0.5
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktorobeszel")
        imagebutton:
            idle "ajtok/furdoszekrenyz.png"
            xpos 0.85
            ypos 0.5
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktorobeszel")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.25
            ypos 0.51
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktoviragok")
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.13
            ypos 0.46
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktoviragok")
        imagebutton:
            idle "ajtok/hosszuajto2z.png"
            xpos 0.25
            ypos 0.68
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktoviragok")
        imagebutton:
            idle "ajtok/ruhazz.png"
            xpos 0.76
            ypos 0.25
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktofa")
        imagebutton:
            idle "ajtok/minuszz.png"
            xpos 0.35
            ypos 0.42
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktopad")
        imagebutton:
            idle "ajtok/minuszz.png"
            xpos 0.52
            ypos 0.42
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktopad")
        imagebutton:
            idle "ajtok/minuszz.png"
            xpos 0.59
            ypos 0.24
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("parktoutcailampa")
        if annaholvan == "parktonal2":
            imagebutton:
                idle "ajtok/debpor2z.png"
                xpos 0.5
                ypos 0.5
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("annavalbeszelniatonal2")





screen parktoszemet3:
    timer 1.0 repeat True action If(parktoszemet3ido <= 0,
    true=[Hide('parktoszemet3')],
    false=[SetVariable('parktoszemet3ido', parktoszemet3ido - 1),
    SetVariable('parktoszemet3elteltido', parktoszemet3elteltido + 1)])
    bar:
        left_bar "#f00"
        if parktoszemet3ido <= 3:
            left_bar "#0ff"
        if parktoszemet3ido <= 0:
            left_bar "#0f0"
        value StaticValue(parktoszemet3elteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen parktoszemet5:
    timer 1.0 repeat True action If(parktoszemet5ido <= 0,
    true=[Hide('parktoszemet5')],
    false=[SetVariable('parktoszemet5ido', parktoszemet5ido - 1),
    SetVariable('parktoszemet5elteltido', parktoszemet5elteltido + 1)])
    bar:
        left_bar "#f00"
        if parktoszemet5ido <= 3:
            left_bar "#0ff"
        if parktoszemet5ido <= 0:
            left_bar "#0f0"
        value StaticValue(parktoszemet5elteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen parktoszemet8:
    timer 1.0 repeat True action If(parktoszemet8ido <= 0,
    true=[Hide('parktoszemet8')],
    false=[SetVariable('parktoszemet8ido', parktoszemet8ido - 1),
    SetVariable('parktoszemet8elteltido', parktoszemet8elteltido + 1)])
    bar:
        left_bar "#f00"
        if parktoszemet8ido <= 3:
            left_bar "#0ff"
        if parktoszemet8ido <= 0:
            left_bar "#0f0"
        value StaticValue(parktoszemet8elteltido, 5) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen parktoszemet2:
    timer 1.0 repeat True action If(parktoszemet2ido <= 0,
    true=[Hide('parktoszemet2')],
    false=[SetVariable('parktoszemet2ido', parktoszemet2ido - 1),
    SetVariable('parktoszemet2elteltido', parktoszemet2elteltido + 1)])
    bar:
        left_bar "#f00"
        if parktoszemet2ido <= 10:
            left_bar "#0ff"
        if parktoszemet2ido <= 0:
            left_bar "#0f0"
        value StaticValue(parktoszemet2elteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen parktoszemet6:
    timer 1.0 repeat True action If(parktoszemet6ido <= 0,
    true=[Hide('parktoszemet6')],
    false=[SetVariable('parktoszemet6ido', parktoszemet6ido - 1),
    SetVariable('parktoszemet6elteltido', parktoszemet6elteltido + 1)])
    bar:
        left_bar "#f00"
        if parktoszemet6ido <= 10:
            left_bar "#0ff"
        if parktoszemet6ido <= 0:
            left_bar "#0f0"
        value StaticValue(parktoszemet6elteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
screen lizamejzozbanvan:
    if lizamekpozbanvan == 1:
        timer 10.0 repeat True action SetVariable('lizamekpozbanvan', 2)
    if lizamekpozbanvan == 2:
        timer 10.0 repeat True action SetVariable('lizamekpozbanvan', 1)
screen horogannalababan:
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.35
        ypos 0.02
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Hide ('horogannalababan'), Jump ("kiszededahorgotannalababol")
screen annafogdosasipontjai1:
    imagebutton:
        idle "ajtok/ruhazz.png"
        xpos 0.65
        ypos 0.73
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("annafogdosasipontjai1")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xpos 0.5
        ypos 0.73
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("annafogdosasipontjai1")
screen annafogdosasipontjai2:
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.65
        ypos 0.59
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("annafogdosasipontjai2")
screen annafogdosasipontjai3:
    imagebutton:
        idle "ajtok/ruhazz.png"
        xpos 0.22
        ypos 0.4
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("annafogdosasipontjai3")
screen annaebred:
    timer 1.0 repeat True action If(annaajultido <= 0,
    true=[Hide('annaebred'),
    Jump ('annafelebred')],
    false=[SetVariable('annaajultido', annaajultido - 1),
    SetVariable('annaajultelteltido', annaajultelteltido + 1)])
    bar:
        left_bar "#0f0"
        if annaajultido <= 60:
            left_bar "#0ff"
        if annaajultido <= 10:
            left_bar "#f00"
        value StaticValue(annaajultelteltido, 120) xpos 0.9 xalign 0.5 ypos 0.05 yalign 0.5 xsize 300 ysize 20
    frame:
        background ('fram')
        xpos 0.075
        ypos 0.9
        xalign 0.5
        textbutton "Back":
            mouse "aktion"
            action Hide ('annaebred'), Jump ("annafelebred")
            text_style "fegeteszov"
screen horgaszas:
    timer 1.0 repeat True action If(ferdhorgaszido <= 0,
    true=[Hide('horgaszas')],
    false=[SetVariable('ferdhorgaszido', ferdhorgaszido - 1),
    SetVariable('ferdhorgaszelteltido', ferdhorgaszelteltido + 1)])
    bar:
        left_bar "#f00"
        if ferdhorgaszido <= 10:
            left_bar "#0ff"
        if ferdhorgaszido <= 0:
            left_bar "#0f0"
        value StaticValue(ferdhorgaszelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
