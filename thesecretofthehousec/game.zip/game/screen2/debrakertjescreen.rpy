screen debrakertje:
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 1.0
        yalign 1.0
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("fajasokertfele")
    if debrakertjekivagnivalobokorenged == True:
        if debrakertjekivagnivalobokor == 0:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.3
                yalign 0.3
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debrakertje2")
    if debrakertjekivagnivalobokorenged == False:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.3
            yalign 0.3
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("debrakertjebokorutban")
    if debrakertjekivagnivalobokorenged == True:
        if debrakertjekivagnivalobokor == 1:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.3
                yalign 0.3
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("debrakertjebokortlevagazutbol")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.54
        yalign 0.46
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertjekomposztalo")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xalign 0.88
        yalign 0.85
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("debrakertjegombak")
    if debraviragcserepe == 2:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.28
            ypos 0.53
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("viragcserepakertben")
    if debraholcsinal == "kertbentanul":
        imagebutton:
            idle "ajtok/ruhazz.png"
            xpos 0.16
            ypos 0.48
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("debratmegnezedakertben")
    if hanyadiknapvan == 7:
        if mamanyaklanc == 3:
            if mamakert2benholvan == 0:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xpos 0.63
                    ypos 0.45
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kertbenmamavalbeszed")
    if hanyadiknapvan == 8:
        if lizanakmegmutatadareceptet == True:
            if poknalad == 0:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    if pokel == True:
                        xpos 0.27
                        ypos 0.8
                    if pokel == False:
                        xpos 0.37
                        ypos 0.83
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("pokotfel")
    if hanyadiknapvan == 9:
        if giliszta2 == 1:
            if fogjhalat == 1:
                imagebutton:
                    idle "ajtok/minuszz.png"
                    xpos 0.38
                    ypos 0.87
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("giliszta2fel")
        if mamaholvan == "kertben.":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.08
                ypos 0.17
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("beszedmamavalkertben8resz")

screen bokorazutban:
    timer 1.0 repeat True action If(bokorazutbanido <= 0,
    true=[SetVariable('debrakertjekivagnivalobokor', debrakertjekivagnivalobokor - 1),
    Hide('bokorazutban'),
    Jump('debrakertje2')],
    false=[SetVariable('bokorazutbanido', bokorazutbanido - 1),
    SetVariable('bokorazutbanelteltido', bokorazutbanelteltido + 1)])
    bar:
        left_bar "#f00"
        if bokorazutbanido <= 10:
            left_bar "#0ff"
        if bokorazutbanido <= 0:
            left_bar "#0f0"
        value StaticValue(bokorazutbanelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
