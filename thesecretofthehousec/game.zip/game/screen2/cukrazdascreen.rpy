screen cukrazda:
    imagebutton:
        idle "ajtok/ruhazz.png"
        xpos 0.03
        ypos 0.16
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("terkep")
    imagebutton:
        idle "ajtok/ruhazz.png"
        xpos 0.03
        ypos 0.28
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("terkep")
    if hanyadiknapvan == 10:
        imagebutton:
            idle "ajtok/hosszuajtoz.png"
            xpos 0.48
            ypos 0.18
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("cukrazdapult")
    if hanyadiknapvan >= 11:
        if lidiaholvan == "pultnal":
            imagebutton:
                idle "ajtok/hosszuajtoz.png"
                xpos 0.48
                ypos 0.18
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("cukrazdapult")
        if lidiaholvan == "sehol":
            imagebutton:
                idle "ajtok/hosszuajtoz.png"
                xpos 0.48
                ypos 0.18
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("cukrazdapult")

    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.52
        ypos 0.67
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cukrazdatorlokendo")
    if etterembenmenufuzet2 == 1:
        imagebutton:
            idle "ajtok/ruhaz.png"
            xpos 0.08
            ypos 0.72
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("cukrazdaetlap")
    imagebutton:
        idle "ajtok/ruhaz.png"
        xpos 0.14
        ypos 0.45
        mouse "aktion"
        activate_sound "audio/click.wav"
        action Jump ("cukrazdaborsszoro")
    if ritaholvan == "cukrazda":
        imagebutton:
            idle "ajtok/ruhazz.png"
            xpos 0.33
            ypos 0.33
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("cukrazdaritavalbeszelni")
    if ismeretlencokaholvan == "cukrazda":
        if ritavalbeszeltelacukrazdaban == True:
            imagebutton:
                idle "ajtok/kijaratz.png"
                xpos 0.5
                ypos 0.3
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("cukrazdaismeretlennelbeszelni")
    if mrpuliholvan == "cukrazda":
        if ritavalbeszeltelacukrazdaban == True:
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.67
                ypos 0.36
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("cukrazdamrpulivalbeszelni")
    if hanyadiknapvan == 11:
        imagebutton:
            idle "ajtok/minuszz.png"
            xalign 0.5
            yalign 0.46
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("cukraszdaorigamikutya")
        if ragasztonalad == 0:
            imagebutton:
                idle "ajtok/minuszz.png"
                xalign 0.46
                yalign 0.43
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("cukraszdaragaszto")
    if lidiaholvan == "kintall":
        imagebutton:
            idle "ajtok/debporz.png"
            xpos 0.58
            ypos 0.2
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("cukrazdapult")
    if amandaholvan == "cukraszda":
        if lidiaholvan == "amandavalbeszel":
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.51
                ypos 0.22
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("cukraszdaamandaeslidia")
        else:
            imagebutton:
                idle "ajtok/debporz.png"
                xpos 0.58
                ypos 0.22
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("cukraszdaamanda")
    if lidiaholvan == "cukrazdabanszamlazik":
        imagebutton:
            idle "ajtok/debpor2z.png"
            xpos 0.13
            ypos 0.33
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lidiaszamlanmergelodik")
        imagebutton:
            idle "ajtok/debpor2z.png"
            xpos 0.13
            ypos 0.53
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lidiaszamlanmergelodik")
        imagebutton:
            idle "ajtok/debpor2z.png"
            xpos 0.13
            ypos 0.73
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("lidiaszamlanmergelodik")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
