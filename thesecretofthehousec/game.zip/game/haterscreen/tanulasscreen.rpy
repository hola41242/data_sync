screen mittanuljak:
    if csinalszvalamit == "semit":
        if hanyadiknapvan == 2:
            if Tanulnimatematika <= 0:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.35
                    xalign 0.5
                    textbutton "Learn math.":
                        mouse "aktion"
                        action Jump ("tanulmatek")
                        text_style "fegeteszov"
            if Tanulniepiteszet <= 0:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.45
                    xalign 0.5
                    textbutton "Learn Architecture.":
                        mouse "aktion"
                        action Jump ("tanulepit")
                        text_style "fegeteszov"
            if Tanulnitortenelem <= 0:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.55
                    xalign 0.5
                    textbutton "Learn History.":
                        mouse "aktion"
                        action Jump ("tanultori")
                        text_style "fegeteszov"
        if hanyadiknapvan == 3:
            if Tanulnimatematika3resz == False:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.35
                    xalign 0.5
                    textbutton "Learn math.":
                        mouse "aktion"
                        action Jump ("tanulmatek")
                        text_style "fegeteszov"
            if Tanulniepiteszet3resz == False:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.45
                    xalign 0.5
                    textbutton "Learn Architecture.":
                        mouse "aktion"
                        action Jump ("tanulepit")
                        text_style "fegeteszov"
            if Tanulnitortenelem3resz == False:
                frame:
                    background ('fram')
                    xpos 0.5
                    ypos 0.55
                    xalign 0.5
                    textbutton "Learn History.":
                        mouse "aktion"
                        action Jump ("tanultori")
                        text_style "fegeteszov"
    else:
        frame:
            background ('fram')
            xpos 0.15
            ypos 0.9
            xalign 0.5
            textbutton "I do no studying anymore.":
                mouse "aktion"
                action Jump ("tanulabahagy")
                text_style "fegeteszov"

screen ferdtanul:
    if csinalszvalamit == "tanulmatek":
        timer 0.5 repeat True action If(Tanulnimatematikaido <= 0,
        true=[SetVariable('Tanulnimatematika', Tanulnimatematika + 1),
        Hide('ferdtanul'),Hide('mittanuljak'),
        Jump('tanulabahagy')],
        false=[SetVariable('Tanulnimatematikaido', Tanulnimatematikaido - 1),
        SetVariable('Tanulnimatematikaeltetido', Tanulnimatematikaeltetido + 1)])
        bar:
            left_bar "#f00"
            if Tanulnimatematikaido <= 30:
                left_bar "#0ff"
            if Tanulnimatematikaido <= 0:
                left_bar "#0f0"
            value StaticValue(Tanulnimatematikaeltetido, 60) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if csinalszvalamit == "tanulepit":
        timer 0.5 repeat True action If(Tanulniepiteszetido <= 0,
        true=[SetVariable('Tanulniepiteszet', Tanulniepiteszet + 1),
        Hide('ferdtanul'),Hide('mittanuljak'),
        Jump('tanulabahagy')],
        false=[SetVariable('Tanulniepiteszetido', Tanulniepiteszetido - 1),
        SetVariable('Tanulniepiteszeteltetido', Tanulniepiteszeteltetido + 1)])
        bar:
            left_bar "#f00"
            if Tanulniepiteszetido <= 30:
                left_bar "#0ff"
            if Tanulniepiteszetido <= 0:
                left_bar "#0f0"
            value StaticValue(Tanulniepiteszeteltetido, 60) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if csinalszvalamit == "tanultori":
        timer 0.5 repeat True action If(Tanulnitortenelemido <= 0,
        true=[SetVariable('Tanulnitortenelem', Tanulnitortenelem + 1),
        Hide('ferdtanul'),Hide('mittanuljak'),
        Jump('tanulabahagy')],
        false=[SetVariable('Tanulnitortenelemido', Tanulnitortenelemido - 1),
        SetVariable('Tanulnitortenelemeltetido', Tanulnitortenelemeltetido + 1)])
        bar:
            left_bar "#f00"
            if Tanulnitortenelemido <= 30:
                left_bar "#0ff"
            if Tanulnitortenelemido <= 0:
                left_bar "#0f0"
            value StaticValue(Tanulnitortenelemeltetido, 60) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
    if csinalszvalamit == "tanuloros":
        timer 1.0 repeat True action If(oroszultanulszido <= 0,
        true=[SetVariable('oroszultanultal', True),
        Hide('ferdtanul'),Hide('mittanuljak')],
        false=[SetVariable('oroszultanulszido', oroszultanulszido - 1),
        SetVariable('oroszultanulszelteltido', oroszultanulszelteltido + 1)])
        bar:
            left_bar "#f00"
            if oroszultanulszido <= 10:
                left_bar "#0ff"
            if oroszultanulszido <= 0:
                left_bar "#0f0"
            value StaticValue(oroszultanulszelteltido, 20) xpos 0.9 xalign 0.5 ypos 0.95 yalign 0.5 xsize 300 ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
