screen kavefozo:
    if kavefozobekapcsolva == False:
        frame:
            background ('fram')
            xpos 0.075
            ypos 0.9
            xalign 0.5
            textbutton "Back":
                mouse "aktion"
                action Hide ('kavefozo'), Jump ("kavefozoki")
                text_style "fegeteszov"
    if kavehaznalatiut == 0:
        imagebutton:
            idle "ajtok/ruhazz.png"
            xalign 0.37
            yalign 0.95
            mouse "aktion"
            activate_sound "audio/click.wav"
            action Jump ("hasznalatiutmutatoolvas")
    if kavehaznalatiut == 2:
        if felszerelszurotarto == True:
            if felszereliakupakot == True:
                if kaveahejen == False:
                    if felszereliaszurot == True:
                        if kavefozobekapcsolva == False:
                            imagebutton:
                                idle "ajtok/ruhaz.png"
                                xalign 0.76
                                yalign 0.61
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                if vizakavefozoben == False:
                                    action Jump ("bekapcsol1")
                                if vizakavefozoben == True:
                                    if akavekiontohejen == False:
                                        action Jump ("bekapcsol2")
                                if vizakavefozoben == True:
                                    if akavekiontohejen == True:
                                        if kaveahejen == False:
                                            action Jump ("bekapcsol3")
    if kavehaznalatiut == 2:
        if felszerelszurotarto == True:
            if felszereliakupakot == True:
                if kaveahejen == True:
                    if felszereliaszurot == True:
                        if kavefozobekapcsolva == False:
                            imagebutton:
                                idle "ajtok/ruhaz.png"
                                xalign 0.76
                                yalign 0.61
                                mouse "aktion"
                                activate_sound "audio/click.wav"
                                if vizakavefozoben == True:
                                    if akavekiontohejen == True:
                                        if kaveahejen == True:
                                            action Jump ("bekapcsol4")
        if kavefozoheztettel == True:
            if kavefozobekapcsolva == False:
                frame:
                    background ('fram')
                    xpos 0.1
                    ypos 0.05
                    xalign 0.5
                    textbutton "Take apart.":
                        mouse "aktion"
                        action Jump ("szetszedkavefozo")
                        text_style "fegeteszov"
        if felszerelszurotarto == False:
            imagebutton:
                idle "ajtok/ruhazz.png"
                xalign 0.22
                yalign 0.75
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("felszereliaszurotartot")
        if felszerelszurotarto == False:
            if felszereliaszurot == False:
                imagebutton:
                    idle "ajtok/ruhaz.png"
                    xalign 0.74
                    yalign 0.91
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("felszereliaszurot")
        if felszereliakupakot == False:
            imagebutton:
                idle "ajtok/ruhaz.png"
                xalign 0.83
                yalign 0.82
                mouse "aktion"
                activate_sound "audio/click.wav"
                action Jump ("felszereliakupakot")
        if megkaptadavizeskancsot == True:
            if vizeskancsovizes == True:
                if vizakavefozoben == False:
                    imagebutton:
                        idle "ajtok/ruhazz.png"
                        xalign 0.93
                        yalign 0.65
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("kaveviszetbetolteni")
        if megkaptadakavekiontott == True:
            if akavekiontohejen == False:
                imagebutton:
                    idle "ajtok/ruhazz.png"
                    xalign 0.47
                    yalign 0.87
                    mouse "aktion"
                    activate_sound "audio/click.wav"
                    action Jump ("kiontotahejere")
        if kaveazasztalon == True:
            if kaveahejen == False:
                if felszerelszurotarto == False:
                    imagebutton:
                        idle "ajtok/ruhazz.png"
                        xalign 0.1
                        yalign 0.85
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("zacotasurobe")
                    imagebutton:
                        idle "ajtok/ruhazz.png"
                        xalign 0.15
                        yalign 0.4
                        mouse "aktion"
                        activate_sound "audio/click.wav"
                        action Jump ("zacotasurobe")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
