screen reszkezelo:
    if hanyadiknapvan == 2:
        if dabraboritekotkaphat == False:
            if dolgozolmosogatas == 2:
                if szenyeseltakaritasa == 2:
                    if mamavalfoglalkoz == 2:
                        if kutyapisok == 2:
                            if mamakeresei == 6:
                                timer 0.1 repeat True action SetVariable('dabraboritekotkaphat', True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
