image final4reszdebraraesnek2fszajanim:
    "final4reszdebraraesnek2fszaj1"
    pause 0.125
    "final4reszdebraraesnek2fszaj3"
    pause 0.125
    "final4reszdebraraesnek2fszaj5"
    pause 0.125
    "final4reszdebraraesnek2fszaj4"
    pause 0.125
    "final4reszdebraraesnek2fszaj2"
    pause 0.125
    "final4reszdebraraesnek2fszaj1"
    pause 0.125
    "final4reszdebraraesnek2fszaj4"
    pause 0.125
    "final4reszdebraraesnek2fszaj2"
    pause 0.125
    "final4reszdebraraesnek2fszaj5"
    pause 0.125
    "final4reszdebraraesnek2fszaj3"
    pause 0.125
    "final4reszdebraraesnek2fszaj1"
    pause 0.125
    "final4reszdebraraesnek2fszaj4"
    pause 0.125
    repeat
image final4reszdebraraesnek2fszemanim:
    "final4reszdebraraesnek2fszem1"
    pause 2.525
    "final4reszdebraraesnek2fszem2"
    pause 0.125
    "final4reszdebraraesnek2fszem3"
    pause 0.125
    "final4reszdebraraesnek2fszem4"
    pause 0.125
    "final4reszdebraraesnek2fszem3"
    pause 0.125
    "final4reszdebraraesnek2fszem2"
    pause 0.125
    "final4reszdebraraesnek2fszem1"
    pause 5.525
    "final4reszdebraraesnek2fszem2"
    pause 0.125
    "final4reszdebraraesnek2fszem3"
    pause 0.125
    "final4reszdebraraesnek2fszem4"
    pause 0.125
    "final4reszdebraraesnek2fszem3"
    pause 0.125
    "final4reszdebraraesnek2fszem2"
    pause 0.125
    repeat
image final4reszdebraraesnek3dorzsianim:
    "final4reszdebraraesnek3dorzsi1"
    pause 0.125
    "final4reszdebraraesnek3dorzsi2"
    pause 0.125
    "final4reszdebraraesnek3dorzsi3"
    pause 0.125
    "final4reszdebraraesnek3dorzsi4"
    pause 0.125
    "final4reszdebraraesnek3dorzsi5"
    pause 0.125
    "final4reszdebraraesnek3dorzsi4"
    pause 0.125
    "final4reszdebraraesnek3dorzsi3"
    pause 0.125
    "final4reszdebraraesnek3dorzsi2"
    pause 0.125
    "final4reszdebraraesnek3dorzsi1"
    pause 0.125
    "final4reszdebraraesnek3dorzsi2"
    pause 0.125
    "final4reszdebraraesnek3dorzsi3"
    pause 0.125
    "final4reszdebraraesnek3dorzsi4"
    pause 0.125
    "final4reszdebraraesnek3dorzsi5"
    pause 0.125
    "final4reszdebraraesnek3dorzsi4"
    pause 0.125
    "final4reszdebraraesnek3dorzsi3"
    pause 0.125
    "final4reszdebraraesnek3dorzsi2"
    pause 0.125
    "final4reszdebraraesnek3dorzsi1"
    pause 0.125
    "final4reszdebraraesnek3dorzsi2"
    pause 0.125
    "final4reszdebraraesnek3dorzsi3"
    pause 0.125
    "final4reszdebraraesnek3dorzsi4"
    pause 0.125
    "final4reszdebraraesnek3dorzsi5"
    pause 0.125
    "final4reszdebraraesnek3dorzsi4"
    pause 0.125
    "final4reszdebraraesnek3dorzsi3"
    pause 0.125
    "final4reszdebraraesnek3dorzsi2"
    pause 0.125
    "final4reszdebraraesnek3dorzsi1"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi5"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi1"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi5"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi1"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi5"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi1"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi5"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi1"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi5"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi1"
    pause 0.1
    "final4reszdebraraesnek3dorzsi2"
    pause 0.1
    "final4reszdebraraesnek3dorzsi3"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.1
    "final4reszdebraraesnek3dorzsi5"
    pause 0.1
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi1"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi5"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi1"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi5"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi1"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi5"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi1"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi5"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi1"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi5"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi1"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi5"
    pause 0.084
    "final4reszdebraraesnek3dorzsi4"
    pause 0.084
    "final4reszdebraraesnek3dorzsi3"
    pause 0.084
    "final4reszdebraraesnek3dorzsi2"
    pause 0.084
    repeat
image final4reszanim1:
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "final4resz-2"
    pause 0.066
    "final4resz-3"
    pause 0.066
    "final4resz-4"
    pause 0.066
    "final4resz-5"
    pause 0.066
    "final4resz-6"
    pause 0.066
    "final4resz-7"
    pause 0.066
    "final4resz-8"
    pause 0.066
    "final4resz2-5"
    pause 0.066
image final4reszanim2:
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "final4resz2-2"
    pause 0.066
    "final4resz2-3"
    pause 0.066
    "final4resz2-4"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "final4resz2-6"
    pause 0.066
    "final4resz2-7"
    pause 0.066
    "final4resz2-8"
    pause 0.066
    "final4resz2-5"
    pause 0.066
image final4reszanim3:
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "feher"
    pause 0.066
    "final4resz2-5"
    pause 0.066
    "final4resz3-2"
    pause 0.066
    "final4resz3-3"
    pause 0.066
    "final4resz3-4"
    pause 0.066
    "final4resz3-5"
    pause 0.066
    "final4resz3-6"
    pause 0.066
    "final4resz3-7"
    pause 0.066
    "final4resz3-8"
    pause 0.066
    "final4resz2-5"
    pause 0.066
image stripbarjelenet13:
    "stripbarjelenet13v1"
    pause 0.1
    "stripbarjelenet13v2"
    pause 0.1
    "stripbarjelenet13v3"
    pause 0.1
    "stripbarjelenet13v4"
    pause 0.1
    "stripbarjelenet13v5"
    pause 0.1
    "stripbarjelenet13v6"
    pause 0.1
    "stripbarjelenet13v7"
    pause 0.1
    repeat
image fiupoz1kep1:
    "fiupoz1"
image fiupoz1kep2:
    "fiupoz1"
image fiupoz1csakszemanimkovetidebrat:
    "fiupoz1csakszem2"
    pause 2.0
    "fiupoz1csakszem3"
    pause 2.0
    "fiupoz1csakszem4"
    pause 1.0
    "fiupoz1csakszem5"
image fiupoz1csakszemanimkovetidebrat2:
    "fiupoz1csakszem2"
    pause 0.2
    "fiupoz1csakszem3"
    pause 0.2
    "fiupoz1csakszem4"
    pause 0.2
    "fiupoz1csakszem5"
image harmasbeszedpoz3ferd2:
    "harmasbeszedpoz3ferd"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
