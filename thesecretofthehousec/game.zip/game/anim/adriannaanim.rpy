image adrianajelenetek9rasz2anim:
    "adrianajelenetek9rasz2moz1"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz6"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz1"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz6"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz1"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz6"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz1"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz6"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz1"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz6"
    pause 0.125
    "adrianajelenetek9rasz2moz5"
    pause 0.125
    "adrianajelenetek9rasz2moz4"
    pause 0.125
    "adrianajelenetek9rasz2moz3"
    pause 0.125
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.125
    "adrianajelenetek9rasz2moz1"
    pause 0.125
    "adrianajelenetek9rasz2moz7"
    pause 0.125
    "adrianajelenetek9rasz2moz8"
    pause 0.125
    "adrianajelenetek9rasz2moz9"
    pause 0.125
    "adrianajelenetek9rasz2moz10"
    pause 0.125
    "adrianajelenetek9rasz2moz9"
    pause 0.125
    "adrianajelenetek9rasz2moz8"
    pause 0.125
    "adrianajelenetek9rasz2moz7"
    pause 0.125
    "adrianajelenetek9rasz2moz1"
    pause 0.125
    "adrianajelenetek9rasz2moz7"
    pause 0.125
    "adrianajelenetek9rasz2moz8"
    pause 0.125
    "adrianajelenetek9rasz2moz9"
    pause 0.125
    "adrianajelenetek9rasz2moz10"
    pause 0.125
    "adrianajelenetek9rasz2moz9"
    pause 0.125
    "adrianajelenetek9rasz2moz8"
    pause 0.125
    "adrianajelenetek9rasz2moz7"
    pause 0.125
    "adrianajelenetek9rasz2moz1"
    pause 0.125
    "adrianajelenetek9rasz2moz7"
    pause 0.1
    "adrianajelenetek9rasz2moz8"
    pause 0.1
    "adrianajelenetek9rasz2moz9"
    pause 0.1
    "adrianajelenetek9rasz2moz10"
    pause 0.1
    "adrianajelenetek9rasz2moz9"
    pause 0.1
    "adrianajelenetek9rasz2moz8"
    pause 0.1
    "adrianajelenetek9rasz2moz7"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz7"
    pause 0.1
    "adrianajelenetek9rasz2moz8"
    pause 0.1
    "adrianajelenetek9rasz2moz9"
    pause 0.1
    "adrianajelenetek9rasz2moz10"
    pause 0.1
    "adrianajelenetek9rasz2moz9"
    pause 0.1
    "adrianajelenetek9rasz2moz8"
    pause 0.1
    "adrianajelenetek9rasz2moz7"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz6"
    pause 0.1
    "adrianajelenetek9rasz2moz5"
    pause 0.1
    "adrianajelenetek9rasz2moz4"
    pause 0.1
    "adrianajelenetek9rasz2moz3"
    pause 0.1
    "adrianajelenetek9rasz2moz2"
    pause 0.1
    "adrianajelenetek9rasz2moz1"
    pause 0.1
    "adrianajelenetek9rasz2moz7"
    pause 0.1
    "adrianajelenetek9rasz2moz8"
    pause 0.1
    "adrianajelenetek9rasz2moz9"
    pause 0.1
    "adrianajelenetek9rasz2moz10"
    pause 0.1
    "adrianajelenetek9rasz2moz9"
    pause 0.1
    "adrianajelenetek9rasz2moz8"
    pause 0.1
    "adrianajelenetek9rasz2moz7"
    pause 0.084
    "adrianajelenetek9rasz2moz1"
    pause 0.084
    "adrianajelenetek9rasz2moz2"
    pause 0.084
    "adrianajelenetek9rasz2moz3"
    pause 0.084
    "adrianajelenetek9rasz2moz4"
    pause 0.084
    "adrianajelenetek9rasz2moz5"
    pause 0.084
    "adrianajelenetek9rasz2moz6"
    pause 0.084
    "adrianajelenetek9rasz2moz5"
    pause 0.084
    "adrianajelenetek9rasz2moz4"
    pause 0.084
    "adrianajelenetek9rasz2moz3"
    pause 0.084
    "adrianajelenetek9rasz2moz2"
    pause 0.084
    "adrianajelenetek9rasz2moz1"
    pause 0.084
    "adrianajelenetek9rasz2moz7"
    pause 0.084
    "adrianajelenetek9rasz2moz8"
    pause 0.084
    "adrianajelenetek9rasz2moz9"
    pause 0.1
    "adrianajelenetek9rasz2moz10"
    pause 0.1
    "adrianajelenetek9rasz2moz9"
    pause 0.1
    "adrianajelenetek9rasz2moz8"
    pause 0.1
    "adrianajelenetek9rasz2moz7"
    pause 0.1
    repeat
image adrianajelenetek9rasz2szaj:
    "adrianajelenetek9rasz2szaj1"
    pause 0.16
    "adrianajelenetek9rasz2szaj2"
    pause 0.16
    "adrianajelenetek9rasz2szaj5"
    pause 0.16
    "adrianajelenetek9rasz2szaj6"
    pause 0.16
    "adrianajelenetek9rasz2szaj3"
    pause 0.16
    "adrianajelenetek9rasz2szaj4"
    pause 0.16
    "adrianajelenetek9rasz2szaj1"
    pause 0.16
    "adrianajelenetek9rasz2szaj5"
    pause 0.16
    "adrianajelenetek9rasz2szaj3"
    pause 0.16
    "adrianajelenetek9rasz2szaj4"
    pause 0.16
    "adrianajelenetek9rasz2szaj6"
    pause 0.16
    "adrianajelenetek9rasz2szaj2"
    pause 0.16
    repeat
image adriana12napfejleanim:
    "adriana12napfejmoz1"
    pause 0.125
    "adriana12napfejmoz2"
    pause 0.125
    "adriana12napfejmoz3"
    pause 0.125
    "adriana12napfejmoz4"
    pause 0.125
    "adriana12napfejmoz5"
    pause 0.125
image adriana12napfejfelanim:
    "adriana12napfejmoz5"
    pause 0.125
    "adriana12napfejmoz4"
    pause 0.125
    "adriana12napfejmoz3"
    pause 0.125
    "adriana12napfejmoz2"
    pause 0.125
    "adriana12napfejmoz1"
    pause 0.125
image adriana12napszajanim:
    "adriana12napszaj1"
    pause 0.16
    "adriana12napszaj2"
    pause 0.16
    "adriana12napszaj5"
    pause 0.16
    "adriana12napszaj4"
    pause 0.16
    "adriana12napszaj3"
    pause 0.16
    "adriana12napszaj4"
    pause 0.16
    "adriana12napszaj1"
    pause 0.16
    "adriana12napszaj5"
    pause 0.16
    "adriana12napszaj3"
    pause 0.16
    "adriana12napszaj4"
    pause 0.16
    "adriana12napszaj5"
    pause 0.16
    "adriana12napszaj2"
    pause 0.16
    repeat
image adriana12napszemanim:
    "adriana12napszem1"
    pause 4.125
    "adriana12napszem2"
    pause 0.125
    "adriana12napszem3"
    pause 0.125
    "adriana12napszem2"
    pause 0.125
    repeat
image adriana12napkezekanim:
    "adriana12napkezek1"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 1.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 2.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 2.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 2.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 1.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 1.87
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 2.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 2.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 2.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 1.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 2.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 1.57
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 3.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 2.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 1.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek5"
    pause 2.17
    "adriana12napkezek4"
    pause 0.17
    "adriana12napkezek3"
    pause 0.17
    "adriana12napkezek2"
    pause 0.17
    "adriana12napkezek1"
    pause 0.17
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
