image kitty270szemetettszedanim:
    "kitty270szemetettszed1"
    pause 1.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.584
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.484
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.584
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.284
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.884
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    repeat
image kitty270szemetettszedanim2:
    "kitty270szemetettszed1"
    pause 1.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.584
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.484
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.584
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.284
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.884
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    repeat
image kitty270szemetettszedanim3:
    "kitty270szemetettszed1"
    pause 1.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.584
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.484
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.584
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.284
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed1"
    pause 0.584
    "kitty270szemetettszed2"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed5"
    pause 0.884
    "kitty270szemetettszed4"
    pause 0.084
    "kitty270szemetettszed3"
    pause 0.084
    "kitty270szemetettszed2"
    pause 0.084
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
