image debrasopor:
    "debrasopor-0001"
    pause 0.16
    "debrasopor-0002"
    pause 0.16
    "debrasopor-0003"
    pause 0.16
    "debrasopor-0004"
    pause 0.20
    "debrasopor-0005"
    pause 0.20
    "debrasopor-0006"
    pause 0.20
    repeat
image debrafotelpislog:
    "debraujsaggalpis1"
    pause 4.16
    "debraujsaggalpis2"
    pause 0.16
    "debraujsaggalpis3"
    pause 0.16
    "debraujsaggalpis2"
    pause 0.16
    repeat
image benyitpan1:
    "jelen3-1"
    pause 0.042
    "jelen3-2"
    pause 0.042
    "jelen3-3"
    pause 0.042
    "jelen3-4"
    pause 0.042
    "jelen3-5"
    pause 0.042
    "jelen3-6"
    pause 0.042
    "jelen3-7"
    pause 0.042
    "jelen3-8"
    pause 0.042
    "jelen3-9"
    pause 0.042
    "jelen3-10"
    pause 0.042
    "jelen3-11"
    pause 0.042
    "jelen3-12"
    pause 0.042
    "jelen3-13"
    pause 0.042
    "jelen3-14"
    pause 0.042
    "jelen3-15"
    pause 0.042
    "jelen3-16"
    pause 0.042
    "jelen3-17"
    pause 0.042
    "jelen3-18"
    pause 0.042
    "jelen3-19"
    pause 0.042
    "jelen3-20"
    pause 0.042
image benyitpan2:
    "jelen4-1"
    pause 0.042
    "jelen4-2"
    pause 0.042
    "jelen4-3"
    pause 0.042
    "jelen4-4"
    pause 0.042
    "jelen4-5"
    pause 0.042
    "jelen4-6"
    pause 0.042
    "jelen4-7"
    pause 0.042
    "jelen4-8"
    pause 0.042
    "jelen4-9"
    pause 0.042
    "jelen4-10"
    pause 0.042
    "jelen4-11"
    pause 0.042
    "jelen4-12"
    pause 0.042
    "jelen4-13"
    pause 0.042
    "jelen4-14"
    pause 0.042
    "jelen4-15"
    pause 0.042
    "jelen4-16"
    pause 0.042
    "jelen4-17"
    pause 0.042
    "jelen4-18"
    pause 0.042
    "jelen4-19"
    pause 0.042
    "jelen4-20"
    pause 0.042
image kukucskasegcsepeg:
    "kulcsjuksegviz1"
    pause 0.16
    "kulcsjuksegviz2"
    pause 0.16
    "kulcsjuksegviz3"
    pause 0.16
    "kulcsjuksegviz4"
    pause 0.16
    repeat
image kukucskamosamagat:
    "kulcsjukfurdik1"
    pause 0.16
    "kulcsjukfurdik2"
    pause 0.16
    "kulcsjukfurdik3"
    pause 0.16
    "kulcsjukfurdik4"
    pause 0.16
    "kulcsjukfurdik5"
    pause 0.16
    "kulcsjukfurdik6"
    pause 0.16
    repeat
image debrakadbanpislog:
    "kulcsjukpislog1"
    pause 4.16
    "kulcsjukpislog2"
    pause 0.16
    "kulcsjukpislog3"
    pause 0.16
    "kulcsjukpislog2"
    pause 0.16
    repeat
image debrakadbanpislogcsepeg:
    "kulcsjukpislogviz1"
    pause 0.16
    "kulcsjukpislogviz2"
    pause 0.16
    "kulcsjukpislogviz3"
    pause 0.16
    "kulcsjukpislogviz4"
    pause 0.16
    "kulcsjukpislogviz5"
    pause 0.16
    repeat
image furdikmemoz:
    "furdikmemoz1"
    pause 3.125
    "furdikmemoz2"
    pause 0.125
    "furdikmemoz3"
    pause 0.125
    "furdikmemoz4"
    pause 0.125
    "furdikmemoz5"
    pause 0.125
    "furdikmemoz6"
    pause 3.125
    "furdikmemoz7"
    pause 0.125
    "furdikmemoz8"
    pause 0.125
    "furdikmemoz9"
    pause 0.125
    "furdikmemoz10"
    pause 0.125
    repeat
image debrafoz:
    "konyhadebrafoz1"
    pause 0.25
    "konyhadebrafoz2"
    pause 0.25
    "konyhadebrafoz3"
    pause 0.25
    repeat
image debrafelmos:
    "debrafelmosas-1"
    pause 0.125
    "debrafelmosas-2"
    pause 0.125
    "debrafelmosas-3"
    pause 0.125
    "debrafelmosas-4"
    pause 0.125
    "debrafelmosas-5"
    pause 0.125
    "debrafelmosas-6"
    pause 0.1
    "debrafelmosas-7"
    pause 0.1
    "debrafelmosas-8"
    pause 0.1
    "debrafelmosas-9"
    pause 0.1
    repeat
image furdobubi1anim:
    "furdobubi1anim1"
    pause 0.16
    "furdobubi1anim2"
    pause 0.16
    "furdobubi1anim3"
    pause 0.16
    "furdobubi1anim4"
    pause 0.16
    "furdobubi1anim5"
    pause 0.16
    "furdobubi1anim6"
    pause 0.16
    "furdobubi1anim7"
    pause 0.16
    "furdobubi1anim8"
    pause 0.16
    "debraujsaggalpis1"
    pause 2.0
    repeat
image furdobubi2anim:
    "debraujsaggalpis1"
    pause 1.0
    "furdobubi2anim1"
    pause 0.16
    "furdobubi2anim2"
    pause 0.16
    "furdobubi2anim3"
    pause 0.16
    "furdobubi2anim4"
    pause 0.16
    "furdobubi2anim5"
    pause 0.16
    "furdobubi2anim6"
    pause 0.16
    "furdobubi2anim7"
    pause 0.16
    "furdobubi2anim8"
    pause 0.16
    "furdobubi2anim9"
    pause 0.16
    repeat
image furdobubi3anim:
    "debraujsaggalpis1"
    pause 0.5
    "furdobubi3anim1"
    pause 0.16
    "furdobubi3anim2"
    pause 0.16
    "furdobubi3anim3"
    pause 0.16
    "furdobubi3anim4"
    pause 0.16
    "furdobubi3anim5"
    pause 0.16
    repeat
image debratvnezpislog:
    "debratvnezszem1"
    pause 3.16
    "debratvnezszem2"
    pause 0.16
    "debratvnezszem3"
    pause 0.16
    "debratvnezszem2"
    pause 0.16
    repeat
image segbebasosjelenet:
    "segbebasosjelenet1-1"
    pause 0.1
    "segbebasosjelenet1-2"
    pause 0.1
    "segbebasosjelenet1-3"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-6"
    pause 0.1
    "segbebasosjelenet1-7"
    pause 0.1
    "segbebasosjelenet1-8"
    pause 0.1
    "segbebasosjelenet1-9"
    pause 0.1
    "segbebasosjelenet1-10"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-13"
    pause 0.1
    "segbebasosjelenet1-14"
    pause 0.1
    "segbebasosjelenet1-1"
    pause 0.1
    "segbebasosjelenet1-2"
    pause 0.1
    "segbebasosjelenet1-3"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-13"
    pause 0.1
    "segbebasosjelenet1-14"
    pause 0.1
    "segbebasosjelenet1-1"
    pause 0.1
    "segbebasosjelenet1-2"
    pause 0.1
    "segbebasosjelenet1-3"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-13"
    pause 0.1
    "segbebasosjelenet1-14"
    pause 0.1
    "segbebasosjelenet1-1"
    pause 0.1
    "segbebasosjelenet1-2"
    pause 0.1
    "segbebasosjelenet1-3"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-6"
    pause 0.1
    "segbebasosjelenet1-7"
    pause 0.1
    "segbebasosjelenet1-8"
    pause 0.1
    "segbebasosjelenet1-9"
    pause 0.1
    "segbebasosjelenet1-10"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-6"
    pause 0.1
    "segbebasosjelenet1-7"
    pause 0.1
    "segbebasosjelenet1-8"
    pause 0.1
    "segbebasosjelenet1-9"
    pause 0.1
    "segbebasosjelenet1-10"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-13"
    pause 0.1
    "segbebasosjelenet1-14"
    pause 0.1
    "segbebasosjelenet1-1"
    pause 0.1
    "segbebasosjelenet1-2"
    pause 0.1
    "segbebasosjelenet1-3"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-6"
    pause 0.1
    "segbebasosjelenet1-7"
    pause 0.1
    "segbebasosjelenet1-8"
    pause 0.1
    "segbebasosjelenet1-9"
    pause 0.1
    "segbebasosjelenet1-10"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-13"
    pause 0.1
    "segbebasosjelenet1-14"
    pause 0.1
    "segbebasosjelenet1-1"
    pause 0.1
    "segbebasosjelenet1-2"
    pause 0.1
    "segbebasosjelenet1-3"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-6"
    pause 0.1
    "segbebasosjelenet1-7"
    pause 0.1
    "segbebasosjelenet1-8"
    pause 0.1
    "segbebasosjelenet1-9"
    pause 0.1
    "segbebasosjelenet1-10"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-13"
    pause 0.1
    "segbebasosjelenet1-14"
    pause 0.1
    "segbebasosjelenet1-1"
    pause 0.1
    "segbebasosjelenet1-2"
    pause 0.1
    "segbebasosjelenet1-3"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-6"
    pause 0.1
    "segbebasosjelenet1-7"
    pause 0.1
    "segbebasosjelenet1-8"
    pause 0.1
    "segbebasosjelenet1-9"
    pause 0.1
    "segbebasosjelenet1-10"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-4"
    pause 0.1
    "segbebasosjelenet1-5"
    pause 0.1
    "segbebasosjelenet1-6"
    pause 0.1
    "segbebasosjelenet1-7"
    pause 0.1
    "segbebasosjelenet1-8"
    pause 0.1
    "segbebasosjelenet1-9"
    pause 0.1
    "segbebasosjelenet1-10"
    pause 0.1
    "segbebasosjelenet1-11"
    pause 0.1
    "segbebasosjelenet1-12"
    pause 0.1
    "segbebasosjelenet1-13"
    pause 0.1
    "segbebasosjelenet1-14"
    pause 0.1
    repeat
image segbebasosjelenet2:
    "segbebasosjelenet1-1"
    pause 0.084
    "segbebasosjelenet1-2"
    pause 0.084
    "segbebasosjelenet1-3"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-6"
    pause 0.084
    "segbebasosjelenet1-7"
    pause 0.084
    "segbebasosjelenet1-8"
    pause 0.084
    "segbebasosjelenet1-9"
    pause 0.084
    "segbebasosjelenet1-10"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-13"
    pause 0.084
    "segbebasosjelenet1-14"
    pause 0.084
    "segbebasosjelenet1-1"
    pause 0.084
    "segbebasosjelenet1-2"
    pause 0.084
    "segbebasosjelenet1-3"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-13"
    pause 0.084
    "segbebasosjelenet1-14"
    pause 0.084
    "segbebasosjelenet1-1"
    pause 0.084
    "segbebasosjelenet1-2"
    pause 0.084
    "segbebasosjelenet1-3"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-13"
    pause 0.084
    "segbebasosjelenet1-14"
    pause 0.084
    "segbebasosjelenet1-1"
    pause 0.084
    "segbebasosjelenet1-2"
    pause 0.084
    "segbebasosjelenet1-3"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-6"
    pause 0.084
    "segbebasosjelenet1-7"
    pause 0.084
    "segbebasosjelenet1-8"
    pause 0.084
    "segbebasosjelenet1-9"
    pause 0.084
    "segbebasosjelenet1-10"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-6"
    pause 0.084
    "segbebasosjelenet1-7"
    pause 0.084
    "segbebasosjelenet1-8"
    pause 0.084
    "segbebasosjelenet1-9"
    pause 0.084
    "segbebasosjelenet1-10"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-13"
    pause 0.084
    "segbebasosjelenet1-14"
    pause 0.084
    "segbebasosjelenet1-1"
    pause 0.084
    "segbebasosjelenet1-2"
    pause 0.084
    "segbebasosjelenet1-3"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-6"
    pause 0.084
    "segbebasosjelenet1-7"
    pause 0.084
    "segbebasosjelenet1-8"
    pause 0.084
    "segbebasosjelenet1-9"
    pause 0.084
    "segbebasosjelenet1-10"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-13"
    pause 0.084
    "segbebasosjelenet1-14"
    pause 0.084
    "segbebasosjelenet1-1"
    pause 0.084
    "segbebasosjelenet1-2"
    pause 0.084
    "segbebasosjelenet1-3"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-6"
    pause 0.084
    "segbebasosjelenet1-7"
    pause 0.084
    "segbebasosjelenet1-8"
    pause 0.084
    "segbebasosjelenet1-9"
    pause 0.084
    "segbebasosjelenet1-10"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-13"
    pause 0.084
    "segbebasosjelenet1-14"
    pause 0.084
    "segbebasosjelenet1-1"
    pause 0.084
    "segbebasosjelenet1-2"
    pause 0.084
    "segbebasosjelenet1-3"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-6"
    pause 0.084
    "segbebasosjelenet1-7"
    pause 0.084
    "segbebasosjelenet1-8"
    pause 0.084
    "segbebasosjelenet1-9"
    pause 0.084
    "segbebasosjelenet1-10"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-4"
    pause 0.084
    "segbebasosjelenet1-5"
    pause 0.084
    "segbebasosjelenet1-6"
    pause 0.084
    "segbebasosjelenet1-7"
    pause 0.084
    "segbebasosjelenet1-8"
    pause 0.084
    "segbebasosjelenet1-9"
    pause 0.084
    "segbebasosjelenet1-10"
    pause 0.084
    "segbebasosjelenet1-11"
    pause 0.084
    "segbebasosjelenet1-12"
    pause 0.084
    "segbebasosjelenet1-13"
    pause 0.084
    "segbebasosjelenet1-14"
    pause 0.084
    repeat
image kavesegtapik20:
    "kavesegtapi1"
    pause 0.14
    "kavesegtapi2"
    pause 0.14
    "kavesegtapi3"
    pause 0.14
    "kavesegtapi4"
    pause 0.14
    "kavesegtapi5"
    pause 0.14
    "kavesegtapi6"
    pause 0.14
    "kavesegtapi7"
    pause 0.14
    repeat
image debrakonyhabaneszikanim:
    "debrakonyhabaneszikkez1"
    pause 0.14
    "debrakonyhabaneszikkez2"
    pause 0.14
    "debrakonyhabaneszikkez3"
    pause 0.14
    "debrakonyhabaneszikkez4"
    pause 0.14
    "debrakonyhabaneszikkez5"
    pause 0.14
    "debrakonyhabaneszikkez6"
    pause 0.98
    "debrakonyhabaneszikkez7"
    pause 0.14
    "debrakonyhabaneszikkez8"
    pause 0.14
    repeat
image debranyulkal3reszanim8:
    "nyulkal3reszanim1"
    pause 0.125
    "nyulkal3reszanim2"
    pause 0.125
    "nyulkal3reszanim3"
    pause 0.125
    "nyulkal3reszanim4"
    pause 0.125
    "nyulkal3reszanim5"
    pause 0.125
    "nyulkal3reszanim6"
    pause 0.125
    "nyulkal3reszanim7"
    pause 0.125
    "nyulkal3reszanim8"
    pause 0.125
    "nyulkal3reszanim9"
    pause 0.125
    "nyulkal3reszanim10"
    pause 0.125
    "nyulkal3reszanim11"
    pause 0.125
    repeat
image debranyulkal3reszanim12:
    "nyulkal3reszanim1"
    pause 0.084
    "nyulkal3reszanim2"
    pause 0.084
    "nyulkal3reszanim3"
    pause 0.084
    "nyulkal3reszanim4"
    pause 0.084
    "nyulkal3reszanim5"
    pause 0.084
    "nyulkal3reszanim6"
    pause 0.084
    "nyulkal3reszanim7"
    pause 0.084
    "nyulkal3reszanim8"
    pause 0.084
    "nyulkal3reszanim9"
    pause 0.084
    "nyulkal3reszanim10"
    pause 0.084
    "nyulkal3reszanim11"
    pause 0.084
    repeat
image debraelveziamitcsinal3reszanim:
    "boldodebra3reszanim1"
    pause 0.125
    "boldodebra3reszanim2"
    pause 0.125
    "boldodebra3reszanim3"
    pause 0.125
    "boldodebra3reszanim4"
    pause 0.125
    "boldodebra3reszanim5"
    pause 0.125
    "boldodebra3reszanim6"
    pause 0.125
    "boldodebra3reszanim7"
    pause 0.125
    "boldodebra3reszanim8"
    pause 0.125
    "boldodebra3reszanim9"
    pause 0.125
    "boldodebra3reszanim10"
    pause 0.125
    "boldodebra3reszanim11"
    pause 0.125
    repeat
image debraablakotmosanim:
    "debraablakotmos1"
    pause 0.125
    "debraablakotmos2"
    pause 0.125
    "debraablakotmos3"
    pause 0.125
    "debraablakotmos4"
    pause 0.125
    "debraablakotmos5"
    pause 0.125
    "debraablakotmos4"
    pause 0.125
    "debraablakotmos3"
    pause 0.125
    "debraablakotmos2"
    pause 0.125
    repeat
image final4reszdebraraesnek2csicsianim:
    "final4reszdebraraesnek2csicsi1"
    pause 0.125
    "final4reszdebraraesnek2csicsi2"
    pause 0.125
    "final4reszdebraraesnek2csicsi3"
    pause 0.125
    "final4reszdebraraesnek2csicsi4"
    pause 0.125
    "final4reszdebraraesnek2csicsi5"
    pause 0.125
    "final4reszdebraraesnek2csicsi6"
    pause 0.125
    "final4reszdebraraesnek2csicsi7"
    pause 0.125
    "final4reszdebraraesnek2csicsi8"
    pause 0.125
    "final4reszdebraraesnek2csicsi9"
    pause 0.125
    "final4reszdebraraesnek2csicsi10"
    pause 0.125
    "final4reszdebraraesnek2csicsi11"
    pause 0.125
    "final4reszdebraraesnek2csicsi12"
    pause 0.125
    "final4reszdebraraesnek2csicsi1"
    pause 0.125
    "final4reszdebraraesnek2csicsi2"
    pause 0.125
    "final4reszdebraraesnek2csicsi3"
    pause 0.125
    "final4reszdebraraesnek2csicsi4"
    pause 0.125
    "final4reszdebraraesnek2csicsi5"
    pause 0.125
    "final4reszdebraraesnek2csicsi6"
    pause 0.125
    "final4reszdebraraesnek2csicsi7"
    pause 0.125
    "final4reszdebraraesnek2csicsi8"
    pause 0.125
    "final4reszdebraraesnek2csicsi9"
    pause 0.125
    "final4reszdebraraesnek2csicsi10"
    pause 0.125
    "final4reszdebraraesnek2csicsi11"
    pause 0.125
    "final4reszdebraraesnek2csicsi12"
    pause 0.125
    "final4reszdebraraesnek2csicsi1"
    pause 0.125
    "final4reszdebraraesnek2csicsi2"
    pause 0.125
    "final4reszdebraraesnek2csicsi3"
    pause 0.125
    "final4reszdebraraesnek2csicsi4"
    pause 0.125
    "final4reszdebraraesnek2csicsi5"
    pause 0.125
    "final4reszdebraraesnek2csicsi6"
    pause 0.125
    "final4reszdebraraesnek2csicsi7"
    pause 0.125
    "final4reszdebraraesnek2csicsi8"
    pause 0.125
    "final4reszdebraraesnek2csicsi9"
    pause 0.125
    "final4reszdebraraesnek2csicsi10"
    pause 0.125
    "final4reszdebraraesnek2csicsi11"
    pause 0.125
    "final4reszdebraraesnek2csicsi12"
    pause 0.125
    "final4reszdebraraesnek2csicsi1"
    pause 0.125
    "final4reszdebraraesnek2csicsi2"
    pause 0.125
    "final4reszdebraraesnek2csicsi3"
    pause 0.125
    "final4reszdebraraesnek2csicsi4"
    pause 0.125
    "final4reszdebraraesnek2csicsi5"
    pause 0.125
    "final4reszdebraraesnek2csicsi6"
    pause 0.125
    "final4reszdebraraesnek2csicsi7"
    pause 0.125
    "final4reszdebraraesnek2csicsi8"
    pause 0.125
    "final4reszdebraraesnek2csicsi9"
    pause 0.125
    "final4reszdebraraesnek2csicsi10"
    pause 0.125
    "final4reszdebraraesnek2csicsi11"
    pause 0.125
    "final4reszdebraraesnek2csicsi12"
    pause 0.1
    "final4reszdebraraesnek2csicsi1"
    pause 0.1
    "final4reszdebraraesnek2csicsi2"
    pause 0.1
    "final4reszdebraraesnek2csicsi3"
    pause 0.1
    "final4reszdebraraesnek2csicsi4"
    pause 0.1
    "final4reszdebraraesnek2csicsi5"
    pause 0.1
    "final4reszdebraraesnek2csicsi6"
    pause 0.1
    "final4reszdebraraesnek2csicsi7"
    pause 0.1
    "final4reszdebraraesnek2csicsi8"
    pause 0.1
    "final4reszdebraraesnek2csicsi9"
    pause 0.1
    "final4reszdebraraesnek2csicsi10"
    pause 0.1
    "final4reszdebraraesnek2csicsi11"
    pause 0.1
    "final4reszdebraraesnek2csicsi12"
    pause 0.1
    "final4reszdebraraesnek2csicsi1"
    pause 0.1
    "final4reszdebraraesnek2csicsi2"
    pause 0.1
    "final4reszdebraraesnek2csicsi3"
    pause 0.1
    "final4reszdebraraesnek2csicsi4"
    pause 0.1
    "final4reszdebraraesnek2csicsi5"
    pause 0.1
    "final4reszdebraraesnek2csicsi6"
    pause 0.1
    "final4reszdebraraesnek2csicsi7"
    pause 0.1
    "final4reszdebraraesnek2csicsi8"
    pause 0.1
    "final4reszdebraraesnek2csicsi9"
    pause 0.1
    "final4reszdebraraesnek2csicsi10"
    pause 0.1
    "final4reszdebraraesnek2csicsi11"
    pause 0.1
    "final4reszdebraraesnek2csicsi12"
    pause 0.1
    "final4reszdebraraesnek2csicsi1"
    pause 0.1
    "final4reszdebraraesnek2csicsi2"
    pause 0.1
    "final4reszdebraraesnek2csicsi3"
    pause 0.1
    "final4reszdebraraesnek2csicsi4"
    pause 0.1
    "final4reszdebraraesnek2csicsi5"
    pause 0.1
    "final4reszdebraraesnek2csicsi6"
    pause 0.1
    "final4reszdebraraesnek2csicsi7"
    pause 0.1
    "final4reszdebraraesnek2csicsi8"
    pause 0.1
    "final4reszdebraraesnek2csicsi9"
    pause 0.1
    "final4reszdebraraesnek2csicsi10"
    pause 0.1
    "final4reszdebraraesnek2csicsi11"
    pause 0.1
    "final4reszdebraraesnek2csicsi12"
    pause 0.1
    "final4reszdebraraesnek2csicsi1"
    pause 0.1
    "final4reszdebraraesnek2csicsi2"
    pause 0.1
    "final4reszdebraraesnek2csicsi3"
    pause 0.1
    "final4reszdebraraesnek2csicsi4"
    pause 0.1
    "final4reszdebraraesnek2csicsi5"
    pause 0.1
    "final4reszdebraraesnek2csicsi6"
    pause 0.1
    "final4reszdebraraesnek2csicsi7"
    pause 0.1
    "final4reszdebraraesnek2csicsi8"
    pause 0.1
    "final4reszdebraraesnek2csicsi9"
    pause 0.1
    "final4reszdebraraesnek2csicsi10"
    pause 0.1
    "final4reszdebraraesnek2csicsi11"
    pause 0.1
    "final4reszdebraraesnek2csicsi12"
    pause 0.1
    "final4reszdebraraesnek2csicsi1"
    pause 0.1
    "final4reszdebraraesnek2csicsi2"
    pause 0.1
    "final4reszdebraraesnek2csicsi3"
    pause 0.1
    "final4reszdebraraesnek2csicsi4"
    pause 0.1
    "final4reszdebraraesnek2csicsi5"
    pause 0.1
    "final4reszdebraraesnek2csicsi6"
    pause 0.1
    "final4reszdebraraesnek2csicsi7"
    pause 0.1
    "final4reszdebraraesnek2csicsi8"
    pause 0.1
    "final4reszdebraraesnek2csicsi9"
    pause 0.1
    "final4reszdebraraesnek2csicsi10"
    pause 0.1
    "final4reszdebraraesnek2csicsi11"
    pause 0.1
    "final4reszdebraraesnek2csicsi12"
    pause 0.1
    "final4reszdebraraesnek2csicsi1"
    pause 0.084
    "final4reszdebraraesnek2csicsi2"
    pause 0.084
    "final4reszdebraraesnek2csicsi3"
    pause 0.084
    "final4reszdebraraesnek2csicsi4"
    pause 0.084
    "final4reszdebraraesnek2csicsi5"
    pause 0.084
    "final4reszdebraraesnek2csicsi6"
    pause 0.084
    "final4reszdebraraesnek2csicsi7"
    pause 0.084
    "final4reszdebraraesnek2csicsi8"
    pause 0.084
    "final4reszdebraraesnek2csicsi9"
    pause 0.084
    "final4reszdebraraesnek2csicsi10"
    pause 0.084
    "final4reszdebraraesnek2csicsi11"
    pause 0.084
    "final4reszdebraraesnek2csicsi12"
    pause 0.084
    "final4reszdebraraesnek2csicsi1"
    pause 0.084
    "final4reszdebraraesnek2csicsi2"
    pause 0.084
    "final4reszdebraraesnek2csicsi3"
    pause 0.084
    "final4reszdebraraesnek2csicsi4"
    pause 0.084
    "final4reszdebraraesnek2csicsi5"
    pause 0.084
    "final4reszdebraraesnek2csicsi6"
    pause 0.084
    "final4reszdebraraesnek2csicsi7"
    pause 0.084
    "final4reszdebraraesnek2csicsi8"
    pause 0.084
    "final4reszdebraraesnek2csicsi9"
    pause 0.084
    "final4reszdebraraesnek2csicsi10"
    pause 0.084
    "final4reszdebraraesnek2csicsi11"
    pause 0.084
    "final4reszdebraraesnek2csicsi12"
    pause 0.084
    "final4reszdebraraesnek2csicsi1"
    pause 0.084
    "final4reszdebraraesnek2csicsi2"
    pause 0.084
    "final4reszdebraraesnek2csicsi3"
    pause 0.084
    "final4reszdebraraesnek2csicsi4"
    pause 0.084
    "final4reszdebraraesnek2csicsi5"
    pause 0.084
    "final4reszdebraraesnek2csicsi6"
    pause 0.084
    "final4reszdebraraesnek2csicsi7"
    pause 0.084
    "final4reszdebraraesnek2csicsi8"
    pause 0.084
    "final4reszdebraraesnek2csicsi9"
    pause 0.084
    "final4reszdebraraesnek2csicsi10"
    pause 0.084
    "final4reszdebraraesnek2csicsi11"
    pause 0.084
    "final4reszdebraraesnek2csicsi12"
    pause 0.084
    "final4reszdebraraesnek2csicsi1"
    pause 0.1
    "final4reszdebraraesnek2csicsi2"
    pause 0.1
    "final4reszdebraraesnek2csicsi3"
    pause 0.1
    "final4reszdebraraesnek2csicsi4"
    pause 0.1
    "final4reszdebraraesnek2csicsi5"
    pause 0.1
    "final4reszdebraraesnek2csicsi6"
    pause 0.1
    "final4reszdebraraesnek2csicsi7"
    pause 0.1
    "final4reszdebraraesnek2csicsi8"
    pause 0.1
    "final4reszdebraraesnek2csicsi9"
    pause 0.1
    "final4reszdebraraesnek2csicsi10"
    pause 0.1
    "final4reszdebraraesnek2csicsi11"
    pause 0.1
    "final4reszdebraraesnek2csicsi12"
    pause 0.1
    "final4reszdebraraesnek2csicsi1"
    pause 0.1
    "final4reszdebraraesnek2csicsi2"
    pause 0.1
    "final4reszdebraraesnek2csicsi3"
    pause 0.1
    "final4reszdebraraesnek2csicsi4"
    pause 0.1
    "final4reszdebraraesnek2csicsi5"
    pause 0.1
    "final4reszdebraraesnek2csicsi6"
    pause 0.1
    "final4reszdebraraesnek2csicsi7"
    pause 0.1
    "final4reszdebraraesnek2csicsi8"
    pause 0.1
    "final4reszdebraraesnek2csicsi9"
    pause 0.1
    "final4reszdebraraesnek2csicsi10"
    pause 0.1
    "final4reszdebraraesnek2csicsi11"
    pause 0.1
    "final4reszdebraraesnek2csicsi12"
    pause 0.1
    repeat
image final4reszdebraraesnek2dszemanim:
    "final4reszdebraraesnek2dszem1"
    pause 3.125
    "final4reszdebraraesnek2dszem2"
    pause 0.125
    "final4reszdebraraesnek2dszem3"
    pause 0.125
    "final4reszdebraraesnek2dszem4"
    pause 0.125
    "final4reszdebraraesnek2dszem3"
    pause 0.125
    "final4reszdebraraesnek2dszem2"
    pause 0.125
    repeat
image final4reszdebraraesnek2dszajanim:
    "final4reszdebraraesnek2dszaj1"
    pause 0.125
    "final4reszdebraraesnek2dszaj3"
    pause 0.125
    "final4reszdebraraesnek2dszaj5"
    pause 0.125
    "final4reszdebraraesnek2dszaj4"
    pause 0.125
    "final4reszdebraraesnek2dszaj2"
    pause 0.125
    "final4reszdebraraesnek2dszaj1"
    pause 0.125
    "final4reszdebraraesnek2dszaj4"
    pause 0.125
    "final4reszdebraraesnek2dszaj2"
    pause 0.125
    "final4reszdebraraesnek2dszaj5"
    pause 0.125
    "final4reszdebraraesnek2dszaj3"
    pause 0.125
    "final4reszdebraraesnek2dszaj1"
    pause 0.125
    "final4reszdebraraesnek2dszaj4"
    pause 0.125
    repeat
image final4reszdebraraesnek3dszemanim:
    "final4reszdebraraesnek3dszem1"
    pause 3.125
    "final4reszdebraraesnek3dszem2"
    pause 0.125
    "final4reszdebraraesnek3dszem3"
    pause 0.125
    "final4reszdebraraesnek3dszem4"
    pause 0.125
    "final4reszdebraraesnek3dszem3"
    pause 0.125
    "final4reszdebraraesnek3dszem2"
    pause 0.125
    repeat
image final4reszdebraraesnek3dszajanim:
    "final4reszdebraraesnek3dszaj1"
    pause 0.125
    "final4reszdebraraesnek3dszaj3"
    pause 0.125
    "final4reszdebraraesnek3dszaj5"
    pause 0.125
    "final4reszdebraraesnek3dszaj4"
    pause 0.125
    "final4reszdebraraesnek3dszaj2"
    pause 0.125
    "final4reszdebraraesnek3dszaj1"
    pause 0.125
    "final4reszdebraraesnek3dszaj4"
    pause 0.125
    "final4reszdebraraesnek3dszaj2"
    pause 0.125
    "final4reszdebraraesnek3dszaj5"
    pause 0.125
    "final4reszdebraraesnek3dszaj3"
    pause 0.125
    "final4reszdebraraesnek3dszaj1"
    pause 0.125
    "final4reszdebraraesnek3dszaj4"
    pause 0.125
    repeat
image final4reszdebraraesnek4szemanim:
    "final4reszdebraraesnek4szem1"
    pause 2.125
    "final4reszdebraraesnek4szem2"
    pause 0.125
    "final4reszdebraraesnek4szem3"
    pause 0.125
    "final4reszdebraraesnek4szem4"
    pause 0.125
    "final4reszdebraraesnek4szem5"
    pause 0.125
    "final4reszdebraraesnek4szem6"
    pause 0.125
image final4reszdebraraesnek4szajanim:
    "final4reszdebraraesnek4szaj1"
    pause 2.25
    "final4reszdebraraesnek4szaj2"
    pause 0.125
    "final4reszdebraraesnek4szaj3"
    pause 0.125
image final4reszdebraraesnek4fiuanim:
    "final4reszdebraraesnek4fiu1"
    pause 0.125
    "final4reszdebraraesnek4fiu2"
    pause 0.125
    "final4reszdebraraesnek4fiu3"
    pause 0.125
    "final4reszdebraraesnek4fiu4"
    pause 0.125
    "final4reszdebraraesnek4fiu5"
    pause 0.125
    "final4reszdebraraesnek4fiu6"
    pause 0.125
    "final4reszdebraraesnek4fiu5"
    pause 0.125
    "final4reszdebraraesnek4fiu4"
    pause 0.125
    "final4reszdebraraesnek4fiu3"
    pause 0.125
    "final4reszdebraraesnek4fiu2"
    pause 0.125
    repeat
image debrahattallomolfojasojobbanim:
    "debrahattallomolmoz1"
    pause 0.2
    "debrahattallomolmoz2"
    pause 0.2
    "debrahattallomolmoz3"
    pause 0.2
    "debrahattallomolmoz2"
    pause 0.2
    repeat
image debrabudittakaritanim:
    "debrabudittakarit1"
    pause 0.2
    "debrabudittakarit2"
    pause 0.2
    repeat
image debrabudittakaritmozanim:
    "debrabudittakaritmoz1"
    pause 0.1
    "debrabudittakaritmoz2"
    pause 0.1
    "debrabudittakaritmoz3"
    pause 0.1
    "debrabudittakaritmoz4"
    pause 0.1
    "debrabudittakaritmoz5"
    pause 0.1
    "debrabudittakaritmoz6"
    pause 0.1
    "debrabudittakaritmoz5"
    pause 0.1
    "debrabudittakaritmoz4"
    pause 0.1
    "debrabudittakaritmoz3"
    pause 0.1
    "debrabudittakaritmoz2"
    pause 0.1
    repeat
image debrakonyhabantorolgetanim:
    "debrakonyhabantorolget1"
    pause 0.1
    "debrakonyhabantorolget2"
    pause 0.1
    "debrakonyhabantorolget3"
    pause 0.1
    "debrakonyhabantorolget4"
    pause 0.1
    "debrakonyhabantorolget5"
    pause 0.1
    "debrakonyhabantorolget6"
    pause 0.1
    "debrakonyhabantorolget7"
    pause 0.1
    "debrakonyhabantorolget8"
    pause 0.1
    "debrakonyhabantorolget9"
    pause 0.1
    repeat
image vegsojelenet6resz3mozanim:
    "vegsojelenet6resz3moz1"
    pause 0.084
    "vegsojelenet6resz3moz2"
    pause 0.084
    "vegsojelenet6resz3moz3"
    pause 0.084
    "vegsojelenet6resz3moz4"
    pause 0.084
    "vegsojelenet6resz3moz5"
    pause 0.084
    "vegsojelenet6resz3moz6"
    pause 0.084
    "vegsojelenet6resz3moz7"
    pause 0.084
    "vegsojelenet6resz3moz8"
    pause 0.084
    "vegsojelenet6resz3moz9"
    pause 0.084
    "vegsojelenet6resz3moz10"
    pause 0.084
    "vegsojelenet6resz3moz11"
    pause 0.084
    "vegsojelenet6resz3moz12"
    pause 0.084
    "vegsojelenet6resz3moz1"
    pause 0.084
    "vegsojelenet6resz3moz2"
    pause 0.084
    "vegsojelenet6resz3moz3"
    pause 0.084
    "vegsojelenet6resz3moz4"
    pause 0.084
    "vegsojelenet6resz3moz5"
    pause 0.084
    "vegsojelenet6resz3moz6"
    pause 0.084
    "vegsojelenet6resz3moz7"
    pause 0.084
    "vegsojelenet6resz3moz8"
    pause 0.084
    "vegsojelenet6resz3moz9"
    pause 0.084
    "vegsojelenet6resz3moz10"
    pause 0.084
    "vegsojelenet6resz3moz11"
    pause 0.084
    "vegsojelenet6resz3moz12"
    pause 0.084
    "vegsojelenet6resz3moz1"
    pause 0.084
    "vegsojelenet6resz3moz2"
    pause 0.084
    "vegsojelenet6resz3moz3"
    pause 0.084
    "vegsojelenet6resz3moz4"
    pause 0.084
    "vegsojelenet6resz3moz5"
    pause 0.084
    "vegsojelenet6resz3moz6"
    pause 0.084
    "vegsojelenet6resz3moz7"
    pause 0.084
    "vegsojelenet6resz3moz8"
    pause 0.084
    "vegsojelenet6resz3moz9"
    pause 0.084
    "vegsojelenet6resz3moz10"
    pause 0.084
    "vegsojelenet6resz3moz11"
    pause 0.084
    "vegsojelenet6resz3moz12"
    pause 0.084
    "vegsojelenet6resz3moz1"
    pause 0.071
    "vegsojelenet6resz3moz2"
    pause 0.071
    "vegsojelenet6resz3moz3"
    pause 0.071
    "vegsojelenet6resz3moz4"
    pause 0.071
    "vegsojelenet6resz3moz5"
    pause 0.071
    "vegsojelenet6resz3moz6"
    pause 0.071
    "vegsojelenet6resz3moz7"
    pause 0.071
    "vegsojelenet6resz3moz8"
    pause 0.071
    "vegsojelenet6resz3moz9"
    pause 0.071
    "vegsojelenet6resz3moz10"
    pause 0.071
    "vegsojelenet6resz3moz11"
    pause 0.071
    "vegsojelenet6resz3moz12"
    pause 0.071
    "vegsojelenet6resz3moz1"
    pause 0.071
    "vegsojelenet6resz3moz2"
    pause 0.071
    "vegsojelenet6resz3moz3"
    pause 0.071
    "vegsojelenet6resz3moz4"
    pause 0.071
    "vegsojelenet6resz3moz5"
    pause 0.071
    "vegsojelenet6resz3moz6"
    pause 0.071
    "vegsojelenet6resz3moz7"
    pause 0.071
    "vegsojelenet6resz3moz8"
    pause 0.071
    "vegsojelenet6resz3moz9"
    pause 0.071
    "vegsojelenet6resz3moz10"
    pause 0.071
    "vegsojelenet6resz3moz11"
    pause 0.071
    "vegsojelenet6resz3moz12"
    pause 0.071
    "vegsojelenet6resz3moz1"
    pause 0.071
    "vegsojelenet6resz3moz2"
    pause 0.071
    "vegsojelenet6resz3moz3"
    pause 0.071
    "vegsojelenet6resz3moz4"
    pause 0.071
    "vegsojelenet6resz3moz5"
    pause 0.071
    "vegsojelenet6resz3moz6"
    pause 0.071
    "vegsojelenet6resz3moz7"
    pause 0.071
    "vegsojelenet6resz3moz8"
    pause 0.071
    "vegsojelenet6resz3moz9"
    pause 0.071
    "vegsojelenet6resz3moz10"
    pause 0.071
    "vegsojelenet6resz3moz11"
    pause 0.071
    "vegsojelenet6resz3moz12"
    pause 0.071
    repeat
image vegsojelenet6resz4anim:
    "vegsojelenet6resz4v1"
    pause 0.1
    "vegsojelenet6resz4v2"
    pause 0.1
    repeat
image vegsojelenet6resz4gecianim:
    "vegsojelenet6resz4geci1"
    pause 0.1
    "vegsojelenet6resz4geci2"
    pause 0.1
    "vegsojelenet6resz4geci3"
    pause 0.1
    "vegsojelenet6resz4geci4"
    pause 0.1
    "vegsojelenet6resz4geci5"
    pause 0.1
    "vegsojelenet6resz4geci6"
    pause 0.1
    "vegsojelenet6resz4geci7"
    pause 0.1
    "vegsojelenet6resz4geci8"
    pause 0.1
    "vegsojelenet6resz4geci9"
    pause 0.1
    "vegsojelenet6resz4geci10"
    pause 0.1
    "vegsojelenet6resz4geci11"
    pause 0.1
    "vegsojelenet6resz4geci12"
    pause 0.1
    "vegsojelenet6resz4geci13"
    pause 0.1
image vegsojelenet6resz5szemanim:
    "vegsojelenet6resz5szem1"
    pause 2.0
    "vegsojelenet6resz5szem2"
    pause 0.1
    "vegsojelenet6resz5szem3"
    pause 0.1
    "vegsojelenet6resz5szem4"
    pause 0.1
    "vegsojelenet6resz5szem5"
    pause 0.1
    "vegsojelenet6resz5szem6"
    pause 0.1
    "vegsojelenet6resz5szem7"
    pause 0.1
image vegsojelenet6resz5szemanim2:
    "vegsojelenet6resz5szem7"
    pause 0.1
    "vegsojelenet6resz5szem8"
    pause 0.1
    "vegsojelenet6resz5szem9"
    pause 0.1
    "vegsojelenet6resz5szem10"
    pause 0.1
    "vegsojelenet6resz5szem11"
    pause 0.1
image vegsojelenet6resz5szemanim3:
    "vegsojelenet6resz5szem11"
    pause 0.1
    "vegsojelenet6resz5szem12"
    pause 0.1
    "vegsojelenet6resz5szem13"
    pause 0.1
    "vegsojelenet6resz5szem14"
    pause 0.1
image vegsojelenet6resz5szemanim4:
    "vegsojelenet6resz5szem7"
    pause 1.5
    "vegsojelenet6resz5szem8"
    pause 0.1
    "vegsojelenet6resz5szem9"
    pause 0.1
    "vegsojelenet6resz5szem10"
    pause 0.1
    "vegsojelenet6resz5szem11"
    pause 1.5
    "vegsojelenet6resz5szem12"
    pause 0.1
    "vegsojelenet6resz5szem13"
    pause 0.1
    "vegsojelenet6resz5szem14"
    pause 1.5
    "vegsojelenet6resz5szem13"
    pause 0.1
    "vegsojelenet6resz5szem12"
    pause 0.1
    "vegsojelenet6resz5szem11"
    pause 1.5
    "vegsojelenet6resz5szem10"
    pause 0.1
    "vegsojelenet6resz5szem9"
    pause 0.1
    "vegsojelenet6resz5szem8"
    pause 0.1
    repeat
image vegsojelenet6resz5szemanim5:
    "vegsojelenet6resz5szem11"
    pause 0.1
    "vegsojelenet6resz5szem10"
    pause 0.1
    "vegsojelenet6resz5szem9"
    pause 0.1
    "vegsojelenet6resz5szem8"
    pause 0.1
    "vegsojelenet6resz5szem7"
    pause 0.1
image vegsojelenet6resz5szemanim6:
    "vegsojelenet6resz5szem14"
    pause 0.1
    "vegsojelenet6resz5szem13"
    pause 0.1
    "vegsojelenet6resz5szem12"
    pause 0.1
    "vegsojelenet6resz5szem11"
    pause 0.1
image vegsojelenet6resz7anim:
    "vegsojelenet6resz7v1"
    pause 0.1
    "vegsojelenet6resz7v2"
    pause 0.1
    repeat
image vegsojelenet6resz7gecianim:
    "vegsojelenet6resz7geci1"
    pause 0.1
    "vegsojelenet6resz7geci2"
    pause 0.1
    "vegsojelenet6resz7geci3"
    pause 0.1
    "vegsojelenet6resz7geci4"
    pause 0.1
    "vegsojelenet6resz7geci5"
    pause 0.1
    "vegsojelenet6resz7geci6"
    pause 0.1
    "vegsojelenet6resz7geci7"
    pause 0.1
    "vegsojelenet6resz7geci8"
    pause 0.1
    "vegsojelenet6resz7geci9"
    pause 0.1
    "vegsojelenet6resz7geci10"
    pause 0.1
    "vegsojelenet6resz7geci11"
    pause 0.1
    "vegsojelenet6resz7geci12"
    pause 0.1
    "vegsojelenet6resz7geci13"
    pause 0.1
    "vegsojelenet6resz7geci14"
    pause 0.1
    "vegsojelenet6resz7geci15"
    pause 0.1
image debrakertbentanulanim:
    "debrakertbentanul1"
    pause 3.125
    "debrakertbentanul2"
    pause 0.125
    "debrakertbentanul3"
    pause 0.125
    "debrakertbentanul4"
    pause 3.125
    "debrakertbentanul3"
    pause 0.125
    "debrakertbentanul2"
    pause 0.125
    repeat
image nap7a32mozanim:
    "nap7a32moz1"
    pause 4.084
    "nap7a32moz2"
    pause 0.084
    "nap7a32moz3"
    pause 0.084
    "nap7a32moz4"
    pause 0.084
    "nap7a32moz5"
    pause 0.084
    "nap7a32moz6"
    pause 0.084
    "nap7a32moz7"
    pause 0.084
    "nap7a32moz8"
    pause 0.084
    "nap7a32moz1"
    pause 0.084
    "nap7a32moz2"
    pause 0.084
    "nap7a32moz3"
    pause 0.084
    "nap7a32moz4"
    pause 0.084
    "nap7a32moz5"
    pause 0.084
    "nap7a32moz6"
    pause 0.084
    "nap7a32moz7"
    pause 0.084
    "nap7a32moz8"
    pause 0.084
    "nap7a32moz1"
    pause 0.084
    "nap7a32moz2"
    pause 0.084
    "nap7a32moz3"
    pause 0.084
    "nap7a32moz4"
    pause 0.084
    "nap7a32moz5"
    pause 0.084
    "nap7a32moz6"
    pause 0.084
    "nap7a32moz7"
    pause 0.084
    "nap7a32moz8"
    pause 0.084
    "nap7a32moz1"
    pause 3.084
    "nap7a32moz2"
    pause 0.084
    "nap7a32moz3"
    pause 0.084
    "nap7a32moz4"
    pause 0.084
    "nap7a32moz5"
    pause 0.084
    "nap7a32moz6"
    pause 0.084
    "nap7a32moz7"
    pause 0.084
    "nap7a32moz8"
    pause 0.084
    repeat
image nap7a35szemanim:
    "nap7a35seggszem1"
    pause 3.1
    "nap7a35seggszem2"
    pause 0.1
    "nap7a35seggszem3"
    pause 0.1
    "nap7a35seggszem4"
    pause 0.1
    "nap7a35seggszem3"
    pause 0.1
    "nap7a35seggszem2"
    pause 0.1
    repeat
image nap7a35szajanim:
    "nap7a35seggszaj1"
    pause 0.125
    "nap7a35seggszaj4"
    pause 0.125
    "nap7a35seggszaj6"
    pause 0.125
    "nap7a35seggszaj3"
    pause 0.125
    "nap7a35seggszaj2"
    pause 0.125
    "nap7a35seggszaj4"
    pause 0.125
    "nap7a35seggszaj1"
    pause 0.125
    "nap7a35seggszaj3"
    pause 0.125
    "nap7a35seggszaj6"
    pause 0.125
    "nap7a35seggszaj2"
    pause 0.125
    "nap7a35seggszaj4"
    pause 0.125
    "nap7a35seggszaj5"
    pause 0.125
    repeat
image nap7a35segganim:
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2v2"
    pause 0.084
    "nap7a35segg2v3"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2v3"
    pause 0.084
    "nap7a35segg2v2"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2v2"
    pause 0.084
    "nap7a35segg2v3"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri4"
    pause 0.084
    "nap7a35segg2veri3"
    pause 0.084
    "nap7a35segg2veri2"
    pause 0.084
    "nap7a35segg2veri1"
    pause 0.084
    "nap7a35segg2v4"
    pause 0.084
    "nap7a35segg2v3"
    pause 0.084
    "nap7a35segg2v2"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg1"
    pause 0.084
    "nap7a35segg2"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg7"
    pause 0.084
    "nap7a35segg6"
    pause 0.084
    "nap7a35segg5"
    pause 0.084
    "nap7a35segg4"
    pause 0.084
    "nap7a35segg3"
    pause 0.084
    repeat
image nap7a37segganim:
    "nap7a37segg1"
    pause 0.084
    "nap7a37segg2"
    pause 0.084
    "nap7a37segg3"
    pause 0.084
    "nap7a37segg4"
    pause 0.084
    "nap7a37segg5"
    pause 0.084
    "nap7a37segg6"
    pause 0.084
    "nap7a37segg7"
    pause 0.084
    "nap7a37segg8"
    pause 0.084
    "nap7a37segg9"
    pause 0.084
    "nap7a37segg10"
    pause 0.084
    "nap7a37segg11"
    pause 0.084
    "nap7a37segg12"
    pause 0.084
    "nap7a37segg13"
    pause 0.084
    "nap7a37segg14"
    pause 0.084
    "nap7a37segg1"
    pause 0.084
    "nap7a37segg2"
    pause 0.084
    "nap7a37segg3"
    pause 0.084
    "nap7a37segg4"
    pause 0.084
    "nap7a37segg5"
    pause 0.084
    "nap7a37segg6"
    pause 0.084
    "nap7a37segg7"
    pause 0.084
    "nap7a37segg8"
    pause 0.084
    "nap7a37segg9"
    pause 0.084
    "nap7a37segg10"
    pause 0.084
    "nap7a37segg11"
    pause 0.084
    "nap7a37segg12"
    pause 0.084
    "nap7a37segg13"
    pause 0.084
    "nap7a37segg14"
    pause 0.084
    "nap7a37segg1"
    pause 0.084
    "nap7a37segg2"
    pause 0.084
    "nap7a37segg3"
    pause 0.084
    "nap7a37segg4"
    pause 0.084
    "nap7a37segg5"
    pause 0.084
    "nap7a37segg6"
    pause 0.084
    "nap7a37segg7"
    pause 0.084
    "nap7a37segg8"
    pause 0.084
    "nap7a37segg9"
    pause 0.084
    "nap7a37segg10"
    pause 0.084
    "nap7a37segg11"
    pause 0.084
    "nap7a37segg12"
    pause 0.084
    "nap7a37segg13"
    pause 0.084
    "nap7a37segg14"
    pause 0.084
    "nap7a37segg1"
    pause 0.071
    "nap7a37segg2"
    pause 0.071
    "nap7a37segg3"
    pause 0.071
    "nap7a37segg4"
    pause 0.071
    "nap7a37segg5"
    pause 0.071
    "nap7a37segg6"
    pause 0.071
    "nap7a37segg7"
    pause 0.071
    "nap7a37segg8"
    pause 0.071
    "nap7a37segg9"
    pause 0.071
    "nap7a37segg10"
    pause 0.071
    "nap7a37segg11"
    pause 0.071
    "nap7a37segg12"
    pause 0.071
    "nap7a37segg13"
    pause 0.071
    "nap7a37segg14"
    pause 0.071
    "nap7a37segg1"
    pause 0.071
    "nap7a37segg2"
    pause 0.071
    "nap7a37segg3"
    pause 0.071
    "nap7a37segg4"
    pause 0.071
    "nap7a37segg5"
    pause 0.071
    "nap7a37segg6"
    pause 0.071
    "nap7a37segg7"
    pause 0.071
    "nap7a37segg8"
    pause 0.071
    "nap7a37segg9"
    pause 0.071
    "nap7a37segg10"
    pause 0.071
    "nap7a37segg11"
    pause 0.071
    "nap7a37segg12"
    pause 0.071
    "nap7a37segg13"
    pause 0.071
    "nap7a37segg14"
    pause 0.071
    "nap7a37segg1"
    pause 0.071
    "nap7a37segg2"
    pause 0.071
    "nap7a37segg3"
    pause 0.071
    "nap7a37segg4"
    pause 0.071
    "nap7a37segg5"
    pause 0.071
    "nap7a37segg6"
    pause 0.071
    "nap7a37segg7"
    pause 0.071
    "nap7a37segg8"
    pause 0.071
    "nap7a37segg9"
    pause 0.071
    "nap7a37segg10"
    pause 0.071
    "nap7a37segg11"
    pause 0.071
    "nap7a37segg12"
    pause 0.071
    "nap7a37segg13"
    pause 0.071
    "nap7a37segg14"
    pause 0.071
    "nap7a37segg1"
    pause 0.071
    "nap7a37segg2"
    pause 0.071
    "nap7a37segg3"
    pause 0.071
    "nap7a37segg4"
    pause 0.071
    "nap7a37segg5"
    pause 0.071
    "nap7a37segg6"
    pause 0.071
    "nap7a37segg7"
    pause 0.071
    "nap7a37segg8"
    pause 0.071
    "nap7a37segg9"
    pause 0.071
    "nap7a37segg10"
    pause 0.071
    "nap7a37segg11"
    pause 0.071
    "nap7a37segg12"
    pause 0.071
    "nap7a37segg13"
    pause 0.071
    "nap7a37segg14"
    pause 0.071
    repeat
image nap7a37szemanim:
    "nap7a37szem1"
    pause 3.1
    "nap7a37szem2"
    pause 0.1
    "nap7a37szem3"
    pause 0.1
    "nap7a37szem4"
    pause 0.1
    "nap7a37szem3"
    pause 0.1
    "nap7a37szem2"
    pause 0.1
    repeat
image nap7f5debramozanim:
    "nap7f5debramoz"
    pause 2.1
    "nap7f5debramoz2"
    pause 0.1
    "nap7f5debramoz3"
    pause 0.1
    "nap7f5debramoz4"
    pause 0.1
    "nap7f5debramoz5"
    pause 0.1
    "nap7f5debramoz6"
    pause 0.1
    "nap7f5debramoz"
    pause 3.1
    "nap7f5debramoz2"
    pause 0.1
    "nap7f5debramoz3"
    pause 0.1
    "nap7f5debramoz4"
    pause 0.1
    "nap7f5debramoz5"
    pause 0.1
    "nap7f5debramoz6"
    pause 0.1
    repeat
image nap7f5debraszemanim:
    "nap7f5debraszem1"
    pause 3.1
    "nap7f5debraszem2"
    pause 0.1
    "nap7f5debraszem3"
    pause 0.1
    "nap7f5debraszem2"
    pause 0.1
    repeat
image nap7f5debraszajanim:
    "nap7f5debraszaj1"
    pause 0.125
    "nap7f5debraszaj4"
    pause 0.125
    "nap7f5debraszaj5"
    pause 0.125
    "nap7f5debraszaj3"
    pause 0.125
    "nap7f5debraszaj2"
    pause 0.125
    "nap7f5debraszaj4"
    pause 0.125
    "nap7f5debraszaj1"
    pause 0.125
    "nap7f5debraszaj3"
    pause 0.125
    "nap7f5debraszaj5"
    pause 0.125
    "nap7f5debraszaj2"
    pause 0.125
    "nap7f5debraszaj4"
    pause 0.125
    "nap7f5debraszaj5"
    pause 0.125
    repeat
image nap7f5fredszajanim:
    "nap7f5fredszaj1"
    pause 0.125
    "nap7f5fredszaj4"
    pause 0.125
    "nap7f5fredszaj2"
    pause 0.125
    "nap7f5fredszaj3"
    pause 0.125
    "nap7f5fredszaj2"
    pause 0.125
    "nap7f5fredszaj4"
    pause 0.125
    "nap7f5fredszaj1"
    pause 0.125
    "nap7f5fredszaj3"
    pause 0.125
    "nap7f5fredszaj1"
    pause 0.125
    "nap7f5fredszaj2"
    pause 0.125
    "nap7f5fredszaj4"
    pause 0.125
    "nap7f5fredszaj3"
    pause 0.125
    repeat
image nap7a38spermaanim:
    "nap7a38sperma-1"
    pause 0.084
    "nap7a38sperma-2"
    pause 0.084
    "nap7a38sperma-3"
    pause 0.084
    "nap7a38sperma-4"
    pause 0.084
    "nap7a38sperma-5"
    pause 0.084
    "nap7a38sperma-6"
    pause 0.084
    "nap7a38sperma-7"
    pause 0.084
    "nap7a38sperma-8"
    pause 0.084
    "nap7a38sperma-9"
    pause 0.084
    "nap7a38sperma-10"
    pause 0.084
    "nap7a38sperma-11"
    pause 0.084
    "nap7a38sperma-12"
    pause 0.084
    "nap7a38sperma-13"
    pause 0.084
    "nap7a38sperma-14"
    pause 0.084
    "nap7a38sperma-15"
    pause 0.084
    "nap7a38sperma-16"
    pause 0.084
    "nap7a38sperma-17"
    pause 0.084
    "nap7a38sperma-18"
    pause 0.084
    "nap7a38sperma-19"
    pause 0.084
    "nap7a38sperma-20"
    pause 0.084
    "nap7a38sperma-21"
    pause 0.084
    "nap7a38sperma-22"
    pause 0.084
    "nap7a38sperma-23"
    pause 0.084
    "nap7a38sperma-24"
    pause 0.084
    "nap7a38sperma-25"
    pause 0.084
    "nap7a38sperma-26"
    pause 0.084
    "nap7a38sperma-27"
image debramosogatanim:
    "debramosogatmoz1"
    pause 0.125
    "debramosogatmoz2"
    pause 0.125
    "debramosogatmoz3"
    pause 0.125
    "debramosogatmoz4"
    pause 0.125
    "debramosogatmoz5"
    pause 0.125
    "debramosogatmoz6"
    pause 0.125
    repeat
image debragyomlalanim:
    "debragyomlalmoz1"
    pause 4.084
    "debragyomlalmoz2"
    pause 0.084
    "debragyomlalmoz3"
    pause 0.084
    "debragyomlalmoz4"
    pause 0.084
    "debragyomlalmoz5"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz9"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz9"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz9"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz9"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz5"
    pause 0.084
    "debragyomlalmoz4"
    pause 0.084
    "debragyomlalmoz3"
    pause 0.084
    "debragyomlalmoz2"
    pause 0.084
    repeat
image debragyomlalanim2:
    "debragyomlalmoz1"
    pause 4.084
    "debragyomlalmoz2"
    pause 0.084
    "debragyomlalmoz3"
    pause 0.084
    "debragyomlalmoz4"
    pause 0.084
    "debragyomlalmoz5"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz9"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz9"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz9"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz9"
    pause 0.084
    "debragyomlalmoz8"
    pause 0.084
    "debragyomlalmoz7"
    pause 0.084
    "debragyomlalmoz6"
    pause 0.084
    "debragyomlalmoz5"
    pause 0.084
    "debragyomlalmoz4"
    pause 0.084
    "debragyomlalmoz3"
    pause 0.084
    "debragyomlalmoz2"
    pause 0.084
    repeat
image debraalvajar540anim:
    "debraalvajar540moz1"
    pause 0.125
    "debraalvajar540moz2"
    pause 0.125
    "debraalvajar540moz3"
    pause 0.125
    "debraalvajar540moz4"
    pause 0.125
    "debraalvajar540moz5"
    pause 0.125
    "debraalvajar540moz4"
    pause 0.125
    "debraalvajar540moz3"
    pause 0.125
    "debraalvajar540moz2"
    pause 0.125
    repeat
image debraalvajaranim:
    "debraalvajarmoz1"
    pause 0.125
    "debraalvajarmoz2"
    pause 0.125
    "debraalvajarmoz3"
    pause 0.125
    "debraalvajarmoz4"
    pause 0.125
    "debraalvajarmoz5"
    pause 0.125
    "debraalvajarmoz4"
    pause 0.125
    "debraalvajarmoz3"
    pause 0.125
    "debraalvajarmoz2"
    pause 0.125
    repeat
image debraalvajaranimokos:
    "debraalvajaranim1"
    pause 0.125
    "debraalvajaranim2"
    pause 0.125
    "debraalvajaranim3"
    pause 0.125
    "debraalvajaranim4"
    pause 0.125
    "debraalvajaranim5"
    pause 0.125
    "debraalvajaranim4"
    pause 0.125
    "debraalvajaranim3"
    pause 0.125
    "debraalvajaranim2"
    pause 0.125
    repeat
image medemcetakarit1debraanim:
    "medemcetakarit1debramoz1"
    pause 0.125
    "medemcetakarit1debramoz2"
    pause 0.125
    "medemcetakarit1debramoz3"
    pause 0.125
    "medemcetakarit1debramoz4"
    pause 0.125
    "medemcetakarit1debramoz5"
    pause 0.125
    "medemcetakarit1debramoz6"
    pause 0.1
    "medemcetakarit1debramoz7"
    pause 0.1
    "medemcetakarit1debramoz8"
    pause 0.1
    "medemcetakarit1debramoz9"
    pause 0.1
    repeat
image debrafelengedanim:
    "debrafelengedmoz1"
    pause 0.1
    "debrafelengedmoz2"
    pause 0.1
    "debrafelengedmoz3"
    pause 0.1
    "debrafelengedmoz4"
    pause 0.1
    repeat
image debramasztijelenet1anim:
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 1.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 1.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 1.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 1.225
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 1.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 1.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 1.325
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 1.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 1.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 1.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 1.525
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz1"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz4"
    pause 0.125
    "debramasztijelenet1moz3"
    pause 0.125
    "debramasztijelenet1moz2"
    pause 0.125
    repeat
image debramasztijelenet1szemanim:
    "debramasztijelenet1szem1"
    pause 4.125
    "debramasztijelenet1szem2"
    pause 0.125
    "debramasztijelenet1szem3"
    pause 0.125
    "debramasztijelenet1szem4"
    pause 0.125
    "debramasztijelenet1szem3"
    pause 0.125
    "debramasztijelenet1szem2"
    pause 0.125
    repeat
image debramasztijelenet1szajanim:
    "debramasztijelenet1szaj1"
    pause 6.125
    "debramasztijelenet1szaj2"
    pause 0.125
    "debramasztijelenet1szaj3"
    pause 6.125
    "debramasztijelenet1szaj2"
    pause 0.125
    repeat
image debramasztijelenet6anim:
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 2.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 1.525
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 1.725
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 2.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 0.125
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    "debramasztijelenet6moz1"
    pause 0.125
    "debramasztijelenet6moz2"
    pause 0.125
    "debramasztijelenet6moz3"
    pause 0.125
    "debramasztijelenet6moz4"
    pause 0.125
    "debramasztijelenet6moz5"
    pause 2.625
    "debramasztijelenet6moz6"
    pause 0.125
    "debramasztijelenet6moz7"
    pause 0.125
    "debramasztijelenet6moz8"
    pause 0.125
    repeat
image debramasztijelenet6szemanim:
    "debramasztijelenet6szem1"
    pause 6.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem4"
    pause 5.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem1"
    pause 6.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem4"
    pause 0.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem1"
    pause 7.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem4"
    pause 0.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem1"
    pause 4.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem4"
    pause 0.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem1"
    pause 6.125
    "debramasztijelenet6szem2"
    pause 0.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem4"
    pause 15.125
    "debramasztijelenet6szem3"
    pause 0.125
    "debramasztijelenet6szem2"
    pause 0.125
image debramasztijelenet2anim8:
    "debramasztijelenet2-moz1"
    pause 0.125
    "debramasztijelenet2-moz2"
    pause 0.125
    "debramasztijelenet2-moz3"
    pause 0.125
    "debramasztijelenet2-moz4"
    pause 0.125
    "debramasztijelenet2-moz5"
    pause 0.125
    "debramasztijelenet2-moz4"
    pause 0.125
    "debramasztijelenet2-moz3"
    pause 0.125
    "debramasztijelenet2-moz2"
    pause 0.125
    repeat
image debramasztijelenet2anim10:
    "debramasztijelenet2-moz1"
    pause 0.1
    "debramasztijelenet2-moz2"
    pause 0.1
    "debramasztijelenet2-moz3"
    pause 0.1
    "debramasztijelenet2-moz4"
    pause 0.1
    "debramasztijelenet2-moz5"
    pause 0.1
    "debramasztijelenet2-moz4"
    pause 0.1
    "debramasztijelenet2-moz3"
    pause 0.1
    "debramasztijelenet2-moz2"
    pause 0.1
    repeat
image debramasztijelenet2szaj1anim8:
    "debramasztijelenet2szaj1-1"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-5"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-1"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-5"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-1"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-5"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-1"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-5"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-1"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-5"
    pause 0.125
    "debramasztijelenet2szaj1-4"
    pause 0.125
    "debramasztijelenet2szaj1-3"
    pause 0.125
    "debramasztijelenet2szaj1-2"
    pause 0.125
    "debramasztijelenet2szaj2-1"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-5"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-1"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-5"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-1"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-5"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-1"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-5"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-1"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-5"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj3-1"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-5"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-1"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-5"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-1"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-5"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-1"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-5"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-1"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-5"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    repeat
image debramasztijelenet2szaj2anim8:
    "debramasztijelenet2szaj2-1"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-5"
    pause 0.125
    "debramasztijelenet2szaj2-4"
    pause 0.125
    "debramasztijelenet2szaj2-3"
    pause 0.125
    "debramasztijelenet2szaj2-2"
    pause 0.125
    repeat
image debramasztijelenet2szaj3anim8:
    "debramasztijelenet2szaj3-1"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-5"
    pause 0.125
    "debramasztijelenet2szaj3-4"
    pause 0.125
    "debramasztijelenet2szaj3-3"
    pause 0.125
    "debramasztijelenet2szaj3-2"
    pause 0.125
    repeat
image debramasztijelenet2szaj1anim10:
    "debramasztijelenet2szaj1-1"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-5"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-1"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-5"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-1"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-5"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-1"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-5"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-1"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-5"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-1"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-5"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-1"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-5"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-1"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-5"
    pause 0.1
    "debramasztijelenet2szaj1-4"
    pause 0.1
    "debramasztijelenet2szaj1-3"
    pause 0.1
    "debramasztijelenet2szaj1-2"
    pause 0.1
    "debramasztijelenet2szaj3-1"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-5"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-1"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-5"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-1"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-5"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-1"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-5"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-1"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-5"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-1"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-5"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-1"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-5"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj2-1"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-5"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-1"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-5"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-1"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-5"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-1"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-5"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-1"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-5"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-1"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-5"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-1"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-5"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    repeat
image debramasztijelenet2szaj2anim10:
    "debramasztijelenet2szaj2-1"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-5"
    pause 0.1
    "debramasztijelenet2szaj2-4"
    pause 0.1
    "debramasztijelenet2szaj2-3"
    pause 0.1
    "debramasztijelenet2szaj2-2"
    pause 0.1
    repeat
image debramasztijelenet2szaj3anim10:
    "debramasztijelenet2szaj3-1"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-5"
    pause 0.1
    "debramasztijelenet2szaj3-4"
    pause 0.1
    "debramasztijelenet2szaj3-3"
    pause 0.1
    "debramasztijelenet2szaj3-2"
    pause 0.1
    repeat
image debramasztijelenet2szem1anim8:
    "debramasztijelenet2szem1-1"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-5"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-1"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-5"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-1"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-5"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem2-1"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-5"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-1"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-5"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-1"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-5"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-1"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-5"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-1"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-5"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem1-1"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-5"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-1"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-5"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-1"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-5"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem2-1"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-5"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-1"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-5"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem1-1"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-5"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-1"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-5"
    pause 0.125
    "debramasztijelenet2szem1-4"
    pause 0.125
    "debramasztijelenet2szem1-3"
    pause 0.125
    "debramasztijelenet2szem1-2"
    pause 0.125
    repeat
image debramasztijelenet2szem2anim8:
    "debramasztijelenet2szem2-1"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-5"
    pause 0.125
    "debramasztijelenet2szem2-4"
    pause 0.125
    "debramasztijelenet2szem2-3"
    pause 0.125
    "debramasztijelenet2szem2-2"
    pause 0.125
    repeat
image debramasztijelenet2szem1anim10:
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-1"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-5"
    pause 0.1
    "debramasztijelenet2szem1-4"
    pause 0.1
    "debramasztijelenet2szem1-3"
    pause 0.1
    "debramasztijelenet2szem1-2"
    pause 0.1
    repeat
image debramasztijelenet2szem2anim10:
    "debramasztijelenet2szem2-1"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-5"
    pause 0.1
    "debramasztijelenet2szem2-4"
    pause 0.1
    "debramasztijelenet2szem2-3"
    pause 0.1
    "debramasztijelenet2szem2-2"
    pause 0.1
    repeat
image debramasztijelenet3anim:
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz7"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz7"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz7"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz7"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz7"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz7"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz8"
    pause 0.125
    "debramasztijelenet3moz9"
    pause 0.125
    "debramasztijelenet3moz10"
    pause 0.125
    "debramasztijelenet3moz11"
    pause 0.125
    "debramasztijelenet3moz12"
    pause 0.125
    "debramasztijelenet3moz13"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz8"
    pause 0.125
    "debramasztijelenet3moz9"
    pause 0.125
    "debramasztijelenet3moz10"
    pause 0.125
    "debramasztijelenet3moz11"
    pause 0.125
    "debramasztijelenet3moz12"
    pause 0.125
    "debramasztijelenet3moz13"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz8"
    pause 0.125
    "debramasztijelenet3moz9"
    pause 0.125
    "debramasztijelenet3moz10"
    pause 0.125
    "debramasztijelenet3moz11"
    pause 0.125
    "debramasztijelenet3moz12"
    pause 0.125
    "debramasztijelenet3moz13"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz8"
    pause 0.125
    "debramasztijelenet3moz9"
    pause 0.125
    "debramasztijelenet3moz10"
    pause 0.125
    "debramasztijelenet3moz11"
    pause 0.125
    "debramasztijelenet3moz12"
    pause 0.125
    "debramasztijelenet3moz13"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz7"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz7"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz7"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz8"
    pause 0.1
    "debramasztijelenet3moz9"
    pause 0.1
    "debramasztijelenet3moz10"
    pause 0.1
    "debramasztijelenet3moz11"
    pause 0.1
    "debramasztijelenet3moz12"
    pause 0.1
    "debramasztijelenet3moz13"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz8"
    pause 0.1
    "debramasztijelenet3moz9"
    pause 0.1
    "debramasztijelenet3moz10"
    pause 0.1
    "debramasztijelenet3moz11"
    pause 0.1
    "debramasztijelenet3moz12"
    pause 0.1
    "debramasztijelenet3moz13"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz8"
    pause 0.1
    "debramasztijelenet3moz9"
    pause 0.1
    "debramasztijelenet3moz10"
    pause 0.1
    "debramasztijelenet3moz11"
    pause 0.1
    "debramasztijelenet3moz12"
    pause 0.1
    "debramasztijelenet3moz13"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz7"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz7"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz7"
    pause 0.125
    "debramasztijelenet3moz6"
    pause 0.125
    "debramasztijelenet3moz5"
    pause 0.125
    "debramasztijelenet3moz4"
    pause 0.125
    "debramasztijelenet3moz3"
    pause 0.125
    "debramasztijelenet3moz2"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz8"
    pause 0.125
    "debramasztijelenet3moz9"
    pause 0.125
    "debramasztijelenet3moz10"
    pause 0.125
    "debramasztijelenet3moz11"
    pause 0.125
    "debramasztijelenet3moz12"
    pause 0.125
    "debramasztijelenet3moz13"
    pause 0.125
    "debramasztijelenet3moz1"
    pause 0.125
    "debramasztijelenet3moz8"
    pause 0.125
    "debramasztijelenet3moz9"
    pause 0.125
    "debramasztijelenet3moz10"
    pause 0.125
    "debramasztijelenet3moz11"
    pause 0.125
    "debramasztijelenet3moz12"
    pause 0.125
    "debramasztijelenet3moz13"
    pause 0.125
    repeat
image debramasztijelenet3anim2:
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz8"
    pause 0.1
    "debramasztijelenet3moz9"
    pause 0.1
    "debramasztijelenet3moz10"
    pause 0.1
    "debramasztijelenet3moz11"
    pause 0.1
    "debramasztijelenet3moz12"
    pause 0.1
    "debramasztijelenet3moz13"
    pause 0.1
    repeat
image debramasztijelenet3animatall:
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz7"
    pause 0.1
    "debramasztijelenet3moz6"
    pause 0.1
    "debramasztijelenet3moz5"
    pause 0.1
    "debramasztijelenet3moz4"
    pause 0.1
    "debramasztijelenet3moz3"
    pause 0.1
    "debramasztijelenet3moz2"
    pause 0.1
    "debramasztijelenet3moz1"
    pause 0.1
    "debramasztijelenet3moz8"
    pause 0.1
    "debramasztijelenet3moz9"
    pause 0.1
    "debramasztijelenet3moz10"
    pause 0.1
    "debramasztijelenet3moz11"
    pause 0.1
    "debramasztijelenet3moz12"
    pause 0.1
    "debramasztijelenet3moz13"
    pause 0.1
    repeat
image debramasztijelenet3remeg:
    "debramasztijelenet3remeg1"
    pause 0.1
    "debramasztijelenet3remeg2"
    pause 0.1
    repeat
image debramasztijelenet3nyalkaanim:
    "debramasztijelenet3nyalka1"
    pause 0.1
    "debramasztijelenet3nyalka2"
    pause 0.1
    "debramasztijelenet3nyalka3"
    pause 0.1
    "debramasztijelenet3nyalka4"
    pause 0.1
    "debramasztijelenet3nyalka5"
    pause 0.1
    "debramasztijelenet3nyalka6"
    pause 0.1
    "debramasztijelenet3nyalka7"
    pause 0.1
    "debramasztijelenet3nyalka8"
    pause 0.1
    "debramasztijelenet3nyalka9"
    pause 0.1
    "debramasztijelenet3nyalka10"
    pause 0.1
image debramasztijelenet3nyalkaanim2:
    "debramasztijelenet3nyalka9"
    pause 0.1
    "debramasztijelenet3nyalka10"
    pause 0.1
    repeat
image debramasztijelenet4nyalkaanim:
    "debramasztijelenet4nyalka-1"
    pause 0.084
    "debramasztijelenet4nyalka-2"
    pause 0.084
    "debramasztijelenet4nyalka-3"
    pause 0.084
    "debramasztijelenet4nyalka-4"
    pause 0.084
    "debramasztijelenet4nyalka-5"
    pause 0.084
    "debramasztijelenet4nyalka-6"
    pause 0.084
    "debramasztijelenet4nyalka-7"
    pause 0.084
image debramasztijelenet4szemanim:
    "debramasztijelenet4szem1"
    pause 3.125
    "debramasztijelenet4szem2"
    pause 0.125
    "debramasztijelenet4szem3"
    pause 0.125
    "debramasztijelenet4szem2"
    pause 0.125
    repeat
image debramasztijelenet4szajanim:
    "debramasztijelenet4szaj1"
    pause 0.16
    "debramasztijelenet4szaj5"
    pause 0.16
    "debramasztijelenet4szaj3"
    pause 0.16
    "debramasztijelenet4szaj4"
    pause 0.16
    "debramasztijelenet4szaj2"
    pause 0.16
    "debramasztijelenet4szaj5"
    pause 0.16
    "debramasztijelenet4szaj4"
    pause 0.16
    "debramasztijelenet4szaj1"
    pause 0.16
    "debramasztijelenet4szaj2"
    pause 0.16
    "debramasztijelenet4szaj3"
    pause 0.16
    "debramasztijelenet4szaj5"
    pause 0.16
    "debramasztijelenet4szaj4"
    pause 0.16
    repeat
image debraalvajar10resza9anim:
    "debraalvajar10resza9v1"
    pause 0.1
    "debraalvajar10resza9v2"
    pause 0.1
    "debraalvajar10resza9v3"
    pause 0.1
    "debraalvajar10resza9v4"
    pause 0.1
image debraalvajar10resza6faszanim:
    "debraalvajar10resza6faszmoz1"
    pause 0.111
    "debraalvajar10resza6faszmoz2"
    pause 0.111
    "debraalvajar10resza6faszmoz3"
    pause 0.111
    "debraalvajar10resza6faszmoz4"
    pause 0.111
    "debraalvajar10resza6faszmoz5"
    pause 0.111
    "debraalvajar10resza6faszmoz6"
    pause 0.111
    "debraalvajar10resza6faszmoz7"
    pause 0.111
    "debraalvajar10resza6faszmoz8"
    pause 0.111
    "debraalvajar10resza6faszmoz1"
    pause 0.111
    "debraalvajar10resza6faszmoz2"
    pause 0.111
    "debraalvajar10resza6faszmoz3"
    pause 0.111
    "debraalvajar10resza6faszmoz4"
    pause 0.111
    "debraalvajar10resza6faszmoz5"
    pause 0.111
    "debraalvajar10resza6faszmoz6"
    pause 0.111
    "debraalvajar10resza6faszmoz7"
    pause 0.111
    "debraalvajar10resza6faszmoz8"
    pause 0.111
    "debraalvajar10resza6faszmoz1"
    pause 0.111
    "debraalvajar10resza6faszmoz2"
    pause 0.111
    "debraalvajar10resza6faszmoz3"
    pause 0.111
    "debraalvajar10resza6faszmoz4"
    pause 0.111
    "debraalvajar10resza6faszmoz5"
    pause 0.111
    "debraalvajar10resza6faszmoz6"
    pause 0.111
    "debraalvajar10resza6faszmoz7"
    pause 0.111
    "debraalvajar10resza6faszmoz8"
    pause 0.111
    "debraalvajar10resza6faszmoz1"
    pause 0.111
    "debraalvajar10resza6faszmoz2"
    pause 0.111
    "debraalvajar10resza6faszmoz3"
    pause 0.111
    "debraalvajar10resza6faszmoz4"
    pause 0.111
    "debraalvajar10resza6faszmoz5"
    pause 0.111
    "debraalvajar10resza6faszmoz6"
    pause 0.111
    "debraalvajar10resza6faszmoz7"
    pause 0.111
    "debraalvajar10resza6faszmoz8"
    pause 0.111
    "debraalvajar10resza6faszmoz1"
    pause 0.111
    "debraalvajar10resza6faszmoz2"
    pause 0.111
    "debraalvajar10resza6faszmoz3"
    pause 0.111
    "debraalvajar10resza6faszmoz4"
    pause 0.111
    "debraalvajar10resza6faszmoz5"
    pause 0.111
    "debraalvajar10resza6faszmoz6"
    pause 0.111
    "debraalvajar10resza6faszmoz7"
    pause 0.111
    "debraalvajar10resza6faszmoz8"
    pause 0.111
    "debraalvajar10resza6faszmoz1"
    pause 0.111
    "debraalvajar10resza6faszmoz2"
    pause 0.111
    "debraalvajar10resza6faszmoz3"
    pause 0.111
    "debraalvajar10resza6faszmoz4"
    pause 0.111
    "debraalvajar10resza6faszmoz5"
    pause 0.111
    "debraalvajar10resza6faszmoz6"
    pause 0.111
    "debraalvajar10resza6faszmoz7"
    pause 0.111
    "debraalvajar10resza6faszmoz8"
    pause 0.111
    "debraalvajar10resza6faszmoz1"
    pause 0.111
    "debraalvajar10resza6faszmoz2"
    pause 0.111
    "debraalvajar10resza6faszmoz3"
    pause 0.111
    "debraalvajar10resza6faszmoz4"
    pause 0.111
    "debraalvajar10resza6faszmoz5"
    pause 0.111
    "debraalvajar10resza6faszmoz6"
    pause 0.111
    "debraalvajar10resza6faszmoz7"
    pause 0.1
    "debraalvajar10resza6faszmoz8"
    pause 0.1
    "debraalvajar10resza6faszmoz1"
    pause 0.1
    "debraalvajar10resza6faszmoz2"
    pause 0.1
    "debraalvajar10resza6faszmoz3"
    pause 0.1
    "debraalvajar10resza6faszmoz4"
    pause 0.1
    "debraalvajar10resza6faszmoz5"
    pause 0.1
    "debraalvajar10resza6faszmoz6"
    pause 0.1
    "debraalvajar10resza6faszmoz7"
    pause 0.1
    "debraalvajar10resza6faszmoz8"
    pause 0.1
    "debraalvajar10resza6faszmoz1"
    pause 0.1
    "debraalvajar10resza6faszmoz2"
    pause 0.1
    "debraalvajar10resza6faszmoz3"
    pause 0.1
    "debraalvajar10resza6faszmoz4"
    pause 0.1
    "debraalvajar10resza6faszmoz5"
    pause 0.1
    "debraalvajar10resza6faszmoz6"
    pause 0.1
    "debraalvajar10resza6faszmoz7"
    pause 0.1
    "debraalvajar10resza6faszmoz8"
    pause 0.1
    "debraalvajar10resza6faszmoz1"
    pause 0.1
    "debraalvajar10resza6faszmoz2"
    pause 0.1
    "debraalvajar10resza6faszmoz3"
    pause 0.1
    "debraalvajar10resza6faszmoz4"
    pause 0.1
    "debraalvajar10resza6faszmoz5"
    pause 0.1
    "debraalvajar10resza6faszmoz6"
    pause 0.1
    "debraalvajar10resza6faszmoz7"
    pause 0.1
    "debraalvajar10resza6faszmoz8"
    pause 0.1
    "debraalvajar10resza6faszmoz1"
    pause 0.1
    "debraalvajar10resza6faszmoz2"
    pause 0.1
    "debraalvajar10resza6faszmoz3"
    pause 0.1
    "debraalvajar10resza6faszmoz4"
    pause 0.1
    "debraalvajar10resza6faszmoz5"
    pause 0.1
    "debraalvajar10resza6faszmoz6"
    pause 0.1
    "debraalvajar10resza6faszmoz7"
    pause 0.1
    "debraalvajar10resza6faszmoz8"
    pause 0.1
    "debraalvajar10resza6faszmoz1"
    pause 0.1
    "debraalvajar10resza6faszmoz2"
    pause 0.1
    "debraalvajar10resza6faszmoz3"
    pause 0.1
    "debraalvajar10resza6faszmoz4"
    pause 0.1
    "debraalvajar10resza6faszmoz5"
    pause 0.1
    "debraalvajar10resza6faszmoz6"
    pause 0.1
    "debraalvajar10resza6faszmoz7"
    pause 0.1
    "debraalvajar10resza6faszmoz8"
    pause 0.1
    repeat
image debraalvajar10resza6animfel:
    "debraalvajar10resza6moz1"
    pause 0.1
    "debraalvajar10resza6moz2"
    pause 0.1
    "debraalvajar10resza6moz3"
    pause 0.1
image debraalvajar10resza6animle:
    "debraalvajar10resza6moz3"
    pause 0.1
    "debraalvajar10resza6moz2"
    pause 0.1
    "debraalvajar10resza6moz1"
    pause 0.1
image debraalvajar10resza6moz1szajanim:
    "debraalvajar10resza6moz1szaj1"
    pause 0.16
    "debraalvajar10resza6moz1szaj5"
    pause 0.16
    "debraalvajar10resza6moz1szaj3"
    pause 0.16
    "debraalvajar10resza6moz1szaj4"
    pause 0.16
    "debraalvajar10resza6moz1szaj2"
    pause 0.16
    "debraalvajar10resza6moz1szaj5"
    pause 0.16
    "debraalvajar10resza6moz1szaj4"
    pause 0.16
    "debraalvajar10resza6moz1szaj1"
    pause 0.16
    "debraalvajar10resza6moz1szaj2"
    pause 0.16
    "debraalvajar10resza6moz1szaj3"
    pause 0.16
    "debraalvajar10resza6moz1szaj5"
    pause 0.16
    "debraalvajar10resza6moz1szaj4"
    pause 0.16
    repeat
image debraalvajar10resza6moz3szajanim:
    "debraalvajar10resza6moz3szaj1"
    pause 0.16
    "debraalvajar10resza6moz3szaj5"
    pause 0.16
    "debraalvajar10resza6moz3szaj3"
    pause 0.16
    "debraalvajar10resza6moz3szaj4"
    pause 0.16
    "debraalvajar10resza6moz3szaj2"
    pause 0.16
    "debraalvajar10resza6moz3szaj5"
    pause 0.16
    "debraalvajar10resza6moz3szaj4"
    pause 0.16
    "debraalvajar10resza6moz3szaj1"
    pause 0.16
    "debraalvajar10resza6moz3szaj2"
    pause 0.16
    "debraalvajar10resza6moz3szaj3"
    pause 0.16
    "debraalvajar10resza6moz3szaj5"
    pause 0.16
    "debraalvajar10resza6moz3szaj4"
    pause 0.16
    repeat
image debraalvajar10resza8moz3szemanim:
    "debraalvajar10resza8moz3szem1"
    pause 0.125
    "debraalvajar10resza8moz3szem2"
    pause 0.125
    "debraalvajar10resza8moz3szem3"
    pause 0.125
    "debraalvajar10resza8moz3szem4"
    pause 0.125
image debraalvajar10resza8animle:
    "debraalvajar10resza8moz1"
    pause 0.1
    "debraalvajar10resza8moz2"
    pause 0.1
    "debraalvajar10resza8moz3"
    pause 0.1
image debraagyonbeszel1szajanim:
    "debraagyonbeszel1szaj1"
    pause 0.16
    "debraagyonbeszel1szaj5"
    pause 0.16
    "debraagyonbeszel1szaj3"
    pause 0.16
    "debraagyonbeszel1szaj4"
    pause 0.16
    "debraagyonbeszel1szaj2"
    pause 0.16
    "debraagyonbeszel1szaj5"
    pause 0.16
    "debraagyonbeszel1szaj4"
    pause 0.16
    "debraagyonbeszel1szaj1"
    pause 0.16
    "debraagyonbeszel1szaj2"
    pause 0.16
    "debraagyonbeszel1szaj3"
    pause 0.16
    "debraagyonbeszel1szaj5"
    pause 0.16
    "debraagyonbeszel1szaj4"
    pause 0.16
    repeat
image debraagyonbeszel3szajanim:
    "debraagyonbeszel3szaj1"
    pause 0.16
    "debraagyonbeszel3szaj5"
    pause 0.16
    "debraagyonbeszel3szaj3"
    pause 0.16
    "debraagyonbeszel3szaj4"
    pause 0.16
    "debraagyonbeszel3szaj2"
    pause 0.16
    "debraagyonbeszel3szaj5"
    pause 0.16
    "debraagyonbeszel3szaj4"
    pause 0.16
    "debraagyonbeszel3szaj1"
    pause 0.16
    "debraagyonbeszel3szaj2"
    pause 0.16
    "debraagyonbeszel3szaj3"
    pause 0.16
    "debraagyonbeszel3szaj5"
    pause 0.16
    "debraagyonbeszel3szaj4"
    pause 0.16
    repeat
image debraagyonbeszelmozfel:
    "debraagyonbeszelmoz1"
    pause 0.1
    "debraagyonbeszelmoz2"
    pause 0.1
    "debraagyonbeszelmoz3"
    pause 0.1
image debraagyonbeszelmozle:
    "debraagyonbeszelmoz3"
    pause 0.1
    "debraagyonbeszelmoz2"
    pause 0.1
    "debraagyonbeszelmoz1"
    pause 0.1
image debrakosztumbenanimfel:
    "debrakosztumbenmoz1"
    pause 0.1
    "debrakosztumbenmoz2"
    pause 0.1
    "debrakosztumbenmoz3"
    pause 0.1
    "debrakosztumbenmoz4"
    pause 0.1
    "debrakosztumbenmoz5"
    pause 0.1
image debrakosztumbenanimle:
    "debrakosztumbenmoz5"
    pause 0.1
    "debrakosztumbenmoz4"
    pause 0.1
    "debrakosztumbenmoz3"
    pause 0.1
    "debrakosztumbenmoz2"
    pause 0.1
    "debrakosztumbenmoz1"
    pause 0.1
image debrakosztumbenmoz1pislog:
    "debrakosztumbenmoz1szem1"
    pause 3.5
    "debrakosztumbenmoz1szem2"
    pause 0.125
    "debrakosztumbenmoz1szem3"
    pause 0.125
    "debrakosztumbenmoz1szem2"
    pause 0.125
    repeat
image debrakosztumbenmoz1beszed:
    "debrakosztumbenmoz1szaj1"
    pause 0.16
    "debrakosztumbenmoz1szaj3"
    pause 0.16
    "debrakosztumbenmoz1szaj2"
    pause 0.16
    "debrakosztumbenmoz1szaj4"
    pause 0.16
    "debrakosztumbenmoz1szaj5"
    pause 0.16
    "debrakosztumbenmoz1szaj2"
    pause 0.16
    "debrakosztumbenmoz1szaj3"
    pause 0.16
    "debrakosztumbenmoz1szaj4"
    pause 0.16
    "debrakosztumbenmoz1szaj1"
    pause 0.16
    "debrakosztumbenmoz1szaj5"
    pause 0.16
    "debrakosztumbenmoz1szaj3"
    pause 0.16
    "debrakosztumbenmoz1szaj5"
    pause 0.16
    "debrakosztumbenmoz1szaj4"
    pause 0.16
    "debrakosztumbenmoz1szaj2"
    pause 0.16
    "debrakosztumbenmoz1szaj3"
    pause 0.16
    repeat
image debrakosztumbenmoz5beszed:
    "debrakosztumbenmoz5szaj1"
    pause 0.16
    "debrakosztumbenmoz5szaj3"
    pause 0.16
    "debrakosztumbenmoz5szaj2"
    pause 0.16
    "debrakosztumbenmoz5szaj4"
    pause 0.16
    "debrakosztumbenmoz5szaj5"
    pause 0.16
    "debrakosztumbenmoz5szaj2"
    pause 0.16
    "debrakosztumbenmoz5szaj3"
    pause 0.16
    "debrakosztumbenmoz5szaj4"
    pause 0.16
    "debrakosztumbenmoz5szaj1"
    pause 0.16
    "debrakosztumbenmoz5szaj5"
    pause 0.16
    "debrakosztumbenmoz5szaj3"
    pause 0.16
    "debrakosztumbenmoz5szaj5"
    pause 0.16
    "debrakosztumbenmoz5szaj4"
    pause 0.16
    "debrakosztumbenmoz5szaj2"
    pause 0.16
    "debrakosztumbenmoz5szaj3"
    pause 0.16
    repeat
image debracicibaszi11napjelenet3anim:
    "debracicibaszi11napjelenet3moz1"
    pause 0.16
    "debracicibaszi11napjelenet3moz2"
    pause 0.16
    "debracicibaszi11napjelenet3moz3"
    pause 0.16
    "debracicibaszi11napjelenet3moz4"
    pause 0.16
    "debracicibaszi11napjelenet3moz5"
    pause 0.16
    "debracicibaszi11napjelenet3moz4"
    pause 0.16
    "debracicibaszi11napjelenet3moz3"
    pause 0.16
    "debracicibaszi11napjelenet3moz2"
    pause 0.16
    "debracicibaszi11napjelenet3moz1"
    pause 0.16
    "debracicibaszi11napjelenet3moz2"
    pause 0.16
    "debracicibaszi11napjelenet3moz3"
    pause 0.16
    "debracicibaszi11napjelenet3moz4"
    pause 0.16
    "debracicibaszi11napjelenet3moz5"
    pause 0.16
    "debracicibaszi11napjelenet3moz4"
    pause 0.16
    "debracicibaszi11napjelenet3moz3"
    pause 0.16
    "debracicibaszi11napjelenet3moz2"
    pause 0.16
    "debracicibaszi11napjelenet3moz1"
    pause 0.16
    "debracicibaszi11napjelenet3moz2"
    pause 0.16
    "debracicibaszi11napjelenet3moz3"
    pause 0.16
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz5"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz1"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz5"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz1"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz5"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz1"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz5"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz1"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz5"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz1"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz5"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz1"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz5"
    pause 0.125
    "debracicibaszi11napjelenet3moz4"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz1"
    pause 0.125
    "debracicibaszi11napjelenet3moz2"
    pause 0.125
    "debracicibaszi11napjelenet3moz3"
    pause 0.16
    "debracicibaszi11napjelenet3moz4"
    pause 0.16
    "debracicibaszi11napjelenet3moz5"
    pause 0.16
    "debracicibaszi11napjelenet3moz4"
    pause 0.16
    "debracicibaszi11napjelenet3moz3"
    pause 0.16
    "debracicibaszi11napjelenet3moz2"
    pause 0.16
    repeat
image debracicibaszi11napjelenet3szajanim:
    "debracicibaszi11napjelenet3szaj1"
    pause 0.16
    "debracicibaszi11napjelenet3szaj3"
    pause 0.16
    "debracicibaszi11napjelenet3szaj2"
    pause 0.16
    "debracicibaszi11napjelenet3szaj4"
    pause 0.16
    "debracicibaszi11napjelenet3szaj5"
    pause 0.16
    "debracicibaszi11napjelenet3szaj2"
    pause 0.16
    "debracicibaszi11napjelenet3szaj3"
    pause 0.16
    "debracicibaszi11napjelenet3szaj4"
    pause 0.16
    "debracicibaszi11napjelenet3szaj1"
    pause 0.16
    "debracicibaszi11napjelenet3szaj5"
    pause 0.16
    "debracicibaszi11napjelenet3szaj3"
    pause 0.16
    "debracicibaszi11napjelenet3szaj5"
    pause 0.16
    "debracicibaszi11napjelenet3szaj4"
    pause 0.16
    "debracicibaszi11napjelenet3szaj2"
    pause 0.16
    "debracicibaszi11napjelenet3szaj3"
    pause 0.16
    repeat
image debracicibaszi11napjelenet3szemanim:
    "debracicibaszi11napjelenet3szem1"
    pause 3.5
    "debracicibaszi11napjelenet3szem2"
    pause 0.125
    "debracicibaszi11napjelenet3szem3"
    pause 0.125
    "debracicibaszi11napjelenet3szem2"
    pause 0.125
    repeat
image debracicibaszi11napjelenet4anim:
    "debracicibaszi11napjelenet4moz1"
    pause 0.16
    "debracicibaszi11napjelenet4moz2"
    pause 0.16
    "debracicibaszi11napjelenet4moz3"
    pause 0.16
    "debracicibaszi11napjelenet4moz4"
    pause 0.16
    "debracicibaszi11napjelenet4moz5"
    pause 0.16
    "debracicibaszi11napjelenet4moz6"
    pause 0.16
    "debracicibaszi11napjelenet4moz1"
    pause 0.16
    "debracicibaszi11napjelenet4moz2"
    pause 0.16
    "debracicibaszi11napjelenet4moz3"
    pause 0.16
    "debracicibaszi11napjelenet4moz4"
    pause 0.16
    "debracicibaszi11napjelenet4moz5"
    pause 0.16
    "debracicibaszi11napjelenet4moz6"
    pause 0.16
    "debracicibaszi11napjelenet4moz1"
    pause 0.16
    "debracicibaszi11napjelenet4moz2"
    pause 0.16
    "debracicibaszi11napjelenet4moz3"
    pause 0.16
    "debracicibaszi11napjelenet4moz4"
    pause 0.16
    "debracicibaszi11napjelenet4moz5"
    pause 0.16
    "debracicibaszi11napjelenet4moz6"
    pause 0.16
    "debracicibaszi11napjelenet4moz1"
    pause 0.16
    "debracicibaszi11napjelenet4moz2"
    pause 0.16
    "debracicibaszi11napjelenet4moz3"
    pause 0.16
    "debracicibaszi11napjelenet4moz4"
    pause 0.16
    "debracicibaszi11napjelenet4moz5"
    pause 0.16
    "debracicibaszi11napjelenet4moz6"
    pause 0.16
    "debracicibaszi11napjelenet4moz1"
    pause 0.16
    "debracicibaszi11napjelenet4moz2"
    pause 0.125
    "debracicibaszi11napjelenet4moz3"
    pause 0.125
    "debracicibaszi11napjelenet4moz4"
    pause 0.125
    "debracicibaszi11napjelenet4moz5"
    pause 0.125
    "debracicibaszi11napjelenet4moz6"
    pause 0.125
    "debracicibaszi11napjelenet4moz1"
    pause 0.125
    "debracicibaszi11napjelenet4moz2"
    pause 0.125
    "debracicibaszi11napjelenet4moz3"
    pause 0.125
    "debracicibaszi11napjelenet4moz4"
    pause 0.125
    "debracicibaszi11napjelenet4moz5"
    pause 0.125
    "debracicibaszi11napjelenet4moz6"
    pause 0.125
    "debracicibaszi11napjelenet4moz1"
    pause 0.125
    "debracicibaszi11napjelenet4moz2"
    pause 0.125
    "debracicibaszi11napjelenet4moz3"
    pause 0.125
    "debracicibaszi11napjelenet4moz4"
    pause 0.125
    "debracicibaszi11napjelenet4moz5"
    pause 0.125
    "debracicibaszi11napjelenet4moz6"
    pause 0.125
    "debracicibaszi11napjelenet4moz1"
    pause 0.125
    "debracicibaszi11napjelenet4moz2"
    pause 0.125
    "debracicibaszi11napjelenet4moz3"
    pause 0.125
    "debracicibaszi11napjelenet4moz4"
    pause 0.125
    "debracicibaszi11napjelenet4moz5"
    pause 0.125
    "debracicibaszi11napjelenet4moz6"
    pause 0.125
    "debracicibaszi11napjelenet4moz1"
    pause 0.125
    "debracicibaszi11napjelenet4moz2"
    pause 0.125
    "debracicibaszi11napjelenet4moz3"
    pause 0.125
    "debracicibaszi11napjelenet4moz4"
    pause 0.125
    "debracicibaszi11napjelenet4moz5"
    pause 0.125
    "debracicibaszi11napjelenet4moz6"
    pause 0.125
    "debracicibaszi11napjelenet4moz1"
    pause 0.125
    "debracicibaszi11napjelenet4moz2"
    pause 0.125
    "debracicibaszi11napjelenet4moz3"
    pause 0.16
    "debracicibaszi11napjelenet4moz4"
    pause 0.16
    "debracicibaszi11napjelenet4moz5"
    pause 0.16
    "debracicibaszi11napjelenet4moz6"
    pause 0.16
    "debracicibaszi11napjelenet4moz1"
    pause 0.16
    "debracicibaszi11napjelenet4moz2"
    pause 0.16
    "debracicibaszi11napjelenet4moz3"
    pause 0.16
    "debracicibaszi11napjelenet4moz4"
    pause 0.16
    "debracicibaszi11napjelenet4moz5"
    pause 0.16
    "debracicibaszi11napjelenet4moz6"
    pause 0.16
    "debracicibaszi11napjelenet4moz1"
    pause 0.16
    "debracicibaszi11napjelenet4moz2"
    pause 0.16
    "debracicibaszi11napjelenet4moz3"
    pause 0.16
    "debracicibaszi11napjelenet4moz4"
    pause 0.16
    "debracicibaszi11napjelenet4moz5"
    pause 0.16
    "debracicibaszi11napjelenet4moz6"
    pause 0.16
    "debracicibaszi11napjelenet4moz1"
    pause 0.16
    "debracicibaszi11napjelenet4moz2"
    pause 0.16
    "debracicibaszi11napjelenet4moz3"
    pause 0.16
    "debracicibaszi11napjelenet4moz4"
    pause 0.16
    "debracicibaszi11napjelenet4moz5"
    pause 0.16
    "debracicibaszi11napjelenet4moz6"
    pause 0.16
    repeat
image debracicibaszi11napjelenet5anim:
    "debracicibaszi11napjelenet5moz1"
    pause 0.125
    "debracicibaszi11napjelenet5moz2"
    pause 0.125
    "debracicibaszi11napjelenet5moz3"
    pause 0.125
    "debracicibaszi11napjelenet5moz4"
    pause 0.125
    "debracicibaszi11napjelenet5moz5"
    pause 0.125
    "debracicibaszi11napjelenet5moz6"
    pause 0.125
    "debracicibaszi11napjelenet5moz1"
    pause 0.125
    "debracicibaszi11napjelenet5moz2"
    pause 0.125
    "debracicibaszi11napjelenet5moz3"
    pause 0.125
    "debracicibaszi11napjelenet5moz4"
    pause 0.125
    "debracicibaszi11napjelenet5moz5"
    pause 0.125
    "debracicibaszi11napjelenet5moz6"
    pause 0.125
    "debracicibaszi11napjelenet5moz1"
    pause 0.125
    "debracicibaszi11napjelenet5moz2"
    pause 0.125
    "debracicibaszi11napjelenet5moz3"
    pause 0.125
    "debracicibaszi11napjelenet5moz4"
    pause 0.125
    "debracicibaszi11napjelenet5moz5"
    pause 0.125
    "debracicibaszi11napjelenet5moz6"
    pause 0.125
    "debracicibaszi11napjelenet5moz1"
    pause 0.125
    "debracicibaszi11napjelenet5moz2"
    pause 0.125
    "debracicibaszi11napjelenet5moz3"
    pause 0.125
    "debracicibaszi11napjelenet5moz4"
    pause 0.125
    "debracicibaszi11napjelenet5moz5"
    pause 0.125
    "debracicibaszi11napjelenet5moz6"
    pause 0.125
    "debracicibaszi11napjelenet5moz1"
    pause 0.125
    "debracicibaszi11napjelenet5moz2"
    pause 0.125
    "debracicibaszi11napjelenet5moz3"
    pause 0.125
    "debracicibaszi11napjelenet5moz4"
    pause 0.125
    "debracicibaszi11napjelenet5moz5"
    pause 0.125
    "debracicibaszi11napjelenet5moz6"
    pause 0.125
    "debracicibaszi11napjelenet5moz1"
    pause 0.125
    "debracicibaszi11napjelenet5moz2"
    pause 0.1
    "debracicibaszi11napjelenet5moz3"
    pause 0.1
    "debracicibaszi11napjelenet5moz4"
    pause 0.1
    "debracicibaszi11napjelenet5moz5"
    pause 0.1
    "debracicibaszi11napjelenet5moz6"
    pause 0.1
    "debracicibaszi11napjelenet5moz1"
    pause 0.1
    "debracicibaszi11napjelenet5moz2"
    pause 0.1
    "debracicibaszi11napjelenet5moz3"
    pause 0.1
    "debracicibaszi11napjelenet5moz4"
    pause 0.1
    "debracicibaszi11napjelenet5moz5"
    pause 0.1
    "debracicibaszi11napjelenet5moz6"
    pause 0.1
    "debracicibaszi11napjelenet5moz1"
    pause 0.1
    "debracicibaszi11napjelenet5moz2"
    pause 0.1
    "debracicibaszi11napjelenet5moz3"
    pause 0.1
    "debracicibaszi11napjelenet5moz4"
    pause 0.1
    "debracicibaszi11napjelenet5moz5"
    pause 0.1
    "debracicibaszi11napjelenet5moz6"
    pause 0.1
    "debracicibaszi11napjelenet5moz1"
    pause 0.1
    "debracicibaszi11napjelenet5moz2"
    pause 0.1
    "debracicibaszi11napjelenet5moz3"
    pause 0.1
    "debracicibaszi11napjelenet5moz4"
    pause 0.1
    "debracicibaszi11napjelenet5moz5"
    pause 0.1
    "debracicibaszi11napjelenet5moz6"
    pause 0.1
    "debracicibaszi11napjelenet5moz1"
    pause 0.1
    "debracicibaszi11napjelenet5moz2"
    pause 0.1
    "debracicibaszi11napjelenet5moz3"
    pause 0.1
    "debracicibaszi11napjelenet5moz4"
    pause 0.1
    "debracicibaszi11napjelenet5moz5"
    pause 0.1
    "debracicibaszi11napjelenet5moz6"
    pause 0.1
    "debracicibaszi11napjelenet5moz1"
    pause 0.1
    "debracicibaszi11napjelenet5moz2"
    pause 0.1
    "debracicibaszi11napjelenet5moz3"
    pause 0.1
    "debracicibaszi11napjelenet5moz4"
    pause 0.1
    "debracicibaszi11napjelenet5moz5"
    pause 0.1
    "debracicibaszi11napjelenet5moz6"
    pause 0.1
    "debracicibaszi11napjelenet5moz1"
    pause 0.1
    "debracicibaszi11napjelenet5moz2"
    pause 0.1
    "debracicibaszi11napjelenet5moz3"
    pause 0.1
    "debracicibaszi11napjelenet5moz4"
    pause 0.1
    "debracicibaszi11napjelenet5moz5"
    pause 0.1
    "debracicibaszi11napjelenet5moz6"
    pause 0.1
    "debracicibaszi11napjelenet5moz1"
    pause 0.1
    "debracicibaszi11napjelenet5moz2"
    pause 0.1
    "debracicibaszi11napjelenet5moz3"
    pause 0.1
    "debracicibaszi11napjelenet5moz4"
    pause 0.1
    "debracicibaszi11napjelenet5moz5"
    pause 0.125
    "debracicibaszi11napjelenet5moz6"
    pause 0.125
    repeat
image debracicibaszi11napjelenet7anime:
    "debracicibaszi11napjelenet7moze1"
    pause 0.125
    "debracicibaszi11napjelenet7moze2"
    pause 0.125
    "debracicibaszi11napjelenet7moze3"
    pause 0.125
    "debracicibaszi11napjelenet7moze4"
    pause 0.125
    "debracicibaszi11napjelenet7moze5"
    pause 0.125
    "debracicibaszi11napjelenet7moze6"
    pause 0.125
    repeat
image debracicibaszi11napjelenet7anime2:
    "debracicibaszi11napjelenet7moze1"
    pause 0.1
    "debracicibaszi11napjelenet7moze2"
    pause 0.1
    "debracicibaszi11napjelenet7moze3"
    pause 0.1
    "debracicibaszi11napjelenet7moze4"
    pause 0.1
    "debracicibaszi11napjelenet7moze5"
    pause 0.1
    "debracicibaszi11napjelenet7moze6"
    pause 0.1
    repeat
image debracicibaszi11napjelenet7mozgyszemanim:
    "debracicibaszi11napjelenet7mozgyszem1"
    pause 3.5
    "debracicibaszi11napjelenet7mozgyszem2"
    pause 0.125
    "debracicibaszi11napjelenet7mozgyszem3"
    pause 0.125
    "debracicibaszi11napjelenet7mozgyszem2"
    pause 0.125
    repeat
image debracicibaszi11napjelenet7mozgyszajanim:
    "debracicibaszi11napjelenet7mozgyszaj1"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj3"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj2"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj4"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj2"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj3"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj4"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj1"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj3"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj4"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj2"
    pause 0.16
    "debracicibaszi11napjelenet7mozgyszaj3"
    pause 0.16
    repeat
image debracicibaszi11napjelenet7animgy:
    "debracicibaszi11napjelenet7mozgy1"
    pause 0.125
    "debracicibaszi11napjelenet7mozgy2"
    pause 0.125
    "debracicibaszi11napjelenet7mozgy3"
    pause 0.125
    "debracicibaszi11napjelenet7mozgy4"
    pause 0.125
    "debracicibaszi11napjelenet7mozgy5"
    pause 0.125
    "debracicibaszi11napjelenet7mozgy6"
    pause 0.125
    repeat
image debracicibaszi11napjelenet8anim:
    "debracicibaszi11napjelenet8moz1"
    pause 2.125
    "debracicibaszi11napjelenet8moz2"
    pause 0.125
    "debracicibaszi11napjelenet8moz3"
    pause 0.125
    "debracicibaszi11napjelenet8moz4"
    pause 0.125
    "debracicibaszi11napjelenet8moz5"
    pause 0.125
    "debracicibaszi11napjelenet8moz6"
    pause 0.125
    "debracicibaszi11napjelenet8moz7"
    pause 0.125
    "debracicibaszi11napjelenet8moz8"
    pause 0.125
    "debracicibaszi11napjelenet8moz9"
    pause 0.125
    "debracicibaszi11napjelenet8moz10"
    pause 0.125
    "debracicibaszi11napjelenet8moz11"
    pause 0.125
    "debracicibaszi11napjelenet8moz12"
    pause 0.125
    "debracicibaszi11napjelenet8moz13"
    pause 0.125
image debracicibaszi11napjelenet9anim:
    "debracicibaszi11napjelenet9moz1"
    pause 0.1
    "debracicibaszi11napjelenet9moz2"
    pause 0.1
    repeat
image debracicibaszi11napjelenet9szajanim:
    "debracicibaszi11napjelenet9szaj1"
    pause 0.16
    "debracicibaszi11napjelenet9szaj3"
    pause 0.16
    "debracicibaszi11napjelenet9szaj2"
    pause 0.16
    "debracicibaszi11napjelenet9szaj4"
    pause 0.16
    "debracicibaszi11napjelenet9szaj3"
    pause 0.16
    "debracicibaszi11napjelenet9szaj2"
    pause 0.16
    "debracicibaszi11napjelenet9szaj3"
    pause 0.16
    "debracicibaszi11napjelenet9szaj4"
    pause 0.16
    "debracicibaszi11napjelenet9szaj1"
    pause 0.16
    "debracicibaszi11napjelenet9szaj2"
    pause 0.16
    "debracicibaszi11napjelenet9szaj3"
    pause 0.16
    "debracicibaszi11napjelenet9szaj1"
    pause 0.16
    "debracicibaszi11napjelenet9szaj4"
    pause 0.16
    "debracicibaszi11napjelenet9szaj2"
    pause 0.16
    "debracicibaszi11napjelenet9szaj3"
    pause 0.16
    repeat
image hazalapdebrahatulrolbaszanim:
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.1
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz1"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz2"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz3"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz4"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz5"
    pause 0.125
    "hazalapdebrahatulrolbaszmoz6"
    pause 0.125
    repeat
image hazalapdebrahatulrolsimogatanim:
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz3"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz3"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz5"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz5"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz3"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz5"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz3"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz5"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz3"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz2"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz1"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz5"
    pause 0.17
    "hazalapdebrahatulrolsimogatmoz4"
    pause 0.17
    repeat
image debraszex12napjelenet4anim6:
    "debraszex12napjelenet4moz1"
    pause 0.17
    "debraszex12napjelenet4moz2"
    pause 0.17
    "debraszex12napjelenet4moz3"
    pause 0.17
    "debraszex12napjelenet4moz4"
    pause 0.17
    "debraszex12napjelenet4moz5"
    pause 0.17
    "debraszex12napjelenet4moz6"
    pause 0.17
    repeat
image debraszex12napjelenet4anim8:
    "debraszex12napjelenet4moz1"
    pause 0.125
    "debraszex12napjelenet4moz2"
    pause 0.125
    "debraszex12napjelenet4moz3"
    pause 0.125
    "debraszex12napjelenet4moz4"
    pause 0.125
    "debraszex12napjelenet4moz5"
    pause 0.125
    "debraszex12napjelenet4moz6"
    pause 0.125
    repeat
image debraszex12napjelenet4anim10:
    "debraszex12napjelenet4moz1"
    pause 0.1
    "debraszex12napjelenet4moz2"
    pause 0.1
    "debraszex12napjelenet4moz3"
    pause 0.1
    "debraszex12napjelenet4moz4"
    pause 0.1
    "debraszex12napjelenet4moz5"
    pause 0.1
    "debraszex12napjelenet4moz6"
    pause 0.1
    repeat
image debraszex12napjelenet6v1anim:
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 1.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 1.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 2.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 1.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 1.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 1.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.125
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.125

    repeat
image debraszex12napjelenet6v1animv2:
    "debraszex12napjelenet6v1moz1"
    pause 0.125
    "debraszex12napjelenet6v1moz2"
    pause 0.125
    "debraszex12napjelenet6v1moz3"
    pause 0.125
    "debraszex12napjelenet6v1moz4"
    pause 0.125
    "debraszex12napjelenet6v1moz5"
    pause 0.125
    "debraszex12napjelenet6v1moz6"
    pause 0.12
    repeat
image debraszex12napjelenet6v2anim6:
    "debraszex12napjelenet6v2moz1"
    pause 0.17
    "debraszex12napjelenet6v2moz2"
    pause 0.17
    "debraszex12napjelenet6v2moz3"
    pause 0.17
    "debraszex12napjelenet6v2moz4"
    pause 0.17
    "debraszex12napjelenet6v2moz5"
    pause 0.17
    "debraszex12napjelenet6v2moz6"
    pause 0.17
    "debraszex12napjelenet6v2moz7"
    pause 0.17
    repeat
image debraszex12napjelenet6v2anim8:
    "debraszex12napjelenet6v2moz1"
    pause 0.125
    "debraszex12napjelenet6v2moz2"
    pause 0.125
    "debraszex12napjelenet6v2moz3"
    pause 0.125
    "debraszex12napjelenet6v2moz4"
    pause 0.125
    "debraszex12napjelenet6v2moz5"
    pause 0.125
    "debraszex12napjelenet6v2moz6"
    pause 0.125
    "debraszex12napjelenet6v2moz7"
    pause 0.125
    repeat
image debraszex12napjelenet6v2anim8valt:
    "debraszex12napjelenet6v2moz1"
    pause 0.167
    "debraszex12napjelenet6v2moz2"
    pause 0.167
    "debraszex12napjelenet6v2moz3"
    pause 0.167
    "debraszex12napjelenet6v2moz4"
    pause 0.167
    "debraszex12napjelenet6v2moz5"
    pause 0.167
    "debraszex12napjelenet6v2moz6"
    pause 0.167
    "debraszex12napjelenet6v2moz7"
    pause 0.167
    "debraszex12napjelenet6v2moz1"
    pause 0.167
    "debraszex12napjelenet6v2moz2"
    pause 0.167
    "debraszex12napjelenet6v2moz3"
    pause 0.167
    "debraszex12napjelenet6v2moz4"
    pause 0.167
    "debraszex12napjelenet6v2moz5"
    pause 0.167
    "debraszex12napjelenet6v2moz6"
    pause 0.167
    "debraszex12napjelenet6v2moz7"
    pause 0.167
    "debraszex12napjelenet6v2moz1"
    pause 0.167
    "debraszex12napjelenet6v2moz2"
    pause 0.167
    "debraszex12napjelenet6v2moz3"
    pause 0.167
    "debraszex12napjelenet6v2moz4"
    pause 0.167
    "debraszex12napjelenet6v2moz5"
    pause 0.167
    "debraszex12napjelenet6v2moz6"
    pause 0.167
    "debraszex12napjelenet6v2moz7"
    pause 0.167
    "debraszex12napjelenet6v1moz1"
    pause 0.167
    "debraszex12napjelenet6v1moz2"
    pause 0.167
    "debraszex12napjelenet6v1moz3"
    pause 0.167
    "debraszex12napjelenet6v1moz4"
    pause 0.167
    "debraszex12napjelenet6v1moz5"
    pause 0.167
    "debraszex12napjelenet6v1moz6"
    pause 0.167
    "debraszex12napjelenet6v1moz1"
    pause 0.167
    "debraszex12napjelenet6v1moz2"
    pause 0.167
    "debraszex12napjelenet6v1moz3"
    pause 0.167
    "debraszex12napjelenet6v1moz4"
    pause 0.167
    "debraszex12napjelenet6v1moz5"
    pause 0.167
    "debraszex12napjelenet6v1moz6"
    pause 0.167
    repeat
image debraszex12napjelenet6v2anim8valt2:
    "debraszex12napjelenet6v2moz1"
    pause 0.143
    "debraszex12napjelenet6v2moz2"
    pause 0.143
    "debraszex12napjelenet6v2moz3"
    pause 0.143
    "debraszex12napjelenet6v2moz4"
    pause 0.143
    "debraszex12napjelenet6v2moz5"
    pause 0.143
    "debraszex12napjelenet6v2moz6"
    pause 0.143
    "debraszex12napjelenet6v2moz7"
    pause 0.143
    "debraszex12napjelenet6v2moz1"
    pause 0.143
    "debraszex12napjelenet6v2moz2"
    pause 0.143
    "debraszex12napjelenet6v2moz3"
    pause 0.143
    "debraszex12napjelenet6v2moz4"
    pause 0.143
    "debraszex12napjelenet6v2moz5"
    pause 0.143
    "debraszex12napjelenet6v2moz6"
    pause 0.143
    "debraszex12napjelenet6v2moz7"
    pause 0.143
    "debraszex12napjelenet6v2moz1"
    pause 0.143
    "debraszex12napjelenet6v2moz2"
    pause 0.143
    "debraszex12napjelenet6v2moz3"
    pause 0.143
    "debraszex12napjelenet6v2moz4"
    pause 0.143
    "debraszex12napjelenet6v2moz5"
    pause 0.143
    "debraszex12napjelenet6v2moz6"
    pause 0.143
    "debraszex12napjelenet6v2moz7"
    pause 0.143
    "debraszex12napjelenet6v1moz1"
    pause 0.143
    "debraszex12napjelenet6v1moz2"
    pause 0.143
    "debraszex12napjelenet6v1moz3"
    pause 0.143
    "debraszex12napjelenet6v1moz4"
    pause 0.143
    "debraszex12napjelenet6v1moz5"
    pause 0.143
    "debraszex12napjelenet6v1moz6"
    pause 0.143
    "debraszex12napjelenet6v1moz1"
    pause 0.143
    "debraszex12napjelenet6v1moz2"
    pause 0.143
    "debraszex12napjelenet6v1moz3"
    pause 0.143
    "debraszex12napjelenet6v1moz4"
    pause 0.143
    "debraszex12napjelenet6v1moz5"
    pause 0.143
    "debraszex12napjelenet6v1moz6"
    pause 0.143
    "debraszex12napjelenet6v1moz1"
    pause 0.143
    "debraszex12napjelenet6v1moz2"
    pause 0.143
    "debraszex12napjelenet6v1moz3"
    pause 0.143
    "debraszex12napjelenet6v1moz4"
    pause 0.143
    "debraszex12napjelenet6v1moz5"
    pause 0.143
    "debraszex12napjelenet6v1moz6"
    pause 0.143
    "debraszex12napjelenet6v1moz1"
    pause 0.143
    "debraszex12napjelenet6v1moz2"
    pause 0.143
    "debraszex12napjelenet6v1moz3"
    pause 0.143
    "debraszex12napjelenet6v1moz4"
    pause 0.143
    "debraszex12napjelenet6v1moz5"
    pause 0.143
    "debraszex12napjelenet6v1moz6"
    pause 0.143
    repeat
image debraszex12napjelenet6szemanim:
    "debraszex12napjelenet6szem1"
    pause 4.17
    "debraszex12napjelenet6szem2"
    pause 0.17
    "debraszex12napjelenet6szem3"
    pause 0.17
    "debraszex12napjelenet6szem2"
    pause 0.17
    repeat
image debraszex12napjelenet6szemanimbecsuk:
    "debraszex12napjelenet6szem1"
    pause 0.17
    "debraszex12napjelenet6szem2"
    pause 0.17
    "debraszex12napjelenet6szem3"
    pause 0.17
image debraszex12napjelenet6szemanimkinyit:
    "debraszex12napjelenet6szem3"
    pause 0.17
    "debraszex12napjelenet6szem2"
    pause 0.17
    "debraszex12napjelenet6szem1"
    pause 0.17
image debraszex12napjelenet6szajanim:
    "debraszex12napjelenet6szaj1"
    pause 0.16
    "debraszex12napjelenet6szaj3"
    pause 0.16
    "debraszex12napjelenet6szaj2"
    pause 0.16
    "debraszex12napjelenet6szaj4"
    pause 0.16
    "debraszex12napjelenet6szaj5"
    pause 0.16
    "debraszex12napjelenet6szaj1"
    pause 0.16
    "debraszex12napjelenet6szaj2"
    pause 0.16
    "debraszex12napjelenet6szaj4"
    pause 0.16
    "debraszex12napjelenet6szaj3"
    pause 0.16
    "debraszex12napjelenet6szaj5"
    pause 0.16
    "debraszex12napjelenet6szaj2"
    pause 0.16
    "debraszex12napjelenet6szaj3"
    pause 0.16
    "debraszex12napjelenet6szaj4"
    pause 0.16
    "debraszex12napjelenet6szaj5"
    pause 0.16
    "debraszex12napjelenet6szaj4"
    pause 0.16
    "debraszex12napjelenet6szaj2"
    pause 0.16
    repeat
image debraszex12napjelenet9anim6:
    "debraszex12napjelenet9moz1"
    pause 0.125
    "debraszex12napjelenet9moz2"
    pause 0.125
    "debraszex12napjelenet9moz3"
    pause 0.125
    "debraszex12napjelenet9moz4"
    pause 0.125
    "debraszex12napjelenet9moz5"
    pause 0.125
    "debraszex12napjelenet9moz6"
    pause 1.125
    "debraszex12napjelenet9moz7"
    pause 0.125
    "debraszex12napjelenet9moz8"
    pause 0.125
    "debraszex12napjelenet9moz9"
    pause 0.125
    "debraszex12napjelenet9moz10"
    pause 0.125
    "debraszex12napjelenet9moz11"
    pause 0.125
    "debraszex12napjelenet9moz12"
    pause 1.125
    "debraszex12napjelenet9moz1"
    pause 0.125
    "debraszex12napjelenet9moz2"
    pause 0.125
    "debraszex12napjelenet9moz3"
    pause 0.125
    "debraszex12napjelenet9moz4"
    pause 0.125
    "debraszex12napjelenet9moz5"
    pause 0.125
    "debraszex12napjelenet9moz6"
    pause 0.125
    "debraszex12napjelenet9moz7"
    pause 0.125
    "debraszex12napjelenet9moz8"
    pause 0.125
    "debraszex12napjelenet9moz9"
    pause 0.125
    "debraszex12napjelenet9moz10"
    pause 0.125
    "debraszex12napjelenet9moz11"
    pause 0.125
    "debraszex12napjelenet9moz12"
    pause 0.125
    "debraszex12napjelenet9moz1"
    pause 0.125
    "debraszex12napjelenet9moz2"
    pause 0.125
    "debraszex12napjelenet9moz3"
    pause 0.125
    "debraszex12napjelenet9moz4"
    pause 0.125
    "debraszex12napjelenet9moz5"
    pause 0.125
    "debraszex12napjelenet9moz6"
    pause 1.125
    "debraszex12napjelenet9moz7"
    pause 0.125
    "debraszex12napjelenet9moz8"
    pause 0.125
    "debraszex12napjelenet9moz9"
    pause 0.125
    "debraszex12napjelenet9moz10"
    pause 0.125
    "debraszex12napjelenet9moz11"
    pause 0.125
    "debraszex12napjelenet9moz12"
    pause 0.125
    "debraszex12napjelenet9moz1"
    pause 0.125
    "debraszex12napjelenet9moz2"
    pause 0.125
    "debraszex12napjelenet9moz3"
    pause 0.125
    "debraszex12napjelenet9moz4"
    pause 0.125
    "debraszex12napjelenet9moz5"
    pause 0.125
    "debraszex12napjelenet9moz6"
    pause 0.125
    "debraszex12napjelenet9moz7"
    pause 0.125
    "debraszex12napjelenet9moz8"
    pause 0.125
    "debraszex12napjelenet9moz9"
    pause 0.125
    "debraszex12napjelenet9moz10"
    pause 0.125
    "debraszex12napjelenet9moz11"
    pause 0.125
    "debraszex12napjelenet9moz12"
    pause 1.125
    repeat
image debraszex12napjelenet9anim8:
    "debraszex12napjelenet9moz1"
    pause 0.125
    "debraszex12napjelenet9moz2"
    pause 0.125
    "debraszex12napjelenet9moz3"
    pause 0.125
    "debraszex12napjelenet9moz4"
    pause 0.125
    "debraszex12napjelenet9moz5"
    pause 0.125
    "debraszex12napjelenet9moz6"
    pause 0.125
    "debraszex12napjelenet9moz7"
    pause 0.125
    "debraszex12napjelenet9moz8"
    pause 0.125
    "debraszex12napjelenet9moz9"
    pause 0.125
    "debraszex12napjelenet9moz10"
    pause 0.125
    "debraszex12napjelenet9moz11"
    pause 0.125
    "debraszex12napjelenet9moz12"
    pause 0.125
    repeat
image debraszex12napjelenet9anim10:
    "debraszex12napjelenet9moz1"
    pause 0.1
    "debraszex12napjelenet9moz2"
    pause 0.1
    "debraszex12napjelenet9moz3"
    pause 0.1
    "debraszex12napjelenet9moz4"
    pause 0.1
    "debraszex12napjelenet9moz5"
    pause 0.1
    "debraszex12napjelenet9moz6"
    pause 0.1
    "debraszex12napjelenet9moz7"
    pause 0.1
    "debraszex12napjelenet9moz8"
    pause 0.1
    "debraszex12napjelenet9moz9"
    pause 0.1
    "debraszex12napjelenet9moz10"
    pause 0.1
    "debraszex12napjelenet9moz11"
    pause 0.1
    "debraszex12napjelenet9moz12"
    pause 0.1
    repeat
image debraszex12napjelenet9szemanimkinyit:
    "debraszex12napjelenet9szem1"
    pause 0.17
    "debraszex12napjelenet9szem2"
    pause 0.17
    "debraszex12napjelenet9szem3"
    pause 0.17
image debraszex12napjelenet9szemanimbecsuk:
    "debraszex12napjelenet9szem3"
    pause 0.17
    "debraszex12napjelenet9szem2"
    pause 0.17
    "debraszex12napjelenet9szem1"
    pause 0.17
image debraszex12napjelenet9szemanim:
    "debraszex12napjelenet9szem3"
    pause 4.17
    "debraszex12napjelenet9szem2"
    pause 0.17
    "debraszex12napjelenet9szem1"
    pause 0.17
    "debraszex12napjelenet9szem2"
    pause 0.17
    repeat
image debraszex12napjelenet9szajbecsuk:
    "debraszex12napjelenet9szaj1"
    pause 0.17
    "debraszex12napjelenet9szaj2"
    pause 0.17
    "debraszex12napjelenet9szaj3"
    pause 0.17
image debraszex12napjelenet7mozanim:
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 1.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 1.125
    repeat
image debraszex12napjelenet7mozanimv2:
    "debraszex12napjelenet7moz1"
    pause 0.14
    "debraszex12napjelenet7moz2"
    pause 0.14
    "debraszex12napjelenet7moz3"
    pause 0.14
    "debraszex12napjelenet7moz4"
    pause 0.14
    "debraszex12napjelenet7moz5"
    pause 0.14
    "debraszex12napjelenet7moz6"
    pause 0.14
    "debraszex12napjelenet7moz1"
    pause 0.14
    "debraszex12napjelenet7moz2"
    pause 0.14
    "debraszex12napjelenet7moz3"
    pause 0.14
    "debraszex12napjelenet7moz4"
    pause 0.14
    "debraszex12napjelenet7moz5"
    pause 0.14
    "debraszex12napjelenet7moz6"
    pause 0.14
    "debraszex12napjelenet7moz1"
    pause 0.14
    "debraszex12napjelenet7moz2"
    pause 0.14
    "debraszex12napjelenet7moz3"
    pause 0.14
    "debraszex12napjelenet7moz4"
    pause 0.14
    "debraszex12napjelenet7moz5"
    pause 0.14
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.125
    "debraszex12napjelenet7moz2"
    pause 0.125
    "debraszex12napjelenet7moz3"
    pause 0.125
    "debraszex12napjelenet7moz4"
    pause 0.125
    "debraszex12napjelenet7moz5"
    pause 0.125
    "debraszex12napjelenet7moz6"
    pause 0.125
    "debraszex12napjelenet7moz1"
    pause 0.14
    "debraszex12napjelenet7moz2"
    pause 0.14
    "debraszex12napjelenet7moz3"
    pause 0.14
    "debraszex12napjelenet7moz4"
    pause 0.14
    "debraszex12napjelenet7moz5"
    pause 0.14
    "debraszex12napjelenet7moz6"
    pause 0.14
    repeat
image debraszex12napjelenet7mozanimv3:
    "debraszex12napjelenet7moz1"
    pause 0.1
    "debraszex12napjelenet7moz2"
    pause 0.1
    "debraszex12napjelenet7moz3"
    pause 0.1
    "debraszex12napjelenet7moz4"
    pause 0.1
    "debraszex12napjelenet7moz5"
    pause 0.1
    "debraszex12napjelenet7moz6"
    pause 0.1
    repeat
image debraszex12napjelenet8anim:
    "debraszex12napjelenet8v1"
    pause 0.1
    "debraszex12napjelenet8v2"
    pause 0.1
    repeat
image 12napfinalanim:
    "12napfinal-0001"
    pause 0.1
    "12napfinal-0002"
    pause 0.1
    "12napfinal-0003"
    pause 0.1
    "12napfinal-0004"
    pause 0.1
    "12napfinal-0005"
    pause 0.1
    "12napfinal-0006"
    pause 0.1
    "12napfinal-0007"
    pause 0.1
    "12napfinal-0008"
    pause 0.1
    "12napfinal-0009"
    pause 0.1
    "12napfinal-0010"
    pause 0.1
    "12napfinal-0011"
    pause 0.1
    "12napfinal-0012"
    pause 0.1
    "12napfinal-0013"
    pause 0.1
    "12napfinal-0014"
    pause 0.1
    "12napfinal-0015"
    pause 0.1
    "12napfinal-0016"
    pause 0.1
    "12napfinal-0017"
    pause 0.1
image debraszex12napjelenet12v1:
    "debraszex12napjelenet6v1moz1"
    pause 0.143
    "debraszex12napjelenet6v1moz2"
    pause 0.143
    "debraszex12napjelenet6v1moz3"
    pause 0.143
    "debraszex12napjelenet6v1moz4"
    pause 0.143
    "debraszex12napjelenet6v1moz5"
    pause 0.143
    "debraszex12napjelenet6v1moz6"
    pause 0.143
image debraszex12napjelenet12v2:
    "debraszex12napjelenet10v1"
    pause 0.143
    "debraszex12napjelenet10v2"
    pause 0.143
    "debraszex12napjelenet10v3"
    pause 0.143
    "debraszex12napjelenet10v4"
    pause 0.143
    "debraszex12napjelenet10v5"
    pause 0.143
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
