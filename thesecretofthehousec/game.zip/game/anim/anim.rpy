image bubi1anim:
    "bubisemmi"
    pause 0.16
    "bubi1anim1"
    pause 0.16
    "bubi1anim2"
    pause 0.16
    "bubi1anim3"
    pause 0.16
    "bubi1anim4"
    pause 0.16
    "bubi1anim5"
    pause 0.16
    "bubi1anim6"
    pause 0.16
    repeat
image bubi2anim:
    "bubisemmi"
    pause 1.16
    "bubi2anim1"
    pause 0.16
    "bubi2anim2"
    pause 0.16
    "bubi2anim3"
    pause 0.16
    "bubi2anim4"
    pause 0.16
    repeat
image bubi3anim:
    "bubisemmi"
    pause 0.56
    "bubi3anim1"
    pause 0.16
    "bubi3anim2"
    pause 0.16
    "bubi3anim3"
    pause 0.16
    "bubi3anim4"
    pause 0.16
    "bubi3anim5"
    pause 0.16
    "bubi3anim6"
    pause 0.16
    "bubi3anim7"
    pause 0.16
    "bubi3anim8"
    pause 0.16
    repeat
image kocsiparkolterkep:
    "terkepauto1"
image kocsimegy1terkep:
    "terkepauto1"
image kocsimegy2terkep:
    "terkepauto1"
image kocsimegy3terkep:
    "terkepauto1"
image kocsimegy4terkep:
    "terkepauto1"
image kocsimegy5terkep:
    "terkepauto2"
image kocsimegy6terkep:
    "terkepauto2"
image kocsimegy7terkep:
    "terkepauto2"
image feketefeher:
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
    pause 0.05
    "feher"
    pause 0.05
    "fekete"
image konyhatanyerszendvicskep2:
    "konyhatanyerszendvics2"
image konyhatanyerszendvicskep3:
    "konyhatanyerszendvics2"
image csovesfodo540cilanim:
    "csovesfodogyuru540csil1"
    pause 0.125
    "csovesfodogyuru540csil2"
    pause 0.125
    "csovesfodogyuru540csil3"
    pause 0.125
    "csovesfodogyuru540csil4"
    pause 0.125
    "csovesfodogyuru540csil5"
    pause 0.125
    "csovesfodogyuru540csil6"
    pause 0.125
    "csovesfodogyuru540csil1"
    pause 2.125
    repeat
image csovesfodobeszedgyurucsilanim:
    "csovesfodobeszedgyurucsil1"
    pause 0.125
    "csovesfodobeszedgyurucsil2"
    pause 0.125
    "csovesfodobeszedgyurucsil3"
    pause 0.125
    "csovesfodobeszedgyurucsil4"
    pause 0.125
    "csovesfodobeszedgyurucsil5"
    pause 0.125
    "csovesfodobeszedgyurucsil6"
    pause 0.125
    "csovesfodobeszedgyurucsil1"
    pause 2.125
    repeat
image stripbaranimsegseta:
    "seggsete1"
    pause 0.1
    "seggsete2"
    pause 0.1
    "seggsete3"
    pause 0.1
    "seggsete4"
    pause 0.6
    "seggsete5"
    pause 0.1
    "seggsete6"
    pause 0.1
    "seggsete7"
    pause 0.1
    "seggsete8"
    pause 0.1
    "seggsete9"
    pause 0.1
    "seggsete10"
    pause 0.1
    "seggsete11"
    pause 0.1
    "seggsete12"
    pause 0.1
    "seggsete13"
    pause 0.7
    "seggsete14"
    pause 0.1
    "seggsete15"
    pause 0.1
    "seggsete16"
    pause 0.1
    "seggsete17"
    pause 0.1
    "seggsete18"
    pause 0.1
    "seggsete19"
    pause 0.1
    "seggsete20"
    pause 0.1
    "seggsete21"
    pause 0.1
    "seggsete22"
    pause 0.1
    "seggsete23"
    pause 0.1
    "seggsete24"
    pause 0.1
    "seggsete25"
    pause 0.1
    "seggsete26"
    pause 0.1
    "seggsete27"
    pause 0.1
    "seggsete28"
    pause 0.1
    "seggsete1"
    pause 0.1
image csillogaskicsianim:
    "csillogaskicsi1"
    pause 0.125
    "csillogaskicsi2"
    pause 0.125
    "csillogaskicsi3"
    pause 0.125
    "csillogaskicsi4"
    pause 0.125
    "csillogaskicsi5"
    pause 0.125
    "csillogaskicsi6"
    pause 0.125
    "ruhaz"
    pause 4.125
    repeat
image kavejelalapfredk1kep1:
    "kavejelalapfredk11"
image kavejelalapfredk1kep2:
    "kavejelalapfredk11"
image pilango6reszanim:
    "pilango1"
    pause 2.1
    "pilango2"
    pause 0.1
    "pilango3"
    pause 0.1
    "pilango4"
    pause 0.1
    repeat
image pilangoszal6reszanim:
    "pilangoszal1"
    pause 3.1
    "pilangoszal2"
    pause 0.1
    "pilangoszal3"
    pause 0.1
    "pilangoszal4"
    pause 0.1
    "pilangoszal5"
    pause 0.1
    "pilangoszal6"
    pause 0.1
    "pilangoszal7"
    pause 0.1
    "pilangoszal8"
    pause 0.1
    "pilangoszal9"
    pause 0.1
    "pilangoszal10"
    pause 0.1
    "pilangoszal11"
    pause 0.1
    "pilangoszal12"
    pause 0.1
    "pilangoszal13"
    pause 0.1
    "pilangoszal14"
    pause 0.1
    "pilangoszal15"
    pause 0.1
    "pilangoszal16"
    pause 0.1
    "pilangoszal17"
    pause 0.1
    "pilangoszal18"
    pause 0.1
    "pilangoszal19"
    pause 0.1
    "pilangoszal20"
    pause 0.1
    repeat
image pilangoszal6reszanim2:
    "pilangoszal1"
    pause 2.7
    "pilangoszal2"
    pause 0.1
    "pilangoszal3"
    pause 0.1
    "pilangoszal4"
    pause 0.1
    "pilangoszal5"
    pause 0.1
    "pilangoszal6"
    pause 0.1
    "pilangoszal7"
    pause 0.1
    "pilangoszal8"
    pause 0.1
    "pilangoszal9"
    pause 0.1
    "pilangoszal10"
    pause 0.1
    "pilangoszal11"
    pause 0.1
    "pilangoszal12"
    pause 0.1
    "pilangoszal13"
    pause 0.1
    "pilangoszal14"
    pause 0.1
    "pilangoszal15"
    pause 0.1
    "pilangoszal16"
    pause 0.1
    "pilangoszal17"
    pause 0.1
    "pilangoszal18"
    pause 0.1
    "pilangoszal19"
    pause 0.1
    "pilangoszal20"
    pause 0.1
    repeat
image pilangoszal6reszanim3:
    "pilangoszal1"
    pause 4.6
    "pilangoszal2"
    pause 0.1
    "pilangoszal3"
    pause 0.1
    "pilangoszal4"
    pause 0.1
    "pilangoszal5"
    pause 0.1
    "pilangoszal6"
    pause 0.1
    "pilangoszal7"
    pause 0.1
    "pilangoszal8"
    pause 0.1
    "pilangoszal9"
    pause 0.1
    "pilangoszal10"
    pause 0.1
    "pilangoszal11"
    pause 0.1
    "pilangoszal12"
    pause 0.1
    "pilangoszal13"
    pause 0.1
    "pilangoszal14"
    pause 0.1
    "pilangoszal15"
    pause 0.1
    "pilangoszal16"
    pause 0.1
    "pilangoszal17"
    pause 0.1
    "pilangoszal18"
    pause 0.1
    "pilangoszal19"
    pause 0.1
    "pilangoszal20"
    pause 0.1
    repeat
image pilangoszal6reszanim4:
    "pilangoszal1"
    pause 1.5
    "pilangoszal2"
    pause 0.1
    "pilangoszal3"
    pause 0.1
    "pilangoszal4"
    pause 0.1
    "pilangoszal5"
    pause 0.1
    "pilangoszal6"
    pause 0.1
    "pilangoszal7"
    pause 0.1
    "pilangoszal8"
    pause 0.1
    "pilangoszal9"
    pause 0.1
    "pilangoszal10"
    pause 0.1
    "pilangoszal11"
    pause 0.1
    "pilangoszal12"
    pause 0.1
    "pilangoszal13"
    pause 0.1
    "pilangoszal14"
    pause 0.1
    "pilangoszal15"
    pause 0.1
    "pilangoszal16"
    pause 0.1
    "pilangoszal17"
    pause 0.1
    "pilangoszal18"
    pause 0.1
    "pilangoszal19"
    pause 0.1
    "pilangoszal20"
    pause 0.1
    repeat
image pilangoszal6reszanim5:
    "pilangoszal1"
    pause 2.1
    "pilangoszal2"
    pause 0.1
    "pilangoszal3"
    pause 0.1
    "pilangoszal4"
    pause 0.1
    "pilangoszal5"
    pause 0.1
    "pilangoszal6"
    pause 0.1
    "pilangoszal7"
    pause 0.1
    "pilangoszal8"
    pause 0.1
    "pilangoszal9"
    pause 0.1
    "pilangoszal10"
    pause 0.1
    "pilangoszal11"
    pause 0.1
    "pilangoszal12"
    pause 0.1
    "pilangoszal13"
    pause 0.1
    "pilangoszal14"
    pause 0.1
    "pilangoszal15"
    pause 0.1
    "pilangoszal16"
    pause 0.1
    "pilangoszal17"
    pause 0.1
    "pilangoszal18"
    pause 0.1
    "pilangoszal19"
    pause 0.1
    "pilangoszal20"
    pause 0.1
    repeat
image pilangoszal6reszanim6:
    "pilangoszal1"
    pause 3.2
    "pilangoszal2"
    pause 0.1
    "pilangoszal3"
    pause 0.1
    "pilangoszal4"
    pause 0.1
    "pilangoszal5"
    pause 0.1
    "pilangoszal6"
    pause 0.1
    "pilangoszal7"
    pause 0.1
    "pilangoszal8"
    pause 0.1
    "pilangoszal9"
    pause 0.1
    "pilangoszal10"
    pause 0.1
    "pilangoszal11"
    pause 0.1
    "pilangoszal12"
    pause 0.1
    "pilangoszal13"
    pause 0.1
    "pilangoszal14"
    pause 0.1
    "pilangoszal15"
    pause 0.1
    "pilangoszal16"
    pause 0.1
    "pilangoszal17"
    pause 0.1
    "pilangoszal18"
    pause 0.1
    "pilangoszal19"
    pause 0.1
    "pilangoszal20"
    pause 0.1
    repeat
image pilango6reszanim2:
    "pilango1"
    pause 3.1
    "pilango2"
    pause 0.1
    "pilango3"
    pause 0.1
    "pilango4"
    pause 0.1
    repeat
image pilango6reszanim3:
    "pilango1"
    pause 2.6
    "pilango2"
    pause 0.1
    "pilango3"
    pause 0.1
    "pilango4"
    pause 0.1
    repeat
image pilango6reszanim4:
    "pilango1"
    pause 4.7
    "pilango2"
    pause 0.1
    "pilango3"
    pause 0.1
    "pilango4"
    pause 0.1
    repeat
image pilango6reszanim5:
    "pilango1"
    pause 2.3
    "pilango2"
    pause 0.1
    "pilango3"
    pause 0.1
    "pilango4"
    pause 0.1
    repeat
image debrakertje2medencekoszosvizanim:
    "debrakertje2medencekoszosvizmoz1"
    pause 0.125
    "debrakertje2medencekoszosvizmoz2"
    pause 0.125
    "debrakertje2medencekoszosvizmoz3"
    pause 0.125
    "debrakertje2medencekoszosvizmoz4"
    pause 0.125
    "debrakertje2medencekoszosvizmoz5"
    pause 0.125
    "debrakertje2medencekoszosvizmoz6"
    pause 0.125
    "debrakertje2medencekoszosvizmoz7"
    pause 0.125
    "debrakertje2medencekoszosvizmoz8"
    pause 0.125
    "debrakertje2medencekoszosvizmoz9"
    pause 0.125
    repeat
image debrakertje2medencetisztavizanim:
    "debrakertje2medencetisztavizmoz1"
    pause 0.125
    "debrakertje2medencetisztavizmoz2"
    pause 0.125
    "debrakertje2medencetisztavizmoz3"
    pause 0.125
    "debrakertje2medencetisztavizmoz4"
    pause 0.125
    "debrakertje2medencetisztavizmoz5"
    pause 0.125
    "debrakertje2medencetisztavizmoz6"
    pause 0.125
    "debrakertje2medencetisztavizmoz7"
    pause 0.125
    "debrakertje2medencetisztavizmoz8"
    pause 0.125
    "debrakertje2medencetisztavizmoz9"
    pause 0.125
    repeat
image parktohalak:
    "hal-1"
    pause 0.084
    "hal-2"
    pause 0.084
    "hal-3"
    pause 0.084
    "hal-4"
    pause 0.084
    "hal-5"
    pause 0.084
    "hal-6"
    pause 0.084
    "hal-7"
    pause 0.084
    "hal-8"
    pause 0.084
    "hal-9"
    pause 0.084
    "hal-10"
    pause 0.084
    "hal-11"
    pause 0.084
    "hal-12"
    pause 0.084
    "hal-13"
    pause 0.084
    "hal-14"
    pause 0.084
    "hal-15"
    pause 0.084
    "hal-16"
    pause 0.084
    "hal-17"
    pause 0.084
    "hal-18"
    pause 0.084
    "hal-19"
    pause 0.084
    "hal-20"
    pause 0.084
    "hal-21"
    pause 0.084
    "hal-22"
    pause 0.084
    "hal-23"
    pause 0.084
    "hal-24"
    pause 0.084
    "hal-25"
    pause 0.084
    "hal-26"
    pause 0.084
    "hal-27"
    pause 0.084
    "hal-28"
    pause 0.084
    "hal-29"
    pause 0.084
    "hal-30"
    pause 0.084
    "hal-31"
    pause 0.084
    "hal-32"
    pause 0.084
    "hal-33"
    pause 0.084
    "hal-34"
    pause 0.084
    "hal-35"
    pause 0.084
    repeat
image lizaszexresz8jel4pulianim:
    "lizaszexresz8jel4pulimoz1"
    pause 0.084
    "lizaszexresz8jel4pulimoz2"
    pause 0.084
    "lizaszexresz8jel4pulimoz3"
    pause 0.084
    "lizaszexresz8jel4pulimoz4"
    pause 0.084
    "lizaszexresz8jel4pulimoz5"
    pause 0.084
    "lizaszexresz8jel4pulimoz6"
image lizaszexresz8jel4pulianim2:
    "lizaszexresz8jel4pulimoz6"
    pause 0.084
    "lizaszexresz8jel4pulimoz4"
    pause 0.084
    "lizaszexresz8jel4pulimoz3"
    pause 0.084
    "lizaszexresz8jel4pulimoz2"
    pause 0.084
    "lizaszexresz8jel4pulimoz1"
image pok:
    "pok1"
    pause 3.1
    "pok2"
    pause 0.1
    "pok3"
    pause 0.1
    "pok2"
    pause 0.1
    repeat
image macskaszalad:
    "macska-8"
    pause 0.125
    "macska-9"
    pause 0.1
    "macska-2"
    pause 0.084
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
    "macska-2"
    pause 0.066
    "macska-3"
    pause 0.066
    "macska-4"
    pause 0.066
    "macska-5"
    pause 0.066
    "macska-6"
    pause 0.066
    "macska-7"
    pause 0.066
    "macska-8"
    pause 0.066
    "macska-9"
    pause 0.066
image banditopoganim:
    "nyfbnt1"
    pause 4.1
    "nyfbnt2"
    pause 0.1
    "nyfbnt3"
    pause 0.1
    "nyfbnt4"
    pause 0.1
    "nyfbnt5"
    pause 0.1
    "nyfbnt1"
    pause 0.1
    "nyfbnt2"
    pause 0.1
    "nyfbnt3"
    pause 0.1
    "nyfbnt4"
    pause 0.1
    "nyfbnt5"
    pause 0.1
    "nyfbnt2"
    pause 0.1
    "nyfbnt3"
    pause 0.1
    "nyfbnt4"
    pause 0.1
    "nyfbnt5"
    pause 0.1
    "nyfbnt2"
    pause 0.1
    "nyfbnt3"
    pause 0.1
    "nyfbnt4"
    pause 0.1
    "nyfbnt5"
    pause 0.1
    "nyfbnt2"
    pause 0.1
    "nyfbnt3"
    pause 0.1
    "nyfbnt4"
    pause 0.1
    "nyfbnt5"
    pause 0.1
    "nyfbnt2"
    pause 0.1
    "nyfbnt3"
    pause 0.1
    "nyfbnt4"
    pause 0.1
    "nyfbnt5"
    pause 0.1
    "nyfbnt2"
    pause 0.1
    "nyfbnt3"
    pause 0.1
    "nyfbnt4"
    pause 0.1
    "nyfbnt5"
    pause 0.1
    "nyfbnt2"
    pause 0.1
    "nyfbnt3"
    pause 0.1
    "nyfbnt4"
    pause 0.1
    "nyfbnt5"
    pause 0.1
    repeat
image pucernoaparkbananim:
    "pucernoaparkban1"
    pause 4.1
    "pucernoaparkban2"
    pause 0.1
    "pucernoaparkban3"
    pause 0.1
    "pucernoaparkban4"
    pause 0.1
    "pucernoaparkban5"
    pause 0.1
    "pucernoaparkban6"
    pause 0.1
    "pucernoaparkban7"
    pause 0.1
    "pucernoaparkban8"
    pause 0.1
    "pucernoaparkban9"
    pause 4.1
    "pucernoaparkban8"
    pause 0.1
    "pucernoaparkban7"
    pause 0.1
    "pucernoaparkban6"
    pause 0.1
    "pucernoaparkban5"
    pause 0.1
    "pucernoaparkban4"
    pause 0.1
    "pucernoaparkban3"
    pause 0.1
    "pucernoaparkban2"
    pause 0.1
    repeat
image parktoszokenovisszahuzanim:
    "ruhazz"
    pause 10.0
    "parktoszokenovisszahuz1"
    pause 0.1
    "parktoszokenovisszahuz1"
    pause 0.1
    "parktoszokenovisszahuz2"
    pause 0.1
    "parktoszokenovisszahuz3"
    pause 0.1
    "parktoszokenovisszahuz4"
    pause 0.1
    "parktoszokenovisszahuz5"
    pause 0.1
    "parktoszokenovisszahuz6"
    pause 0.1
    "parktoszokenovisszahuz7"
    pause 0.1
    "parktoszokenovisszahuz8"
    pause 0.1
    "parktoszokenovisszahuz9"
    pause 0.1
    "parktoszokenovisszahuz10"
    pause 0.1
    "parktoszokenovisszahuz11"
    pause 0.1
    "parktoszokenovisszahuz12"
    pause 0.1
    "parktoszokenovisszahuz13"
    pause 0.1
    "parktoszokenovisszahuz14"
    pause 0.1
    "parktoszokenovisszahuz15"
    pause 0.1
    "parktoszokenovisszahuz16"
    pause 0.1
    "parktoszokenovisszahuz17"
    pause 0.1
    "parktoszokenovisszahuz18"
    pause 0.1
    repeat
image kutyasarga10reszanim:
    "kutyasarga10reszmoz1"
    pause 0.125
    "kutyasarga10reszmoz2"
    pause 0.125
    "kutyasarga10reszmoz3"
    pause 0.125
    "kutyasarga10reszmoz4"
    pause 0.125
    "kutyasarga10reszmoz5"
    pause 0.125
    "kutyasarga10reszmoz6"
    pause 0.125
    "kutyasarga10reszmoz7"
    pause 0.125
    "kutyasarga10reszmoz8"
    pause 0.125
    repeat
image naptar1 animated:
    "naptar1"
    pause .082
    "naptar2"
    pause .082
    "naptar3"
    pause .082
    "naptar4"
    pause .082
    "naptar5"
    pause .082
    repeat 1.0
image naptar2 animated:
    "naptar5"
    pause .082
    "naptar6"
    pause .082
    "naptar7"
    pause .082
    "naptar8"
    pause .082
    "naptar9"
    pause .082
    repeat 1.0
image naptar3 animated:
    "naptar9"
    pause .082
    "naptar10"
    pause .082
    "naptar11"
    pause .082
    "naptar12"
    pause .082
    "naptar1"
    pause .082
    repeat 1.0
image kanaviz animated:
    "kanavizz"
    pause .5
    "kanaviz6"
    pause .1
    "kanaviz7"
    pause .1
    "kanaviz8"
    pause .1
    "kanaviz9"
    pause .1
    "kanaviz10"
    pause .1
    "kanaviz11"
    pause .1
    "kanaviz12"
    pause .1
    "kanaviz13"
    pause .1
    "kanaviz14"
    pause .1
    "kanavizz"
    repeat 1.0
image kana animated:
    "kana1"
    pause .1
    "kana2"
    pause .1
    "kana3"
    pause .1
    "kana4"
    pause .1
    "kana5"
    pause .1
    "kana6"
    pause .4
    "kana10"
    pause .1
    "kana11"
    pause .1
    "kana12"
    pause .1
    "kana13"
    pause .1
    "kana1"
    pause .1

image novekvoviragf animated:
    "novekvovirag1"
    pause .1
    repeat 1.0
image novekvoviragff animated:
    "novekvovirag1"
    pause .1
    repeat 1.0
image novekvoviragk animated:
    "novekvovirag1"
    pause .1
    repeat 1.0
image novekvoviragp animated:
    "novekvovirag1"
    pause .1
    repeat 1.0
image novekvovirags animated:
    "novekvovirag1"
    pause .1
    repeat 1.0

image novekvoviragf2 animated:
    "novekvovirag1"
    pause .1
    "novekvovirag2"
    pause .1
    "novekvovirag3"
    pause .1
    repeat 1.0
image novekvoviragff2 animated:
    "novekvovirag1"
    pause .1
    "novekvovirag2"
    pause .1
    "novekvovirag3"
    pause .1
    repeat 1.0
image novekvoviragk2 animated:
    "novekvovirag1"
    pause .1
    "novekvovirag2"
    pause .1
    "novekvovirag3"
    pause .1
    repeat 1.0
image novekvoviragp2 animated:
    "novekvovirag1"
    pause .1
    "novekvovirag2"
    pause .1
    "novekvovirag3"
    pause .1
    repeat 1.0
image novekvovirags2 animated:
    "novekvovirag1"
    pause .1
    "novekvovirag2"
    pause .1
    "novekvovirag3"
    pause .1
    repeat 1.0

image novekvoviragf3 animated:
    "novekvovirag3"
    pause .1
    "novekvovirag4"
    pause .1
    "novekvovirag5"
    pause .1
    repeat 1.0
image novekvoviragff3 animated:
    "novekvovirag3"
    pause .1
    "novekvovirag4"
    pause .1
    "novekvovirag5"
    pause .1
    repeat 1.0
image novekvoviragk3 animated:
    "novekvovirag3"
    pause .1
    "novekvovirag4"
    pause .1
    "novekvovirag5"
    pause .1
    repeat 1.0
image novekvoviragp3 animated:
    "novekvovirag3"
    pause .1
    "novekvovirag4"
    pause .1
    "novekvovirag5"
    pause .1
    repeat 1.0
image novekvovirags3 animated:
    "novekvovirag3"
    pause .1
    "novekvovirag4"
    pause .1
    "novekvovirag5"
    pause .1
    repeat 1.0

image novekvoviragf4 animated:
    "novekvovirag5"
    pause .1
    "novekvovirag6"
    pause .1
    "novekvovirag7f"
    pause .1
    repeat 1.0
image novekvoviragff4 animated:
    "novekvovirag5"
    pause .1
    "novekvovirag6"
    pause .1
    "novekvovirag7f"
    pause .1
    repeat 1.0
image novekvoviragk4 animated:
    "novekvovirag5"
    pause .1
    "novekvovirag6"
    pause .1
    "novekvovirag7k"
    pause .1
    repeat 1.0
image novekvoviragp4 animated:
    "novekvovirag5"
    pause .1
    "novekvovirag6"
    pause .1
    "novekvovirag7p"
    pause .1
    repeat 1.0
image novekvovirags4 animated:
    "novekvovirag5"
    pause .1
    "novekvovirag6"
    pause .1
    "novekvovirag7s"
    pause .1
    repeat 1.0

image szarazviragf animated:
    "novekvovirag7f"
    pause .1
    "novekvovirag8"
    pause .1
    repeat 1.0
image szarazviragff animated:
    "novekvovirag7ff"
    pause .1
    "novekvovirag8"
    pause .1
    repeat 1.0
image szarazviragk animated:
    "novekvovirag7k"
    pause .1
    "novekvovirag8"
    pause .1
    repeat 1.0
image szarazviragp animated:
    "novekvovirag7p"
    pause .1
    "novekvovirag8"
    pause .1
    repeat 1.0
image szarazvirags animated:
    "novekvovirag7s"
    pause .1
    "novekvovirag8"
    pause .1
    repeat 1.0

image szarazviragf2 animated:
    "novekvovirag8"
    pause .1
    "novekvovirag9"
    pause .1
    "novekvovirag10"
    pause .1
    "novekvovirag11"
    pause .1
    "kanavizz"
    pause .1
    repeat 1.0
image szarazviragff2 animated:
    "novekvovirag8"
    pause .1
    "novekvovirag9"
    pause .1
    "novekvovirag10"
    pause .1
    "novekvovirag11"
    pause .1
    "kanavizz"
    pause .1
    repeat 1.0
image szarazviragk2 animated:
    "novekvovirag8"
    pause .1
    "novekvovirag9"
    pause .1
    "novekvovirag10"
    pause .1
    "novekvovirag11"
    pause .1
    "kanavizz"
    pause .1
    repeat 1.0
image szarazviragp2 animated:
    "novekvovirag8"
    pause .1
    "novekvovirag9"
    pause .1
    "novekvovirag10"
    pause .1
    "novekvovirag11"
    pause .1
    "kanavizz"
    pause .1
    repeat 1.0
image szarazvirags2 animated:
    "novekvovirag8"
    pause .1
    "novekvovirag9"
    pause .1
    "novekvovirag10"
    pause .1
    "novekvovirag11"
    pause .1
    "kanavizz"
    pause .1
    repeat 1.0
image pilango animated:
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause 2.3
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    repeat
image pilango1 animated:
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .7
    "pilango1"
    pause .5
    "pilango2"
    pause .7
    "pilango1"
    pause .5
    "pilango2"
    pause .7
    "pilango1"
    pause 2.5
    "pilango2"
    pause .3
    "pilango1"
    pause 2.5
    "pilango2"
    pause .3
    "pilango1"
    pause 2.5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .7
    "pilango1"
    pause .5
    "pilango2"
    pause .7
    "pilango1"
    pause .5
    "pilango2"
    pause .7
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    repeat
image pilango2 animated:
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    "pilango1"
    pause 1.5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .7
    repeat
image pilango3 animated:
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause 3.5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause 1.5
    "pilango2"
    pause .3
    repeat
image pilango4 animated:
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    "pilango1"
    pause 2.5
    "pilango2"
    pause .3
    repeat
image pilango5 animated:
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    repeat
image pilango6 animated:
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause 3.5
    "pilango2"
    pause .3
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    repeat
image pilango7 animated:
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .1
    "pilango2"
    pause .1
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .1
    "pilango2"
    pause .1
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilango1"
    pause .5
    "pilango2"
    pause .3
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    repeat
image pilango8 animated:
    "pilango1"
    pause 2.5
    "pilango2"
    pause .3
    "pilangoszal1"
    pause .1
    "pilangoszal2"
    pause .1
    "pilangoszal3"
    pause .1
    "pilangoszal4"
    pause .1
    "pilangoszal5"
    pause .1
    "pilangoszal6"
    pause .1
    "pilangoszal7"
    pause .1
    "pilangoszal8"
    pause .1
    "pilangoszal9"
    pause .1
    "pilangoszal10"
    pause .1
    "pilangoszal11"
    pause .1
    "pilangoszal12"
    pause .1
    "pilangoszal13"
    pause .1
    "pilangoszal14"
    pause .1
    "pilangoszal15"
    pause .1
    "pilangoszal16"
    pause .1
    "pilangoszal17"
    pause .1
    "pilangoszal18"
    pause .1
    "pilangoszal19"
    pause .1
    "pilangoszal20"
    pause .1
    repeat
image egyetemenjoetanulanim:
    "egyetemenjoetanulmoz1"
    pause 0.125
    "egyetemenjoetanulmoz2"
    pause 0.125
    "egyetemenjoetanulmoz3"
    pause 0.125
    "egyetemenjoetanulmoz4"
    pause 0.125
    "egyetemenjoetanulmoz5"
    pause 0.125
    "egyetemenjoetanulmoz6"
    pause 0.125
    "egyetemenjoetanulmoz1"
    pause 0.125
    "egyetemenjoetanulmoz2"
    pause 0.125
    "egyetemenjoetanulmoz3"
    pause 0.125
    "egyetemenjoetanulmoz4"
    pause 0.125
    "egyetemenjoetanulmoz5"
    pause 0.125
    "egyetemenjoetanulmoz6"
    pause 0.125
    "egyetemenjoetanulmoz1"
    pause 0.125
    "egyetemenjoetanulmoz2"
    pause 0.125
    "egyetemenjoetanulmoz3"
    pause 0.125
    "egyetemenjoetanulmoz4"
    pause 0.125
    "egyetemenjoetanulmoz5"
    pause 0.125
    "egyetemenjoetanulmoz6"
    pause 0.125
    "egyetemenjoetanulmoz1"
    pause 0.125
    "egyetemenjoetanulmoz2"
    pause 0.125
    "egyetemenjoetanulmoz3"
    pause 0.125
    "egyetemenjoetanulmoz4"
    pause 0.125
    "egyetemenjoetanulmoz5"
    pause 0.125
    "egyetemenjoetanulmoz6"
    pause 0.125
    "egyetemenjoetanulmoz1"
    pause 0.1
    "egyetemenjoetanulmoz2"
    pause 0.1
    "egyetemenjoetanulmoz3"
    pause 0.1
    "egyetemenjoetanulmoz4"
    pause 0.1
    "egyetemenjoetanulmoz5"
    pause 0.1
    "egyetemenjoetanulmoz6"
    pause 0.1
    "egyetemenjoetanulmoz1"
    pause 0.1
    "egyetemenjoetanulmoz2"
    pause 0.1
    "egyetemenjoetanulmoz3"
    pause 0.1
    "egyetemenjoetanulmoz4"
    pause 0.1
    "egyetemenjoetanulmoz5"
    pause 0.1
    "egyetemenjoetanulmoz6"
    pause 0.1
    "egyetemenjoetanulmoz1"
    pause 0.1
    "egyetemenjoetanulmoz2"
    pause 0.1
    "egyetemenjoetanulmoz3"
    pause 0.1
    "egyetemenjoetanulmoz4"
    pause 0.1
    "egyetemenjoetanulmoz5"
    pause 0.1
    "egyetemenjoetanulmoz6"
    pause 0.1
    "egyetemenjoetanulmoz1"
    pause 0.1
    "egyetemenjoetanulmoz2"
    pause 0.1
    "egyetemenjoetanulmoz3"
    pause 0.1
    "egyetemenjoetanulmoz4"
    pause 0.1
    "egyetemenjoetanulmoz5"
    pause 0.1
    "egyetemenjoetanulmoz6"
    pause 0.1
    "egyetemenjoetanulmoz1"
    pause 0.1
    "egyetemenjoetanulmoz2"
    pause 0.1
    "egyetemenjoetanulmoz3"
    pause 0.084
    "egyetemenjoetanulmoz4"
    pause 0.084
    "egyetemenjoetanulmoz5"
    pause 0.084
    "egyetemenjoetanulmoz6"
    pause 0.084
    "egyetemenjoetanulmoz1"
    pause 0.084
    "egyetemenjoetanulmoz2"
    pause 0.084
    "egyetemenjoetanulmoz3"
    pause 0.084
    "egyetemenjoetanulmoz4"
    pause 0.084
    "egyetemenjoetanulmoz5"
    pause 0.084
    "egyetemenjoetanulmoz6"
    pause 0.084
    "egyetemenjoetanulmoz1"
    pause 0.084
    "egyetemenjoetanulmoz2"
    pause 0.084
    "egyetemenjoetanulmoz3"
    pause 0.084
    "egyetemenjoetanulmoz4"
    pause 0.084
    "egyetemenjoetanulmoz5"
    pause 0.084
    "egyetemenjoetanulmoz6"
    pause 0.084
    "egyetemenjoetanulmoz1"
    pause 0.084
    "egyetemenjoetanulmoz2"
    pause 0.1
    "egyetemenjoetanulmoz3"
    pause 0.1
    "egyetemenjoetanulmoz4"
    pause 0.1
    "egyetemenjoetanulmoz5"
    pause 0.1
    "egyetemenjoetanulmoz6"
    pause 0.1
    "egyetemenjoetanulmoz1"
    pause 5.125
    repeat
image cilijelenetanimlimbal:
    "cilijelenetmoz2"
    pause 0.75
    "cilijelenetmoz3"
    pause 0.75
    "cilijelenetmoz4"
    pause 0.75
image cilijelenetanimdob:
    "cilijelenetmoz2"
    pause 0.25
    "cilijelenetmoz3"
    pause 0.15
    "cilijelenetmoz4"
    pause 0.10
    "cilijelenetmoz5"
    pause 0.10
    "cilijelenetmoz6"
    pause 0.1
    "cilijelenetmoz7"
    pause 0.1
    "cilijelenetmoz8"
    pause 0.1
    "cilijelenetmoz9"
    pause 0.1
    "cilijelenetmoz10"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
