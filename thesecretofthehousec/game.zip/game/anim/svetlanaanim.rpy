image svetlana11napjelenet3nyelvanim:
    "svetlana11napjelenet3nyelvmoz1"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz2"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz3"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz4"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz5"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz6"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz7"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz8"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz9"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz10"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz11"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz12"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz13"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz14"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz15"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz16"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz17"
    pause 0.1
    "svetlana11napjelenet3nyelvmoz18"
    pause 0.1
    repeat
image svetlana11napjelenet4anim1:
    "svetlana11napjelenet4moz1"
    pause 1.25
    "svetlana11napjelenet4moz2"
    pause 0.125
    "svetlana11napjelenet4moz3"
    pause 0.125
    "svetlana11napjelenet4moz4"
    pause 0.125
    "svetlana11napjelenet4moz5"
    pause 1.125
    "svetlana11napjelenet4moz6"
    pause 0.125
    "svetlana11napjelenet4moz7"
    pause 0.125
    "svetlana11napjelenet4moz8"
    pause 0.125
    "svetlana11napjelenet4moz9"
    pause 0.125
    "svetlana11napjelenet4moz10"
    pause 0.125
    "svetlana11napjelenet4moz11"
    pause 0.125
    "svetlana11napjelenet4moz12"
    pause 1.125
    "svetlana11napjelenet4moz13"
    pause 0.125
    "svetlana11napjelenet4moz14"
    pause 0.125
    "svetlana11napjelenet4moz15"
    pause 0.125
image svetlana11napjelenet4anim2:
    "svetlana11napjelenet4moz15"
    pause 0.125
    "svetlana11napjelenet4moz16"
    pause 0.125
    "svetlana11napjelenet4moz17"
    pause 0.125
    "svetlana11napjelenet4moz18"
    pause 0.125
    "svetlana11napjelenet4moz19"
    pause 0.125
    "svetlana11napjelenet4moz20"
    pause 0.125
    repeat
image svetlana11napjelenet4anim3:
    "svetlana11napjelenet4moz15"
    pause 0.125
    "svetlana11napjelenet4moz16"
    pause 0.125
    "svetlana11napjelenet4moz17"
    pause 0.125
    "svetlana11napjelenet4moz18"
    pause 0.125
    "svetlana11napjelenet4moz19"
    pause 0.125
    "svetlana11napjelenet4moz20"
    pause 0.125
    "svetlana11napjelenet4moz15"
    pause 0.125
    "svetlana11napjelenet4moz16"
    pause 0.125
    "svetlana11napjelenet4moz17"
    pause 0.125
    "svetlana11napjelenet4moz18"
    pause 0.125
    "svetlana11napjelenet4moz19"
    pause 0.125
    "svetlana11napjelenet4moz20"
    pause 0.125
    "svetlana11napjelenet4moz15"
    pause 0.1
    "svetlana11napjelenet4moz16"
    pause 0.1
    "svetlana11napjelenet4moz17"
    pause 0.1
    "svetlana11napjelenet4moz18"
    pause 0.1
    "svetlana11napjelenet4moz19"
    pause 0.1
    "svetlana11napjelenet4moz20"
    pause 0.1
    "svetlana11napjelenet4moz15"
    pause 0.1
    "svetlana11napjelenet4moz16"
    pause 0.1
    "svetlana11napjelenet4moz17"
    pause 0.1
    "svetlana11napjelenet4moz18"
    pause 0.1
    "svetlana11napjelenet4moz19"
    pause 0.1
    "svetlana11napjelenet4moz20"
    pause 0.1
    "svetlana11napjelenet4moz15"
    pause 0.1
    "svetlana11napjelenet4moz16"
    pause 0.1
    "svetlana11napjelenet4moz17"
    pause 0.1
    "svetlana11napjelenet4moz18"
    pause 0.1
    "svetlana11napjelenet4moz19"
    pause 0.1
    "svetlana11napjelenet4moz20"
    pause 0.1
    "svetlana11napjelenet4moz15"
    pause 0.1
    "svetlana11napjelenet4moz16"
    pause 0.1
    "svetlana11napjelenet4moz17"
    pause 0.1
    "svetlana11napjelenet4moz18"
    pause 0.1
    "svetlana11napjelenet4moz19"
    pause 0.1
    "svetlana11napjelenet4moz20"
    pause 0.1
    repeat
image svetlana11napjelenet4anim4:
    "svetlana11napjelenet4moz15"
    pause 0.1
    "svetlana11napjelenet4moz16"
    pause 0.1
    "svetlana11napjelenet4moz17"
    pause 0.1
    "svetlana11napjelenet4moz18"
    pause 0.1
    "svetlana11napjelenet4moz19"
    pause 0.1
    "svetlana11napjelenet4moz20"
    pause 0.1
    "svetlana11napjelenet4moz15"
    pause 0.1
    "svetlana11napjelenet4moz16"
    pause 0.1
    "svetlana11napjelenet4moz17"
    pause 0.1
    "svetlana11napjelenet4moz18"
    pause 0.1
    "svetlana11napjelenet4moz19"
    pause 0.1
    "svetlana11napjelenet4moz20"
    pause 0.1
    "svetlana11napjelenet4moz15"
    pause 0.125
    "svetlana11napjelenet4moz16"
    pause 0.125
    "svetlana11napjelenet4moz17"
    pause 0.125
    "svetlana11napjelenet4moz18"
    pause 0.125
    "svetlana11napjelenet4moz19"
    pause 0.125
    "svetlana11napjelenet4moz20"
    pause 0.125
    "svetlana11napjelenet4moz15"
    pause 0.125
    "svetlana11napjelenet4moz16"
    pause 0.125
    "svetlana11napjelenet4moz17"
    pause 0.125
    "svetlana11napjelenet4moz18"
    pause 0.125
    "svetlana11napjelenet4moz19"
    pause 0.125
    "svetlana11napjelenet4moz20"
    pause 0.125
    "svetlana11napjelenet4moz15"
    pause 0.125
    "svetlana11napjelenet4moz16"
    pause 0.125
    "svetlana11napjelenet4moz17"
    pause 0.125
    "svetlana11napjelenet4moz18"
    pause 0.125
    "svetlana11napjelenet4moz19"
    pause 0.125
    "svetlana11napjelenet4moz20"
    pause 0.125
    "svetlana11napjelenet4moz15"
    pause 0.125
    "svetlana11napjelenet4moz16"
    pause 0.125
    "svetlana11napjelenet4moz17"
    pause 0.125
    "svetlana11napjelenet4moz18"
    pause 0.125
    "svetlana11napjelenet4moz19"
    pause 0.125
    "svetlana11napjelenet4moz20"
    repeat
image svetlana11napjelenet4anim5:
    "svetlana11napjelenet4moz15"
    pause 0.1
    "svetlana11napjelenet4moz16"
    pause 0.1
    "svetlana11napjelenet4moz17"
    pause 0.1
    "svetlana11napjelenet4moz18"
    pause 0.1
    "svetlana11napjelenet4moz19"
    pause 0.1
    "svetlana11napjelenet4moz20"
    pause 0.1
    repeat
image svetlana11napjelenet5anim:
    "svetlana11napjelenet5moz1"
    pause 0.125
    "svetlana11napjelenet5moz2"
    pause 0.125
    "svetlana11napjelenet5moz3"
    pause 0.125
    "svetlana11napjelenet5moz4"
    pause 0.125
    "svetlana11napjelenet5moz5"
    pause 0.125
    "svetlana11napjelenet5moz6"
    pause 0.125
    repeat
image svetlana11napjelenet6anim1:
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.084
    "svetlana11napjelenet6moz2"
    pause 0.084
    "svetlana11napjelenet6moz3"
    pause 0.084
    "svetlana11napjelenet6moz4"
    pause 0.084
    "svetlana11napjelenet6moz5"
    pause 0.084
    "svetlana11napjelenet6moz6"
    pause 0.084
    "svetlana11napjelenet6moz1"
    pause 0.084
    "svetlana11napjelenet6moz2"
    pause 0.084
    "svetlana11napjelenet6moz3"
    pause 0.084
    "svetlana11napjelenet6moz4"
    pause 0.084
    "svetlana11napjelenet6moz5"
    pause 0.084
    "svetlana11napjelenet6moz6"
    pause 0.084
    "svetlana11napjelenet6moz1"
    pause 0.084
    "svetlana11napjelenet6moz2"
    pause 0.084
    "svetlana11napjelenet6moz3"
    pause 0.084
    "svetlana11napjelenet6moz4"
    pause 0.084
    "svetlana11napjelenet6moz5"
    pause 0.084
    "svetlana11napjelenet6moz6"
    pause 0.084
    "svetlana11napjelenet6moz1"
    pause 0.084
    "svetlana11napjelenet6moz2"
    pause 0.084
    "svetlana11napjelenet6moz3"
    pause 0.084
    "svetlana11napjelenet6moz4"
    pause 0.084
    "svetlana11napjelenet6moz5"
    pause 0.084
    "svetlana11napjelenet6moz6"
    pause 0.084
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    "svetlana11napjelenet6moz1"
    pause 0.1
    "svetlana11napjelenet6moz2"
    pause 0.1
    "svetlana11napjelenet6moz3"
    pause 0.1
    "svetlana11napjelenet6moz4"
    pause 0.1
    "svetlana11napjelenet6moz5"
    pause 0.1
    "svetlana11napjelenet6moz6"
    pause 0.1
    repeat
image svetlana11napjelenet6v2anim1:
    "svetlana11napjelenet6v2moz1"
    pause 0.1
    "svetlana11napjelenet6v2moz2"
    pause 0.1
    "svetlana11napjelenet6v2moz3"
    pause 0.1
    "svetlana11napjelenet6v2moz4"
    pause 0.1
    "svetlana11napjelenet6v2moz5"
    pause 0.1
    "svetlana11napjelenet6v2moz6"
    pause 0.1
    "svetlana11napjelenet6v2moz1"
    pause 0.1
    "svetlana11napjelenet6v2moz2"
    pause 0.1
    "svetlana11napjelenet6v2moz3"
    pause 0.1
    "svetlana11napjelenet6v2moz4"
    pause 0.1
    "svetlana11napjelenet6v2moz5"
    pause 0.1
    "svetlana11napjelenet6v2moz6"
    pause 0.1
    "svetlana11napjelenet6v2moz1"
    pause 0.1
    "svetlana11napjelenet6v2moz2"
    pause 0.1
    "svetlana11napjelenet6v2moz3"
    pause 0.1
    "svetlana11napjelenet6v2moz4"
    pause 0.1
    "svetlana11napjelenet6v2moz5"
    pause 0.1
    "svetlana11napjelenet6v2moz6"
    pause 0.1
    "svetlana11napjelenet6v2moz1"
    pause 0.1
    "svetlana11napjelenet6v2moz2"
    pause 0.1
    "svetlana11napjelenet6v2moz3"
    pause 0.1
    "svetlana11napjelenet6v2moz4"
    pause 0.1
    "svetlana11napjelenet6v2moz5"
    pause 0.1
    "svetlana11napjelenet6v2moz6"
    pause 0.1
    "svetlana11napjelenet6v2moz1"
    pause 0.1
    "svetlana11napjelenet6v2moz2"
    pause 0.1
    "svetlana11napjelenet6v2moz3"
    pause 0.1
    "svetlana11napjelenet6v2moz4"
    pause 0.1
    "svetlana11napjelenet6v2moz5"
    pause 0.1
    "svetlana11napjelenet6v2moz6"
    pause 0.1
    "svetlana11napjelenet6v2moz1"
    pause 0.084
    "svetlana11napjelenet6v2moz2"
    pause 0.084
    "svetlana11napjelenet6v2moz3"
    pause 0.084
    "svetlana11napjelenet6v2moz4"
    pause 0.084
    "svetlana11napjelenet6v2moz5"
    pause 0.084
    "svetlana11napjelenet6v2moz6"
    pause 0.084
    "svetlana11napjelenet6v2moz1"
    pause 0.084
    "svetlana11napjelenet6v2moz2"
    pause 0.084
    "svetlana11napjelenet6v2moz3"
    pause 0.084
    "svetlana11napjelenet6v2moz4"
    pause 0.084
    "svetlana11napjelenet6v2moz5"
    pause 0.084
    "svetlana11napjelenet6v2moz6"
    pause 0.084
    "svetlana11napjelenet6v2moz1"
    pause 0.084
    "svetlana11napjelenet6v2moz2"
    pause 0.084
    "svetlana11napjelenet6v2moz3"
    pause 0.084
    "svetlana11napjelenet6v2moz4"
    pause 0.084
    "svetlana11napjelenet6v2moz5"
    pause 0.084
    "svetlana11napjelenet6v2moz6"
    pause 0.084
    "svetlana11napjelenet6v2moz1"
    pause 0.084
    "svetlana11napjelenet6v2moz2"
    pause 0.084
    "svetlana11napjelenet6v2moz3"
    pause 0.084
    "svetlana11napjelenet6v2moz4"
    pause 0.084
    "svetlana11napjelenet6v2moz5"
    pause 0.084
    "svetlana11napjelenet6v2moz6"
    pause 0.084
    "svetlana11napjelenet6v2moz1"
    pause 0.084
    "svetlana11napjelenet6v2moz2"
    pause 0.084
    "svetlana11napjelenet6v2moz3"
    pause 0.084
    "svetlana11napjelenet6v2moz4"
    pause 0.084
    "svetlana11napjelenet6v2moz5"
    pause 0.084
    "svetlana11napjelenet6v2moz6"
    pause 0.084
    "svetlana11napjelenet6v2moz1"
    pause 0.1
    "svetlana11napjelenet6v2moz2"
    pause 0.1
    "svetlana11napjelenet6v2moz3"
    pause 0.1
    "svetlana11napjelenet6v2moz4"
    pause 0.1
    "svetlana11napjelenet6v2moz5"
    pause 0.1
    "svetlana11napjelenet6v2moz6"
    pause 0.1
    "svetlana11napjelenet6v2moz1"
    pause 0.1
    "svetlana11napjelenet6v2moz2"
    pause 0.1
    "svetlana11napjelenet6v2moz3"
    pause 0.1
    "svetlana11napjelenet6v2moz4"
    pause 0.1
    "svetlana11napjelenet6v2moz5"
    pause 0.1
    "svetlana11napjelenet6v2moz6"
    pause 0.1
    repeat
image svetlana11napjelenet6v3anim1:
    "svetlana11napjelenet6v3moz1"
    pause 0.1
    "svetlana11napjelenet6v3moz2"
    pause 0.1
    "svetlana11napjelenet6v3moz3"
    pause 0.1
    "svetlana11napjelenet6v3moz4"
    pause 0.1
    "svetlana11napjelenet6v3moz5"
    pause 0.1
    "svetlana11napjelenet6v3moz6"
    pause 0.1
    "svetlana11napjelenet6v3moz1"
    pause 0.1
    "svetlana11napjelenet6v3moz2"
    pause 0.1
    "svetlana11napjelenet6v3moz3"
    pause 0.1
    "svetlana11napjelenet6v3moz4"
    pause 0.1
    "svetlana11napjelenet6v3moz5"
    pause 0.1
    "svetlana11napjelenet6v3moz6"
    pause 0.1
    "svetlana11napjelenet6v3moz1"
    pause 0.1
    "svetlana11napjelenet6v3moz2"
    pause 0.1
    "svetlana11napjelenet6v3moz3"
    pause 0.1
    "svetlana11napjelenet6v3moz4"
    pause 0.1
    "svetlana11napjelenet6v3moz5"
    pause 0.1
    "svetlana11napjelenet6v3moz6"
    pause 0.1
    "svetlana11napjelenet6v3moz1"
    pause 0.084
    "svetlana11napjelenet6v3moz2"
    pause 0.084
    "svetlana11napjelenet6v3moz3"
    pause 0.084
    "svetlana11napjelenet6v3moz4"
    pause 0.084
    "svetlana11napjelenet6v3moz5"
    pause 0.084
    "svetlana11napjelenet6v3moz6"
    pause 0.084
    "svetlana11napjelenet6v3moz1"
    pause 0.084
    "svetlana11napjelenet6v3moz2"
    pause 0.084
    "svetlana11napjelenet6v3moz3"
    pause 0.084
    "svetlana11napjelenet6v3moz4"
    pause 0.084
    "svetlana11napjelenet6v3moz5"
    pause 0.084
    "svetlana11napjelenet6v3moz6"
    pause 0.084
    "svetlana11napjelenet6v3moz1"
    pause 0.084
    "svetlana11napjelenet6v3moz2"
    pause 0.084
    "svetlana11napjelenet6v3moz3"
    pause 0.084
    "svetlana11napjelenet6v3moz4"
    pause 0.084
    "svetlana11napjelenet6v3moz5"
    pause 0.084
    "svetlana11napjelenet6v3moz6"
    pause 0.084
    "svetlana11napjelenet6v3moz1"
    pause 0.1
    "svetlana11napjelenet6v3moz2"
    pause 0.1
    "svetlana11napjelenet6v3moz3"
    pause 0.1
    "svetlana11napjelenet6v3moz4"
    pause 0.1
    "svetlana11napjelenet6v3moz5"
    pause 0.1
    "svetlana11napjelenet6v3moz6"
    pause 0.1
    "svetlana11napjelenet6v3moz1"
    pause 0.1
    "svetlana11napjelenet6v3moz2"
    pause 0.1
    "svetlana11napjelenet6v3moz3"
    pause 0.1
    "svetlana11napjelenet6v3moz4"
    pause 0.1
    "svetlana11napjelenet6v3moz5"
    pause 0.1
    "svetlana11napjelenet6v3moz6"
    pause 0.1
    "svetlana11napjelenet6v3moz1"
    pause 0.1
    "svetlana11napjelenet6v3moz2"
    pause 0.1
    "svetlana11napjelenet6v3moz3"
    pause 0.1
    "svetlana11napjelenet6v3moz4"
    pause 0.1
    "svetlana11napjelenet6v3moz5"
    pause 0.1
    "svetlana11napjelenet6v3moz6"
    pause 0.1
    "svetlana11napjelenet6v3moz1"
    pause 0.1
    "svetlana11napjelenet6v3moz2"
    pause 0.1
    "svetlana11napjelenet6v3moz3"
    pause 0.1
    "svetlana11napjelenet6v3moz4"
    pause 0.1
    "svetlana11napjelenet6v3moz5"
    pause 0.1
    "svetlana11napjelenet6v3moz6"
    pause 0.1
    "svetlana11napjelenet6v3moz1"
    pause 0.1
    "svetlana11napjelenet6v3moz2"
    pause 0.1
    "svetlana11napjelenet6v3moz3"
    pause 0.1
    "svetlana11napjelenet6v3moz4"
    pause 0.1
    "svetlana11napjelenet6v3moz5"
    pause 0.1
    "svetlana11napjelenet6v3moz6"
    pause 0.1
    "svetlana11napjelenet6v3moz1"
    pause 0.084
    "svetlana11napjelenet6v3moz2"
    pause 0.084
    "svetlana11napjelenet6v3moz3"
    pause 0.084
    "svetlana11napjelenet6v3moz4"
    pause 0.084
    "svetlana11napjelenet6v3moz5"
    pause 0.084
    "svetlana11napjelenet6v3moz6"
    pause 0.084
    "svetlana11napjelenet6v3moz1"
    pause 0.084
    "svetlana11napjelenet6v3moz2"
    pause 0.084
    "svetlana11napjelenet6v3moz3"
    pause 0.084
    "svetlana11napjelenet6v3moz4"
    pause 0.084
    "svetlana11napjelenet6v3moz5"
    pause 0.084
    "svetlana11napjelenet6v3moz6"
    pause 0.084
    "svetlana11napjelenet6v3moz1"
    pause 0.084
    "svetlana11napjelenet6v3moz2"
    pause 0.084
    "svetlana11napjelenet6v3moz3"
    pause 0.084
    "svetlana11napjelenet6v3moz4"
    pause 0.084
    "svetlana11napjelenet6v3moz5"
    pause 0.084
    "svetlana11napjelenet6v3moz6"
    pause 0.084
    repeat
image svetlana11napjelenet7szajanim:
    "svetlana11napjelenet7szaj1"
    pause 0.16
    "svetlana11napjelenet7szaj3"
    pause 0.16
    "svetlana11napjelenet7szaj4"
    pause 0.16
    "svetlana11napjelenet7szaj5"
    pause 0.16
    "svetlana11napjelenet7szaj2"
    pause 0.16
    "svetlana11napjelenet7szaj3"
    pause 0.16
    "svetlana11napjelenet7szaj1"
    pause 0.16
    "svetlana11napjelenet7szaj2"
    pause 0.16
    "svetlana11napjelenet7szaj5"
    pause 0.16
    "svetlana11napjelenet7szaj4"
    pause 0.16
    "svetlana11napjelenet7szaj1"
    pause 0.16
    "svetlana11napjelenet7szaj3"
    pause 0.16
    "svetlana11napjelenet7szaj2"
    pause 0.16
    "svetlana11napjelenet7szaj4"
    pause 0.16
    "svetlana11napjelenet7szaj2"
    pause 0.16
    "svetlana11napjelenet7szaj3"
    pause 0.16
    "svetlana11napjelenet7szaj1"
    pause 0.16
    "svetlana11napjelenet7szaj5"
    pause 0.16
    repeat
image svetlana11napjelenet7szemanim:
    "svetlana11napjelenet7szem1"
    pause 3.525
    "svetlana11napjelenet7szem2"
    pause 0.125
    "svetlana11napjelenet7szem3"
    pause 0.125
    "svetlana11napjelenet7szem4"
    pause 0.125
    "svetlana11napjelenet7szem5"
    pause 0.125
    "svetlana11napjelenet7szem6"
    pause 0.125
    "svetlana11napjelenet7szem7"
    pause 0.125
    repeat
image svetlanakerestavolianim:
    "svetlanakerestavolimoz1"
    pause 3.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz5"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz1"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz5"
    pause 2.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz1"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz5"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz1"
    pause 1.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz5"
    pause 3.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz1"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz5"
    pause 4.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz1"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz5"
    pause 0.125
    "svetlanakerestavolimoz4"
    pause 0.125
    "svetlanakerestavolimoz3"
    pause 0.125
    "svetlanakerestavolimoz2"
    pause 0.125
    repeat
image svetlanakerestavoliszemanim:
    "svetlanakerestavoliszem1"
    pause 5.525
    "svetlanakerestavoliszem2"
    pause 0.125
    "svetlanakerestavoliszem3"
    pause 0.125
    "svetlanakerestavoliszem4"
    pause 0.125
    "svetlanakerestavoliszem5"
    pause 0.125
    repeat
image svetlanakereskozelianim:
    "svetlanakereskozelimoz1"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz1"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz5"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz1"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz1"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz5"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz1"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz5"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz5"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz1"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz5"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz4"
    pause 0.125
    "svetlanakereskozelimoz5"
    pause 0.125
    "svetlanakereskozelimoz3"
    pause 0.125
    "svetlanakereskozelimoz2"
    pause 0.125
    "svetlanakereskozelimoz1"
    pause 3.125
    repeat
image svetlanakereskozeliszajanim:
    "svetlanakereskozeliszaj1"
    pause 0.16
    "svetlanakereskozeliszaj3"
    pause 0.16
    "svetlanakereskozeliszaj4"
    pause 0.16
    "svetlanakereskozeliszaj5"
    pause 0.16
    "svetlanakereskozeliszaj2"
    pause 0.16
    "svetlanakereskozeliszaj3"
    pause 0.16
    "svetlanakereskozeliszaj1"
    pause 0.16
    "svetlanakereskozeliszaj2"
    pause 0.16
    "svetlanakereskozeliszaj5"
    pause 0.16
    "svetlanakereskozeliszaj4"
    pause 0.16
    "svetlanakereskozeliszaj1"
    pause 0.16
    "svetlanakereskozeliszaj3"
    pause 0.16
    "svetlanakereskozeliszaj2"
    pause 0.16
    "svetlanakereskozeliszaj4"
    pause 0.16
    "svetlanakereskozeliszaj2"
    pause 0.16
    "svetlanakereskozeliszaj3"
    pause 0.16
    "svetlanakereskozeliszaj1"
    pause 0.16
    "svetlanakereskozeliszaj5"
    pause 0.16
    repeat
image svetlanakereskozeliszemanim:
    "svetlanakereskozeliszem1"
    pause 4.525
    "svetlanakereskozeliszem2"
    pause 0.125
    "svetlanakereskozeliszem3"
    pause 0.125
    "svetlanakereskozeliszem4"
    pause 0.125
    "svetlanakereskozeliszem5"
    pause 0.125
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
