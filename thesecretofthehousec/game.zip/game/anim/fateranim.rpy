image faterpislognapaliban:
    "faterszem1"
    pause 4.0
    "faterszem2"
    pause 0.125
    "faterszem3"
    pause 0.125
    "faterszem2"
    pause 0.125
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
