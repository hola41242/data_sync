image lizagyomlalanim:
    "liza4reszgyomlal1"
    pause 0.25
    "liza4reszgyomlal2"
    pause 0.125
    "liza4reszgyomlal3"
    pause 0.125
    "liza4reszgyomlal4"
    pause 0.125
    "liza4reszgyomlal5"
    pause 0.325
    "liza4reszgyomlal4"
    pause 0.125
    "liza4reszgyomlal3"
    pause 0.125
    "liza4reszgyomlal2"
    pause 0.125
    repeat
image lizagyomlalanim2:
    "liza4reszgyomlal1"
    pause 0.25
    "liza4reszgyomlal2"
    pause 0.125
    "liza4reszgyomlal3"
    pause 0.125
    "liza4reszgyomlal4"
    pause 0.125
    "liza4reszgyomlal5"
    pause 0.325
    "liza4reszgyomlal4"
    pause 0.125
    "liza4reszgyomlal3"
    pause 0.125
    "liza4reszgyomlal2"
    pause 0.125
    repeat
image lizagyomlalkicsianim:
    "liza4reszgyomlalkicsi1"
    pause 0.25
    "liza4reszgyomlalkicsi2"
    pause 0.125
    "liza4reszgyomlalkicsi3"
    pause 0.125
    "liza4reszgyomlalkicsi4"
    pause 0.125
    "liza4reszgyomlalkicsi5"
    pause 0.325
    "liza4reszgyomlalkicsi4"
    pause 0.125
    "liza4reszgyomlalkicsi3"
    pause 0.125
    "liza4reszgyomlalkicsi2"
    pause 0.125
    repeat
image lizafogdosas5reszanim:
    "lizafogdosas5resz1"
    pause 0.1
    "lizafogdosas5resz2"
    pause 0.1
    "lizafogdosas5resz3"
    pause 0.1
    "lizafogdosas5resz4"
    pause 0.1
    "lizafogdosas5resz5"
    pause 0.1
    "lizafogdosas5resz6"
    pause 0.1
    "lizafogdosas5resz7"
    pause 0.1
    "lizafogdosas5resz8"
    pause 0.1
    "lizafogdosas5resz9"
    pause 0.1
    "lizafogdosas5resz10"
    pause 0.1
    repeat
image lizafogdosas5reszszemanim:
    "lizafogdosas5reszszem1"
    pause 2.25
    "lizafogdosas5reszszem2"
    pause 0.125
    "lizafogdosas5reszszem3"
    pause 0.125
    "lizafogdosas5reszszem4"
    pause 0.125
    "lizafogdosas5reszszem3"
    pause 0.125
    "lizafogdosas5reszszem2"
    pause 0.125
    "lizafogdosas5reszszem1"
    pause 0.125
    repeat
image lizafogdosas5reszszajanim:
    "lizafogdosas5reszszaj1"
    pause 0.16
    "lizafogdosas5reszszaj5"
    pause 0.16
    "lizafogdosas5reszszaj3"
    pause 0.16
    "lizafogdosas5reszszaj2"
    pause 0.16
    "lizafogdosas5reszszaj4"
    pause 0.16
    "lizafogdosas5reszszaj1"
    pause 0.16
    "lizafogdosas5reszszaj2"
    pause 0.16
    "lizafogdosas5reszszaj5"
    pause 0.16
    "lizafogdosas5reszszaj1"
    pause 0.16
    "lizafogdosas5reszszaj3"
    pause 0.16
    "lizafogdosas5reszszaj4"
    pause 0.16
    "lizafogdosas5reszszaj5"
    pause 0.16
    "lizafogdosas5reszszaj2"
    pause 0.16
    "lizafogdosas5reszszaj4"
    pause 0.16
    repeat
image stripbarjelenet5szemanim:
    "stripbarjelenet5szem1"
    pause 3.0
    "stripbarjelenet5szem2"
    pause 0.15
    "stripbarjelenet5szem3"
    pause 0.15
    "stripbarjelenet5szem4"
    pause 0.15
    "stripbarjelenet5szem5"
    pause 0.15
    "stripbarjelenet5szem6"
    pause 0.15
    "stripbarjelenet5szem7"
    pause 0.23
    "stripbarjelenet5szem8"
    pause 0.15
image stripbarjelenet6mozanim:
    "stripbarjelenet6moz1"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz5"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz1"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz5"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz1"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz5"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz1"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz5"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz1"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz5"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz1"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz5"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz1"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz5"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz1"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz5"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz1"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz5"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz1"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz5"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz1"
    pause 0.1
    "stripbarjelenet6moz2"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz5"
    pause 0.1
    "stripbarjelenet6moz4"
    pause 0.1
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz1"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz5"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz1"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz5"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz1"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz5"
    pause 0.125
    "stripbarjelenet6moz4"
    pause 0.125
    "stripbarjelenet6moz3"
    pause 0.125
    "stripbarjelenet6moz2"
    pause 0.125
    repeat
image stripbarjelenet6szemanim:
    "stripbarjelenet6szem1"
    pause 3.0
    "stripbarjelenet6szem2"
    pause 0.1
    "stripbarjelenet6szem3"
    pause 0.1
    "stripbarjelenet6szem2"
    pause 0.1
    "stripbarjelenet6szem1"
    pause 2.5
    "stripbarjelenet6szem2"
    pause 0.1
    "stripbarjelenet6szem3"
    pause 0.1
    "stripbarjelenet6szem4"
    pause 0.1
    "stripbarjelenet6szem5"
    pause 2.5
    "stripbarjelenet6szem4"
    pause 0.1
    "stripbarjelenet6szem3"
    pause 0.1
    "stripbarjelenet6szem4"
    pause 0.1
    "stripbarjelenet6szem5"
    pause 3.1
    "stripbarjelenet6szem4"
    pause 0.1
    "stripbarjelenet6szem3"
    pause 0.1
    "stripbarjelenet6szem2"
    pause 0.1
    repeat
image stripbarjelenet6szajanim:
    "stripbarjelenet6szaj1"
    pause 0.16
    "stripbarjelenet6szaj3"
    pause 0.16
    "stripbarjelenet6szaj5"
    pause 0.16
    "stripbarjelenet6szaj6"
    pause 0.16
    "stripbarjelenet6szaj4"
    pause 0.16
    "stripbarjelenet6szaj2"
    pause 0.16
    "stripbarjelenet6szaj3"
    pause 0.16
    "stripbarjelenet6szaj6"
    pause 0.16
    "stripbarjelenet6szaj1"
    pause 0.16
    "stripbarjelenet6szaj3"
    pause 0.16
    "stripbarjelenet6szaj4"
    pause 0.16
    "stripbarjelenet6szaj2"
    pause 0.16
    "stripbarjelenet6szaj6"
    pause 0.16
    "stripbarjelenet6szaj3"
    pause 0.16
    repeat
image stripbarjelenet12:
    "stripbarjelenet12v1"
    pause 0.1
    "stripbarjelenet12v2"
    pause 0.1
    repeat
image szexanim5reszlizaanim:
    "szexanim5reszliza1"
    pause 0.125
    "szexanim5reszliza2"
    pause 0.125
    "szexanim5reszliza3"
    pause 0.125
    "szexanim5reszliza4"
    pause 0.125
    "szexanim5reszliza5"
    pause 0.125
    "szexanim5reszliza6"
    pause 0.125
    "szexanim5reszliza7"
    pause 0.125
    "szexanim5reszliza8"
    pause 0.125
    "szexanim5reszliza1"
    pause 0.125
    "szexanim5reszliza2"
    pause 0.125
    "szexanim5reszliza3"
    pause 0.125
    "szexanim5reszliza4"
    pause 0.125
    "szexanim5reszliza5"
    pause 0.125
    "szexanim5reszliza6"
    pause 0.125
    "szexanim5reszliza7"
    pause 0.125
    "szexanim5reszliza8"
    pause 0.125
    "szexanim5reszliza1"
    pause 0.125
    "szexanim5reszliza2"
    pause 0.125
    "szexanim5reszliza3"
    pause 0.125
    "szexanim5reszliza4"
    pause 0.125
    "szexanim5reszliza5"
    pause 0.125
    "szexanim5reszliza6"
    pause 0.125
    "szexanim5reszliza7"
    pause 0.125
    "szexanim5reszliza8"
    pause 0.125
    "szexanim5reszliza1"
    pause 0.125
    "szexanim5reszliza2"
    pause 0.125
    "szexanim5reszliza3"
    pause 0.125
    "szexanim5reszliza4"
    pause 0.125
    "szexanim5reszliza5"
    pause 0.125
    "szexanim5reszliza6"
    pause 0.125
    "szexanim5reszliza7"
    pause 0.125
    "szexanim5reszliza8"
    pause 0.125
    "szexanim5reszliza1"
    pause 0.125
    "szexanim5reszliza2"
    pause 0.125
    "szexanim5reszliza3"
    pause 0.125
    "szexanim5reszliza4"
    pause 0.125
    "szexanim5reszliza5"
    pause 0.125
    "szexanim5reszliza6"
    pause 0.125
    "szexanim5reszliza7"
    pause 0.125
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.1
    "szexanim5reszliza2"
    pause 0.1
    "szexanim5reszliza3"
    pause 0.1
    "szexanim5reszliza4"
    pause 0.1
    "szexanim5reszliza5"
    pause 0.1
    "szexanim5reszliza6"
    pause 0.1
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.1
    "szexanim5reszliza2"
    pause 0.1
    "szexanim5reszliza3"
    pause 0.1
    "szexanim5reszliza4"
    pause 0.1
    "szexanim5reszliza5"
    pause 0.1
    "szexanim5reszliza6"
    pause 0.1
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.1
    "szexanim5reszliza2"
    pause 0.1
    "szexanim5reszliza3"
    pause 0.1
    "szexanim5reszliza4"
    pause 0.1
    "szexanim5reszliza5"
    pause 0.1
    "szexanim5reszliza6"
    pause 0.1
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.1
    "szexanim5reszliza2"
    pause 0.1
    "szexanim5reszliza3"
    pause 0.1
    "szexanim5reszliza4"
    pause 0.1
    "szexanim5reszliza5"
    pause 0.1
    "szexanim5reszliza6"
    pause 0.1
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.1
    "szexanim5reszliza2"
    pause 0.1
    "szexanim5reszliza3"
    pause 0.1
    "szexanim5reszliza4"
    pause 0.1
    "szexanim5reszliza5"
    pause 0.1
    "szexanim5reszliza6"
    pause 0.1
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.1
    "szexanim5reszliza2"
    pause 0.1
    "szexanim5reszliza3"
    pause 0.1
    "szexanim5reszliza4"
    pause 0.1
    "szexanim5reszliza5"
    pause 0.1
    "szexanim5reszliza6"
    pause 0.1
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.084
    "szexanim5reszliza8"
    pause 0.084
    "szexanim5reszliza1"
    pause 0.084
    "szexanim5reszliza2"
    pause 0.084
    "szexanim5reszliza3"
    pause 0.084
    "szexanim5reszliza4"
    pause 0.084
    "szexanim5reszliza5"
    pause 0.084
    "szexanim5reszliza6"
    pause 0.084
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.1
    "szexanim5reszliza2"
    pause 0.1
    "szexanim5reszliza3"
    pause 0.1
    "szexanim5reszliza4"
    pause 0.1
    "szexanim5reszliza5"
    pause 0.1
    "szexanim5reszliza6"
    pause 0.1
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    "szexanim5reszliza1"
    pause 0.1
    "szexanim5reszliza2"
    pause 0.1
    "szexanim5reszliza3"
    pause 0.1
    "szexanim5reszliza4"
    pause 0.1
    "szexanim5reszliza5"
    pause 0.1
    "szexanim5reszliza6"
    pause 0.1
    "szexanim5reszliza7"
    pause 0.1
    "szexanim5reszliza8"
    pause 0.1
    repeat
image stripbarjelenet14anim:
    "stripbarjelenet14v1"
    pause 0.1
    "stripbarjelenet14v2"
    pause 0.1
    repeat
image stripbarjelenet14animgeci:
    "geciz5resz-1"
    pause 0.1
    "geciz5resz-2"
    pause 0.1
    "geciz5resz-3"
    pause 0.1
    "geciz5resz-4"
    pause 0.1
    "geciz5resz-5"
    pause 0.1
    "geciz5resz-6"
    pause 0.1
    "geciz5resz-7"
    pause 0.1
    "geciz5resz-8"
    pause 0.1
    "geciz5resz-9"
    pause 0.1
    "geciz5resz-10"
    pause 0.1
    "geciz5resz-11"
    pause 0.1
image stripbarjelenet14animgeciremeg:
    "geciz5resz-10"
    pause 0.1
    "geciz5resz-11"
    pause 0.1
    repeat
image lizakertbentornazikanim:
    "lizatornazmoz1"
    pause 0.15
    "lizatornazmoz2"
    pause 0.15
    "lizatornazmoz3"
    pause 0.15
    "lizatornazmoz4"
    pause 0.15
    "lizatornazmoz5"
    pause 0.15
    "lizatornazmoz4"
    pause 0.15
    "lizatornazmoz3"
    pause 0.15
    "lizatornazmoz2"
    pause 0.15
    repeat
image lizakertbentornazik1080anim:
    "lizatornaz1080moz1"
    pause 0.15
    "lizatornaz1080moz2"
    pause 0.15
    "lizatornaz1080moz3"
    pause 0.15
    "lizatornaz1080moz4"
    pause 0.15
    "lizatornaz1080moz5"
    pause 0.15
    "lizatornaz1080moz4"
    pause 0.15
    "lizatornaz1080moz3"
    pause 0.15
    "lizatornaz1080moz2"
    pause 0.15
    repeat
image lizaarcahozkozelpeni6reszv2mozanim:
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz6"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz7"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz6"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz7"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz6"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz7"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz6"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz7"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-6"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-7"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-8"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-6"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-7"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-8"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2mozv2-6"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2mozv2-7"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2mozv2-8"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2mozv2-6"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2mozv2-7"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2mozv2-8"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz6"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz7"
    pause 0.125
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz6"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz7"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-6"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-7"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-8"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz1"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz2"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz3"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz4"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2moz5"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-6"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-7"
    pause 0.1
    "lizaarcahozkozelpeni6reszv2mozv2-8"
    pause 0.1
    repeat
image lizacicikozelrolnez6reszv2cicifoganim:
    "lizacicikozelrolnez6reszv2cicifog1"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog6"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog1"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog6"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog1"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog6"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog1"
    pause 2.0
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog6"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog1"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog6"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog1"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog6"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog1"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog6"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog1"
    pause 2.0
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog6"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog5"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog4"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog3"
    pause 0.1
    "lizacicikozelrolnez6reszv2cicifog2"
    pause 0.1
    repeat
image lizacicikozelrolnez6reszv2ciciszopanim:
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 1.2
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 1.2
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop1"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop4"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop3"
    pause 0.1
    "lizacicikozelrolnez6reszv2ciciszop2"
    pause 0.1
    repeat
image lizacicikozelrolnez6reszv2szajanim:
    "lizacicikozelrolnez6reszv2szaj1"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj5"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj3"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj2"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj4"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj6"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj2"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj5"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj1"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj3"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj6"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj5"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj2"
    pause 0.16
    "lizacicikozelrolnez6reszv2szaj4"
    pause 0.16
    repeat
image lizacicibasz7reszaanim:
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    repeat
image lizacicibasz7reszanim:
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1bmoz1"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz8"
    pause 0.084
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz10"
    pause 0.084
    "nap7f1bmoz1"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz8"
    pause 0.084
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz10"
    pause 0.084
    "nap7f1bmoz1"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz8"
    pause 0.084
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz10"
    pause 0.084
    "nap7f1bmoz1"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz8"
    pause 0.084
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz10"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1amoz1"
    pause 0.084
    "nap7f1amoz2"
    pause 0.084
    "nap7f1amoz3"
    pause 0.084
    "nap7f1amoz4"
    pause 0.084
    "nap7f1amoz5"
    pause 0.084
    "nap7f1amoz6"
    pause 0.084
    "nap7f1amoz7"
    pause 0.084
    "nap7f1bmoz1"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz8"
    pause 0.084
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz10"
    pause 0.084
    "nap7f1bmoz1"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz8"
    pause 0.084
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz10"
    pause 0.084
    "nap7f1bmoz1"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz8"
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz10"
    pause 0.084
    repeat
image lizacicibasz7reszbanim:
    "nap7f1bmoz1"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz8"
    pause 0.084
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz10"
    pause 0.084
    repeat
image lizacicibasz7reszbanimv2:
    "nap7f1bmoz10"
    pause 0.084
    "nap7f1bmoz9"
    pause 0.084
    "nap7f1bmoz8"
    pause 0.084
    "nap7f1bmoz7"
    pause 0.084
    "nap7f1bmoz6"
    pause 0.084
    "nap7f1bmoz5"
    pause 0.084
    "nap7f1bmoz4"
    pause 0.084
    "nap7f1bmoz3"
    pause 0.084
    "nap7f1bmoz2"
    pause 0.084
    "nap7f1bmoz1"
    pause 0.084
image lizacicibasz7reszszembanim:
    "nap7f1szemb1"
    pause 3.25
    "nap7f1szemb2"
    pause 0.125
    "nap7f1szemb3"
    pause 0.125
    "nap7f1szemb2"
    pause 0.125
    repeat
image lizacicibasz7reszszembroljanim:
    "nap7f1szemb1"
    pause 3.25
    "nap7f1szemb2"
    pause 0.125
    "nap7f1szemb3"
    pause 0.125
    "nap7f1szemj2"
    pause 0.125
    "nap7f1szemj1"
    pause 0.125
image lizacicibasz7reszszemjanim:
    "nap7f1szemj1"
    pause 3.25
    "nap7f1szemj2"
    pause 0.125
    "nap7f1szemj3"
    pause 0.125
    "nap7f1szemj2"
    pause 0.125
    repeat
image lizacicibasz7reszszemjanim2:
    "nap7f1szemj1"
    pause 3.25
    "nap7f1szemj2"
    pause 0.125
    "nap7f1szemj3"
    pause 0.125
image lizacicibasz7reszszemjanim3:
    "nap7f1szemj3"
    pause 0.125
    "nap7f1szemb2"
    pause 0.125
    "nap7f1szemb1"
    pause 0.125
image lizacicibasz7reszszemjrolbanim:
    "nap7f1szemj1"
    pause 3.25
    "nap7f1szemj2"
    pause 0.125
    "nap7f1szemj3"
    pause 0.125
    "nap7f1szemb2"
    pause 0.125
    "nap7f1szemb1"
    pause 0.125
image lizacicibasz7reszszajanim:
    "nap7f1szaj1"
    pause 0.16
    "nap7f1szaj5"
    pause 0.16
    "nap7f1szaj3"
    pause 0.16
    "nap7f1szaj6"
    pause 0.16
    "nap7f1szaj4"
    pause 0.16
    "nap7f1szaj1"
    pause 0.16
    "nap7f1szaj2"
    pause 0.16
    "nap7f1szaj5"
    pause 0.16
    "nap7f1szaj6"
    pause 0.16
    "nap7f1szaj3"
    pause 0.16
    "nap7f1szaj4"
    pause 0.16
    "nap7f1szaj5"
    pause 0.16
    "nap7f1szaj2"
    pause 0.16
    "nap7f1szaj4"
    pause 0.16
    repeat
image lizacicibaszpan7reszanim:
    "nap7f2moz1"
image lizacicibaszpangeci7reszanim:
    "nap7f2g-1"
    pause 0.884
    "nap7f2g-2"
    pause 0.084
    "nap7f2g-3"
    pause 0.084
    "nap7f2g-4"
    pause 0.084
    "nap7f2g-5"
    pause 0.084
    "nap7f2g-6"
    pause 0.084
    "nap7f2g-7"
    pause 0.084
    "nap7f2g-8"
    pause 0.084
    "nap7f2g-9"
    pause 0.084
    "nap7f2g-10"
    pause 0.084
    "nap7f2g-11"
    pause 0.084
    "nap7f2g-12"
    pause 0.084
    "nap7f2g-13"
    pause 0.084
    "nap7f2g-14"
    pause 0.084
    "nap7f2g-15"
    pause 0.084
    "nap7f2g-16"
    pause 0.084
    "nap7f2g-17"
    pause 0.084
    "nap7f2g-18"
    pause 0.084
    "nap7f2g-19"
    pause 0.084
    "nap7f2g-20"
    pause 0.084
    "nap7f2g-21"
    pause 0.084
    "nap7f2g-22"
    pause 0.084
    "nap7f2g-23"
    pause 0.084
    "nap7f2g-24"
    pause 0.084
    "nap7f2g-25"
    pause 0.084
    "nap7f2g-26"
    pause 0.084
    "nap7f2g-27"
    pause 0.084
    "nap7f2g-28"
    pause 0.084
    "nap7f2g-29"
    pause 0.084
    "nap7f2g-30"
    pause 0.084
    "nap7f2g-31"
    pause 0.084
    "nap7f2g-32"
    pause 0.084
image lizakeresalap1:
    "lizakeresalap"
image lizakeresalap2:
    "lizakeresalap"
image lizakeresanim1:
    "lizakeresmoz1"
    pause 0.525
    "lizakeresmoz2"
    pause 0.125
    "lizakeresmoz3"
    pause 0.125
    "lizakeresmoz4"
    pause 0.125
    "lizakeresmoz5"
    pause 0.125
    "lizakeresmoz6"
    pause 0.125
    "lizakeresmoz7"
    pause 0.725
    "lizakeresmoz6"
    pause 0.125
    "lizakeresmoz5"
    pause 0.125
    "lizakeresmoz4"
    pause 0.125
    "lizakeresmoz3"
    pause 0.125
    "lizakeresmoz2"
    pause 0.125
    repeat
image lizakeresanim2:
    "lizakeresmoz1"
    pause 0.525
    "lizakeresmoz2"
    pause 0.125
    "lizakeresmoz3"
    pause 0.125
    "lizakeresmoz4"
    pause 0.125
    "lizakeresmoz5"
    pause 0.125
    "lizakeresmoz6"
    pause 0.125
    "lizakeresmoz7"
    pause 0.725
    "lizakeresmoz6"
    pause 0.125
    "lizakeresmoz5"
    pause 0.125
    "lizakeresmoz4"
    pause 0.125
    "lizakeresmoz3"
    pause 0.125
    "lizakeresmoz2"
    pause 0.125
    repeat
image lizaszexresz8jel0szajanim:
    "lizaszexresz8jel0szaj1"
    pause 0.16
    "lizaszexresz8jel0szaj2"
    pause 0.16
    "lizaszexresz8jel0szaj4"
    pause 0.16
    "lizaszexresz8jel0szaj5"
    pause 0.16
    "lizaszexresz8jel0szaj1"
    pause 0.16
    "lizaszexresz8jel0szaj3"
    pause 0.16
    "lizaszexresz8jel0szaj2"
    pause 0.16
    "lizaszexresz8jel0szaj4"
    pause 0.16
    "lizaszexresz8jel0szaj1"
    pause 0.16
    "lizaszexresz8jel0szaj5"
    pause 0.16
    "lizaszexresz8jel0szaj3"
    pause 0.16
    "lizaszexresz8jel0szaj2"
    pause 0.16
    "lizaszexresz8jel0szaj4"
    pause 0.16
    "lizaszexresz8jel0szaj5"
    pause 0.16
    repeat
image lizaszexresz8jel0szemanim:
    "lizaszexresz8jel0szem1"
    pause 3.25
    "lizaszexresz8jel0szem2"
    pause 0.125
    "lizaszexresz8jel0szem3"
    pause 0.125
    "lizaszexresz8jel0szem2"
    pause 0.125
    repeat
image lizaszexresz8jel1segganim:
    "lizaszexresz8jel1segg1"
    pause 1.125
    "lizaszexresz8jel1segg2"
    pause 0.125
    "lizaszexresz8jel1segg3"
    pause 0.125
    "lizaszexresz8jel1segg4"
    pause 1.625
    "lizaszexresz8jel1segg3"
    pause 0.125
    "lizaszexresz8jel1segg2"
    pause 0.125
    repeat
image lizaszexresz8jel1szajanim:
    "lizaszexresz8jel1szaj1"
    pause 0.16
    "lizaszexresz8jel1szaj2"
    pause 0.16
    "lizaszexresz8jel1szaj4"
    pause 0.16
    "lizaszexresz8jel1szaj5"
    pause 0.16
    "lizaszexresz8jel1szaj1"
    pause 0.16
    "lizaszexresz8jel1szaj3"
    pause 0.16
    "lizaszexresz8jel1szaj2"
    pause 0.16
    "lizaszexresz8jel1szaj4"
    pause 0.16
    "lizaszexresz8jel1szaj1"
    pause 0.16
    "lizaszexresz8jel1szaj5"
    pause 0.16
    "lizaszexresz8jel1szaj3"
    pause 0.16
    "lizaszexresz8jel1szaj2"
    pause 0.16
    "lizaszexresz8jel1szaj4"
    pause 0.16
    "lizaszexresz8jel1szaj5"
    pause 0.16
    repeat
image lizaszexresz8jel2lizafejeanim:
    "lizaszexresz8jel2lizafejemoz1"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz2"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz3"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz4"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz5"
    pause 0.125
image lizaszexresz8jel2lizafejeanimfojamatos:
    "lizaszexresz8jel2lizafejemoz5"
    pause 3.125
    "lizaszexresz8jel2lizafejemoz4"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz3"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz2"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz1"
    pause 3.125
    "lizaszexresz8jel2lizafejemoz2"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz3"
    pause 0.125
    "lizaszexresz8jel2lizafejemoz4"
    pause 0.125
    repeat
image lizaszexresz8jel2lizafejeanimv2:
    "lizaszexresz8jel2lizafejemoz5"
    pause 0.084
    "lizaszexresz8jel2lizafejemoz4"
    pause 0.084
    "lizaszexresz8jel2lizafejemoz3"
    pause 0.084
    "lizaszexresz8jel2lizafejemoz2"
    pause 0.084
    "lizaszexresz8jel2lizafejemoz1"
    pause 0.084
image lizaszexresz8jel2lizafaszanim:
    "lizaszexresz8jel2lizafasz1"
    pause 0.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 0.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 0.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 0.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 0.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 0.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 1.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 0.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 1.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 0.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 0.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 1.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 0.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 1.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 1.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 1.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 1.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 1.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    "lizaszexresz8jel2lizafasz1"
    pause 1.125
    "lizaszexresz8jel2lizafasz2"
    pause 0.125
    "lizaszexresz8jel2lizafasz3"
    pause 0.125
    "lizaszexresz8jel2lizafasz4"
    pause 0.125
    "lizaszexresz8jel2lizafasz5"
    pause 1.125
    "lizaszexresz8jel2lizafasz6"
    pause 0.125
    "lizaszexresz8jel2lizafasz7"
    pause 0.125
    "lizaszexresz8jel2lizafasz8"
    pause 0.125
    repeat
image lizaszexresz8jel2lizafejemoz1szajanim:
    "lizaszexresz8jel2lizafejemoz1szaj1"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj2"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj5"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj4"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj3"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj1"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj5"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj4"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj2"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj1"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj3"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj5"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj4"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz1szaj3"
    pause 0.16
    repeat
image lizaszexresz8jel2lizafejemoz5szajanim:
    "lizaszexresz8jel2lizafejemoz5szaj1"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj2"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj5"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj4"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj3"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj1"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj5"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj4"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj2"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj1"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj3"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj5"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj4"
    pause 0.16
    "lizaszexresz8jel2lizafejemoz5szaj3"
    pause 0.16
    repeat
image lizaszexresz8jel4anim:
    "lizaszexresz8jel4moz1"
    pause 0.1
    "lizaszexresz8jel4moz2"
    pause 0.1
    "lizaszexresz8jel4moz3"
    pause 0.1
    "lizaszexresz8jel4moz4"
    pause 0.1
    "lizaszexresz8jel4moz5"
    pause 0.1
    "lizaszexresz8jel4moz6"
    pause 0.1
    repeat
image lizaszexresz8jel4leteszanim:
    "lizaszexresz8jel4moz1"
    pause 0.1
    "lizaszexresz8jel4moz2"
    pause 0.1
    "lizaszexresz8jel4moz3"
    pause 0.1
    "lizaszexresz8jel4moz4"
    pause 0.1
    "lizaszexresz8jel4moz5"
    pause 0.1
    "lizaszexresz8jel4moz6"
    pause 0.1
    "lizaszexresz8jel4leteszmoz1"
    pause 0.1
    "lizaszexresz8jel4leteszmoz2"
    pause 0.1
    "lizaszexresz8jel4leteszmoz3"
    pause 0.1
    "lizaszexresz8jel4leteszmoz4"
    pause 0.1
image lizaszexresz8jel4fojtattanim:
    "lizaszexresz8jel4leteszmoz4"
    pause 0.1
    "lizaszexresz8jel4leteszmoz3"
    pause 0.1
    "lizaszexresz8jel4leteszmoz2"
    pause 0.1
    "lizaszexresz8jel4leteszmoz1"
    pause 0.1
    "lizaszexresz8jel4moz2"
    pause 0.1
    "lizaszexresz8jel4moz3"
    pause 0.1
    "lizaszexresz8jel4moz4"
    pause 0.1
    "lizaszexresz8jel4moz5"
    pause 0.1
    "lizaszexresz8jel4moz6"
    pause 0.1
image lizaszexresz8jel5fiuanim:
    "lizaszexresz8jel5fiu1"
    pause 0.1
    "lizaszexresz8jel5fiu2"
    pause 0.1
    "lizaszexresz8jel5fiu3"
    pause 0.1
    "lizaszexresz8jel5fiu4"
    pause 0.1
    "lizaszexresz8jel5fiu5"
    pause 0.1
    "lizaszexresz8jel5fiu6"
    pause 0.1
    "lizaszexresz8jel5fiu1"
    pause 0.1
    "lizaszexresz8jel5fiu2"
    pause 0.1
    "lizaszexresz8jel5fiu3"
    pause 0.1
    "lizaszexresz8jel5fiu4"
    pause 0.1
    "lizaszexresz8jel5fiu5"
    pause 0.1
    "lizaszexresz8jel5fiu6"
    pause 0.1
    "lizaszexresz8jel5fiu1"
    pause 0.1
    "lizaszexresz8jel5fiu2"
    pause 0.1
    "lizaszexresz8jel5fiu3"
    pause 0.1
    "lizaszexresz8jel5fiu4"
    pause 0.1
    "lizaszexresz8jel5fiu5"
    pause 0.1
    "lizaszexresz8jel5fiu6"
    pause 0.1
    "lizaszexresz8jel5fiu1"
    pause 0.1
    "lizaszexresz8jel5fiu2"
    pause 0.1
    "lizaszexresz8jel5fiu3"
    pause 0.1
    "lizaszexresz8jel5fiu4"
    pause 0.1
    "lizaszexresz8jel5fiu5"
    pause 0.1
    "lizaszexresz8jel5fiu6"
    pause 0.1
    "lizaszexresz8jel5fiu1"
    pause 0.1
    "lizaszexresz8jel5fiu2"
    pause 0.1
    "lizaszexresz8jel5fiu3"
    pause 0.1
    "lizaszexresz8jel5fiu4"
    pause 0.1
    "lizaszexresz8jel5fiu5"
    pause 0.1
    "lizaszexresz8jel5fiu6"
    pause 0.1
    "lizaszexresz8jel5fiu1"
    pause 0.1
    "lizaszexresz8jel5fiu2"
    pause 0.1
    "lizaszexresz8jel5fiu3"
    pause 0.1
    "lizaszexresz8jel5fiu4"
    pause 0.1
    "lizaszexresz8jel5fiu5"
    pause 0.1
    "lizaszexresz8jel5fiu6"
    pause 0.1
    "lizaszexresz8jel5fiu1"
    pause 0.1
    "lizaszexresz8jel5fiu2"
    pause 0.1
    "lizaszexresz8jel5fiu3"
    pause 0.1
    "lizaszexresz8jel5fiu4"
    pause 0.1
    "lizaszexresz8jel5fiu5"
    pause 0.1
    "lizaszexresz8jel5fiu6"
    pause 0.1
    "lizaszexresz8jel5fiu1"
    pause 0.1
    "lizaszexresz8jel5fiu2"
    pause 0.1
    "lizaszexresz8jel5fiu3"
    pause 0.1
    "lizaszexresz8jel5fiu4"
    pause 0.1
    "lizaszexresz8jel5fiu5"
    pause 0.1
    "lizaszexresz8jel5fiu6"
    pause 0.1
    "lizaszexresz8jel5fiu1"
    pause 0.084
    "lizaszexresz8jel5fiu2"
    pause 0.084
    "lizaszexresz8jel5fiu3"
    pause 0.084
    "lizaszexresz8jel5fiu4"
    pause 0.084
    "lizaszexresz8jel5fiu5"
    pause 0.084
    "lizaszexresz8jel5fiu6"
    pause 0.084
    "lizaszexresz8jel5fiu1"
    pause 0.084
    "lizaszexresz8jel5fiu2"
    pause 0.084
    "lizaszexresz8jel5fiu3"
    pause 0.084
    "lizaszexresz8jel5fiu4"
    pause 0.084
    "lizaszexresz8jel5fiu5"
    pause 0.084
    "lizaszexresz8jel5fiu6"
    pause 0.084
    "lizaszexresz8jel5fiu1"
    pause 0.084
    "lizaszexresz8jel5fiu2"
    pause 0.084
    "lizaszexresz8jel5fiu3"
    pause 0.084
    "lizaszexresz8jel5fiu4"
    pause 0.084
    "lizaszexresz8jel5fiu5"
    pause 0.084
    "lizaszexresz8jel5fiu6"
    pause 0.084
    "lizaszexresz8jel5fiu1"
    pause 0.084
    "lizaszexresz8jel5fiu2"
    pause 0.084
    "lizaszexresz8jel5fiu3"
    pause 0.084
    "lizaszexresz8jel5fiu4"
    pause 0.084
    "lizaszexresz8jel5fiu5"
    pause 0.084
    "lizaszexresz8jel5fiu6"
    pause 0.084
    "lizaszexresz8jel5fiu1"
    pause 0.084
    "lizaszexresz8jel5fiu2"
    pause 0.084
    "lizaszexresz8jel5fiu3"
    pause 0.084
    "lizaszexresz8jel5fiu4"
    pause 0.084
    "lizaszexresz8jel5fiu5"
    pause 0.084
    "lizaszexresz8jel5fiu6"
    pause 0.084
    "lizaszexresz8jel5fiu1"
    pause 0.084
    "lizaszexresz8jel5fiu2"
    pause 0.084
    "lizaszexresz8jel5fiu3"
    pause 0.084
    "lizaszexresz8jel5fiu4"
    pause 0.084
    "lizaszexresz8jel5fiu5"
    pause 0.084
    "lizaszexresz8jel5fiu6"
    pause 0.084
    "lizaszexresz8jel5fiu1"
    pause 0.084
    "lizaszexresz8jel5fiu2"
    pause 0.084
    "lizaszexresz8jel5fiu3"
    pause 0.084
    "lizaszexresz8jel5fiu4"
    pause 0.084
    "lizaszexresz8jel5fiu5"
    pause 0.084
    "lizaszexresz8jel5fiu6"
    pause 0.084
    repeat
image lizaszexresz8jel5noanim:
    "lizaszexresz8jel5no1"
    pause 0.1
    "lizaszexresz8jel5no2"
    pause 0.1
    "lizaszexresz8jel5no3"
    pause 0.1
    "lizaszexresz8jel5no4"
    pause 0.1
    "lizaszexresz8jel5no5"
    pause 0.1
image lizaszexresz8jel5noanim2:
    "lizaszexresz8jel5no5"
    pause 0.1
    "lizaszexresz8jel5no4"
    pause 0.1
    "lizaszexresz8jel5no3"
    pause 0.1
    "lizaszexresz8jel5no2"
    pause 0.1
    "lizaszexresz8jel5no1"
    pause 0.1
image lizaszexresz8jel6remeg:
    "lizaszexresz8jel6remegv1"
    pause 0.1
    "lizaszexresz8jel6remegv2"
    pause 0.1
    repeat
image lizaszexresz8jel6gecisszajanim:
    "lizaszexresz8jel6gecisszaj1"
    pause 0.16
    "lizaszexresz8jel6gecisszaj1"
    pause 0.16
    "lizaszexresz8jel6gecisszaj1"
    pause 0.16
    "lizaszexresz8jel6gecisszaj3"
    pause 0.16
    "lizaszexresz8jel6gecisszaj5"
    pause 0.16
    "lizaszexresz8jel6gecisszaj4"
    pause 0.16
    "lizaszexresz8jel6gecisszaj2"
    pause 0.16
    "lizaszexresz8jel6gecisszaj3"
    pause 0.16
    "lizaszexresz8jel6gecisszaj2"
    pause 0.16
    "lizaszexresz8jel6gecisszaj1"
    pause 0.16
    "lizaszexresz8jel6gecisszaj4"
    pause 0.16
    "lizaszexresz8jel6gecisszaj5"
    pause 0.16
    repeat
image lizaszexresz8jel6gecisszemanim:
    "lizaszexresz8jel6gecisszem1"
    pause 3.25
    "lizaszexresz8jel6gecisszem2"
    pause 0.125
    "lizaszexresz8jel6gecisszem3"
    pause 0.125
    "lizaszexresz8jel6gecisszem2"
    pause 0.125
    repeat
image lizaszexresz8jel6gecianim:
    "lizaszexresz8jel6geci1"
    pause 0.8
    "lizaszexresz8jel6geci2"
    pause 0.1
    "lizaszexresz8jel6geci3"
    pause 0.1
    "lizaszexresz8jel6geci4"
    pause 0.1
    "lizaszexresz8jel6geci5"
    pause 0.1
    "lizaszexresz8jel6geci6"
    pause 0.1
    "lizaszexresz8jel6geci7"
    pause 0.1
    "lizaszexresz8jel6geci8"
    pause 0.1
    "lizaszexresz8jel6geci9"
    pause 0.1
    "lizaszexresz8jel6geci10"
    pause 0.1
    "lizaszexresz8jel6geci11"
    pause 0.1
    "lizaszexresz8jel6geci12"
    pause 0.1
    "lizaszexresz8jel6geci13"
    pause 0.1
    "lizaszexresz8jel6geci14"
    pause 0.1
    "lizaszexresz8jel6geci15"
    pause 0.1
image lizanagybeszeleloszajanim:
    "lizanagybeszeleloszaj1"
    pause 0.16
    "lizanagybeszeleloszaj4"
    pause 0.16
    "lizanagybeszeleloszaj3"
    pause 0.16
    "lizanagybeszeleloszaj2"
    pause 0.16
    "lizanagybeszeleloszaj5"
    pause 0.16
    "lizanagybeszeleloszaj3"
    pause 0.16
    "lizanagybeszeleloszaj5"
    pause 0.16
    "lizanagybeszeleloszaj1"
    pause 0.16
    "lizanagybeszeleloszaj3"
    pause 0.16
    "lizanagybeszeleloszaj5"
    pause 0.16
    "lizanagybeszeleloszaj4"
    pause 0.16
    "lizanagybeszeleloszaj2"
    pause 0.16
    "lizanagybeszeleloszaj4"
    pause 0.16
    "lizanagybeszeleloszaj3"
    pause 0.16
    "lizanagybeszeleloszaj5"
    pause 0.16
    repeat
image lizanagybeszeleloszemanim:
    "lizanagybeszeleloszem1"
    pause 3.25
    "lizanagybeszeleloszem2"
    pause 0.125
    "lizanagybeszeleloszem3"
    pause 0.125
    "lizanagybeszeleloszem2"
    pause 0.125
    repeat
image lizanagybeszeleloanim:
    "lizanagybeszelelomoz1"
    pause 0.125
    "lizanagybeszelelomoz2"
    pause 0.125
    "lizanagybeszelelomoz3"
    pause 0.125
    "lizanagybeszelelomoz4"
    pause 0.125
    "lizanagybeszelelomoz5"
    pause 0.125
    "lizanagybeszelelomoz4"
    pause 0.125
    "lizanagybeszelelomoz3"
    pause 0.125
    "lizanagybeszelelomoz2"
    pause 0.125
    "lizanagybeszelelomoz1"
    pause 0.125
    "lizanagybeszelelomoz2"
    pause 0.125
    "lizanagybeszelelomoz3"
    pause 0.125
    "lizanagybeszelelomoz4"
    pause 0.125
    "lizanagybeszelelomoz5"
    pause 0.125
    "lizanagybeszelelomoz4"
    pause 0.125
    "lizanagybeszelelomoz3"
    pause 0.125
    "lizanagybeszelelomoz2"
    pause 0.125
    "lizanagybeszelelomoz1"
    pause 4.0
    "lizanagybeszelelomoz2"
    pause 0.125
    "lizanagybeszelelomoz3"
    pause 0.125
    "lizanagybeszelelomoz4"
    pause 0.125
    "lizanagybeszelelomoz5"
    pause 4.0
    "lizanagybeszelelomoz4"
    pause 0.125
    "lizanagybeszelelomoz3"
    pause 0.125
    "lizanagybeszelelomoz2"
    pause 0.125
    "lizanagybeszelelomoz1"
    pause 0.125
    "lizanagybeszelelomoz2"
    pause 0.125
    "lizanagybeszelelomoz3"
    pause 0.125
    "lizanagybeszelelomoz4"
    pause 0.125
    "lizanagybeszelelomoz5"
    pause 0.125
    "lizanagybeszelelomoz4"
    pause 0.125
    "lizanagybeszelelomoz3"
    pause 0.125
    "lizanagybeszelelomoz2"
    pause 0.125
    "lizanagybeszelelomoz1"
    pause 0.125


image lizaszex12napjelenetremeg:
    "lizaszex12napjelenet4fredv2"
    pause 0.2
    "lizaszex12napjelenet4fredv3"
    pause 0.2
    repeat
image lizaszex12napjelenet4fredgyors:
    "lizaszex12napjelenet4fredv1"
    pause 0.125
    "lizaszex12napjelenet4fredv2"
    pause 0.125
    "lizaszex12napjelenet4fredv3"
    pause 0.125
    "lizaszex12napjelenet4fredv4"
    pause 0.125
    "lizaszex12napjelenet4fredv5"
    pause 0.125
    "lizaszex12napjelenet4fredv6"
    pause 0.125
    "lizaszex12napjelenet4fredv1"
    pause 0.125
    "lizaszex12napjelenet4fredv2"
    pause 0.125
    "lizaszex12napjelenet4fredv3"
    pause 0.125
    "lizaszex12napjelenet4fredv4"
    pause 0.125
    "lizaszex12napjelenet4fredv5"
    pause 0.125
    "lizaszex12napjelenet4fredv6"
    pause 0.125
    "lizaszex12napjelenet4fredv1"
    pause 0.125
    "lizaszex12napjelenet4fredv2"
    pause 0.125
    "lizaszex12napjelenet4fredv3"
    pause 0.125
    "lizaszex12napjelenet4fredv4"
    pause 0.125
    "lizaszex12napjelenet4fredv5"
    pause 0.125
    "lizaszex12napjelenet4fredv6"
    pause 0.125
    "lizaszex12napjelenet4fredv1"
    pause 0.125
    "lizaszex12napjelenet4fredv2"
    pause 0.125
    "lizaszex12napjelenet4fredv3"
    pause 0.125
    "lizaszex12napjelenet4fredv4"
    pause 0.125
    "lizaszex12napjelenet4fredv5"
    pause 0.125
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    repeat
image lizaszex12napjelenet4fredlassub:
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.125
    "lizaszex12napjelenet4fredv3"
    pause 0.125
    "lizaszex12napjelenet4fredv4"
    pause 0.125
    "lizaszex12napjelenet4fredv5"
    pause 0.125
    "lizaszex12napjelenet4fredv6"
    pause 0.125
    "lizaszex12napjelenet4fredv7"
    pause 0.125
    "lizaszex12napjelenet4fredv1"
    pause 0.125
    "lizaszex12napjelenet4fredv2"
    pause 0.125
    "lizaszex12napjelenet4fredv3"
    pause 0.125
    "lizaszex12napjelenet4fredv4"
    pause 0.125
    "lizaszex12napjelenet4fredv5"
    pause 0.125
    "lizaszex12napjelenet4fredv6"
    pause 0.125
    "lizaszex12napjelenet4fredv7"
    pause 0.125
    "lizaszex12napjelenet4fredv1"
    pause 0.125
    "lizaszex12napjelenet4fredv2"
    pause 0.125
    "lizaszex12napjelenet4fredv3"
    pause 0.125
    "lizaszex12napjelenet4fredv4"
    pause 0.125
    "lizaszex12napjelenet4fredv5"
    pause 0.125
    "lizaszex12napjelenet4fredv6"
    pause 0.125
    "lizaszex12napjelenet4fredv7"
    pause 0.125
    "lizaszex12napjelenet4fredv1"
    pause 0.125
    "lizaszex12napjelenet4fredv2"
    pause 0.125
    "lizaszex12napjelenet4fredv3"
    pause 0.125
    "lizaszex12napjelenet4fredv4"
    pause 0.125
    "lizaszex12napjelenet4fredv5"
    pause 0.125
    "lizaszex12napjelenet4fredv6"
    pause 0.125
    "lizaszex12napjelenet4fredv7"
    pause 0.125
    "lizaszex12napjelenet4fredv1"
    pause 0.125
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv1"
    pause 0.084
    "lizaszex12napjelenet4fredv2"
    pause 0.084
    "lizaszex12napjelenet4fredv3"
    pause 0.084
    "lizaszex12napjelenet4fredv4"
    pause 0.084
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    repeat
image lizaszex12napjelenet4fredgyorsabb:
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv8"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv8"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.1
    "lizaszex12napjelenet4fredv2"
    pause 0.1
    "lizaszex12napjelenet4fredv3"
    pause 0.1
    "lizaszex12napjelenet4fredv4"
    pause 0.1
    "lizaszex12napjelenet4fredv5"
    pause 0.1
    "lizaszex12napjelenet4fredv6"
    pause 0.1
    "lizaszex12napjelenet4fredv7"
    pause 0.1
    "lizaszex12napjelenet4fredv8"
    pause 0.1
    "lizaszex12napjelenet4fredv1"
    pause 0.084
    "lizaszex12napjelenet4fredv2"
    pause 0.084
    "lizaszex12napjelenet4fredv3"
    pause 0.084
    "lizaszex12napjelenet4fredv4"
    pause 0.084
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv8"
    pause 0.084
    "lizaszex12napjelenet4fredv1"
    pause 0.084
    "lizaszex12napjelenet4fredv2"
    pause 0.084
    "lizaszex12napjelenet4fredv3"
    pause 0.084
    "lizaszex12napjelenet4fredv4"
    pause 0.084
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv8"
    pause 0.084
    "lizaszex12napjelenet4fredv1"
    pause 0.084
    "lizaszex12napjelenet4fredv2"
    pause 0.084
    "lizaszex12napjelenet4fredv3"
    pause 0.084
    "lizaszex12napjelenet4fredv4"
    pause 0.084
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv8"
    pause 0.084
    "lizaszex12napjelenet4fredv1"
    pause 0.084
    "lizaszex12napjelenet4fredv2"
    pause 0.084
    "lizaszex12napjelenet4fredv3"
    pause 0.084
    "lizaszex12napjelenet4fredv4"
    pause 0.084
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv8"
    pause 0.084
    "lizaszex12napjelenet4fredv1"
    pause 0.084
    "lizaszex12napjelenet4fredv2"
    pause 0.084
    "lizaszex12napjelenet4fredv3"
    pause 0.084
    "lizaszex12napjelenet4fredv4"
    pause 0.084
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv8"
    pause 0.084
    "lizaszex12napjelenet4fredv1"
    pause 0.067
    "lizaszex12napjelenet4fredv2"
    pause 0.067
    "lizaszex12napjelenet4fredv3"
    pause 0.067
    "lizaszex12napjelenet4fredv4"
    pause 0.067
    "lizaszex12napjelenet4fredv5"
    pause 0.067
    "lizaszex12napjelenet4fredv6"
    pause 0.067
    "lizaszex12napjelenet4fredv7"
    pause 0.067
    "lizaszex12napjelenet4fredv8"
    pause 0.067
    "lizaszex12napjelenet4fredv1"
    pause 0.067
    "lizaszex12napjelenet4fredv2"
    pause 0.067
    "lizaszex12napjelenet4fredv3"
    pause 0.067
    "lizaszex12napjelenet4fredv4"
    pause 0.067
    "lizaszex12napjelenet4fredv5"
    pause 0.067
    "lizaszex12napjelenet4fredv6"
    pause 0.067
    "lizaszex12napjelenet4fredv7"
    pause 0.067
    "lizaszex12napjelenet4fredv8"
    pause 0.067
    "lizaszex12napjelenet4fredv1"
    pause 0.067
    "lizaszex12napjelenet4fredv2"
    pause 0.067
    "lizaszex12napjelenet4fredv3"
    pause 0.067
    "lizaszex12napjelenet4fredv4"
    pause 0.067
    "lizaszex12napjelenet4fredv5"
    pause 0.067
    "lizaszex12napjelenet4fredv6"
    pause 0.067
    "lizaszex12napjelenet4fredv7"
    pause 0.067
    "lizaszex12napjelenet4fredv8"
    pause 0.067
    "lizaszex12napjelenet4fredv1"
    pause 0.067
    "lizaszex12napjelenet4fredv2"
    pause 0.067
    "lizaszex12napjelenet4fredv3"
    pause 0.067
    "lizaszex12napjelenet4fredv4"
    pause 0.067
    "lizaszex12napjelenet4fredv5"
    pause 0.067
    "lizaszex12napjelenet4fredv6"
    pause 0.067
    "lizaszex12napjelenet4fredv7"
    pause 0.067
    "lizaszex12napjelenet4fredv8"
    pause 0.067
    "lizaszex12napjelenet4fredv1"
    pause 0.067
    "lizaszex12napjelenet4fredv2"
    pause 0.067
    "lizaszex12napjelenet4fredv3"
    pause 0.067
    "lizaszex12napjelenet4fredv4"
    pause 0.067
    "lizaszex12napjelenet4fredv5"
    pause 0.067
    "lizaszex12napjelenet4fredv6"
    pause 0.067
    "lizaszex12napjelenet4fredv7"
    pause 0.067
    "lizaszex12napjelenet4fredv8"
    pause 0.067
    "lizaszex12napjelenet4fredv1"
    pause 0.067
    "lizaszex12napjelenet4fredv2"
    pause 0.067
    "lizaszex12napjelenet4fredv3"
    pause 0.067
    "lizaszex12napjelenet4fredv4"
    pause 0.067
    "lizaszex12napjelenet4fredv5"
    pause 0.067
    "lizaszex12napjelenet4fredv6"
    pause 0.067
    "lizaszex12napjelenet4fredv7"
    pause 0.067
    "lizaszex12napjelenet4fredv8"
    pause 0.067
    "lizaszex12napjelenet4fredv1"
    pause 0.067
    "lizaszex12napjelenet4fredv2"
    pause 0.067
    "lizaszex12napjelenet4fredv3"
    pause 0.067
    "lizaszex12napjelenet4fredv4"
    pause 0.067
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv8"
    pause 0.084
    "lizaszex12napjelenet4fredv1"
    pause 0.084
    "lizaszex12napjelenet4fredv2"
    pause 0.084
    "lizaszex12napjelenet4fredv3"
    pause 0.084
    "lizaszex12napjelenet4fredv4"
    pause 0.084
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv8"
    pause 0.084
    "lizaszex12napjelenet4fredv1"
    pause 0.084
    "lizaszex12napjelenet4fredv2"
    pause 0.084
    "lizaszex12napjelenet4fredv3"
    pause 0.084
    "lizaszex12napjelenet4fredv4"
    pause 0.084
    "lizaszex12napjelenet4fredv5"
    pause 0.084
    "lizaszex12napjelenet4fredv6"
    pause 0.084
    "lizaszex12napjelenet4fredv7"
    pause 0.084
    "lizaszex12napjelenet4fredv8"
    pause 0.084
    repeat
image lizaszex12napjelenet4fredgyorsabb2:
    "lizaszex12napjelenet4fredv1"
    pause 0.067
    "lizaszex12napjelenet4fredv2"
    pause 0.067
    "lizaszex12napjelenet4fredv3"
    pause 0.067
    "lizaszex12napjelenet4fredv4"
    pause 0.067
    "lizaszex12napjelenet4fredv5"
    pause 0.067
    "lizaszex12napjelenet4fredv6"
    pause 0.067
    "lizaszex12napjelenet4fredv7"
    pause 0.067
    "lizaszex12napjelenet4fredv8"
    pause 0.067
    repeat
image lizaszex12napjelenet4lizav1szemanim:
    "lizaszex12napjelenet4lizav1szem1"
    pause 3.25
    "lizaszex12napjelenet4lizav1szem2"
    pause 0.125
    "lizaszex12napjelenet4lizav1szem3"
    pause 0.125
    "lizaszex12napjelenet4lizav1szem2"
    pause 0.125
    repeat
image lizaszex12napjelenet4lizav1szajanim:
    "lizaszex12napjelenet4lizav1szaj1"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj4"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj3"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj2"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj5"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj3"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj5"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj1"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj3"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj5"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj4"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj2"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj4"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj3"
    pause 0.16
    "lizaszex12napjelenet4lizav1szaj5"
    pause 0.16
    repeat
image lizaszex12napjelenet4lizav6szajanim:
    "lizaszex12napjelenet4lizav6szaj1"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj4"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj3"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj2"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj5"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj3"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj5"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj1"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj3"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj5"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj4"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj2"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj4"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj3"
    pause 0.16
    "lizaszex12napjelenet4lizav6szaj5"
    pause 0.16
    repeat
image lizaszex12napjelenet4lizavfel:
    "lizaszex12napjelenet4lizav1"
    pause 0.1
    "lizaszex12napjelenet4lizav2"
    pause 0.1
    "lizaszex12napjelenet4lizav3"
    pause 0.1
    "lizaszex12napjelenet4lizav4"
    pause 0.1
    "lizaszex12napjelenet4lizav5"
    pause 0.1
    "lizaszex12napjelenet4lizav6"
    pause 0.1
image lizaszex12napjelenet4lizavle:
    "lizaszex12napjelenet4lizav6"
    pause 0.1
    "lizaszex12napjelenet4lizav5"
    pause 0.1
    "lizaszex12napjelenet4lizav4"
    pause 0.1
    "lizaszex12napjelenet4lizav3"
    pause 0.1
    "lizaszex12napjelenet4lizav2"
    pause 0.1
    "lizaszex12napjelenet4lizav1"
    pause 0.1
image lizaszex12napjelenet6lizavfel:
    "lizaszex12napjelenet6lizav1"
    pause 0.1
    "lizaszex12napjelenet6lizav2"
    pause 0.1
    "lizaszex12napjelenet6lizav3"
    pause 0.1
    "lizaszex12napjelenet6lizav4"
    pause 0.1
    "lizaszex12napjelenet6lizav5"
    pause 0.1
    "lizaszex12napjelenet6lizav6"
    pause 0.1
image lizaszex12napjelenet6lizavfle:
    "lizaszex12napjelenet6lizav6"
    pause 0.1
    "lizaszex12napjelenet6lizav5"
    pause 0.1
    "lizaszex12napjelenet6lizav4"
    pause 0.1
    "lizaszex12napjelenet6lizav3"
    pause 0.1
    "lizaszex12napjelenet6lizav2"
    pause 0.1
    "lizaszex12napjelenet6lizav1"
    pause 0.1
image lizaszex12napjelenet6lizav1szemanim:
    "lizaszex12napjelenet6lizav1szem1"
    pause 3.25
    "lizaszex12napjelenet6lizav1szem2"
    pause 0.125
    "lizaszex12napjelenet6lizav1szem3"
    pause 0.125
    "lizaszex12napjelenet6lizav1szem2"
    pause 0.125
    repeat
image lizaszex12napjelenet6lizav1szajanim:
    "lizaszex12napjelenet6lizav1szaj1"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj4"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj3"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj2"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj5"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj3"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj5"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj1"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj3"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj5"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj4"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj2"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj4"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj3"
    pause 0.16
    "lizaszex12napjelenet6lizav1szaj5"
    pause 0.16
    repeat
image lizaszex12napjelenet6lizav6szajanim:
    "lizaszex12napjelenet6lizav6szaj1"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj4"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj3"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj2"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj5"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj3"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj5"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj1"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj3"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj5"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj4"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj2"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj4"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj3"
    pause 0.16
    "lizaszex12napjelenet6lizav6szaj5"
    pause 0.16
    repeat
image lizaszex12napjelenet6fredvgyors:
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    repeat
image lizaszex12napjelenet6fredvlassub:
    "lizaszex12napjelenet6fredv1"
    pause 0.1
    "lizaszex12napjelenet6fredv2"
    pause 0.1
    "lizaszex12napjelenet6fredv3"
    pause 0.1
    "lizaszex12napjelenet6fredv4"
    pause 0.1
    "lizaszex12napjelenet6fredv5"
    pause 0.1
    "lizaszex12napjelenet6fredv6"
    pause 0.1
    "lizaszex12napjelenet6fredv7"
    pause 0.1
    "lizaszex12napjelenet6fredv1"
    pause 0.1
    "lizaszex12napjelenet6fredv2"
    pause 0.1
    "lizaszex12napjelenet6fredv3"
    pause 0.1
    "lizaszex12napjelenet6fredv4"
    pause 0.1
    "lizaszex12napjelenet6fredv5"
    pause 0.1
    "lizaszex12napjelenet6fredv6"
    pause 0.1
    "lizaszex12napjelenet6fredv7"
    pause 0.1
    "lizaszex12napjelenet6fredv1"
    pause 0.1
    "lizaszex12napjelenet6fredv2"
    pause 0.1
    "lizaszex12napjelenet6fredv3"
    pause 0.1
    "lizaszex12napjelenet6fredv4"
    pause 0.1
    "lizaszex12napjelenet6fredv5"
    pause 0.1
    "lizaszex12napjelenet6fredv6"
    pause 0.1
    "lizaszex12napjelenet6fredv7"
    pause 0.1
    "lizaszex12napjelenet6fredv1"
    pause 0.1
    "lizaszex12napjelenet6fredv2"
    pause 0.1
    "lizaszex12napjelenet6fredv3"
    pause 0.1
    "lizaszex12napjelenet6fredv4"
    pause 0.1
    "lizaszex12napjelenet6fredv5"
    pause 0.1
    "lizaszex12napjelenet6fredv6"
    pause 0.1
    "lizaszex12napjelenet6fredv7"
    pause 0.1
    "lizaszex12napjelenet6fredv1"
    pause 0.1
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.1
    "lizaszex12napjelenet6fredv7"
    pause 0.1
    repeat
image lizaszex12napjelenet6fredvgyorsabb:
    "lizaszex12napjelenet6fredv1"
    pause 0.1
    "lizaszex12napjelenet6fredv2"
    pause 0.1
    "lizaszex12napjelenet6fredv3"
    pause 0.1
    "lizaszex12napjelenet6fredv4"
    pause 0.1
    "lizaszex12napjelenet6fredv5"
    pause 0.1
    "lizaszex12napjelenet6fredv6"
    pause 0.1
    "lizaszex12napjelenet6fredv7"
    pause 0.1
    "lizaszex12napjelenet6fredv8"
    pause 0.1
    "lizaszex12napjelenet6fredv1"
    pause 0.1
    "lizaszex12napjelenet6fredv2"
    pause 0.1
    "lizaszex12napjelenet6fredv3"
    pause 0.1
    "lizaszex12napjelenet6fredv4"
    pause 0.1
    "lizaszex12napjelenet6fredv5"
    pause 0.1
    "lizaszex12napjelenet6fredv6"
    pause 0.1
    "lizaszex12napjelenet6fredv7"
    pause 0.1
    "lizaszex12napjelenet6fredv8"
    pause 0.1
    "lizaszex12napjelenet6fredv1"
    pause 0.1
    "lizaszex12napjelenet6fredv2"
    pause 0.1
    "lizaszex12napjelenet6fredv3"
    pause 0.1
    "lizaszex12napjelenet6fredv4"
    pause 0.1
    "lizaszex12napjelenet6fredv5"
    pause 0.1
    "lizaszex12napjelenet6fredv6"
    pause 0.1
    "lizaszex12napjelenet6fredv7"
    pause 0.1
    "lizaszex12napjelenet6fredv8"
    pause 0.1
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv8"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv8"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv8"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv8"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv8"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv8"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv8"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv8"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv8"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv8"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv8"
    pause 0.067
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv8"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv8"
    pause 0.084
    "lizaszex12napjelenet6fredv1"
    pause 0.084
    "lizaszex12napjelenet6fredv2"
    pause 0.084
    "lizaszex12napjelenet6fredv3"
    pause 0.084
    "lizaszex12napjelenet6fredv4"
    pause 0.084
    "lizaszex12napjelenet6fredv5"
    pause 0.084
    "lizaszex12napjelenet6fredv6"
    pause 0.084
    "lizaszex12napjelenet6fredv7"
    pause 0.084
    "lizaszex12napjelenet6fredv8"
    pause 0.084
    repeat
image lizaszex12napjelenet6fredvgyorsabb2:
    "lizaszex12napjelenet6fredv1"
    pause 0.067
    "lizaszex12napjelenet6fredv2"
    pause 0.067
    "lizaszex12napjelenet6fredv3"
    pause 0.067
    "lizaszex12napjelenet6fredv4"
    pause 0.067
    "lizaszex12napjelenet6fredv5"
    pause 0.067
    "lizaszex12napjelenet6fredv6"
    pause 0.067
    "lizaszex12napjelenet6fredv7"
    pause 0.067
    "lizaszex12napjelenet6fredv8"
    pause 0.067
    repeat
image lizaszex12napjelenet5vanim:
    "lizaszex12napjelenet5v1"
    pause 0.1
    "lizaszex12napjelenet5v2"
    pause 0.1
    "lizaszex12napjelenet5v3"
    pause 0.1
    "lizaszex12napjelenet5v4"
    pause 0.1
    "lizaszex12napjelenet5v3"
    pause 0.1
    "lizaszex12napjelenet5v2"
    pause 0.1
    "lizaszex12napjelenet5v1"
    pause 0.1
    "lizaszex12napjelenet5v2"
    pause 0.1
    "lizaszex12napjelenet5v3"
    pause 0.1
    "lizaszex12napjelenet5v4"
    pause 0.1
    "lizaszex12napjelenet5v3"
    pause 0.1
    "lizaszex12napjelenet5v2"
    pause 0.1
    "lizaszex12napjelenet5v1"
    pause 0.1
    "lizaszex12napjelenet5v2"
    pause 0.1
    "lizaszex12napjelenet5v3"
    pause 0.1
    "lizaszex12napjelenet5v4"
    pause 0.1
    "lizaszex12napjelenet5v3"
    pause 0.1
    "lizaszex12napjelenet5v2"
    pause 0.1
    "lizaszex12napjelenet5v1"
    pause 0.1
image lizaszex12napjelenet5szemanim:
    "lizaszex12napjelenet5szem1"
    pause 3.25
    "lizaszex12napjelenet5szem2"
    pause 0.125
    "lizaszex12napjelenet5szem3"
    pause 0.125
    "lizaszex12napjelenet5szem2"
    pause 0.125
    repeat
image lizaszex12napjelenet5szajanim:
    "lizaszex12napjelenet5szaj1"
    pause 0.16
    "lizaszex12napjelenet5szaj4"
    pause 0.16
    "lizaszex12napjelenet5szaj3"
    pause 0.16
    "lizaszex12napjelenet5szaj2"
    pause 0.16
    "lizaszex12napjelenet5szaj5"
    pause 0.16
    "lizaszex12napjelenet5szaj3"
    pause 0.16
    "lizaszex12napjelenet5szaj5"
    pause 0.16
    "lizaszex12napjelenet5szaj1"
    pause 0.16
    "lizaszex12napjelenet5szaj3"
    pause 0.16
    "lizaszex12napjelenet5szaj5"
    pause 0.16
    "lizaszex12napjelenet5szaj4"
    pause 0.16
    "lizaszex12napjelenet5szaj2"
    pause 0.16
    "lizaszex12napjelenet5szaj4"
    pause 0.16
    "lizaszex12napjelenet5szaj3"
    pause 0.16
    "lizaszex12napjelenet5szaj5"
    pause 0.16
    repeat
image lizaszex12napjelenet5vanimgeci:
    "l3geci-1"
    pause 0.1
    "l3geci-2"
    pause 0.1
    "l3geci-3"
    pause 0.1
    "l3geci-4"
    pause 0.1
    "l3geci-5"
    pause 0.1
    "l3geci-6"
    pause 0.1
    "l3geci-7"
    pause 0.1
    "l3geci-8"
    pause 0.1
    "l3geci-9"
    pause 0.1
    "l3geci-10"
    pause 0.1
    "l3geci-11"
    pause 0.1
    "l3geci-12"
    pause 0.1
    "l3geci-13"
    pause 0.1
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
