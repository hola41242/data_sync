image ritafaszszopasjelenet1szemanim:
    "ritafaszszopasjelenet1szem1"
    pause 3.0
    "ritafaszszopasjelenet1szem2"
    pause 0.1
    "ritafaszszopasjelenet1szem3"
    pause 0.1
    "ritafaszszopasjelenet1szem4"
    pause 0.1
    "ritafaszszopasjelenet1szem3"
    pause 0.1
    "ritafaszszopasjelenet1szem2"
    pause 0.1
    repeat
image ritafaszszopasjelenet1szajanim:
    "ritafaszszopasjelenet1szaj1"
    pause 0.16
    "ritafaszszopasjelenet1szaj4"
    pause 0.16
    "ritafaszszopasjelenet1szaj3"
    pause 0.16
    "ritafaszszopasjelenet1szaj2"
    pause 0.16
    "ritafaszszopasjelenet1szaj4"
    pause 0.16
    "ritafaszszopasjelenet1szaj1"
    pause 0.16
    "ritafaszszopasjelenet1szaj3"
    pause 0.16
    "ritafaszszopasjelenet1szaj2"
    pause 0.16
    "ritafaszszopasjelenet1szaj3"
    pause 0.16
    "ritafaszszopasjelenet1szaj4"
    pause 0.16
    "ritafaszszopasjelenet1szaj1"
    pause 0.16
    "ritafaszszopasjelenet1szaj2"
    pause 0.16
    "ritafaszszopasjelenet1szaj3"
    pause 0.16
    "ritafaszszopasjelenet1szaj4"
    pause 0.16
    repeat
image ritafaszszopasjelenetf1ritaanim:
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.125
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.1
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz1"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz2"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz3"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz4"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz5"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz6"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz7"
    pause 0.111
    "ritafaszszopasjelenetf1ritamoz8"
    pause 0.111
    repeat
image ritafaszszopasjelenetf2kozeliszopasanim:
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.125
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz1"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz2"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz3"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz4"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz5"
    pause 0.1
    "ritafaszszopasjelenetf2kozeliszopasmoz6"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz7"
    pause 0.111
    "ritafaszszopasjelenetf2kozeliszopasmoz8"
    pause 0.111
    repeat
image ritafaszszopasjelenetf3ritafejeanim:
    "ritafaszszopasjelenetf3ritafeje1"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje2"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje3"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje4"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje5"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje6"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje7"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje8"
    pause 0.111
    repeat
image ritafaszszopasjelenetf3ritafejeanim2:
    "ritafaszszopasjelenetf3ritafeje1"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje2"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje3"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje4"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje5"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje6"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje7"
    pause 0.111
    "ritafaszszopasjelenetf3ritafeje8"
    pause 0.111
image ritafaszszopasjelenetf3szajaanim:
    "ritafaszszopasjelenetf3szaja1"
    pause 0.16
    "ritafaszszopasjelenetf3szaja4"
    pause 0.16
    "ritafaszszopasjelenetf3szaja3"
    pause 0.16
    "ritafaszszopasjelenetf3szaja2"
    pause 0.16
    "ritafaszszopasjelenetf3szaja5"
    pause 0.16
    "ritafaszszopasjelenetf3szaja1"
    pause 0.16
    "ritafaszszopasjelenetf3szaja3"
    pause 0.16
    "ritafaszszopasjelenetf3szaja2"
    pause 0.16
    "ritafaszszopasjelenetf3szaja5"
    pause 0.16
    "ritafaszszopasjelenetf3szaja4"
    pause 0.16
    "ritafaszszopasjelenetf3szaja1"
    pause 0.16
    "ritafaszszopasjelenetf3szaja2"
    pause 0.16
    "ritafaszszopasjelenetf3szaja3"
    pause 0.16
    "ritafaszszopasjelenetf3szaja5"
    pause 0.16
    repeat
image ritafaszszopasjelenetf1fiuszajanim:
    "ritafaszszopasjelenetf1fiuszaj1"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj4"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj3"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj2"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj5"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj1"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj3"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj2"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj5"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj4"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj1"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj2"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj3"
    pause 0.16
    "ritafaszszopasjelenetf1fiuszaj5"
    pause 0.16
    repeat
image ritabaszjelenet10reszm1szajanim:
    "ritabaszjelenet10reszm1szaj1"
    pause 0.16
    "ritabaszjelenet10reszm1szaj4"
    pause 0.16
    "ritabaszjelenet10reszm1szaj3"
    pause 0.16
    "ritabaszjelenet10reszm1szaj2"
    pause 0.16
    "ritabaszjelenet10reszm1szaj5"
    pause 0.16
    "ritabaszjelenet10reszm1szaj1"
    pause 0.16
    "ritabaszjelenet10reszm1szaj3"
    pause 0.16
    "ritabaszjelenet10reszm1szaj2"
    pause 0.16
    "ritabaszjelenet10reszm1szaj5"
    pause 0.16
    "ritabaszjelenet10reszm1szaj4"
    pause 0.16
    "ritabaszjelenet10reszm1szaj1"
    pause 0.16
    "ritabaszjelenet10reszm1szaj2"
    pause 0.16
    "ritabaszjelenet10reszm1szaj3"
    pause 0.16
    "ritabaszjelenet10reszm1szaj5"
    pause 0.16
    repeat
image ritabaszjelenet10reszm1szemanim:
    "ritabaszjelenet10reszm1szem1"
    pause 3.0
    "ritabaszjelenet10reszm1szem2"
    pause 0.1
    "ritabaszjelenet10reszm1szem3"
    pause 0.1
    "ritabaszjelenet10reszm1szem4"
    pause 0.1
    "ritabaszjelenet10reszm1szem3"
    pause 0.1
    "ritabaszjelenet10reszm1szem2"
    pause 0.1
    repeat
image ritabaszjelenet10reszm1kezanim:
    "ritabaszjelenet10reszm1kezmoz5"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz4"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz3"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz2"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz1"
image ritabaszjelenet10reszm1kezanim2:
    "ritabaszjelenet10reszm1kezmoz1"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz2"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz3"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz4"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz5"
    pause 0.1
image ritabaszjelenet10reszm1kezanim3:
    "ritabaszjelenet10reszm1kezmoz5"
    pause 4.1
    "ritabaszjelenet10reszm1kezmoz4"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz3"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz2"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz1"
    pause 3.1
    "ritabaszjelenet10reszm1kezmoz2"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz3"
    pause 0.1
    "ritabaszjelenet10reszm1kezmoz4"
    pause 0.1
    repeat
image ritabaszjelenet10reszm2ritaszajanim:
    "ritabaszjelenet10reszm2ritaszaj1"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj4"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj3"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj2"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj5"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj1"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj3"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj2"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj5"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj4"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj1"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj2"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj3"
    pause 0.16
    "ritabaszjelenet10reszm2ritaszaj5"
    pause 0.16
    repeat
image ritabaszjelenet10reszm2ritaszemanim:
    "ritabaszjelenet10reszm2ritaszem1"
    pause 3.0
    "ritabaszjelenet10reszm2ritaszem2"
    pause 0.1
    "ritabaszjelenet10reszm2ritaszem3"
    pause 0.1
    "ritabaszjelenet10reszm2ritaszem4"
    pause 0.1
    "ritabaszjelenet10reszm2ritaszem3"
    pause 0.1
    "ritabaszjelenet10reszm2ritaszem2"
    pause 0.1
    repeat
image ritabaszjelenet10reszm2ritaszemanim2:
    "ritabaszjelenet10reszm2ritaszem1"
    pause 0.1
    "ritabaszjelenet10reszm2ritaszem2"
    pause 0.1
    "ritabaszjelenet10reszm2ritaszem3"
    pause 0.1
    "ritabaszjelenet10reszm2ritaszem4"
image ritabaszjelenet10reszm2ritaanim:
    "ritabaszjelenet10reszm2ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm2ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm2ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm2ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm2ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm2ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm2ritamoz7"
    pause 0.111
image ritabaszjelenet10reszm2fiuanim:
    "ritabaszjelenet10reszm2fiumoz1"
    pause 0.125
    "ritabaszjelenet10reszm2fiumoz2"
    pause 0.125
    "ritabaszjelenet10reszm2fiumoz3"
    pause 0.125
    "ritabaszjelenet10reszm2fiumoz4"
    pause 0.125
    "ritabaszjelenet10reszm2fiumoz5"
    pause 0.125
    "ritabaszjelenet10reszm2fiumoz6"
    pause 0.125
    "ritabaszjelenet10reszm2fiumoz7"
    pause 0.125
image ritabaszjelenet10reszm2veranim:
    "ritabaszjelenet10reszm2vermoz1"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz2"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz3"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz4"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz5"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz6"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz7"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz8"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz9"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz10"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz11"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz12"
    pause 0.125
    "ritabaszjelenet10reszm2vermoz13"
    pause 0.125
image ritabaszjelenet10reszm2rita7szajanim:
    "ritabaszjelenet10reszm2rita7szaj2"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj4"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj6"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj3"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj2"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj5"
    pause 0.16
    "ruhaz"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj3"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj2"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj5"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj6"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj4"
    pause 0.16
    "ruhaz"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj2"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj3"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj6"
    pause 0.16
    "ritabaszjelenet10reszm2rita7szaj5"
    pause 0.16
    repeat
image ritabaszjelenet10reszm4ritaanim:
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz1"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz2"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz3"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz4"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz5"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz6"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.111
    repeat
image ritabaszjelenet10reszm4ritaanim2:
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.1
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
    repeat
image ritabaszjelenet10reszm4ritaanim3:
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz7"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz8"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz9"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz10"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz11"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.084
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.084
image ritabaszjelenet10reszm4ritaanim4:
    "ritabaszjelenet10reszm4ritamoz12"
    pause 0.111
    "ritabaszjelenet10reszm4ritamoz13"
    pause 0.111
    repeat
image ritabaszjelenet10reszm4fiulabaanim:
    "ritabaszjelenet10reszm4fiulaba1"
    pause 0.125
    "ritabaszjelenet10reszm4fiulaba2"
    pause 0.125
    "ritabaszjelenet10reszm4fiulaba3"
    pause 0.125
    repeat
image ritabaszjelenet10reszm4ritaranim:
    "ritabaszjelenet10reszm4ritar1"
    pause 0.125
    "ritabaszjelenet10reszm4ritar2"
    pause 0.125
    repeat
image egyetemenritatanulanimfel:
    "egyetemenritatanulmoz1"
    pause 0.084
    "egyetemenritatanulmoz2"
    pause 0.084
    "egyetemenritatanulmoz3"
    pause 0.084
    "egyetemenritatanulmoz4"
    pause 0.084
    "egyetemenritatanulmoz5"
    pause 0.084
image egyetemenritatanulanimle:
    "egyetemenritatanulmoz5"
    pause 0.042
    "egyetemenritatanulmoz4"
    pause 0.042
    "egyetemenritatanulmoz3"
    pause 0.042
    "egyetemenritatanulmoz2"
    pause 0.042
    "egyetemenritatanulmoz1"
    pause 0.042
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
