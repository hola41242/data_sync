image fifioldalseta:
    "fifi-1"
    pause 0.25
    "fifi-2"
    pause 0.25
    "fifi-3"
    pause 0.25
    "fifi-4"
    pause 0.25
    repeat
image fifisetaszembe:
    "fifi-5"
    pause 0.25
    "fifi-6"
    pause 0.25
    "fifi-7"
    pause 0.25
    "fifi-8"
    pause 0.25
    repeat
image fifisetahatra:
    "fifi-9"
    pause 0.25
    "fifi-10"
    pause 0.25
    "fifi-11"
    pause 0.25
    "fifi-12"
    pause 0.25
    repeat
image fififelfeleszagol:
    "fififelfeleszagol1"
    pause 0.1
    "fififelfeleszagol2"
    pause 0.1
    "fififelfeleszagol3"
    pause 0.1
    "fififelfeleszagol4"
    pause 0.1
    repeat
image fififelfeleszagolpislog:
    "fififelfeleszagolszem1"
    pause 3.25
    "fififelfeleszagolszem2"
    pause 0.16
    "fififelfeleszagolszem3"
    pause 0.16
    "fififelfeleszagolszem2"
    pause 0.16
    repeat
image fifiszagolpislog:
    "fifiszagolszem1"
    pause 3.25
    "fifiszagolszem2"
    pause 0.16
    "fifiszagolszem3"
    pause 0.16
    "fifiszagolszem2"
    pause 0.16
    repeat
image fifiszagolpislog2:
    "fifiszagolszem1"
    pause 3.25
    "fifiszagolszem2"
    pause 0.16
    "fifiszagolszem3"
    pause 0.16
    "fifiszagolszem2"
    pause 0.16
    repeat
image fifiszagol2:
    "fifiszagol"
image fifimorog:
    "fifimorog1"
    pause 0.16
    "fifimorog2"
    pause 0.16
    "fifimorog3"
    pause 0.16
    repeat
image fifipisil:
    "fifipisil1"
    pause 0.16
    "fifipisil2"
    pause 0.16
    "fifipisil3"
    pause 0.16
    repeat
image hugy1:
    "hugy"
image fifigameover:
    "papirszettepve1"
    pause 0.16
    "papirszettepve2"
    pause 0.16
    "papirszettepve3"
    pause 0.16
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
