image annaatonalajultszemmoz:
    "annaatonalajultszem1"
    pause 10.125
    "annaatonalajultszem2"
    pause 0.125
    "annaatonalajultszem3"
    pause 5.225
    "annaatonalajultszem2"
    pause 0.125
    "annaatonalajultszem1"
    pause 12.125
    "annaatonalajultszem2"
    pause 0.125
    "annaatonalajultszem3"
    pause 6.125
    "annaatonalajultszem2"
    pause 0.125
    repeat
image annaatonalajultcsombfogdosasanim:
    "annaatonalajultcsombfogdosaszom1"
    pause 0.25
    "annaatonalajultcsombfogdosaszom2"
    pause 0.125
    "annaatonalajultcsombfogdosaszom3"
    pause 0.125
    "annaatonalajultcsombfogdosaszom4"
    pause 0.125
    "annaatonalajultcsombfogdosaszom5"
    pause 0.25
    "annaatonalajultcsombfogdosaszom4"
    pause 0.125
    "annaatonalajultcsombfogdosaszom3"
    pause 0.125
    "annaatonalajultcsombfogdosaszom2"
    pause 0.125
    repeat
image annaatonalajultpinadorzianim:
    "annaatonalajultpinadorzimoz1"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz7"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz1"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz7"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz1"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz7"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz1"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz7"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz1"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz7"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz1"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz7"
    pause 0.125
    "annaatonalajultpinadorzimoz6"
    pause 0.125
    "annaatonalajultpinadorzimoz5"
    pause 0.125
    "annaatonalajultpinadorzimoz4"
    pause 0.125
    "annaatonalajultpinadorzimoz3"
    pause 0.125
    "annaatonalajultpinadorzimoz2"
    pause 0.125
    "annaatonalajultpinadorzimoz1"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz7"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz1"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz7"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz1"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz7"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz1"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz7"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz1"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz7"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz1"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz7"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz1"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz7"
    pause 0.1
    "annaatonalajultpinadorzimoz6"
    pause 0.1
    "annaatonalajultpinadorzimoz5"
    pause 0.1
    "annaatonalajultpinadorzimoz4"
    pause 0.1
    "annaatonalajultpinadorzimoz3"
    pause 0.1
    "annaatonalajultpinadorzimoz2"
    pause 0.1
    repeat
image annaatonalajultcicitapianim:
    "annaatonalajultcicitapimoz1"
    pause 0.125
    "annaatonalajultcicitapimoz2"
    pause 0.125
    "annaatonalajultcicitapimoz3"
    pause 0.125
    "annaatonalajultcicitapimoz4"
    pause 0.125
    "annaatonalajultcicitapimoz5"
    pause 0.125
    "annaatonalajultcicitapimoz6"
    pause 0.125
    "annaatonalajultcicitapimoz7"
    pause 0.125
    "annaatonalajultcicitapimoz8"
    pause 0.125
    "annaatonalajultcicitapimoz1"
    pause 0.125
    "annaatonalajultcicitapimoz2"
    pause 0.125
    "annaatonalajultcicitapimoz3"
    pause 0.125
    "annaatonalajultcicitapimoz4"
    pause 0.125
    "annaatonalajultcicitapimoz5"
    pause 0.125
    "annaatonalajultcicitapimoz6"
    pause 0.125
    "annaatonalajultcicitapimoz7"
    pause 0.125
    "annaatonalajultcicitapimoz8"
    pause 0.125
    "annaatonalajultcicitapimoz1"
    pause 0.125
    "annaatonalajultcicitapimoz2"
    pause 0.125
    "annaatonalajultcicitapimoz3"
    pause 0.125
    "annaatonalajultcicitapimoz4"
    pause 0.125
    "annaatonalajultcicitapimoz5"
    pause 0.125
    "annaatonalajultcicitapimoz6"
    pause 0.125
    "annaatonalajultcicitapimoz7"
    pause 0.125
    "annaatonalajultcicitapimoz8"
    pause 0.125
    "annaatonalajultcicitapimoz1"
    pause 0.125
    "annaatonalajultcicitapimoz2"
    pause 0.1
    "annaatonalajultcicitapimoz3"
    pause 0.1
    "annaatonalajultcicitapimoz4"
    pause 0.1
    "annaatonalajultcicitapimoz5"
    pause 0.1
    "annaatonalajultcicitapimoz6"
    pause 0.1
    "annaatonalajultcicitapimoz7"
    pause 0.1
    "annaatonalajultcicitapimoz8"
    pause 0.1
    "annaatonalajultcicitapimoz1"
    pause 0.1
    "annaatonalajultcicitapimoz2"
    pause 0.1
    "annaatonalajultcicitapimoz3"
    pause 0.1
    "annaatonalajultcicitapimoz4"
    pause 0.1
    "annaatonalajultcicitapimoz5"
    pause 0.1
    "annaatonalajultcicitapimoz6"
    pause 0.1
    "annaatonalajultcicitapimoz7"
    pause 0.1
    "annaatonalajultcicitapimoz8"
    pause 0.1
    "annaatonalajultcicitapimoz1"
    pause 0.1
    "annaatonalajultcicitapimoz2"
    pause 0.1
    "annaatonalajultcicitapimoz3"
    pause 0.1
    "annaatonalajultcicitapimoz4"
    pause 0.1
    "annaatonalajultcicitapimoz5"
    pause 0.1
    "annaatonalajultcicitapimoz6"
    pause 0.1
    "annaatonalajultcicitapimoz7"
    pause 0.1
    "annaatonalajultcicitapimoz8"
    pause 0.1
    "annaatonalajultcicitapimoz1"
    pause 0.1
    "annaatonalajultcicitapimoz2"
    pause 0.1
    "annaatonalajultcicitapimoz3"
    pause 0.1
    "annaatonalajultcicitapimoz4"
    pause 0.1
    "annaatonalajultcicitapimoz5"
    pause 0.1
    "annaatonalajultcicitapimoz6"
    pause 0.1
    "annaatonalajultcicitapimoz7"
    pause 0.1
    "annaatonalajultcicitapimoz8"
    pause 0.1
    "annaatonalajultcicitapimoz1"
    pause 0.1
    "annaatonalajultcicitapimoz2"
    pause 0.1
    "annaatonalajultcicitapimoz3"
    pause 0.1
    "annaatonalajultcicitapimoz4"
    pause 0.1
    "annaatonalajultcicitapimoz5"
    pause 0.1
    "annaatonalajultcicitapimoz6"
    pause 0.1
    "annaatonalajultcicitapimoz7"
    pause 0.1
    "annaatonalajultcicitapimoz8"
    pause 0.1
    "annaatonalajultcicitapimoz1"
    pause 0.1
    "annaatonalajultcicitapimoz2"
    pause 0.1
    "annaatonalajultcicitapimoz3"
    pause 0.1
    "annaatonalajultcicitapimoz4"
    pause 0.1
    "annaatonalajultcicitapimoz5"
    pause 0.1
    "annaatonalajultcicitapimoz6"
    pause 0.1
    "annaatonalajultcicitapimoz7"
    pause 0.1
    "annaatonalajultcicitapimoz8"
    pause 0.1
    "annaatonalajultcicitapimoz1"
    pause 0.1
    "annaatonalajultcicitapimoz2"
    pause 0.1
    "annaatonalajultcicitapimoz3"
    pause 0.1
    "annaatonalajultcicitapimoz4"
    pause 0.1
    "annaatonalajultcicitapimoz5"
    pause 0.125
    "annaatonalajultcicitapimoz6"
    pause 0.125
    "annaatonalajultcicitapimoz7"
    pause 0.125
    "annaatonalajultcicitapimoz8"
    pause 0.125
    "annaatonalajultcicitapimoz1"
    pause 0.125
    "annaatonalajultcicitapimoz2"
    pause 0.125
    "annaatonalajultcicitapimoz3"
    pause 0.125
    "annaatonalajultcicitapimoz4"
    pause 0.125
    "annaatonalajultcicitapimoz5"
    pause 0.125
    "annaatonalajultcicitapimoz6"
    pause 0.125
    "annaatonalajultcicitapimoz7"
    pause 0.125
    "annaatonalajultcicitapimoz8"
    pause 0.125
    repeat
image annaatonalajultcicitapianim2:
    "annaatonalajultcicitapimoz1"
    pause 0.125
    "annaatonalajultcicitapimoz2"
    pause 0.125
    "annaatonalajultcicitapimoz3"
    pause 0.125
    "annaatonalajultcicitapimoz4"
    pause 0.125
    "annaatonalajultcicitapimoz5"
    pause 0.125
    "annaatonalajultcicitapimoz6"
    pause 0.125
    "annaatonalajultcicitapimoz7"
    pause 0.125
    "annaatonalajultcicitapimoz8"
    pause 0.125
    "annaatonalajultcicitapimoz1"
    pause 0.125
image annaatonalajultszemkinyit:
    "annaatonalajultszem1"
    pause 0.125
    "annaatonalajultszem2"
    pause 0.125
    "annaatonalajultszem3"
    pause 0.625
    "annaatonalajultszem2"
    pause 0.125
    "annaatonalajultszem1"
    pause 1.0
    "annaatonalajultszem2"
    pause 0.125
    "annaatonalajultszem3"
    pause 0.125
    "annaatonalajultszem4"
    pause 0.25
    "annaatonalajultszem5"
    pause 0.125
    "annaatonalajultszem6"
    pause 0.125
    "annaatonalajultszem7"
    pause 0.125
    "annaatonalajultszem8"
image annaatonalajultszajanim:
    "annaatonalajultszaj1"
    pause 0.16
    "annaatonalajultszaj2"
    pause 0.16
    "annaatonalajultszaj3"
    pause 0.16
    "annaatonalajultszaj4"
    pause 0.16
    "annaatonalajultszaj5"
    pause 0.16
    "annaatonalajultszaj3"
    pause 0.16
    "annaatonalajultszaj4"
    pause 0.16
    "annaatonalajultszaj1"
    pause 0.16
    "annaatonalajultszaj2"
    pause 0.16
    "annaatonalajultszaj5"
    pause 0.16
    repeat
image annalabaverzikanim:
    "annalabaverzik-1"
    pause 0.084
    "annalabaverzik-2"
    pause 0.084
    "annalabaverzik-3"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    "furdoszekrenyz"
image annalabaverzikanim2:
    "annalabaverzik-4"
    pause 0.084
    "annalabaverzik-5"
    pause 0.084
    "annalabaverzik-6"
    pause 0.084
    "annalabaverzik-7"
    pause 0.084
    "annalabaverzik-8"
    pause 0.084
    repeat
image annaatobananimseta:
    "annaatobanmoz1"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz5"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz1"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz5"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz1"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz5"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz1"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz5"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz1"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz5"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz1"
    pause 0.125
    "annaatobanmoz2"
    pause 0.125
    "annaatobanmoz3"
    pause 0.125
    "annaatobanmoz4"
    pause 0.125
    "annaatobanmoz5"
    pause 2.125
    "annaatobanmoz6"
    pause 0.125
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
