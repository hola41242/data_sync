image mamakanapenpislog:
    "nagyikanapen1szem1"
    pause 4.2
    "nagyikanapen1szem2"
    pause 0.16
    "nagyikanapen1szem3"
    pause 0.16
    "nagyikanapen1szem2"
    pause 0.16
    "nagyikanapen1szem1"
    pause 3.5
    "nagyikanapen1szem2"
    pause 0.16
    "nagyikanapen1szem3"
    pause 0.16
    "nagyikanapen2szem2"
    pause 0.16
    "nagyikanapen2szem1"
    pause 3.5
    "nagyikanapen2szem2"
    pause 0.16
    "nagyikanapen2szem3"
    pause 0.16
    "nagyikanapen1szem2"
    pause 0.16
    repeat
image mamakanapenpislogbalra:
    "nagyikanapen1szem1"
    pause 4.2
    "nagyikanapen1szem2"
    pause 0.16
    "nagyikanapen1szem3"
    pause 0.16
    "nagyikanapen1szem2"
    pause 0.16
    repeat
image mamakanapenpislogjobra:
    "nagyikanapen2szem1"
    pause 4.2
    "nagyikanapen2szem2"
    pause 0.16
    "nagyikanapen2szem3"
    pause 0.16
    "nagyikanapen2szem2"
    pause 0.16
    repeat
image mamakanapensemoldokvalt1rol4:
    "nagyikanapenszemoldok1"
    pause 0.1
    "nagyikanapenszemoldok2"
    pause 0.1
    "nagyikanapenszemoldok3"
    pause 0.1
    "nagyikanapenszemoldok4"
    pause 0.1
    repeat
image mamakanapensemoldokvalt4rol1:
    "nagyikanapenszemoldok4"
    pause 0.1
    "nagyikanapenszemoldok3"
    pause 0.1
    "nagyikanapenszemoldok2"
    pause 0.1
    "nagyikanapenszemoldok1"
    pause 0.1
    repeat
image mamavetkozi4reszlegzesanim:
    "mamavetkozik4resz2anim1"
    pause 0.375
    "mamavetkozik4resz2anim2"
    pause 0.125
    "mamavetkozik4resz2anim3"
    pause 0.125
    "mamavetkozik4resz2anim4"
    pause 0.125
    "mamavetkozik4resz2anim5"
    pause 0.125
    "mamavetkozik4resz2anim6"
    pause 0.125
    "mamavetkozik4resz2anim7"
    pause 0.25
    "mamavetkozik4resz2anim6"
    pause 0.125
    "mamavetkozik4resz2anim5"
    pause 0.125
    "mamavetkozik4resz2anim4"
    pause 0.125
    "mamavetkozik4resz2anim3"
    pause 0.125
    "mamavetkozik4resz2anim2"
    pause 0.125
    "mamavetkozik4resz2anim1"
    pause 0.125
    repeat
image mamavetkozi4reszszemanim:
    "mamavetkozik4resz2szemb1"
    pause 2.0
    "mamavetkozik4resz2szemb2"
    pause 0.125
    "mamavetkozik4resz2szemb3"
    pause 0.125
    "mamavetkozik4resz2szemb2"
    pause 0.125
    "mamavetkozik4resz2szemb1"
    pause 2.0
    "mamavetkozik4resz2szemb2"
    pause 0.125
    "mamavetkozik4resz2szemb3"
    pause 0.125
    "mamavetkozik4resz2szemj2"
    pause 0.125
    "mamavetkozik4resz2szemj1"
    pause 3.0
    "mamavetkozik4resz2szemj2"
    pause 0.125
    "mamavetkozik4resz2szemj3"
    pause 0.125
    "mamavetkozik4resz2szemj2"
    pause 0.125
    "mamavetkozik4resz2szemj1"
    pause 2.0
    "mamavetkozik4resz2szemj2"
    pause 0.125
    "mamavetkozik4resz2szemj3"
    pause 0.125
    "mamavetkozik4resz2szemb2"
    pause 0.125
    repeat
image mamavetkozi4reszszajanim:
    "mamavetkozik4resz2szaj1"
    pause 5.125
    "mamavetkozik4resz2szaj2"
    pause 0.125
    "mamavetkozik4resz2szaj3"
    pause 0.125
    "mamavetkozik4resz2szaj4"
    pause 0.125
    "mamavetkozik4resz2szaj5"
    pause 0.125
    "mamavetkozik4resz2szaj6"
    pause 0.125
image mamakavezikanim:
    "mamakavezik1"
    pause 2.125
    "mamakavezik2"
    pause 0.125
    "mamakavezik3"
    pause 0.125
    "mamakavezik4"
    pause 0.125
    "mamakavezik5"
    pause 0.125
    "mamakavezik6"
    pause 0.125
    "mamakavezik7"
    pause 1.125
    "mamakavezik6"
    pause 0.125
    "mamakavezik5"
    pause 0.125
    "mamakavezik4"
    pause 0.125
    "mamakavezik3"
    pause 0.125
    "mamakavezik2"
    pause 0.125
    repeat
image mamakeresmozanim:
    "mamakeresmoz1"
    pause 0.5
    "mamakeresmoz2"
    pause 0.1
    "mamakeresmoz3"
    pause 0.1
    "mamakeresmoz4"
    pause 0.3
    "mamakeresmoz3"
    pause 0.1
    "mamakeresmoz2"
    pause 0.1
    repeat
image mama540keresmozanim:
    "mama540keresmoz1"
    pause 0.5
    "mama540keresmoz2"
    pause 0.1
    "mama540keresmoz3"
    pause 0.1
    "mama540keresmoz4"
    pause 0.3
    "mama540keresmoz3"
    pause 0.1
    "mama540keresmoz2"
    pause 0.1
    repeat
image mama540keresmozanim2:
    "mama540keresmoz1"
    pause 0.5
    "mama540keresmoz2"
    pause 0.1
    "mama540keresmoz3"
    pause 0.1
    "mama540keresmoz4"
    pause 0.3
    "mama540keresmoz3"
    pause 0.1
    "mama540keresmoz2"
    pause 0.1
    repeat
image maminezelodikanim:
    "maminezelodik1"
    pause 2.1
    "maminezelodik2"
    pause 0.1
    "maminezelodik3"
    pause 0.1
    "maminezelodik4"
    pause 0.1
    "maminezelodik5"
    pause 4.1
    "maminezelodik4"
    pause 0.1
    "maminezelodik3"
    pause 0.1
    "maminezelodik2"
    pause 0.1
    repeat
image mami540nezelodikanim:
    "mami540nezelodik1"
    pause 2.1
    "mami540nezelodik2"
    pause 0.1
    "mami540nezelodik3"
    pause 0.1
    "mami540nezelodik4"
    pause 0.1
    "mami540nezelodik5"
    pause 4.1
    "mami540nezelodik4"
    pause 0.1
    "mami540nezelodik3"
    pause 0.1
    "mami540nezelodik2"
    pause 0.1
    repeat
image mami540nezelodikanim2:
    "mami540nezelodik1"
    pause 2.1
    "mami540nezelodik2"
    pause 0.1
    "mami540nezelodik3"
    pause 0.1
    "mami540nezelodik4"
    pause 0.1
    "mami540nezelodik5"
    pause 4.1
    "mami540nezelodik4"
    pause 0.1
    "mami540nezelodik3"
    pause 0.1
    "mami540nezelodik2"
    pause 0.1
    repeat
image medemcetakarit1mamaanim:
    "medemcetakarit1mamamoz1"
    pause 0.125
    "medemcetakarit1mamamoz2"
    pause 0.125
    "medemcetakarit1mamamoz3"
    pause 0.125
    "medemcetakarit1mamamoz4"
    pause 0.125
    "medemcetakarit1mamamoz5"
    pause 0.125
    "medemcetakarit1mamamoz6"
    pause 0.125
    "medemcetakarit1mamamoz7"
    pause 0.125
    "medemcetakarit1mamamoz6"
    pause 0.125
    "medemcetakarit1mamamoz5"
    pause 0.125
    "medemcetakarit1mamamoz4"
    pause 0.125
    "medemcetakarit1mamamoz3"
    pause 0.125
    "medemcetakarit1mamamoz2"
    pause 0.125
    repeat
image debrakertje2mamanapozikanim:
    "debrakertje2mamanapozikmoz1"
    pause 2.0
    "debrakertje2mamanapozikmoz2"
    pause 0.1
    "debrakertje2mamanapozikmoz3"
    pause 0.1
    "debrakertje2mamanapozikmoz4"
    pause 0.1
    "debrakertje2mamanapozikmoz5"
    pause 5.1
    "debrakertje2mamanapozikmoz4"
    pause 0.1
    "debrakertje2mamanapozikmoz3"
    pause 0.1
    "debrakertje2mamanapozikmoz2"
    pause 0.1
    "debrakertje2mamanapozikmoz1"
    pause 3.1
    repeat
image mamanapozik9reszpinapszajanim:
    "mamanapozik9reszpinapszaj1"
    pause 0.125
    "mamanapozik9reszpinapszaj2"
    pause 0.125
    "mamanapozik9reszpinapszaj6"
    pause 0.125
    "mamanapozik9reszpinapszaj5"
    pause 0.125
    "mamanapozik9reszpinapszaj3"
    pause 0.125
    "mamanapozik9reszpinapszaj4"
    pause 0.125
    "mamanapozik9reszpinapszaj2"
    pause 0.125
    "mamanapozik9reszpinapszaj6"
    pause 0.125
    "mamanapozik9reszpinapszaj3"
    pause 0.125
    "mamanapozik9reszpinapszaj4"
    pause 0.125
    "mamanapozik9reszpinapszaj3"
    pause 0.125
    "mamanapozik9reszpinapszaj2"
    pause 0.125
    repeat
image mamanapozik9reszfejanim1:
    "mamanapozik9reszfejmoz1"
    pause 0.1
    "mamanapozik9reszfejmoz2"
    pause 0.1
    "mamanapozik9reszfejmoz3"
    pause 0.1
    "mamanapozik9reszfejmoz4"
    pause 0.1
    "mamanapozik9reszfejmoz5"
    pause 0.1
image mamanapozik9reszfejanim2:
    "mamanapozik9reszfejmoz5"
    pause 0.1
    "mamanapozik9reszfejmoz4"
    pause 0.1
    "mamanapozik9reszfejmoz3"
    pause 0.1
    "mamanapozik9reszfejmoz2"
    pause 0.1
    "mamanapozik9reszfejmoz1"
    pause 0.1
image mamanapozik9reszfejszajanim:
    "mamanapozik9reszfejszaj1"
    pause 0.125
    "mamanapozik9reszfejszaj2"
    pause 0.125
    "mamanapozik9reszfejszaj6"
    pause 0.125
    "mamanapozik9reszfejszaj5"
    pause 0.125
    "mamanapozik9reszfejszaj3"
    pause 0.125
    "mamanapozik9reszfejszaj4"
    pause 0.125
    "mamanapozik9reszfejszaj2"
    pause 0.125
    "mamanapozik9reszfejszaj6"
    pause 0.125
    "mamanapozik9reszfejszaj3"
    pause 0.125
    "mamanapozik9reszfejszaj4"
    pause 0.125
    "mamanapozik9reszfejszaj3"
    pause 0.125
    "mamanapozik9reszfejszaj2"
    pause 0.125
    repeat
image mamanapozik9reszseganim:
    "mamanapozik9reszsegmoz1"
    pause 0.125
    "mamanapozik9reszsegmoz2"
    pause 0.125
    "mamanapozik9reszsegmoz3"
    pause 0.125
    "mamanapozik9reszsegmoz4"
    pause 0.125
    "mamanapozik9reszsegmoz5"
    pause 0.125
    "mamanapozik9reszsegmoz6"
    pause 0.125
    "mamanapozik9reszsegmoz1"
    pause 0.125
    "mamanapozik9reszsegmoz2"
    pause 0.125
    "mamanapozik9reszsegmoz3"
    pause 0.125
    "mamanapozik9reszsegmoz4"
    pause 0.125
    "mamanapozik9reszsegmoz5"
    pause 0.125
    "mamanapozik9reszsegmoz6"
    pause 0.125
    "mamanapozik9reszsegmoz1"
    pause 0.125
    "mamanapozik9reszsegmoz2"
    pause 0.125
    "mamanapozik9reszsegmoz3"
    pause 0.125
    "mamanapozik9reszsegmoz4"
    pause 0.125
    "mamanapozik9reszsegmoz5"
    pause 0.125
    "mamanapozik9reszsegmoz6"
    pause 0.125
    "mamanapozik9reszsegmoz1"
    pause 0.125
    "mamanapozik9reszsegmoz2"
    pause 0.125
    "mamanapozik9reszsegmoz3"
    pause 0.125
    "mamanapozik9reszsegmoz4"
    pause 0.125
    "mamanapozik9reszsegmoz5"
    pause 0.125
    "mamanapozik9reszsegmoz6"
    pause 0.125
    "mamanapozik9reszsegmoz1"
    pause 0.125
    "mamanapozik9reszsegmoz2"
    pause 0.125
    "mamanapozik9reszsegmoz3"
    pause 0.125
    "mamanapozik9reszsegmoz4"
    pause 0.125
    "mamanapozik9reszsegmoz5"
    pause 0.125
    "mamanapozik9reszsegmoz6"
    pause 0.125
    "mamanapozik9reszsegmoz1"
    pause 0.166
    "mamanapozik9reszsegmoz2"
    pause 0.166
    "mamanapozik9reszsegmoz3"
    pause 0.166
    "mamanapozik9reszsegmoz4"
    pause 0.166
    "mamanapozik9reszsegmoz5"
    pause 0.166
    "mamanapozik9reszsegmoz6"
    pause 0.166
    "mamanapozik9reszsegmoz1"
    pause 0.166
    "mamanapozik9reszsegmoz2"
    pause 0.166
    "mamanapozik9reszsegmoz3"
    pause 0.166
    "mamanapozik9reszsegmoz4"
    pause 0.166
    "mamanapozik9reszsegmoz5"
    pause 0.166
    "mamanapozik9reszsegmoz6"
    pause 0.166
    "mamanapozik9reszsegmoz1"
    pause 0.166
    "mamanapozik9reszsegmoz2"
    pause 0.166
    "mamanapozik9reszsegmoz3"
    pause 0.166
    "mamanapozik9reszsegmoz4"
    pause 0.166
    "mamanapozik9reszsegmoz5"
    pause 0.166
    "mamanapozik9reszsegmoz6"
    pause 0.166
    "mamanapozik9reszsegmoz1"
    pause 0.166
    "mamanapozik9reszsegmoz2"
    pause 0.166
    "mamanapozik9reszsegmoz3"
    pause 0.166
    "mamanapozik9reszsegmoz4"
    pause 0.166
    "mamanapozik9reszsegmoz5"
    pause 0.166
    "mamanapozik9reszsegmoz6"
    pause 0.166
    "mamanapozik9reszsegmoz1"
    pause 0.166
    "mamanapozik9reszsegmoz2"
    pause 0.166
    "mamanapozik9reszsegmoz3"
    pause 0.166
    "mamanapozik9reszsegmoz4"
    pause 0.166
    "mamanapozik9reszsegmoz5"
    pause 0.166
    "mamanapozik9reszsegmoz6"
    pause 0.166
    "mamanapozik9reszsegmoz1"
    pause 0.125
    "mamanapozik9reszsegmoz2"
    pause 0.125
    "mamanapozik9reszsegmoz3"
    pause 0.125
    "mamanapozik9reszsegmoz4"
    pause 0.125
    "mamanapozik9reszsegmoz5"
    pause 0.125
    "mamanapozik9reszsegmoz6"
    pause 0.125
    "mamanapozik9reszsegmoz1"
    pause 0.1
    "mamanapozik9reszsegmoz2"
    pause 0.1
    "mamanapozik9reszsegmoz3"
    pause 0.1
    "mamanapozik9reszsegmoz4"
    pause 0.1
    "mamanapozik9reszsegmoz5"
    pause 0.1
    "mamanapozik9reszsegmoz6"
    pause 0.1
    "mamanapozik9reszsegmoz1"
    pause 0.1
    "mamanapozik9reszsegmoz2"
    pause 0.1
    "mamanapozik9reszsegmoz3"
    pause 0.1
    "mamanapozik9reszsegmoz4"
    pause 0.1
    "mamanapozik9reszsegmoz5"
    pause 0.1
    "mamanapozik9reszsegmoz6"
    pause 0.1
    "mamanapozik9reszsegmoz1"
    pause 0.1
    "mamanapozik9reszsegmoz2"
    pause 0.1
    "mamanapozik9reszsegmoz3"
    pause 0.1
    "mamanapozik9reszsegmoz4"
    pause 0.1
    "mamanapozik9reszsegmoz5"
    pause 0.1
    "mamanapozik9reszsegmoz6"
    pause 0.1
    "mamanapozik9reszsegmoz1"
    pause 0.1
    "mamanapozik9reszsegmoz2"
    pause 0.1
    "mamanapozik9reszsegmoz3"
    pause 0.1
    "mamanapozik9reszsegmoz4"
    pause 0.1
    "mamanapozik9reszsegmoz5"
    pause 0.1
    "mamanapozik9reszsegmoz6"
    pause 0.1
    "mamanapozik9reszsegmoz1"
    pause 0.1
    "mamanapozik9reszsegmoz2"
    pause 0.1
    "mamanapozik9reszsegmoz3"
    pause 0.1
    "mamanapozik9reszsegmoz4"
    pause 0.1
    "mamanapozik9reszsegmoz5"
    pause 0.1
    "mamanapozik9reszsegmoz6"
    pause 0.1
    "mamanapozik9reszsegmoz1"
    pause 0.1
    "mamanapozik9reszsegmoz2"
    pause 0.1
    "mamanapozik9reszsegmoz3"
    pause 0.1
    "mamanapozik9reszsegmoz4"
    pause 0.1
    "mamanapozik9reszsegmoz5"
    pause 0.1
    "mamanapozik9reszsegmoz6"
    pause 0.1
    "mamanapozik9reszsegmoz1"
    pause 0.1
    "mamanapozik9reszsegmoz2"
    pause 0.1
    "mamanapozik9reszsegmoz3"
    pause 0.1
    "mamanapozik9reszsegmoz4"
    pause 0.1
    "mamanapozik9reszsegmoz5"
    pause 0.1
    "mamanapozik9reszsegmoz6"
    pause 0.1
    repeat
image mamanapozik9reszseganimferdbeszel:
    "mamanapozik9reszsegmoz1"
    pause 0.125
    "mamanapozik9reszsegmoz2"
    pause 0.125
    "mamanapozik9reszsegmoz3"
    pause 0.125
    "mamanapozik9reszsegmoz4"
    pause 0.125
    "mamanapozik9reszsegmoz5"
    pause 0.125
    "mamanapozik9reszsegmoz6"
    pause 0.125
    "mamanapozik9reszsegmoz1"
    pause 0.125
image mamacicikiesikanim:
    "mamacicikiesik1"
    pause 0.1
    "mamacicikiesik2"
    pause 0.1
    "mamacicikiesik3"
    pause 0.1
    "mamacicikiesik4"
    pause 0.1
    "mamacicikiesik5"
    pause 0.1
    "mamacicikiesik6"
    pause 0.1
    "mamacicikiesik7"
    pause 0.1
image mamacicikiesik1szajanim:
    "mamacicikiesik1szaj1"
    pause 0.16
    "mamacicikiesik1szaj3"
    pause 0.16
    "mamacicikiesik1szaj2"
    pause 0.16
    "mamacicikiesik1szaj4"
    pause 0.16
    "mamacicikiesik1szaj1"
    pause 0.16
    "mamacicikiesik1szaj2"
    pause 0.16
    "mamacicikiesik1szaj4"
    pause 0.16
    "mamacicikiesik1szaj3"
    pause 0.16
    "mamacicikiesik1szaj2"
    pause 0.16
    "mamacicikiesik1szaj4"
    pause 0.16
    "mamacicikiesik1szaj1"
    pause 0.16
    "mamacicikiesik1szaj3"
    pause 0.16
    repeat
image mamacicikiesik7szajanim:
    "mamacicikiesik7szaj1"
    pause 0.16
    "mamacicikiesik7szaj3"
    pause 0.16
    "mamacicikiesik7szaj2"
    pause 0.16
    "mamacicikiesik7szaj4"
    pause 0.16
    "mamacicikiesik7szaj1"
    pause 0.16
    "mamacicikiesik7szaj2"
    pause 0.16
    "mamacicikiesik7szaj4"
    pause 0.16
    "mamacicikiesik7szaj3"
    pause 0.16
    "mamacicikiesik7szaj2"
    pause 0.16
    "mamacicikiesik7szaj4"
    pause 0.16
    "mamacicikiesik7szaj1"
    pause 0.16
    "mamacicikiesik7szaj3"
    pause 0.16
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
