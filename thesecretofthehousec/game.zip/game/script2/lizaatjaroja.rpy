label lizaatjaroja:
    $ holvagyok = "lizaatjaroja"
    jump tiltasok
label lizaatjarojaszov:
    show lizaatjaroja
    jump engedejek

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
