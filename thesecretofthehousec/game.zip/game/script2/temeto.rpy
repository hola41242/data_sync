label temeto:
    $ holvagyok = "temeto"
    jump tiltasok
$ renpy. pause(hard=True)
label temetoszov:
    if hanyadiknapvan == 9:
        if resz9jelenet1 == False:
            jump resz9jelenet1
    show temeto
    show temetosirok onlayer hatso
    show temetoelott onlayer kozep4
    if temetosirkosz1 == 1:
        show temetosirkosz1 onlayer hatso
    if temetosirkosz2 == 1:
        show temetosirkosz2 onlayer hatso
    if temetosirkosz3 == 1:
        show temetosirkosz3 onlayer hatso
    if temetolevagotrozsak == 1:
        show temetolevagotrozsak onlayer hatso2
    if temetoigyufa == 1:
        show temetoigyufa onlayer hatso
    if svetlana == "temetoben":
        show taska5resz:
            zoom 0.5
            xpos 0.23
            ypos 0.64
        show svetlana540:
            zoom 0.7
            xpos 0.18
            ypos 0.32
    if macskaholvan == "temeto":
        if macskanalad == 0:
            show macska-10:
                zoom 0.8
                xpos 0.22
                ypos 0.68
    if dagiholvan == "temeto":
        show dagi540allas1:
            zoom 0.7
            xpos 0.2
            ypos 0.35


    jump engedejek


$ renpy. pause(hard=True)
label gyufatfelveszedtemetobol:
    $ gyufanalad = 1
    $ temetoigyufa = 0
    show temetoigyufa onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
$ renpy. pause(hard=True)
label temetosirkosz1:
    hide screen temeto
    if kerjmunkatkerhec == True:
        if sirokatmegtisztithatod == True:
            if temetosirkosz1 == 1:
                if festekoldonalad == 1:
                    $ festekoldonalad = 2
                    $ temetosirkosz1 = 0
                    show temetosirkosz1 onlayer hatso:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    if temetosirkosz1 == 0:
                        if temetosirkosz2 == 0:
                            if temetosirkosz3 == 0:
                                $ ladalakatnyithato = True
                    jump sirugrik1
                if debrakendobenazagyon == False:
                    $ debrakendobenazagyon = True
                    $ debraholcsinal = "atjarobantorolkozoben"
                $ sirfestekeshezkell = True
                f "I can not read it from the dye... Here stands some kind of Maria... I should clean the grave first..."
                show screen temeto
                $ renpy. pause(hard=True)
label sirugrik1:
    if temetosirkosz1 == 1:
        f "Someone painted the gravestone. The name is Maria…"
    if temetosirkosz1 == 0:
        f "{b}{space=400}Maria Sankomerg{p}{space=350}Dec.30.1817/Jun.3.18{size=+20}53{size=-20}{p}{space=430}Rest in Peace"


    show screen temeto
$ renpy. pause(hard=True)
label temetosirkosz2:
    hide screen temeto
    if kerjmunkatkerhec == True:
        if sirokatmegtisztithatod == True:
            if temetosirkosz2 == 1:
                if spaklinalad == 1:
                    $ temetosirkosz2 = 0
                    show temetosirkosz2 onlayer hatso:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    if temetosirkosz1 == 0:
                        if temetosirkosz2 == 0:
                            if temetosirkosz3 == 0:
                                $ ladalakatnyithato = True
                    jump sirugrik2
                $ sirmohashezkell = True
                f "I can not read it from the moss... Here stands some kind of Maria... I should clean the grave first... I should find some kind of a scraping tool…"
                show screen temeto
                $ renpy. pause(hard=True)
label sirugrik2:
    if temetosirkosz2 == 1:
        f "I can not read the name, but here stands the name of Maria. The moss grew all around."
    if temetosirkosz2 == 0:
        f "{b}{space=400}Maria Fernanda Willson {p}{space=380}Feb.3.1905/Feb.12.19{size=+20}43"
    show screen temeto
$ renpy. pause(hard=True)
label temetosirkosz3:
    hide screen temeto
    if kerjmunkatkerhec == True:
        if sirokatmegtisztithatod == True:
            if temetosirkosz3 == 1:
                if metszoollonalad == 1:
                    $ temetosirkosz3 = 0
                    show temetosirkosz3 onlayer hatso:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    $ temetolevagotrozsak = 1
                    show temetolevagotrozsak onlayer hatso2:
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    if temetosirkosz1 == 0:
                        if temetosirkosz2 == 0:
                            if temetosirkosz3 == 0:
                                $ ladalakatnyithato = True
                    jump sirugrik3
                $ sirrozashezkell = True
                $ mamaholvan = "szobajaban"
                f "I can not read it from the roses... Here stands some kind of Maria... I should clean the grave first... I should cut the roses..."
                show screen temeto
                $ renpy. pause(hard=True)
label sirugrik3:
    if temetosirkosz3 == 1:
        f "I can not see the last name of Maria. Roses are all around."
    if temetosirkosz3 == 0:
        f "{b}{space=400}Maria Hillson{p}{space=300}Aug.5.1922/Feb.1.19{size=+20}67"

    show screen temeto
$ renpy. pause(hard=True)
label segisir:
    hide screen temeto
    f "An old gravestone."
    show screen temeto
$ renpy. pause(hard=True)
label levagottrozsak:
    hide screen temeto
    if hanyadiknapvan == 11:
        if rozsakatfelszedheted == True:
            hide screen temeto
            f "Cool! These roses seem to be fresh."
            $ temetolevagotrozsak = 0
            show temetolevagotrozsak onlayer hatso2:
                alpha 1.0
                linear 20.0 alpha 0.0
            show screen rozsatfelszedni
            show screen s5
            u ""
            show amandakosztumben540:
                xpos 0.27
                ypos 0.3
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show csillagok6resz onlayer elotte:
                xpos 0.1
                ypos -3.5
                linear 10.0 ypos 1.2
            show amandakosztumben onlayer elotte:
                xpos 0.1
                ypos 1.2
                linear 10.0 ypos -3.5
            show screen s1e5
            u ""
            play sound "audio/csillag.ogg"
            show screen s8e5
            u ""
            show screen s4
            am "Hy Fred! What are you planning with those roses?"
            hide invertori onlayer elotte6
            hide screen invertori2
            hide screen invertori
            hide csillagok6resz onlayer elotte
            hide amandakosztumben onlayer elotte
            show temetokozeli onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show amandapoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "I would like to give them to someone…”special”…"
            am "Understood. Someone cleaned the graves. Do you know that person?"
            show fiupoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Nope. Why do you ask?"
            am "Never mind. I wanted to thank him for his hard work… The graves looked awfull…"
            f "Let me think! Now I remember! I cleaned the graves!"
            am "Really? I don't believe you now..."
            show fiupoz2 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Why are you dressing like this?"
            am "This is my costume. I help out in the theater."
            show ferdpoz1szemlefelenez onlayer elotte
            f "Are you a princess or what?"
            am "Oh no. I am one of the 12 harem ladies. Not a big role, but it pays well."
            hide ferdpoz1szemlefelenez onlayer elotte
            f "Sounds great. Maybe I can visit the theater later. Can I go to the dressing room with you?"
            am "Are you kidding me?"
            hide amandakosztumben540
            show fiupoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz4 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Never mind. I had to ask it..."
            am "I have to go now. Baby did not receive any new letters yet, so we have nothing to do with each other."
            show fiupoz4 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Ok! Bye!"
            show temetokozeli onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show amandapoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            $ amandaholvan = "cukraszda"
            $ lidiaholvan = "amandavalbeszel"
            $ ismeretlencokaholvan = "sehol"
            $ rozsaknalad = 1
            show screen temeto
            show invertori onlayer elotte6:
                ypos 0.0
            show screen invertori
            $ renpy. pause(hard=True)
    f "Cut off roses."
    show screen temeto
$ renpy. pause(hard=True)
label megegetsir:
    hide screen temeto
    f "Someone burned this grave... I am wondering... Why?"
    show screen temeto
$ renpy. pause(hard=True)
label ismeretlensir:
    hide screen temeto
    f "Unknown grave."
    show screen temeto
$ renpy. pause(hard=True)
label resz9jelenet1:
    play music "audio/leskelodos.ogg" fadeout 1
    show screen s2
    u ""
    hide screen invertori2
    hide invertori onlayer elotte6
    $ resz9jelenet1 = True
    show haznallesed
    show text "{b}{size=+10}30 minutes later." onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s3
    u ""
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    queue sound "audio/tannenbaum.ogg"
    hide text onlayer screens
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1e5
    u ""
    fg "This is scary. The time is around midnight and he is searching between the ruins again…"
    fg "Did he kill my father? Is he dangerous? Does he really search for the crystals?"
    fg "Why the fuck is he humming?"
    show megleskapunal:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    fg "Fantastic, I followed this man to the old graveyard..."
    fg "What does he want?"
    fg "Is this a break-in?"
    show temetonelllesed:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    stop sound
    fg "He entered the mortuary… What is he doing? He did not turn on any lights. It is pitch dark…"
    fg "This graveyard is really scary… How long will it take for him to get out of the mortuary?"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    show elkapbaby
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s5
    b "I Got you! You fucking grave destroyer!"
    f "What! No! I am…!"
    b "Now I will teach you a lesson!"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show text "{b}{size=+10}A few minutes later…" onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s2
    u ""
    hide text onlayer screens
    show temetoihazalaphatter
    show amandapoztemetoben1
    show babypoz1
    show temetoihazasztala onlayer hatso
    show temetoihazafiupoz1 onlayer kozep
    show temetoihazmindenelott onlayer kozep2
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen s1
    u ""
    b "Now you shitty gnome! Explain to us! What are you doing in the graveyard during these hours?"
    f "Well… Nothing. WHat are You doing here?"
    show temetoihazafiupoz1 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz2 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "We live here. This is our home."
    show babypoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "Amanda! Shut up, Do not answer him! HE should answer us…"
    show babypoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show temetoihazafiupoz2 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz1 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "What is your name?"
    f "My name is Fred."
    b "Yeah and I am the Santa Claus! Hurry! Give me an identity card! Fast!"
    f "I can not. I left my papers at home. But I have a phone... Let us call some people, they can prove my words..."
    b "Sure, you and your friends can lie. You came here to ruin the gravestones again. Didn’t you?"
    f "I did not ruin any gravestone! I followed you…"
    show amandapoztemetoben1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben2:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Yes? By the way. Where have you been brother? Did you fuck the whores int he strip bar again? "
    show babypoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "I never would do such things!"
    show temetoihazafiupoz1 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz2 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "He lies! I saw him in the strip bar a few days ago!"
    show amandapoztemetoben2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show babypoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "I knew it! You spend all our money on bitches!!!! AGHHH!!! Tell me more Fred!"
    b "This is not true. You saw a similar guy I guess…"
    show babypoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "Amanda! Do not call him Fred. It is not his real name!"
    show babypoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show temetoihazafiupoz2 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz1 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "Show us your papers!"
    f "I can not. I left my papers in my room at home... I mean in Debra’s house…"
    f "Will you kill me? Just like my father?"
    b "What the hell are you talking about? I killed no one!"
    f "Really? Why are you searching between the ruins every single night?"
    b "Wel… I…"
    show amandapoztemetoben1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben2:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Why? I am interested Bro... What are you searching for?"
    show babypoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "I am a working Sister! I told you!"
    am "What are you searching for? And why? What do you have to do with that burned house?"
    f "I want to know this as well…"
    b "Do not change the subject. Fred… I mean this guy is ruining the gravestones… It is not your business… I... I am working there…"
    show babypoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "What do you have to do with those ruins anyway kid?"
    f "I lived there. The house which burned down was my home."
    am "Fred answered you and now you should answer us."
    show babypoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "Oh shit… Ok… I will explain. I can lose my job you know… It pays well… Do not tell this to anyone!"
    show temetoihazafiupoz1 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz2 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Who cares! Just spit it out! You spend all your money on whores so this will not be a big loss…"
    show babypoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show temetoihazafiupoz2 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz1 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "Well... I search there every night because I am searching for a red canvas bag. I am searching for a crystal collection."
    f "Who do these crystals belong to?"
    b "I do not know. I receview letters with orders and I have to burn the letters after I read them…"
    b "This guy wrote me, he lended the christals to the dead guy and after this guy commited suicide my boss did not get the christals back."
    f "I never heard of any collection of crystals."
    show amandapoztemetoben2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben1:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Alright. Now I understand... strange story…"
    b "I never heard of your father before kid. I have nothing to do with his death. A few days ago I heard a rumor about him. Someone told me he lost all his money and he wanted to close his firm…"
    f "I heard some rumors as well. Someone saw a man come out of the house before the explosion…"
    am "Do you think someone killed your father? I read about suicide."
    show temetoihazafiupoz1 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz2 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "I know. But some people say it was a murder. I will contact the cops and tell them everything."
    show temetoihazafiupoz2 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz1 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "Will you tell the cops about me? They will put me in jail!"
    show temetoihazafiupoz1 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show temetoihazafiupoz2 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Do not worry! Noone will call the police!"
    show babypoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "My brother told you. He only searches for those crystals. There is a guy who gave him orders. You should find him"
    am "Maybe he knows more about your fathers death."
    am "If you call the cops and give out my brother, they will put him in jail for sure."
    am "If you do this, we will tell them that you destroyed the gravestones."
    f "I did not want to… You have the right… we should wait…"
    b "Of course she is right! My sister is clever!"
    show amandapoztemetoben1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben2:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Shut up! Whore pimp! You will get some from me later for these! You Are spending our money on bitches! When can I go back to the university? When will we have enough money to pay for college?"
    am "Ok... Now let us agree on something."
    am "Bro! Did you find the crystals?"
    b "Nope!"
    show amandapoztemetoben2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben1:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "And you?"
    f "No."
    show amandapoztemetoben1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben2:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "When is the next letter comin?"
    b "I do not know. He sends me the money and the letters weekly."
    am "And how do you answer him if you find the crystals?"
    b "He gave me a special place to put the crystals in. I do not know his address."
    am "Next time Bro will keep the letter and we will check it. Fred! Bring a witness with you. Someone you trust."
    show amandapoztemetoben2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show babypoz2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Ok, but what if you write a letter and you try to trick me?"
    am "Trust me, I never lie!"
    f "I trust you but I do not trust your brother."
    am "I do not trust my brother either. But belive me, he is not enozgh clever to plana murder and find out such a story with a christal collection. I am surprised he knows the red color…"
    show babypoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show babypoz2:
        alpha 0.0
        linear 1.0 alpha 1.0
    b "Hey Sis! Do not ruin my image."
    show amandapoztemetoben1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben2:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "He won’t choose you for example, do not worry!"
    show amandapoztemetoben2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben1:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Will this be fine for you Fred?"
    f "Fine. Here is my phone number: +36……."
    b "Oh Sis!"
    show amandapoztemetoben1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben2:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Shut up or I will call the cops!"
    b "Ok! OK!"
    show amandapoztemetoben2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoztemetoben1:
        alpha 0.0
        linear 1.0 alpha 1.0
    am "Great! Now let’s head to bed! I am tired! We should rest!"
    $ tiltjaatereketszomszedok = True
    $ tiltjaatereketpark = True
    $ tiltjaatereketbolt = True
    $ tiltjaatereketegyetem = True
    $ tiltjaatereketsritbar = True
    $ tiltjaadebrakertjet = True
    $ fekete = True
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show invertori onlayer elotte6:
        yalign 0.0
    $ zenenincsismetles = 7
    play music "audio/temeto.ogg" fadeout 1
    jump temeto
$ renpy. pause(hard=True)
label macskafelvesztemeto:
    hide screen temeto
    $ macskaelszaladt = True
    if kutyatalban == "hal":
        $ ritamacskajakajatpap = 2
        $ kutyatalnalad = 2
        show macska-10:
            alpha 1.0
            linear 1.0 alpha 0.0
        show macskatalhalas:
            zoom 0.8
            xpos 0.22
            ypos 0.68
            alpha 0.0
            linear 1.0 alpha 1.0
        show macska-11:
            zoom 0.8
            xpos 0.22
            ypos 0.68
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s3
        u ""
        hide macska-10
        show macskatalhalas:
            zoom 0.8
            xpos 0.22
            ypos 0.68
            alpha 1.0
            linear 1.0 alpha 0.0
        show macska-11:
            zoom 0.8
            xpos 0.22
            ypos 0.68
            alpha 1.0
            linear 1.0 alpha 0.0
        $ kutyatalban = "semmi"
        $ kutyatalnalad = 1
        $ macskanalad = 1
        show screen s1
        u ""
        f "I got you Pepper! I will give you back to Rita."
        show screen temeto
        $ renpy. pause(hard=True)
    hide macska-10
    show macskaszalad:
        zoom 0.8
        xpos 0.22
        ypos 0.68
        linear 0.125 xpos 0.23
        linear 0.1 xpos 0.24
        linear 0.084 xpos 0.25
        linear 6.0 xpos 1.2
    show screen s1
    u ""
    f "This won't work. I need to find a way to catch him."
    show screen temeto
$ renpy. pause(hard=True)
label svetlanaatemetoben:
    hide screen temeto
    show temetokozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show svetlanapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    f "What are you doing here?"
    s "Give me money and I will tell you!"
    f "I do not have money, but wait! I gave you a coin which brought you 100.000.000 Forints! Is that money not enough to answer such a question? Really…"
    show svetlanapoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show svetlanapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    s "Silly me... I forgot… My memory is not the best…"
    f "Did someone die?"
    show svetlanapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show svetlanapoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    s "Nope, I just sample the candlesticks. I sell them again."
    show fiupoz1sokkolt onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "This is disgusting! You have enough money, don’t you?"
    show fiupoz1sokkolt onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    s "I can not stop working. What if I spend the money? Should I start again from the beginning? Nope! This is a nice business! Now scram!"
    show temetokozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show svetlanapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen temeto
$ renpy. pause(hard=True)
label dagiatemetoben:
    hide screen temeto
    $ ladabanvanvalamiszamodra = False
    show temetokozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show puffypoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    if hanyadiknapvan == 10:
        if ladatmegtalalhatod == 0:
            f "What are you doing here?"
            da "I am working, Bro! Did you find a job?"
            f "Not yet, but I will try my best."
            da "Thank you Brother! I love you!"
            jump dagitemetobenugrik
        if ladatmegtalalhatod == 1:
            if karkotonalad == 0:
                f "I found an old box, but I can not open it. Can you lend me a hand? "
                da "Show me…{w}This looks... interesting… I can not solve any mysteries and puzzles... I am silly. Use your head! Break the box!"
                f "I do not want to break the box. I like it. I want ott keep it."
                jump dagitemetobenugrik
        if karkotonalad == 1:
            f "Hey! How much money is this bracelet worth?"
            da "Let me see… {w}This is not gold for sure. There is no official sign inside… But it is quite heavy…"
            da "Let us look for it on the internet! I got the firm… {w} The price is 8000 Forints newly… I found some used pieces, they cost 3000 Forints."
            f "Thank you! You are the best! I will search for Svetlana and sell the bracelet."
            da "Ok, give me 2000 Forints. I will give it back shortly."
            f "I will."
            jump dagitemetobenugrik
        if penz >= 2000:
            $ adtalpenzdaginak10resz = True
            $ penz -= 2000
            $ dagiholvan = "sehol"
            hide dagi540allas1
            f "I have the 2000 Forints Bro! Here you are!"
            da "Thank you! You are my hero! Now I can go and buy the necklace. I just finished here. Let us meet tomorrow!"
            if adtalpenzdaginak10resz == True:
                if adtalpenzbebynak10resz == True:
                    $ mrpuliholvan = "cukrazda"
                    $ ritaholvan = "cukrazda"
                    $ cukrazdalathato = True
                    jump dagitemetobenugrik
            jump dagitemetobenugrik
    f "What are you doing here? Are you visiting an old grave?"
    da "Oh no. I am samling the candlesticks for Svetlana.I have no time. I am in a hurry."
label dagitemetobenugrik:
    show temetokozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show puffypoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1e5
    u ""
    $ ladabanvanvalamiszamodra = True
    show screen temeto

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
