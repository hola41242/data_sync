label ladaazinvertoriban:
    $ ladabanvagyok = True
    jump tiltasok
label ladaazinvertoribanszov:
    hide screen invertori2
    hide screen invertori
    hide invertori onlayer elotte6
    show talaltlada9resz onlayer elotte6:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show screen lada
    $ sirokatmegtisztithatod = True

$ renpy. pause(hard=True)
label ladaazinvertoribanki:
    $ fekete = True
    hide screen ladabelseje
    show talaltlada9resz onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
label ladaazinvertoribanki2:
    $ fekete = True
    hide screen ladabelseje
    hide talaltlada9resz onlayer elotte6
    hide talaltlada9reszlakat onlayer elotte6
    show talaltlada9reszbelurrolalap onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    show talaltlada9reszbelurrolkarkoto onlayer elotte6:
        alpha 1.0
        linear 2.0 alpha 0.0
    show screen s1
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
label ladarolalaptudnivalo:
    hide screen lada
    f "I found this old box between the ruins. Luckily it did not burn with the house."
    f "I see a padlock on the box. It needs 4 numbers to open it. How should I know the number combination?"
    show screen lada
$ renpy. pause(hard=True)
label ladanlevomariferirat:
    hide screen lada
    f "Maria… Maria... I can read the same name on the box all around… Does this box belong to Maria? Who is Maria?"
    f "I saw this name: Maria before soemwhere…"
    show screen lada
$ renpy. pause(hard=True)
label ladanlevolakat:
    hide screen lada
    hide talaltlada9reszlakat onlayer elotte6
    show talaltlada9reszlakat onlayer elotte6:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "Something is written on the other side of the padlock."
    f "This must be some kind of a number puzzle. What could be the solution? Hm…"
    python:
        ladalakatjanakkodjabeirt = renpy.input(_("Enter the code here:"))
        ladalakatjanakkodjabeirt = ladalakatjanakkodjabeirt.strip() or __("0")
    if ladalakatnyithato == True:
        if ladalakatjanakkodjabeirt == "1629":
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            jump ladakinyitva
    f "No. This is not the code…"
    show talaltlada9reszlakat onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen lada
$ renpy. pause(hard=True)
label ladakinyitva:
    show talaltlada9reszbelurrolalap onlayer elotte6
    if talaltlada9reszbelurrolkarkotoresz1 == 1:
        show talaltlada9reszbelurrolkarkotoresz1 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
    if talaltlada9reszbelurrolkarkotoresz2 == 1:
        show talaltlada9reszbelurrolkarkotoresz2 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
    if talaltlada9reszbelurrolkarkotoresz3 == 1:
        show talaltlada9reszbelurrolkarkotoresz3 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
    if talaltlada9reszbelurrolkarkotoresz4 == 1:
        show talaltlada9reszbelurrolkarkotoresz4 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
    if talaltlada9reszbelurrolkarkotoresz5 == 1:
        show talaltlada9reszbelurrolkarkotoresz5 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
    if talaltlada9reszbelurrolkarkotoresz6 == 1:
        show talaltlada9reszbelurrolkarkotoresz6 onlayer elotte6:
            alpha 0.0
            linear 1.0 alpha 1.0
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    $ ladabanvanvalamiszamodra = True
    show screen ladabelseje

$ renpy. pause(hard=True)
label talaltlada9reszbelurrolkarkotoresz1fel:
    $ talaltlada9reszbelurrolkarkotoresz1 = 0
    show talaltlada9reszbelurrolkarkotoresz1 onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    if talaltlada9reszbelurrolkarkotoresz1 == 0:
        if talaltlada9reszbelurrolkarkotoresz2 == 0:
            if talaltlada9reszbelurrolkarkotoresz3 == 0:
                if talaltlada9reszbelurrolkarkotoresz4 == 0:
                    if talaltlada9reszbelurrolkarkotoresz5 == 0:
                        if talaltlada9reszbelurrolkarkotoresz6 == 0:
                            show talaltlada9reszbelurrolkarkoto onlayer elotte6:
                                alpha 0.0
                                linear 2.0 alpha 1.0
                            show screen s2
                            u ""
                            $ ladabanvanvalamiszamodra = False
                            $ karkotonalad = 1
                            jump ladaazinvertoribanki2
$ renpy. pause(hard=True)
label talaltlada9reszbelurrolkarkotoresz2fel:
    $ talaltlada9reszbelurrolkarkotoresz2 = 0
    show talaltlada9reszbelurrolkarkotoresz2 onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    if talaltlada9reszbelurrolkarkotoresz1 == 0:
        if talaltlada9reszbelurrolkarkotoresz2 == 0:
            if talaltlada9reszbelurrolkarkotoresz3 == 0:
                if talaltlada9reszbelurrolkarkotoresz4 == 0:
                    if talaltlada9reszbelurrolkarkotoresz5 == 0:
                        if talaltlada9reszbelurrolkarkotoresz6 == 0:
                            show talaltlada9reszbelurrolkarkoto onlayer elotte6:
                                alpha 0.0
                                linear 2.0 alpha 1.0
                            show screen s2
                            u ""
                            $ ladabanvanvalamiszamodra = False
                            $ karkotonalad = 1
                            jump ladaazinvertoribanki2
$ renpy. pause(hard=True)
label talaltlada9reszbelurrolkarkotoresz3fel:
    $ talaltlada9reszbelurrolkarkotoresz3 = 0
    show talaltlada9reszbelurrolkarkotoresz3 onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    if talaltlada9reszbelurrolkarkotoresz1 == 0:
        if talaltlada9reszbelurrolkarkotoresz2 == 0:
            if talaltlada9reszbelurrolkarkotoresz3 == 0:
                if talaltlada9reszbelurrolkarkotoresz4 == 0:
                    if talaltlada9reszbelurrolkarkotoresz5 == 0:
                        if talaltlada9reszbelurrolkarkotoresz6 == 0:
                            show talaltlada9reszbelurrolkarkoto onlayer elotte6:
                                alpha 0.0
                                linear 2.0 alpha 1.0
                            show screen s2
                            u ""
                            $ ladabanvanvalamiszamodra = False
                            $ karkotonalad = 1
                            jump ladaazinvertoribanki2
$ renpy. pause(hard=True)
label talaltlada9reszbelurrolkarkotoresz4fel:
    $ talaltlada9reszbelurrolkarkotoresz4 = 0
    show talaltlada9reszbelurrolkarkotoresz4 onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    if talaltlada9reszbelurrolkarkotoresz1 == 0:
        if talaltlada9reszbelurrolkarkotoresz2 == 0:
            if talaltlada9reszbelurrolkarkotoresz3 == 0:
                if talaltlada9reszbelurrolkarkotoresz4 == 0:
                    if talaltlada9reszbelurrolkarkotoresz5 == 0:
                        if talaltlada9reszbelurrolkarkotoresz6 == 0:
                            show talaltlada9reszbelurrolkarkoto onlayer elotte6:
                                alpha 0.0
                                linear 2.0 alpha 1.0
                            show screen s2
                            u ""
                            $ ladabanvanvalamiszamodra = False
                            $ karkotonalad = 1
                            jump ladaazinvertoribanki2
$ renpy. pause(hard=True)
label talaltlada9reszbelurrolkarkotoresz5fel:
    $ talaltlada9reszbelurrolkarkotoresz5 = 0
    show talaltlada9reszbelurrolkarkotoresz5 onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    if talaltlada9reszbelurrolkarkotoresz1 == 0:
        if talaltlada9reszbelurrolkarkotoresz2 == 0:
            if talaltlada9reszbelurrolkarkotoresz3 == 0:
                if talaltlada9reszbelurrolkarkotoresz4 == 0:
                    if talaltlada9reszbelurrolkarkotoresz5 == 0:
                        if talaltlada9reszbelurrolkarkotoresz6 == 0:
                            show talaltlada9reszbelurrolkarkoto onlayer elotte6:
                                alpha 0.0
                                linear 2.0 alpha 1.0
                            show screen s2
                            u ""
                            $ ladabanvanvalamiszamodra = False
                            $ karkotonalad = 1
                            jump ladaazinvertoribanki2
$ renpy. pause(hard=True)
label talaltlada9reszbelurrolkarkotoresz6fel:
    $ talaltlada9reszbelurrolkarkotoresz6 = 0
    show talaltlada9reszbelurrolkarkotoresz6 onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    if talaltlada9reszbelurrolkarkotoresz1 == 0:
        if talaltlada9reszbelurrolkarkotoresz2 == 0:
            if talaltlada9reszbelurrolkarkotoresz3 == 0:
                if talaltlada9reszbelurrolkarkotoresz4 == 0:
                    if talaltlada9reszbelurrolkarkotoresz5 == 0:
                        if talaltlada9reszbelurrolkarkotoresz6 == 0:
                            show talaltlada9reszbelurrolkarkoto onlayer elotte6:
                                alpha 0.0
                                linear 2.0 alpha 1.0
                            show screen s2
                            u ""
                            $ ladabanvanvalamiszamodra = False
                            $ karkotonalad = 1
                            jump ladaazinvertoribanki2
$ renpy. pause(hard=True)
label muanygkorte:
    hide screen ladabelseje
    f "A plastic pear."
    show screen ladabelseje
$ renpy. pause(hard=True)
label muanygalma:
    hide screen ladabelseje
    f "A plastic apple."
    show screen ladabelseje
$ renpy. pause(hard=True)
label feketekavics:
    hide screen ladabelseje
    f "A dark stone."
    show screen ladabelseje
$ renpy. pause(hard=True)
label feherkavics:
    hide screen ladabelseje
    f "A white stone."
    show screen ladabelseje
$ renpy. pause(hard=True)
label regiragtapasz:
    hide screen ladabelseje
    f "An old wound dressing."
    show screen ladabelseje
$ renpy. pause(hard=True)
label papircetlik:
    hide screen ladabelseje
    f "Used paper sticky notes."
    show screen ladabelseje
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
