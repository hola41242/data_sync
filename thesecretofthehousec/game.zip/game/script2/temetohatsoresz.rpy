label temetohatsoresz:
    hide screen temeto
    f "The backyard of this old graveyard.I have nothing to do there."
    show screen temeto
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
