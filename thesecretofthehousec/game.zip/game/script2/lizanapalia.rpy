label lizanapalia:
    if hanyadiknapvan == 6:
        if lizakertjekesz < 2:
            if lizanapaliabamehec == True:
                $ holvagyok = "lizanapalia"
                jump tiltasok
        if lizanapaliabamehec == False:
            hide screen baloldalisomszed
            hide screen invertori
            hide invertori onlayer elotte6
            $ lizanapaliabamehec = True
            show lize3reszk58:
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 2.0
            l "Hy Honey! What is up?"
            f "I have time to clean your backyard. Can I come in? I can come back later, if needed…"
            l "Oh come in Dear!"
            $ invertorinejelenyenmeg = True
            $ holvagyok = "lizanapalia"
            jump tiltasok
    if hanyadiknapvan >= 7:
        $ holvagyok = "lizanapalia"
        jump tiltasok


    f "I can not enter Lisa’s house. I have nothing to do there."
$ renpy. pause(hard=True)
label lizanapaliaszov:
    show lizanappalia
    if hanyadiknapvan == 6:
        if lizanapaliaeloszormesz == True:
            $ fekete = True
            $ lizanapaliaeloszormesz = False
            show invertori onlayer elotte6:
                yalign 0.0
            show screen invertori2

            show cili:
                zoom 0.7
                xpos 0.5
                ypos 0.2
            show lizapoz1:
                zoom 0.8
                xpos 0.55
                ypos 0.2
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            show cili:
                zoom 0.7
                xpos 0.5
                ypos 0.2
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizapoz1:
                zoom 0.8
                xpos 0.55
                ypos 0.2
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizanappaliakozeli:
                alpha 0.0
                linear 1.0 alpha 1.0
            show cilipoz1:
                zoom 0.9
                xpos 0.0
                yalign 1.0
                alpha 0.0
                linear 1.0 alpha 1.0
            show anikamom:
                xpos 0.15
                ypos 0.15
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1:
                xpos -0.1
                ypos 0.07
                alpha 0.0
                linear 1.0 alpha 1.0
            l "Cili! Let me introduce you to Fred. She is Cili."
            c "Oh Liza! There are so many handsome guys hanging around here! You never told me you live in such a great place!"
            l "Well, you know he lived in the neighborhood. His home burned down a few days ago."
            c "Fred! Why did you come?"
            f "I should clean Liza’s backyard… I have time for it now..."
            c "You are such a nice guy! Yo remember me on our Alexander…"
            f "Who is Alexander?"
            c "He is our Factotum. Now I remember, I should go now… I hope we will meet again... Bye…"
            c "Bye Honey!"
            l "Bye Bye! See you soon!"
            hide cili
            show cilipoz1:
                zoom 0.9
                xpos 0.0
                yalign 1.0
                alpha 1.0
                linear 1.0 alpha 0.0
            l "Fred! The middle door leads to the bathroom. You can exit the house by using the left door and the right door leads to the garden."
            l "I have to do my daily practice to get in form. You will find me in the garden. Come and clean the backyard if you are ready!"
            f "Ok. I will follow you in a few minutes."
            show lizanappaliakozeli:
                alpha 1.0
                linear 1.0 alpha 0.0
            show anikamom:
                xpos 0.15
                ypos 0.15
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                xpos -0.1
                ypos 0.07
                alpha 1.0
                linear 1.0 alpha 0.0
    if hanyadiknapvan == 7:
        if tu == 0:
            show tuazinvertoriban:
                zoom 0.4
                xpos 0.37
                ypos 0.78
            if pulinapozoagya == 1:
                show csillogaskicsianim:
                    xpos 0.375
                    ypos 0.79
        if pulivalbeszelsz == 0:
            $ pulivalbeszelsz = 1
            $ fekete = True
            show mrpuli540:
                zoom 1.3
                xpos 0.5
                ypos 0.2
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            mr "Who are you? Where are you? I cannot see you! But I smell you!"
            show mrpuli540:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizanappaliakozeli:
                alpha 0.0
                linear 1.0 alpha 1.0
            show mrpulipoz:
                xpos 0.2
                xzoom -1.0
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1e5
            u ""
            f "This is me Mr. Puli… I am Fred."
            mr "Oh, you are here my boy! Why do you visit me in the dark?"
            f "The sun already raised Mr. Puli... Liza told me I should come to receview my payment."
            mr "Yeah, she has got the money. She worked all night long. She must be practicing in the garden."
            mr "Go and find her. I will be there in a few minutes as well. I have something to do…"
            f "Ok Mr. Puli…"
            hide mrpuli540
            show lizanappaliakozeli:
                alpha 1.0
                linear 1.0 alpha 0.0
            show mrpulipoz:
                xpos 0.2
                xzoom -1.0
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1:
                alpha 1.0
                linear 1.0 alpha 0.0
    if hanyadiknapvan >= 11:
        if mrpuliholvan == "lizanapaliban":
            show mrpuli540:
                zoom 1.3
                xpos 0.5
                ypos 0.2
        if holvanliza == "lizanapaliaban":
            show lizapoz1:
                zoom 0.8
                xpos 0.55
                ypos 0.2
        if ciliholvan == "lizanapaliaban":
            show cili:
                zoom 0.7
                xpos 0.5
                ypos 0.2
    if hanyadiknapvan == 12:
        if sujzonalad == 0:
            show sujzoklizalan

    jump engedejek

$ renpy. pause(hard=True)
label tutfelvenni:
    $ tu = 1
    show tuazinvertoriban:
        zoom 0.4
        xpos 0.37
        ypos 0.78
        alpha 1.0
        linear 1.0 alpha 0.0
    show csillogaskicsianim:
        xpos 0.375
        ypos 0.79
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label mrpulivalbeszelnilizanapaliban:
    hide screen lizanapalia
    show lizanappaliakozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mrpulipoz:
        xpos 0.2
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    f "Good morning Mr. Puli!"
    mr "Morning! Who the hell are you?"
    f "I am Fred. Do you remember me?"
    mr "Yes. What are you doing here?"
    f "I had something to do and I thought I would visit you and ask you how you feel today."
    mr "I am fine, but go now. I have no time for you now. I Am busy."
    f "Ok, I'm leaving now."
    show lizanappaliakozeli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mrpulipoz:
        xpos 0.2
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen lizanapalia
$ renpy. pause(hard=True)
label lizacilibeszelnapaliban:
    hide screen lizanapalia
    hide lizanappaliakozeli onlayer elotte
    hide cilipoz1 onlayer elotte
    hide anikamom onlayer elotte
    hide fiupoz1 onlayer elotte
    show lizanappaliakozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show cilipoz1 onlayer elotte:
        zoom 0.9
        xpos 0.0
        yalign 1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show anikamom onlayer elotte:
        xpos 0.15
        ypos 0.15
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        xpos -0.1
        ypos 0.07
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    f "Hello!"
    l "Hy Fred! What are you doing here?"
    f "I am looking for Cili."
    c "Me? Why?"
    f "I heard of your Factotum."
    c "Yes?"
    l "Just talk! I have to visit the bathroom…"
    $ holvanliza = "lizawcen"
    show anikamom onlayer elotte:
        xpos 0.15
        ypos 0.15
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen invertori2
    show cilikozelibeszed1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "Could you lend me the factotum's phone number. He should fix our drying machine."
    c "I can, but inform me first!"
    f "What kind of information do you need?"
    c "Liza talked to me about some juicy stuffs…"
    f "What kind of juicy stuff?"
    c "She told me you fucked her and it was great..."
    f "Yeah, that is right..."
    c "Tell me! Do you find me attractive?"
    f "You are a beautiful woman..."
    c "You could tell even more… Never mind. How much money do you want for a day?"
    f "Do you want to rent me? I am not a male wore!"
    u ""
    show cilikozelibeszed2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    c "Everyone has his price. Tell me your price!"
    f "I am sorry, but you can not buy my love… I would like to get the drying machine repaired only..."
    f "Could you give me the factotum number?"
    c "Well… Fine!... Alexander's number is. +36……"
    f "Thank you!"
    u ""
    hide cilikozelibeszed1 onlayer elotte
    $ sanyithivhatod = 1
    hide lizapoz1
    hide lizanappaliakozeli onlayer elotte
    hide cilipoz1 onlayer elotte
    hide fiupoz1 onlayer elotte
    show cilikozelibeszed2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show invertori onlayer elotte6:
        ypos 0.0
    show screen invertori
    show screen lizanapalia
$ renpy. pause(hard=True)
label cilibeszelnapaliban:
    hide screen lizanapalia
    hide lizanappaliakozeli onlayer elotte
    hide cilipoz1 onlayer elotte
    hide anikamom onlayer elotte
    hide fiupoz1 onlayer elotte
    show lizanappaliakozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show cilipoz1 onlayer elotte:
        zoom 0.9
        xpos 0.0
        yalign 1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        xpos -0.1
        ypos 0.07
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    if sanyithivhatod == 1:
        if sanyithivtad == True:
            $ sanyithivhatod = 2
            $ ciliszovegvaltozik = True
            hide cilikozelibeszed1 onlayer elotte
            hide cilikozelibeszed2 onlayer elotte
            hide cilikozelibeszed3 onlayer elotte
            c "Did you change your mind? What is your price?"
            f "Not really… Can I ask you a favor?"
            hide invertori onlayer elotte6
            hide screen invertori
            hide screen invertori2
            show cilikozelibeszed1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            c "Pending on… What kind of a favor?"
            f "Could you call Alexander? I have no money on my phone account."
            c "Why should I? Go and talk to him. He is standing before the supermarket now."
            f "How do you know this?"
            show cilikozelibeszed2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            c "He is waiting for us… So he will be there for a while…"
            f "Thank You! Will he help me?"
            show cilikozelibeszed2 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            c "Of course. Tell him, I sent you…"
            f "Thank You! You are a kind person."
            c "A kind person? Me? You are so naive! You owe me!"
            f "I do not mind. What can I help you with?"
            show cilikozelibeszed3 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            c "I will find out something for you."
            c "Now leave. I am waiting for Liza, we will go out to have fun. I will call you if I need you."
            f "Ok, here's my number: + 36……. Goodbye!"
            u ""
            $ sanyiholvan = "boltnal"
            $ fodoholvan = "sehol"
            $ annaholvan = "parktoban"
            hide lizanappaliakozeli onlayer elotte
            hide cilipoz1 onlayer elotte
            hide fiupoz1 onlayer elotte
            hide cilikozelibeszed1 onlayer elotte
            hide cilikozelibeszed2 onlayer elotte
            show cilikozelibeszed3 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            show invertori onlayer elotte6:
                ypos 0.0
            show screen invertori
            show screen lizanapalia
            $ renpy. pause(hard=True)
    if ciliszovegvaltozik == True:
        c "I have no time now. I will contact you later."
    if ciliszovegvaltozik == False:
        c "Nah? Will you be my male wore? What is your price?"
        f "Just… forget it…"
    show lizanappaliakozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show cilipoz1 onlayer elotte:
        zoom 0.9
        xpos 0.0
        yalign 1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        xpos -0.1
        ypos 0.07
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen lizanapalia
$ renpy. pause(hard=True)
label sanyithivod:
    $ sanyithivtad = True
    inf "There is not enough money in the account to start the call…"
$ renpy. pause(hard=True)
label sujzofel:
    if lizafehiv12napesbeszeltelvele == False:
        hide screen lizanapalia
        f "New and heavy dumbbells."
        show screen lizanapalia
    else:
        $ sujzonalad = 1
        show sujzoklizalan:
            alpha 1.0
            linear 1.0 alpha 0.0




$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
