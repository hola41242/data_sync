label lizafurdoje:
    if holvanliza == "lizawcen":
        hide screen lizanapalia
        f "It is closed. Liza is inside. She locked the door..."
        show screen lizanapalia
        $ renpy. pause(hard=True)
    $ holvagyok = "lizafurdoje"
    jump tiltasok
label lizafurdojeszov:
    show lizafurdo
    if hanyadiknapvan == 7:
        if kiskendofurdoben == True:
            show lizafurdokiskendo
    jump engedejek



$ renpy. pause(hard=True)
label lizatorolkozofurdo:
    hide screen lizafurdoje
    f "A towel. I do not need it."
    if hanyadiknapvan == 7:
        if pulinapozoagya >= 1:
            if pulinapozoagya < 3:
                f "A towel. I can not use it as a canvas. It is weak and small."
    show screen lizafurdoje
$ renpy. pause(hard=True)
label lizatorlokendofurdofel:
    if hanyadiknapvan == 7:
        if pulinapozoagya == 3:
            show lizafurdokiskendo:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ kiskendofurdoben = False
            $ renpy. pause(hard=True)
    f "A towel."
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
