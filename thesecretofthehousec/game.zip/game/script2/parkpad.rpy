label parkpad:
    $ holvagyok = "parkpad"
    jump tiltasok
$ renpy. pause(hard=True)
label parkpadszov:
    hide screen invertori2
    hide invertori onlayer elotte6
    $ invertorinejelenyenmeg = True
    show parkpadoshater
    if parkpadoshaterfaag == 1:
        show parkpadoshaterfaag
    if Edwardsholvan == "parkban":
        if parkpadoshaterlevel == 1:
            show parkpadoshaterlevel
        if parkpadoshatertaska == 1:
            show parkpadoshatertaska
        if parkpadoshatertej == 1:
            show parkpadoshatertej
        if parkpadoshaterzsepi == 1:
            show parkpadoshaterzsepi
        if parkpadoshaterszedvics == 1:
            show parkpadoshaterszedvics
    if Edwardsholvan == "parkban":
        show parkpadoshatermredwards
    if hanyadiknapvan >= 11:
        if csacsikalapjanalad == 0:
            show csacsikalapjafoldon:
                yalign 1.0
                xalign 1.0
    show parkpadoshaterbokor onlayer kozep
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen parkpad


$ renpy. pause(hard=True)
label faagfel:
    if agfuresznalad == 1:
        $ parkpadoshaterfaag = 0
        $ faagnalad = 1
        show parkpadoshaterfaag:
            alpha 1.0
            linear 1.0 alpha 0.0
        if faagnalad == 1:
            if gilisztanalad == 2:
                if horognalad == 1:
                    if madzagveheto == 2:
                        $ faagnalad = 2
                        $ gilisztanalad = 3
                        $ horognalad = 2
                        $ madzagveheto = 4
    else:
        hide screen parkpad
        if metszoollonalad == 1:
            $ kellegyagfuresz = True
            f "I can not cut down the branch with this tool, I should find a saw."
            show screen parkpad
            $ renpy. pause(hard=True)
        $ metszoollofelveheted = True
        f "I could use this branch for my fishing rod."
        show screen parkpad
$ renpy. pause(hard=True)
label parkpadedwards:
    hide screen parkpad
    if parkpadoshatertej == 2:
        f "Would you like to have a conversation with me?"
        mre "Nope, I am fine, young man. Leave me alone."
    if parkpadoshatertej == 1:
        if szedvicsnalad == 1:
            f "Here is your sandwich Sir…"
            $ parkpadoshatertej = 2
            show parkpadoshaterszedvics:
                alpha 0.0
                linear 1.0 alpha 1.0
            mre "Here is your milk young man."
            show parkpadoshatertej:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ szedvicsnalad = 2
            $ tejnalad = 1
            $ parkpadoshaterszedvics = 1
            f "Thank you very much. Let me know if you need any help! "
            mre "Thank you! I will…"
            f "Goodbye!"
            jump park
        if beszeltelmredwardssal == 2:
            f "What did you ask for the milk in exchange?"
            mre "A nice sandwich young man."
        if beszeltelmredwardssal == 0:
            $ beszeltelmredwardssal = 1
            f "Good morning Sir!"
            mre "Call me Mr. Edwards. Now leave me alone please…"
        if beszeltelmredwardssal == 1:
            f "I am sorry but can I have the milk?"
            mre "You should buy some in the supermarket…"
            f "I have no money. Would you like to have something for exchange?"
            mre "I wish for the kindness of a woman… I have lived alone for 40 years now. I am lonely…"
            f "I am not a owman… so I cna not help you in such things…"
            mre "Of course not... I thought about the kindness of a woman... no one has made me a sandwich in 40 years…"
            mre "It would be nice to have a sandwich. Can you make me a sandwich?"
            f "Oh! It will be here in no time!"
            $ beszeltelmredwardssal = 2
    if parkpadoshatertej == 0:
        $ beszeltelmredwardssal = 1
        f "Good morning Sir!"
        mre "Call me Mr- Edwards. Leave me alone."
        f "Excuse me!"
    show screen parkpad
$ renpy. pause(hard=True)
label parkpadlevel:
    hide screen parkpad
    f "An old letter."
    show screen parkpad
$ renpy. pause(hard=True)
label parkpadborond:
    hide screen parkpad
    f "An old dirty coffer."
    show screen parkpad
$ renpy. pause(hard=True)
label parkpadzsepi:
    hide screen parkpad
    f "A linen handkerchief."
    show screen parkpad
$ renpy. pause(hard=True)
label parkpadtej:
    hide screen parkpad
    f "A bottle of milk."
    show screen parkpad
$ renpy. pause(hard=True)
label parkpadszendvics:
    hide screen parkpad
    f "A sandwich."
    show screen parkpad
$ renpy. pause(hard=True)
label csacsikalapfel:
    if csacsikalapjatfelveheted == True:
        $ csacsikalapjanalad = 1
        show csacsikalapjafoldon:
            yalign 1.0
            xalign 1.0
            alpha 1.0
            linear 1.0 alpha 0.0
    else:
        f "This is an old dirty hat. Noone needs it anymore…"

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
