label debrakertje:
    if tiltjaadebrakertjet == False:
        $ holvagyok = "debrakertje"
        jump tiltasok
    if tiltjaadebrakertjet == True:
        f "I can not go there."
$ renpy. pause(hard=True)
label debrakertjeszov:
    show debrakertje
    show debrakertjegombak
    show debrakertjekomposztlada
    show pilango6reszanim:
        xpos 0.17
        ypos 0.7
    show pilango6reszanim2:
        zoom 0.4
        xpos 0.4
        ypos 0.2
    show pilango6reszanim3:
        zoom 0.8
        xzoom -1.0
        xpos 0.0
        ypos 0.2
    show pilango6reszanim4:
        xpos 0.824
        ypos 0.358
    show pilango6reszanim5:
        xzoom -1.0
        zoom 0.8
        xpos 0.739
        ypos 0.89
    show pilangoszal6reszanim6:
        zoom 1.2
        xpos 0.05
        ypos 0.77
    show pilangoszal6reszanim:
        xpos 0.65
        ypos 0.35
    show pilangoszal6reszanim2:
        zoom 0.9
        xzoom -1.0
        xpos 0.85
        ypos 0.55
    show pilangoszal6reszanim3:
        zoom 0.5
        xpos 0.2
        ypos 0.3
    show pilangoszal6reszanim4:
        zoom 0.4
        xzoom -1.0
        xpos 0.1
        ypos 0.4
    show pilangoszal6reszanim5:
        xpos 0.97
        ypos 0.2
    if debrakertjedudvak1 == 1:
        show debrakertjedudvak1
    if debrakertjedudvak2 == 1:
        show debrakertjedudvak2
    if debrakertjedudvak3 == 1:
        show debrakertjedudvak3
    if debrakertjedudvak4 == 1:
        show debrakertjedudvak4
    if debrakertjedudvak5 == 1:
        show debrakertjedudvak5
    if debrakertjegombakelveheto == 1:
        show debrakertjegombakelveheto
    if debrakertjekivagnivalobokor == 1:
        show debrakertjekivagnivalobokor
    if debrakertjekomposztladafu1 == 1:
        show debrakertjekomposztladafu1
    if debrakertjekomposztladafu2 == 1:
        show debrakertjekomposztladafu2
    if debraviragcserepe == 2:
        show debrakertbentanulcserep
    if debraholcsinal == "kertbentanul":
        show debrakertbentanulkonyv
        show debrakertbentanulanim
    if hanyadiknapvan == 7:
        if mamanyaklanc == 3:
            if kiteritesiproba == 0:
                show mama540keresmozanim:
                    zoom 1.0
                    xpos 0.55
                    ypos 0.4
    if hanyadiknapvan == 8:
        show pokhalo
        if poknalad == 0:
            show csillogaskicsianim:
                xpos 0.32
                ypos 0.91
            if pokel == True:
                show pok
            if pokel == False:
                show pokhalott
        if debraholcsinal == "kertbentanul":
            $ mamaholvan = "szobajaban."
        if mamaholvan == "kertben.":
            show mamalabal2r11080:
                zoom 0.5
                xpos 0.12
                ypos 0.2
    if hanyadiknapvan == 9:
        if giliszta2 == 1:
            show debrakertjegiliszta
            if fogjhalat == 1:
                show csillogaskicsianim:
                    xpos 0.4
                    ypos 0.93



    jump engedejek
$ renpy. pause(hard=True)
label debrakertjekomposztalo:
    hide screen debrakertje
    if hanyadiknapvan == 12:
        if asonallad == 1:
            if komposztnallad == 0:
                $ komposztnallad = 1
    if kompostszemet == False:
        f "Composting bin."
    if kompostszemet == True:
        if szemeteszak > 1:
            play sound "audio/elvesz.wav"
        $ szemeteszak = 1
        $ kompostszemet = False
    show screen debrakertje
$ renpy. pause(hard=True)
label debrakertjegombak:
    if hanyadiknapvan == 8:
        if lizanakmegmutatadareceptet == True:
            if gombanalad == 0:
                $ gombanalad = 1
                $ targyazinvertoriban += 1
                $ debrakertjegombakelveheto = 0
                show debrakertjegombakelveheto:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                $ renpy. pause(hard=True)
    hide screen debrakertje
    f "Mushrooms."
    show screen debrakertje
$ renpy. pause(hard=True)
label debrakertjebokorutban:
    hide screen debrakertje
    f "I can not pass through this bush. It blocks the way."
    f "I need a secateurs."
    $ metszoollo = 1
    show screen debrakertje
$ renpy. pause(hard=True)
label debrakertjebokortlevagazutbol:
    if debraviragcserepe == 1:
        f "I have to put down the flowerpot."
        $ renpy. pause(hard=True)
    if debraviragcserepe == 0:
        f "I should bring out the flowerpot."
        $ renpy. pause(hard=True)
    queue sound "audio/bokornyiras.ogg"
    queue sound "audio/bokornyiras.ogg"
    queue sound "audio/bokornyiras.ogg"
    queue sound "audio/bokornyiras.ogg"
    queue sound "audio/bokornyiras.ogg"
    queue sound "audio/bokornyiras.ogg"
    hide screen debrakertje
    show screen bokorazutban
    $ debrakertjekomposztladafu1 = 1
    $ debrakertjekomposztladafu2 = 1
    show debrakertjekomposztladafu1:
        alpha 0.0
        pause 5.0
        linear 1.0 alpha 1.0
    show debrakertjekomposztladafu2:
        alpha 0.0
        pause 12.5
        linear 1.0 alpha 1.0
    show debrakertjekivagnivalobokor:
        alpha 1.0
        linear 20.0 alpha 0.0
$ renpy. pause(hard=True)
label viragcserepetletenni:
    hide screen debrakertje
    $ debraviragcserepe = 2
    $ debraholcsinal = "kertbentanul"
    show debrakertbentanulcserep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show debrakertbentanulkonyv:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrakertbentanulanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen debrakertje
$ renpy. pause(hard=True)
label debratmegnezedakertben:
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen debrakertje
    hide debraolvaskertben
    show debraolvaskertben:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    if hanyadiknapvan == 7:
        f "What are you doing?"
        d "I learn about horticulture. This is some kind of relaxation I guess... It is fucking boring."
        f "I thought you were very busy today."
        d "Yeah, I have a lot to do, but you will do all my housework, because you are thankful for me..."
    if hanyadiknapvan == 8:
        f "Debra! Can I ask you for a bowl? I have to prepare a cream."
        d "Why do you think I will help you?"
        f "Well… I only ask…"
        d "Use the turmix machine."
        f "Can I put a dead spider in the turmix machine?"
        d "Now i think… do not use the turmix machine… I remember i have an old bowl… it was a present…"
        d "I will go to the kitchen now and I will put the bowl on the table for you."
        f "Thank you!"
        $ mozsarazasztalon = 1
        $ debraholcsinal = "foz"
        hide debrakertbentanulkonyv
        hide debrakertbentanulanim
    if hanyadiknapvan == 9:
        if annavalbeseltelparktonal == 1:
            if betadinnalad == 0:
                f "Debra! Can I ask for the disinfectant?"
                d "What is it? Did Fifi bite Puffy again?"
                f "No, someone else got injured..."
                d "Do you work for the Red Cross? Why do you have to help everyone?"
                f "A friend was injured by an old hook and I have to take care of her wound..."
                d "Sounds good… Wait a minute!"
                hide fekete onlayer screens
                show fekete onlayer screens:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1
                u ""
                show text "{b}{size=+10}A few minutes later…" onlayer screens:
                    xpos 0.5
                    xalign 0.5
                    yalign 0.475
                show screen s2
                u ""
                hide text onlayer screens
                hide fekete onlayer screens
                show fekete onlayer screens:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1
                u ""
                $ betadinnalad = 1
                d "Bring the bottle back. Do not spill it out! I am not in the mood to buy another. "
                f "I thought you had no money..."
                d "Same thing…"
    if hanyadiknapvan == 12:
        f "Thank you for the sandwiches!"
        d "What kind of sandwiches?"
        f "The sandwiches you are preparing for me every morning…"
        d "So you are the asshole who is taking my sandwiches every fucking day?"
        f "Well... Should I give them back to you?"
        d "You touched them. I do not need them anymore."
        f "Thank you! They are really tasty!"
        d "Oh... my… I will put a note on the table next time…"
        d "Go now! I want to plant some flowers."
    u ""
    show debraolvaskertben:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen debrakertje
$ renpy. pause(hard=True)
label kertbenmamavalbeszed:
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen debrakertje
    hide debrakertkozelei
    hide fiupoz1
    hide mamabikinibenpoz1
    show debrakertkozelei:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamabikinibenpoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    m "Oh Freddy! I can not find my neckleak!"
    f "Do not worry! You will find it for sure!"
    m "Maybe you have the right, but I am worried."
    show debrakertkozelei:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mamabikinibenpoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen debrakertje
$ renpy. pause(hard=True)
label pokotfel:
    if pokel == True:
        $ pokfelvetel = 1
        $ mamaholvan = "konyha"
        f "I won’t touch it! It is alive! I hate spiders!"
    if pokel == False:
        $ poknalad = 1
        show pokhalott:
            alpha 1.0
            linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label beszedmamavalkertben8resz:
    hide debrakertkozelei
    hide mamapoz3r1
    hide fiupoz1
    hide screen debrakertje
    show debrakertkozelei:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamapoz3r1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        alpha 0.0
        linear 1.0 alpha 1.0
    m "This felt good! I feel the garden is much cleaner now..."
    show debrakertkozelei:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mamapoz3r1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen debrakertje
$ renpy. pause(hard=True)
label giliszta2fel:
    $ giliszta2 = 0
    $ gilisztanalad +=1
    hide csillogaskicsianim
    show debrakertjegiliszta:
        alpha 1.0
        linear 1.0 alpha 0.0
    if faagnalad == 1:
        if gilisztanalad == 2:
            if horognalad == 1:
                if madzagveheto == 2:
                    $ faagnalad = 2
                    $ gilisztanalad = 3
                    $ horognalad = 2
                    $ madzagveheto = 4
$ renpy. pause(hard=True)
label viragcserepakertben:
    hide screen debrakertje
    if hanyadiknapvan == 12:
        if debrafeladatotad12nap == 1:
            if komposztnallad == 1:
                if viraghagymanallad == 1:
                    $ komposztnallad = 2
                    $ viraghagymanallad = 2
                    show debrakertbentanulcserep2:
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    show screen s1
                    u ""
                    hide debrakertbentanulcserep
                    $ debraviragcserepe = 3
                    $ viragcserepnalad2 = 1
                    show debrakertbentanulcserep2:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    show screen debrakertje
                    $ renpy. pause(hard=True)

    f "Flowerpot."
    show screen debrakertje
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
