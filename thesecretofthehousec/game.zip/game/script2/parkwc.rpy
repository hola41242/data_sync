label parkwc:
    hide screen park
    f "This is the bathroom of the park."
    show screen park

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
