label gyerekszoba:
    hide screen fajasokertfele
    f "Debra’s daughter's room. She is not home. I can not enter her room."
    show screen fajasokertfele

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
