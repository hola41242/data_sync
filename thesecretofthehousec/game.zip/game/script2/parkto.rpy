label parkkisto:
    if mehetszaparktohoz == True:
        $ holvagyok = "parkto"
        jump tiltasok
    if hanyadiknapvan >= 8:
        if lizanakmegmutatadareceptet == True:
            if tojasnalad == 1:
                if tulipannalad == 1:
                    if gyongyviragnalad == 1:
                        if poknalad == 1:
                            if gombanalad == 1:
                                if uditosmagamhozveni == 1:
                                    $ mehetszaparktohoz = True
                                    $ holvagyok = "parkto"
                                    jump tiltasok
    if lizanakmegmutatadareceptet == True:
        if mehetszaparktohoz == False:
            hide screen park
            f "I do not want to go there now. I have to pick up some ingredients first."
            show screen park
    if lizanakmegmutatadareceptet == False:
        hide screen park
        f "A little lake in the park."
        if hanyadiknapvan == 8:
            if receptnalad == 1:
                f "I do not want to go there. I should show the recipe to Liza first."
        show screen park
        $ renpy. pause(hard=True)
$ renpy. pause(hard=True)
label parktoszov:
    show parktoalap
    show parktopadok
    show parktohatsofa
    if parktoszemet2 == 0:
        show parktohalak
    show parktoelsofa onlayer hatso
    show parktobokrokelol onlayer hatso2
    if parktoszemet1 == 1:
        show parktoszemet1 onlayer hatso3
    if parktoszemet2 == 1:
        show parktoszemet2
    if parktoszemet3 == 1:
        show parktoszemet3 onlayer hatso3
    if parktoszemet4 == 1:
        show parktoszemet4 onlayer hatso3
    if parktoszemet5 == 1:
        show parktoszemet5 onlayer hatso3
    if parktoszemet6 == 1:
        show parktoszemet6
    if parktoszemet7 == 1:
        show parktoszemet7 onlayer hatso3
    if parktoszemet8 == 1:
        show parktoszemet8 onlayer hatso3
    if pillangokaparktoban == True:
        show pilango6reszanim onlayer hatso3:
            xpos 0.305
            ypos 0.64
        show pilango6reszanim2 onlayer hatso3:
            zoom 0.8
            xpos 0.34
            ypos 0.47
        show pilango6reszanim3 onlayer hatso3:
            zoom 1.1
            xzoom -1.0
            xpos 0.06
            ypos 0.39
        show pilango6reszanim4 onlayer hatso3:
            xpos 0.752
            ypos 0.445
        show pilango6reszanim5 onlayer hatso3:
            xzoom -1.0
            zoom 0.8
            xpos 0.9
            ypos 0.39
        show pilangoszal6reszanim6 onlayer hatso3:
            zoom 1.2
            xpos 0.34
            ypos 0.62
        show pilangoszal6reszanim onlayer hatso3:
            xpos 0.78
            ypos 0.6
        show pilangoszal6reszanim2 onlayer hatso3:
            zoom 0.9
            xzoom -1.0
            xpos 0.83
            ypos 0.52
        show pilangoszal6reszanim3 onlayer hatso3:
            zoom 0.5
            xpos 0.302
            ypos 0.392
        show pilangoszal6reszanim4 onlayer hatso3:
            zoom 0.4
            xzoom -1.0
            xpos 0.53
            ypos 0.42
        show pilangoszal6reszanim5 onlayer hatso3:
            zoom 0.45
            xpos 0.43
            ypos 0.43
    if holvanliza == "parktonal":
        $ holvanliza = "parktonalviragotkutata1"
        show lizapoz1 onlayer elotte6:
            zoom 0.9
            xzoom -1.0
            xpos 0.05
            ypos 0.1
        jump lizabeszdtonal8resz
    if holvanliza == "parktonalviragotkutata1":
        show screen lizamejzozbanvan
        $ lizamekpozbanvan = 1
        show lizagyomlalanim:
            xzoom -1.0
            zoom 0.6
            xpos 0.4
            ypos 0.2
            pause 9.0
            linear 1.0 alpha 0.0
            pause 9.0
            linear 1.0 alpha 1.0
            repeat
        show lizakeresanim1:
            zoom 0.65
            xpos 0.45
            ypos 0.46
            alpha 0.0
            pause 9.0
            linear 1.0 alpha 1.0
            pause 9.0
            linear 1.0 alpha 0.0
            repeat
        show lizakeresalap1:
            zoom 0.65
            xpos 0.45
            ypos 0.46
            alpha 0.0
            pause 9.0
            linear 1.0 alpha 1.0
            pause 9.0
            linear 1.0 alpha 0.0
            repeat
    if holvanliza == "parktonalviragotkutata2":
        show screen lizamejzozbanvan
        $ lizamekpozbanvan = 1
        show lizagyomlalanim2:
            zoom 0.4
            xpos -0.00
            ypos 0.23
            pause 9.0
            linear 1.0 alpha 0.0
            pause 9.0
            linear 1.0 alpha 1.0
            repeat
        show lizakeresanim2:
            zoom 0.4
            xzoom -1.0
            xpos 0.15
            ypos 0.4
            alpha 0.0
            pause 9.0
            linear 1.0 alpha 1.0
            pause 9.0
            linear 1.0 alpha 0.0
            repeat
        show lizakeresalap2:
            zoom 0.4
            xzoom -1.0
            xpos 0.15
            ypos 0.4
            alpha 0.0
            pause 9.0
            linear 1.0 alpha 1.0
            pause 9.0
            linear 1.0 alpha 0.0
            repeat
    if macskaholvan == "parktonal":
        show macska-10:
            zoom 0.34
            xzoom -1.0
            xpos 0.43
            ypos 0.47
    if annaholvan == "parktonal":
        show annaatonalhaterben onlayer hatso3
    if annaholvan == "parktonal2":
        show toesannafekszik onlayer hatso3
        hide parktobokrokelol onlayer hatso2
        show parktobokrokelol onlayer hatso3
    if annaholvan == "parktoban":
        show annaatobananimseta:
            parallel:
                xpos 0.75
                linear 5.525 xpos 0.85
                pause 2.125
                linear 5.525 xpos 0.75
                pause 2.125
            parallel:
                ypos 0.43
                linear 5.525 ypos 0.44
                pause 2.125
                linear 5.525 ypos 0.43
                pause 2.125
            parallel:
                xzoom 1.0
                pause 7.75
                xzoom -1.0
                pause 7.75
                xzoom 1.0
            repeat
    if fodoholvan == "parkto":
        show csovesfodo onlayer hatso3:
            zoom 0.8
            xpos 0.5
            ypos 0.2
        hide parktobokrokelol onlayer hatso2
        show parktobokrokelol onlayer hatso3
    if hanyadiknapvan == 10:
        show parktoszokenovisszahuzanim onlayer hatso
    if hanyadiknapvan >= 11:
        $ pucernoaparktoban = renpy.random.randint (1, 10)
        $ pucernoaparktoban = (pucernoaparkban)
        if pucernoaparktoban > 3:
            show parktoszokenovisszahuzanim onlayer hatso


    jump engedejek

$ renpy. pause(hard=True)
label lizabeszdtonal8resz:
    $ fekete = True
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    l "I am so glad you came, Fred! I am searching for the flower but I did not find it until now..."
    show lizapoz1 onlayer elotte6:
        zoom 0.9
        xzoom -1.0
        xpos 0.05
        ypos 0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show lizagyomlalanim:
        xzoom -1.0
        zoom 0.6
        xpos 0.4
        ypos 0.2
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show lizagyomlalanim:
        xzoom -1.0
        zoom 0.6
        xpos 0.4
        ypos 0.2
        pause 9.0
        linear 1.0 alpha 0.0
        pause 9.0
        linear 1.0 alpha 1.0
        repeat
    show lizakeresanim1:
        zoom 0.65
        xpos 0.45
        ypos 0.46
        alpha 0.0
        pause 9.0
        linear 1.0 alpha 1.0
        pause 9.0
        linear 1.0 alpha 0.0
        repeat
    show lizakeresalap1:
        zoom 0.65
        xpos 0.45
        ypos 0.46
        alpha 0.0
        pause 9.0
        linear 1.0 alpha 1.0
        pause 9.0
        linear 1.0 alpha 0.0
        repeat
    show screen lizamejzozbanvan
    jump engedejek
$ renpy. pause(hard=True)
label parktoszemet1:
    hide screen invertori
    show screen invertori2
    hide screen parkto
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parktoszemet1 -= 1
            show parktoszemet1 onlayer hatso3:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump lizaodaadjaaviragot
    hide screen invertori2
    show screen invertori
    show screen parkto
$ renpy. pause(hard=True)
label parktoszemet2:
    hide screen invertori
    show screen invertori2
    hide screen parkto
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if gerebjenalad == 0:
        $ gerebjekell8resz = True
        f "I need a rake. I can not reach the seaweed from here… I do not want to get wet."
    if szemeteszsaknalad == True:
        if gerebjenalad == 1:
            if szemeteszak >= 4:
                f "The rubbish bag is full, I have to empty the bag first."
            if szemeteszak < 4:
                play sound "audio/elvesz.wav"
                show screen parktoszemet2
                $ szemeteszedtel += 1
                $ parktoszemet2 -= 1
                show parktoszemet2:
                    alpha 1.0
                    linear 20.0 alpha 0.0
                show parktohalak:
                    alpha 0.0
                    linear 20.0 alpha 1.0
                if holvanliza == "parktonalviragotkutata1":
                    $ holvanliza = "parktonalviragotkutata2"
                    if lizamekpozbanvan == 1:
                        hide lizakeresanim1
                        hide lizakeresalap1
                        show lizagyomlalanim:
                            xzoom -1.0
                            zoom 0.6
                            xpos 0.4
                            ypos 0.2
                            alpha 1.0
                            linear 1.0 alpha 0.0
                        show lizagyomlalanim2:
                            zoom 0.4
                            xpos -0.00
                            ypos 0.23
                            alpha 0.0
                            linear 1.0 alpha 1.0
                    if lizamekpozbanvan == 2:
                        hide lizagyomlalanim
                        show lizakeresanim1:
                            zoom 0.65
                            xpos 0.45
                            ypos 0.46
                            alpha 1.0
                            linear 1.0 alpha 0.0
                        show lizakeresalap1:
                            zoom 0.65
                            xpos 0.45
                            ypos 0.46
                            alpha 1.0
                            linear 1.0 alpha 0.0
                        show lizagyomlalanim2:
                            zoom 0.4
                            xpos -0.00
                            ypos 0.23
                            alpha 0.0
                            linear 1.0 alpha 1.0
                    pause 1.0
                    hide screen lizamejzozbanvan
                    show screen lizamejzozbanvan
                    hide lizakeresanim1
                    hide lizakeresalap1
                    hide lizagyomlalanim
                    show lizagyomlalanim2:
                        zoom 0.4
                        xpos -0.00
                        ypos 0.23
                        pause 9.0
                        linear 1.0 alpha 0.0
                        pause 9.0
                        linear 1.0 alpha 1.0
                        repeat
                    show lizakeresanim2:
                        zoom 0.4
                        xzoom -1.0
                        xpos 0.15
                        ypos 0.4
                        alpha 0.0
                        pause 9.0
                        linear 1.0 alpha 1.0
                        pause 9.0
                        linear 1.0 alpha 0.0
                        repeat
                    show lizakeresalap2:
                        zoom 0.4
                        xzoom -1.0
                        xpos 0.15
                        ypos 0.4
                        alpha 0.0
                        pause 9.0
                        linear 1.0 alpha 1.0
                        pause 9.0
                        linear 1.0 alpha 0.0
                        repeat
                    jump ugrik8reszliza
                if holvanliza == "parktonalviragotkutata2":
                    $ holvanliza = "parktonalviragotkutata1"
                    if lizamekpozbanvan == 1:
                        hide lizakeresanim2
                        hide lizakeresalap2
                        hide lizagyomlalanim2
                        hide lizagyomlalanim
                        show lizagyomlalanim:
                            xzoom -1.0
                            zoom 0.6
                            xpos 0.4
                            ypos 0.2
                            alpha 0.0
                            linear 1.0 alpha 1.0
                        show lizagyomlalanim2:
                            zoom 0.4
                            xpos -0.00
                            ypos 0.23
                            alpha 1.0
                            linear 1.0 alpha 0.0
                    if lizamekpozbanvan == 2:
                        hide lizagyomlalanim2
                        show lizakeresanim2:
                            zoom 0.4
                            xzoom -1.0
                            xpos 0.15
                            ypos 0.4
                            alpha 1.0
                            linear 1.0 alpha 0.0
                        show lizakeresalap2:
                            zoom 0.4
                            xzoom -1.0
                            xpos 0.15
                            ypos 0.4
                            alpha 1.0
                            linear 1.0 alpha 0.0
                        show lizagyomlalanim:
                            xzoom -1.0
                            zoom 0.6
                            xpos 0.4
                            ypos 0.2
                            ypos 0.2
                            alpha 0.0
                            linear 1.0 alpha 1.0
                    pause 1.0
                    hide screen lizamejzozbanvan
                    show screen lizamejzozbanvan
                    hide lizakeresanim1
                    hide lizakeresalap1
                    hide lizagyomlalanim
                    show lizagyomlalanim:
                        xzoom -1.0
                        zoom 0.6
                        xpos 0.4
                        ypos 0.2
                        pause 9.0
                        linear 1.0 alpha 0.0
                        pause 9.0
                        linear 1.0 alpha 1.0
                        repeat
                    show lizakeresanim1:
                        zoom 0.65
                        xpos 0.45
                        ypos 0.46
                        alpha 0.0
                        pause 9.0
                        linear 1.0 alpha 1.0
                        pause 9.0
                        linear 1.0 alpha 0.0
                        repeat
                    show lizakeresalap1:
                        zoom 0.65
                        xpos 0.45
                        ypos 0.46
                        alpha 0.0
                        pause 9.0
                        linear 1.0 alpha 1.0
                        pause 9.0
                        linear 1.0 alpha 0.0
                        repeat
                    jump ugrik8reszliza
                label ugrik8reszliza:
                show screen s8
                u ""
                $ szemeteszak += 1
                show screen s10
                u ""
                $ szemeteszak += 1
                show screen s2
                u ""
                $ szemeteszak += 1
                if szemeteszedtel == 8:
                    jump lizaodaadjaaviragot
    hide screen invertori2
    show screen invertori
    show screen parkto
$ renpy. pause(hard=True)
label parktoszemet3:
    hide screen invertori
    show screen invertori2
    hide screen parktototo
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            show screen parktoszemet3
            $ szemeteszedtel += 1
            $ parktoszemet3 -= 1
            show parktoszemet3 onlayer hatso3:
                alpha 1.0
                linear 5.0 alpha 0.0
            show screen s1
            u ""
            $ szemeteszak += 1
            show screen s2
            u ""
            $ szemeteszak += 1
            show screen s2
            u ""
            $ szemeteszak += 1
            if szemeteszedtel == 8:
                jump lizaodaadjaaviragot
    hide screen invertori2
    show screen invertori
    show screen parkto
$ renpy. pause(hard=True)
label parktoszemet4:
    hide screen invertori
    show screen invertori2
    hide screen parkto
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parktoszemet4 -= 1
            show parktoszemet4 onlayer hatso3:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump lizaodaadjaaviragot
    hide screen invertori2
    show screen invertori
    show screen parkto
$ renpy. pause(hard=True)
label parktoszemet5:
    hide screen invertori
    show screen invertori2
    hide screen parkto
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            show screen parktoszemet5
            $ szemeteszedtel += 1
            $ parktoszemet5 -= 1
            show parktoszemet5 onlayer hatso3:
                alpha 1.0
                linear 5.0 alpha 0.0
            show screen s1
            u ""
            $ szemeteszak += 1
            show screen s2
            u ""
            $ szemeteszak += 1
            show screen s2
            u ""
            $ szemeteszak += 1
            if szemeteszedtel == 8:
                jump lizaodaadjaaviragot
    hide screen invertori2
    show screen invertori
    show screen parkto
$ renpy. pause(hard=True)
label parktoszemet6:
    hide screen invertori
    show screen invertori2
    hide screen parkto
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            show screen parktoszemet6
            $ szemeteszedtel += 1
            $ parktoszemet6 -= 1
            show parktoszemet6:
                alpha 1.0
                linear 20.0 alpha 0.0
            if holvanliza == "parktonalviragotkutata1":
                $ holvanliza = "parktonalviragotkutata2"
                if lizamekpozbanvan == 1:
                    hide lizakeresanim1
                    hide lizakeresalap1
                    show lizagyomlalanim:
                        xzoom -1.0
                        zoom 0.6
                        xpos 0.4
                        ypos 0.2
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    show lizagyomlalanim2:
                        zoom 0.4
                        xpos -0.00
                        ypos 0.23
                        alpha 0.0
                        linear 1.0 alpha 1.0
                if lizamekpozbanvan == 2:
                    hide lizagyomlalanim
                    show lizakeresanim1:
                        zoom 0.65
                        xpos 0.45
                        ypos 0.46
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    show lizakeresalap1:
                        zoom 0.65
                        xpos 0.45
                        ypos 0.46
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    show lizagyomlalanim2:
                        zoom 0.4
                        xpos -0.00
                        ypos 0.23
                        alpha 0.0
                        linear 1.0 alpha 1.0
                pause 1.0
                hide screen lizamejzozbanvan
                show screen lizamejzozbanvan
                hide lizakeresanim1
                hide lizakeresalap1
                hide lizagyomlalanim
                show lizagyomlalanim2:
                    zoom 0.4
                    xpos -0.00
                    ypos 0.23
                    pause 9.0
                    linear 1.0 alpha 0.0
                    pause 9.0
                    linear 1.0 alpha 1.0
                    repeat
                show lizakeresanim2:
                    zoom 0.4
                    xzoom -1.0
                    xpos 0.15
                    ypos 0.4
                    alpha 0.0
                    pause 9.0
                    linear 1.0 alpha 1.0
                    pause 9.0
                    linear 1.0 alpha 0.0
                    repeat
                show lizakeresalap2:
                    zoom 0.4
                    xzoom -1.0
                    xpos 0.15
                    ypos 0.4
                    alpha 0.0
                    pause 9.0
                    linear 1.0 alpha 1.0
                    pause 9.0
                    linear 1.0 alpha 0.0
                    repeat
                jump ugrik8reszliza
            if holvanliza == "parktonalviragotkutata2":
                $ holvanliza = "parktonalviragotkutata1"
                if lizamekpozbanvan == 1:
                    hide lizakeresanim2
                    hide lizakeresalap2
                    hide lizagyomlalanim2
                    hide lizagyomlalanim
                    show lizagyomlalanim:
                        xzoom -1.0
                        zoom 0.6
                        xpos 0.4
                        ypos 0.2
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    show lizagyomlalanim2:
                        zoom 0.4
                        xpos -0.00
                        ypos 0.23
                        alpha 1.0
                        linear 1.0 alpha 0.0
                if lizamekpozbanvan == 2:
                    hide lizagyomlalanim2
                    show lizakeresanim2:
                        zoom 0.4
                        xzoom -1.0
                        xpos 0.15
                        ypos 0.4
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    show lizakeresalap2:
                        zoom 0.4
                        xzoom -1.0
                        xpos 0.15
                        ypos 0.4
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    show lizagyomlalanim:
                        xzoom -1.0
                        zoom 0.6
                        xpos 0.4
                        ypos 0.2
                        ypos 0.2
                        alpha 0.0
                        linear 1.0 alpha 1.0
                pause 1.0
                hide screen lizamejzozbanvan
                show screen lizamejzozbanvan
                hide lizakeresanim1
                hide lizakeresalap1
                hide lizagyomlalanim
                show lizagyomlalanim:
                    xzoom -1.0
                    zoom 0.6
                    xpos 0.4
                    ypos 0.2
                    pause 9.0
                    linear 1.0 alpha 0.0
                    pause 9.0
                    linear 1.0 alpha 1.0
                    repeat
                show lizakeresanim1:
                    zoom 0.65
                    xpos 0.45
                    ypos 0.46
                    alpha 0.0
                    pause 9.0
                    linear 1.0 alpha 1.0
                    pause 9.0
                    linear 1.0 alpha 0.0
                    repeat
                show lizakeresalap1:
                    zoom 0.65
                    xpos 0.45
                    ypos 0.46
                    alpha 0.0
                    pause 9.0
                    linear 1.0 alpha 1.0
                    pause 9.0
                    linear 1.0 alpha 0.0
                    repeat
                jump ugrik8reszliza

            show screen s8
            u ""
            $ szemeteszak += 1
            show screen s10
            u ""
            $ szemeteszak += 1
            show screen s2
            u ""
            $ szemeteszak += 1
            if szemeteszedtel == 8:
                jump lizaodaadjaaviragot
    hide screen invertori2
    show screen invertori
    show screen parkto
$ renpy. pause(hard=True)
label parktoszemet7:
    hide screen invertori
    show screen invertori2
    hide screen parkto
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parktoszemet7 -= 1
            show parktoszemet7 onlayer hatso3:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump lizaodaadjaaviragot
    hide screen invertori2
    show screen invertori
    show screen parkto
$ renpy. pause(hard=True)
label parktoszemet8:
    hide screen invertori
    show screen invertori2
    hide screen parkto
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            show screen parktoszemet8
            $ szemeteszedtel += 1
            $ parktoszemet8 -= 1
            show parktoszemet8 onlayer hatso3:
                alpha 1.0
                linear 5.0 alpha 0.0
            show screen s1
            u ""
            $ szemeteszak += 1
            show screen s2
            u ""
            $ szemeteszak += 1
            show screen s2
            $ szemeteszak += 1
            u ""
            if szemeteszedtel == 8:
                jump lizaodaadjaaviragot
    hide screen invertori2
    show screen invertori
    show screen parkto
$ renpy. pause(hard=True)
label lizaseggeparkban:
    hide screen parkto
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    show lizaseggeparktonal onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    u ""
    show lizaseggeparktonal onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen parkto
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
$ renpy. pause(hard=True)
label lizaodaadjaaviragot:
    hide screen parkto
    show pilango6reszanim onlayer hatso3:
        xpos 0.305
        ypos 0.64
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilango6reszanim2 onlayer hatso3:
        zoom 0.8
        xpos 0.34
        ypos 0.47
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilango6reszanim3 onlayer hatso3:
        zoom 1.1
        xzoom -1.0
        xpos 0.06
        ypos 0.39
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilango6reszanim4 onlayer hatso3:
        xpos 0.752
        ypos 0.445
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilango6reszanim5 onlayer hatso3:
        xzoom -1.0
        zoom 0.8
        xpos 0.9
        ypos 0.39
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilangoszal6reszanim6 onlayer hatso3:
        zoom 1.2
        xpos 0.34
        ypos 0.62
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilangoszal6reszanim onlayer hatso3:
        xpos 0.78
        ypos 0.6
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilangoszal6reszanim2 onlayer hatso3:
        zoom 0.9
        xzoom -1.0
        xpos 0.83
        ypos 0.52
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilangoszal6reszanim3 onlayer hatso3:
        zoom 0.5
        xpos 0.302
        ypos 0.392
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilangoszal6reszanim4 onlayer hatso3:
        zoom 0.4
        xzoom -1.0
        xpos 0.53
        ypos 0.42
        alpha 0.0
        linear 1.0 alpha 1.0
    show pilangoszal6reszanim5 onlayer hatso3:
        zoom 0.45
        xpos 0.43
        ypos 0.43
        alpha 0.0
        linear 1.0 alpha 1.0
    $ pillangokaparktoban = True
    show kitty onlayer kozep:
        zoom 0.95
        xpos 0.1
        ypos 0.15
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    k "The lake looks just wonderful! I am amazed!"
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    show parktokozeli onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer kozep:
        xpos 0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show kittykedvesazrc onlayer kozep2:
        alpha 0.0
        linear 1.0 alpha 1.0

    f "Well, yeah, I tried my best. I helped you clean the park, just like I told you earlier."
    k "Oh yeah! Thank you!"
    show fiupoz1pir onlayer kozep:
        xpos 0.1
        alpha 0.0
    show kittypuszitad onlayer kozep2:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show fiupoz1pir onlayer kozep:
        xpos 0.1
        alpha 1.0
    u ""
    show kittypuszitad onlayer kozep2:
        alpha 1.0
        linear 1.0 alpha 0.0
    f "You… You are welcome!"
    show lizamergespoz onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    l "What are you doing here? You fat pig!"
    show fiupoz1pir onlayer kozep:
        xpos 0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    hide kittykedvesazrc onlayer kozep2
    show kittymérgesazrc onlayer kozep2
    k "Excuse me! Who are you?"
    hide lizamergespoz onlayer kozep
    show lizakedvespoz onlayer kozep
    l "Fred will introduce me for sure…"
    f "Liza, she is Kitty, she is my classmate... Kitty, she is Liza, she is my ex neighbor, I helped her today..."
    k "Nice to meet you!"
    show lizamergespoz onlayer kozep
    hide lizakedvespoz onlayer kozep
    l "I wonder why you pretend to be nice, you little dirty fat pig! Are you looking for acorns?"
    show kittykedvesazrc onlayer kozep2
    hide kittymérgesazrc onlayer kozep2
    hide fiupoz1 onlayer kozep
    show fiupoz4 onlayer kozep:
        xpos 0.1
    f "Liza! Please stop talking like that!"
    hide fiupoz4 onlayer kozep
    show fiupoz2 onlayer kozep:
        xpos 0.1
    hide lizamergespoz onlayer kozep
    show lizakedvespoz onlayer kozep
    l "As you wish Fred Honey!"
    k "I would be happy if you would stop calling me a pig M’am..."
    show lizamergespoz onlayer kozep
    hide lizakedvespoz onlayer kozep
    hide kittykedvesazrc onlayer kozep2
    show kittymérgesazrc onlayer kozep2
    l "Why do you not scram jerk? You are not good enough to make Fred notice you. Scram Piggy!"
    hide fiupoz2 onlayer kozep
    show fiupoz5 onlayer kozep:
        xpos 0.1
    f "You are not nicer at all!"
    hide fiupoz5 onlayer kozep
    show fiupoz1 onlayer kozep:
        xpos 0.1
    f "We have been friends with Kitty since our childhood..."
    k "Let it be Fred... I wanted to leave anyway…"
    show kittymérgesazrc onlayer kozep2:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    hide kitty onlayer kozep
    hide lizamergespoz onlayer kozep
    show lizakedvespoz onlayer kozep
    l "Now I remember! I found the white flower for you Dear!"
    f "Fine. Now we miss only two ingredients…"
    l "I have to go back to my husband, he might miss me…"
    f "I will follow you as soon as I have the cream. Bye!"
    $ lizaviragnalad = 1
    $ holvanliza = "tornazik"
    $ debraholcsinal = "mosogat"
    $ svetlana = "boltnal"
    hide lizagyomlalanim
    hide lizakeresanim1
    hide lizakeresalap1
    show parktokozeli onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer kozep:
        xpos 0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show lizakedvespoz onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0










    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen parkto
$ renpy. pause(hard=True)
label macskaelszaladparktonal:
    hide screen parkto
    $ macskaholvan = "parknal"
    $ ritamacskajakajatpap = 1
    $ kutyatalatfelveheted = True
    hide macska-10
    show macskaszalad:
        zoom 0.34
        xzoom -1.0
        xpos 0.43
        ypos 0.47
        linear 0.125 xpos 0.42
        linear 0.1 xpos 0.41
        linear 0.084 xpos 0.40
        linear 6.0 xpos -0.2
    show screen s1
    u ""
    f "This won't work. I need to find a way to catch him."
    show screen parkto
$ renpy. pause(hard=True)
label annavalbeszelniatonal:
    hide screen parkto
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    show annaatonal1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    if annavalbeseltelparktonal == 2:
        f "Is everything ok?"
        an "Yeah! Everything is so nice and peaceful…"
    if annavalbeseltelparktonal == 1:
        if betadinnalad == 1:
            $ betadinnalad = 2
            f "Here I have the magic medicine..."
            show annaatonal2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show annaatonal2kampo onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            an "Ok, let us start it..."
            show screen horogannalababan
            $ renpy. pause(hard=True)
    if annavalbeseltelparktonal == 1:
        an "Bring me the magic potion. I won’t look at you until then!"
        f "Ok…"
    if annavalbeseltelparktonal == 0:
        $ annavalbeseltelparktonal = 1
        $ debraholcsinal = "kertbentanul"
        $ debrakertje2medencetisztaviz = 1
        $ debrakertje2salgcso = 1
        $ debrakertje2salgcsofoltok = 1
        $ boboholvan = "sehol"
        f "Anna?"
        an "Who are you? Are you Fred?"
        f "Yeah... Did J find you?"
        an "Yeah, I moved into his house and he had something to do so I came to the lake to pass time…"
        f "And… What are you doing now?"
        an "I am just sitting here and I am thinking of mermaids… You know... I went into the water and something bit me. I do not know, it feels like it is still in the wound…"
        f "What could it be?"
        f "Did you not check the wound?"
        an "It would be so depressing. Now I imagine I am a mermaid who was bitten by the terrible seamonster and I am waiting to die slowly..."
        an "And by the way, I can not look at blood. I am afraid of blood. I can not see it..."
        an "...Maybe you could save me..."
        f "... Let me see!"
        show annaatonal2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show annaatonal2kampo onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        f "I think you stepped on a hook..."
        an "I think it is a sea monster still..."
        f "Nope… It is a hook. wait a minute.I will bring you some kind of „magic disinfectant”... Do not move!"
        show annaatonal2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show annaatonal2kampo onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s2
        u ""
        an "Ok. I will sit here and wait for death…"
    show annaatonal1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen parkto
    show screen invertori
    show invertori onlayer elotte6:
        ypos 0.0
$ renpy. pause(hard=True)
label annavalbeszelniatonal2:
    hide screen parkto
    an "Live me alone! I am meditating."
    f "In this pose?"
    an "I always meditate in such a pose…"
    show screen parkto
$ renpy. pause(hard=True)
label kiszededahorgotannalababol:
    f "This will hurt a bit."
    show screen s1
    u ""
    show annaatonal2kampo onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show annaatonal2szem2 onlayer elotte
    show screen s1
    u ""
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    queue sound "audio/spricc.ogg"
    show annalabaverzikanim onlayer elotte:
        alpha 1.0
        pause 2.0
        alpha 0.0
    show annalabaverzikanim2 onlayer elotte:
        alpha 0.0
        pause 2.0
        alpha 1.0
    an "AUUUUUUUUUU!!!!!"
    hide annalabaverzikanim onlayer elotte
    an "Is this blood? Does my blood splatter?"
    f "Nope… I it is just dripping…"
    an "That is a lie! I lost my blood! I do not feel well!"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    stop sound
    queue sound "audio/reszeg.ogg"
    show screen s1
    u ""
    stop sound
    hide annalabaverzikanim2 onlayer elotte
    hide annaatonal2szem2 onlayer elotte
    hide annalabaverzikanim onlayer elotte
    hide annaatonal2kampo onlayer elotte
    hide annaatonal1 onlayer elotte
    hide pilango6reszanim onlayer hatso3
    hide pilango6reszanim2 onlayer hatso3
    hide pilango6reszanim3 onlayer hatso3
    hide pilango6reszanim4 onlayer hatso3
    hide pilango6reszanim5 onlayer hatso3
    hide pilangoszal6reszanim6 onlayer hatso3
    hide pilangoszal6reszanim onlayer hatso3
    hide pilangoszal6reszanim2 onlayer hatso3
    hide pilangoszal6reszanim3 onlayer hatso3
    hide pilangoszal6reszanim4 onlayer hatso3
    hide pilangoszal6reszanim5 onlayer hatso3
    hide parktohalak
    show annaatonalajultmegjelenik onlayer elotte
    queue sound "audio/paff.wav"
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    stop sound
    f "Anna! Are you ok?"
    f "It seems she fainted..."
    f "She is a strange girl for sure, but she has a nice sexy body..."
    f "Now she is unconscious... how about we ..."
    show fredperverz onlayer elotte:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    f "touch her a bit?"
    $ horognalad = 1
    hide annaatonalajultmegjelenik onlayer elotte
    show annaatonalajultalap onlayer elotte
    show annaatonalajultmelle onlayer elotte
    show annaatonalajultszemmoz onlayer elotte
    show annaatonalajultszaj2 onlayer elotte
    hide fredperverz onlayer elotte
    show fredperverz onlayer elotte:
        xzoom -1.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen annafogdosasipontjai1
    show screen annafogdosasipontjai2
    show screen annafogdosasipontjai3
    show screen annaebred
$ renpy. pause(hard=True)
label annafogdosasipontjai1:
    hide screen annafogdosasipontjai1
    hide screen annafogdosasipontjai2
    hide screen annafogdosasipontjai3
    if annatholfogdosod == 2:
        show annaatonalajultpinadorzianim onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
    if annatholfogdosod == 3:
        hide annaatonalajultcicitapianim onlayer elotte
        show annaatonalajultcicitapianim2 onlayer elotte
        show screen s1
        u ""
        hide annaatonalajultcicitapianim2 onlayer elotte
        show annaatonalajultmelle onlayer elotte
        show annaatonalajultcicitapimoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
    hide screen annafogdosasipontjai1
    show screen annafogdosasipontjai2
    show screen annafogdosasipontjai3
    $ annatholfogdosod = 1
    show annaatonalajultcsombfogdosasanim onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
label annafogdosasipontjai2:
    hide screen annafogdosasipontjai1
    hide screen annafogdosasipontjai2
    hide screen annafogdosasipontjai3
    if annatholfogdosod == 1:
        show annaatonalajultcsombfogdosasanim onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
    if annatholfogdosod == 3:
        hide annaatonalajultcicitapianim onlayer elotte
        show annaatonalajultcicitapianim2 onlayer elotte
        show screen s1
        u ""
        hide annaatonalajultcicitapianim2 onlayer elotte
        show annaatonalajultmelle onlayer elotte
        show annaatonalajultcicitapimoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""

    hide screen annafogdosasipontjai2
    show screen annafogdosasipontjai1
    show screen annafogdosasipontjai3
    $ annatholfogdosod = 2
    show annaatonalajultpinadorzianim onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
label annafogdosasipontjai3:
    hide screen annafogdosasipontjai1
    hide screen annafogdosasipontjai2
    hide screen annafogdosasipontjai3
    if annatholfogdosod == 2:
        show annaatonalajultpinadorzianim onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
    if annatholfogdosod == 1:
        show annaatonalajultcsombfogdosasanim onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
    hide screen annafogdosasipontjai3
    show screen annafogdosasipontjai2
    show screen annafogdosasipontjai1
    $ annatholfogdosod = 3
    show annaatonalajultcicitapimoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide annaatonalajultcicitapimoz1 onlayer elotte
    hide annaatonalajultmelle onlayer elotte
    show annaatonalajultcicitapianim onlayer elotte
$ renpy. pause(hard=True)
label annafelebred:
    hide screen annafogdosasipontjai1
    hide screen annafogdosasipontjai2
    hide screen annafogdosasipontjai3
    if annatholfogdosod == 1:
        show annaatonalajultcsombfogdosasanim onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
    if annatholfogdosod == 2:
        show annaatonalajultpinadorzianim onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
    if annatholfogdosod == 3:
        hide annaatonalajultcicitapianim onlayer elotte
        show annaatonalajultcicitapianim2 onlayer elotte
        show screen s1
        u ""
        hide annaatonalajultcicitapianim2 onlayer elotte
        show annaatonalajultmelle onlayer elotte
        show annaatonalajultcicitapimoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
    show screen s1
    u ""
    hide annaatonalajultszemmoz onlayer elotte
    show annaatonalajultszemkinyit onlayer elotte
    show screen s2
    u ""
    f "Are you alright Anna?"
    hide annaatonalajultszaj2 onlayer elotte
    show annaatonalajultszajanim onlayer elotte
    a "What happened to my leg and to the hook?"
    f "The bleeding stopped. I made the wound clear. I put the hook in my pocket. Do not worry!"
    f "You fainted and I took care of you until now..."
    a "Great… I had a terrible dream. I worked in an office and I had to do the same job every single day…"
    show annaatonalajultszaj2 onlayer elotte
    hide annaatonalajultszajanim onlayer elotte
    f "What is your problem with such a workplace?"
    hide annaatonalajultszaj2 onlayer elotte
    show annaatonalajultszajanim onlayer elotte
    a "It is like hell..."
    a "Well… who cares about this anymore... It was justa dream, but I felt really hot during my dream…"
    show annaatonalajultszaj2 onlayer elotte
    hide annaatonalajultszajanim onlayer elotte
    f "Ehm… I should go now… bye!"
    if faagnalad == 1:
        if gilisztanalad == 2:
            if horognalad == 1:
                if madzagveheto == 2:
                    $ faagnalad = 2
                    $ gilisztanalad = 3
                    $ horognalad = 2
                    $ madzagveheto = 4
    show parktohalak
    show pilango6reszanim onlayer hatso3:
        xpos 0.305
        ypos 0.64
    show pilango6reszanim2 onlayer hatso3:
        zoom 0.8
        xpos 0.34
        ypos 0.47
    show pilango6reszanim3 onlayer hatso3:
        zoom 1.1
        xzoom -1.0
        xpos 0.06
        ypos 0.39
    show pilango6reszanim4 onlayer hatso3:
        xpos 0.752
        ypos 0.445
    show pilango6reszanim5 onlayer hatso3:
        xzoom -1.0
        zoom 0.8
        xpos 0.9
        ypos 0.39
    show pilangoszal6reszanim6 onlayer hatso3:
        zoom 1.2
        xpos 0.34
        ypos 0.62
    show pilangoszal6reszanim onlayer hatso3:
        xpos 0.78
        ypos 0.6
    show pilangoszal6reszanim2 onlayer hatso3:
        zoom 0.9
        xzoom -1.0
        xpos 0.83
        ypos 0.52
    show pilangoszal6reszanim3 onlayer hatso3:
        zoom 0.5
        xpos 0.302
        ypos 0.392
    show pilangoszal6reszanim4 onlayer hatso3:
        zoom 0.4
        xzoom -1.0
        xpos 0.53
        ypos 0.42
    show pilangoszal6reszanim5 onlayer hatso3:
        zoom 0.45
        xpos 0.43
        ypos 0.43
    hide annaatonalajultszemkinyit onlayer elotte
    hide annaatonal2 onlayer elotte
    hide annaatonal1 onlayer elotte
    show annaatonalajultszem8 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show annaatonalajultalap onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show annaatonalajultmelle onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show annaatonalajultszaj2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    $ annavalbeseltelparktonal = 2
    show screen s2
    u ""
    show screen parkto
    show screen invertori
    show invertori onlayer elotte6:
        ypos 0.0
$ renpy. pause(hard=True)
label horgaszparktonal:
    hide screen parkto
    if faagnalad == 2:
        show screen horgaszas
        show fredhorgaszik onlayer hatso3:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s5
        u ""
        $ annaholvan = "parktoban"
        show annaatobanmoz1:
            xpos 0.75
            ypos 0.43
            alpha 0.0
            linear 1.0 alpha 1.0
        show annaatonalhaterben onlayer hatso3:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        hide annaatobanmoz1
        show annaatobananimseta:
            parallel:
                xpos 0.75
                linear 5.525 xpos 0.85
                pause 2.125
                linear 5.525 xpos 0.75
                pause 2.125
            parallel:
                ypos 0.43
                linear 5.525 ypos 0.44
                pause 2.125
                linear 5.525 ypos 0.43
                pause 2.125
            parallel:
                xzoom 1.0
                pause 7.75
                xzoom -1.0
                pause 7.75
                xzoom 1.0
            repeat
        show screen s4
        u ""
        show screen s10
        u ""
        $ halnalad = 1
        $ fogjhalat = 2
        $ holvanliza = "sertegetikittyaparkban"
        $ kittyholvan = "sertegetikittyaparkban"
        $ macskaholvan = "temeto"
        show fredhorgaszik onlayer hatso3:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen parkto
        $ renpy. pause(hard=True)

    f "I need a fishing rod to catch a fish."
    show screen parkto
$ renpy. pause(hard=True)
label fodovalbeszelniatonal:
    hide screen parkto
    if cottonnalad == 0:
        $ fodo10reszcotton = 1
        f "Hy Fodo Master! Can you lend me a condom?"
        fr "Nope, kid! I need it. I will have a date at night. It is hard to find a condom nowadays."
        f "Still… thank you!"
        if mama10reszcotton == 1:
            if fodo10reszcotton == 1:
                if eszter10reszcotton == 1:
                    $ zoliholvan = "othon"
    if cottonnalad >= 1:
        fr "Did you see Anika somewhere?"
        f "Nope."
    show screen parkto
$ renpy. pause(hard=True)
label parktorobeszel:
    hide screen parkto
    f "This is a lake with a lot of fishes in it."
    show screen parkto
$ renpy. pause(hard=True)
label parktoviragok:
    hide screen parkto
    f "Beautiful flowers."
    show screen parkto
$ renpy. pause(hard=True)
label parktopad:
    hide screen parkto
    f "Bench."
    show screen parkto
$ renpy. pause(hard=True)
label parktoutcailampa:
    hide screen parkto
    f "Streetlight."
    show screen parkto
$ renpy. pause(hard=True)
label parktofa:
    hide screen parkto
    f "Can you not see? A big tree…"
    show screen parkto
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
