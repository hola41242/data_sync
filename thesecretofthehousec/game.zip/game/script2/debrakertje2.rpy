label debrakertje2:
    if eremkiasva == 0:
        if fifiazutban == 2:
            if madzagveheto >= 2:
                if mamanyaklanczalogjegy == 1:
                    $ debrakertje2foldturas = 1
                    $ debrakertje2erme = 1
                    $ debrakertje2foldturasazermen = 1
                    $ eremkiasva = 1
    stop sound
    $ holvagyok = "debrakertje2"
    jump tiltasok
$ renpy. pause(hard=True)
label debrakertje2szov:
    show debrakertje2
    show debrakertje2soveny onlayer hatso
    show debrakertje2vetemenyes onlayer hatso3
    show debrakertje2sovenyelol onlayer kozep4
    if debrakertje2sokdudvafelszed1 == 1:
        show debrakertje2sokdudvafelszed1 onlayer kozep3
    if debrakertje2sokdudvafelszed2 == 1:
        show debrakertje2sokdudvafelszed2 onlayer kozep3
    if debrakertje2sokdudvafelszed3 == 1:
        show debrakertje2sokdudvafelszed3 onlayer kozep
    if debrakertje2sokdudvafelszed4 == 1:
        show debrakertje2sokdudvafelszed4 onlayer kozep
    if debrakertje2sokdudvafelszed5 == 1:
        show debrakertje2sokdudvafelszed5 onlayer kozep
    if debrakertje2sokdudvafelszed6 == 1:
        show debrakertje2sokdudvafelszed6 onlayer kozep
    if debrakertje2sokdudvafelszed7 == 1:
        show debrakertje2sokdudvafelszed7 onlayer kozep
    if debrakertje2sokdudvafelszed8 == 1:
        show debrakertje2sokdudvafelszed8 onlayer kozep
    if debrakertje2sokdudvafelszed9 == 1:
        show debrakertje2sokdudvafelszed9 onlayer kozep
    if debrakertje2sokdudvafelszed10 == 1:
        show debrakertje2sokdudvafelszed10 onlayer kozep
    if debrakertje2sokdudvafelszed11 == 1:
        show debrakertje2sokdudvafelszed11 onlayer kozep
    if debrakertje2sokdudvafelszed12 == 1:
        show debrakertje2sokdudvafelszed12 onlayer kozep
    if debrakertje2vetemenyesdudva == 1:
        show debrakertje2vetemenyesdudva onlayer hatso3
    if debrakertje2bokorgaz == 1:
        show debrakertje2bokorgaz onlayer hatso1
    if debrakertje2foldturas == 1:
        show debrakertje2foldturas onlayer hatso1
    if debrakertje2erme == 1:
        show debrakertje2erme onlayer hatso1
    if debrakertje2foldturasazermen == 1:
        show debrakertje2foldturasazermen onlayer hatso1
    if debrakertje2jomadzag == 1:
        show debrakertje2jomadzag onlayer hatso1
    if debrakertje2leerestocso == 1:
        show debrakertje2leerestocso onlayer hatso1
    if debrakertje2leerestocsohejen == 1:
        show debrakertje2leerestocsohejen onlayer hatso1
    show debrakertje2medencealap onlayer kozep
    if debrakertje2medencekoszosviz == 1:
        show debrakertje2medencekoszosviz onlayer kozep
        show debrakertje2medencekoszosvizanim onlayer kozep
    if debrakertje2medencetisztaviz == 1:
        show debrakertje2medencetisztaviz onlayer kozep
        show debrakertje2medencetisztavizanim onlayer kozep
    show debrakertje2medenceteto onlayer kozep2
    if debrakertje2medencekosz == 1:
        show debrakertje2medencekosz onlayer kozep2
    if debrakertje2roszmadzag == 1:
        show debrakertje2roszmadzag onlayer hatso1
    if debrakertje2ruhafent == 1:
        show debrakertje2ruhafent onlayer hatso1
    if debrakertje2ruhalent == 1:
        show debrakertje2ruhalent onlayer hatso1
    if debrakertje2salgcso == 1:
        show debrakertje2salgcso onlayer hatso1
    if debrakertje2salgcsofoltok == 1:
        show debrakertje2salgcsofoltok onlayer hatso1
    if sokfol8resz == 1:
        show debrakertje2asasutan onlayer hatso3
    if leengedocsoafoldon == 1:
        show debrakertje2leengedocso1 onlayer kozep
    if debraholcsinal == "debrafelengediamedencet":
        show debrafelengedanim onlayer kozep4

    if hanyadiknapvan == 7:
        if mamakert2benholvan == 1:
            show mami540nezelodikanim:
                zoom 0.2
                xpos 0.6
                ypos 0.47
        if mamakert2benholvan == 2:
            show mama540keresmozanim onlayer hatso1:
                xzoom -1.0
                zoom 0.3
                xpos 0.33
                ypos 0.54
        if mamakert2benholvan == 3:
            show mami540nezelodikanim:
                xzoom -1.0
                zoom 0.35
                xpos 0.00
                ypos 0.405
        if fifiazutban == 2:
            show fifiszagol onlayer kozep2:
                xzoom -1.0
                xpos 0.41
                ypos 0.79
                zoom 0.5
            show fifiszagolpislog onlayer kozep2:
                xzoom -1.0
                xpos 0.41
                ypos 0.79
                zoom 0.5
        if fifiazutban == 3:
            $ fifiholvanakertben = renpy.random.choice(['1', '2', '3' ])
            if fifiholvanakertben == "1":
                show fifiszagol2 onlayer kozep2:
                    zoom 0.4
                    xpos 0.84
                    ypos 0.67
                show fifiszagolpislog2 onlayer kozep2:
                    zoom 0.4
                    xpos 0.84
                    ypos 0.67
            if fifiholvanakertben == "2":
                show fifiszagol2 onlayer kozep2:
                    zoom 0.4
                    xpos 0.37
                    ypos 0.67
                show fifiszagolpislog2 onlayer kozep2:
                    zoom 0.4
                    xpos 0.37
                    ypos 0.67
            if fifiholvanakertben == "3":
                show fifipisil onlayer hatso:
                    xzoom -1.0
                    zoom 0.3
                    xpos 0.56
                    ypos 0.65
    if debraholcsinal == "debragyomlalkert2ben":
        $ debrakert2benholvan = 0
        $ debrakert2benholvan = renpy.random.choice(['1', '2' ])
        if debrakert2benholvan == "1":
            $ debrakert2pozbanvan = 1
            show screen debrakert2pozbanvan
            show debragyomlalanim onlayer hatso1:
                zoom 0.3
                xpos 0.65
                ypos 0.52
                alpha 0.0
                pause 23.0
                linear 1.0 alpha 1.0
                pause 23.0
                linear 1.0 alpha 0.0
                repeat
            show debragyomlalanim2 onlayer kozep2:
                zoom 0.8
                xpos 0.5
                ypos 0.64
                alpha 1.0
                pause 23.0
                linear 1.0 alpha 0.0
                pause 23.0
                linear 1.0 alpha 1.0
                repeat
        if debrakert2benholvan == "2":
            $ debrakert2pozbanvan = 2
            show screen debrakert2pozbanvan
            show debragyomlalanim onlayer hatso1:
                zoom 0.3
                xpos 0.65
                ypos 0.52
                alpha 1.0
                pause 23.0
                linear 1.0 alpha 0.0
                pause 23.0
                linear 1.0 alpha 1.0
                repeat
            show debragyomlalanim2 onlayer kozep2:
                zoom 0.8
                xpos 0.5
                ypos 0.64
                alpha 0.0
                pause 23.0
                linear 1.0 alpha 1.0
                pause 23.0
                linear 1.0 alpha 0.0
                repeat
    if debraholcsinal == "mamadebrabeszelkert2":
        if mamaholvan == "mamadebrabeszelkert2":
            show mamadebrabeszel onlayer hatso1:
                zoom 0.5
                xpos 0.4
                ypos 0.45
    if hanyadiknapvan == 8:
        if tulipannalad == 0:
            show tulipanazinvertoriban:
                xpos 0.48
                ypos 0.68


        if debraholcsinal == "debrakertje2":
            show debraall onlayer kozep:
                zoom 0.4
                xzoom -1.0
                xpos 0.6
                ypos 0.45
    if mamaholvan == "kert2ben":
        $ mamakert2benholvan = renpy.random.choice(['1', '2', '3' ])
        if mamakert2benholvan == '1':
            show screen mamakert2pozbanvan
            $ mamakert2pozbanvan = 1
            show mami540nezelodikanim2:
                zoom 0.2
                xpos 0.6
                ypos 0.47
                alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                pause 11.0
                linear 1.0 alpha 1.0
                repeat
            show mama540keresmozanim onlayer hatso1:
                xzoom -1.0
                zoom 0.3
                xpos 0.33
                ypos 0.54
                alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                pause 6.0
                repeat
            show mami540nezelodikanim:
                xzoom -1.0
                zoom 0.35
                xpos 0.00
                ypos 0.405
                alpha 0.0
                pause 11.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                repeat
        if mamakert2benholvan == '2':
            show screen mamakert2pozbanvan
            $ mamakert2pozbanvan = 2
            show mami540nezelodikanim2:
                zoom 0.2
                xpos 0.6
                ypos 0.47
                alpha 0.0
                pause 11.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                repeat
            show mama540keresmozanim onlayer hatso1:
                xzoom -1.0
                zoom 0.3
                xpos 0.33
                ypos 0.54
                alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                pause 11.0
                linear 1.0 alpha 1.0
                repeat
            show mami540nezelodikanim:
                xzoom -1.0
                zoom 0.35
                xpos 0.00
                ypos 0.405
                alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                pause 6.0
                repeat
        if mamakert2benholvan == '3':
            show screen mamakert2pozbanvan
            $ mamakert2pozbanvan = 3
            show mami540nezelodikanim2:
                zoom 0.2
                xpos 0.6
                ypos 0.47
                alpha 0.0
                pause 5.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                pause 6.0
                repeat
            show mama540keresmozanim onlayer hatso1:
                xzoom -1.0
                zoom 0.3
                xpos 0.33
                ypos 0.54
                alpha 0.0
                pause 11.0
                linear 1.0 alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                repeat
            show mami540nezelodikanim:
                xzoom -1.0
                zoom 0.35
                xpos 0.00
                ypos 0.405
                alpha 1.0
                pause 5.0
                linear 1.0 alpha 0.0
                pause 11.0
                linear 1.0 alpha 1.0
                repeat
    if mamaholvan == "napozikkert2ben":
        show debrakertje2mamanapozikanim onlayer kozep
    if hanyadiknapvan == 11:
        if letranalad == 0:
            show letra onlayer kozep:
                zoom 0.4
                xpos 0.65
                ypos 0.4
    if mamaholvan == "kertbenkenocsrevar":
        show mamalabal3r3540 onlayer kozep2:
            xzoom -1.0
            zoom 0.6
            xpos 0.45
            ypos 0.45

    jump engedejek

$ renpy. pause(hard=True)
label debrakertje2nincsutmeg:
    hide screen debrakertje2
    f "I have nothing to do there."
    show screen debrakertje2
$ renpy. pause(hard=True)
label debrakertje2ruhaszarito:
    hide screen debrakertje2
    if hanyadiknapvan == 7:
        if madzagveheto == 2:
            $ madzagveheto = 3
            $ debrakertje2jomadzag = 1
        if debrakertje2jomadzag == 1:
            show debrakertje2jomadzag onlayer hatso1
            hide debrakertje2roszmadzag onlayer hatso1
            $ debrakertje2roszmadzag = 0
        if ruhakosarnaladtele == True:
            if debrakertje2roszmadzag == 0:
                if ruhakosarnaladtelemijenruhaval == "vizes":
                    show screen ruhateregetes
                    if kiteritesiproba == 0:
                        $ mamakert2benholvan = 1
                        $ debrakertje2ruhalent = 1
                        $ debrakertje2jomadzag = 0
                        $ ruhakosarnaladtele = False
                        $ debrakertje2roszmadzag = 1
                        show mami540nezelodikanim2 onlayer elotte:
                            zoom 1.2
                            xpos -0.1
                            yalign 1.0
                            alpha 0.0
                            linear 1.0 alpha 1.0
                            pause 9.0
                            linear 1.0 alpha 0.0
                        show mami540nezelodikanim:
                            zoom 0.2
                            xpos 0.6
                            ypos 0.47
                            alpha 0.0
                            pause 10.0
                            linear 1.0 alpha 1.0
                        show debrakertje2ruhafent onlayer hatso1:
                            alpha 0.0
                            linear 20.0 alpha 1.0
                            pause 1.0
                            alpha 1.0
                            linear 1.0 alpha 0.0
                        show debrakertje2ruhalent onlayer hatso1:
                            alpha 0.0
                            pause 21.0
                            alpha 0.0
                            linear 1.0 alpha 1.0
                        show debrakertje2roszmadzag onlayer hatso1:
                            alpha 0.0
                            pause 21.0
                            alpha 0.0
                            linear 1.0 alpha 1.0
                        show debrakertje2jomadzag onlayer hatso1:
                            alpha 1.0
                            pause 21.0
                            alpha 1.0
                            linear 1.0 alpha 0.0
                        show screen s2
                        u ""
                        m "Where the fuck could I lose the damn necklace!"
                        $ renpy. pause(hard=True)
                    if kiteritesiproba == 3:
                        $ debrakertje2ruhafent = 1
                        $ mamakert2benholvan = 3
                        $ ruhakosarnaladtele = False
                        show mama540keresmozanim onlayer hatso1:
                            xzoom -1.0
                            zoom 0.3
                            xpos 0.33
                            ypos 0.54
                            alpha 1.0
                            linear 1.0 alpha 0.0
                        show mama540keresmozanim2 onlayer kozep:
                            zoom 0.4
                            xpos 0.74
                            ypos 0.54
                            alpha 0.0
                            linear 1.0 alpha 1.0
                            pause 9.0
                            linear 1.0 alpha 0.0
                        show mami540nezelodikanim:
                            xzoom -1.0
                            zoom 0.35
                            xpos 0.00
                            ypos 0.405
                            alpha 0.0
                            pause 10.0
                            linear 1.0 alpha 1.0
                        show debrakertje2ruhafent onlayer hatso1:
                            alpha 0.0
                            linear 20.0 alpha 1.0
                        show screen s2
                        u ""
                        m "I had sex with Mr. Thomas yesterday around this place. The necklace should lie here..."
                        $ renpy. pause(hard=True)
            if ruhakosarnaladtelemijenruhaval == "koszos":
                f "The clothes got all dirty."
        if debrakertje2roszmadzag == 1:
            f "I need a new drying rope. The old one weekend."
    if hanyadiknapvan == 9:
        if pecabotkell == True:
            if madzagveheto == 3:
                if ruhakosarnalad == False:
                    $ ruhakosaratfelveheted = True
                    f "I could use the clothesline as a fishline… I have to sample the clothes first."
                    show screen debrakertje2
                    $ renpy. pause(hard=True)
                if ruhakosarnalad == True:
                    $ debrakertje2ruhafent = 0
                    $ ruhaszaritoido = 10
                    $ ruhaszaritoelteltido = 0
                    show screen ruhateregetes
                    show debrakertje2ruhafent onlayer hatso1:
                        alpha 1.0
                        linear 10.0 alpha 0.0
                    show screen s10
                    u ""
                    $ ruhakosarnaladtele = True
                    $ madzagveheto = 2
                    $ debrakertje2jomadzag = 0
                    if faagnalad == 1:
                        if gilisztanalad == 2:
                            if horognalad == 1:
                                if madzagveheto == 2:
                                    $ faagnalad = 2
                                    $ gilisztanalad = 3
                                    $ horognalad = 2
                                    $ madzagveheto = 4
                    show debrakertje2jomadzag onlayer hatso1:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                    show screen s1
                    u ""

                    show screen debrakertje2
                    $ renpy. pause(hard=True)
    if kiteritesiproba == 4:
        if debrakertje2ruhafent == 1:
            f "A drying rack with washed clothes."
        else:
            f "An old style drying rack."
    else:
        f "An old style drying rack."
    show screen debrakertje2
$ renpy. pause(hard=True)
label debrakertje2medence:
    $ csinalszvalamit = "igen"
    hide screen debrakertje2
    if hanyadiknapvan == 9:
        if leengedonalad == 1:
            $ leengedonalad = 2
            $ csinalszvalamit = "medencetengedsz"
            $ debrakertje2medencekoszosviz = 0
            $ leengedocsoafoldon = 1
            show debrakertje2leerestocsohejen onlayer kozep4:
                alpha 0.0
                linear 1.0 alpha 1.0
                linear 19.0 alpha 0.0
            show screen medenceleengedodik
            show debrakertje2medencekoszosviz onlayer kozep:
                alpha 1.0
                linear 20.0 alpha 0.0
            show debrakertje2medencekoszosvizanim onlayer kozep:
                alpha 1.0
                linear 20.0 alpha 0.0
            show screen s10
            u ""
            show screen s10
            u ""
            show debrakertje2leengedocso1 onlayer kozep:
                alpha 0.0
                linear 1.0 alpha 1.0
            hide debrakertje2leerestocsohejen onlayer kozep4
            $ csinalszvalamit = "semit"
            if debrakertje2medencekoszosviz == 0:
                if debrakertje2salgcsofoltok == 1:
                    hide screen debrakertje2
                    hide screen debrakert2pozbanvan
                    hide screen mamakert2pozbanvan
                    hide debragyomlalanim onlayer hatso1
                    hide debragyomlalanim2 onlayer kozep2
                    hide mami540nezelodikanim2
                    hide mama540keresmozanim onlayer hatso1
                    hide mami540nezelodikanim
                    $ debraholcsinal = "mamadebrabeszelkert2"
                    $ mamaholvan = "mamadebrabeszelkert2"
                    if debrakert2pozbanvan == 2:
                        show debragyomlalanim onlayer hatso1:
                            zoom 0.3
                            xpos 0.65
                            ypos 0.52
                            alpha 1.0
                            linear 1.0 alpha 0.0
                    if debrakert2pozbanvan == 1:
                        show debragyomlalanim2 onlayer kozep2:
                            zoom 0.8
                            xpos 0.5
                            ypos 0.64
                            alpha 1.0
                            linear 1.0 alpha 0.0
                    if mamakert2pozbanvan == 1:
                        show mami540nezelodikanim2:
                            zoom 0.2
                            xpos 0.6
                            ypos 0.47
                            alpha 1.0
                            linear 1.0 alpha 0.0
                    if mamakert2pozbanvan == 2:
                        show mama540keresmozanim onlayer hatso1:
                            xzoom -1.0
                            zoom 0.3
                            xpos 0.33
                            ypos 0.54
                            alpha 1.0
                            linear 1.0 alpha 0.0
                    if mamakert2pozbanvan == 3:
                        show mami540nezelodikanim:
                            xzoom -1.0
                            zoom 0.35
                            xpos 0.00
                            ypos 0.405
                            alpha 1.0
                            linear 1.0 alpha 0.0
                    show mamadebrabeszel onlayer hatso1:
                        zoom 0.5
                        xpos 0.4
                        ypos 0.45
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    show screen s1
                    u ""
            $ csinalszvalamit = "semit"
            show screen debrakertje2
            $ renpy. pause(hard=True)
        if debrakertje2medencekoszosviz == 1:
            $ tiltjaaterkepet = False
            if csovekkelenek9resz == 0:
                $ csovekkelenek9resz = 1
            f "We should get rid of this dirty water. There is no drain valve…I should find a downpipe and a hose pipe first."
        if debrakertje2medencekosz == 1:
            if debrakertje2medencekoszosviz == 0:
                if debrakertje2medencetisztaviz == 0:
                    f "Empty dirty pool."
                    $ csinalszvalamit = "semit"
                    show screen debrakertje2
                    $ renpy. pause(hard=True)
        if debrakertje2medencekoszosviz == 0:
            if debrakertje2medencetisztaviz == 0:
                f "Empty pool."
        if debrakertje2medencetisztaviz == 1:
            f "A pool filled with water."
        show screen debrakertje2
        $ csinalszvalamit = "semit"
        $ renpy. pause(hard=True)
    f "An abandoned swimming pool."
    $ csinalszvalamit = "semit"
    show screen debrakertje2
$ renpy. pause(hard=True)
label debrakertje2vetemenyes:
    hide screen debrakertje2
    if hanyadiknapvan == 12:
        if asonallad == 1:
            if debrakertje2vetemenyesdudva == 1:
                show screen kertfelas
                show debrakertje2vetemenyesdudva onlayer hatso3:
                    alpha 1.0
                    linear 10.0 alpha 0.0
                show screen s5
                u ""
                show mamalabal3r3540 onlayer kozep2:
                    xzoom -1.0
                    zoom 0.6
                    xpos 0.45
                    ypos 0.45
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s5
                u ""
                $ viraghagymanallad = 1
                f "I found an onion. I hope it will become a beautiful flower."
                show debrakert2kozelei onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show mamapoz1r3 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show fiupoz1 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1
                u ""
                m "Oh tell me Freddy! Can you lend me a hand?"
                $ debrakertje2vetemenyesdudva = 0
                f "I have a lot to do now Grandma... but… what can I help you?"
                m "Can you please pull up the zipper? Grandma has a job now…"
                f "Sounds great. Can you pay your debt with the money you earn with this new job?"
                m "Grandma will lie down and spread her legs. Grandma will earn enough money unless the load of penises are too much or too big…"
                show fiupoz2 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show fiupoz1 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                f "Are you not ashamed of such work?"
                m "Oh, Freddy! You are so nice and chaste! A job is a job and has to be done. By the way, if you wish to sample some experiences…"
                m "I can show you the way I made Puffy happy last time..."
                show fiupoz2 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz8 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                f "Nope! No! I mean… I do not need such experiences."
                f "I will pull up your zipper and we are done."
                show fiupoz8 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz1 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                m "Oh Gosh! I forgot to bring the cream with me. You have to apply some cream on my back so you can pull up the zipper. It is stuck."
                f "Where is the cream?"
                m "I do not know. It is somewhere in the house.Search for it! I will be waiting for you here. I will be enjoying the sun."
                f "I will go now. I will come back soon."
                $ mamaholvan = "kertbenkenocsrevar"
                $ mamahatatbekellkeni12nap = 1
                show debrakert2kozelei onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show mamapoz1r3 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz1 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1
                u ""
                show screen debrakertje2
                $ renpy. pause(hard=True)
    if debrakertje2vetemenyesdudva == 0:
        f "Excavated kitchen garden."
    if debrakertje2vetemenyesdudva == 1:
        f "An abandoned kitchen-garden."
    show screen debrakertje2
$ renpy. pause(hard=True)
label debrakertje2kerticsap:
    hide screen debrakertje2
    if hanyadiknapvan == 9:
        if salgcsonalad == 1:
            $ salgcsonalad = 2
            $ debrakertje2salgcso = 1
            show debrakertje2salgcso onlayer hatso1:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
        if salgcsonalad == 2:
            if tapasznalad == 1:
                $ debrakertje2salgcsofoltok = 1
                $ tapasznalad = 2
                show debrakertje2salgcsofoltok onlayer hatso1:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1
                u ""
            if tapasznalad == 2:
                f "The hose pipe can be used now."
                if debrakertje2medencekoszosviz == 0:
                    if debrakertje2salgcsofoltok == 1:
                        hide screen debrakertje2
                        hide screen debrakert2pozbanvan
                        hide screen mamakert2pozbanvan
                        hide debragyomlalanim onlayer hatso1
                        hide debragyomlalanim2 onlayer kozep2
                        hide mami540nezelodikanim2
                        hide mama540keresmozanim onlayer hatso1
                        hide mami540nezelodikanim
                        $ debraholcsinal = "mamadebrabeszelkert2"
                        $ mamaholvan = "mamadebrabeszelkert2"
                        if debrakert2pozbanvan == 2:
                            show debragyomlalanim onlayer hatso1:
                                zoom 0.3
                                xpos 0.65
                                ypos 0.52
                                alpha 1.0
                                linear 1.0 alpha 0.0
                        if debrakert2pozbanvan == 1:
                            show debragyomlalanim2 onlayer kozep2:
                                zoom 0.8
                                xpos 0.5
                                ypos 0.64
                                alpha 1.0
                                linear 1.0 alpha 0.0
                        if mamakert2pozbanvan == 1:
                            show mami540nezelodikanim2:
                                zoom 0.2
                                xpos 0.6
                                ypos 0.47
                                alpha 1.0
                                linear 1.0 alpha 0.0
                        if mamakert2pozbanvan == 2:
                            show mama540keresmozanim onlayer hatso1:
                                xzoom -1.0
                                zoom 0.3
                                xpos 0.33
                                ypos 0.54
                                alpha 1.0
                                linear 1.0 alpha 0.0
                        if mamakert2pozbanvan == 3:
                            show mami540nezelodikanim:
                                xzoom -1.0
                                zoom 0.35
                                xpos 0.00
                                ypos 0.405
                                alpha 1.0
                                linear 1.0 alpha 0.0
                        show mamadebrabeszel onlayer hatso1:
                            zoom 0.5
                            xpos 0.4
                            ypos 0.45
                            alpha 0.0
                            linear 1.0 alpha 1.0
                        show screen s1
                        u ""
                show screen debrakertje2
                $ renpy. pause(hard=True)
            f "We can not use this hose pipe, it is full of holes."
            show screen debrakertje2
            $ renpy. pause(hard=True)

            show debrakertje2salgcsofoltok onlayer hatso1

    f "A working garden tap."
    show screen debrakertje2
$ renpy. pause(hard=True)
label ruhafentaraszriton:
    if kiteritesiproba == 1:
        $ ruhakosarnaladtelemijenruhaval = "koszos"
        $ madzagveheto = 1
        $ fifiazutban = 1
        $ ruhaszaritoido = 10
        $ ruhaszaritoelteltido = 0
        f "Oh fuck! The drying rope broke! I have to start all over! I must repair the drying rack."
    if kiteritesiproba == 4:
        f "This will do. The clothes will dry. I should tell Debra about this."
    if kiteritesiproba == 2:
        $ debraholcsinal = "furdobenbenyitolra7nap"
        $ ruhakosarnaladtele = True
        $ ruhaszaritoido = 20
        $ kiteritesiproba = 3
        $ debrakertje2ruhalent = 0
        $ ruhaszaritoelteltido = 0
        $ szenyesnalad = True
        $ mijenszenyesvannalad = "debrajeke"
        f "The clothes got all dirty."
    show screen debrakertje2
$ renpy. pause(hard=True)
label kert2benmamavalbeszed:
    $ csinalszvalamit = "mamavalbeszelsz"
    hide invertori onlayer elotte6
    hide screen invertori
    hide screen debrakertje2
    hide debrakert2kozelei onlayer elotte
    hide fiupoz1 onlayer elotte
    hide mamabikinibenpoz1 onlayer elotte
    show debrakert2kozelei onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamabikinibenpoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    m "Oh Freddy! I can not find my neckleak!"
    f "Do not worry! You will find it for sure!"
    m "Maybe you have the right, but I am worried."
    show debrakert2kozelei onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mamabikinibenpoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    $ csinalszvalamit = "semit"
    show screen debrakertje2
$ renpy. pause(hard=True)
label kert2benruhatfelszedni:
    hide screen debrakertje2
    show screen ruhateregetes
    $ mamakert2benholvan = 2
    show debrakertje2ruhalent onlayer hatso1:
        alpha 1.0
        linear 10.0 alpha 0.0
    show mama540keresmozanim onlayer hatso1:
        xzoom -1.0
        zoom 0.3
        xpos 0.33
        ypos 0.54
        alpha 0.0
        pause 5.0
        linear 1.0 alpha 1.0
    show mami540nezelodikanim2:
        zoom 0.25
        xpos 0.76
        ypos 0.45
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 4.0
        linear 1.0 alpha 0.0
    show mami540nezelodikanim:
        zoom 0.2
        xpos 0.6
        ypos 0.47
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    m "I can't find it anywhere!"
$ renpy. pause(hard=True)
label fifitleteszedhatsokertben:
    $ fifitfelvetem = False
    $ fifiazutban = 2
    show fifimorog onlayer kozep2:
        xzoom -1.0
        xpos 0.41
        ypos 0.79
        zoom 0.5
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 5.0
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifiszagol onlayer kozep2:
        xzoom -1.0
        xpos 0.41
        ypos 0.79
        zoom 0.5
        alpha 0.0
        pause 6.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show fifiszagolpislog onlayer kozep2:
        xzoom -1.0
        xpos 0.41
        ypos 0.79
        zoom 0.5
        alpha 0.0
        pause 6.0
        alpha 0.0
        linear 1.0 alpha 1.0
$ renpy. pause(hard=True)
label ermetfelveszed:
    $ fifiholvanakertben = renpy.random.choice(['1', '2', '3' ])
    $ fifiazutban = 3
    $ debrakertje2erme = 0
    $ debrakertje2foldturasazermen = 0
    $ svetlanaermeje = 1
    show fifiszagol onlayer kozep2:
        xzoom -1.0
        xpos 0.41
        ypos 0.79
        zoom 0.5
        alpha 1.0
        linear 1.0 alpha 0.0
    show fifiszagolpislog onlayer kozep2:
        xzoom -1.0
        xpos 0.41
        ypos 0.79
        zoom 0.5
        alpha 1.0
        linear 1.0 alpha 0.0

    if fifiholvanakertben == "1":
        show fifiszagol2 onlayer kozep2:
            zoom 0.4
            xpos 0.84
            ypos 0.67
            alpha 0.0
            linear 1.0 alpha 1.0
        show fifiszagolpislog2 onlayer kozep2:
            zoom 0.4
            xpos 0.84
            ypos 0.67
            alpha 0.0
            linear 1.0 alpha 1.0

    if fifiholvanakertben == "2":
        show fifiszagol2 onlayer kozep2:
            zoom 0.4
            xpos 0.37
            ypos 0.67
            alpha 0.0
            linear 1.0 alpha 1.0
        show fifiszagolpislog2 onlayer kozep2:
            zoom 0.4
            xpos 0.37
            ypos 0.67
            alpha 0.0
            linear 1.0 alpha 1.0

    if fifiholvanakertben == "3":
        show fifipisil onlayer hatso:
            xzoom -1.0
            zoom 0.3
            xpos 0.56
            ypos 0.65
            alpha 0.0
            linear 1.0 alpha 1.0
    show debrakertje2erme onlayer hatso1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrakertje2foldturasazermen onlayer hatso1:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label tulipanfel:
    show tulipanazinvertoriban:
        xpos 0.48
        ypos 0.68
        alpha 1.0
        linear 1.0 alpha 0.0
    $ targyazinvertoriban += 1
    $ tulipannalad = 1
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed1fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz.wav"
            show debrakertje2sokdudvafelszed1 onlayer kozep3:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed1 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed2fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz2.wav"
            show debrakertje2sokdudvafelszed2 onlayer kozep3:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed2 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed3fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz.wav"
            show debrakertje2sokdudvafelszed3 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed3 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed4fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz2.wav"
            show debrakertje2sokdudvafelszed4 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed4 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed5fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz.wav"
            show debrakertje2sokdudvafelszed5 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed5 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed6fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz.wav"
            show debrakertje2sokdudvafelszed6 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed6 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed7fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz2.wav"
            show debrakertje2sokdudvafelszed7 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed7 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed8fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz.wav"
            show debrakertje2sokdudvafelszed8 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed8 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed9fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz2.wav"
            show debrakertje2sokdudvafelszed9 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed9 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed10fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz.wav"
            show debrakertje2sokdudvafelszed10 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed10 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed11fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz.wav"
            show debrakertje2sokdudvafelszed11 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed11 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrakertje2sokdudvafelszed12fel:
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            $ kompostszemet = True
            play sound "audio/elvesz2.wav"
            show debrakertje2sokdudvafelszed12 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            $ debrakertje2sokdudvafelszed12 = 0
            $ debrakert2dudva -= 1
            $ szemeteszak += 1
            if debrakert2dudva == 0:
                if debrakertje2bokorgaz == 0:
                    jump debrajekegyutt8resz
$ renpy. pause(hard=True)
label debrautasit8reszkertben:
    hide screen debrakertje2
    $ debrautasit8reszkertben = True
    $ mamaholvan = "kert2ben"
    show debrakert2kozelei onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show debrapoz4 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    $ debraholcsinal = "napaliban3"
    pause 1.5
    f "What are you searching for in the garden?"
    hide debraall onlayer kozep
    d "I was thinking about how I should start clean up the garden…"
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0

    f "Ehm… I have a lot to do now… bye…"
    show fiupoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
        pause 1.0
        xpos -0.6
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
        pause 1.0
        linear 1.0 alpha 0.0
        pause 1.0
        xzoom 1.0
        xpos 0.0
        linear 1.0 alpha 1.0
    d "Stop! Come back here Jerk!"
    show debrapoz4 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Pick up the weeds and clean the bushes!"
    show fiupoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Alright… what are you doing until I clean the backyard?"
    show debrapoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "This is not your business. We are not on the same level, but I will tell you. I will go to watch TV I guess…"
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "Fucking cool!"
    show debrakert2kozelei onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show debrapoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz4 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen debrakertje2
$ renpy. pause(hard=True)
label debrakertje2bokorgazlevag:
    hide screen debrakertje2
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if metszoollonalad == 0:
        f "I need a secateurs."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            if metszoollonalad == 1:
                if szemeteszsaknalad == True:
                    $ debrakertje2bokorgaz = 0
                    $ debraholcsinal = "debragyomlalkert2ben"
                    show debragyomlalanim2 onlayer kozep2:
                        zoom 0.8
                        xpos 0.5
                        ypos 0.64
                        alpha 0.0
                        linear 1.0 alpha 1.0
                    show screen s1
                    u ""
                    show debragyomlalanim onlayer hatso1:
                        zoom 0.3
                        xpos 0.65
                        ypos 0.52
                        alpha 0.0
                        pause 23.0
                        linear 1.0 alpha 1.0
                        pause 23.0
                        linear 1.0 alpha 0.0
                        repeat
                    show debragyomlalanim2 onlayer kozep2:
                        zoom 0.8
                        xpos 0.5
                        ypos 0.64
                        alpha 1.0
                        pause 23.0
                        linear 1.0 alpha 0.0
                        pause 23.0
                        linear 1.0 alpha 1.0
                        repeat
                    queue sound "audio/bokornyiras.ogg"
                    queue sound "audio/bokornyiras.ogg"
                    queue sound "audio/bokornyiras.ogg"
                    queue sound "audio/bokornyiras.ogg"
                    queue sound "audio/bokornyiras.ogg"
                    queue sound "audio/bokornyiras.ogg"
                    show debrakertje2bokorgaz onlayer hatso1:
                        alpha 1.0
                        linear 20.0 alpha 0.0
                    $ kompostszemet = True
                    show screen bokornyiras8resz
                    show screen s5
                    u ""
                    $ szemeteszak += 1
                    show screen s5
                    u ""
                    $ szemeteszak += 1
                    show screen s5
                    u ""
                    $ szemeteszak += 1
                    show screen s5
                    u ""

                if debrakert2dudva == 0:
                    if debrakertje2bokorgaz == 0:
                        jump debrajekegyutt8resz


    show screen debrakertje2
$ renpy. pause(hard=True)
label debrajekegyutt8resz:
    hide screen debrakertje2
    hide screen debrakert2pozbanvan
    hide screen mamakert2pozbanvan
    hide debragyomlalanim onlayer hatso1
    hide debragyomlalanim2 onlayer kozep2
    hide mami540nezelodikanim2
    hide mama540keresmozanim onlayer hatso1
    hide mami540nezelodikanim
    $ debraholcsinal = "mamadebrabeszelkert2"
    $ mamaholvan = "mamadebrabeszelkert2"
    if debrakert2pozbanvan == 2:
        show debragyomlalanim onlayer hatso1:
            zoom 0.3
            xpos 0.65
            ypos 0.52
            alpha 1.0
            linear 1.0 alpha 0.0
    if debrakert2pozbanvan == 1:
        show debragyomlalanim2 onlayer kozep2:
            zoom 0.8
            xpos 0.5
            ypos 0.64
            alpha 1.0
            linear 1.0 alpha 0.0
    if mamakert2pozbanvan == 1:
        show mami540nezelodikanim2:
            zoom 0.2
            xpos 0.6
            ypos 0.47
            alpha 1.0
            linear 1.0 alpha 0.0
    if mamakert2pozbanvan == 2:
        show mama540keresmozanim onlayer hatso1:
            xzoom -1.0
            zoom 0.3
            xpos 0.33
            ypos 0.54
            alpha 1.0
            linear 1.0 alpha 0.0
    if mamakert2pozbanvan == 3:
        show mami540nezelodikanim:
            xzoom -1.0
            zoom 0.35
            xpos 0.00
            ypos 0.405
            alpha 1.0
            linear 1.0 alpha 0.0
    show mamadebrabeszel onlayer hatso1:
        zoom 0.5
        xpos 0.4
        ypos 0.45
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen debrakertje2
$ renpy. pause(hard=True)
label mamadebrabeszel8resz:
    hide screen debrakertje2
    hide screen invertori
    hide invertori onlayer elotte6
    show 1dm onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz1ferd onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz1mama onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz1debra onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "What are you doing here?"
    m "We play chess just by thinking…"
    show harmasbeszedpoz1ferdszem2 onlayer elotte
    f "What?"
    d "We chat… Did you finish the housework?"
    f "Yeah, I did. I wanted to tell you about this and I have to tell you something… more…"
    show 2dm onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz2mama onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz2debra onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "What do you want?"
    hide harmasbeszedpoz1ferdszem2 onlayer elotte
    mg "I hope the cash collectors did not come too early. I have a week to pay… or... Do I remember wrong?"
    dg "Does he want to tell Grandma about the blowjob and about the rub from yesterday?"
    f "found an old coin yesterday in the garden…"
    d "And? What is the problem? Did you throw it in the trash?"
    show 3dm onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz3ferd onlayer elotte1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz2mama onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3mama1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz2debra onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3debra1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    m "How old was that coin anyway? Because Grandma needs every single Forint now…"
    f "No it was a really old dirty coin… It looked like old trash…"
    m "Thank God. It was not worth much then."
    f "Well… You are a bit… wrong… I exchanged it for something useful yesterday..."
    d "Did you make a good deal?"
    f "Not really… The coin was really expensive it seems…"
    d "How much was it worth? 1.000 Forints? Did you exchange for a lollipop again?"
    m "I am not interested in small changes at all. Grandma needs a lot of money."
    m "I owe some guys 100.000 Forints."
    show harmasbeszedpoz3debra1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3debra2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Why do you not solve the problem with a fuck, like you always did?"
    m "Are you crazy? I would have solved my problem a long time ago if I had had such an option."
    show harmasbeszedpoz3mama1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3mama2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "What is the problem? Do man not want to fuck you because you are to old?"
    m "I know someone who gets no sex.. She is even younger… Do you know this person, Debra?..."
    show harmasbeszedpoz3debra2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3debra1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Shut up old whore! Let Us not discuss my personal life here, before Fred! You make him feel bad!"
    m "Who cares? He is not your son! I think he is sexually mature, just like my dear Puffy.."
    f "I am 21 years old… Please let me explain! Let me talk about the damn coin!"
    d "Who cares…"
    show harmasbeszedpoz3mama2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3mama1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    f "It was really expensive!"
    m "How much?"
    d "Yeah, how much was it worth? I'm starting to get interested in the price... Just tell us!"
    f "100…"
    m "100.000 Forints? Do not tell me! This is terrible! Grandma could be rescued with that money!"
    show harmasbeszedpoz3debra1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3debra2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Not even God could rescue you Grandma!"
    show harmasbeszedpoz3mama1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3mama2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    m "Hahhha! Really funny!"

    show harmasbeszedpoz3debra2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3debra1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz3mama2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3mama1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz3ferdcsepp onlayer elotte1:
        xpos -0.03
        alpha 0.0
        linear 1.0 alpha 1.0
    f "….100.000.000 Forints…."
    d "What the fuck???"
    m "Are you serious???"
    f "Yeah, she earned 100.000.000 Forints with the old coin…"
    m "Ehm… Did you find the coin in this garden?"
    f "Yeah, Fifi found it…"
    m "Grandma has something to do now. She has no time for a chit-chat here…I have to count the worms…."
    d "Well… I remember I planted some Tulips in the garden… I have to find the tulip onions…"
    show harmasbeszedpoz3debra1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3debra2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz3mama1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3mama2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz3ferdcsepp onlayer elotte1:
        ypos 0.0
        linear 4.0 ypos 0.05
    m "I never knew you were interested in nature so much..."
    d "You never did any earthworks and now for a sudden you get interested in the worms…"
    show harmasbeszedpoz3debra2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3debra3 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz3mama2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz3mama3 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    d "Stipstop! I need the spade!"
    m "I will search with my bare hands! My nails are strong enough! Fifi! Come honey! Help Grandma a bit! Dig Fifi! Dig!"
    show fekete onlayer elotte6:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    show text "{b}{size=+10}Some hours later." onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s2
    u ""
    show debraesmamaasasutan onlayer elotte2
    show screen s2
    u ""
    hide text onlayer screens
    show fekete onlayer elotte6:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide fekete onlayer elotte6
    $ debraholcsinal = "furdo"
    $ mamaholvan = "szobajaban"
    f "Did you find something?"
    d "No… Ask the coin back!"
    m "Grandma needs her soft bed… She will not take any shower..."
    f "No, I can not prove the exchange… I should rest, too..."
    d "Oh fuck! Nononono!!! You have to rake the ground now. You owe us a lot now!"
    show debrakertje2debraesmamahaterbenkososak onlayer hatso3
    show debrakertje2asasutan onlayer hatso3
    $ sokfol8resz = 1
    show screen s1
    u ""
    hide 1dm onlayer elotte
    hide harmasbeszedpoz1ferd onlayer elotte
    hide harmasbeszedpoz1mama onlayer elotte
    hide harmasbeszedpoz1debra onlayer elotte
    hide 2dm onlayer elotte
    hide harmasbeszedpoz3ferd onlayer elotte1
    hide harmasbeszedpoz2mama onlayer elotte
    hide harmasbeszedpoz2debra onlayer elotte
    hide 3dm onlayer elotte
    hide harmasbeszedpoz3mama1 onlayer elotte
    hide harmasbeszedpoz3debra1 onlayer elotte
    hide harmasbeszedpoz3mama2 onlayer elotte
    hide harmasbeszedpoz3debra2 onlayer elotte
    hide harmasbeszedpoz3mama3 onlayer elotte
    hide harmasbeszedpoz3debra3 onlayer elotte
    hide harmasbeszedpoz3ferdcsepp onlayer elotte1
    hide mamadebrabeszel onlayer hatso1
    show debraesmamaasasutan onlayer elotte2:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show debrakertje2debraesmamahaterbenkososak onlayer hatso3:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori
    show screen debrakertje2
$ renpy. pause(hard=True)
label foldeltuntetese:
    hide screen debrakertje2
    $ debrakertje2foldturas = 0
    show debrakertje2foldturas onlayer hatso1:
        alpha 1.0
        linear 20.0 alpha 0.0
    $ sokfol8resz = 0
    show debrakertje2asasutan onlayer hatso3:
        alpha 1.0
        linear 20.0 alpha 0.0
    show screen foldeltuntetese
    show screen s10
    u ""
    show screen s10
    u ""
    $ vegea8resznek = True
    show screen debrakertje2
$ renpy. pause(hard=True)
label kert2bendebravalbeszed:
    hide screen debrakertje2
    hide screen invertori2
    hide screen invertori
    hide invertori onlayer elotte6
    $ csinalszvalamit = "debravalbeszelsz"
    show debraolvaskertben2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    if salgcsonalad >= 1:
        if leengedonalad >= 1:
            if tapasznalad >= 1:
                d "Take care of the pool! Do not disturb me now!"
                f "I have everything needed."
                d "Clean the pool Idiot! Leave me alone!"
                show debraolvaskertben2 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1
                u ""
                show screen invertori
                show invertori onlayer elotte6:
                    yalign 0.0
                $ csinalszvalamit = "semit"
                show screen debrakertje2
                $ renpy. pause(hard=True)
    d "Take care of the pool bastard!"
    f "Ok… Ok, but I have no tools…"
    d "Search for the tools! I have no money to buy any. You ruined our life, you know. You gave that coin… You owe us a lot!"
    show debraolvaskertben2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    $ csinalszvalamit = "semit"
    show screen debrakertje2
$ renpy. pause(hard=True)
label mamadebrabeszel9resz:
    hide screen debrakertje2
    hide screen invertori
    hide invertori onlayer elotte6
    show 1dm onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz1ferd onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz1mama onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz1debra onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show harmasbeszedpoz1ferdszem2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    if debravalesmamavalbeszeltel9resz == True:
        d "Do you have the tools I asked for?"
        if tisztitoszernalad == 1:
            if szivacsnalad == 1:
                $ szivacsestisztitodebranal = True
                $ sanyiholvan = "sehol"
                $ bandiholvan = "sehol"
                f "Yeah."
                jump medencetakaritosjelenet
        f "Nope…"
        d "Move on! Hurry and bring us the tools before Grandma's mustache grows big."
        m "But Debra! I removed my mustache only yesterday!"
    if debravalesmamavalbeszeltel9resz == False:
        f "There is no dirty water in the pool anymore and I found a hose pipe."
        hide harmasbeszedpoz1ferdszem2 onlayer elotte
        m "Why have you done this to Grandmother Freddy?"
        show 3dm onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show harmasbeszedpoz3ferd onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show harmasbeszedpoz3mama2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show harmasbeszedpoz3debra2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        d "Because we have to clean the pool."
        show harmasbeszedpoz3mama2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show harmasbeszedpoz3mama1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        m "Why have you done this to me Freddy? You sold my coin…"
        show harmasbeszedpoz3debra2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show harmasbeszedpoz3debra1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Debra asked me for this and…"
        show harmasbeszedpoz3ferd onlayer elotte2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show harmasbeszedpoz3ferd2 onlayer elotte2:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        d "Alright! Shut up and bring me the sponge from the bathroom and bring me some kind of detergent from the kitchen!"
        show harmasbeszedpoz3mama1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show harmasbeszedpoz3mama2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show harmasbeszedpoz3debra1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show harmasbeszedpoz3debra2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        m "Does Grandma need to clean the pool, too?"
        d "Of course!"
        show harmasbeszedpoz3ferd onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show harmasbeszedpoz3ferd2 onlayer elotte2:
            xzoom -1.0
            alpha 1.0
            linear 1.0 alpha 0.0
        m "I am just an old poor lady. What if my legs start to hurst? What if my Reuma comes back?"
        d "Do you want to enjoy the water or not?"
        show 2dm onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show harmasbeszedpoz2mama onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show harmasbeszedpoz2debra onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        m "You are a dirty bitch Debra. You are not afraid to blackmail a weak old lady..."
        hide 3dm onlayer elotte
        hide harmasbeszedpoz3ferd onlayer elotte2
        hide harmasbeszedpoz3ferd2 onlayer elotte2
        hide harmasbeszedpoz3debra1 onlayer elotte
        hide harmasbeszedpoz3debra2 onlayer elotte
        d "Who the hell cares?"
        hide harmasbeszedpoz3mama2 onlayer elotte
        hide 2dm onlayer elotte2
        hide harmasbeszedpoz2mama onlayer elotte2
        hide harmasbeszedpoz2debra onlayer elotte2
        show harmasbeszedpoz1ferdszem2 onlayer elotte
        hide 2dm onlayer elotte
        hide harmasbeszedpoz2mama onlayer elotte
        hide harmasbeszedpoz2debra onlayer elotte
        show 2dm onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show harmasbeszedpoz2mama onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show harmasbeszedpoz2debra onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        hide 2dm onlayer elotte
        hide harmasbeszedpoz2mama onlayer elotte
        hide harmasbeszedpoz2debra onlayer elotte
        d "Now Fred! Do not just stand there! Move! Bring me the sponge and the detergent!The sponge is in the bathroom under the sink and you can find the detergent in the kitchen next to the rubbish bags."
        $ debraszivacsotestisztitoszertker9resz = True
        $ debravalesmamavalbeszeltel9resz = True
    show 1dm onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz1ferd onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz1mama onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz1debra onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show harmasbeszedpoz1ferdszem2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen debrakertje2
    show screen invertori
    show invertori onlayer elotte6:
        ypos 0.0
$ renpy. pause(hard=True)
label medencetakaritosjelenet:
    show medemcetakarit1megjeleno onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    show medemcetakarit1hater onlayer elotte
    show medemcetakarit1debraanim onlayer elotte
    show medemcetakarit1mamaanim onlayer elotte
    show medemcetakarit1ferd onlayer elotte
    show screen s3
    u ""
    m "Do you like what you see?"
    hide medemcetakarit1megjeleno onlayer elotte
    m "You do not have to be ashamed of anything. It is natural that your hormones work and you watch sexy curves…"
    u ""
    show medemcetakarit2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    dg "This old whore goes on my nerves… She is teasing Fred…"
    dg "She is shaking her old fat ass in a tong…"
    dg "She flirts with every single man she meets… I should stop this…"
    show medemcetakarit3 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show medemcetakarit3cseppek onlayer elotte:
        alpha 0.0
        pause 2.0
        linear 1.0 alpha 1.0
        ypos 0.0
        linear 2.0 ypos 0.03
    show screen s1
    u ""
    m "Oh FUCK! Shit! It is cold!"
    d "You should cool down Grandmother…"
    $ debrakertje2medencekosz = 0
    hide medemcetakarit1hater onlayer elotte
    hide medemcetakarit1debraanim onlayer elotte
    hide medemcetakarit1mamaanim onlayer elotte
    hide medemcetakarit1ferd onlayer elotte
    hide medemcetakarit2 onlayer elotte
    hide debrakertje2medencekosz onlayer kozep2
    hide 1dm onlayer elotte
    hide harmasbeszedpoz1ferd onlayer elotte
    hide harmasbeszedpoz1mama onlayer elotte
    hide harmasbeszedpoz1debra onlayer elotte
    hide harmasbeszedpoz1ferdszem2 onlayer elotte
    $ debraholcsinal = "debrafelengediamedencet"
    $ mamaholvan = "napozikkert2ben"
    $ tisztitoszernalad = 2
    $ szivacsnalad = 2
    hide mamadebrabeszel onlayer hatso1
    show debrakertje2mamanapozikanim onlayer kozep
    show debrafelengedanim onlayer kozep4
    $ debrakertje2salgcso = 0
    hide debrakertje2salgcso onlayer hatso1
    $ debrakertje2salgcsofoltok = 0
    hide debrakertje2salgcsofoltok onlayer hatso1
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show text "{b}{size=+10}10 minutes later." onlayer screens:
        xpos 0.5
        xalign 0.5
        yalign 0.475
    show screen s2
    u ""
    hide medemcetakarit3 onlayer elotte
    hide medemcetakarit3cseppek onlayer elotte
    hide text onlayer screens
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen debrakertje2
    show screen invertori
    show invertori onlayer elotte6:
        ypos 0.0
$ renpy. pause(hard=True)
label debravalbeszed9reszfelenged:
    hide screen debrakertje2
    hide screen invertori
    hide invertori onlayer elotte6
    hide debrafelengedpinup onlayer elotte
    show debrafelengedpinup onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    if vetelkiamacskanakkajatahutobol == 1:
        if tejnalad == 0:
            if macskanakkinaltadakutyakajat == True:
                $ parkpadoshatertej = 1
                f "Do we have milk?"
                d "No, We ran out of milk. I ate cornflakes for breakfast and I needed milk. "
                f "Can you give me some money?"
                d "I have no money. I will receive my payments tomorrow. Come back tomorrow and let us see if I give you any money... Idiot..."
                f "Ok…"
                show debrafelengedpinup onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s1
                u ""
                show screen invertori
                show invertori onlayer elotte6:
                    ypos 0.0
                show screen debrakertje2
                $ renpy. pause(hard=True)
    f "What are you doing Debra?"
    d "The hose pipe seems to be too short.I have to hold it until the pool is filled with water."
    f "Why did you not pull the pool closer to the water supply?"
    d "Shut up and scream before I kick your ass!"
    show debrafelengedpinup onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        ypos 0.0
    show screen debrakertje2
$ renpy. pause(hard=True)
label mamavalbeszed9reszbeken:
    hide screen debrakertje2
    hide screen invertori
    hide invertori onlayer elotte6
    show mamanapozik9reszpinap onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mamanapozik9reszpinapszaj1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    hide mamanapozik9reszpinapszaj1 onlayer elotte
    show mamanapozik9reszpinapszajanim onlayer elotte
    if mamatbekented9resz == False:
        m "Oh Fredd! Please come and apply the cream of Grandma's ass. Grandma got tired from cleaning the pool."
        show mamanapozik9reszpinapszaj1 onlayer elotte
        hide mamanapozik9reszpinapszajanim onlayer elotte
        f "I am a bit emberassed... Should I rub the cream on your ass?"
        hide mamanapozik9reszpinapszaj1 onlayer elotte
        show mamanapozik9reszpinapszajanim onlayer elotte
        m "Yeah! Hurry! You owe me a lot and this cream is fantastic! Now! Get started!"
        show mamanapozik9reszpinapszaj1 onlayer elotte
        hide mamanapozik9reszpinapszajanim onlayer elotte
        f "But I do not want to touch your ass!"
        hide mamanapozik9reszpinapszaj1 onlayer elotte
        show mamanapozik9reszpinapszajanim onlayer elotte
        m "Freddy… You ruined my financial life, I hope you remember this. You owe me a lot..."
        show mamanapozik9reszpinapszaj1 onlayer elotte
        hide mamanapozik9reszpinapszajanim onlayer elotte
        f "But I did not… I did not know about the price and…"
        hide mamanapozik9reszpinapszaj1 onlayer elotte
        show mamanapozik9reszpinapszajanim onlayer elotte
        m "Start to rub on Grandmother's ass. Do not make me stand up and push your face in the fresh dogshit…"
        show mamanapozik9reszpinapszaj1 onlayer elotte
        hide mamanapozik9reszpinapszajanim onlayer elotte
        f "Alright! I will help you!"
        hide mamanapozik9reszpinapszaj1 onlayer elotte
        show mamanapozik9reszpinapszajanim onlayer elotte
        m "Good boy!"
        show mamanapozik9reszpinapszaj1 onlayer elotte
        hide mamanapozik9reszpinapszajanim onlayer elotte
        $ beszeljpuffyval9resz = 1
        fg "What an old heg! I owe her and I have to touch her disgusting old ass now... UGh! Uggly!"
    if hanyadiknapvan == 11:
        show mamanapozik9reszpinapszaj1 onlayer elotte
        hide mamanapozik9reszpinapszajanim onlayer elotte
        f "Good morning Grandma. Did you see Debra somewhere? "
        hide mamanapozik9reszpinapszaj1 onlayer elotte
        show mamanapozik9reszpinapszajanim onlayer elotte
        m "Debra went to an important business appointment early in the morning."
        m "She will be back in the afternoon. She doesn't go very often… Why are you looking after Debra?"
        show mamanapozik9reszpinapszaj1 onlayer elotte
        hide mamanapozik9reszpinapszajanim onlayer elotte
        f "I am not looking after her. I just… did not know where she could be…"
        hide mamanapozik9reszpinapszaj1 onlayer elotte
        show mamanapozik9reszpinapszajanim onlayer elotte
        m "Why are you thinking of Debra. I am here for you!"
        show mamanapozik9reszpinapszaj1 onlayer elotte
        hide mamanapozik9reszpinapszajanim onlayer elotte
        f "I… I have to go to the university…"
        jump ugrikmamanal11nap
    if mamatbekented9resz == True:
        m "I do not need anything right now. You can leave!"
label ugrikmamanal11nap:
    show mamanapozik9reszpinapszaj1 onlayer elotte
    hide mamanapozik9reszpinapszajanim onlayer elotte
    if mamatbekented9resz == False:
        show screen mamakermje9resz
        $ renpy. pause(hard=True)
    show mamanapozik9reszpinap onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mamanapozik9reszpinapszaj1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen debrakertje2
    show screen invertori
    show invertori onlayer elotte6:
        ypos 0.0
$ renpy. pause(hard=True)
label mama9reszbeken:
    $ mamatbekented9resz = True
    show fredundor onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show mamanapozik9reszmegjelenik onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide mamanapozik9reszmegjelenik onlayer elotte
    show mamanapozik9reszmozalap onlayer elotte
    show mamanapozik9reszseganim onlayer elotte
    show mamanapozik9reszfejmoz1 onlayer elotte2
    show screen s3
    u ""
    show mamanapozik9reszfejszajanim onlayer elotte2
    m "Oh yeah! I like this! Rub my ass Freddy! I have something to read…"
    hide mamanapozik9reszfejszajanim onlayer elotte2
    hide mamanapozik9reszfejmoz1 onlayer elotte2
    show mamanapozik9reszfejanim1 onlayer elotte2
    show screen s5
    u ""
    u ""
    hide mamanapozik9reszseganim onlayer elotte
    show mamanapozik9reszseganimferdbeszel onlayer elotte
    show screen s1
    u ""
    f "I applied enough cream on your body I guess…"
    hide mamanapozik9reszfejanim1 onlayer elotte2
    show mamanapozik9reszfejanim2 onlayer elotte2
    show screen s1
    u ""
    show mamanapozik9reszfejszajanim onlayer elotte2
    m "Rub my ass! Rub it more! Rub it until I can not feel my breech. Make my cellulite disappear!"
    hide mamanapozik9reszfejszajanim onlayer elotte2
    show mamanapozik9reszseganim onlayer elotte
    hide mamanapozik9reszseganimferdbeszel onlayer elotte
    show mamanapozik9reszfejanim1 onlayer elotte2
    hide mamanapozik9reszfejanim2 onlayer elotte2
    show screen s5
    u ""
    u ""
    hide mamanapozik9reszseganim onlayer elotte
    show mamanapozik9reszseganimferdbeszel onlayer elotte
    show screen s1
    u ""
    f "My army got tired, I can not do this anymore…"
    hide mamanapozik9reszfejanim1 onlayer elotte2
    show mamanapozik9reszfejanim2 onlayer elotte2
    show screen s1
    u ""
    show mamanapozik9reszfejszajanim onlayer elotte2
    m "Well, alright! We are done now. I can't feel my ass, you made a good job Freddy!"
    $ puffyholvan = "boltnal"
    $ svetlana = "boltnal"
    hide mamanapozik9reszfejszajanim onlayer elotte2
    hide mamanapozik9reszfejanim2 onlayer elotte2
    hide mamanapozik9reszseganimferdbeszel onlayer elotte
    hide mamanapozik9reszpinap onlayer elotte
    hide mamanapozik9reszpinapszaj1 onlayer elotte
    hide fredundor onlayer elotte
    hide mamanapozik9reszmozalap onlayer elotte
    hide mamanapozik9reszsegmoz1 onlayer elotte
    hide mamanapozik9reszsegmoz1 onlayer elotte2
    show mamanapozik9reszmegjelenik onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show screen debrakertje2
    show screen invertori
    show invertori onlayer elotte6:
        ypos 0.0
$ renpy. pause(hard=True)
label letratfelvenni:
    hide screen debrakertje2
    if debra11napfeladatotad == 0:
        f "A ladder. Why is this ladder in the garden? The fuck knows! I do not care! "
    else:
        $ letranalad = 1
        show letra onlayer kozep:
            zoom 0.4
            xpos 0.65
            ypos 0.4
            alpha 1.0
            linear 1.0 alpha 0.0
    show screen debrakertje2
$ renpy. pause(hard=True)
label leengedocsoszoveg:
    hide screen debrakertje2
    f "Downpipe."
    show screen debrakertje2
$ renpy. pause(hard=True)
label mamacibzarfel:
    hide screen debrakertje2
    if mamakenocsenalad == 1:
        hide invertori onlayer elotte6
        hide screen invertori
        hide screen invertori2
        show debrakert2kozelei onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show mamapoz1r3 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "Here is the cream. Let me see the zipper!"
        show mamapoz1r3 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show mamapoz1r5 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show ferdpoz1szemlefelenez onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        m "This is it."
        show ferdpoz1szemlefelenez onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz8 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        fg "Fuck! It is worse than I expected!"
        m "Come on Freddy! Do it!"
        f "Just a moment! I have to be prepared…"
        m "Do not waste my time! I have to go in a few minutes."
        show fredundor onlayer elotte:
            xzoom -1.0
            alpha 0.0
            linear 1.0 alpha 1.0
        f "Gulp!... Come on! You will make it! You can do it!"
        show fekete onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "Ugh! Disgusting! Agghhh!"
        show screen perc10
        play sound "audio/zipzar.wav"
        show screen s3
        u ""
        hide screen perc10
        $ mamaholvan = "sehol"
        hide mamalabal3r3540 onlayer kozep2
        hide fredundor onlayer elotte
        hide fiupoz8 onlayer elotte
        hide mamapoz1r5 onlayer elotte
        hide mamapoz1r3 onlayer elotte
        show mamapoz1r4 onlayer elotte
        show fiupoz4 onlayer elotte
        hide fekete onlayer elotte
        show fekete onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        f "I am done!"
        m "Your hand felt so nice Freddy! You can use your hands for sure.. I will ask you next time, too…"
        m "See you later! Do not wait for me too long!"
        show debrakert2kozelei onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show mamapoz1r4 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz4 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        $ mamakenocsenalad = 2
        $ nap12estelegyen += 1
        if nap12estelegyen == 5:
            $ ancikaholvan = "sehol"
            $ eszterholvan = "sehol"
            $ mamaholvan = "mamakanapenanapaliban"
            $ tiltjaatereketsetlanahaza = True
            $ tiltjaatereketnyomortanya = True
            $ tiltjaatereketlakotomb = True
            $ tiltjaatereketcukrazda = True
            $ tiltjaatereketszomszedok = True
            $ esteighatralevoido = 0
            $ tiltjaatereketegyetem = True
            $ tiltjaatereketpark = True
            $ tiltjaatereketsritbar = False
            $ boltbanemmehetek = True
            $ tiltjaadebrakertjet = True
        show invertori onlayer elotte6:
            yalign 0.0
        show screen invertori
    if mamakenocsenalad == 0:
        f "I do not have the crem yet."
    show screen debrakertje2
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
