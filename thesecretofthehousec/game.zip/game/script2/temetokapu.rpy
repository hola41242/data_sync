label temetokapu:
    $ holvagyok = "temetokapu"
    jump tiltasok
$ renpy. pause(hard=True)
label temetokapuszov:
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori2
    show temetokepu
    show temetokepuelott onlayer kozep4
    if temetokapuszemet1 == 1:
        show temetokapuszemet1 onlayer hatso
    if temetokapuszemet2 == 1:
        show temetokapuszemet2 onlayer hatso
    if temetokapuszemet3 == 1:
        show temetokapuszemet3 onlayer hatso
    if temetokapuszemet4 == 1:
        show temetokapuszemet4 onlayer hatso
    if temetokapuszemet5 == 1:
        show temetokapuszemet5 onlayer hatso
    if temetokapuszemet6 == 1:
        show temetokapuszemet6 onlayer hatso
    if temetokapuszemet7 == 1:
        show temetokapuszemet7 onlayer hatso
    if temetokapuszemet8 == 1:
        show temetokapuszemet8 onlayer hatso
    if temetokapuszemet9 == 1:
        show temetokapuszemet9 onlayer hatso
    if temetokapuszemet10 == 1:
        show temetokapuszemet10 onlayer hatso
    if temetokapuszemet11 == 1:
        show temetokapuszemet11 onlayer hatso
    if temetokapuszemet12 == 1:
        show temetokapuszemet12 onlayer hatso
    if temetokapuszemet13 == 1:
        show temetokapuszemet13 onlayer hatso
    if temetokapuszemet14 == 1:
        show temetokapuszemet14 onlayer hatso
    if temetokapuszemet15 == 1:
        show temetokapuszemet15 onlayer hatso
    if temetokapuszemet16 == 1:
        show temetokapuszemet16 onlayer hatso
    if temetokapuszemet17 == 1:
        show temetokapuszemet17 onlayer hatso
    if temetokapuszemet18 == 1:
        show temetokapuszemet18 onlayer hatso
    if temetokapuszemet19 == 1:
        show temetokapuszemet19 onlayer hatso
    if temetokapuszemet20 == 1:
        show temetokapuszemet20 onlayer hatso
    if temetokapuszemet21 == 1:
        show temetokapuszemet21 onlayer hatso
    if temetokapuszemet22 == 1:
        show temetokapuszemet22 onlayer hatso
    if temetokapuszemet23 == 1:
        show temetokapuszemet23 onlayer hatso

    jump engedejek


$ renpy. pause(hard=True)
label temetokapulomok:
    hide screen temetokapu
    f "Some trash."
    show screen temetokapu
$ renpy. pause(hard=True)
label temetokapuelsosegejlada:
    hide screen temetokapu
    if hanyadiknapvan == 10:
        if zoli10reszcotton == 1:
            if cottonnalad >= 1:
                play sound "audio/felnyit.wav"
                f "It is empty."
                show screen temetokapu
            if cottonnalad == 0:
                play sound "audio/felnyit.wav"
                $ cottonnalad = 1
                f "Cool! One condom was left!"
                show screen temetokapu
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 11:
        if cottonkell11nap == 2:
            if cottonnalad == 1:
                $ cottonkell11nap = 3
                play sound "audio/felnyit.wav"
                f "I hope it is not too late..."
                $ cottonnalad = 0
            if cottonnalad == 0:
                play sound "audio/felnyit.wav"
                f "Cool! The box is full of condoms!"
                show screen temetokapu
                $ renpy. pause(hard=True)
    if hanyadiknapvan == 12:
        if tanulhac12nap == 2:
            if cottonnalad == 0:
                $ cottonnalad = 1
                play sound "audio/felnyit.wav"
                f "Cool! The box is full of condoms!"
                show screen temetokapu
                $ renpy. pause(hard=True)


    f "An emergency box. It is closed."

    show screen temetokapu
$ renpy. pause(hard=True)
label temetokapudoboz:
    hide screen temetokapu
    f "A box with sweepings."
    show screen temetokapu
$ renpy. pause(hard=True)
label temetokapuagvagofel:
    $ temetokapuszemet23 = 0
    $ agfuresznalad = 1
    show temetokapuszemet23 onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label temetokapuharang:
    hide screen temetokapu
    f "A heavy bell. Noone stole it until now… starnge…"
    show screen temetokapu
$ renpy. pause(hard=True)
label szamitogepegerfell:
    hide screen temetokapu
    if lidianakregiegerkell == True:
        $ temetokapuszemet1 = 0
        $ regiegernalad = 1
        show temetokapuszemet1 onlayer hatso:
            alpha 1.0
            linear 1.0 alpha 0.0
    if lidianakregiegerkell == False:
        f "A mouse for the computer. No USB connection. This is an old mouse."
    show screen temetokapu
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
