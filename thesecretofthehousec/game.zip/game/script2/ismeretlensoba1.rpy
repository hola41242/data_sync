label ismeretlenajto1:
    hide screen fajasokertfele
    f "Why should I enter this room?"
    show screen fajasokertfele

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
