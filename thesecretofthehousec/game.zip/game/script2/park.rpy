label park:
    $ holvagyok = "park"
    jump tiltasok
$ renpy. pause(hard=True)
label parkszov:
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori2
    show parkalap
    show parkhatsobokor
    show parkhatsobokorelotifa onlayer hatso1
    show parkwcelotiresz onlayer hatso1
    show parkkozepsoresz onlayer hatso2
    show parklegfelsoresz onlayer hatso3
    show pilango6reszanim onlayer kozep:
        xpos 0.8
        ypos 0.4
    show pilango6reszanim5 onlayer kozep:
        xzoom -1.0
        zoom 0.8
        xpos 0.81
        ypos 0.43
    show pilangoszal6reszanim onlayer kozep:
        xpos 0.82
        ypos 0.44
    show pilangoszal6reszanim2 onlayer kozep:
        zoom 0.9
        xzoom -1.0
        xpos 0.79
        ypos 0.43
    show pilangoszal6reszanim5 onlayer kozep:
        xpos 0.78
        ypos 0.43
    if parkszemet1 == 1:
        show parkszemet1 onlayer kozep:
            xpos 0.1
            ypos -0.1
    if parkszemet2 == 1:
        show parkszemet2 onlayer kozep
    if parkszemet3 == 1:
        show parkszemet3 onlayer kozep
    if parkszemet4 == 1:
        show parkszemet4 onlayer kozep
    if parkszemet5 == 1:
        show parkszemet5 onlayer kozep
    if parkszemet6 == 1:
        show parkszemet6 onlayer kozep
    if parkszemet7 == 1:
        show parkszemet7 onlayer kozep
    if parkszemet8 == 1:
        show parkszemet8 onlayer kozep
    if parkadriana == 1:
        show parkadriana onlayer kozep
    if adrianaholvan == "parkban":
        show parkadriana onlayer kozep
    if kittyholvan == "parkban":
        if kittyholtakarit > 0:
            $ kittyholtakarit = renpy.random.choice(['1', '2', '3' ])
            if kittyholtakarit == "1":
                show kitty270szemetettszedanim onlayer hatso:
                    zoom 0.4
                    xpos 0.6
                    ypos 0.3
            if kittyholtakarit == "2":
                show kitty270szemetettszedanim2 onlayer hatso1:
                    zoom 0.7
                    xpos 0.85
                    ypos 0.28
            if kittyholtakarit == "3":
                show kitty270szemetettszedanim3 onlayer hatso2:
                    zoom 1.0
                    xpos 0.1
                    ypos 0.25
    if parkbanjarsz == 0:
        $ parkbanjarsz = 1
        $ parkadriana = 1
        $ fekete = True
        show kitty onlayer kozep:
            zoom 0.6
            xpos 0.5
            ypos 0.2
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.0
        show screen s2
        u ""
        show parkkozelei onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show kitty onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show kittyelolbeszed1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer kozep:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        k "Oh you came!"
        f "Yeah! Did you find something useful for me?"
        k "Not yet. I just looked around. The park got really messy and dirty. I will never finish cleaning it alone."
        f "Let me help you! You are always so nice to me."
        k "Super! Start over there. I will clean the bushes."
        f "Do you have any bags for me? I should put the trash in a rubbish bag first."
        k "I have only one. Sorry! Please look for another one and start on the work!"
        f "Fucking cool… I will go home. I remember I put a strong rubbish bag under the sink in the kitchen yesterday. I will be back soon!"
        k "Ok, I start cleaning."
        f "Bye!"
        show parkkozelei onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show kittyelolbeszed1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer kozep:
            alpha 1.0
            linear 1.0 alpha 0.0
        $ kittyholtakarit = renpy.random.choice(['1', '2', '3' ])
        if kittyholtakarit == "1":
            show kitty270szemetettszedanim onlayer hatso:
                zoom 0.4
                xpos 0.6
                ypos 0.3
                alpha 0.0
                linear 1.0 alpha 1.0
        if kittyholtakarit == "2":
            show kitty270szemetettszedanim2 onlayer hatso1:
                zoom 0.7
                xpos 0.85
                ypos 0.28
                alpha 0.0
                linear 1.0 alpha 1.0
        if kittyholtakarit == "3":
            show kitty270szemetettszedanim3 onlayer hatso2:
                zoom 1.0
                xpos 0.1
                ypos 0.25
                alpha 0.0
                linear 1.0 alpha 1.0
        show screen s2
        u ""
    if hanyadiknapvan == 8:
        if gyongyviragnalad == 0:
            show gyongyviragazinvertoriban onlayer kozep:
                xpos 0.71
                ypos 0.44
    if Edwardsholvan == "parkban":
        show oregaparkban onlayer kozep
    if hanyadiknapvan == 9:
        if beszeltelannaval9resz == True:
            if leengedonalad == 0:
                show anikalabbal540 onlayer kozep:
                    zoom 0.8
                    xpos 0.65
                    ypos 0.25
                show csovesfodo540 onlayer kozep:
                    xzoom -1.0
                    xpos 0.55
                    ypos 0.2
            if leengedocsofelveheted == False:
                show jimelolbeszed2 onlayer hatso1:
                    zoom 0.2
                    xpos 0.75
                    ypos 0.32
                    linear 1.0 ypos 0.34
                    pause 4.0
                    linear 1.0 ypos 0.32
                    pause 4.0
                    repeat
        if giliszta == 1:
            show parkgiliszta onlayer kozep
            if fogjhalat == 1:
                show csillogaskicsianim onlayer kozep:
                    xpos 0.56
                    ypos 0.66

        if macskaholvan == "parknal":
            show macska-10 onlayer hatso2:
                zoom 0.8
                xzoom -1.0
                xpos 0.65
                ypos 0.5
        if boboholvan == "parkban":
            show boboalap425:
                zoom 0.5
                xpos 0.05
                ypos 0.31
    if holvanliza == "sertegetikittyaparkban":
        if kittyholvan == "sertegetikittyaparkban":
            show kitty270szemetettszedanim3 onlayer hatso2:
                zoom 1.0
                xpos 0.1
                ypos 0.25
            show parkbanliza onlayer hatso2:
                zoom 0.8
                xpos 0.1
                ypos 0.093
    if ritaholvan == "parkbanpadon":
        show ritaaparkban onlayer kozep
    if hanyadiknapvan == 10:
        show pucernoaparkbananim onlayer hatso:
            xpos 0.8
            ypos 0.345
    if hanyadiknapvan >= 11:
        $ pucernoaparkban = renpy.random.randint (1, 10)
        $ pucernoaparkban = (pucernoaparkban)
        if pucernoaparkban > 6:
            show pucernoaparkbananim onlayer hatso:
                xpos 0.8
                ypos 0.345
        if boboholvan == "parkban":
            show boboalap425:
                zoom 0.5
                xpos 0.05
                ypos 0.31
        if csacsiholvan == "parkban":
            show csacsi1 onlayer kozep
            show csacsigazdaja onlayer kozep
            if csacsimotyo == 1:
                show csacsimotyo onlayer hatso3
            if csacsikalapja == 1:
                show csacsikalap onlayer kozep
    if hanyadiknapvan == 12:
        if asonallad == 1:
            if viragcserepnalad2 == 2:
                jump asotletenni
        if asonallad == 0:
            show asoaparkban onlayer hatso2
        if kittyszemetenalad == 0:
            show szemet2azinvertoriban:
                xpos 0.65
                ypos 0.7

    jump engedejek
$ renpy. pause(hard=True)
label sakkasztal:
    hide screen park
    f "A table with chairs."
    show screen park
$ renpy. pause(hard=True)
label parkadriana:
    hide screen park
    hide screen invertori
    hide invertori onlayer elotte6
    if hanyadiknapvan == 7:
        show adriana onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
    if hanyadiknapvan == 9:
        if adrianavalbeszeltel9resz == 0:
            show adrianajelenetek9rasz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
        if adrianavalbeszeltel9resz == 1:
            show adriana onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
    if hanyadiknapvan == 12:
        show adriana onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
    show screen s2
    u ""
    if hanyadiknapvan == 9:
        if adrianavalbeszeltel9resz == 0:
            $ adrianavalbeszeltel9resz = 1
            ad "Oh Dr. Your patients are waiting for you…"
            hide parkadriana onlayer kozep
            show adrianabeszedfreddel onlayer kozep2
            m2 "Yeah, I have to go now, but I will be right back. Wait for me please!"
            ad "Alright Dr…"
            show adrianajelenetek9rasz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            ad "Hy Fred! Did you notice something?"
            f "Yeah and I am a bit wondering… Are you not married to Bram?"
            ad "Well… yeah, he is my husband but… life is difficult you know… I am in big trouble…"
            f "What is the problem?"
            ad "I do not know who is the father of my baby…"
            f "That sucks… Can I help you?"
            ad "Maybe after the baby was born…"
            ad "But… Can I help you with something?"
            f "I just saw your nipples and I am just wondering… Can I taste your nipples, too?"
            ad "Why should I allow you to?"
            show screen fedvalaszaadriananak9resz
            $ renpy. pause(hard=True)
            label adrianahadja9resz:
                hide screen fedvalaszaadriananak9resz
                $ adriananakvizkell = True
                f "I never could suck anyone's nipples and I am really sad because of this reason…"
                ad "Oh, poor boy! Nah, I'll let you taste it. Come!"
                show adrianajelenetek9rasz2megjeleno onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s1
                u ""
                show adrianajelenetek9rasz2alap onlayer elotte
                show adrianajelenetek9rasz2szaj1 onlayer elotte
                show adrianajelenetek9rasz2anim onlayer elotte
                show adrianajelenetek9rasz2elotte onlayer elotte2
                show screen s1
                u ""
                show adrianajelenetek9rasz2szaj onlayer elotte
                hide adrianajelenetek9rasz2szaj1 onlayer elotte
                ad "Suck it light and firm…"
                ad "Oh yeah! You make this good…"
                show adrianajelenetek9rasz2szaj1 onlayer elotte
                hide adrianajelenetek9rasz2szaj onlayer elotte
                u ""
                show adrianajelenetek9rasz2szaj onlayer elotte
                hide adrianajelenetek9rasz2szaj1 onlayer elotte
                ad "My husband is disgusted of my belly and we had no sex since months now… I am horny…"
                ad "Oh yeah, suck my pille… You lick it so nice…"
                $ adrianahadja9resz = True
                show adrianajelenetek9rasz2szaj1 onlayer elotte
                hide adrianajelenetek9rasz2szaj onlayer elotte
                u ""
                show screen s2
                u ""
                hide adrianajelenetek9rasz2elotte onlayer elotte2
                hide adrianajelenetek9rasz2alap onlayer elotte
                hide adrianajelenetek9rasz2szaj1 onlayer elotte
                hide adrianajelenetek9rasz2anim onlayer elotte
                hide adrianabeszedfreddel onlayer kozep2
                show adriana onlayer elotte
                hide adrianajelenetek9rasz2megjeleno onlayer elotte
                show adrianajelenetek9rasz2megjeleno onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s2
                u ""
                ad "It is enough for now. I hope we can continue this in the future..."
                ad "Can I help you anything more?"
                jump adriananalugrik9resz
                show adrianabeszedfreddel onlayer kozep2:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s2
                u ""
                show screen park
                $ renpy. pause(hard=True)
            label adriananemhadja:
                hide screen fedvalaszaadriananak9resz
                $ adriananakvizkell = True
                ad "I do not let you suck my boobs... See you later…"
                label adriananalugrik9resz:
                f "I need a strong material to repair the hose pipe."
                ad "I can give you sticking plasters, but before I do, bring me a glass of water please! I got thirsty."
                f "I am right back with the water."
                if adrianahadja9resz == False:
                    show adrianabeszedfreddel onlayer kozep2:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                if adrianahadja9resz == True:
                    show adriana onlayer elotte:
                        alpha 1.0
                        linear 1.0 alpha 0.0
                show parkadriana onlayer kozep:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s2
                u ""
                show screen invertori
                show invertori onlayer elotte6:
                    yalign 0.0
                show screen park
                $ renpy. pause(hard=True)
        if adrianavalbeszeltel9resz == 1:
            if poharbanban == "semmi":
                f "What did you ask for?"
                ad "Please bring me a glass of water. I am thirsty."
                f "OK."
                show adriana onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
            else:
                $ tapasznalad = 1
                $ poharbanban = "semmi"
                $ adriananakvizkell = False
                $ adrianaholvan = "sehol"
                hide parkadriana onlayer kozep
                ad "Thank you! I really needed this."
                show adriana onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
    if hanyadiknapvan == 7:
        if adrianahazaakarmenni == True:
            $ adrianahazaakarmenniszojbramnak = True
            ad "Hy! Your name is Fred. Do I remember well?"
            f "Yeah!"
            ad "I can not reach my husband. He left his mobile phone in the car again."
            ad "I would like to go home. I got tired. Can you find him and tell him about this?"
            f "Of course! I am right on my way!"
            ad "He must be hanging around the Shopping mall."
            f "Understood. I will look after him."
            show adriana onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            show screen invertori
            show invertori onlayer elotte6:
                yalign 0.0
            show screen park
            $ renpy. pause(hard=True)
        f "Hello! My name is Fred!"
        ad "I am Adriana. What can I help you with?"
        f "Nothing. I just hang around."
        ad "I do not feel like having a chat. I want to enjoy the sun and the fresh air only."
        f "Understood. Have a nice time!"
        show adriana onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
    if hanyadiknapvan == 12:
        if girosznalad == 1:
            $ nap12estelegyen += 1
            ad "Hy! Something smells so good! What do you have!"
            f "Oh! You can smell my Gyros I guess.."
            ad "Do you have a Gyros?"
            f "I think it is made of octopus meat."
            ad "What do you want for exchange?"
            f "I can not explain it clearly. Can I show you instead?"
            show adrianhater12napalap onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide adrianhater12napalap onlayer elotte
            show adrianhater12nap onlayer elotte
            show adriana12napfejalap onlayer elotte
            show adriana12napszemanim onlayer elotte
            show adriana12napszaj1 onlayer elotte
            show adriana12napkezekanim onlayer elotte2
            show screen s3
            u ""
            hide adriana12napszaj1 onlayer elotte
            show adriana12napszajanim onlayer elotte
            ad "I never expected you to wish to do something like that…"
            show adriana12napszaj1 onlayer elotte
            hide adriana12napszajanim onlayer elotte
            show screen s2
            u ""
            hide adriana12napfejalap onlayer elotte
            hide adriana12napszemanim onlayer elotte
            hide adriana12napszaj1 onlayer elotte
            show adriana12napfejleanim onlayer elotte
            show screen s2
            u ""
            f "I just love to touch your big breasts like this.."
            show screen s2
            u ""
            f "They are soft and they have a nice from…"
            hide adriana12napfejleanim onlayer elotte
            show adriana12napfejfelanim onlayer elotte
            show screen s1
            u ""
            hide adriana12napfejfelanim onlayer elotte
            show adriana12napfejalap onlayer elotte
            show adriana12napszemanim onlayer elotte
            show adriana12napszaj1 onlayer elotte
            show adriana12napkezekanim onlayer elotte2
            show screen s2
            u ""
            hide adriana12napszaj1 onlayer elotte
            show adriana12napszajanim onlayer elotte
            ad "Just… enjoy yourself as long as you can... I have to go in a few minutes…"
            show adriana12napszaj1 onlayer elotte
            hide adriana12napszajanim onlayer elotte
            show screen s2
            u ""
            u ""

            hide adrianhater12napalap onlayer elotte
            show adrianhater12napalap onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide adriana onlayer elotte
            hide adrianhater12nap onlayer elotte
            hide adriana12napfejalap onlayer elotte
            hide adriana12napszemanim onlayer elotte
            hide adriana12napszaj1 onlayer elotte
            hide adriana12napkezekanim onlayer elotte2
            $ adrianaholvan = "sehol"
            $ girosznalad = 2
            hide parkadriana onlayer kozep
            show adrianhater12napalap onlayer elotte2:
                alpha 1.0
                linear 1.0 alpha 0.0
            if nap12estelegyen == 5:
                $ ancikaholvan = "sehol"
                $ eszterholvan = "sehol"
                $ mamaholvan = "mamakanapenanapaliban"
                $ tiltjaatereketsetlanahaza = True
                $ tiltjaatereketnyomortanya = True
                $ tiltjaatereketlakotomb = True
                $ tiltjaatereketcukrazda = True
                $ tiltjaatereketszomszedok = True
                $ esteighatralevoido = 0
                $ tiltjaatereketegyetem = True
                $ tiltjaatereketpark = True
                $ tiltjaatereketsritbar = False
                $ boltbanemmehetek = True
                $ tiltjaadebrakertjet = True
            show screen invertori
            show invertori onlayer elotte6:
                yalign 0.0
            show screen park





            $ renpy. pause(hard=True)

        if girosznalad == 0:
            ad "I am so hungry... I would like to rest a bit. Leave me alone. "
            show adriana onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen park
$ renpy. pause(hard=True)
label parkszemetes:
    hide screen park
    if hanyadiknapvan == 12:
        if kittyszemetenalad == 1:
            $ kittyszemetenalad = 2

    if hanyadiknapvan == 8:
        if rovarirtokukaban == 1:
            play sound "audio/elvesz.wav"
            $ rovarirtokukaban = 2
            $ targyazinvertoriban += 1
            $ rovarirtonalad = 1
        if debrakert2dudva == 0:
            if debrakertje2bokorgaz == 0:
                $ szemeteszsaknalad = False
    if kutyatalban == "kutyakaja":
        f "I won't throw it away. It would be unneeded wastefullness…"
    if kutyatalban == "tej":
        f "I won't throw it away. It would be unneeded wastefullness…"
    if szemeteszak == 1:
        f "Trash can."
    if szemeteszak > 1:
        play sound "audio/felveszszemet.ogg"
    $ szemeteszak = 1
    if szemeteszedtel == 8:
        $ szemeteszsaknalad = False
    show screen park
$ renpy. pause(hard=True)
label parkviragok:
    hide screen park
    f "Beautiful flowers."
    show screen park
$ renpy. pause(hard=True)
label parkszemet1:
    hide screen invertori
    show screen invertori2
    hide screen park
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parkszemet1 -= 1
            show parkszemet1 onlayer kozep:
                xpos 0.1
                ypos -0.1
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump kittycernatad
    hide screen invertori2
    show screen invertori
    show screen park
$ renpy. pause(hard=True)
label parkszemet2:
    hide screen invertori
    show screen invertori2
    hide screen park
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parkszemet2 -= 1
            show parkszemet2 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump kittycernatad
    hide screen invertori2
    show screen invertori
    show screen park
$ renpy. pause(hard=True)
label parkszemet3:
    hide screen invertori
    show screen invertori2
    hide screen park
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parkszemet3 -= 1
            show parkszemet3 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump kittycernatad
    hide screen invertori2
    show screen invertori
    show screen park
$ renpy. pause(hard=True)
label parkszemet4:
    hide screen invertori
    show screen invertori2
    hide screen park
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parkszemet4 -= 1
            show parkszemet4 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump kittycernatad
    hide screen invertori2
    show screen invertori
    show screen park
$ renpy. pause(hard=True)
label parkszemet5:
    hide screen invertori
    show screen invertori2
    hide screen park
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parkszemet5 -= 1
            show parkszemet5 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump kittycernatad
    hide screen invertori2
    show screen invertori
    show screen park
$ renpy. pause(hard=True)
label parkszemet6:
    hide screen invertori
    show screen invertori2
    hide screen park
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parkszemet6 -= 1
            show parkszemet6 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump kittycernatad
    hide screen invertori2
    show screen invertori
    show screen park
$ renpy. pause(hard=True)
label parkszemet7:
    hide screen invertori
    show screen invertori2
    hide screen park
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parkszemet7 -= 1
            show parkszemet7 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump kittycernatad
    hide screen invertori2
    show screen invertori
    show screen park
$ renpy. pause(hard=True)
label parkszemet8:
    hide screen invertori
    show screen invertori2
    hide screen park
    if szemeteszsaknalad == False:
        f "I need a rubbish bag for this."
    if szemeteszsaknalad == True:
        if szemeteszak >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if szemeteszak < 4:
            play sound "audio/elvesz.wav"
            $ szemeteszak += 1
            $ szemeteszedtel += 1
            $ parkszemet8 -= 1
            show parkszemet8 onlayer kozep:
                alpha 1.0
                linear 1.0 alpha 0.0
            if szemeteszedtel == 8:
                jump kittycernatad
    hide screen invertori2
    show screen invertori
    show screen park
$ renpy. pause(hard=True)
label kittyparkbanszexy:
    hide screen park
    hide screen invertori
    hide invertori onlayer elotte6
    hide nap7kittysexy onlayer elotte
    show nap7kittysexy onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    if hanyadiknapvan == 7:
        k "Why are you look at me like that? Gosh! I got tired! Still, the hard work is worth it. Look around! "
        f "Yeah, the park looks wonderful."
    if hanyadiknapvan == 8:
        f "Hy Kitty! What are you doing here?"
        k "I pick up the trash. Some idiots came here at night and threw insecticide and paint sprays, papers all around the bushes."
        f "I will help you if I have a bit of time for sure. You are really nice and helpful. The thread was a big help yesterday."
        if kerdezkorbe8resz == True:
            if receptnalad == 0:
                f "Do you know any trick to heal sunburn?"
                k "No, I only put on the sun milk and it protects me…"
                f "Ok, thank you for your answer!"
            if receptnalad == 1:
                if lizanakmegmutatadareceptet == False:
                    f "Can you read me this recipe?"
                    k "Sorry, but I can not read this. I can not help you. I have dyslexia and because of that it is extremely hard for me to read handwriting. Sorry!"
    if hanyadiknapvan == 10:
        if kerjmunkatkerhec == True:
            if ladatmegtalalhatod == 0:
                f "Hy!"
                k "Hello! Would you like to help me again?"
                f "I am sorry, I have no time. Do you know about some jobs I could accept? I need money."
                k "No. Let me know your phone number and I will call you if I find some!"
                f "Ok +36……"
                show screen s25
        if gyufanalad == 1:
            $ spaklinalad = 1
            $ gyufanalad = 2
            $ kittyholvan = "sehol"
            hide kitty270szemetettszedanim onlayer hatso
            hide kitty270szemetettszedanim onlayer hatso1
            hide kitty270szemetettszedanim onlayer hatso2
            f "Here you are! The matches."
            k "Thank you! Now I can burn the twigs."
            k "Would you like to join me?"
            f "Sorry! I am helping Puffy now. Maybe next time!"
            k "Ok. I will show you the labyrint. It is fun."
            show screen s25
        if sirmohashezkell == True:
            if spaklinalad == 0:
                if kittyvelbeszeltel10resz == True:
                    $ kittykeriagyufat = True
                    f "What did you ask for?"
                    k "I asked for matches."
                    show screen s25
                if kittyvelbeszeltel10resz == False:
                    $ kittykeriagyufat = True
                    $ kittyvelbeszeltel10resz = True
                    f "Are you visiting the artistic curse?"
                    k "Yes, I am. Do you wish to join me?"
                    f "No, I am looking for a tool… for a scraper tool. I am looking for some kind of a spatula."
                    k "I have one."
                    f "Can you lend me the spatula?"
                    k "Of course, but please help me. Could you bring me a lighter or some matches? I would like to burn the twigs in the labyrinth."
                    k "I have no time to go home for one and I forgot my wallet at home… I am really busy cleaning the park."
                    f "Ok, I will bring you something."
                    show screen s25
    if hanyadiknapvan == 11:
        k "I heard about you and Rita… You are… lovers now..."
        f "What? No…"
        k "But you took her virginity..."
        f "Yes, but we are not a couple, she misunderstood the situation and..."
        k "This is not my business. You do not have to explain it."
    if hanyadiknapvan == 12:
        if kittyszemetenalad == 2:
            k "Did you throw out the trash? Thank you! I got tired."
            f "Why do you not take a break?"
            k "It is a good idea! Let us sit down on the bench."
            show kitty12napjelenet onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            k "Ehm… What are you doing now?"
            f "I am just resting…"
            k "This is getting a bit uncomfortable for me. You are lovers with Rita…"
            f "We are not lovers, we just fuck sometimes."
            k "Well… that is even worse, but still not ok for me. I am going home!"
            f "Your tights felt good… Alright. I have to learn, too."
            hide nap7kittysexy onlayer elotte
            $ kittyholvan = "sehol"
            $ tanulhac12nap = 1
            hide kitty270szemetettszedanim onlayer hatso
            hide kitty270szemetettszedanim2 onlayer hatso1
            hide kitty270szemetettszedanim3 onlayer hatso2
            show kitty12napjelenet onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            show screen invertori
            show invertori onlayer elotte6:
                yalign 0.0
            show screen park
            $ renpy. pause(hard=True)
    u ""
    f "Hello! What are you doing?"
    k "I am taking care of the park. Would you like to help me?"
    f "I have no time. Sorry!"

    show nap7kittysexy onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen park
$ renpy. pause(hard=True)
label kittycernatad:
    hide screen park
    show parkkozelei onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show kittyelolbeszed1 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer kozep:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    k "I found something for you. Will this do?"
    $ cerna = 1
    f "Oh yeah! You are the best Kitty! Thank you!"
    k "I should be thankful. You cleaned a big parcel. I will stay here to clean up everything."
    f "I have to go now. I have a lot to do. Bye Bye!"
    show parkkozelei onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show kittyelolbeszed1 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen park
    show screen invertori
    hide screen invertori2
$ renpy. pause(hard=True)
label gyongyviragfel:
    show gyongyviragazinvertoriban onlayer kozep:
        xpos 0.71
        ypos 0.44
        alpha 1.0
        linear 1.0 alpha 0.0
    $ gyongyviragnalad = 1
    $ targyazinvertoriban += 1
$ renpy. pause(hard=True)
label fodoesanikabeszelgetparkban:
    hide screen invertori
    hide invertori onlayer elotte6
    hide screen park
    hide fiupoz1 onlayer elotte
    hide fiupoz2 onlayer elotte
    show parkosjelenetanikafordoesferd onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    fr "You came again Honey!"
    a "Yeah! I had some freetime…"
    fr "Why did you bring this nubbin with you?"
    a "Who cares! He can watch us. It is so exciting to do it in public…"
    show parkosjelenetanikafordoesferd onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0

    show screen s2
    u ""
    show screen park
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
$ renpy. pause(hard=True)
label jimmelbeszelniparkban:
    hide screen park
    $ leengedocsofelveheted = True
    hide fiupoz1 onlayer elotte
    hide fiupoz2 onlayer elotte
    show parkkozelei2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show jimelolbeszed2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    f "Hey Jim! Do you know a guy called J?"
    show jimelolbeszed2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show jimelolbeszed1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    j "J is my nickname! This name is strong and everyone calls me J who respects my coolness…"
    f "Fine as fuck! Do you know a girl called Anna?"
    show fiupoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    j "I have a nephew with the same name..."
    f "She has been waiting for you for days now."
    show jimelolbeszed1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show jimelolbeszed2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    j "Yeah... I totally forgot! I did not find her at the bus station and I could not reach her on the phone..."
    f "She asked me to search for you."
    j "Well, I was not searching for her because you know… she is a bit crazy and strange…"
    f "Can be. She is waiting next to the ruins. Should I bring her here?"
    j "No, I guess I will go to her now."
    f "Super! Leave the snake there if possible!"
    j "What kind of a… snake?"
    f "You will find out..."
    $ keresedjet = False
    hide jimelolbeszed2 onlayer hatso1
    show parkkozelei2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show jimelolbeszed2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen park
$ renpy. pause(hard=True)
label macskaelszaladparknal:
    hide screen park
    $ macskaholvan = "parknal"
    $ macskaelszaladt = True
    if kutyatalban == "kutyakaja":
        $ kutyatalnalad = 2
        show macskatalkutyakajas onlayer hatso2:
            zoom 0.8
            xzoom -1.0
            xpos 0.65
            ypos 0.5
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
    if kutyatalban == "tej":
        $ kutyatalnalad = 2
        show macskataltejes onlayer hatso2:
            zoom 0.8
            xzoom -1.0
            xpos 0.65
            ypos 0.5
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
    hide macska-10 onlayer hatso2
    show macskaszalad onlayer hatso2:
        zoom 0.8
        xzoom -1.0
        xpos 0.65
        ypos 0.5
        linear 0.125 xpos 0.64
        linear 0.1 xpos 0.625
        linear 0.084 xpos 0.605
        linear 4.0 xpos -0.2
    show screen s1
    u ""
    if kutyatalban == "kutyakaja":
        $ pulikutyaholvan = "boltoknal"
        $ macskanakkinaltadakutyakajat = True
        f "Pepper doesn't like dog food. I will try to give him milk."
        show macskatalkutyakajas onlayer hatso2:
            zoom 0.8
            xzoom -1.0
            xpos 0.65
            ypos 0.5
            alpha 1.0
            linear 1.0 alpha 0.0
        $ kutyatalnalad = 1
        show screen park
        $ renpy. pause(hard=True)
    if kutyatalban == "tej":
        $ macskanakkinaltadatejet = True
        f "This fucking cat does not like milk.I should go and ask Rita about this damn cat."
        show macskataltejes onlayer hatso2:
            zoom 0.8
            xzoom -1.0
            xpos 0.65
            ypos 0.5
            alpha 1.0
            linear 1.0 alpha 0.0
        $ kutyatalnalad = 1
        show screen park
        $ renpy. pause(hard=True)
    f "This won't work. I need to find a way to catch him."
    show screen park
$ renpy. pause(hard=True)
label gilisztafel:
    $ giliszta = 0
    $ gilisztanalad +=1
    hide csillogaskicsianim onlayer kozep
    show parkgiliszta onlayer kozep:
        alpha 1.0
        linear 1.0 alpha 0.0
    if faagnalad == 1:
        if gilisztanalad == 2:
            if horognalad == 1:
                if madzagveheto == 2:
                    $ faagnalad = 2
                    $ gilisztanalad = 3
                    $ horognalad = 2
                    $ madzagveheto = 4
$ renpy. pause(hard=True)
label kittyeslizaparkbanvitatkozik:
    hide screen park
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    show kittylizaveszekszik9resz onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    l "What is up fat?"
    k "Hy Liza… I have a name..."
    l "Yeah, but who cares?"
    k "Why did you come?"
    l "I was just bored and I decided to take a walk in the park… Do you have any problem with this pig?"
    k "No… Can you please take a walk far away from me?"
    l "I have my freedom, I can walk anywhere I want in this park piggy…"
    k "Ok, but why are you insulting me?"
    l "I am not insulting you swine… I just wanted to talk to you…"
    k "I am so lucky you know so many names of the animal called hog…"
    l "I am so lucky pigs eat anything… Do you eat anything sow?"
    k "I am so lucky I am a peaceful person..."
    show kittylizaveszekszik9resz onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0
    show screen park
$ renpy. pause(hard=True)
label bobovalbeszelszaparkban:
    hide screen park
    show parkkozelei onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1szem2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show bobopoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    if sanyithivhatod == 0:
        if mosogepetmegkeljavitani == 1:
            $ mosogepetmegkeljavitanibobovalbeszeltel = True
            $ holvanliza = "lizanapaliaban"
            $ ciliholvan = "lizanapaliaban"
            f "Hy Boby! Can a goblin repair the drying machine?"
            bo "My name is BOBO and I am NOT a Goblin!"
            f "Do you know anyone who could repair my machine? I need to make it work fast."
            bo "You should ask for mercy first. You are a big penis, you know?"
            show fiupoz4 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1szem2 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            f "I am sorry! I do not know, why I behave like this in your near."
            bo "Forget it. I know how brainless giants work… One brainless giant is standing next to me right now. I got used to assholes…"
            show fiupoz4 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1szem2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Can you help me or not?"
            bo "Ask Alexander. He is the factotum of Andrew."
            f "Where can I find Alexander? Do you know his phone number?"
            bo "I really do not know. Andrew could tell..."
            f "Where can I find Andrew?"
            bo "You better do not visit Andrew with this. He is an angry man. Do you know Liza?"
            f "Yes. Why?"
            bo "Liza is the friend of Cili. Cili should know the number of Alexander as well."
            f "Fine. I will go and ask Liza. "
            bo "Ok, but take your smell with you! You smell disgusting!"
            f "Of course Goblin!"
            jump bobonalugrik11nap
    if keresedjet == True:
        f "I am sorry Mr. Goblin! Does the nickname „J” belong to you?"
        bo "No, and I am not a goblin. My name is Bobo!"
        f "I am sorry!"
    if keresedjet == False:
        f "Are you the goblin of the labyrinth?"
        bo "You think you are funny, don’t you?"
        f "I am sorry to hurt your feelings Mr.Goblin. Can I wish?"
        bo "You should wish for your mother! Motherfucker!"
        f "I am sorry, I was just kidding! Sorry!"
        bo "Never mind…"
        f "Super! I have to go now."
        bo "You are welcome.{size=-10} I just came out to get some fresh air and an asshole starts to joke around... Typical..."
label bobonalugrik11nap:
    show parkkozelei onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1szem2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show bobopoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen park
$ renpy. pause(hard=True)
label parkrita:
    if hanyadiknapvan == 12:
        if cottonnalad == 1:
            $ cottonnalad = 2
            $ nap12estelegyen += 1
            play music "audio/szexy.ogg" fadeout 1
            hide screen park
            hide screen invertori2
            hide screen invertori
            hide invertori onlayer elotte6
            show ritaszex12napjel1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            r "Make it gentle. It hurt last time."
            f "I will be gentle."
            u ""
            show ritaszex12napjel2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            r "Oh yeah! It feels so nice!"
            r "Make me your woman!"
            r "{size=-10}I will be yours. Noone can take me from you…"
            show ritabaszjelenet10reszm4megjeleno onlayer elotte3:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            hide ritabaszjelenet10reszm4megjeleno onlayer elotte3
            show ritabaszjelenet10reszm4alap onlayer elotte
            show ritabaszjelenet10reszm4ritar1 onlayer elotte
            show ritabaszjelenet10reszm4ritaanim onlayer elotte2
            show ritabaszjelenet10reszm4fiulabaanim onlayer elotte2
            show screen s3
            u ""
            r "Oh yeah! Make me your woman!"
            show screen s3
            u ""
            r "This feels so great!"
            show screen s3
            u ""
            r "Is my pussy nice?"
            f "It is Fantastic and tight."
            show screen s3
            u ""
            show ritaszex12napjel3 onlayer elotte3:
                ypos -1.7
                alpha 0.0
                linear 2.0 alpha 1.0
            show screen s2e5
            u ""
            hide ritaszex12napjel3 onlayer elotte3
            show ritaszex12napjel3 onlayer elotte2:
                ypos -1.7
                linear 4.0 ypos 0.0
            show screen s4
            u ""
            show ritabaszjelenet10reszm5kihuzza1 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            show ritabaszjelenet10reszm5kihuzza2 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            play music "audio/park.ogg" fadeout 1
            hide ritabaszjelenet10reszm4alap onlayer elotte
            hide ritabaszjelenet10reszm4ritar1 onlayer elotte
            hide ritabaszjelenet10reszm4ritaanim onlayer elotte2
            hide ritabaszjelenet10reszm4fiulabaanim onlayer elotte2
            hide ritaszex12napjel1 onlayer elotte
            hide ritaszex12napjel2 onlayer elotte
            hide ritaszex12napjel3 onlayer elotte3
            hide ritaszex12napjel3 onlayer elotte2
            hide ritabaszjelenet10reszm4megjeleno onlayer elotte3
            hide ritabaszjelenet10reszm5kihuzza1 onlayer elotte2
            show parkkozelei onlayer elotte
            show fiupoz6 onlayer elotte
            show ritabeszed onlayer elotte
            show ritabaszjelenet10reszm5kihuzza2 onlayer elotte2:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            r "What time is it? Oh well, I have to go now. See you later!"
            f "Bye!"
            $ ritaholvan = "sehol"
            hide ritaaparkban onlayer kozep
            show parkkozelei onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz6 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show ritabeszed onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            if nap12estelegyen == 5:
                $ ancikaholvan = "sehol"
                $ eszterholvan = "sehol"
                $ mamaholvan = "mamakanapenanapaliban"
                $ tiltjaatereketsetlanahaza = True
                $ tiltjaatereketnyomortanya = True
                $ tiltjaatereketlakotomb = True
                $ tiltjaatereketcukrazda = True
                $ tiltjaatereketszomszedok = True
                $ esteighatralevoido = 0
                $ tiltjaatereketegyetem = True
                $ tiltjaatereketpark = True
                $ tiltjaatereketsritbar = False
                $ boltbanemmehetek = True
                $ tiltjaadebrakertjet = True



            show invertori onlayer elotte6:
                yalign 0.0
            show screen invertori
            show screen park


            $ renpy. pause(hard=True)
        else:


            hide screen park
            f "I do not have a condom. I can not go back to Rita."
            show screen park
        $ renpy. pause(hard=True)
    if cottonnalad == 1:
        $ cottonnalad = 2
        play music "audio/szexy.ogg" fadeout 1
        hide screen park
        hide screen invertori2
        hide screen invertori
        hide invertori onlayer elotte6
        show ritaszexutan10reszn6 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        r "Did you find a condom?"
        f "Yeah! I got it!"
        r "Put it on, please!"
        f "My penis is soft. I can not put it on in this condition."
        r "What should I do? Should I suck it again?"
        f "No, just show me your pussy!"
        r "Ok. This is so exciting!"
        show ritabaszjelenet10reszm1megjeleno onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        hide ritabaszjelenet10reszm1megjeleno onlayer elotte
        show ritabaszjelenet10reszm1alap onlayer elotte
        show ritabaszjelenet10reszm1szaj2 onlayer elotte
        show ritabaszjelenet10reszm1szemanim onlayer elotte
        show ritabaszjelenet10reszm1kezmoz5 onlayer elotte
        show ritabaszjelenet10reszm1arny onlayer elotte2
        show screen s1
        u ""
        hide ritabaszjelenet10reszm1szaj2 onlayer elotte
        show ritabaszjelenet10reszm1szajanim onlayer elotte
        r "Is this ok? Do you want to see a bit more?"
        show ritabaszjelenet10reszm1szaj2 onlayer elotte
        hide ritabaszjelenet10reszm1szajanim onlayer elotte
        f "Just a bit more…"
        hide ritabaszjelenet10reszm1kezmoz5 onlayer elotte
        show ritabaszjelenet10reszm1kezanim onlayer elotte
        show screen s1
        u ""
        hide ritabaszjelenet10reszm1szaj2 onlayer elotte
        show ritabaszjelenet10reszm1szajanim onlayer elotte
        r "How does it look? Better?"
        show ritabaszjelenet10reszm1szaj2 onlayer elotte
        hide ritabaszjelenet10reszm1szajanim onlayer elotte
        f "Much better! Wow!"
        hide ritabaszjelenet10reszm1kezanim onlayer elotte
        show ritabaszjelenet10reszm1kezanim2 onlayer elotte
        show screen s1
        u ""
        hide ritabaszjelenet10reszm1szaj2 onlayer elotte
        show ritabaszjelenet10reszm1szajanim onlayer elotte
        r "Wel… I got a bit embarrassed..."
        r "Are you hard enough?"
        show ritabaszjelenet10reszm1szaj2 onlayer elotte
        hide ritabaszjelenet10reszm1szajanim onlayer elotte
        f "Show me it once again and we will be ready!"
        hide ritabaszjelenet10reszm1kezanim2 onlayer elotte
        show ritabaszjelenet10reszm1kezanim onlayer elotte
        show screen s1
        u ""
        hide ritabaszjelenet10reszm1szaj2 onlayer elotte
        show ritabaszjelenet10reszm1szajanim onlayer elotte
        r "Tell me if we can go further!"
        show ritabaszjelenet10reszm1szaj2 onlayer elotte
        hide ritabaszjelenet10reszm1szajanim onlayer elotte
        hide ritabaszjelenet10reszm1kezanim onlayer elotte
        show ritabaszjelenet10reszm1kezanim3 onlayer elotte
        show screen s1
        u ""
        u ""
        show ritabaszjelenet10reszm2megjeleno onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        hide ritabaszjelenet10reszm1megjeleno onlayer elotte
        hide ritabaszjelenet10reszm1alap onlayer elotte
        hide ritabaszjelenet10reszm1szaj2 onlayer elotte
        hide ritabaszjelenet10reszm1szemanim onlayer elotte
        hide ritabaszjelenet10reszm1kezanim onlayer elotte
        hide ritabaszjelenet10reszm1kezanim2 onlayer elotte
        hide ritabaszjelenet10reszm1arny onlayer elotte2
        hide ritabaszjelenet10reszm1szajanim onlayer elotte
        hide ritabaszjelenet10reszm1kezmoz5 onlayer elotte
        hide ritabaszjelenet10reszm2megjeleno onlayer elotte2
        show ritabaszjelenet10reszm2alap onlayer elotte
        show ritabaszjelenet10reszm2rita1 onlayer elotte
        show ritabaszjelenet10reszm2rita1arny onlayer elotte2
        show ritabaszjelenet10reszm2ritaszaj2 onlayer elotte
        show ritabaszjelenet10reszm2ritaszemanim onlayer elotte
        show ritabaszjelenet10reszm2fiumoz1 onlayer elotte3
        show screen s1
        u ""
        f "I am ready. Are you ready, too? Are you sure?"
        hide ritabaszjelenet10reszm2ritaszaj2 onlayer elotte
        show ritabaszjelenet10reszm2ritaszajanim onlayer elotte
        r "Yes. I am ready."
        show ritabaszjelenet10reszm2ritaszaj2 onlayer elotte
        hide ritabaszjelenet10reszm2ritaszajanim onlayer elotte
        f "Let us get going in!"
        show screen s04
        u ""
        hide ritabaszjelenet10reszm2ritaszemanim onlayer elotte
        show ritabaszjelenet10reszm2ritaszemanim2 onlayer elotte
        hide ritabaszjelenet10reszm2fiumoz1 onlayer elotte3
        show ritabaszjelenet10reszm2fiuanim onlayer elotte3
        show screen s04
        u ""
        hide ritabaszjelenet10reszm2ritaszemanim2 onlayer elotte
        hide ritabaszjelenet10reszm2rita1 onlayer elotte
        hide ritabaszjelenet10reszm2rita1arny onlayer elotte2
        hide ritabaszjelenet10reszm2ritaszaj2 onlayer elotte
        show ritabaszjelenet10reszm2ritaanim onlayer elotte
        show screen s1
        u ""
        show ritabaszjelenet10reszm2veranim onlayer elotte3:
            pause 2.0
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        hide ritabaszjelenet10reszm2ritaanim onlayer elotte
        show ritabaszjelenet10reszm2rita7 onlayer elotte
        show ritabaszjelenet10reszm2rita7szajanim onlayer elotte
        show ritabaszjelenet10reszm2rita7arny onlayer elotte2
        r "Oh yeah! I feel different now! I am not a virgin anymore. Let us make love!"
        hide ritabaszjelenet10reszm2rita7szajanim onlayer elotte
        show ritabaszjelenet10reszm3tovig1 onlayer elotte3:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        f "Can I push it deeper?"
        r "Is your penis not full inside me? It is huge!"
        f "Nope."
        r "Wow! Push it all in please! I want to feel you totally inside me. "
        u ""
        show ritabaszjelenet10reszm3tovig2 onlayer elotte3:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        u ""
        show ritabaszjelenet10reszm6 onlayer elotte3:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        r "It hurts a bit and on the other side I get excited of a nice feeling… Is it full in?"
        f "Yes! I am deep in you!"
        r "Your penis stretches me. Move it please. I think it will feel lighter."
        u ""
        show ritabaszjelenet10reszm4megjeleno onlayer elotte3:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        hide ritabaszjelenet10reszm3tovig1 onlayer elotte3
        hide ritabaszjelenet10reszm3tovig2 onlayer elotte3
        hide ritabaszjelenet10reszm6 onlayer elotte3
        hide ritabaszjelenet10reszm4megjeleno onlayer elotte3
        hide ritabaszjelenet10reszm2rita7arny onlayer elotte2
        hide ritabaszjelenet10reszm2fiuanim onlayer elotte3
        hide ritabaszjelenet10reszm2veranim onlayer elotte3
        show ritabaszjelenet10reszm4alap onlayer elotte
        show ritabaszjelenet10reszm4ritar1 onlayer elotte
        show ritabaszjelenet10reszm4ritaanim onlayer elotte2
        show ritabaszjelenet10reszm4fiulabaanim onlayer elotte2
        show screen s3
        u ""
        r "Oh yeah! Make me your woman!"
        show screen s3
        u ""
        r "This feels so great!"
        show screen s3
        u ""
        r "Is my pussy nice?"
        f "It is Fantastic and tight."
        show screen s3
        u ""
        show screen elevezesrevaltani
        $ renpy. pause(hard=True)
        label elelvezni10reszrita:
            hide ritabaszjelenet10reszm4ritaanim onlayer elotte2
            show ritabaszjelenet10reszm4ritaanim2 onlayer elotte2
            show screen s3
            u ""
            r "Oh yeah! Puss it all in!"
            show screen s3
            u ""
        show screen elevezesrevaltani2
        $ renpy. pause(hard=True)
        label elelvezni10reszrita2:
            hide ritabaszjelenet10reszm4ritaanim2 onlayer elotte2
            show ritabaszjelenet10reszm4ritaanim3 onlayer elotte2
            show screen s2e3
            u ""
            hide ritabaszjelenet10reszm4ritaanim3 onlayer elotte2
            show ritabaszjelenet10reszm4ritaanim4 onlayer elotte2
            hide ritabaszjelenet10reszm4ritar1 onlayer elotte
            show ritabaszjelenet10reszm4ritaranim onlayer elotte
            show screen s3
            u ""
            u ""
            show ritabaszjelenet10reszm5kihuzza1 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            show ritabaszjelenet10reszm5kihuzza2 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            u ""
            hide ritabaszjelenet10reszm4ritaanim1 onlayer elotte2
            hide ritabaszjelenet10reszm4ritaanim2 onlayer elotte2
            hide ritabaszjelenet10reszm4ritaanim3 onlayer elotte2
            hide ritabaszjelenet10reszm4ritaanim4 onlayer elotte2
            hide ritabaszjelenet10reszm4ritaranim onlayer elotte
            hide ritabaszjelenet10reszm4alap onlayer elotte
            hide ritabaszjelenet10reszm4ritar1 onlayer elotte
            hide ritabaszjelenet10reszm4ritaanim onlayer elotte2
            hide ritabaszjelenet10reszm4fiulabaanim onlayer elotte2
            hide ritabaszjelenet10reszm2ritaszemanim2 onlayer elotte
            hide ritabaszjelenet10reszm2ritaanim onlayer elotte
            hide ritabaszjelenet10reszm2rita7 onlayer elotte
            hide ritabaszjelenet10reszm2rita7szajanim onlayer elotte
            hide ritabaszjelenet10reszm2alap onlayer elotte
            hide ritaszexutan10reszn1 onlayer elotte
            hide ritabaszjelenet10reszm1kezanim onlayer elotte
            hide ritabaszjelenet10reszm1kezanim2 onlayer elotte
            hide ritabaszjelenet10reszm1kezanim3 onlayer elotte
            hide ritaszexutan10reszn6 onlayer elotte
            u ""
            show ritaszexutan10reszn1 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            play music "audio/park.ogg" fadeout 1
            hide ritabaszjelenet10reszm5kihuzza1 onlayer elotte2
            hide ritabaszjelenet10reszm5kihuzza2 onlayer elotte2
            r "The sex was absolutely fantastic. I think this is because we love each other."
            r "You made it so gentle. This can be possible because you love me so much and you care of me…"
            fg "What?"
            r "This means we are lovers from now on. It is official."
            f "I do not think so. We only had sex…"
            show ritaszexutan10reszn2 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            r "Oh, you are always kidding. You are so funny, I love this craziness in you…"
            r "Now we are Lovers and everything will change from now on. Our whole life will change."
            show ritaszexutan10reszn3 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            r "All love stories end so romantic and happy. Our love story will be special. It will end like a great dream…"
            r "Our story is typical. The parents are against us…"
            r "Or… like in an old SegPit novel… We could die together for love…"
            show ritaszexutan10reszn4 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            f "Hm? What are you talking about?"
            r "I am talking about our feelings, about US…"
            f "I only humped you…"
            r "My fiancé will visit us soon and you will come and fight with him for me. And you will fight against my parents…"
            r "I can imagine: You will have a dispute with my father. He won't agree and you will make me escape from home. We will live together far away from my parents…"
            f "...NOPE..."
            show ritaszexutan10reszn5 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            r "I know… I know! The hero always says no at first. After that he will rescue the princess…"
            r "I am so happy! I should go and talk about all these with my parents."
            f "You should NOT!"
            r "You have the right. We should keep this as a secret until you discuss it with my fiancé…"
            fg "She is crazy!!!!!"
            r "I will go home and I will dream about our romance…"
            r "I hope, You will introduce me to your parents."
            f "It will not be so easy… you know they…"
            r "I know you will solve all problems. So long my dear lover! We will meet tomorrow!"
            hide ritaszexutan10reszn3 onlayer elotte2
            show ritaszexutan10reszn3 onlayer elotte2:
                alpha 0.0
                linear 1.0 alpha 1.0
            fg "She cummed and she got crazy from the feeling… I guess…"
            fg "Well… who cares… I should head home…"
            $ ritaholvan = "sehol"
            $ bertalanholvan = "napaliban"
            hide ritaaparkban onlayer kozep
            hide ritaszexutan10reszn1 onlayer elotte2
            hide ritaszexutan10reszn2 onlayer elotte2
            hide ritaszexutan10reszn4 onlayer elotte2
            hide ritaszexutan10reszn5 onlayer elotte2
            show ritaszexutan10reszn3 onlayer elotte2:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            show screen invertori
            show invertori onlayer elotte6:
                ypos 0.0
            show screen park
            $ renpy. pause(hard=True)
    if fagylaltoknalad == 2:
        if cottonnalad == 0:
            hide screen park
            f "I do not have a condom. I can not go back to Rita."
            show screen park
    if fagylaltoknalad == 1:
        play music "audio/baszosalap.ogg" fadeout 1
        $ fagylaltoknalad = 2
        $ annaholvan = "parktoban"
        $ holvanliza = "tornazik"
        $ fodoholvan = "parkto"
        $ mamaholvan = "konyha"
        $ annaholvan = "sehol"
        hide screen park
        hide screen invertori2
        hide screen invertori
        hide invertori onlayer elotte6
        show fagyiznakaparkbanhatter onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fagyiznakaparkbanrita1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fagyiznakaparkbanferd1 onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        r "Do you know the reason why I asked for a punch of ice cream?"
        f "Do you like the taste of the punch ice cream?"
        r "Nope, guess more!"
        f "Why don’t you tell me? Our ice will melt soon. The weather is really hot…"
        show fagyiznakaparkbanrita1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanrita2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        r "Oh, well… I will tell you. I asked for the punch ice cream because I practiced sucking penis."
        show fagyiznakaparkbanferd1 onlayer elotte2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanferd2 onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        r "It is similar to a penis. The rose part is the glans penis and the cone is the penis."
        show fagyiznakaparkbanferd2 onlayer elotte2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanferd3 onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        r "I am imagining, I will lick a penis and it tastes much better…"
        f "Tell me more! This is so intellectual…"
        show fagyiznakaparkbanrita2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanrita3 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        r "You know, my parents are pushing me to marry a rich man."
        r "But I do not like him. He is selfish and arrogant…"
        f "Did you talk about this with your parents?"
        r "I did, but they don't really care. They have an agreement with that rich family. It is good for the business…"
        show fagyiznakaparkbanrita3 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanrita2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        r "You know… I am still a virgin and I do not want to lose my virginity with that rich guy. "
        r "And I do nto want to be clumsy when I will have sex with my husband…"
        f "...Understandable..."
        r "I thought about..."
        f "Tell me, I am listening..."
        fg "Nah, this date will become a therapy occupation..."
        show fagyiznakaparkbanrita2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanrita3 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        r "Could you let me suck your penis and could you take my virginity?"
        f "Sure… but here?"
        show fagyiznakaparkbanrita3 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanrita4 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        r "Why not? Anika made it in the park, too…"
        r "Or… Do you not like me?"
        f "I like you of course… ok… If you wish to practice, I am here! Use me!"
        show fagyiznakaparkbanrita4 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanrita3 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        r "Ok, but how should we start it?"
        f "I do not know."
        r "I know! Let us kiss first!"
        show fagyiznakaparkbanrita3 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanrita5 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        show fagyiznakaparkbanferd3 onlayer elotte2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanferd1 onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        fg "It is really hot here. My ice cream will melt…"
        show fagyiznakaparkbanferd1 onlayer elotte2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fagyiznakaparkbanferd3 onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        fg "Well... Let this get over with!"
        show ritaesferdcsokja onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        u ""
        show ritafaszszopasjelenetf1megjeleno onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""

        hide ritaesferdcsokja onlayer elotte2
        hide ritafaszszopasjelenetf1megjeleno onlayer elotte2
        hide fagyiznakaparkbanferd1 onlayer elotte2
        hide fagyiznakaparkbanferd2 onlayer elotte2
        hide fagyiznakaparkbanferd3 onlayer elotte2
        hide fagyiznakaparkbanrita1 onlayer elotte
        hide fagyiznakaparkbanrita2 onlayer elotte
        hide fagyiznakaparkbanrita3 onlayer elotte
        hide fagyiznakaparkbanrita5 onlayer elotte
        hide fagyiznakaparkbanrita4 onlayer elotte
        hide fagyiznakaparkbanhatter onlayer elotte
        show ritafaszszopasjelenetf1alap onlayer elotte
        show ritafaszszopasjelenetf1fiu onlayer elotte
        show ritafaszszopasjelenetf1ritamoz1 onlayer elotte
        show ritafaszszopasjelenetf1fiulaba onlayer elotte2
        show ritafaszszopasjelenetf1karfa onlayer elotte2
        show ritafaszszopasjelenetf1fiuszajanim onlayer elotte2

        f "Oh yeah! Start to suck my penis firmly..."
        hide ritafaszszopasjelenetf1fiuszajanim onlayer elotte2
        show ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
        hide ritafaszszopasjelenetf1ritamoz1 onlayer elotte
        show ritafaszszopasjelenetf1ritaanim onlayer elotte

        show screen s3
        u ""
        show ritafaszszopasjelenetf1fiuszajanim onlayer elotte2
        hide ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
        f "Make it the way you lick the ice cream… Now open your mouth widely!"
        hide ritafaszszopasjelenetf1fiuszajanim onlayer elotte2
        show ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
        show screen s3
        u ""
        show ritafaszszopasjelenetf1fiuszajanim onlayer elotte2
        hide ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
        f "I never thought you could suck it so well…"
        hide ritafaszszopasjelenetf1fiuszajanim onlayer elotte2
        show ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
        show screen s3
        u ""
        show ritafaszszopasjelenetf1fiuszajanim onlayer elotte2
        hide ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
        f "Oh yeah! Suck it! Suck it hard! You make this great! Just like a pro…"
        hide ritafaszszopasjelenetf1fiuszajanim onlayer elotte2
        show ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
        show screen s3
        u ""
        u ""
        show ritafaszszopasjelenetf2kozeliszopasanim onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s3
        u ""
        f "Oh! Almost there! Suck it harder!"
        show screen s3
        u ""
        u ""
        show ritafaszszopasjelenetf3alap onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show ritafaszszopasjelenetf3szaja1 onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show ritafaszszopasjelenetf3ritafejeanim onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s3
        u ""
        hide ritafaszszopasjelenetf3szaja1 onlayer elotte2
        show ritafaszszopasjelenetf3szajaanim onlayer elotte2
        f "Yeah! My penis is pulsing! Let me put it in!"
        show ritafaszszopasjelenetf3szaja1 onlayer elotte2
        hide ritafaszszopasjelenetf3szajaanim onlayer elotte2
        hide ritafaszszopasjelenetf3ritafejeanim onlayer elotte2
        show ritafaszszopasjelenetf3ritafejeanim2 onlayer elotte2
        show screen s1e5
        u ""
        show ritafaszszopasjelenet1megjeleno onlayer elotte2:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1e5
        u ""
        hide ritafaszszopasjelenet1megjeleno onlayer elotte2
        show ritafaszszopasjelenet1alap onlayer elotte2
        show ritafaszszopasjelenet1szemanim onlayer elotte2
        show ritafaszszopasjelenet1szaj1 onlayer elotte2
        show screen s1
        u ""
        hide ritafaszszopasjelenet1szaj1 onlayer elotte2
        show ritafaszszopasjelenet1szajanim onlayer elotte2
        r "Do you have a condom?"
        show ritafaszszopasjelenet1szaj1 onlayer elotte2
        hide ritafaszszopasjelenet1szajanim onlayer elotte2
        f "No. I will pull it out before I cum."
        hide ritafaszszopasjelenet1szaj1 onlayer elotte2
        show ritafaszszopasjelenet1szajanim onlayer elotte2
        r "I really like you but I do not trust you. Use a condom and I will allow you to fuck me."
        show ritafaszszopasjelenet1szaj1 onlayer elotte2
        hide ritafaszszopasjelenet1szajanim onlayer elotte2
        f "Wait a minute! I will find some!"
        hide ritafaszszopasjelenetf3alap onlayer elotte2
        hide ritafaszszopasjelenetf3szaja1 onlayer elotte2
        hide ritafaszszopasjelenetf3ritafejeanim onlayer elotte2
        hide ritafaszszopasjelenetf3ritafejeanim2 onlayer elotte2
        hide ritafaszszopasjelenet1alap onlayer elotte2
        hide ritafaszszopasjelenet1szemanim onlayer elotte2
        hide ritafaszszopasjelenet1szaj1 onlayer elotte2
        hide ritafaszszopasjelenetf2kozeliszopasanim onlayer elotte2
        hide ritafaszszopasjelenetf1alap onlayer elotte
        hide ritafaszszopasjelenetf1fiu onlayer elotte
        hide ritafaszszopasjelenetf1ritaanim onlayer elotte
        hide ritafaszszopasjelenetf1fiulaba onlayer elotte2
        hide ritafaszszopasjelenetf1karfa onlayer elotte2
        hide ritafaszszopasjelenetf1fiuszaj1 onlayer elotte2
        show ritafaszszopasjelenet1megjeleno onlayer elotte2:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        $ annaholvan = "parktoban"
        show screen invertori
        show invertori onlayer elotte6:
            ypos 0.0
        show screen park
        play music "audio/park.ogg" fadeout 1
$ renpy. pause(hard=True)
label csacsigazdajaparkban:
    hide screen park
    f "He is sleeping."
    show screen park
$ renpy. pause(hard=True)
label csacsiparkban:
    hide screen park
    if eszterrelbeszeltel11nap == True:
        if cottonkell11nap == 1:
            if csacsikalapjanalad == 1:
                $ csacsikalapja = 1
                $ csacsikalapjanalad = 2
                $ cottonkell11nap = 2
                show csacsikalap onlayer kozep:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                $ cottonnalad = 1
                $ penz = 0
                f "The donkey is happy, I got my condom and the owner should be happy as well with the money..."
                f "I should put the condom in the box before it gets dark. Someone might need the condom today..."
                show screen park
                $ renpy. pause(hard=True)
            if csacsimotyo == 1:
                f "The condoms should be in the pocket somewhere…"
                f "I need only one condom Donkey! Please!!! I do not want to become a father! I am so young... I will leave money for the condom here... Please!"
                hide csacsi1 onlayer kozep
                show csacsi2 onlayer kozep
                f "I can not take the condom. The donkey might bite me… I have to find out something…"
                hide csacsi2 onlayer kozep
                show csacsi1 onlayer kozep
                $ csacsikalapjatfelveheted = True
                show screen park
                $ renpy. pause(hard=True)
    else:
        f "A cute donkey."
    show screen park
$ renpy. pause(hard=True)
label parkbanasofel:
    hide screen park
    if asonallad == 0:
        if debrafeladatotad12nap == 1:
            $ asonallad = 1
            show asoaparkban onlayer hatso2:
                alpha 1.0
                linear 1.0 alpha 0.0
            f "I will only borrow this. I will bring it back later."
        else:
            f "A spade. Nice quality. The owner could be… Kitty or someone else… Who cares?"

    show screen park
$ renpy. pause(hard=True)
label kittyszemetetfelveszed:
    hide screen park
    if kittyszemetetfelveheted == True:
        $ kittyszemetenalad = 1
        show szemet2azinvertoriban:
            xpos 0.65
            ypos 0.7
            alpha 1.0
            linear 1.0 alpha 0.0
    if kittyszemetetfelveheted == False:
        f "Trash. I do not feel like picking it up."
    show screen park
$ renpy. pause(hard=True)
label asotletenni:
    $ asonallad = 0
    show asoaparkban onlayer hatso2
    if kittyszemetenalad == 0:
        show szemet2azinvertoriban:
            xpos 0.65
            ypos 0.7
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    $ fekete = True
    f "I put this back where it belongs to. Someone might need his/her spade."
    jump engedejek
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
