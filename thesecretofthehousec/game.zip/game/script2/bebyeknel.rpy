label bebyeknel:
    if hanyadiknapvan == 10:
        if adtalpenzbebynak10resz == False:
            if penz >= 2000:
                jump ugrikbabyekhez
    if hanyadiknapvan >= 9:
        hide screen temeto
        f "I have noting to do there."
        show screen temeto
        $ renpy. pause(hard=True)
label ugrikbabyekhez:
    $ holvagyok = "bebyeknel"
    jump tiltasok
$ renpy. pause(hard=True)
label bebyeknelszov:
    if hanyadiknapvan == 10:
        hide invertori onlayer elotte6
        hide screen invertori2
        hide screen invertori
        show fredbabybeszel10resz
        hide fekete onlayer screens
        show fekete onlayer screens:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        $ adtalpenzbebynak10resz = True
        $ penz -= 2000
        b "Hy Fred! Nice to meet you! I wanted to call you…"
        f "Did you get a new letter?"
        b "Nope, but I wanted to talk about this, man. I want money. I want to get rich."
        f "How could I help you? I am poor. I have no money."
        b "The information costs money."
        f "Shit..."
        b "Do not talk shit. My sister is not here. I hit you in the face next time. Do not talk vulgaris."
        f "How much money do you want?"
        b "Let me think. Give me 2000 Forints. I will tell you more later."
        f "I have 2000 Forints. Here you are. Please understand, I am not a billionaire."
        b "I know. Find a good job! Now go!"
        $ invertorinejelenyenmeg = True
        $ invertorialapjelenyenmeg = True
        if adtalpenzdaginak10resz == True:
            if adtalpenzbebynak10resz == True:
                $ mrpuliholvan = "cukrazda"
                $ ritaholvan = "cukrazda"
                $ cukrazdalathato = True
        jump temeto


$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
