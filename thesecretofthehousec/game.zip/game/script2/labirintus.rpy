label labirintus:
    hide screen park
    f "This is a labirynt. I do not want to enter this labirynt. I might get lost. "
    show screen park
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
