label lizakertje:
    $ holvagyok = "lizakertje"
    jump tiltasok
label lizakertjeszov:
    if lizakertjefeledatok == 0:
        $ lizakertjefeledatok = 1


    show lizakertje
    show pilango6reszanim:
        xpos 0.17
        ypos 0.795
    show pilango6reszanim2:
        zoom 0.4
        xpos 0.5
        ypos 0.23
    show pilango6reszanim3:
        zoom 1.1
        xzoom -1.0
        xpos 0.06
        ypos 0.4
    show pilango6reszanim4:
        xpos 0.8
        ypos 0.5
    show pilango6reszanim5:
        xzoom -1.0
        zoom 0.8
        xpos 0.9
        ypos 0.4
    show pilangoszal6reszanim6:
        zoom 1.2
        xpos 0.05
        ypos 0.78
    show pilangoszal6reszanim:
        xpos 0.7
        ypos 0.5
    show pilangoszal6reszanim2:
        zoom 0.9
        xzoom -1.0
        xpos 0.85
        ypos 0.55
    show pilangoszal6reszanim3:
        zoom 0.5
        xpos 0.2
        ypos 0.3
    show pilangoszal6reszanim4:
        zoom 0.4
        xzoom -1.0
        xpos 0.1
        ypos 0.4
    show pilangoszal6reszanim5:
        xpos 0.97
        ypos 0.2
    if hanyadiknapvan == 6:
        show lizatornazszonyeg
        show lizakertbentornazikanim:
            zoom 0.45
            xpos 0.45
            ypos 0.36
        if lizakertjegomba == 1:
            show kertigomba
        if lizakertjeszemet1 == 1:
            show kertiszemet1
        if lizakertjeszemet2 == 1:
            show kertiszemet2
        if lizakertjeszemet3 == 1:
            show kertiszemet3
        if lizakertjeszemet4 == 1:
            show kertiszemet4
        if lizakertjedudva1 == 1:
            show kertidudva1
        if lizakertjedudva2 == 1:
            show kertidudva2
        if lizakertjedudva3 == 1:
            show kertidudva3
        if lizakertjedudva4 == 1:
            show kertidudva4
        if lizakertjelevelek == 1:
            show levelekszet
        if lizakertjelevelek == 2:
            show levelekossze
    if lizakertjemadarhaza == 3:
        show madarhaza
    if hanyadiknapvan == 7:
        show lizatornazszonyeg
        show lizakertbentornazikanim:
            zoom 0.45
            xpos 0.45
            ypos 0.36
        if pulinapozoagyakesz == False:
            show nap7napozokeret
        if pulinapozoagyakesz == True:
            show nap7napozopuli

        if pulinapozoagya == 2:
            hide lizakertbentornazikanim
            show nap7f32:
                zoom 0.45
                xpos 0.45
                ypos 0.36
            if lizanvangeci == True:
                show nap7f3g2:
                    zoom 0.45
                    xpos 0.45
                    ypos 0.36
            jump lizaszex7nap

        if pulinapozoagya == 3:
            hide lizakertbentornazikanim
            show nap7f32:
                zoom 0.45
                xpos 0.45
                ypos 0.36
            if lizanvangeci == True:
                show nap7f3g2:
                    zoom 0.45
                    xpos 0.45
                    ypos 0.36
    if hanyadiknapvan >= 8:
        show lizatornazszonyeg
        if holvanliza == "tornazik":
            show lizakertbentornazikanim:
                zoom 0.45
                xpos 0.45
                ypos 0.36
        if mrpuliholvan == "napozoagy":
            show nap7napozopuli
            if pulilevanegve == True:
                show pulialszikleegett
        else:
            show nap7napozokeret
            show nap7napozovaszon


        if kenocspulinak == 0:
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s2
            u ""
            jump lizaketbenbeszed

    jump engedejek
$ renpy. pause(hard=True)
label lizakertjelevelekossze:
    hide screen invertori
    show screen invertori2
    hide screen lizakertje
    if gerebjenyel == 1:
        if gerebjefej == 1:
            $ lizakertjelevelek = 2
            play sound "audio/elvesz2.wav"
            show levelekossze:
                alpha 0.0
                linear 1.0 alpha 1.0
            show levelekszet:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            hide screen invertori2
            show screen invertori
            show screen lizakertje
            $ renpy. pause(hard=True)
    if gerebjekell == 0:
        $ gerebjekell = 1
    f "I do not want to pick them up one by one. It would take forever. I need a rake."
    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label lizakertjelevelekfel:
    hide screen invertori
    show screen invertori2
    hide screen lizakertje
    if lizaszemeteszakja >= 4:
        f "The rubbish bag is full, I have to empty the bag first."
    if lizaszemeteszakja < 4:
        $ lizakertjelevelek = 3
        show levelekossze:
            alpha 1.0
            linear 1.0 alpha 0.66
        show screen s1
        u ""
        $ lizaszemeteszakja += 1
        show levelekossze:
            alpha 0.66
            linear 1.0 alpha 0.33
        show screen s1
        u ""
        $ lizaszemeteszakja += 1
        show levelekossze:
            alpha 0.33
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        $ lizaszemeteszakja += 1
        $ lizakertjelevelekosszeszedve = True
    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label lizakertjemadarhaz:
    hide screen invertori
    show screen invertori2
    hide screen lizakertje
    if lizakertjemadarhaza == 1:
        if lizamadarhaza == 0:
            f "Something is missing."
    if lizakertjemadarhaza == 0:
        $ lizakertjemadarhaza = 1
        f "Something is missing."
    if lizakertjemadarhaza == 2:
        if csavar6resz == 0:
            f "The wind will blow the aviary away again. I should fix it to the column."
        if csavarhuzo6resz == 0:
            f "I need a screwdriver to put the screws in the right place."
        if csavar6resz == 1:
            if csavarhuzo6resz == 1:
                $ lizakertjemadarhazaahejen = True
                $ csavar6resz = 2
                $ lizamadarhaza = 3
                $ lizakertjemadarhaza = 3
                show madarhaza:
                    alpha 0.0
                    linear 1.0 alpha 1.0




    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label lizakertjedudva1:
    hide screen invertori
    show screen invertori2
    hide screen lizakertje
    if lizakertjekukaszsakotkaptal == False:
        f "I need a rubbish bag for this."
    if lizaszemeteszakja >= 4:
        f "The rubbish bag is full, I have to empty the bag first."
    if lizaszemeteszakja < 4:
        if lizakertjekukaszsakotkaptal == True:
            play sound "audio/elvesz.wav"
            $ lizaszemeteszakja += 1
            $ lizakertjedudva1 -= 1
            show kertidudva1:
                alpha 1.0
                linear 1.0 alpha 0.0
    if lizakertjedudva1 == 0:
        if lizakertjedudva2 == 0:
            if lizakertjedudva3 == 0:
                if lizakertjedudva4 == 0:
                    $ lizakertjedudvafelszedve = True
    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label lizakertjedudva2:
    hide screen invertori
    show screen invertori2
    hide screen lizakertje
    if lizakertjekukaszsakotkaptal == False:
        f "I need a rubbish bag for this."
    if lizaszemeteszakja >= 4:
        f "The rubbish bag is full, I have to empty the bag first."
    if lizaszemeteszakja < 4:
        if lizakertjekukaszsakotkaptal == True:
            play sound "audio/elvesz.wav"
            $ lizaszemeteszakja += 1
            $ lizakertjedudva2 -= 1
            show kertidudva2:
                alpha 1.0
                linear 1.0 alpha 0.0
            if lizakertjedudva1 == 0:
                if lizakertjedudva2 == 0:
                    if lizakertjedudva3 == 0:
                        if lizakertjedudva4 == 0:
                            $ lizakertjedudvafelszedve = True
    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label lizakertjedudva3:
    hide screen invertori
    show screen invertori2
    hide screen lizakertje
    if lizakertjekukaszsakotkaptal == False:
        f "I need a rubbish bag for this."
    if lizaszemeteszakja >= 4:
        f "The rubbish bag is full, I have to empty the bag first."
    if lizaszemeteszakja < 4:
        if lizakertjekukaszsakotkaptal == True:
            play sound "audio/elvesz.wav"
            $ lizaszemeteszakja += 1
            $ lizakertjedudva3 -= 1
            show kertidudva3:
                alpha 1.0
                linear 1.0 alpha 0.0
            if lizakertjedudva1 == 0:
                if lizakertjedudva2 == 0:
                    if lizakertjedudva3 == 0:
                        if lizakertjedudva4 == 0:
                            $ lizakertjedudvafelszedve = True
    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label lizakertjedudva4:
    hide screen invertori
    show screen invertori2
    hide screen lizakertje
    if lizakertjekukaszsakotkaptal == False:
        f "I need a rubbish bag for this."
    if lizaszemeteszakja >= 4:
        f "The rubbish bag is full, I have to empty the bag first."
    if lizaszemeteszakja < 4:
        if lizakertjekukaszsakotkaptal == True:
            play sound "audio/elvesz.wav"
            $ lizaszemeteszakja += 1
            $ lizakertjedudva4 -= 1
            show kertidudva4:
                alpha 1.0
                linear 1.0 alpha 0.0
            if lizakertjedudva1 == 0:
                if lizakertjedudva2 == 0:
                    if lizakertjedudva3 == 0:
                        if lizakertjedudva4 == 0:
                            $ lizakertjedudvafelszedve = True
    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label lizakertjeszemet1:
    if lizakertjekukaszsakotkaptal == False:
        f "I need a rubbish bag for this."
    if lizakertjekukaszsakotkaptal == True:
        if lizaszemeteszakja >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if lizaszemeteszakja < 4:
            queue sound "audio/felveszszemet.ogg"
            queue sound "audio/felveszszemet.ogg"
            hide screen invertori
            hide screen lizakertje
            show screen invertori2
            show screen szemetosszesed1
$ renpy. pause(hard=True)
label lizakertjeszemet2:
    if lizakertjekukaszsakotkaptal == False:
        f "I need a rubbish bag for this."
    if lizakertjekukaszsakotkaptal == True:
        if lizaszemeteszakja >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if lizaszemeteszakja < 4:
            queue sound "audio/felveszszemet.ogg"
            queue sound "audio/felveszszemet.ogg"
            hide screen invertori
            hide screen lizakertje
            show screen invertori2
            show screen szemetosszesed2
$ renpy. pause(hard=True)
label lizakertjeszemet3:
    if lizakertjekukaszsakotkaptal == False:
        f "I need a rubbish bag for this."
    if lizakertjekukaszsakotkaptal == True:
        if lizaszemeteszakja >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if lizaszemeteszakja < 4:
            queue sound "audio/felveszszemet.ogg"
            queue sound "audio/felveszszemet.ogg"
            hide screen invertori
            hide screen lizakertje
            show screen invertori2
            show screen szemetosszesed3
$ renpy. pause(hard=True)
label lizakertjeszemet4:
    if lizakertjekukaszsakotkaptal == False:
        f "I need a rubbish bag for this."
    if lizakertjekukaszsakotkaptal == True:
        if lizaszemeteszakja >= 4:
            f "The rubbish bag is full, I have to empty the bag first."
        if lizaszemeteszakja < 4:
            queue sound "audio/felveszszemet.ogg"
            queue sound "audio/felveszszemet.ogg"
            hide screen invertori
            hide screen lizakertje
            show screen invertori2
            show screen szemetosszesed4
$ renpy. pause(hard=True)
label lizakertjeszemet1fel:
    show kertiszemet1:
        alpha 1.0
        linear 1.0 alpha 0.0
    if lizakertjeszemet1 == 0:
        if lizakertjeszemet2 == 0:
            if lizakertjeszemet3 == 0:
                if lizakertjeszemet4 == 0:
                    $ lizakertjeszemetosszeszedve = True
$ renpy. pause(hard=True)
label lizakertjeszemet2fel:
    show kertiszemet2:
        alpha 1.0
        linear 1.0 alpha 0.0
    if lizakertjeszemet1 == 0:
        if lizakertjeszemet2 == 0:
            if lizakertjeszemet3 == 0:
                if lizakertjeszemet4 == 0:
                    $ lizakertjeszemetosszeszedve = True
$ renpy. pause(hard=True)
label lizakertjeszemet3fel:
    show kertiszemet3:
        alpha 1.0
        linear 1.0 alpha 0.0
    if lizakertjeszemet1 == 0:
        if lizakertjeszemet2 == 0:
            if lizakertjeszemet3 == 0:
                if lizakertjeszemet4 == 0:
                    $ lizakertjeszemetosszeszedve = True
$ renpy. pause(hard=True)
label lizakertjeszemet4fel:
    show kertiszemet4:
        alpha 1.0
        linear 1.0 alpha 0.0
    if lizakertjeszemet1 == 0:
        if lizakertjeszemet2 == 0:
            if lizakertjeszemet3 == 0:
                if lizakertjeszemet4 == 0:
                    $ lizakertjeszemetosszeszedve = True
$ renpy. pause(hard=True)
label lizaketbenbeszed:
    hide screen invertori
    hide screen invertori2
    hide screen lizakertje
    hide invertori onlayer elotte6
    hide lizatornazbeszedalap
    hide lizakertbentornazik1080anim
    hide fred6reszk5
    show lizatornazbeszedalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizakertbentornazik1080anim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fred6reszk5:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    if hanyadiknapvan == 6:
        if gerebjekell == 1:
            if lizakertjekerdeztezlevelek == False:
                $ lizakertjekerdeztezlevelek = True
                f "Do you have a rake?"
                l "I do not have any. You should find some yourself."
                f "Ok, I will solve this problem."
        if lizakertjekukaszsakotkersz == False:
            $ lizakertjekukaszsakotkersz = True
            f "Do you have any kind of bag which I can use to put the trash in?"
            l "Of course I have. Wait here! I will bring it to you in no time."
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 0.0
                linear 1.0 alpha 1.0
            pause 1.0
            $ lizakertjekukaszsakotkaptal = True
            hide fekete onlayer screens
            show fekete onlayer screens:
                alpha 1.0
                linear 1.0 alpha 0.0
            pause 1.0
            l "You can throw the trash in the dustbin when the garbage bag fills up. You find the green dustbin before my home."
            f "Alright."
        if lizakertjemadarhaza >= 1:
            if lizakertjemadarhaza < 3:
                if lizakertjekerdeztezmadarhaz == False:
                    $ lizakertjekerdeztezmadarhaz = True
                    f "I saw a small column. Is something missing from the top?"
                    l "Yeah, the aviary is missing. The wind took the aviary somewhere. You should search for it and put it in the right place Honey!"
        if lizakertjemadarhaza == 2:
            if lizakertjekerdeztezcsavarok == False:

                $ lizakertjekerdeztezcsavarok = True
                if csavar6resz == 0:
                    if csavarhuzo6resz == 0:
                        f "Do you have screws and screwdrivers?"
                if csavar6resz == 1:
                    if csavarhuzo6resz == 0:
                        f "Do you have a screwdriver?"
                if csavar6resz == 1:
                    if csavarhuzo6resz == 0:
                        f "Do you have any screws?"
                l "I am sorry Honey. I have only some perfumes and lipsticks. The workers usually bring their tools to repair my stuff."
                f "Ok, understood."
        if lizakertjedudvafelszedve == True:
            if lizakertjeszemetosszeszedve == True:
                if lizakertjelevelekosszeszedve == True:
                    if lizakertjemadarhazaahejen == True:
                        $ lizakertjekesz = 1
                        pause 2.0
                        l "I see you finished already."
                        f "Is there anything else I can do for you?"
                        l "I should pay you for the hard work. What do you wish for a payment?"
                        show lizacicikozelrolnez6resz:
                            alpha 0.0
                            linear 1.0 alpha 1.0
                        f "I have some idease…"
    if hanyadiknapvan == 7:
        if pulinapozoagya == 0:
            $ pulinapozoagya = 1
            f "Hy Liza!"
            l "Hy Fred! I missed you!"
            f "Strange… Noone missed me before…"
            l "I have a problem…"
            f "Can I help you?"
            l "Yeah. My husband brought a sunbed yesterday and the sunbed misses some parts as you can notice."
            l "Be kind Honey and fix it before he notices!"
            f "Ok, I will try my best!"
            l "Thank you! I will be thankful. I will pay you after you fixed the sunbed Honey."
            jump lizaketbenbeszedvege
        if pulinapozoagya == 1:
            l "Leave me alone! I need to do gymnastics."
            f "I would like to watch you."
            l "Oh, fine!"
        if pulinapozoagya == 2:
            f "I fixed the sunbed. You promised me a nice „Thank you”…"
            l "Oh well... Did I?..."
            f "Yeah, but we can not do it here…"
            l "Why not? It would be really exciting.Don’t you think? My husband fell asleep…"
            f "What if he wakes up?"
            l "What if he won’t wake up?"
    if hanyadiknapvan == 8:
        if kenocspulinak == 0:
            $ kenocspulinak = 1
            $ fekete = True
            $ kerdezkorbe8resz = True
            show screen s1
            u ""
            l "I have been waiting for you!"
            f "What is the problem?"
            l "My husband fell asleep yesterday and the sun burned his body. He can not move and he has terrible pains."
            l "I tried all the ointments I found but nothing helped. These creams are useless! He can not move at all!"
            f "Understood, but how can I help you? Go to a pharmacy and buy some kind of medicine!"
            l "I have no money to buy medicine. I did not work yesterday and I spent all my money. Today I have some work, but I can not let my husband lie down here for 2 days."
            f "What can I help you with?"
            l "We can not lift him, it would hurt him a lot. You should find some home made recipes to heal the sunburn."
            f "SoI have to find a homemade recipe against the sunburn. Fine."
            l "Oh Thank you Fred! I will be thankful forever!"
            jump lizaketbenbeszedvege
        if receptnalad == 1:
            if lizaviragnalad == 0:
                $ lizanakmegmutatadareceptet = True
                $ holvanliza = "parktonal"
                f "I found a working recipe, but I cannot read it."
                l "Let me see!"
                f "Here it is! Look! Can you read it?"
                l " Of course! The handwriting of my mother looks much worse! I can read this easily!"
                l "It says: „Recipe against sunburn.Egg ,Dry yeast,Orange juice,Tulip,Hyacinth,White palmack flower,Mushroom,Spider,Put the ingredients in a bowl and crumble them until you can apply the cream easily..."
                l "We only have chocolet and soy-beans at home, but I saw the white flower in the park shomewhere…"
                l "It is a beautiful flower and it likes water and sunny places."
                f "Nice, but I don't really know anything about flowers…"
                l "Do not worry, I will find you some. I will go to the park."
                f "I have some work to do in the park as well.Let us meet there a bit later!"
                hide lizakertbentornazikanim
                jump lizaketbenbeszedvege
            if lizaviragnalad == 1:
                l "Could you prepare the cream?"
                f "Not yet, I am searching for the ingredients."
                l "Ok, but hurry! I have to practice now. I will have a job tonight…"
                f "I will try my best!"
                jump lizaketbenbeszedvege
    if hanyadiknapvan == 10:
        if kerjmunkatkerhec == True:
            if ladatmegtalalhatod == 0:
                l "Did you miss me?"
                f "It is always a pleasure to see you Liza. You look great!"
                f "Do you have any work for me to do? I need money urgently."
                l "Did you spend the money I gave you last time?"
                f "Well... Yeah. I had to."
                l "I have no work for you now. I know your phone number. I will call you if I need anything. Let us meet a bit later! I have something for you…"
                show lizacicikozelrolnez6resz onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s2
                u ""
                hide lizakertbentornazik1080anim
                hide nap7f3
                show nap7f3
                hide fred6reszk5
                show fred6reszk5
                f "What is it? Let me guess!"
                l "I know, but I need to do my daily routine now. I will call you soon..."
                show lizacicikozelrolnez6resz onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s2
                u ""
                f "Ok. Now I have to go. Call me please!"
                show nap7f3:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show lizakertbentornazik1080anim:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                hide fred6reszk5
                show fred6reszk5
                l "Sure! Kisss! Kisss!"
                show screen lizabeszed
                $ renpy. pause(hard=True)
    if hanyadiknapvan == 12:
        if lizafehiv12nap == True:
            if sujzonalad == 0:
                $ lizafehiv12napesbeszeltelvele = True
                $ lakotombaterkepen = True
                $ ciliholvan = "cilinapaliaban"
                f "I am here. Why do you need me?"
                l "You should bring some stuff to Cili. I have to go to work in a few minutes."
                f "Where are those things?"
                l "The dumbbells are in the living room. Do not worry, you do not have to carry them too far."
                l "The Address is MariaCity Wolf Street 25/A."
                f "I am sorry, but I do not have money for a taxi and I do not know where Wolf Street is."
                l "No problem. Look on the right."
                f "You can see a big residential block behind the bushes. "
                l "You have to carry the dumbbells just there.Floor 5."
                f "Which apartment belongs to Cili on the 5. floor?"
                l "The 5. floor is her own"
                f "She must be rich."
                l "Yes, she is. She can buy anything she wants."
                f "Ok. I have to go now."
                l "Byebye!"
                show screen lizabeszed
                $ renpy. pause(hard=True)



    if hanyadiknapvan >= 9:
        l "Leave me alone! I need to do gymnastics."
        f "I would like to watch you."
        l "Oh, fine!"

    show screen lizabeszed
$ renpy. pause(hard=True)
label lizaketbenbeszedvege:
    show lizatornazbeszedalap:
        alpha 1.0
        linear 1.0 alpha 0.0
    show lizakertbentornazik1080anim:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fred6reszk5:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show invertori onlayer elotte6:
        yalign 0.0
    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label lizaketbenbeszedvege2:
    if hanyadiknapvan == 6:
        hide screen lizabeszed
        hide screen lizabeszed2
        mr "{size=-10}Liza! Where are you Dear? I can not see you!"
        if lizatudbeszelni == True:
            hide lizafogdosas5reszszaj5
            show lizafogdosas5reszszajanim:
                xzoom -1.0
            l "This is my husband. You should stop for now."
            show lizafogdosas5reszszaj5:
                xzoom -1.0
            hide lizafogdosas5reszszajanim
        if lizatudbeszelni == False:
            l "This is my husband. You should stop for now."
        f "I should go now…"
        if lizatudbeszelni == True:
            hide lizafogdosas5reszszaj5
            show lizafogdosas5reszszajanim:
                xzoom -1.0
            l "{size=+10}I have my workout time in the garden!!!"
            show lizafogdosas5reszszaj5:
                xzoom -1.0
            hide lizafogdosas5reszszajanim
        if lizatudbeszelni == False:
            l "{size=+10}I have my workout time in the garden!!!"
        mr "{size=-10}I am coming Dear!"
        jump megzavarnak6resz
    if hanyadiknapvan == 7:
        f "nem gondolom hogy jó otlet lenne nem merem itt meg tenni."
        jump lizaketbenbeszedvege
$ renpy. pause(hard=True)
label lizaketbenbeszedvege3:
    hide screen invertori
    hide screen invertori2
    hide screen lizakertje
    hide invertori onlayer elotte6
    show lizakertbentornazikanim:
        zoom 0.45
        xpos 0.45
        ypos 0.36
        alpha 1.0
        linear 1.0 alpha 0.0
    show lizapoz1540:
        zoom 1.1
        xpos 0.4
        ypos 0.18
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    mr "{size=-10}Liza! Where are you Dear? I can not see you!"
    l "This is my husband. You should stop for now."
    f "Ok, I should go now…"
    l "{size=+10}I have my workout time in the garden!!!"
    mr "{size=-10}I am coming Dear!"
    show mrpuli540:
        zoom 0.9
        xpos 0.32
        ypos 0.25
        alpha 0.0
        linear 1.0 alpha 1.0
    jump megzavarnak6resz2
$ renpy. pause(hard=True)
label lizaketbenfogdos:
    $ lizatudbeszelni = True
    hide lizaarcahozkozelpeni6reszv2hat
    show lizaarcahozkozelpeni6reszv2hat:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizafogdosas5reszalap:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizafogdosas5reszanim:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizafogdosas5reszszemanim:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizafogdosas5reszszaj5:
        xzoom -1.0
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    u ""
    hide lizafogdosas5reszszaj5
    show lizafogdosas5reszszajanim:
        xzoom -1.0
    l "This is a nice thought. Let us think a bit more…"
    show lizafogdosas5reszszaj5:
        xzoom -1.0
    hide lizafogdosas5reszszajanim
    if hanyadiknapvan == 6:
        show screen lizabeszed2
    if hanyadiknapvan == 7:
        jump lizaketbenfogdos2
$ renpy. pause(hard=True)
label lizaketbenfogdos2:
    hide screen lizabeszed2
    hide lizacicikozelrolnez6reszv2hat
    show lizacicikozelrolnez6reszv2hat:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizacicikozelrolnez6reszv2alap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizacicikozelrolnez6reszv2ciciszopanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizacicikozelrolnez6reszv2cicifoganim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizacicikozelrolnez6reszv2szaj1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizacicikozelrolnez6reszv2ele:
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    u ""
    if hanyadiknapvan == 6:
        mr "{size=-10}Liza! Where are you Dear? I can not see you!"
        hide lizacicikozelrolnez6reszv2szaj1
        show lizacicikozelrolnez6reszv2szajanim
        l "This is my husband. You should stop for now."
        hide lizacicikozelrolnez6reszv2szajanim
        show lizacicikozelrolnez6reszv2szaj1
        f "Hmmmm…."
        hide lizacicikozelrolnez6reszv2szaj1
        show lizacicikozelrolnez6reszv2szajanim
        l "{size=+10}I have my workout time in the garden!!!"
        hide lizacicikozelrolnez6reszv2szajanim
        show lizacicikozelrolnez6reszv2szaj1
        mr "{size=-10}I am coming Dear!"
        jump megzavarnak6resz
    if hanyadiknapvan == 7:
        show screen s2
        u ""
        jump lizaketbenszopat
$ renpy. pause(hard=True)
label lizaketbenszopat:
    hide lizaarcahozkozelpeni6resz
    show lizaarcahozkozelpeni6resz:
        alpha 0.0
        linear 1.0 alpha 1.0
    u ""
    l "I like the way you think Honey…"
    hide lizaarcahozkozelpeni6reszv2hat
    show lizaarcahozkozelpeni6reszv2hat:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaarcahozkozelpeni6reszv2alap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaarcahozkozelpeni6reszv2mozanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    u ""
    if hanyadiknapvan == 6:
        mr "{size=-10}Liza! Where are you Dear? I can not see you!"
        show lizaarcahozkozelpeni6reszv2hat:
            alpha 1.0
            linear 1.0 alpha 0.0
        show lizaarcahozkozelpeni6reszv2alap:
            alpha 1.0
            linear 1.0 alpha 0.0
        show lizaarcahozkozelpeni6reszv2mozanim:
            alpha 1.0
            linear 1.0 alpha 0.0
        pause 1.5
        l "This is my husband. You should stop for now."
        f "I should go now… really…"
        l "{size=+10}I have my workout time in the garden!!!"
        mr "{size=-10}I am coming Dear!"
        jump megzavarnak6resz
    if hanyadiknapvan == 7:
        show lizaszexjelenet7nappulival:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        l "And now fuck my boobs!"
        f "We should not do this. Your husband can wake up any minute!"
        l "I do not think so. He is sleeping like a baby!"
        show nap7f1alap:
            alpha 0.0
            linear 1.0 alpha 1.0
        show lizacicibasz7reszszembanim:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7f1szaj1:
            alpha 0.0
            linear 1.0 alpha 1.0
        show lizacicibasz7reszaanim:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s2
        u ""
        hide lizaszexjelenet7nappulival
        hide lizakertbentornazik1080anim
        hide lizakertbentornazikanim
        hide lizaarcahozkozelpeni6reszv2hat
        hide lizafogdosas5reszalap
        hide lizafogdosas5reszanim
        hide lizafogdosas5reszszemanim
        hide lizafogdosas5reszszaj5
        hide lizafogdosas5reszszajanim
        hide lizafogdosas5reszszaj5
        hide lizacicikozelrolnez6reszv2hat
        hide lizacicikozelrolnez6reszv2alap
        hide lizacicikozelrolnez6reszv2ciciszopanim
        hide lizacicikozelrolnez6reszv2cicifoganim
        hide lizacicikozelrolnez6reszv2szaj1
        hide lizacicikozelrolnez6reszv2ele
        hide lizaarcahozkozelpeni6resz
        hide lizaarcahozkozelpeni6reszv2hat
        hide lizaarcahozkozelpeni6reszv2alap
        hide lizaarcahozkozelpeni6reszv2mozanim
        hide pilango6reszanim
        hide pilango6reszanim2
        hide pilango6reszanim3
        hide pilango6reszanim4
        hide pilango6reszanim5
        hide pilangoszal6reszanim6
        hide pilangoszal6reszanim
        hide pilangoszal6reszanim2
        hide pilangoszal6reszanim3
        hide pilangoszal6reszanim4
        hide pilangoszal6reszanim5
        hide lizatornazbeszedalap
        hide fred6reszk5
        hide nap7napozopuli
        hide nap7napozokozeli
        hide lizaarcahozkozelpeni6reszv2hat
        hide mrpulipoz
        hide fiupoz1
        hide lizakertje
        hide madarhaza
        hide lizatornazszonyeg
        hide nap7f1szaj1
        show lizacicibasz7reszszajanim
        l "This is so exciting? Isn’t it?"
        show nap7f1szaj1
        hide lizacicibasz7reszszajanim
        f "Oh yeah and you have really big boobs…"
        hide lizacicibasz7reszszembanim
        show lizacicibasz7reszszembroljanim:
            pause 3.25
            alpha 0.0
        show lizacicibasz7reszszemjanim:
            alpha 0.0
            pause 3.25
            alpha 1.0
        hide lizacicibasz7reszaanim
        show lizacicibasz7reszanim
        show screen s3
        u ""
        hide nap7f1szaj1
        show lizacicibasz7reszszajanim
        l "Stop talking like this! You will embarrass me..."
        show nap7f1szaj1
        hide lizacicibasz7reszszajanim
        f "I get horny from you..."
        lg "I hope I can get his services this way cheaper."
        hide lizacicibasz7reszszemjanim
        show lizacicibasz7reszszemjrolbanim:
            pause 3.25
            alpha 0.0
        show lizacicibasz7reszszembanim:
            alpha 0.0
            pause 3.25
            alpha 1.0
        show screen s3
        u ""
        hide nap7f1szaj1
        show lizacicibasz7reszszajanim
        l "Oh you pervert! I love the way you talk…"
        show nap7f1szaj1
        hide lizacicibasz7reszszajanim
        hide lizacicibasz7reszanim
        show lizacicibasz7reszbanim
        f "I am almost cumming..."
        hide lizacicibasz7reszszembanim
        hide lizacicibasz7reszszembroljanim
        show lizacicibasz7reszszembroljanim:
            pause 3.25
            alpha 0.0
        show lizacicibasz7reszszemjanim2:
            alpha 0.0
            pause 3.25
            alpha 1.0
        show screen s5
        u ""
        hide nap7f1szaj1
        show lizacicibasz7reszszajanim
        l "Oh yeah, do it fast before my husband wakes up!"
        show nap7f1szaj4
        hide lizacicibasz7reszszajanim
        show screen s2
        u ""
        hide lizacicibasz7reszszemjanim2
        show lizacicibasz7reszszemjanim3
        hide lizacicibasz7reszbanim
        show lizacicibasz7reszbanimv2
        hide nap7f1szaj4
        show lizacicibasz7reszszajanim
        l "Pull out and cum on me!"
        show nap7f1szaj4
        hide lizacicibasz7reszszajanim
        hide nap7f1alap
        hide lizacicibasz7reszszembanim
        hide nap7f1szaj1
        hide lizacicibasz7reszanim
        hide lizacicibasz7reszszajanim
        hide lizacicibasz7reszszembroljanim
        hide lizacicibasz7reszszemjanim
        hide lizacicibasz7reszszajanim
        hide lizacicibasz7reszszajanim
        hide lizacicibasz7reszszemjanim2
        hide nap7f1szaj4
        hide lizacicibasz7reszbanim
        show lizacicibaszpan7reszanim:
            ypos -1.19
            pause 0.352
            linear 3.192 ypos 0.0
        show lizacicibaszpangeci7reszanim:
            ypos -1.19
            pause 0.352
            linear 3.192 ypos 0.0
        show screen s3
        u ""
        jump lizakertjeszov
label lizaszex7nap:
    hide screen lizabeszed
    if pulinapozoagya == 3:
        hide screen lizakertje
        hide screen invertori
        hide screen invertori2
        hide invertori onlayer elotte6
        show lizatornazbeszedalap:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7f3:
            alpha 0.0
            linear 1.0 alpha 1.0
        show nap7f3g:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fred6reszk5:
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 2.0
        if kiskendofurdoben == False:
            $ kiskendolizanal = True
            $ pulinapozoagya = 4
            show nap7f3g:
                alpha 1.0
                linear 1.0 alpha 0.0
            l "Thank You Fred. I can continue the workout now."
            show lizakertbentornazikanim:
                zoom 0.45
                xpos 0.45
                ypos 0.36
            hide lizatornazbeszedalap
            hide nap7f32
            hide nap7f3g2
            show lizatornazbeszedalap
            show nap7f3:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lizakertbentornazik1080anim:
                alpha 0.0
                linear 1.0 alpha 1.0
            hide fred6reszk5
            show fred6reszk5
            pause 1.0
            l "Oh, I almost forgot. Here you are!Here is your payment."
            $ penz += 3200
            $ penztkaszlizatol7resz = True
            f "Thank you! I need this."
            l "Do not spend your money on crazy things!"
            f "I will do my best!"
            f "I have to go now. Goodbye!"
            jump lizaketbenbeszedvege
    if pulinapozoagya == 2:
        show lizatornazbeszedalap
        show nap7f3
        show nap7f3g
        show fred6reszk5
        pause 2.0
        l "Oh my! You made me all dirty. Bring me a towel! I can not enter the house like that. I would make everything dirty… The towel is in the bathroom."
        f "Ok, I will be right back! I hope Mr. Puli won’t wake up..."
        l "I wait for you Honey…"
        $ pulinapozoagya = 3
        jump lizaketbenbeszedvege4


    l "Do not play around, bring me the towel!"
    f "Ok... Ok!"
    show screen lizabeszed
$ renpy. pause(hard=True)
label lizaketbenbeszedvege4:
    show lizatornazbeszedalap:
        alpha 1.0
        linear 1.0 alpha 0.0
    show nap7f3:
        alpha 1.0
        linear 1.0 alpha 0.0
    if lizanvangeci == True:
        show nap7f3g:
            alpha 1.0
            linear 1.0 alpha 0.0
    show fred6reszk5:
        alpha 1.0
        linear 1.0 alpha 0.0
    pause 1.0
    show invertori onlayer elotte6:
        yalign 0.0
    hide screen invertori2
    show screen invertori
    show screen lizakertje
$ renpy. pause(hard=True)
label megzavarnak6resz:
    hide lizakertje
    hide lizatornazszonyeg
    hide lizakertbentornazikanim
    hide kertigomba
    hide madarhaza
    show lizakertje:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizatornazszonyeg:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizapoz1540:
        zoom 1.1
        xpos 0.4
        ypos 0.18
        alpha 0.0
        linear 1.0 alpha 1.0
    show mrpuli540:
        zoom 0.9
        xpos 0.32
        ypos 0.25
        alpha 0.0
        linear 1.0 alpha 1.0
    show kertigomba:
        alpha 0.0
        linear 1.0 alpha 1.0
    show madarhaza:
        alpha 0.0
        linear 1.0 alpha 1.0
label megzavarnak6resz2:
    $ lizakertjekesz = 2
    pause 2.0
    hide lizaarcahozkozelpeni6reszv2hat
    show lizaarcahozkozelpeni6reszv2hat:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mrpulipoz:
        alpha 0.0
        linear 1.0 alpha 1.0
    show anikamom:
        xpos 0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    mr "The backyard is a mess! Why are you practicing here?"
    l "The backyard is no longer amess. Fred cleaned the garden."
    mr "Who is Fred?"
    f "I am."
    mr "Whoaaa! Who the hell was that? Boy! I did not see you. You scared me."
    l "My husband is almost blind you know. "
    f "Now I understand. Sorry Mr. Puli!"
    l "The Doctors say there is no hope to cure him. He is almost blind from his childhood."
    mr "Yeah, I am almost blind, but I have some positive virtues. I am clever and have a nice muscular bodytype…"
    mr "Liza! Did he clean the whole garden?"
    l "Yeah Honey! I wanted to pay him just now. I should go to my room to pick up the money…"
    mr "Do not waste your time Dear! I spent all of your money. I bought a super sunbed. The guys helped me and took the money from the wallet. I could only pay for the bed. No money left."
    l "Alright… Fred! Can you come back tomorrow for the money?"
    f "Sure. I wanted to leave anyway… Goodbye!"
    p "Where are you? I can not see you!"
    $ invertorinejelenyenmeg = True
    jump baloldaliszomszed
$ renpy. pause(hard=True)
label pulinapozoagya:
    hide screen lizakertje
    hide screen invertori
    show screen invertori2
    if hanyadiknapvan == 7:
        if pulinapozoagya == 1:
            if tu == 1:
                if vaszon1 == 1:
                    if vaszon2 == 1:
                        if cerna == 1:
                            $ tu = 2
                            $ vaszon1 = 2
                            $ vaszon2 = 2
                            $ cerna = 2
                            show mrpuli540:
                                zoom 0.9
                                xpos 0.32
                                ypos 0.25
                                alpha 0.0
                                pause 5.0
                                linear 1.0 alpha 1.0
                            hide screen lizakertje
                            show nap7napozovaszon:
                                alpha 0.0
                                linear 20.0 alpha 1.0
                            show screen napozoagy
                            show screen s6
                            u ""
                            mr "Liza! Did Fred fix the sunbed?"
                            l "The sunbed is almost ready. Fred fixes it for you..."
                            $ renpy. pause(hard=True)
        if tu == 1:
            if cerna == 1:
                if vaszon1 == 1:
                    $ adrianahazaakarmenni = True
                    f "I have not enough canvas to fix the sunbed.I need to find more material."
        if tu == 0:
            f "I need something to fix the canvas. I could maybe sew."
        if cerna == 0:
            f "I need some kind of thread to fix the canvas to the basics."
        if vaszon1 == 0:
            f "I need some kind of canvas to place it on the sunbed base."
        if pulinapozoagya >= 2:
            f "It seems he fell asleep…"
    if hanyadiknapvan == 8:
        if pulilevanegve == True:
            f "Mr. Puli burned…"
            mr "Help me my son! Hurry! I can not move! Now I understand how the tinsmith felt…"
            f "I will try my best!"
        if pulilevanegve == False:
            f "It seems he fell asleep…"
    if hanyadiknapvan >= 9:
        f "Mr Puli! Take car eof yourself or you will burn again."
        mr "Why? I just came a few minutes ago to sunbath.."
        f "You came here in the morning, long hours ago."
        mr "Who cares!"
        f "As you wish."


    show screen lizakertje
    hide screen invertori2
    show screen invertori
$ renpy. pause(hard=True)
label pulinapozojakesz:
    show lizaarcahozkozelpeni6reszv2hat:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mrpulipoz:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show nap7napozokozeli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    f "Now it is ready to use."
    mr "Thank You Fred. I will take the sunbed in use now. Liza will pay you."
    hide lizaarcahozkozelpeni6reszv2hat
    hide mrpuli540
    hide mrpulipoz
    hide fiupoz1
    hide nap7napozokeret
    hide nap7napozovaszon
    show nap7napozopuli
    show nap7napozokozeli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show lizaarcahozkozelpeni6reszv2hat:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mrpulipoz:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    jump lizaketbenbeszed
$ renpy. pause(hard=True)
label pulinapegeseelmulik:
    hide screen lizakertje
    $ pulilevanegve = False
    show pulialszikleegett:
        alpha 1.0
        linear 5.0 alpha 0.0
    $ mozsarnalad = 2
    show screen s5
    f "Alright. You will feel better in no time Mr. Puli…"
    hide screen invertori
    hide screen invertori2
    hide invertori onlayer elotte6
    hide nap7napozopuli

    show nap7napozokeret
    show nap7napozovaszon
    show nap7napozopuli:
        alpha 1.0
        linear 1.0 alpha 0.0
    show lizakertbentornazikanim:
        zoom 0.45
        xpos 0.45
        ypos 0.36
        alpha 1.0
        linear 1.0 alpha 0.0
    show lizapoz1540:
        zoom 1.1
        xpos 0.4
        ypos 0.18
        alpha 0.0
        linear 1.0 alpha 1.0
    show mrpuli540:
        zoom 0.9
        xpos 0.32
        ypos 0.25
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    hide lizaarcahozkozelpeni6reszv2hat
    show lizaarcahozkozelpeni6reszv2hat:
        alpha 0.0
        linear 1.0 alpha 1.0
    show mrpulipoz:
        alpha 0.0
        linear 1.0 alpha 1.0
    show anikamom:
        xpos 0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 2.0
    mr "This cream works! I feel reborn! I can move again! Thank you!"
    f "I am happy! I searched a lot for the ingredients..."
    l "I found the white flower Honey! Do not forget to thank me for it!"
    mr "Oh I thank you Dear! I am so thankful! You were on my side all time long… I love you!"
    mr "But now, let us lie down again! I need to sample more Vitamin D..."
    l "Ok Honey! I will pay for the help…"
    show lizaarcahozkozelpeni6reszv2hat:
        alpha 1.0
        linear 1.0 alpha 0.0
    show mrpulipoz:
        alpha 1.0
        linear 1.0 alpha 0.0
    show anikamom:
        xpos 0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s2
    u ""
    show nap7napozopuli:
        alpha 0.0
        linear 1.0 alpha 1.0
    show nap7f32:
        zoom 0.45
        xpos 0.45
        ypos 0.36
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizapoz1540:
        zoom 1.1
        xpos 0.4
        ypos 0.18
        alpha 1.0
        linear 1.0 alpha 0.0
    show mrpuli540:
        zoom 0.9
        xpos 0.32
        ypos 0.25
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide nap7napozokeret
    hide nap7napozovaszon
    show screen s1
    u ""
    hide lizatornazbeszedalap
    hide nap7f3
    hide fred6reszk5
    show lizatornazbeszedalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show nap7f3:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fred6reszk5:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    l "{size=-10}Fred! My husband has not fallen asleep yet. Let us whisper."
    l "{size=-10}Last time you told me about your wishes, now I want to ask you something to do…"
    f "{size=-10}Ok... What is it?"
    show lizaszexresz8jel0:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaszexresz8jel0szaj1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaszexresz8jel0szemanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide lizaszexresz8jel0szaj1
    show lizaszexresz8jel0szajanim
    l "{size=-10}What do you think? I'll let you guess…"
    show lizaszexresz8jel0szaj1
    hide lizaszexresz8jel0szajanim
    f "{size=-10}I have some… ideas…"
    show lizaszexresz8jel1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaszexresz8jel1segganim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaszexresz8jel1szaj1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide lizaszexresz8jel1szaj1
    show lizaszexresz8jel1szajanim
    l "{size=-10} You are on the right way…"
    l "{size=-10} Before we continue I have a question. Are you horny?"
    show lizaszexresz8jel1szaj1
    hide lizaszexresz8jel1szajanim
    f "{size=-10}You made me horny. I am hard as a rock.Let me put in my penis a bit!"
    show screen s1
    u ""
    u ""
    show lizaszexresz8jel2megjeleno:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""

    show lizaszexresz8jel2
    show lizaszexresz8jel2lizafejeanim
    show lizaszexresz8jel2lizafejemoz5szajanim
    show lizaszexresz8jel2lizafejeelotalap onlayer hatso
    show lizaszexresz8jel2lizafaszanim onlayer hatso
    show lizaszexresz8jel2mindenfole onlayer hatso
    l "{size=-10}Do not insert your penis so suddenly! Rub my pussy with the tip a bit Honey! Make my hole horny!"
    hide lizaszexresz8jel2lizafejemoz5szajanim
    show screen s1
    u ""
    hide lizaszexresz8jel2lizafejeanim
    show lizaszexresz8jel2lizafejeanimv2
    show screen s4
    u ""
    show lizaszexresz8jel2lizafejemoz1szajanim
    l "{size=-10}Oh nice… Please continue!"
    hide lizaszexresz8jel2lizafejemoz1szajanim
    show screen s1
    u ""
    hide lizaszexresz8jel2lizafejeanimv2
    show lizaszexresz8jel2lizafejeanim
    show screen s4
    u ""
    hide lizaszexresz8jel2lizafejeanim
    show lizaszexresz8jel2lizafejeanimv2
    show screen s1
    u ""
    show lizaszexresz8jel2lizafejemoz1szajanim
    l "{size=-10}I am getting wet…"
    hide lizaszexresz8jel2lizafejemoz1szajanim
    show screen s1
    u ""
    hide lizaszexresz8jel2lizafejeanimv2
    show lizaszexresz8jel2lizafejeanim
    show screen s4
    u ""
    hide lizaszexresz8jel2lizafejeanim
    show lizaszexresz8jel2lizafejeanimv2
    show screen s1
    u ""
    show lizaszexresz8jel2lizafejemoz1szajanim
    l "{size=-10}Your penis feels good! Make me wet!"
    hide lizaszexresz8jel2lizafejemoz1szajanim
    show screen s1
    u ""
    hide lizaszexresz8jel2lizafejeanimv2
    show lizaszexresz8jel2lizafejeanim
    show screen s4
    u ""
    hide lizaszexresz8jel2lizafejeanim
    show lizaszexresz8jel2lizafejeanimv2
    show screen s1
    u ""
    show lizaszexresz8jel2lizafejemoz1szajanim
    l "{size=-10}I want it inside. The feeling gets stronger and stronger…"
    hide lizaszexresz8jel2lizafejemoz1szajanim
    show screen s1
    u ""
    hide lizaszexresz8jel2lizafejeanimv2
    show lizaszexresz8jel2lizafejeanim
    show screen s4
    u ""
    show lizaszexresz8jel2lizafejemoz5szajanim
    l "{size=-10}I can not take it any longer! Put in! Put your penis in my dirty hole!"
    hide lizaszexresz8jel2lizafejeanim
    show lizaszexresz8jel2lizafejeanimfojamatos
    hide pilango6reszanim
    hide pilango6reszanim2
    hide pilango6reszanim3
    hide pilango6reszanim4
    hide pilango6reszanim5
    hide pilangoszal6reszanim6
    hide pilangoszal6reszanim
    hide pilangoszal6reszanim2
    hide pilangoszal6reszanim3
    hide pilangoszal6reszanim4
    hide pilangoszal6reszanim5
    hide lizaszexresz8jel1
    hide lizaszexresz8jel1segganim
    hide lizaszexresz8jel1szaj1
    hide lizaszexresz8jel2megjeleno
    hide lizatornazbeszedalap
    hide nap7f3
    hide lizakertje
    hide nap7f32
    hide lizatornazszonyeg
    hide nap7napozopuli
    hide fred6reszk5
    hide madarhaza
    hide lizaszexresz8jel0
    hide lizaszexresz8jel0szaj1
    hide lizaszexresz8jel0szemanim
    hide lizaszexresz8jel2lizafejemoz5szajanim
    hide lizaszexresz8jel2lizafejeelotalap onlayer hatso
    hide lizaszexresz8jel2lizafaszanim onlayer hatso
    hide lizaszexresz8jel2mindenfole onlayer hatso
    show lizaszexresz8jel2lizafejeelotalap
    show lizaszexresz8jel2lizafaszanim

    u ""
    show lizaszexresz8jel3:
        alpha 0.0
        linear 1.0 alpha 1.0
    u ""
    show lizaszexresz8jel4megjelenik:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide lizaszexresz8jel4megjelenik
    show lizaszexresz8jel4alap
    show lizaszexresz8jel4anim
    show lizaszexresz8jel4pulimoz1 onlayer hatso
    $ vigyazgombholvan = renpy.random.choice(['1', '2', '3' ])
    show screen vigyazliza8resz
    show screen s5
    u ""
    show screen s5
    u ""
    show screen s5
    u ""
    show lizaszexresz8jel4pulianim onlayer hatso
    hide lizaszexresz8jel4pulimoz1 onlayer hatso
    play sound "audio/hatranez.wav"
$ renpy. pause(hard=True)
label lizaszexjel8reszfojtatt:
    show lizaszexresz8jel5alapmegjelenik onlayer hatso:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    hide lizaszexresz8jel4alap
    hide lizaszexresz8jel4anim
    hide lizaszexresz8jel4pulianim onlayer hatso
    hide lizaszexresz8jel4pulianim2 onlayer hatso
    hide lizaszexresz8jel5alapmegjelenik onlayer hatso
    hide lizaszexresz8jel4leteszanim onlayer hatso
    hide lizaszexresz8jel4fojtattanim onlayer hatso

    show lizaszexresz8jel5alap
    show lizaszexresz8jel5fiuanim
    show lizaszexresz8jel5noanim
    show lizaszexresz8jel5mindenfele onlayer hatso
    l "Oh yeah! That feels good! I am going wet!"
    show screen s2
    u ""
    show lizaszexresz8jel5noanim2
    hide lizaszexresz8jel5noanim
    l "Oh yeah! Do it!"
    show screen s2
    u ""
    show lizaszexresz8jel5noanim
    hide lizaszexresz8jel5noanim2
    l "You have a hard penis. I felt such a hardon a long time ago."
    show screen s2
    u ""
    show lizaszexresz8jel5noanim2
    hide lizaszexresz8jel5noanim
    l "Do not stop! Cum in my pussy! Fill me in!"
    show screen s2
    u ""
    show lizaszexresz8jel5noanim
    hide lizaszexresz8jel5noanim2
    l "I can feel it! You are almost done! Give me all your cum Honey!"
    show screen s2
    u ""
    u ""
    show lizaszexresz8jel5mindenfele onlayer hatso:
        alpha 1.0
        linear 1.0 alpha 0.0
    show lizaszexresz8jel6remeg:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s4
    u ""
    hide lizaszexresz8jel5mindenfele onlayer hatso
    show lizaszexresz8jel6gecisalap:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaszexresz8jel6gecisszaj1:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaszexresz8jel6gecisszemanim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lizaszexresz8jel6gecianim:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2e5
    u ""
    hide lizaszexresz8jel6gecisszaj1
    show lizaszexresz8jel6gecisszajanim
    l "Agh! That felt so good! Nice warm semen in my little pussy…."
    hide lizaszexresz8jel6gecisszajanim
    show lizaszexresz8jel6gecisszaj1
    show screen s1
    u ""
    show lizaszexresz8jel7:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    l "Thank you for your help! Now you should leave. My husband will wake up at any time and he will get suspicious if he finds you here."
    $ debraholcsinal = "debrakertje2"
    $ invertorinejelenyenmeg = True
    jump baloldaliszomszed
$ renpy. pause(hard=True)
label pulimegfordulbisztonsagosan:
    $ pulimegfordulhanyadik += 1
    $ pulimegfordulido = 20
    $ pulimegfordulelteltido = 0
    $ vigyazgombholvan = "0"
    $ vigyazgombholvan = renpy.random.choice(['1', '2', '3' ])
    hide lizaszexresz8jel4anim
    show lizaszexresz8jel4leteszanim
    show screen s2
    u ""
    play sound "audio/visszanez.wav"
    show lizaszexresz8jel4pulianim2 onlayer hatso
    hide lizaszexresz8jel4pulianim onlayer hatso
    show screen s2
    u ""
    hide lizaszexresz8jel4leteszanim
    show lizaszexresz8jel4fojtattanim
    show screen s1
    u ""
    hide lizaszexresz8jel4fojtattanim
    show lizaszexresz8jel4anim
    if pulimegfordulhanyadik == 3:
        show screen s5
        u ""
        jump lizaszexjel8reszfojtatt
    show screen vigyazliza8resz

    show screen s5
    u ""
    show screen s5
    u ""
    show screen s5
    u ""
    play sound "audio/hatranez.wav"
    show lizaszexresz8jel4pulianim onlayer hatso
    hide lizaszexresz8jel4pulianim2 onlayer hatso
$ renpy. pause(hard=True)
label lizaszexjel8reszabahagy:
    hide lizaszexresz8jel4pulianim onlayer hatso
    hide lizaszexresz8jel4pulianim2 onlayer hatso
    hide lizaszexresz8jel5alapmegjelenik onlayer hatso
    hide lizaszexresz8jel4leteszanim onlayer hatso
    hide lizaszexresz8jel4fojtattanim onlayer hatso
    show lizaszexresz8jel4pulimoz1
    $ debraholcsinal = "debrakertje2"
    show lizaszexresz8jel5alapmegjelenik:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    l "This is too dangerous, Honey! My husband could catch us!"
    show lizaszexresz8jel7:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    l "Please leave now! We will continue this another time!"
    $ invertorinejelenyenmeg = True
    jump baloldaliszomszed
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
