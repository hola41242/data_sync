label cukrazda:
    $ holvagyok = "cukrazda"
    jump tiltasok
$ renpy. pause(hard=True)
label cukrazdaszov:
    show invertori onlayer elotte6:
        yalign 0.0
    show screen invertori2
    show etteremalap
    if lidiaholvan == "pultnal":
        show lidiapoz1540:
            zoom 0.4
            xpos 0.7
            ypos 0.25
    show etterempult onlayer hatso
    show etteremasztal1 onlayer hatso
    show etteremfotel2 onlayer hatso
    show etteremszekekk3 onlayer hatso2
    if ritaholvan == "cukrazda":
        show etterembenrita onlayer hatso2
        if hanyadiknapvan == 11:
            show etteremeszkoz1 onlayer hatso2
            show etteremeszkoz2 onlayer hatso2
            if ragasztonalad == 0:
                show etteremeszkoz3 onlayer hatso3
            if rozsaknalad == 2:
                show vazabanrozsakazinvertoriban onlayer hatso3:
                    xpos 0.45
                    ypos 0.38
    show kutyasarga10reszanim onlayer hatso2:
        parallel:
            zoom 0.8
            linear 20.0 zoom 1.0
            linear 20.0 zoom 0.8
        parallel:
            xzoom 1.0
            pause 20.0
            xzoom -1.0
            pause 20.0
        parallel:
            xpos -0.2
            linear 20.0 xpos 1.1
            linear 20.0 xpos -0.2
        parallel:
            ypos 0.44
            linear 20.0 ypos 0.55
            linear 20.0 ypos 0.44
        repeat
    show etteremszekekk4 onlayer hatso3
    show etteremszekekk5 onlayer hatso3
    show etteremszekekk6 onlayer kozep
    show etteremszekekk7 onlayer kozep2
    show etteremvirag8 onlayer kozep
    show etteremvirag9 onlayer elotte
    show etterembencetli onlayer hatso
    if ismeretlencokaholvan == "cukrazda":
        show etterembencsoka onlayer hatso
    show etterembenmenufuzet onlayer hatso
    if etterembenmenufuzet2 == 1:
        show etterembenmenufuzet2 onlayer kozep2
    if mrpuliholvan == "cukrazda":
        show etterembenmrpuli onlayer kozep2
        show etterembenkendo onlayer kozep
    show etterembenpohar onlayer hatso2
    show etterembensoszoro onlayer hatso3
    show etterembensoszoro2 onlayer hatso2
    show etterembenzacsi onlayer hatso3
    if amandaholvan == "cukraszda":
        show amandakintiruha1080 onlayer hatso3:
            zoom 0.7
            xpos 0.58
            ypos 0.16
        if lidiaholvan == "amandavalbeszel":
            show lidia1080 onlayer hatso3:
                zoom 0.7
                xpos 0.42
                ypos 0.16
            if amandapan2 == 0:
                jump amandapan2
    if lidiaholvan == "kintall":
        show lidia2v1080 onlayer hatso3:
            zoom 0.7
            xpos 0.55
            ypos 0.16
    if lidiaholvan == "cukrazdabanszamlazik":
        $ etterembenmenufuzet2 = 0
        hide etterembenmenufuzet2 onlayer kozep2
        show etteremlidiaelolul onlayer kozep2
    jump engedejek
$ renpy. pause(hard=True)
label cukrazdatorlokendo:
    hide screen cukrazda
    f "This is a wipe."
    show screen cukrazda
$ renpy. pause(hard=True)
label cukrazdaetlap:
    hide screen cukrazda
    f "This is a menu."
    show screen cukrazda
$ renpy. pause(hard=True)
label cukrazdaborsszoro:
    hide screen cukrazda
    f "A pepper shaker, nothing interesting."
    show screen cukrazda
$ renpy. pause(hard=True)
label cukrazdaritavalbeszelni:
    hide etteremkozeli onlayer elotte
    hide fiupoz1 onlayer elotte
    hide fiupoz2 onlayer elotte
    hide ritabeszed onlayer elotte
    hide screen cukrazda
    if cukraszdaritavalbeszeltel == 0:
        $ cukraszdaritavalbeszeltel = 1
        $ ritaholvan = "parkbanpadon"
        $ ritavalbeszeltelacukrazdaban = True
        show etteremkozeli onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show ritabeszed onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1
        u ""
        f "I am here. Would you like to order something?"
        r "Hy! I really do not know. There are a lot of great meals here… It is hard to choose…"
        show fiupoz2 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        f "Oh shit… Chose something… I have no time for that…"
        r "I really can not choose. I got nervous…"
        r "What do you wish to eat?"
        hide etterembenrita onlayer hatso2
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz2 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        f "I like ice cream. How about that?"
        r "Oh yeah! Ice cream! It is romantic to eat ice cream on the first date. Let it be an ice cream!"
        f "What kind do you wish for?"
        r "My favorite is punch ice cream."
        f "Cup or funnel?"
        r "It is so complicated to choose…"
        show fiupoz1sokkolt onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "What is so complicated?"
        f "Do you want to eat the funnel or not?"
        show fiupoz1sokkolt onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        r "I wish to. It is tasty."
        f "Ok... Now I will go and buy you an ice cream. Where can the seller be?"
        r "I do not know, but can we eat the ice cream in the park? We have such nice weather. I wish to lick my ice cream in nature. It is so intimate there."
        f "Of course… we can eat the ice cream in the park."
        r "Alright. I will go now and I will drop my ball home on my way. It won’t take long. Let us meet in the park!"
        f "Ok. I have to find the seller. Let us meet in the park!"
        show etteremkozeli onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show ritabeszed onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        if cukraszdaismeretlencokavalbeszeltel == 1:
            if cukraszdaritavalbeszeltel == 1:
                if cukraszdamrpulivalbeszeltel == 1:
                    $ lidiaholvan = "pultnal"
                    jump lidiamegjelenik
    if hanyadiknapvan >= 11:
        show etteremkozeli onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show ritabeszed onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1e5
        u ""
        if hanyadiknapvan == 11:
            if ragasztokell == False:
                f "Why are you avoiding meat the university?"
                r "Oh you silly bear! No one should know that we are lovers. The rumors are bad..."
                hide invertori onlayer elotte6
                hide screen invertori
                hide screen invertori2
                show ritacsokcukrazda onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s2
                u ""
                show fiupoz1pir onlayer elotte
                hide ritacsokcukrazda onlayer elotte
                show ritacsokcukrazda onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show screen s2
                u ""
                show invertori onlayer elotte6:
                    yalign 0.0
                show screen invertori
                f "Did you not tell this to anyone yet?"
                show fiupoz1pir onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz1 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz2 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                r "I talked with Kitty about us, but she is trustful. "
                f "Fine. Kitty knows it."
                r "Do not worry! She will not tell this to anyone..."
                f "I know. She has been a friend of mine since I was 3 years old... What are you doing here?"
                show fiupoz2 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show fiupoz1 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                r "I have homework from art class. I have to prepare an origami exhibition."
                f "Did you do that puppy? It is cool! You are very talented!"
                r "Yeap! Thank you! I barely used any glue…"
                f "Fucking amazing! What will you make next?"
                r "I really don't know. I am thinking of it right now. I need more pieces..."
            if rozsaknalad == 0:
                if ragasztokell == True:
                    f "Could you lend me the glue a bit?"
                    r "Of course! But I need something special for exchange… Like flowers..."
                    f "Shit! What kind of flowers do you mean?"
                    r "The flower, which symbolizes the embodied love…"
                    f "Fine…"
                    $ rozsakatfelszedheted = True
            if rozsaknalad == 1:
                f "These flowers are for you..."
                r "Oh Fred! You are fantastic! I had never seen such beautiful flowers before!"
                f "Super. Can I have the glue?"
                r "Of course! What do you think? Should we go to the park again to lick the „ iceream”?"
                f "Sorry! I have no time now…"
                r "No problem. I put these beautiful flowers on the table like this…"
                show vazabanrozsakazinvertoriban onlayer hatso3:
                    xpos 0.45
                    ypos 0.38
                hide lidia1080 onlayer hatso3
                if lidiaholvan == "amandavalbeszel":
                    show lidia1080 onlayer hatso3:
                        zoom 0.7
                        xpos 0.42
                        ypos 0.16

                $ rozsaknalad = 2
                $ ragasztonalad = 1
                hide etteremeszkoz3 onlayer hatso3
                $ ragasztokell = False
                if oroszultanultal == True:
                    if oroszruha == "tiszta":
                        if ragasztonalad == 1:
                            f "I can dress in now. I will do it."
                            jump beoltozikfred11nap



        show etteremkozeli onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show ritabeszed onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
    show screen cukrazda
$ renpy. pause(hard=True)
label cukrazdaismeretlennelbeszelni:
    hide screen cukrazda
    $ cukraszdaismeretlencokavalbeszeltel = 1
    if lidiamarapultnal == True:
        i "I do not want to talk to you."
    else:
        f "I'm sorry Sir! Did you see the seller?"
        i "I did, but now I do not see her. Where could she go?"
        f "Thank you Sir!"
        if cukraszdaismeretlencokavalbeszeltel == 1:
            if cukraszdaritavalbeszeltel == 1:
                if cukraszdamrpulivalbeszeltel == 1:
                    $ lidiaholvan = "pultnal"
                    jump lidiamegjelenik
    show screen cukrazda
$ renpy. pause(hard=True)
label cukrazdamrpulivalbeszelni:
    hide etteremkozeli onlayer elotte
    hide fiupoz1 onlayer elotte
    hide mrpulipoz onlayer elotte
    hide mrpulipozsalja onlayer elotte
    hide fiupoz1sokkoltjobra onlayer elotte
    hide screen cukrazda
    if cukraszdamrpulivalbeszeltel == 1:
        f "I do not want to disturb Mr. Puli. He is eating…"
    if cukraszdamrpulivalbeszeltel == 0:
        $ cukraszdamrpulivalbeszeltel = 1
        show etteremkozeli onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show fiupoz1 onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        show mrpulipoz onlayer elotte:
            xzoom -1.0
            xpos 0.3
            alpha 0.0
            linear 1.0 alpha 1.0
        show mrpulipozsalja onlayer elotte:
            xzoom -1.0
            xpos 0.3
            alpha 0.0
            linear 1.0 alpha 1.0
        show screen s1e5
        u ""
        f "Hello Mr. Puli!"
        mr "Do not disturb me kid! I am feeding myself. My body needs energy. I need the calories to keep my body in this fantastic condition…"
        show fiupoz1sokkoltjobra onlayer elotte:
            alpha 0.0
            linear 1.0 alpha 1.0
        f "I am really sorry, but can you tell me where I can find the seller?"
        show fiupoz1sokkoltjobra onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        mr "I can not see anything my son. Where are you? I can not see you…"
        f "Thank you! And I am sorry again!"
        show etteremkozeli onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show fiupoz1 onlayer elotte:
            alpha 1.0
            linear 1.0 alpha 0.0
        show mrpulipoz onlayer elotte:
            xzoom -1.0
            xpos 0.3
            alpha 1.0
            linear 1.0 alpha 0.0
        show mrpulipozsalja onlayer elotte:
            xzoom -1.0
            xpos 0.3
            alpha 1.0
            linear 1.0 alpha 0.0
        show screen s1
        u ""
        if cukraszdaismeretlencokavalbeszeltel == 1:
            if cukraszdaritavalbeszeltel == 1:
                if cukraszdamrpulivalbeszeltel == 1:
                    $ lidiaholvan = "pultnal"
                    jump lidiamegjelenik

    show screen cukrazda
$ renpy. pause(hard=True)
label cukrazdapult:
    hide screen cukrazda
    if lidiaholvan == "kintall":
        if hanyadiknapvan == 11:
            if mubajuszkell == 1:
                hide invertori onlayer elotte6
                hide screen invertori
                hide screen invertori2
                hide lidiapoztvalt1 onlayer elotte
                hide lidiapoztvalt2 onlayer elotte
                show lidiapoztvalt1 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                show screen s2
                u ""
                li "Do you want anything else?"
                f "Can I ask you something?"
                li "Sure."
                f "You said last time you had a child. If you have to buy him a costume, where do you go?"
                li "I do not buy any costumes. I make them."
                li "What kind of a costume do you need?"
                f "I need an artificial mustache…"
                show lidiapoztvalt2 onlayer elotte:
                    alpha 0.0
                    linear 1.0 alpha 1.0
                li "Do you want to look older?"
                f "Something like that…"
                li "I need material and 1- 3 days..."
                f "I need it now."
                li "Ok. We can cut your hair down on the two sides and put the hair on your face with some glue..."
                f "You can not touch my hair! It is my treasure..."
                show lidiapoztvalt2 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                li "In this case I can not help you. Would you like to order something?"
                f "No. Thank you!"
                li "Good bye!"
                show lidiapoztvalt1 onlayer elotte:
                    alpha 1.0
                    linear 1.0 alpha 0.0
                show invertori onlayer elotte6:
                    yalign 0.0
                show screen invertori
            else:
                li "Do you want anything else?"
                f "No. Thank you!"
                show screen cukrazda
                $ renpy. pause(hard=True)
    if lidiaholvan == "pultnal":
        if hanyadiknapvan == 12:
            li "Do you want anything else?"
            f "No. Thank you!"
            show screen cukrazda
            $ renpy. pause(hard=True)
        if hanyadiknapvan == 11:
            li "Do you want anything else?"
            f "No. Thank you!"
            show screen cukrazda
            $ renpy. pause(hard=True)
    if hanyadiknapvan <= 10:
        if lidiaholvan == "pultnal":
            if fagylaltoknalad == 2:
                if cottonnalad == 0:
                    li "Do you want anything else?"
                    f "Yeah, but I do not think you sell something like that…"
                    li "What is it?"
                    f "I try to tell it quietly, so no one hears it… I need a condom."
                    li "What? I didn't hear it well! Condom?! Hey! Jerry! Do we have a condom?...."
                    f "Thank you for your discretion…"
                    li "Nah, we have no condoms."
                else:
                    li "Do you want anything else?"
                    f "No. Thank you!"
            if fagylaltoknalad == 1:
                li "Do you want anything else?"
                f "No. Thank you!"
            if fagylaltoknalad == 0:
                $ fagylaltoknalad = 1
                $ penz -= 600
                li "Here you go! The two ice creams."
                f "Thank you! Goodbye!"
                li "Come next time!"
        else:
            f "Noone is here. Where is the seller?"
    show screen cukrazda
$ renpy. pause(hard=True)
label lidiamegjelenik:
    hide screen invertori2
    hide screen invertori
    hide invertori onlayer elotte6
    show lidia1080 onlayer hatso2:
        zoom 0.7
        xpos 0.37
        ypos 0.16
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s2
    u ""
    show csillagok6resz onlayer elotte:
        ypos -3.8
        linear 10.0 ypos 1.3
    show lidiapankep onlayer elotte:
        zoom 0.8
        xalign 0.5
        ypos 0.9
        linear 10.0 ypos -2.9
    show screen s1e5
    u ""
    play sound "audio/csillag.ogg"
    show screen s8e5
    u ""
    hide etteremkozeli onlayer elotte
    hide fiupoz1 onlayer elotte
    hide mrpulipoz onlayer elotte
    show etteremkozeli onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show lidiapoz1 onlayer elotte:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1e5
    u ""
    li "Hy! I am sorry. I had something to do fast."
    f "No problem. Please give me the complaint book. Just kidding!"
    li "I am really sorry. My little son, Timmy, is ill and he is only 6 years ol. I could not leave her alone. I could not find anyone to take care of him so fast in the morning…"
    f "Do not worry, I was just joking around. I wish him a fast recovery. Did we meet before?"
    li "You are a funny guy, huh? I never saw you before."
    f "But you have a special birthmark. I saw it in the same place before… I got it! Liza! Liza has such a birthmark on her face!"
    li "Well… yeah, no surprise! She is my mother… I inherited the birthmark."
    f "Is she your mom?"
    hide fiupoz1sokkolt onlayer elotte
    show fiupoz1sokkolt onlayer elotte
    li "You seem to be a bit slow… YEAH... she… Is… My… mother…"
    hide fiupoz1sokkolt onlayer elotte
    li "Now we had a nice conversation... A bit long but nice. Let me know your order!"
    f "Well. I wish to get two icereams. One is punch and the other is vanilie."
    li "Nah! This did not take so long to spit it out. I am on my way to deliver the two icereams."
    show etteremkozeli2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show etterembenbeszedlidiapuniferd onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    mr "Hey. My child! Where is my dessert?"
    li "It is ready. A minute and I will bring it to you dad."
    mr "Does this guy harrash on you honey?"
    f "It is me Mr. Puli! I am Fred! You know! The university student who helps you with housework..."
    mr "Do not stop my daughter from working! She is bringing me my dessert at the moment."
    li "Oh daddy! Go and sit down! I will be right there!"
    show etteremkozeli2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show etterembenbeszedlidiapuniferd onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    hide lidia1080 onlayer hatso2
    $ lidiaholvan = "pultnal"
    $ lidiamarapultnal = True
    f "Why does your Dad not take care of Timmy?"
    li "You know… My dad has his own biorhythm. I can not disturb him in… concentration…"
    f "Well… yeah… he has a strange… I mean interesting lifestyle…"
    show lidiapoz1540:
        zoom 0.4
        xpos 0.7
        ypos 0.25
    show etteremkozeli onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show lidiapoz1 onlayer elotte:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1e5
    u ""
    show screen invertori
    show invertori onlayer elotte6:
        yalign 0.0

    show screen cukrazda
$ renpy. pause(hard=True)
label cukraszdaorigamikutya:
    hide screen cukrazda
    f "An origami puppy. Rita made it."
    show screen cukrazda
$ renpy. pause(hard=True)
label cukraszdaragaszto:
    hide screen cukrazda
    f "Glue."
    show screen cukrazda
$ renpy. pause(hard=True)
label amandapan2:
    $ amandapan2 = 1
    $ fekete = True
    hide fekete onlayer screens
    show fekete onlayer screens:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show csillagok6resz onlayer elotte:
        xpos 0.1
        ypos -3.5
        linear 10.0 ypos 1.2
    show amandakintiruha onlayer elotte:
        xpos 0.1
        ypos 1.2
        linear 10.0 ypos -3.6
    show screen s1e5
    u ""
    play sound "audio/csillag.ogg"
    show screen s8e5
    u ""
    hide csillagok6resz onlayer elotte
    hide amandakintiruha onlayer elotte
    jump engedejek
$ renpy. pause(hard=True)
label cukraszdaamandaeslidia:
    hide screen cukrazda
    hide invertori onlayer elotte6
    hide screen invertori2
    hide screen invertori
    hide lidiapoz1 onlayer elotte
    hide etteremkozeli2 onlayer elotte
    hide amandapoz2 onlayer elotte
    hide frednagybanelol onlayer elotte
    show etteremkozeli2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show amandapoz2 onlayer elotte:
        xpos 0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show lidiapoz1 onlayer elotte:
        xpos -0.2
        alpha 0.0
        linear 1.0 alpha 1.0
    show frednagybanelol onlayer elotte:
        xpos -0.1
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    li "Are you still together with that handsome guy, Amanda?"
    am "We are engaged. Don’t you remember?"
    li "Oh, nowadays an engagement is insignificant…"
    am "Just like the order of your customers. I have been waiting for my gyros for 50 minutes now…"
    li "I am just kidding, you know. We are friends…"
    am "If you tell…"
    show etteremkozeli2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoz2 onlayer elotte:
        xpos 0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show lidiapoz1 onlayer elotte:
        xpos -0.2
        alpha 1.0
        linear 1.0 alpha 0.0
    show frednagybanelol onlayer elotte:
        xpos -0.1
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show invertori onlayer elotte6:
        ypos 0.0

    show screen invertori
    show screen cukrazda
$ renpy. pause(hard=True)
label cukraszdaamanda:
    hide screen cukrazda
    hide invertori onlayer elotte6
    hide screen invertori2
    hide screen invertori
    hide fiupoz1 onlayer elotte
    hide etteremkozeli2 onlayer elotte
    hide amandapoz2 onlayer elotte
    show etteremkozeli2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show amandapoz2 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show fiupoz1 onlayer elotte:
        alpha 0.0
        linear 1.0 alpha 1.0
    show screen s1
    u ""
    f "Did you change your dress?"
    am "Why? Do you wear your costume all day long?"
    f "I have only this dress left. All other dresses burned in the fire. I have no money to buy any new dresses…"
    am "What if you need to wash the dress? What do you wear during the washing process?"
    f "I have 3 sets of this kind of dress…"
    am "You are like a cartoon character. You Are always in the same dress…"
    f "Yeah... It seems..."
    f "What are you doing here?"
    am "I am waiting for my order. Maybe Lidia will deliver it today..."
    f "Ok, Bye!"
    show etteremkozeli2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show amandapoz2 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show fiupoz1 onlayer elotte:
        alpha 1.0
        linear 1.0 alpha 0.0
    show screen s1
    u ""
    show invertori onlayer elotte6:
        ypos 0.0

    show screen invertori
    show screen cukrazda
$ renpy. pause(hard=True)
label lidiaszamlanmergelodik:
    hide screen cukrazda
    if lidiaraer12nap == True:
        if regiegernalad == 1:
            hide invertori onlayer elotte6
            hide lidiaszamlakpoz1 onlayer elotte
            hide lidiaszamlakpoz2 onlayer elotte
            hide lidiaszamlakpoz3 onlayer elotte
            hide screen invertori
            hide screen invertori2
            show lidiaszamlakpoz2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            li "Tell me you found a mouse."
            f "I found a mouse."
            li "Are you just kidding?"
            f "Not really. I found one."
            show lidiaszamlakpoz3 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            li "I wouldn't have been worrying so much, if I had asked you earlier."
            f "Ok, but I don't know if the mouse works..."
            li "Give it to me, please. If this mouse has worked, I shall give you something tasty."
            $ regiegernalad = 2
            hide lidiaszamlakpoz2 onlayer elotte
            hide etteremlidiaelolul onlayer kozep2
            $ lidiaholvan = "pultnal"
            show lidiaszamlakpoz3 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            show invertori onlayer elotte6:
                yalign 0.0
            show screen invertori
            show screen s2
            u ""
            show lidiav31080 onlayer hatso3:
                zoom 0.7
                xpos 0.55
                ypos 0.16
                alpha 0.0
                linear 1.0 alpha 1.0
            show polip1080 onlayer hatso3:
                zoom 0.7
                xpos 0.55
                ypos 0.16
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s2
            u ""
            show etteremkozeli onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show fiupoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show lidiapoz2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show lidiapoz2polip onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            li "You made my day! The mouse is working perfectly. Only that little ball was missing but I could put the old one in this mouse..."
            li "I brought this fresh octopus only for you."
            show fiupoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz7 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            show fiupoz7 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz8 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            f "I am sorry Lidia, do not take it wrong, but I think this octopus is toooo fresh for me..."
            f "Do you have anything else to offer me?"
            show fiupoz8 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            li "Of course I have. Wait a minute! I think you will like that much better..."
            show lidiapoz2 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lidiapoz2polip onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s3
            u ""
            show lidiapoz2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show lidiapoz2giros onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            li "Does this look much better?"
            f "Yeap! It looks tasty!"
            li "Good appetite!"
            $ girosznalad = 1
            f "Thank you. I will eat it later. I have something to do now."
            li "Visit us any time! Bye!"
            hide lidiav31080 onlayer hatso3
            hide polip1080 onlayer hatso3
            show lidiapoz1540:
                zoom 0.4
                xpos 0.7
                ypos 0.25
            show etteremkozeli onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show fiupoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lidiapoz2 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show lidiapoz2giros onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""






        if regiegernalad == 0:
            hide invertori onlayer elotte6
            hide lidiaszamlakpoz1 onlayer elotte
            hide lidiaszamlakpoz2 onlayer elotte
            hide lidiaszamlakpoz3 onlayer elotte
            hide screen invertori
            hide screen invertori2
            show lidiaszamlakpoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            li "What do you wish, Fred?"
            f "You seem to be worried. What happened?"
            show lidiaszamlakpoz2 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            li "That damn mouse. The PC mouse fell from the table and it broke in pieces."
            li "I should send the bills to the taxing office quickly, but I can not make it without a computer. My computer is old as fuck and I can apply only PS2 mouse. Every shop sells USB mouses..."
            li "I just bought a new computer, but it will be ready to use only tomorrow. I will get in trouble if I do not report the income today."
            f "Maybe I can help..."
            show lidiaszamlakpoz3 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            li "Do you think so? Find an old type mouse for me please! You will save my life."
            f "Just a minute. I will be back soon."
            hide lidiaszamlakpoz1 onlayer elotte
            show lidiaszamlakpoz1 onlayer elotte:
                alpha 0.0
                linear 1.0 alpha 1.0
            show screen s1
            u ""
            li "Ok. I will continue arguing until then."
            $ lidianakregiegerkell = True
            hide lidiaszamlakpoz2 onlayer elotte
            hide lidiaszamlakpoz3 onlayer elotte
            show lidiaszamlakpoz1 onlayer elotte:
                alpha 1.0
                linear 1.0 alpha 0.0
            show screen s1
            u ""
            show invertori onlayer elotte6:
                yalign 0.0
            show screen invertori
    if lidiaraer12nap == False:
        li "I am sorry Fred. I have no time. These damn bills!"
    show screen cukrazda

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
