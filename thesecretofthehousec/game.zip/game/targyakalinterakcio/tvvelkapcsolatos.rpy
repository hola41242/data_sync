label csengetnektvmiadt:
    play sound "audio/cseng.ogg"
    f "Maybe they brought the television. I should go to the entrance."
    if holvagyok == "fojasoball":
        show screen fojasoball
    if holvagyok == "fojasojobb":
        show screen fojasojobb
$ renpy. pause(hard=True)
label tvtaviranyitofel:
    if fifitfelvetem == True:
        f "I got Fifi in my pocket, I can not take up anything while she is here."
        $ renpy. pause(hard=True)
    $ tvtaviranyitonalad = True
    show taviranyitokonyhaban:
        alpha 1.0
        linear 1.0 alpha 0.0
$ renpy. pause(hard=True)
label tvprogramozas:
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    $ csinalszvalamit = "tvprogramoz"
    $ bebramarotvan = False
    jump tiltasok
label tvprogramozasszov:
    hide fredprogramoz onlayer hatso
    show fredprogramoz onlayer hatso:
        zoom 0.7
        xpos 0.1
        ypos 0.5
        alpha 0.0
        linear 2.0 alpha 1.0
    show screen tvprogramozas
$ renpy. pause(hard=True)
label tvprogramozasabahagy:
    $ fekete = True
    $ csinalszvalamit = "semit"
    hide screen tvprogramozas
    show fredprogramoz onlayer hatso:
        alpha 1.0
        linear 2.0 alpha 0.0

    if tvprogramkesz == True:
        play music "audio/tvadas.ogg" fadeout 1
        $ tvtaviranyitomamanal = True
        $ mamakeresei = 4
        m "Super Freddy! I got hungry, Bring me a sandwich honey."
    if bebramarotvan == True:
        $ bebramarotvan = False
        d "Nah, I need to go to work a bit."
        show debratvnezalap:
            alpha 1.0
            linear 2.0 alpha 0.0
        show debratvnezpislog:
            alpha 1.0
            linear 2.0 alpha 0.0
    jump engedejek

label debrabejopiszkalni:
    if bebramarotvan == False:
        $ bebramarotvan = True
        show debratvnezalap:
            alpha 0.0
            linear 2.0 alpha 1.0
        show debratvnezpislog:
            alpha 0.0
            linear 2.0 alpha 1.0
        pause 2.0

    if debrabejopiszkalni == 1:
        d "What is up Grandma? Will we watch Tv or we will just watch Fred while he is programming the television…"
        m "He will make it in no time, Or i will ask him to sing and dance…"
    if debrabejopiszkalni == 2:
        d "We are on the right track, but I see only ants in war... They are fighting…"
        m "I tough they repeat the last episode of Tinderbill serie..."
    if debrabejopiszkalni == 3:
        m "Debra! Do you know when they repeat my series? Freddy won't make it until it begins..."
        d "But of course i know! Go to your room! They repeat it just now in there..."
        f "You do not need to go Grandma!"
        d "Thank you for asking Grandma to stay…I will thank you for this in another way as well..."
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
