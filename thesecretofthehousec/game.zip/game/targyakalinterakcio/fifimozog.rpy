label fifinapalibanmozog:
    hide fifisetaszembe onlayer hatsominus1
    hide fifioldalseta onlayer hatsominus1
    hide fifisetahatra onlayer hatsominus1
    hide fifipisil
    $ fifinapaliban = False
    if fifiholcsinal == "napaliban2":
        hide fifipisil
        show fifipisil:
            zoom 0.7
            xpos 0.1
            ypos 0.54
            alpha 0.0
            linear 2.0 alpha 1.0
            pause (fificsinalido)
            alpha 1.0
            linear 2.0 alpha 0.0
        show hugy:
            alpha 0.0
            pause (fificsinalido)
            zoom 0.7
            xpos 0.16
            ypos 0.76
            alpha 0.0
            linear 2.0 alpha 1.0
        $ renpy. pause(hard=True)
    if fifiholcsinal == "napaliban4":
        hide fifipisil onlayer hatso
        show fifipisil onlayer hatso:
            zoom 0.7
            xpos 0.6
            ypos 0.56
            alpha 0.0
            linear 2.0 alpha 1.0
            pause (fificsinalido)
            alpha 1.0
            linear 2.0 alpha 0.0
        show hugy1:
            alpha 0.0
            pause (fificsinalido)
            zoom 0.8
            xpos 0.64
            ypos 0.78
            alpha 0.0
            linear 2.0 alpha 1.0
        $ renpy. pause(hard=True)
    hide fifiszagolpislog
    hide fifiszagol
    show fifisetaszembe onlayer hatsominus1:
        parallel:
            alpha 1.0
            pause 10.0 alpha 0.0
            pause 30.0 alpha 1.0
            repeat
        parallel:
            xpos 0.12
            linear 10.0 xpos 0.12
            repeat
        parallel:
            ypos 0.55
            linear 10.0 ypos 0.65
            repeat
        parallel:
            zoom 0.25
            linear 10.0 zoom 0.26
            repeat
    show fifioldalseta onlayer hatsominus1:
        parallel:
            ypos 0.7
            pause 10.0
            linear 10.0 ypos 0.68
            linear 10.0 ypos 0.7
            pause 10.0
            repeat
        parallel:
            alpha 0.0
            pause 10.0 alpha 1.0
            pause 20.0 alpha 0.0
            pause 10.0 alpha 0.0
            repeat
        parallel:
            xpos 0.16
            pause 10.0
            linear 10.0 xpos 0.6
            linear 10.0 xpos 0.16
            pause 10.0
            repeat
        parallel:
            zoom 0.2
            pause 10.0
            linear 10.0 zoom 0.18
            linear 10.0 zoom 0.2
            pause 10.0
            repeat
        parallel:
            xzoom 1.0
            pause 10.0
            pause 10.0 xzoom -1.0
            pause 10.0 xzoom 1.0
            pause 10.0
            repeat
    show fifisetahatra onlayer hatsominus1:
        parallel:
            alpha 0.0
            pause 30.0 alpha 1.0
            pause 10.0 alpha 0.0
            repeat
        parallel:
            xpos 0.12
            linear 10.0 xpos 0.12
            repeat
        parallel:
            ypos 0.65
            linear 10.0 ypos 0.55
            repeat
        parallel:
            zoom 0.25
            linear 10.0 zoom 0.25
            repeat
    if csinalszvalamit == "semit":
        $ fekete = True
        jump engedejek
$ renpy. pause(hard=True)
label fifiatjarobanmozog:
    $ fifiatjaroban = False
    hide fififelfeleszagol
    hide fififelfeleszagolpislog
    show fififelfeleszagol:
        zoom 0.6
        xpos 0.46
        ypos 0.66
        alpha 0.0
        linear 2.0 alpha 1.0
    show fififelfeleszagolpislog:
        zoom 0.6
        xpos 0.46
        ypos 0.66
        alpha 0.0
        linear 2.0 alpha 1.0
    if csinalszvalamit == "semit":
        $ fekete = True
        jump engedejek
$ renpy. pause(hard=True)
label fifiatjarobamegy:
    $ fifiatjaroban = False
    hide fifisetaszembe onlayer hatsominus1
    hide fifioldalseta onlayer hatsominus1
    hide fifisetahatra onlayer hatsominus1
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
