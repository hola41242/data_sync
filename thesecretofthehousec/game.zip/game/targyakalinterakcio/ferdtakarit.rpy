label fifipisifeltakarit:
    if torloszivacsnalad == False:
        f "I can not clean it up with my bare hands. I need a sponge from the bathroom cabinet."
        $ renpy. pause(hard=True)
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    $ csinalszvalamit = "takarit"
    jump tiltasok
label fifipisifeltakarit2:
    if torloszivacsnalad == False:
        f "I can not clean it up with my bare hands. I need a sponge from the bathroom cabinet."
        $ renpy. pause(hard=True)
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    $ csinalszvalamit = "takarit2"
    jump tiltasok
label fifipisifeltakarit3:
    if torloszivacsnalad == False:
        f "I can not clean it up with my bare hands. I need a sponge from the bathroom cabinet."
        $ renpy. pause(hard=True)
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    $ csinalszvalamit = "takarit3"
    jump tiltasok
label fifipisifeltakarit4:
    $ csinalszvalamit = "takarit4"
    jump tiltasok
label fifipisifeltakaritszov:
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    show screen takaritabahagy
    show screen ferdtakarit
    show felsurolfiu onlayer hatso:
        zoom 0.5
        xpos 0.55
        ypos 0.58
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi1anim:
        xpos 0.55
        ypos 0.7
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi2anim:
        zoom 0.8
        xpos 0.55
        ypos 0.7
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi3anim:
        zoom 1.3
        xpos 0.55
        ypos 0.69
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label fifipisifeltakarit2szov:
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    show screen takaritabahagy
    show screen ferdtakarit
    show felsurolfiu onlayer hatso:
        zoom 0.6
        xpos 0.16
        ypos 0.51
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi1anim:
        xpos 0.16
        ypos 0.66
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi2anim:
        xpos 0.16
        ypos 0.66
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi3anim:
        xpos 0.16
        ypos 0.66
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label fifipisifeltakarit3szov:
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    show screen takaritabahagy
    show screen ferdtakarit
    show felsurolfiu onlayer hatso:
        zoom 0.65
        xpos 0.65
        ypos 0.51
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi1anim:
        xpos 0.65
        ypos 0.7
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi2anim:
        zoom 0.8
        xpos 0.65
        ypos 0.7
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi3anim:
        zoom 1.3
        xpos 0.65
        ypos 0.69
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label fifipisifeltakarit4szov:
    show screen invertori2
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    queue sound "audio/surol.wav"
    show screen takaritabahagy
    show screen ferdtakarit
    show felsurolfiu onlayer hatso:
        zoom 0.65
        xpos 0.365
        ypos 0.62
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi1anim:
        xpos 0.37
        ypos 0.8
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi2anim:
        xzoom -1.0
        zoom 0.8
        xpos 0.38
        ypos 0.8
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi3anim onlayer hatso:
        zoom 1.3
        xpos 0.37
        ypos 0.8
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label takaritabahagy:
    stop sound
    hide screen ferdtakarit
    hide screen takaritabahagy
    $ csinalszvalamit = "semit"
    $ fekete = True
    show bubi1anim:
        alpha 1.0
        linear 2.0 alpha 0.0
    show bubi2anim:
        alpha 1.0
        linear 2.0 alpha 0.0
    show bubi3anim:
        alpha 1.0
        linear 2.0 alpha 0.0
    hide bubi3anim onlayer hatso
    if hanyadiknapvan == 5:
        if dolgozoltakaritelteltido >= 10:
            show hugy:
                alpha 0.66
        if dolgozoltakaritelteltido >= 20:
            show hugy:
                alpha 0.33
                linear 1.0 alpha 0.0
    show felsurolfiu onlayer hatso:
        alpha 1.0
        linear 2.0 alpha 0.0
    if szivacskoszoslett >= 10:
        f "The sponge is dirty, I should clean it!"
    jump engedejek
$ renpy. pause(hard=True)
label takaritaskesz:
    if fifipisi1 == True:
        if fifipisi2 == True:
            if fifipisi3 == True:
                $ kutyapisok = 2
    show hugy:
        alpha 1.0
        linear 1.0 alpha 0.0
    show felsurolfiu onlayer hatso:
        alpha 1.0
        linear 2.0 alpha 0.0
    jump takaritabahagy
$ renpy. pause(hard=True)
label takaritaskesz2:
    if fifipisi1 == True:
        if fifipisi2 == True:
            if fifipisi3 == True:
                $ kutyapisok = 2
    show hugy1:
        alpha 1.0
        linear 1.0 alpha 0.0
    show felsurolfiu onlayer hatso:
        alpha 1.0
        linear 2.0 alpha 0.0
    jump takaritabahagy
$ renpy. pause(hard=True)
label takaritaskesz4:
    $ kakialatpisi = 2
    jump takaritabahagy
$ renpy. pause(hard=True)
label porszivoz:
    $ csinalszvalamit = "porszivoz"
    jump tiltasok
label porszivozszov:
    show screen ferdporszivoz
    queue sound "audio/porszivo.ogg"
    queue sound "audio/porszivo.ogg"
    queue sound "audio/porszivo.ogg"
    queue sound "audio/porszivo.ogg"
    if holvagyok == "fojasojobb":
        if debraholcsinal == "lomolgatfojasojobb":
            show debrahattallomolfojasojobbanim:
                alpha 1.0
                linear 1.0 alpha 0.0
        show debraablakotmosanim:
            zoom 0.95
            xzoom -1.0
            xpos 0.02
            ypos 0.05
            alpha 0.0
            linear 1.0 alpha 1.0
        if debraholcsinal == "ablakotpucoljobbfojason":
            hide debraablakotmosanim
            show debraablakotmosanim:
                zoom 0.95
                xzoom -1.0
                xpos 0.02
                ypos 0.05
        $ debraholcsinal = "ablakotpucoljobbfojason"
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 0.7
            xpos 0.35
            ypos 0.25
            alpha 0.0
            linear 1.0 alpha 1.0
        $ renpy. pause(hard=True)
    if holvagyok == "fojasoball":
        show mamahattalall:
            xpos -0.15
            ypos 0.08
            alpha 0.0
            linear 1.0 alpha 1.0
        if mamaholvan == "fojasoball":
            hide mamahattalall
            show mamahattalall:
                xpos -0.15
                ypos 0.08
        $ mamaholvan = "fojasoball"
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 0.7
            xpos 0.4
            ypos 0.25
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 4.0
        m "What a boring movie…"
        $ renpy. pause(hard=True)
    if holvagyok == "napaliban":
        show mamanappalihattal:
            alpha 0.0
            linear 1.0 alpha 1.0
        if mamaholvan == "nappali":
            hide mamanappalihattal
            show mamanappalihattal
        $ mamaholvan = "nappali"
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            xpos 0.1
            ypos 0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 4.0
        m "The door was here a few minutes ago… It dissapperaed… Strange…"
        $ renpy. pause(hard=True)
    if holvagyok == "atjaro":
        show debrahatta6resz onlayer screens:
            alpha 0.0
            linear 1.0 alpha 1.0
        if debraholcsinal == "atjaro":
            hide debrahatta6resz onlayer screens
            show debrahatta6resz onlayer screens
        $ debraholcsinal = "atjaro"
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 0.8
            xpos 0.3
            ypos 0.25
            alpha 0.0
            linear 1.0 alpha 1.0
        pause 5.0
        d "What a magnificent painting! Someone is peeing behind the bushes…"
        $ renpy. pause(hard=True)
    if holvagyok == "furdo":
        show debrabudittakaritmozanim:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrabudittakaritanim:
            alpha 0.0
            linear 1.0 alpha 1.0

        if debraholcsinal == "furdo2":
            hide debrabudittakaritmozanim
            show debrabudittakaritmozanim
            hide debrabudittakaritanim
            show debrabudittakaritanim
        $ mamaholvan = "Konyha"
        $ debraholcsinal = "furdo2"
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 1.1
            xpos 0.3
            ypos 0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        $ renpy. pause(hard=True)
    if holvagyok == "konyha":
        show debrakonyhabantorolgetanim:
            alpha 0.0
            linear 1.0 alpha 1.0
        if debraholcsinal == "konyhatorol":
            hide debrakonyhabantorolgetanim
            show debrakonyhabantorolgetanim
        $ debraholcsinal = "konyhatorol"
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 1.1
            xpos 0.07
            ypos 0.1
            alpha 0.0
            linear 1.0 alpha 1.0
        $ renpy. pause(hard=True)


$ renpy. pause(hard=True)
label porszivozabahagy:
    stop sound
    if holvagyok == "fojasojobb":
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 0.7
            xpos 0.35
            ypos 0.25
            alpha 1.0
            linear 1.0 alpha 0.0
    if holvagyok == "fojasoball":
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 0.7
            xpos 0.4
            ypos 0.25
            alpha 1.0
            linear 1.0 alpha 0.0
    if holvagyok == "napaliban":
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            xpos 0.1
            ypos 0.1
            alpha 1.0
            linear 1.0 alpha 0.0
    if holvagyok == "atjaro":
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 0.8
            xpos 0.3
            ypos 0.25
            alpha 1.0
            linear 1.0 alpha 0.0
    if holvagyok == "furdo":
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 1.1
            xpos 0.3
            ypos 0.1
            alpha 1.0
            linear 1.0 alpha 0.0
    if holvagyok == "konyha":
        hide ferdporszivozikmagas1080
        show ferdporszivozikmagas1080:
            zoom 1.1
            xpos 0.07
            ypos 0.1
            alpha 1.0
            linear 1.0 alpha 0.0
    $ fekete = True
    hide screen ferdporszivoz
    $ csinalszvalamit = "semit"
    if porszivozfojasojobb == 1:
        if porszivozfojasobal == 1:
            if porszivoznapali == 1:
                if porszivozatjaro == 1:
                    if porszivozfurdo == 1:
                        if porszivozkonyha == 1:
                            $ porszivofeladet = 2
                            $ debravegigpan = 1
                            $ mamaholvan = "szobajaban"
                            $ debraholcsinal = "napalikusztum"
                            if holvagyok == "napaliban":
                                jump debraanapalibavissza2
    jump engedejek

$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
