label szedvicsel:
    $ kivelbeszelsz = "szedvics"
    $ fekete = True
    jump tiltasok
label szedvicselszov:

    show screen szedvicskerdes

$ renpy. pause(hard=True)
label szedvicselszov2:
    $ szendvicsmilesz = True
    hide invertori onlayer elotte6
    hide screen szedvicskerdes
    hide screen invertori2
    show megettsedvics1:
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 3.0
    d "I prepared the sandwich for Grandma. I told you I won't serve you!"
    f "I am sorry, I thought you put this on the table for me…"
    d "Ask your mother to make you a sandwich!"
    show megettsedvics2:
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 2.0
    f "She died when I was born. I never had a mother."
    show megettsedvics3:
        alpha 0.0
        linear 2.0 alpha 1.0
    pause 2.0
    d "Oh well… I will prepare another for Grandma."
    hide megettsedvics1
    hide megettsedvics2
    hide haznappalitanyer
    hide nappalisedvics
    show megettsedvics3:
        alpha 1.0
        linear 2.0 alpha 0.0
    pause 2.0
    hide megettsedvics3
    show invertori onlayer elotte6:
        yalign 0.0
    jump engedejek
$ renpy. pause(hard=True)
label szedvicselszov3:
    $ szendvicsmilesznemetted = True
    $ debratmertkeresed = "sedvics"
    hide screen szedvicskerdes

    jump debratolkerdezel

$ renpy. pause(hard=True)
label szedvicsinvertoriba:
    $ szendvicsmilesz = True
    $ szendvicsinvertoriba = True
    show haznappalitanyer:
        alpha 1.0
        linear 2.0 alpha 0.0
    show nappalisedvics:
        alpha 1.0
        linear 2.0 alpha 0.0
$ renpy. pause(hard=True)
label szedvicskeszites:
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    $ csinalszvalamit = "szendvics"
    jump tiltasok
label szedvicskeszitesszov:
    hide screen invertori2
    hide invertori onlayer elotte6
    if debraholcsinal == "konyhaeszik":
        hide debrakonyhabaneszikanim onlayer hatso
        hide debrakonyhabaneszikalap onlayer hatso
        show debrakonyhabaneszikanim
        show debrakonyhabaneszikalap
    hide konyhazoldelol onlayer elotte
    show konyhazoldelol
    show szenyohater:
        alpha 0.0
        linear 2.0 alpha 1.0
    show szenyokenyer:
        alpha 0.0
        linear 2.0 alpha 1.0
    if szedvicbenvaj == True:
        show szenyovaj:
            alpha 0.0
            linear 2.0 alpha 1.0
    if szedvicbenparizsi == True:
        show szenyoparizel:
            alpha 0.0
            linear 2.0 alpha 1.0
    if szedvicbenszalami == True:
        show szenyoszalami:
            alpha 0.0
            linear 2.0 alpha 1.0
    if szedvicbensalata == True:
        show szenyosalata:
            alpha 0.0
            linear 2.0 alpha 1.0
    if szedvicbenkecsap == True:
        show szenyoketchu:
            alpha 0.0
            linear 2.0 alpha 1.0
    if szedvicbenmajonez == True:
        show szenyomajonez:
            alpha 0.0
            linear 2.0 alpha 1.0
    if szedvicbenmustar == True:
        show szenyomustar:
            alpha 0.0
            linear 2.0 alpha 1.0
    pause 2.0
    hide szenyohater
    show szenyohater
    hide szenyokenyer
    show szenyokenyer
    if szedvicbenvaj == True:
        hide szenyovaj
        show szenyovaj
    if szedvicbenparizsi == True:
        hide szenyoparizel
        show szenyoparizel
    if szedvicbenszalami == True:
        hide szenyoszalami
        show szenyoszalami
    if szedvicbensalata == True:
        hide szenyosalata
        show szenyosalata
    if szedvicbenkecsap == True:
        hide szenyoketchu
        show szenyoketchu
    if szedvicbenmajonez == True:
        hide szenyomajonez
        show szenyomajonez
    if szedvicbenmustar == True:
        hide szenyomustar
        show szenyomustar
    show screen szedvicsepites
$ renpy. pause(hard=True)
label szedvicbenvaj:
    $ szedvicbenvaj = True
    show szenyovaj:
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label szedvicbenkecsap:
    $ szedvicbenkecsap = True
    show szenyoketchu:
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label szedvicbenmajonez:
    $ szedvicbenmajonez = True
    show szenyomajonez:
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label szedvicbenmustar:
    $ szedvicbenmustar = True
    show szenyomustar:
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label szedvicbenparizsi:
    $ szedvicbenparizsi = True
    show szenyoparizel:
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label szedvicbenszalami:
    $ szedvicbenszalami = True
    show szenyoszalami:
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label szedvicbensalata:
    $ szedvicbensalata = True
    show szenyosalata:
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label szedvicskilep:
    hide screen szedvicsepites
    hide szenyohater
    hide szenyokenyer
    hide szenyovaj
    hide szenyokenyer2
    hide szenyoketchu
    hide szenyomajonez
    hide szenyomustar
    hide szenyoparizel
    hide szenyosalata
    hide szenyoszalami
    $ csinalszvalamit = "semit"
    show screen invertori2
    show invertori onlayer elotte6:
        yalign 0.0
    if debraholcsinal == "konyhaeszik":
        show debrakonyhabaneszikanim onlayer hatso
        show debrakonyhabaneszikalap onlayer hatso
        hide debrakonyhabaneszikanim
        hide debrakonyhabaneszikalap
    show konyhazoldelol onlayer elotte
    hide konyhazoldelol
    jump engedejek
$ renpy. pause(hard=True)
label szedvicskesz:
    hide screen szedvicsepites
    if hanyadiknapvan == 2:
        $ szedvicskesz = True
        show szenyokenyer2:
            alpha 0.0
            linear 2.0 alpha 1.0
        pause 2.0
        hide szenyokenyer2
        show szenyokenyer2
        $ vanszedvicsed = True
        $ szendvicsinvertoriba = True
    if hanyadiknapvan == 3:
        $ szedvicskesz = True
        $ ennivini += 1
        $ vanszedvicsed2 += 1
        show szenyokenyer2:
            alpha 0.0
            linear 2.0 alpha 1.0
        pause 2.0
        hide szenyokenyer2
        show szenyokenyer2
        $ vanszedvicsed = True
    if hanyadiknapvan == 4:
        $ szedvicskesz = True
        $ ennivini += 1
        $ vanszedvicsed2 += 1
        show szenyokenyer2:
            alpha 0.0
            linear 2.0 alpha 1.0
        pause 2.0
        hide szenyokenyer2
        show szenyokenyer2
        $ vanszedvicsed = True
    if hanyadiknapvan == 9:
        $ szedvicsnalad = 1
        show szenyokenyer2:
            alpha 0.0
            linear 2.0 alpha 1.0
        pause 2.0
        hide szenyokenyer2
        show szenyokenyer2
    jump szedvicskilep
$ renpy. pause(hard=True)
label szedvicmegeszed:
    $ megetedvanszedvicsed  += 1
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    hide szenyovaj
    hide szenyokenyer2
    hide szenyoketchu
    hide szenyomajonez
    hide szenyomustar
    hide szenyoparizel
    hide szenyosalata
    hide szenyoszalami
    if hanyadiknapvan >= 3:
        $ ennivini -= 1
        if vanszedvicsed2 > 0:
            $ vanszedvicsed2 -= 1
$ renpy. pause(hard=True)
label szedvicsazinvertoribamamanak:
    if regell4resz == False:
        if szedvicbenvaj == True:
            if szedvicbenszalami == True:
                if szedvicbensalata == True:
                    if szedvicbenmajonez == True:
                        $ mamaszedvicsamitelfogad = True
    if regell4resz == True:
        $ mamanakkonyhaszedvics = True
        $ mamaszedvicsetker4resz = True
        show konyhatanyerszendvics

    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    hide szenyovaj
    hide szenyokenyer2
    hide szenyoketchu
    hide szenyomajonez
    hide szenyomustar
    hide szenyoparizel
    hide szenyosalata
    hide szenyoszalami
    $ mamaszedvicsetker4resz = True
    $ ennivini -= 1
    $ vanszedvicsed2 -= 1
    $ mamaszedvics = 2
    if hanyadiknapvan == 4:
        if ennivini == 2:
            if mamaszedvicsetker4resz == True:
                jump szedvicskilep
$ renpy. pause(hard=True)
label szedvicsazinvertoriba:
    if hanyadiknapvan >= 3:
        if vanszedvicsed2 < 2:
            $ szedvicskesz = False
            $ vanszedvicsed = False
            $ szedvicbenvaj = False
            $ szedvicbenkecsap = False
            $ szedvicbenmajonez = False
            $ szedvicbenmustar = False
            $ szedvicbensalata = False
            $ szedvicbenparizsi = False
            $ szedvicbenszalami = False
            hide szenyovaj
            hide szenyokenyer2
            hide szenyoketchu
            hide szenyomajonez
            hide szenyomustar
            hide szenyoparizel
            hide szenyosalata
            hide szenyoszalami
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 4:
        if mamaszedvicsetker4resz == False:
            $ szedvicskesz = False
            $ vanszedvicsed = False
            $ szedvicbenvaj = False
            $ szedvicbenkecsap = False
            $ szedvicbenmajonez = False
            $ szedvicbenmustar = False
            $ szedvicbensalata = False
            $ szedvicbenparizsi = False
            $ szedvicbenszalami = False
            hide szenyovaj
            hide szenyokenyer2
            hide szenyoketchu
            hide szenyomajonez
            hide szenyomustar
            hide szenyoparizel
            hide szenyosalata
            hide szenyoszalami
            $ renpy. pause(hard=True)
    $ szendvicsinvertoriba = True
    jump szedvicskilep
$ renpy. pause(hard=True)
label nincskenyer:
    if nincskenyeraszedvicshez == True:
        if kenyeretvetetem == True:
            $ debratolkenyeretkerni = 3
            $ nincskenyeraszedvicshez = False
            jump szedvicskeszites
    $ debratolkerdeznikenyer = True
    f "There is no bread. I can not prepare a sandwich!"
$ renpy. pause(hard=True)
label debralevesziaszedvicset:
    $ kivelbeszelsz = "debraesik"
    jump tiltasok
$ renpy. pause(hard=True)
label debralevesziaszedvicsetszov:
    hide screen debramitcsinaljon
    $ szendvicsinvertoriba = False
    if debraholcsinal == "konyha":
        show debrafoz:
            alpha 1.0
            linear 1.0 alpha 0.0
    show debraeszik1:
        ypos 0.08
        alpha 0.0
        linear 1.0 alpha 1.0
    pause 1.0
    hide debraeszik1
    show debraeszik1:
        ypos 0.08
    d "Thank you so much! I was so hungry and I came at the right moment.This sandwich looks cool!"
    d "I take it now but i don't owe you anything, right?"
    hide debraeszik1
    show debraeszik2:
        ypos 0.08
    d "This is jummy! I like salat and ketchup together..."
    d "But next time put in less ketchup. This is a bit too much for me..."
    hide debraeszik2
    show debraeszik1:
        ypos 0.08
    d "I should continue my work. Make a sandwich for Grandma, you are slow like a sloth!"
    $ debrakedvencszedvicse = False
    $ szedvicbenvaj = False
    $ szedvicbenkecsap = False
    $ szedvicbenmajonez = False
    $ szedvicbenmustar = False
    $ szedvicbensalata = False
    $ szedvicbenparizsi = False
    $ szedvicbenszalami = False
    $ szedvicskesz = False
    $ vanszedvicsed = False
    $ fekete = True
    show debraeszik1:
        ypos 0.08
        alpha 1.0
        linear 2.0 alpha 0.0
    pause 2.0
    jump engedejek
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
