label mosogas:
    if fifitfelvetem == True:
        f "I have Fifi, I can not do anything."
        $ renpy. pause(hard=True)
    if hanyadiknapvan == 3:
        if harmadikreszkonyha <= 5:
            f "I can wash the dishes after I am done with everything."
            $ renpy. pause(hard=True)
        if szenyeseltakaritasa < 2:
            f "I can wash the dishes after I am done with everything."
            $ renpy. pause(hard=True)
        if hoztejet < 2:
            f "I can wash the dishes after I am done with everything."
            $ renpy. pause(hard=True)
        if beszeljaszomszedokkal < 2:
            f "I can wash the dishes after I am done with everything."
            $ renpy. pause(hard=True)
    if hanyadiknapvan == 5:
        if szivacskimosasaproba == 0:
            $ szivacskimosasaproba = 1
            $ dolgozolmosogatas = 1
            f "I can not clean the sponge. I need to wash the dishes first."
            $ renpy. pause(hard=True)
    $ csinalszvalamit = "mosogat"
    jump tiltasok
$ renpy. pause(hard=True)
label mosogasszov:
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    show screen ferdmosogat
    show screen mosogatabahagy
    show ferdmosogat:
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi1anim:
        xpos 0.3
        ypos 0.35
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi2anim:
        zoom 0.8
        xpos 0.3
        ypos 0.35
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi3anim:
        zoom 1.3
        xpos 0.3
        ypos 0.3
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
label mosogatabahagy:
    stop sound
    hide screen ferdmosogat
    hide screen mosogatabahagy
    if csinalszvalamit == "mosogat2":
        show konyhamosatlan2:
            alpha 1.0
            linear 2.0 alpha 0.0
    $ csinalszvalamit = "semit"
    $ fekete = True
    show ferdmosogat:
        alpha 1.0
        linear 2.0 alpha 0.0
    show bubi1anim:
        alpha 1.0
        linear 2.0 alpha 0.0
    show bubi2anim:
        alpha 1.0
        linear 2.0 alpha 0.0
    show bubi3anim:
        alpha 1.0
        linear 2.0 alpha 0.0
    if hanyadiknapvan == 3:
        if harmadikreszvegehez == True:
            jump tvnezosjelenet
    jump engedejek
$ renpy. pause(hard=True)
label mosogataskesz:
    if hanyadiknapvan == 3:
        $ harmadikreszvegehez = True
    show konyhamosotedeny:
        alpha 0.0
        linear 2.0 alpha 1.0
    show konyhamosatlan:
        alpha 1.0
        linear 2.0 alpha 0.0
    if csinalszvalamit == "mosogat2":
        show konyhamosotedeny:
            alpha 1.0
        hide konyhamosatlan
    jump mosogatabahagy
$ renpy. pause(hard=True)
label debraeszik:
    if debraeszik == 1:
        $ debraeszik = 2
        $ esteighatralevoido = 0
        show konyhaeste:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrakonyhabaneszikanim:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrakonyhabaneszikalap:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debraiszik3resz:
            xzoom -1.0
            xpos -0.45
            alpha 0.0
            pause 5.0
            linear 1.0 alpha 1.0
    if debraeszik == 0:
        $ debraeszik = 1
        show debrafoz:
            alpha 1.0
            linear 1.0 alpha 0.0
        show debrakonyhabaneszikanim:
            alpha 0.0
            linear 1.0 alpha 1.0
        show debrakonyhabaneszikalap:
            alpha 0.0
            linear 1.0 alpha 1.0

$ renpy. pause(hard=True)

label kimosniaszivacsot:
    $ csinalszvalamit = "mosogat2"
    jump tiltasok
label kimosniaszivacsotszov:
    show screen mosogatabahagy
    show screen ferdmosogat
    queue sound "audio/surolhossz.ogg"
    queue sound "audio/surolhossz.ogg"
    $ szivacskoszoslettidoszamol = False
    $ szivacskoszoslettido = szivacskoszoslett * 0.5
    hide konyhamosatlan2
    show konyhamosatlan2:
        alpha 0.0
        linear 2.0 alpha 1.0
    hide ferdmosogat
    show ferdmosogat:
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi1anim:
        xpos 0.3
        ypos 0.35
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi2anim:
        zoom 0.8
        xpos 0.3
        ypos 0.35
        alpha 0.0
        linear 2.0 alpha 1.0
    show bubi3anim:
        zoom 1.3
        xpos 0.3
        ypos 0.3
        alpha 0.0
        linear 2.0 alpha 1.0
$ renpy. pause(hard=True)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
