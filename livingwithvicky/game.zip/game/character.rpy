

define v = Character("[vicky_nick]", color="#3cb371")
define vi = Character("[vicky_nick]", color="#3cb371", what_prefix="{i}", what_suffix="{/i}", what_color="#ff5500")
define d = Character("[vicky_ex_nick]", color="B50000")
define mc = Character("[player_name]", color="#4169e1")
define n = Character("[player_name]", color="#4169e1", what_prefix="{i}", what_suffix="{/i}",what_color="#ff0000")
define s = Character("Sabrina", color="9acd32")
define e = Character("employee", color="#ffffff")
define t = Character("Tracy", color="#f984ef")
define cas = Character("Casandra", color="#fff000")
define sa = Character("store associate", color="#ffffff")
define L = Character("Lexi", color="#ffffff")
define b = Character("Beth", color="#ffffff")
define sal = Character("Sally", color="#ffffff",)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
