label prologue:

show text "PROLOGUE" with dissolve
pause 

scene sc9038 with dissolve

n "I just packed a bunch of boxes waiting on the moving van..."

scene sc9039 with dissolve

n "It's been a long divorce battle between my [vicky_nick] and [vicky_ex_nick]."
n "I'm actually going to miss this place, we've had a lot good times here."

scene sc9040 with dissolve
pause

scene sc9041 with dissolve

mc "I'm about done packing [vicky_nick]..."

scene sc9042 with dissolve

mc "Will you be sad about leaving this place?"
n "I always love sneaking up on her..."


scene sc9043 with dissolve

n "She always let's out the cutest little noises when she's startled..."
v "Oh! [player_name], well of course I'll be sad. I'm going to miss it!"
v "But you we can't look back, it's times like these that bring us even closer."

scene sc9044 with dissolve

mc "I know, there are just so many memories here..."
v "We will make new ones at the new place."
v "Can't be afraid of change, this can be new and exciting."

scene sc9045 with dissolve

v "And you know, you're looking at it all wrong."
v "What if we move to our new place, get settled in, you get a girl friend, start school and find new friends?"
v "It could be fun, you can start fresh."
mc "Yeah, I guess."

scene sc9046 with dissolve

v "I don't want you to be stressed out about this move!"
mc "I'm not, I just wasn't prepared for this..."
v "I promise you we will be ok and we will spend more time together, it'll be great!"
n "She was always so positive about things!"
v "Hey come help me wipe off some dust off those high shelves."
v "I just need a spotter so I don't fall..."

scene sc9047 with dissolve

v "Here let's get that chair and boost me up..."

scene sc9050 with dissolve

v "Up here!"

scene sc9051 with dissolve

v "Just make sure I don't fall!"
n "Oh man, does she know she's wearing a skirt?"

scene sc9052 with dissolve

mc "Uh, like this?"
v "Yes, that's good."
v "I forget how much I'm afraid of heights!"
n "Man her skin is so soft and warm!"

scene sc9053 with dissolve

n "Oh shit! I can see straight up her skirt!"
n "I don't think she even realizes it..."

scene sc9054 with dissolve

n "The more she struggles the more her skirt rides up."

scene sc9055 with dissolve

mc "are we all done now?"

scene sc9048 with dissolve

v "These boxes will go with the movers..."
mc "Yes, [vicky_nick]..."

scene sc9049 with dissolve

n "Oh wow, I can see down her top..."
n "She's been working all day and still manages to look so good!"

scene sc9056 with dissolve

v "All that is left is to load the car with our presonal belongings!"
mc "Very good, can't wait to be done."
v "Oh, you're a trooper..."

scene black with dissolve

n "Today we are moving to a house that my [vicky_ex_nick] gave to [vicky_nick] in the divorce. I have no idea what to expect."

scene sc9057 with dissolve

mc "I already loaded up your bag."

scene sc9058 with dissolve

v "I hope you were careful with my stuff."
mc "I was very careful [vicky_nick]."

scene sc9059 with dissolve

v "Did you pack all your clothes that you're going to wear this summer?"
v "Don't forget anything because I'm not sure what's available for shopping!"
mc "I am sure I packed everything."

scene sc9060 with dissolve

v "Sorry I must be nagging you already?"
v "Y'know, I was hoping we'd be able to bond somewhat considering it's just you and me."
mc "Of course [vicky_nick], now we have all that time together with no interruptions."
mc "I think we will have a great time."

scene sc9061 with dissolve

v "I don't mean to get this way, it's just I'm kind of nervous about this trip, I hope we get settled in ok."
mc "You worry too much, [vicky_nick]."

scene sc9062 with dissolve

menu:
    "What should I do?"
    "Lift skirt.":

        n "I've been creeping on her since I can remember."
        n "She's always been such a beautiful woman."

        jump rightaway
    "Just hug her.":

        n "Too risky to lift her skirt, I'll just hug her."

        jump later

label rightaway:

scene sc9063 with dissolve

n "I've been getting handsy with her lately trying to gain her trust."

scene sc9064 with dissolve
pause

label later:

scene sc9065 with dissolve

v "[player_name]!"

scene sc9066 with dissolve

mc "I can't wait to spend some time with you [vicky_nick]."

scene sc9067 with dissolve

v "We're going to have a great time!"
v "Can you believe it, this next place is going to be our new home."

scene sc9068 with dissolve

mc "And I'm so glad we're going to have it to ourselvse."
mc "Just you and me, peace and quiet."
vi "The way he said that and how he is holding me is a bit strange..."
v "Oh [player_name], you make it sounds so nice."

scene sc9069 with dissolve

v "We should start driving before it gets too dark."
mc "There's a little motel on the way there that we can spend the night. I'll pull it up on the map."

scene black with fade

scene b014 with dissolve

n "We are on our way to our new home, and I'm as excited as can be."

scene b015 with dissolve

n "I've always wanted to be near her, but always had something or someone in the way."

scene b016 with dissolve

n "First, my [vicky_ex_nick] left and my [sabrina_rel] left to stay with him."
n "Finally it's just us."

scene b017 with dissolve
pause  

scene b018 with dissolve

v "Oh my, this place looks run down."
mc "It's the only place available, we can manage for tonight."

scene b019 with dissolve

v "There's only one bed..."
mc "I'll sleep on that side."

scene b018 with dissolve

v "Ok, as long as you don't feel uncomfortable."
mc "Well, it's been awhile since I had a good cuddle."

scene b020 with dissolve

v "Stop joking, I don't want this to get weird."

scene b019 with dissolve

mc "Who is joking? I am about share a bed with a beautiful woman?"

scene b021 with dissolve

v "See that's what I mean!"

scene b018 with dissolve

v "I don't want it to get weird."
mc "It won't get weird. I promise to behave."

scene b022 with dissolve

v "Well, I have my boundaries please respect them."

scene b023 with dissolve

v "Shoot, I forgot my pajamas in the other bag."
mc "Want me to go get them out of the car?"

scene b024 with dissolve

v "Not unless you're ok with me sleeping in my undies."
mc "Im totally ok with that, believe me."

scene b019 with dissolve

v "[player_name]..."

scene b025 with dissolve

v "I'm going to take a shower, I'm beat."
n "The teasing and back and forth started when [vicky_ex_nick] got caught cheating on [vicky_nick]."

scene b026 with dissolve

n "After that I felt like I had to swoop in."
n "I think she notices me flirting with her, but I'm pretty sure she enjoys it."

scene b027 with dissolve
pause

scene b028 with dissolve

n "Oh, I got a text messege from my [sabrina_rel]."

scene b029 with dissolve


menu:
    "What should I do?"
    "Peek on [vicky_nick] in the shower":


        jump rightaway01
    "Check your phone.":

        n "Too risky."

        jump later02


label rightaway01:

scene b030 with dissolve

n "I can hear the water running. Maybe I can't take a look."

scene b031 with dissolve

n "man she really steamed up the place."

scene b032 with dissolve

n "I can just make out her ass through the steam."

scene b033 with dissolve

n "...and some curves. She sure is curvy!"
n " My phone is buzzing better see what Sabrina wants."

label later02:

scene b028 with dissolve

call phone_start from _call_phone_start
call message_start ("SABRINA", "hey") from _call_message_start
call message ("SABRINA", "Why didn't you text me when you got to the hotel?") from _call_message
call reply_message ("Didn't know I was supposed to.") from _call_reply_message
call message ("SABRINA", "Yeah either you or [vicky_nick] were supposed to text me wtf") from _call_message_1
call reply_message ("Sorry, what's going on") from _call_reply_message_1
call message ("SABRINA", "Nothing, I'm pissed. I've been waiting for an hour for one of you to reply") from _call_message_2
call reply_message ("Jeez calm down what do you need?") from _call_reply_message_2
call message ("SABRINA", "I'm with [vicky_ex_nick]") from _call_message_3
call reply_message ("ok and?") from _call_reply_message_3
call message ("SABRINA", "Nothing, I was thinking of coming over to the new house when you guys get settled in.") from _call_message_4
call reply_message ("We're not even there yet, relax.") from _call_reply_message_4
call message ("SABRINA", "I'm just saying.") from _call_message_5
call message ("SABRINA", "Oh, want to see the new place dad got?") from _call_message_6
call reply_message ("ok") from _call_reply_message_5
call message_img ("SABRINA", "see it", "images/B01/B060.png") from _call_message_img
call message ("SABRINA", "you like it?") from _call_message_7
call reply_message ("you or the apartment?") from _call_reply_message_6
call message ("SABRINA", "hehe, does it matter?") from _call_message_8
call reply_message ("Wait a minute, are you wearing any pants?") from _call_reply_message_7
call message ("SABRINA", "maybe, maybe not") from _call_message_9
call reply_message ("Show me?") from _call_reply_message_8
call message_img ("SABRINA", "Maybe I'm not so what", "images/B01/B061.png") from _call_message_img_1
call reply_message ("Why arent you wearing any pants?") from _call_reply_message_9
call message ("SABRINA", "Dad doesnt mind") from _call_message_10
call reply_message ("I'm sure he doesn't") from _call_reply_message_10
call message ("SABRINA", "Whatever, I'm going to go watch tv. Text me when you guys get there.") from _call_message_11
call reply_message ("bye") from _call_reply_message_11
call phone_end from _call_phone_end

scene b034 with dissolve
pause

scene b036 with dissolve

v "All done [player_name], your turn."
mc "Will you text Sabrina when we arrive?"

scene b037 with dissolve

v "Yes, I will text her first thing."

scene b038 with dissolve
v "The shower was nice!"

scene b039 with dissolve

v "This place is such a dump, I hope nobody was murdered in here."
v "I hope these sheets are clean."

scene b040 with dissolve

mc "If they're clean we should dirty them up."

scene b041 with dissolve

v "That's a really dirty joke, don't say that."
v "Keep your bodily fluids to yourself!"
mc "Where's the fun in that?"

scene b042 with dissolve

v "Hey, c'mon now."
mc "Ok, ok!"

scene b043 with dissolve

v "C'mon get in the shower...you dirty young man."
mc "Smooth."

scene b044 with dissolve

n "Man, all this teasing is getting me riled up."

scene b045 with dissolve
n "How am I supposed to sleep next to my [vicky_rel]?"

scene b046 with dissolve

n "Man, she's already reading."

scene b047 with dissolve

v "Wasn't that nice?"
mc "All clean for you now."
v "Hop in the bed!"

scene b048 with dissolve

v "You're being extra flirty."
mc "I don't know [vicky_nick], you're the only pretty woman here. What am I supposed to do?"

scene b049 with dissolve

mc "You don't like flirting with me?"
v "...I do, it's just not very appropriate."

scene b050 with dissolve

mc "I mean you are lying here in your panties and you expect me to be indifferent?"
v "Do I really need to put on some pants?"
mc "You think pants are enough to keep me away?"

scene b051 with dissolve

v "[player_name]! Anymore from you and you'll be sleeping in the car!"
mc "You want me to?"

scene b052 with dissolve

v "No, I'm just joking."
v "...You ready for bed?"

scene b053 with dissolve

v "Ok let's get some sleep"

scene black with fade

scene b054 with dissolve

n "Her light breathing wakes me up at night."

scene b055 with dissolve

n "I just want to kiss those lips."
n "The way she smells and the warmth of her body is making groin stir"
n "eventually I drift back off to sleep"

scene black with dissolve

show text "Morning."
pause

scene b056 with dissolve

v "[player_name]? Wake up."

scene b057 with dissolve

v "We have four more hours of driving. Let's get going."

scene b058 with dissolve

mc "Where's my morning kiss?"

scene b059 with dissolve

v "You better be in that car or you're walking!"
mc "OK ok, jeez."

scene black with fade

show text "On The Road Again."
pause

scene filler01 with dissolve

n "It's been awhile since [vicky_ex_nick] divorced [vicky_nick], they were seperated even longer before the divorce."
n "Today we are moving into one of [vicky_ex_nick]'s old rental properties."

scene prol004 with dissolve

n "He did not want to give it to [vicky_nick] but he had no choice."
n "I feel that [vicky_nick] deserves way more than this."
n "She has been great through out this whole ordeal."
n "I think it's because she's still quite young and is taking it very well."

scene prol003 with dissolve

n "She's great, real smart, very pretty...and she's really sexy too."
n "She looks like she should have been a model, but acts like she was destined to become a librarian."
v "We're almost there."

scene prol002 with dissolve

n "I don't think I'll miss [vicky_ex_nick] much, [vicky_nick] has been occupying my time."
n "I just can't believe he left such a fine piece of ass like my [vicky_rel]."

scene prol01 with dissolve

n "She's in her late thirties."
n "She's single because she keeps to herself, very modest and I rarely even hear her curse."
n "She doesn't go out much and would much rather enjoy spending ther free time reading a book."

scene prol02 with dissolve

n "But she's far from a book nerd, she's very sexy but I don't think she knows it."
n "I know it."

scene prol03 with dissolve

n "I can't take my eyes off of her."

scene prol07 with dissolve

n "I would watch her doing the most mundane tasks, and she somehow manages to make it sexy."

scene prol08 with dissolve

n "She does it so effortlessly."
n "It's crazy, she could have been a model for sure."

scene prol09 with dissolve

n "I've never desired anyone like I desire her."
n "Oh, the things I would do to her."

scene prol003 with dissolve

v "Yay, we're here!"
v "The longest two hours of my life! Something about driving in the contry side, it bores the hell out of me."
v "Glad you were here along for the ride."
mc "What are you talking about I slept through the whole thing."
v "You were with me in body."

scene filler02 with dissolve

mc "Neat little town."
v "Oh I love it, so quiet and peaceful."
v "Grab your bag. Let's go, I want to see what your [vicky_ex_rel] left us."

scene black with dissolve

show text "A NEW HOME"
pause

scene sce0101 with dissolve

v "Oh [player_name], isn't this great?"
v "Look at this place!"

scene sce0102 with fade

v "I don't remember it being this big."
mc "Must have been one of [vicky_ex_nick]'s love nests."

scene sce0103 with fade

v "Don't ruin it for me, [player_name]."
n "Man, two hours of driving I'm beat. Can't wait to just jerk off and go to sleep."

scene sce0102 with dissolve


v "Your [vicky_ex_rel] really knew his real estate."
v "I bet this is the smallest house he had to give up in the divorce."
mc "I doubt he notices it's gone."

scene sce0103 with fade

v "Oh this is going to be so nice! This whole palace all to ourselves."
v "It's going to be a great summer with you."
mc "I'm looking forward to spending some quality time with you."

scene sce0104 with dissolve

v "This place is so big I can hear it echo as we speak."

scene sce0105 with dissolve

v "Lets take a look."
v "I wonder where the bedrooms are?"

scene sce0106 with dissolve

v "Im just in love with our new place!"
v "We can get an L-shaped sofa and put it right in that corner..."
n "She's dreaming already, [vicky_ex_nick] hasn't even cut her a check."

scene sce0107 with dissolve

v "Aren't you glad you decided to stay with me and not your [vicky_ex_rel]?"
mc "I'm getting the feeling that I made the right choice."
n "Am I trying to be smooth with my [vicky_rel]?"

scene sce0108 with dissolve

v "Come on [player_name] let's explore."
mc "Right behind you, [vicky_nick]."

scene sce0109 with dissolve

n "CELL PHONE BUZZ"
v "Oh, that's my cellphone, I bet it's your [sabrina_rel]."
v "She must be worried sick, I left my phone in the bag and forgot to call her"

scene sce01010 with dissolve

n "Oh, wow. I can see down [vicky_nick]'s shirt"

n "[vicky_nick] is very sexy for her age, her skin looks so smooth."

scene sce01011 with dissolve

v "Yep it's your [sabrina_rel], she texted me twenty times and I missed it because I was driving."
v "I hope she's not worried, I better text her right now."
mc "What does she want?"

scene sce01012 with dissolve

call phone_start from _call_phone_start_1
call message_start ("Sabrina", "is my [player_sab_rel] behaving? You didnt text me for 4 hours") from _call_message_start_1
call message ("Sabrina", "I hope you guys made it") from _call_message_12
call reply_message ("oh sorry bb, we made it") from _call_reply_message_12
call phone_end from _call_phone_end_1

v "She's so silly."
v "She she's asking if you're behaving."
mc "She's one to talk, wonder how many guys shes going out with right now."
v "Hey, be nice. She's your little [sabrina_rel]."

scene black with fade

jump chapter1
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
