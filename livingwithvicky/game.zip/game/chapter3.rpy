



label chapter3:

scene black with dissolve

show text "Chapter 3" with dissolve
pause

show text "THE NEXT MORNING." with dissolve
pause

scene sc85n1

n "I cannot beleive what happened last night."

scene sc85n1 with dissolve

n "Did my [vicky_nick] really give me a blowjob?"

scene sc85n1 with dissolve

n "Was I dreaming the whole thing?"

scene sc85n2 with dissolve

n "I should check on her."
n "She seemed pretty upset after."

scene sc85n3 with dissolve
pause (2)

scene sc85n4 with dissolve
pause (2)

scene sc85n5 with dissolve

n "Man, there she is."
n "I still can't believe it."
n "She's sleeping like a baby."

scene sc85n6 with dissolve

n "I can't keep my hands off of her."

scene sc85n7 with dissolve

n "Let's see if I can keep her from waking up."

scene sc85n8 with dissolve

n "It's a shame really, I wanted to do so much more with her."

scene sc85n9 with dissolve

n "Those cute panties of hers."

scene sc85n10 with dissolve

n "Seems like she's sound asleep."

scene sc85n13 with dissolve

n "Her skin is delicious, I want to taste her."
n "Let's see what kind of fun I can have while she is asleep..."

menu:
    "Lick her feet.":


        jump lckfeet
    "Lick her ass.":

        jump lckass



label lckfeet:

    scene sc85n14 with dissolve

    n "My heart is beating so fast, I really hope she doesn't wake up!"

    scene sc85n15 with dissolve

    v "...Mmmm."
    n "That first lick got a response right away. Maybe she likes it."
    n "Even, her feet taste delicious."
    n "And I'm not even a foot guy."

    scene sc85n18 with dissolve

    v "Mmm....hmm."

    jump endlck



label lckass:

    scene sc85n16 with dissolve

    n "You don't have to ask me twice..."
    n "She tastes like lotion, a very fruity mix."

    scene sc85n17 with dissolve

    n "I absolutely love her smell."
    n "I would lick her ass hole if I could."

    jump endlck



label endlck:

scene sc85n19 with dissolve

n "Oh man she smells so angelic."
n "Her smell alone could make me cum."
v "...*sigh*."
n "I think I might have taken it too far...she's waking up."

scene sc85n20 with dissolve

v "...[player_name]?"
v "What are you doing?"
mc "Didn't mean to wake you..."
mc "I couldn't help myself, I'm still thinking about last night..."
v "You're what?"

scene sc85n21 with dissolve

v "What about last night?"
v "Jesus, are you perving on me while I'm sleeping?"
mc "A little bit, you didn't seem to mind..."
v "Are you crazy!?"

scene sc85n22 with dissolve

v "Get off me."
v "First of all nothing happened last night, you need to forget about it!"
mc "No way, I can't do that!"
v "Yes way, I don't even want to hear it!"

scene sc85n23 with dissolve

v "It's bad enough the things we've done."
v "But now you're creeping on me in my room as I'm sleeping!"
mc "Relax, honestly I think we're passed that part."
mc "If anything we should be sharing a bed by now!"

scene sc85n24 with dissolve

v "I don't fucking think so!"
v "You can't be serious!"
mc "Jesus why are you acting so crazy!"

scene sc85n25 with dissolve

v "Uhhh, crazy!?"
v "You don't even know what crazy is."
mc "Hey [vicky_nick], calm down its not that serious..."
v "I want you to leave my room, NOW!"

scene sc85n26 with dissolve

mc "I really feel like you're overeacting!"

scene sc85n27 with dissolve

v "I don't think so..."
v "Get out!"

scene sc85n28 with dissolve

mc "Jeez, she has never snapeed at me like that..."
mc "This feels terrible!"

scene sc85n29 with dissolve

"PHONE VIBRATES"

scene sc85n30 with dissolve

n "It's Sabrina, wonder what she wants..."

call phone_start from _call_phone_start_7
call message_start ("SABRINA", "hey") from _call_message_start_6
call reply_message ("what's up") from _call_reply_message_90
call message ("SABRINA", "Whatcha doing?") from _call_message_89
call reply_message ("Just hanging around, u?") from _call_reply_message_91
call message ("SABRINA", "Same but not really") from _call_message_90
call reply_message ("???") from _call_reply_message_92
call message ("SABRINA", "I dunno I'm kind of in a bind here") from _call_message_91
call reply_message ("Everything ok?") from _call_reply_message_93
call message ("SABRINA", "Not going to lie I need to get away from [vicky_ex_nick]") from _call_message_92
call reply_message ("Why? I thought you liked it there with him.") from _call_reply_message_94
call message ("SABRINA", "He's too controlling I need space") from _call_message_93
call reply_message ("Let me guess, he caught you doing something bad and now you're grounded?") from _call_reply_message_95
call message ("SABRINA", "LOL, no stupid") from _call_message_94
call reply_message ("You need money huh?") from _call_reply_message_96
call message ("SABRINA", "I know you don't have any") from _call_message_95
call reply_message ("Ok well what is it?") from _call_reply_message_97
call message ("SABRINA", "I need your help with something ") from _call_message_96
call reply_message ("What is it?") from _call_reply_message_98
call message ("SABRINA", "I think we should meet in person though. ") from _call_message_97
call reply_message ("Sounds serious, better not be an ambush") from _call_reply_message_99
call message ("SABRINA", "LOL stfu") from _call_message_98
call reply_message ("Ok, where do you want to meet?") from _call_reply_message_100
call message ("SABRINA", "Remember that park we used to hang out in?") from _call_message_99
call reply_message ("Yeah I remember") from _call_reply_message_101
call message ("SABRINA", "See you around 1pm?") from _call_message_100
call reply_message ("Gotcha") from _call_reply_message_102

call phone_end from _call_phone_end_7



scene black with dissolve

show text "THE MEETING."
pause

scene sc85n31 with dissolve
pause

scene sc85n32 with dissolve
pause

scene sc85n33 with dissolve
pause

scene sc85n34 with dissolve

n "Looks like my [sabrina_rel] has inherited [vicky_ex_nick]'s car."
n "She's always been a spoiled brat."

scene sc85n35 with dissolve
pause

scene sc85n36 with dissolve

n "Damn, she's actually a little babe."
n "She's always been a pain in my ass but seeing her now, almost like a stranger, is different."

scene sc85n37 with dissolve

s "[player_name]! Oh my gosh. I feel like it has been so long."
mc "I know I can't believe we haven't hung out sooner."
s "The distance doesn't help!"

scene sc85n38 with dissolve

n "Mmm, damn she's about 90lbs and smells really good."

scene sc85n39 with dissolve

n "She feels really soft in my arms."

scene sc85n40 with dissolve

s "How long has it been?"
mc "Well, since [vicky_nick] and [vicky_ex_nick] seperated I guess."
s "It feels like a hundred years..."
mc "That's a bit of an exaggeration."

scene sc85n41 with dissolve

n "Man, she's cute. Her skin is so fair."
n "She's younger than me but she has turned into a a little lady in no time."

scene sc85n42 with dissolve

s "Oh my gosh, I miss [vicky_nick], how is she?"
mc "She's good, we just settled into place that [vicky_ex_nick] had to give up in the dvorce."
s "I heard he gave her the one bedroom."
mc "We're making it work."
s "You've always made it work!"

scene sc85n43 with dissolve

mc "And [vicky_ex_nick]?"

scene sc85n44 with dissolve

s "He's actually a pain in my ass."
s "It's why I need your help..."
mc "He was always a pain in the ass."
mc "For everyone..."

scene sc85n45 with dissolve

s "Well he's an even bigger pain right now."
s "He's trying to kick me out of the house."
mc "What happened, last time we spoke you had it good."
s "He found about my modeling ambitions."
mc "You mean your Lonelypage?"
s "Umm, yeah so now I either stop what I've been doing or move out and do it full time."
s "And I know you have that nice camera of yours."
mc "Wait you want me to take sexy pictures of you?"
n "Holy shit I have to find her Lonelypage!"

scene sc85n46 with dissolve

s "Well yeah, I didn't think you'd mind."
s "And it's not graphic its mostly like vanilla."
mc "You'd have to show me..."

scene sc85n47 with dissolve

s "I will!"
mc "I mean if you don't mind that you're my [sabrina_rel]..."
s "Oh, come on, I always known you were a pervert."
mc "What makes you say that?"
s "Oh please, that camera of yours probably has more up skirts on it than my Lonelypage does."

scene sc85n48 with dissolve

n "Damn she's already a little slut."
n "[vicky_ex_nick] has to be pissed."
n "She's got some cute little titties, can't wait to see them now."
mc "Well I will obviously help you."

scene sc85n49 with dissolve

s "I'm not sure I can pay for your time yet."
mc "I'm sure we can work something out."

scene sc85n50 with dissolve

s "[player_name], if [vicky_ex_nick] finds out he'll definitely kick me out of the house..."
mc "I understand."
mc "I wouldn't worry about that."

scene sc85n51 with dissolve

s "Any chance I can come live with you and [vicky_nick]?"
s "I actually don't know how much longer I can live with [vicky_ex_nick]."
mc "Well, you know there isn't much room."
mc "[vicky_ex_nick] really screwed [vicky_nick] with that house."
mc "She would have to addon to the house or sell it and get a bigger house."
mc "And she does't have that kind of money, things are tight as it is."

scene sc85n52 with dissolve

s "I know but where else would I go?!"

scene sc85n53 with dissolve

s "You and [vicky_nick] are the only ones I have..."
mc "Well let's see how it goes with [vicky_ex_nick] then we will talk about it."

scene sc85n54 with dissolve

mc "For now, just keep a low profile."

scene sc85n55 with dissolve

s "Thanks so much [player_name]."
s "I don't know where I'd be without you..."

scene sc85n56 with dissolve

mc "Don't worry about it."

scene sc85n57 with dissolve

mc "And send me some pictures of what you'd like to do..."
s "Hehe, of course, you'll get your pictures."

scene sc85n58 with dissolve

n "Man, I can't wait to see what she has in store for me."
n "I better get back home and smooth things over with [vicky_nick]."



scene black with dissolve

show text "BACK HOME." with dissolve
pause

scene sc87 with dissolve

n "When I got home it was pretty awkward."
n "We hardly said anything to each other and I could tell she was thinking about what happened last night."

scene sc88 with dissolve
pause

scene sc89 with dissolve

n "I really tried to mind my own business, but the urge to apologize and kiss her and make up was unbearable."

scene sc811 with dissolve

n "She only wore that to make sure I didn't get any funny ideas."
n "She tries to be boring just to spite me."

scene sc812 with dissolve

n "But I could still make out her curves through her conservative get up."

scene sc813 with dissolve

n "The tension is so high, I almost want to reach out and stop her."

scene sc814 with dissolve

n "I don't know if I was horny or not thinking straight, but I was certain that she wanted me to say something or stop her from leaving."

scene sc815 with dissolve
pause

scene sc816 with dissolve
pause

scene sc817 with dissolve
pause

scene sc818 with dissolve
pause



scene black with dissolve

show text "LATER THAT NIGHT" with dissolve
pause

scene sc819 with dissolve
pause

scene sc820 with dissolve
pause

scene sc822 with dissolve

n "That night I decided to let out some of that built up frustration by watching some porn on the TV."
n "I turned it up to insure she heard that I was watching porn."
n "I don't know what I was thinking that this would accomplish."
n "The video I chose had a young boy making love to an older woman."
n "It got me really hot and bothered."
n "I was really hoping she would walk out of her room and take care of me."

"PHONE VIBRATES"

scene sc820 with dissolve
pause

call phone_start from _call_phone_start_8
call message_start ("[vicky_nick]", "Hey") from _call_message_start_7
call reply_message ("Hey") from _call_reply_message_103
call message ("[vicky_nick]", "Are you watching a naughty movie?") from _call_message_101
call reply_message ("Maybe, why?") from _call_reply_message_104
call message ("[vicky_nick]", "I can clearly hear it.") from _call_message_102
call reply_message ("Really? would you care to join me?") from _call_reply_message_105
call message ("[vicky_nick]", "I can't believe you. ") from _call_message_103
call reply_message ("Are you still mad at me?") from _call_reply_message_106
call message ("[vicky_nick]", "I am still upset... ") from _call_message_104
call reply_message ("I need you right now please don't be upset.") from _call_reply_message_107
call message ("[vicky_nick]", "We can't be doing this. ") from _call_message_105
call reply_message ("We're fine, I think you're overreacting.") from _call_reply_message_108
call message ("[vicky_nick]", "I had you in my mouth!") from _call_message_106
call reply_message ("I know and I need it again!") from _call_reply_message_109
call message ("[vicky_nick]", "No!") from _call_message_107
call message ("[vicky_nick]", "This is so wrong!") from _call_message_108
call reply_message ("Please, I need you to let go of this denial.") from _call_reply_message_110
call reply_message ("Look at how terrible things are now.") from _call_reply_message_111
call reply_message ("We're not even talking.") from _call_reply_message_112
call message ("[vicky_nick]", "I hate it.") from _call_message_109
call reply_message ("Hate what?") from _call_reply_message_113
call message ("[vicky_nick]", "Not being able to talk to you.") from _call_message_110
call reply_message ("Look how in love we were as boyfriend and girlfriend.") from _call_reply_message_114
call message ("[vicky_nick]", "But we can't.") from _call_message_111
call reply_message ("This is the closest we've ever been.") from _call_reply_message_115
call message ("[vicky_nick]", "It feels so wrong.") from _call_message_112
call reply_message ("It might feel that way only because it's new.") from _call_reply_message_116
call message ("[vicky_nick]", "But I'm your [vicky_rel].") from _call_message_113
call reply_message ("All I have is you.") from _call_reply_message_117
call reply_message ("Look how close we've gotten lately.") from _call_reply_message_118
call reply_message ("I don't think it's wrong at all.") from _call_reply_message_119
call message ("[vicky_nick]", "I do feel closer to you, but still...") from _call_message_114
call message ("[vicky_nick]", "...do we really need to do all the sexual stuff?") from _call_message_115
call reply_message ("What can I say? I have needs.") from _call_reply_message_120
call reply_message ("Don't you have needs? I could help you too.") from _call_reply_message_121
call message ("[vicky_nick]", "Don't even start.") from _call_message_116
call reply_message ("I'm very horny [vicky_nick].") from _call_reply_message_122
call message ("[vicky_nick]", "Well it sounds like you have your night planned out, just turn it down.") from _call_message_117
call reply_message ("I want you though.") from _call_reply_message_123
call message ("[vicky_nick]", "I'm sorry.") from _call_message_118
call reply_message ("What are you wearing?") from _call_reply_message_124
call message ("[vicky_nick]", "ummm...") from _call_message_119
call reply_message ("Please [vicky_nick], what are you wearing?") from _call_reply_message_125
call message ("[vicky_nick]", "I'm wearing my pink night gown.") from _call_message_120

call reply_message ("What are you wearing under it?") from _call_reply_message_127
call message ("[vicky_nick]", "My panties.") from _call_message_121
call reply_message ("What color?") from _call_reply_message_128
call message ("[vicky_nick]", "My white cotton panties.") from _call_message_122
call reply_message ("yum") from _call_reply_message_129
call message ("[vicky_nick]", "Tell me what you're watching on the television.") from _call_message_123

call reply_message ("I'ts an older woman being taken by a much younger guy.") from _call_reply_message_131
call message ("[vicky_nick]", "Of course.") from _call_message_124
call reply_message ("I try and find videos with women that look like you.") from _call_reply_message_132
call message ("[vicky_nick]", "Oh?") from _call_message_125
call reply_message ("But none are as hot as you.") from _call_reply_message_133
call message ("[vicky_nick]", "OMG stop it...") from _call_message_126
call message ("[vicky_nick]", "...") from _call_message_127
call message ("[vicky_nick]", "Are you pleasuring yourself?") from _call_message_128
call reply_message ("Yeah you got me all hot and bothered now.") from _call_reply_message_134
call message ("[vicky_nick]", "Maybe this will help.") from _call_message_129
call message_img ("[vicky_nick]", "My panties", "images/SC8/SC8v1.png") from _call_message_img_7
call reply_message ("Oh god, yes [vicky_nick]!") from _call_reply_message_135
call message ("[vicky_nick]", "You're easy to please.") from _call_message_130
call reply_message ("I want more [vicky_nick].") from _call_reply_message_136
call reply_message ("I want to see what you look like down there.") from _call_reply_message_137
call message ("[vicky_nick]", "You're pushing it.") from _call_message_131
call reply_message ("...do you shave down there?") from _call_reply_message_138
call message ("[vicky_nick]", "I trim it, ok?") from _call_message_132
call reply_message ("Please show me.") from _call_reply_message_139
call reply_message ("You don't have to show me everything, just show me something.") from _call_reply_message_140
call message ("[vicky_nick]", "...") from _call_message_133
call message_img ("[vicky_nick]", "", "images/SC8/SC8v2.png") from _call_message_img_8
call reply_message ("Oh god that's so sexy.") from _call_reply_message_141
call message ("[vicky_nick]", "You are silly.") from _call_message_134
call message ("[vicky_nick]", "Ok I think this has gone far enough.") from _call_message_135
call message ("[vicky_nick]", "I'm going to sleep, goodnight.") from _call_message_136
call reply_message ("What? No way, you can't leave me like this!") from _call_reply_message_142
call message ("[vicky_nick]", "I'm sorry, finish yourself off and get some sleep.") from _call_message_137
call reply_message ("No way [vicky_nick] I'm coming in.") from _call_reply_message_143
call message ("[vicky_nick]", "WHAT? Wait no...") from _call_message_138
call phone_end from _call_phone_end_8

scene sc825 with dissolve

n "Fuck that I need her now."
n "She can't be teasing me like this..."

scene sc826 with dissolve

n "Fuck, she's trying to act asleep."

scene sc827 with dissolve

n "She can't really be sleeping, she was just texting me."
n "God damn that ass is sweet."
mc "Are you pretending to be asleep?"

scene sc828 with dissolve

v "Oh my gosh, [player_name]!"
v "I told you I'm sleeping."

scene sc829 with dissolve

mc "I need you, I'm so horny!"
v "[player_name], I know but please, let's not do that again."

scene sc830 with dissolve

mc "I love you [vicky_nick]."
mc "I'm sorry but I need it."

scene sc831 with dissolve

v "[player_name] what are saying..."
v "...No."

scene sc832 with dissolve

v "AAACK."

scene sc833 with dissolve

v "Hey, stop!"

scene sc834 with dissolve

v "Mmm."

scene sc835 with dissolve

n "She's so warm down there."
n "I start to run my fingers around her pussy."
n "I could feel fabric and skin pressing up against it."

scene sc836 with dissolve

v "No fingers!"
n "She's got a great grip on me."

scene sc837 with dissolve

v "NNNG."

scene sc838 with dissolve

n "Even though she's holding my hand, I have some room to fiddle her."
n "I run my fingers around where her clit should be."
n "She responds by breathing heavier."

scene sc839 with dissolve

n "I kiss and nibble on her neck."
n "Her skin taste a little like lotion but its sweet as hell."

scene sc841 with dissolve

v "OH, god..."

scene sc842 with dissolve

n "I come back around and kiss her lips, only to find her already waiting."

scene sc843 with dissolve

n "I jump over her to get a better angle."

scene sc844 with dissolve
pause

scene sc845 with dissolve

mc "I fucking love this so much, [vicky_nick]."
v "[player_name], please."
n "She doesn't even say stop, sounds like she has accepted her fate."

scene scsc8a1 with dissolve

v "Ok, what do you want?"
v "Let's get it over with."



menu:
    "Ask for Blow job.":
        jump bljob
    "Lick her pussy.":

        jump lckpuss


label bljob:

scene scsc8b1 with dissolve

v "A blowjob again?"
mc "Wow, that's the first time I ever heard you say it like that."

scene scsc8b2 with dissolve

v "Ok, try and make it quick and please, let me know when you're about to finish!"

scene scsc8b3 with dissolve

v "I'm serious, you need to make it quick."
mc "Can you just relax and enjoy it?"
v "Easy for you to say!"

scene scsc8b4 with dissolve
pause

scene scsc8b5 with dissolve

n "She puts me in her mouth, it's so warm and wet."
mc "Fuck, I love your mouth [vicky_nick]."

scene animation17 with dissolve

mc "MMm, Fuck [vicky_nick]."

scene scsc8b6 with dissolve

v "Mmmmm, look how big you get in my mouth."
mc "Fuck, I love when you talk dirty like that."
mc "More please."

scene animation17 with dissolve

mc "Mmm, That's it [vicky_nick]."

scene scsc8b8 with dissolve

mc "Oh god yeah, lick my balls too."
v "Mhmmm, <Slurp>."

scene animation18 with dissolve

n "Her spit is running down my taint as her mouth makes smacking noise against my balls."
mc "Suck me deeper [vicky_nick]."
n "She changes position to her elbows and knees."

scene animation20 with dissolve
pause

scene scsc8b12 with dissolve

v "<GASP> Uuhhh, you're so big."
mc "I feel like I'm going to cum soon, [vicky_nick]."

scene scsc8b11 with dissolve

mc "Mmm, Fuck [vicky_nick]."

scene animation19 with dissolve

mc "That feels so good [vicky_nick]!"

scene scsc8b6 with dissolve

v "Cum for me!"

scene animation17 with dissolve

mc "OH YEAH [vicky_nick]! I'm going to cum!"
mc "I'm cumming!"

scene scsc8b16 with dissolve
pause



menu:
    "Cum in her mouth.":
        jump cummouth
    "Cum on her face.":

        jump cumface



label cummouth:

scene scsc8b20b with dissolve

n "I Start to pump my cum into her mouth as I grunt away."
v "HMMMMPPHH."

scene scsc8b21b with dissolve

v "MMMmmmm."
n "She moans a little as I finish pumping her mouth full cum."

scene scsc8b22b with dissolve

mc "Oh god [vicky_nick], show me my cum in your mouth."
v "...Nnnn."

scene scsc8b23b with dissolve
pause

scene scsc8b24b with dissolve

n "Man I can see my cum in my [vicky_nick]'s mouth."
mc "Amazing."

scene scsc8b25b with dissolve

mc "Now swallow my cum [vicky_nick]."

scene scsc8b26b with dissolve
pause

scene scsc8b27b with dissolve

v "Did you enjoy that?"
mc "Fuck that's hot."

scene scsc8b28b with dissolve

v "You're a little freak."
v "I'm going to go wash up."
n "I'm absolutely spent."

scene scsc8b29b with dissolve

n "I feel myself drift off to sleep."

jump bljobpass

label cumface:

scene scsc8b17 with dissolve

v "Ahhhh! Jeez!"
mc "Fuuuuckk!"

scene scsc8b18 with dissolve
pause

scene scsc8b19 with dissolve

v "Oh my gosh that was a lot!"
v "Lucky I didn't get any in my eyes."
mc "Fuck [vicky_nick], you look so sexy covered in my cum like that."

scene scsc8b29b with dissolve

n "I feel myself drifting off to sleep."

jump bljobpass

label lckpuss:

scene scsc8a2 with dissolve

v "What are you doing!?"
mc "I want to make you feel good."
n "I spend no time fooling around and grab the sides of her panties and start to pull them down."

scene scsc8a3 with dissolve

v "I don't know."
v "I don't feel like you should be staring at my privates."
mc "Nonsense [vicky_nick], you've seen mine plenty of times."
v "Not by my choice!"

scene scsc8a4 with dissolve

n "Fuck, as soon as I started seeing a little bit of bush my heart started skipping."
n "My [vicky_nick]'s pussy hair!"
v "You were asking about my bush?"
mc "It's perfect."

scene scsc8a5 with dissolve

n "I slide her panties off completely."

scene scsc8a6 with dissolve

n "I can't make out her labia or any other details."

scene scsc8a7 with dissolve

n "I toss her panties on the floor."
mc "There's no turning back now."
v "..."

scene scsc8a8 with dissolve

v "This is a little embarrassing!"
mc "Are you kidding me?"
mc "You are so beautiful."
mc "This is a dream come true for me."
n "As I say that I spread her thighs to make room to get between her legs."
v "I don't like this..."

scene scsc8a9 with dissolve

n "I'm now inches away from her pussy."
n "It's smells so sweet, I can feel the heat radiating off of it."
n "Her labia is neatly folded and her clitoris hidden away."
mc "Oh my god [vicky_nick], you are so pretty down here."
v "I.., I think we should stop."
mc "Stop it, its too late for that."

scene scsc8a10 with dissolve

n "I waste no time and take the first lick."
n "Oh my god, I am in love. It's salty at first but doesn't taste bad."
n "I lick again and it tastes even better."

scene animation21 with dissolve

pause

scene scsc8a11 with dissolve

v "Oh god."
v "I can't believe you're doing this to me."

scene scsc8a12 with dissolve

n "I lick and suck on her pussy lips."
v "Oh wow."
n "I start to get a little adventurous with my tongue and circle around her little bean."
n "Then I make my way to her entrance with my tongue and return to the bean again."
v "Mmmmm."

scene animation21 with dissolve
pause

scene scsc8a13 with dissolve

n "Her breathing gets faster, and her abdomen starts to violently move up and down."

scene scsc8a14 with dissolve

n "She pulls her leg up, opening herself wider and I can tell she might be close."
n "I focus more on the clitoris, my tongue now buzzing from the friction."
n "Her wetness is all over my mouth and I can't help but think I am swallowing most of it."

scene scsc8a15 with dissolve

n "She pulles her other leg up, opening herself up wide, leaving herself completly vulnerable to me."
v "Oh fuck!"
n "I've rarely hear her cuss so this must be a good sign."
n "Cant help but notice her pubic hair keeps getting in the way of her now swollen clit."
n "I push the resilient pubes away with my tongue making a wet mess."

scene scsc8a16 with dissolve

v "Ohhhh, myyy fuckk."
n "she grunts very deeply, like she's possessed."
v "Oh, yes, yes, yes."
n "Her eyes roll in the back of her head."

scene scsc8a17 with dissolve

n "She grabs my head and pulls me further into her pubis."
n "As she grinds her pussy against my mouth, I begin to suck and flick my tongue on her clit."
v "uuuhuh, uuuhuh yes, please..."
n "I could cum hearing her moan like this!"

scene scsc8a18 with dissolve

v "UUUHHhhhhhhh, godddddddd."
n "She lets out what I feel is a low screech, something only woman in orgasm could summon."

scene scsc8a19 with dissolve

n "I could feel her cum."
n "Her legs gave out and almost crushed my head as her takes shuddering breaths."
n "Her breathing begins to settle down, as she comes down from her orgasm."

scene scsc8a20 with dissolve

n "She turns her head. Is it in shame?."
n "I watch her slowly drift of to sleep."

label bljobpass:



scene black with dissolve

show text "NEXT MORNING" with dissolve
pause

scene sc9101 with dissolve
pause

scene sc9102 with dissolve

n "Holy shit, I don't even remember falling asleep last night."

scene sc9103 with dissolve

n "I think I hear [vicky_nick] in the living room..."

scene sc9104 with dissolve

n "Oh she looks great doing the laundry."
n "I'm really hoping she's not mad about last night."

scene sc9105 with dissolve

mc "Hey [vicky_nick], what happened to my clothes?"

scene sc9106 with dissolve

v "Morning sleepy head, thought I'd do the laundry."
v "You kicked your pants off last night..."

scene sc9107 with dissolve

v "Why are you walking around naked."
v "Can you please wait a minute while I get you something to wear?"

scene sc9108 with dissolve

v "Can't be parading around the house like that!"
mc "Nothing you haven't seen before..."

scene sc9109 with dissolve

v "Please don't remind me!"
mc "Remind you of the fun we had?"

scene sc9110 with dissolve

v "No, actually reminds me of the little man you used to be!"
v "I Should find some of those baby pictures!"
mc "Oh, what heck [vicky_nick]? Not what I was getting at!"

scene sc9110 with dissolve

v "Jeez, where does the time go?"

scene sc9112 with dissolve

v "Now look at you, standing in front of me..."
v "All grown up!"

scene sc9113 with dissolve

v "I remember washing that penis."
n "What the heck?"
n "What kind of denial is she in?"
n "Is she making fun of me or something?"
n "But I'm not going to lie, this is turning me on..."
n "Her on her knees looking at me completely nude..."
n "Ok yeah, I'm turned on."

scene sc9114 with dissolve

mc "[vicky_nick], stop it."

scene sc9115 with dissolve

v "Huh, why is it moving?"

scene sc9117 with dissolve

v "It's swelling up!"
v "Why?"

scene sc9116 with dissolve

mc "Ugh, I don't know probably from you looking at me."

scene sc9118 with dissolve

v "Just by looking at you!?"
v "You've got to be kidding me."
mc "I don't know, but can you take care of it?"
v "Take care of it?"

scene sc9119 with dissolve

v "I don't think so, mister."
v "Here, I found you some boxers."
mc "Oh come on."

scene sc9120 with dissolve

v "Now!"

scene sc9121 with dissolve

mc "Ok, ok!"
mc "I just want you to know the affect you have on me."
v "I'm flattered, but now is not the time for this!"

scene sc9122 with dissolve

v "But you sure have grown into a young man."

scene sc9123 with dissolve

mc "Could not have done it without you, hehe."

scene sc9124 with dissolve

v "I really hope so."
v "Lately I feel like I've done more damage than good."
mc "Don't even say that."
mc "I desire you like this because you are so amazing."
v "Let me stop you there, Casanova."

scene sc9125 with dissolve

v "I'm going to go pull the sheets."
mc "Ugh, damn [vicky_nick], why are you such a tease!"

scene sc9126 with dissolve

n "Holy hell, those jeans look great on her."

scene sc9127 with dissolve

mc "Hey how about another date soon?"
v "I don't know, I'm not sure we should."

"PHONE VIBRATES"

n "It's probably Sabrina."
v "Sounds like you're pretty busy yourself."

scene sc9128 with dissolve

v "Psst, hopefully not too busy."
v "Don't forget about me..."
n "What the hell? First she denies anything happened"
n "Now she is teasing"

scene sc9129 with dissolve

v "A date does sound nice though."

scene sc130 with dissolve

n "Holy, shit yes! [vicky_nick] is ok for another date!"
n "Damn Sabrina is calling."

scene sc131 with dissolve

mc "Hello?"
s "It's Sabrina, what are you up to?"
mc "Hey, what's going on [sabrina_nick]?"

scene sc132 with dissolve

s "I'm in town, near you guys!"
mc "What brings you?"
s "Well remember how we talked about the whole modeling thing?"
s "With you taking pictures...?"
mc "I do remember you mentioning something about photos..."
mc "Something spicy, slightly naughty photos?"

scene sc134 with dissolve

s "Haha, maybe a little..."
s "We'll see how I feel, don't know how far I'd like to take it with you taking the pics..."

scene sc133 with dissolve

s "Hold on, let me send you my location, maybe you can pick me up here?"

scene sc134 with dissolve

s "Ok, sent."
mc "Cool, I'll be there in like twenty minutes..."
s "ok, thanks"
n "Nice, I really want to see what she has in mind."



scene black with dissolve

show text "PICKING UP SABRINA" with dissolve
pause

scene sc541 with dissolve

n "It was a little drive into town."

scene sc135 with dissolve

n "And there she is. So cute."

"HONK HONK"

scene sc136 with dissolve
pause


scene sc137 with dissolve

s "Hey mister can you give me a ride?"
s "Hehe, just kidding."
mc "Very funny. You look great."

scene sc138 with dissolve

n "Oh man, her little cleavage."
n "She has filled out!"

scene sc139 with dissolve

s "Alright! I'm so excited."
s "It's so nice to get away sometimes."
s "[vicky_ex_nick] has been riding my ass lately."
mc "Really? Why?"
s "Yeah, I snuck out a few times, that's probably why..."
mc "Pffft, Yeah dummy. What the hell are you thinking?"
s "Yeah yeah, he needs to get over it!"

scene sc140 with dissolve

s "A young girl's gotta live!"
mc "I guess!"
s "So where are we going and I hope you brought your camera!"
mc "Of course I brought the camera, how else would I get you naked, haha."
s "Ew, gross, perv!"

scene sc141 with dissolve

mc "I got a place in mind, it's an old park out of town."
s "We should grab a bite after!"
mc "Sounds like a date!"
s "You're hopeless..."



scene black with fade

show text "AT THE PARK - THE PHOTO SHOOT" with dissolve
pause

scene sc142 with dissolve

s "How the hell did you find this place?"
mc "Come on, what are you afraid of?"

scene sc143 with dissolve

s "I don't know looks a little run down?"
mc "Would you stop? Maybe you don't want to do this?"

scene sc144 with dissolve

s "Ok, ok. You're in charge."
s "Tell me what to do, I'm not used to this."
mc "Just relax and loosen up."

scene sc145 with dissolve

mc "This place looks great. Why don't you come up here?."

scene sc146 with dissolve

s "Ok, I'm coming."

scene sc148 with dissolve

s "Wow this place is like abandoned!"
mc "Maybe we'll see some ghosts or something."
s "Shut up before I leave you here."

scene sc149 with dissolve

mc "Ok, smile."
s "What already?"
mc "Yeah, I want to capture the natural you."
s "I'll trust you on that!"
s "Just make me look pretty please."
mc "That's not hard to do!"

scene sc150 with dissolve

s "Mmm I hope you mean that."
mc "I do!"

scene sc151 with dissolve

mc "Ok, switch poses."
s "You really think I'm cute?"

scene sc152 with dissolve

mc "Yes, you really took after [vicky_nick]."
s "Oh, my god how is she?"
mc "She's good!"
mc "[vicky_ex_nick] kinda screwed her and left her the one bedroom so I'm staying on the couch."
s "Holy shit, that sounds like him."
mc "Yeah it's fine though, we've gotten really close because of that."
s "I was hoping there would be room for me maybe."
s "...If things don't work out with [vicky_ex_nick]."

scene sc153 with dissolve

mc "Well, if it gets to that point, I'm sure we can make room for you."
s "You're sweet."
s "We'll see, maybe I can smooth things out with him."
mc "Just don't let him look at these pictures."
s "Why, not like they're naughty or anything like that."
mc "Not yet..."
mc "But if you really want better pictures, we're going to spice things up."

scene sc154 with dissolve

s "Spice things up?"
s "Hmm, what do you think?"
mc "That's up to you [sabrina_nick]."

scene sc155 with dissolve

s "Shit, you don't think it's weird or anything?"
mc "Weird why?"
s "Because you're my [player_sab_rel]."
s "Seems kinda wrong?"
mc "I don't think so."
mc "After all, we are keeping this professional right?"

scene sc156 with dissolve

s "Haha ok, the shirt might go... or just unbuttoned."
mc "I think you can go far with this modeling thing."
s "Oh you think so?"
mc "Yeah, [sabrina_nick] you look so good on camera."

scene sc157 with dissolve

s "You're just saying that because I'm undressing."
mc "Haha, what do you mean."
s "You're trying to get nude pictures."
mc "Would be some killer photos."

scene sc158 with dissolve

s "Ah there, I feel free!"
s "Set them free! HAHA!"
mc "Yeah that looks sexy!"
n "Damn, her nipples are so hard."

scene sc159 with dissolve

s "Ah, now I'm sexy?"
s "You're a perv!"
n "If only she knew the things I've done to [vicky_nick] already."
mc "That's good, up against the statue."

scene sc160 with dissolve

s "Like this?"
mc "Yeah, just like that and arch your back."
mc "It's your body, great pose, looking great."

scene sc161 with dissolve

n "This is going well. She's getting more comfortable..."

scene sc162 with dissolve

s "How's this?"
mc "Good, let loose."
s "Ok tell me what to do."

scene sc163 with dissolve

mc "Let's make it sexier, ok?"
s "How so?"
mc "Get down up against the statue."

scene sc164 with dissolve

s "Mmm, you're really enjoying this, huh?"
mc "I am actually. Why do you ask?"
s "I don't know why, it just feels like you're into it."

scene sc165 with dissolve

mc "I am, now lean back."
s "Um, [player_sab_nick], I'm wearing a skirt."
mc "Yeah I know..."
s "Haha, wow. So my panties will be on full display."
s "I just hope you're ready for that."

scene sc166 with dissolve

mc "You wanted sexy photos, you're going to get them."
n "She sits against the statue and her skirt falls away from her thighs."
n "I can make out her pink lace panties."

scene sc167 with dissolve

n "So hot, little panties covering her little mound."
n "I hope she doesn't notice I'm zooming in on them."

scene sc168 with dissolve

s "I guess I did ask for this."
mc "Don't be ashamed, there's nothing you should be ashamed of."
s "I know, it's just, you know, you're my [player_sab_rel]."
mc "Well if you can do this with me, then you'd be able to do it with any professional photographer."
s "I guess you're right."
s "What's next?"

scene sc169 with dissolve

mc "I think you know what's next."
s "I think I have an idea, I'm just shocked!"
mc "Why? You've seen models in other photo shoots."
s "Damn, I think your right, as long as these come out good."

scene sc171 with dissolve

s "It still feels weird, ugh."
s "I'm actually nervous."
n "Shit, my heart is racing too..."

scene sc172 with dissolve

n "I can see her hand slightly shaking."
n "She slowly reaches for the tip of her skirt."

scene sc170 with dissolve

mc "Wow..."
n "I can't just make out the shadow of her bush under the panties"
s "Shut up."
n "I see her blush real hard."
s "Take the pictures already!"

scene sc173 with dissolve

n "She quickly stands up to hide her crotch."
s "Jeez [player_name], really enjoying yourself..."
mc "Let's see the back side now."
s "Fuck... why are guys such perverts?"
n "I could hear her cursing under hear breath, but at the same time giving into my commands."
n "She yanks the back of her skirt for me to see."

scene sc174 with dissolve

mc "Very good."
mc "I love your tan lines!"
s "...Thanks"

scene sc175 with dissolve

n "Her lovely ass on display for me."
n "I think she's both ashamed and proud."

scene sc176 with dissolve

s "You like this? Just like this?"
mc "Yeah, very good [sabrina_nick]!"
n "I could almost hear her voice change tone. She went from a shy little girl to a horny little vixen."
n "She then sticks her ass out in a very seductive way."
s "Here you go you pervert!"

scene sc177 with dissolve

n "Once again she yanks her skirt."

scene sc178 with dissolve

n "I can see the little gap between her thighs."
mc "God, [sabrina_nick]. Thats really hot!"

scene sc179 with dissolve

s "Naughty, very naughty [player_sab_nick]."
mc "I think you are enjoying this just as much as I am..."
s "I would never admit to it!"

scene sc180 with dissolve

n "Let's see how much control I have over her."
mc "Lift your skirt up completely."

scene sc181 with dissolve

n "She doesn't say a word."
n "She pulls her skirt up by both ends."
n "Fuck! What an ass!"

scene sc182 with dissolve

n "I continue to snap the pictures."
n "My spank bank will be full."

scene sc157 with dissolve
s " I think that's enough for now."
mc "I agree and you did great!"
n "It would have been awesome if I could have got her completely nude though."

scene sc183 with dissolve

s "Can I see?"
n "Uh oh, I hope she doesn't suspect what I'll be jerking off to..."

scene sc184 with dissolve

s "Oh wow, these are really good."
mc "I still need to edit them, but I think this is a good start."
s "Wow, you really have an eye for this!"

scene sc185 with dissolve

s "These are pretty naughty though, I hope I can trust you with this?"
n "I know she's really asking me if I'll be jerking off to them."

scene sc186 with dissolve

mc "Of course you can trust me. What kind of perv do you think I am!?"
s "Well, I don't know."
mc "They're going to end up on the internet in the end anyway."
s "Yeah...so?"
mc "Well, you're going to have a lot of guys pleasuring themselves to these."

scene sc187 with dissolve

s "Oh my god!"
mc "Haha, what? I'm just telling you how it is."

scene sc186 with dissolve

s "A-A...Are you going to?"
mc "I am going to what?"
s "You know... Pleasure yourself to these pictures?"
mc "Well, I think you already know the answer to that question."

scene sc187 with dissolve

s "Oh my god, you're a complete pervert!"
s "I am going to pretend I didn't hear that, HAHA."
n "I could tell she feels a little uneasy, but turned on."
mc "Alright, looks like were good here, why don't we go get something to eat before before you have to go home."
s "Good idea! Let's go before it gets dark!"



scene black with dissolve

show text "GRABBING A BITE." with dissolve
pause

scene sc189 with dissolve

n "The ride there was quiet. But once and awhile I'd catch her looking over."
n "Every time she made a move, she released the most pleasant of fragrance, a very youthful rose scent."

scene sc190 with dissolve
pause 

scene sc191 with dissolve
pause 

scene sc192 with dissolve
pause 



scene black with dissolve

show text "THE CAFE" with dissolve
pause

scene sc193 with dissolve

s "How do you like the new arrangement?"
s "Living with [vicky_nick] must be kinda nice?"
mc "Yeah I don't mind it, we have definitely gotten closer."
s "Awe that's so nice!"
mc "Yeah it really is."
s "It probably really helps that [vicky_nick] is really pretty."
mc "Haha, you know what? It does!"
s "She could have totally been a model."
mc "I think so too, I tried telling her."
s "Shit, oh my god, you should have a photo shoot with her."
s "I bet that would make her feel hot again!"
n "She read my mind! I wonder what she would say if I told her I already took pictures of [vicky_nick]."
mc "Actually not a bad idea, maybe you can help!"

scene sc194 with dissolve

s "Oh wow, now we're talking."
mc "Well, hows dating life?"
s "Who me!?"
s "What the hell is dating!?"
mc "Damn, it's that bad?"

scene sc195 with dissolve

s "This is the closest thing to a date I've been on for a long time, haha."
mc "I don't believe that."
s "I'm not lying! Today has been the most action I've had in like, forever!"
mc "Maybe we can change that."

scene sc197 with dissolve

s "Haha, what?"
mc "I'm kidding."
s "I don't know you've already had me taking off my clothes!"
mc "That was for your Lonelypage page..."
mc "...but it was very nice."

scene sc196 with dissolve

s "I bet it was, for you."
s "I can't imagine you're still single!"
mc "Why is that?"
s "Oh, I don't know I guess because I'm enjoying myself right now."
s "I guess if I was any other girl, you'd be on your way."
mc "Well that's good to know."
mc "I'm really enjoying myself too."

scene sc194 with dissolve

s "Honestly more guys could learn a thing or two from you..."
mc "Well, you know we can keep doing this..."
s "Huh, doing what?"
mc "We should do this again."

scene sc197 with dissolve

s "...Go on a date? With your [sabrina_rel]?"
mc "Yes, why not?"
s "I guess, you're not weirded out by the thought?"
mc "Not at all."
mc "As a matter a fact, I think I've seen you in a new light today."
s "Stop it, I'm blushing."

scene sc198 with dissolve

s "Hey, you're not just trying to get in my pants are you?!"
mc "Haha, you're my [sabrina_rel] what kind of pervert do think I am."

scene sc199 with dissolve

s "It sounds like you are trying to charm my pants off."
mc "You're not wearing pants, I've seen it."

scene sc200 with dissolve

s "Oh, god you pervert!"
s "How can you be talking to me like that I'm your...."

scene sc201 with dissolve

L "I don't mean to interrupt..."
s "No troubles..."
L "Your order?"
s "I'm starving thank you so much!"
L "First date?"

scene sc202 with dissolve

s "Uhhh..."
mc "Yes it is actually."
L "Oh, that's so sweet!"
L "I'm sorry I don't mean to pry, but I kinda knew it when I saw you two from afar."
mc "Oh, how could you tell?"


scene sc203 with dissolve

L "Hmm, well, I could always tell when people are in love."

scene sc209 with dissolve

s "Oh, brother..."

scene sc204 with dissolve

L "I'm sorry?"
s "Oh, nothing just funny is all."
L "Hehe, oh good."
L "Well, enjoy and have a good night."

scene sc205 with dissolve

mc "Thank you."
L "See you two around..."

scene sc206 with dissolve
pause

scene sc207 with dissolve

n "Man it's really hard not to check her out."

scene sc208 with dissolve

s "Wow, really?"
mc "What?"
s "Checking out the waitress? Pick your chin up of the floor and stop drooling."
mc "She was nice!"

scene sc210 with dissolve

s "'See you two around...'"
n "I laugh inside as she imitates the waitress."
s "Really? The nerve of her."
s "Don't leave a tip, ok?"
mc "Hey relax, haha."

scene sc211 with dissolve

s "Shit, its getting late."
mc "Damn, already?"

scene sc212 with dissolve

s "I know, I really don't want it to end..."
mc "Well we don't have to."
s "Yeah I know."
mc "I hope [vicky_ex_nick] is not waiting up?"
s "No, he knows I'm with you."
mc "So stay a little longer..."
s "Ok sure, but what do we do now?"
mc "I don't know what do couples usually do after?"
s "Hehe, hmm let me think."

scene sc213 with dissolve

s "Oh, hey I know, let's get a better view of the town."
mc "From there?"
s "Yeah why not?"
s "Afraid of heights?"
mc "Actually maybe."
s "Silly, it's just some stairs."
s "Let's go."

scene black with fade

scene sc214 with dissolve

n "I'm panting. I need to get in shape."

scene sc215 with dissolve

s "Not a bad view, huh?"
mc "You can say that again..."
s "Not a bad view, huh?"
mc "Very funny little [sabrina_nick]"

scene sc216 with dissolve

s "Oh, wow."

scene sc218 with dissolve

s "Worth the climb huh?"
mc "Absolutely."

scene sc217 with dissolve

n "This is pretty romantic, maybe I can get somewhere with this..."

scene sc218 with dissolve

s "I don't get to do this often."
mc "Do what?"
s "I don't know, get out, do what I want?"


scene sc219 with dissolve

mc "Why not?"
s "Shit [player_name], I really need to get away from [vicky_ex_nick]."
mc "It's that bad huh?"
s "Yeah."

scene sc220 with dissolve

s "What do you think?"
s "Maybe I can come stay with you and [vicky_nick]?"
mc "Where would you sleep?"
s "I don't care, I'll sleep on the floor if I have too..."

scene sc221 with dissolve

s "I can cuddle up with you on the couch! I don't care!"
mc "That actually sounds nice!"
s "Kinda knew you'd like that, pervert."

scene sc222 with dissolve
s "But I'm serious."
s "I need to get out..."
s "So if you don't take me I'll have to go somewhere else..."

scene sc223 with dissolve
mc "Relax, no need to jump the gun."
mc "Can you tough it out for a little bit?"
s "Yes, I guess so."

scene sc224 with dissolve

mc "I just need a little time with [vicky_nick]."
mc "I'll just have to ease her into it."
n "Among other things and having her there with me and [vicky_nick] will certainly make it more complicated."

scene sc225 with dissolve

mc "In the meantime, work hard, we'll do more photo shoots and get you out of there."
s "Oh, that sounds nice [player_name]."
mc "And you if you really want this, you MUST do as I say?"
mc "If things don't work out, I don't want to hear or see you crying."
mc "Understood?"
s "Y-yes..."
n "Man, I love when women respond to my authroity."

scene sc226 with dissolve

mc "Hey..."
s "Yeah?"
mc "It'll be ok."
mc "I promise."

scene sc227 with dissolve

s "[player_name], I feel very safe with you."
mc "Good."

scene sc228 with dissolve

n "Fuck, this seems like a very good time to kiss her."
n "She's trembling."
n "But she's not denying me."

scene sc229 with dissolve

s "...Shit."
mc "What's wrong."
n "Shit, I better kiss her before she changes her mind."

scene sc230 with dissolve

n "Fuck."
n "It's like kissing [vicky_nick] the first time."
n "Feels so wrong. I am starting to get aroused, I really am a pervert."
s "...Mmm."
n "She let out a whimper."
n "Only our lips are interlocked."
n "I should try and add my tongue to the mix."

scene sc231 with dissolve
pause

scene sc232 with dissolve

n "I could feel her hands caress me."
n "Her breathing speeds up."
n "I need to open her mouth with my tongue."

scene sc233 with dissolve

n "I can feel her lips part and I take a chance."
n "My tongue plunges in after hers."
n "I could feel her warm spit, its refreshing."

scene sc234 with dissolve

n "This maybe lasts for thirty seconds, but it felt way longer."
n "I could feel her slowly push back."

scene sc235 with dissolve

s "Woah."
mc "What?"
s "I don't know what to say?"
mc "Don't say anything."

scene sc236 with dissolve

s "Ok..."

scene sc237 with dissolve

n "And with that we really didn't say much for the rest of the night."
n "I took her home right after."
n "What a night."



scene black with dissolve

show text "BACK HOME" with dissolve
pause

scene sc9e1 with dissolve

n "Shit, [vicky_nick] is still awake?"

scene sc9e2 with dissolve

mc "Hey, you waited up?"
v "...."

scene sc9e3 with dissolve
pause

scene sc9e4 with dissolve

n "She left the television on..."
n "No way she is this knocked out."

scene sc9e5 with dissolve

n "Well that explains it."
n "Looks like she almost finished the entire bottle! What a lush."

scene sc9e6 with dissolve

n "Oh, wow."
n "I'm actually very horny from the photo shoot with Sabrina, may be I can get my release with [vicky_nick]."

scene sc9e7 with dissolve

n "She always looks so good sleeping."
n "I'm going to touch her. I hope she doesn't wake up..."

scene sc9e8 with dissolve

n "Holy shit so smooth."
n "So soft."

scene sc9e9 with dissolve

n "What an amazing sight."
n "I need to undress her."

scene sc9e10 with dissolve

n "Damn she has nice tits!"

scene sc9e12 with dissolve

v "Hmmm...."
v "[player_name]...."
mc "H-Hey..."

scene sc9e11 with dissolve

mc "You fell asleep with the TV on..."
v "Oh, *hiccup* I think I fell asleep."
mc "You drank a lot."

scene sc9e13 with dissolve

v "Mmnnnn, a little bit..."
mc "Let me take you to your room."
v "I can...do it my self....ok?"
v "Why is my breast out?"

scene sc9e14 with dissolve

v "You're being a perv again!"
v "I'm going to... *hiccup* go to bed."
mc "Wait, why don't you stay awhile?"

scene sc9e15 with dissolve

v "What...no...please."

scene sc9e16 with dissolve

v "No, I need to go before this gets out of hand..."
mc "Wait, you can barely walk."
mc "Jeez, how much did you drink?"

scene sc9e17 with dissolve

v "Hey!"
mc "Look at you, you can barely stand!"
mc "Stay for a bit let me take care of you!"
v "No please... I can do this on my own"
v "Let me go pleaseee."
mc "Would you just relax!"

scene sc9e18 with dissolve

v "OH sh..."
mc "[vicky_nick]!"
mc "Careful!"

scene sc9e19 with dissolve

v "Ouch..."
mc "You ok?"
v "I'm sorry."

scene sc9e20 with dissolve

mc "Here, take my hand."
v "Wait let me just rest a little."

scene sc9e21 with dissolve

v "Just let me be..."
mc "Stop being so stubborn!"

scene sc9e22 with dissolve

v "Hey let me go!"
mc "Man you're a little heavy."
v "HEY!"

scene sc9e23 with dissolve

v "Nnnnnghh."
n "I feel like ripping her pants off."

scene sc9e24 with dissolve

mc "I'm going to make you comfortable."
mc "Let me take your clothes off..."

scene sc9e25 with dissolve

mc "UGh, come on."

scene sc9e26 with dissolve

v "Just let me sleep..."

scene sc9e27 with dissolve

n "Bingo! She is out of it."
n "I have to do this."

scene sc9e28 with dissolve

mc "Let me take these off of you."

scene sc9e29 with dissolve

n "Just like this..."
v "Hnnngg."

scene sc9e30 with dissolve

mc "Let's see what you'r hiding from me."

scene sc9e31 with dissolve

n "Oh wow."

scene sc9e32 with dissolve

mc "See, isn't that better?"
v "mmmpph."

scene sc9e33 with dissolve

n "Oh Wow, I rarely seen her wear thongs."

scene sc9e34 with dissolve

mc "Ok, now my turn."

scene sc9e35 with dissolve

n "Can't wait to bury my face in that ass."

scene sc9e36 with dissolve
pause

scene sc9e37 with dissolve

n "Holy shit, she smells so good."
n "I'm already hard."

scene sc9e38 with dissolve

n "My heart is beating so fast."
n "I hope she doesn't mind."

scene sc9e39 with dissolve

v "Oh...mmmm....ughhhhh."
n "I'm trying to lick through the fabric of her panties."
n "Making her panties damp."

scene sc9e40 with dissolve

n "I prop her up on her knees and bury my face into her crotch."
n "I'm going to ruin her panties this way, they're soaked."

scene sc9e41 with dissolve

v "Uhhh, yes.."
n "I think she's enjoying this!"
mc "I'm going to take your panties off."

scene sc9e42 with dissolve

v "MMm, noo."
n "She's not resisting much."

scene sc9e43 with dissolve
pause

scene sc9e44 with dissolve

n "Before I can remove her panties she flips over..."
n "Damn."

scene sc9e45 with dissolve

n "Oh, shit her panties shifted."
n "This is the first time I really got a good look at her pussy..."

scene sc9e46 with dissolve
pause



scene sc9e47 with dissolve

n "She's already responding just from my breath alone."
n "Initial lick was very salty, I could taste her sweat."
n "But it isn't repulsive, its actually very nice."

scene sc9e48 with dissolve

v "Ohhh, hmmph. Fuck."
n "This is a good sign."
n "Her fleshy lips roll and stretch from me sucking on them."

scene sc9e49 with dissolve

v "Oh shit..."
v "I need that so badly."
n "I was not ready to hear that!"
n "It's probably the alcohol."

scene sc9e50 with dissolve

mc "Please, [vicky_nick] let me give it to you!"
v "Just kiss me."

scene sc9e51 with dissolve

n "Oh damn, she's not holding back this time."
n "She's kissing me pretty aggressive."
n "Not that I mind..."

scene sc9e52 with dissolve

n "I don't think she noticed my naked erection yet."
n "I'm rubbing it on her exposed pussy."
n "The heat from her pussy is causing my dick to throb and ache."
n "My dick does not care that this is my [vicky_rel], it just wants to feel the hot velvet smoothness of a pussy."

scene sc9e53 with dissolve

n "Our making out slowly turns into me sucking on her neck."
v "Oh god yes."
mc "I want to cover you in kisses."
v "Please..."

scene sc9e54 with dissolve

v "Mmm."
n "Her mouth is sloppy on to mine."

scene sc9e55 with dissolve

v "Somehow you manage to make me feel so good."
mc "Please [vicky_nick], let me make you feel good."
v "I don't know not again..."
mc "Why? We deserve to feel good."
mc "You make me feel very good, when you feel good I feel great."
v "I really don't want this to become a habit."
mc "Just trust me, and enjoy yourself."
v "You could be right..."
v "I bet you want me to get out of these clothes?"
mc "Yes please..."

scene sc9e56 with dissolve

n "Fuck."

scene sc9e57 with dissolve

mc "You are so hot, mom..."

scene sc9e58 with dissolve
pause

scene sc9e59 with dissolve
pause

scene sc9e60 with dissolve

v "Hows this?"
mc "Amazing..."
v "You're so sweet."

scene sc9e61 with dissolve

n "Her moaning while kissing me is turning me on so much."

scene sc9e62 with dissolve

n "She's being very aggressive."
mc "Woah, you've been wanting this as much as I have, huh?"
v "I think it's the wine."

scene sc9e63 with dissolve
pause

scene sc9e64 with dissolve

mc "Woah, [vicky_nick], I love this new you."
v "Hehe, I hope so."
v "You're not scared?"

scene sc9e65 with dissolve

"muah"
n "I love feeling her saliva making its way into my mouth."

scene sc9e66 with dissolve

mc "I'm not scared at all."
v "Good, then I guess we have an understanding."
v "That this is probably as much educational as it is a fun activity."
mc "Definitely educational and very fun."

scene animation22 with dissolve

v "I can feel you getting so hard."
mc "Mmmhmmm, I need you."
v "I'm actually so proud of you, you've become such a healthy young boy."
mc "Can I put it in you?"
v "Absolutely not!"
mc "Then sit sit on my face..."
v "..."

scene sc9e69 with dissolve

v "Like this?"

scene sc9e70 with dissolve

n "Without hesitation I start to eat her."
v "Oh, god. YES."

scene sc9e71 with dissolve

n "I can feel her body turn clammy as her little asshole contracts as she orgasms."

scene sc9e72 with dissolve

v "Yes, right there. Right there, yes.. yes!."

scene sc9e73 with dissolve

n "Delicious little pussy."
v "Fuck, fuck, fuck."
n "I can feel her press down on my face."

scene sc9e74 with dissolve

v "Mmfmmph."
n "I can feel her engulf my dick as she begins to bob her head up and down."
n " Her tongue starts swirl around the head of my cock."

scene animation23 with dissolve
pause

scene sc9e77 with dissolve

v "Ahhhhh!"
n "She comes back up for air."

scene animation23 with dissolve
pause

scene sc9e78 with dissolve

v "Oh, god I'm so close!"

scene animation23 with dissolve
pause


scene sc9e79 with dissolve

v "Wait, wait, let me sit on your face some more."

scene sc9e80 with dissolve

v "OH, GOD, IM CUMMING!."
v "HNnnnnnnnnng!"
n "I feel her hips give a few violent jerks as she grinds her crotch on my face."
v "Oh my gosh, that was amazing."
v "I can't believe you just made me cum like that..."
v "My own [player_rel]..."

scene sc9e81 with dissolve

n "I don't want to stop licking her pussy."
v "I'm done. Get over here let's finish you off."
n "Never thought I'd hear words like that come out of her mouth."

scene sc9e84 with dissolve

mc "Like this?"
v "Yes."
mc "This will actually help me in the future."
v "Yes, I get it but it doesn't change the fact that it's wrong."
mc "Then why is it so hot?"
v "You are a very bad boy, you know that."
v "Now cum for me."

scene sc9e83 with dissolve

mc "Fuck, yes [vicky_nick] talk dirty to me?"
v "I don't know what to say..."
mc "Oh, please that's bullshit."
mc "C'mon say something outrageous."
mc "Say something hot..."
mc "Don't be shy now."
v "Ok, ok. I was never good at this."
mc "Well all that is going to change now."
v "Mm, just cum for your [vicky_nick]..."
mc "Mmm, that's a start."
v "Yeah, baby. I want you to cum all over my face."
mc "Fuck..."

scene sc9e84 with dissolve

v "I want to taste your hot cum..."
mc "Yes [vicky_nick]...please."
v "I love wrapping my mouth around your fat cock."
v "I want it to hit the back of my throat."
mc "Fuck, I'm so hard right now."
mc "I could pop any second now..."

scene sc9e85 with dissolve

v "Oh, I can see that."
v "Give me that cum."
mc "Put it in your mouth."

scene sc9e86 with dissolve

v "Hmmph!"
mc "OH yeah, I'm so close..."

scene sc9e87 with dissolve

n "I let out a loud grunt and explode unto her face."
mc "Phhfuuuuuuckk."
v "Oh!"
n "It still caught her by surprise."

scene sc9e88 with dissolve

n "My massive load covered her whole face, and as she went and put my cock back in her mouth I felt another load erupt into her mouth."
n "She only let out slight whimper, and then swallowed the remaining load."
v "Holy shit."

scene sc9e89 with dissolve

"..."
mc "How do you feel?"
v "You're expecting me to freak out huh?"
mc "I hope we're over that stage now."
v "I'm fine."
v "Luckily I'm still drunk."
v "And we can blame it on the drink again, ok?"
mc "Sure, [vicky_nick]."
mc "But did you feel as good as I did?"
v "You're going to make some girl very happy."

scene sc9e90 with dissolve

v "I know so, because I'm very happy right now."

scene sc9e91 with dissolve
v "Mmmmm."

jump chapter4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
