

image splash = "splash.png"

label splashscreen:

    scene black with fade

    show splash with dissolve
    with Pause(5)

    scene black with fade

    return



label start:

"THIS GAME CONTAINS ADULT CONTENT. YOU MUST BE 18 YEARS OF AGE TO PLAY THIS GAME. ARE YOU 18 YEARS OF AGE?"

menu:
    "ARE YOU 18 YEARS OLD?"
    "I AM 18 YEARS OR OLDER.":


        jump iam18
    "I AM NOT 18 YEARS OF AGE.":

        jump iamnot18

label iamnot18:
    scene sc6ps
    pause 3
    return


label iam18:



$ player_name = renpy.input("What is your name?")
if player_name.strip() == "":
    $ player_name = "Stan"

scene black with dissolve

"Before we start, who is Vicky to you?"

label set_variables:

$ vicky_rel = renpy.input("Vicky is my")
if vicky_rel.strip() == "":
    $ vicky_rel = "landlady"

$ vicky_nick = renpy.input("I call her")
if vicky_nick.strip() == "":
    $ vicky_nick = "Ms.Vicky"

"And who are you to Vicky?"

$ player_rel = renpy.input("I am Vicky's")
if player_rel.strip() == "":
    $ player_rel = "Tennant"

"Who is Vicky's ex-husband to you"

$ vicky_ex_rel = renpy.input("Vicky's ex-husband is my")
if vicky_ex_rel.strip() == "":
    $ vicky_ex_rel = "landlord"

$ vicky_ex_nick = renpy.input("I call him")
if vicky_ex_nick.strip() == "":
    $ vicky_ex_nick = "Stan"

"Vicky has a daughter, Sabrina. Who is Sabrina to you?"

$ sabrina_rel = renpy.input("Sabrina is my")
if sabrina_rel.strip() == "":
    $ sabrina_rel = "roomy"

$ player_sab_rel = renpy.input("I am Sabrina's")
if player_sab_rel.strip() == "":
    $ player_sab_rel = "House mate"

$ sabrina_nick = renpy.input("I sometimes call her")
if sabrina_nick.strip() == "":
    $ sabrina_nick = "Sabrina"

$ player_sab_nick = renpy.input("She sometimes calls me")
if player_sab_nick.strip() == "":
    $ player_sab_nick = "roomy"


"My name is [player_name]. Vicky is my [vicky_rel]. I call her [vicky_nick] and she calls me [player_name], she also calls me [player_rel]."
"Vicky's ex-husband is my [vicky_ex_rel]. I call him [vicky_ex_nick]"
"Sabrina is my [sabrina_rel], and I am her [player_sab_rel]. I sometimes call her [sabrina_nick] and she sometimes calls me [player_sab_nick]"

"Is this correct?"

menu:
    "Yes":
        "Lets begin"
    "No, that's still not right.":

        "Lets try again"

        jump set_variables



jump prologue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
