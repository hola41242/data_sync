label chapter2:

scene black with dissolve

show text "CHAPTER TWO" with dissolve
pause

scene fill06 with dissolve
pause

scene sc501 with dissolve

n "Damn, I slept like a rock. But I can't stop thinking about those pictures [vicky_nick] sent."
n "What a fox."

scene sc502 with dissolve

n "I had a hard time falling asleep, I was so damn horny."
n "This is absolute torture."

scene sc503 with dissolve

n "And now I smell something good!"
n "I think [vicky_nick] is making breakfast."
n "Man If I was a guy her age I'd put a ring on that finger."

scene sc505 with dissolve

n "She's the total package."
n "Damn! Look at that ass!"

scene sc506 with dissolve

mc "You making breakfast for me?"
mc "Why do I feel like I'm being rewarded?"

scene sc507 with dissolve

v "This is for being a good boy."
mc "Not what I was going for but I'll take it."


scene sc508 with dissolve

v "I hope you slept well."
mc "Oh yeah, a night I won't forget."

scene sc509 with dissolve

n "Jesus, her middrift looks so smooth."
v "I don't know what you're referring to."
mc "You know exactly what I'm talking about."

scene sc510 with dissolve

v "Jesus [player_name] don't start."
v "Promise me you'll delete those pictures."
mc "Don't worry [vicky_nick]."

scene sc511 with dissolve

v "I'm serious, mister."

scene sc512 with dissolve

mc "They're just between us to remind me of how beautiful you are."
v "I don't even want to know what you were doing after I went to sleep."

scene sc513 with dissolve

mc "Let's just say my hand is a little sore."

scene sc514 with dissolve

v "Oh my gosh, [player_name]! You can't just say things like that."
mc "Why? I'm not ashamed, I think you're the hottest woman I've ever seen."

scene sc515 with dissolve

v "Haha, Well now I know you're just lying to me!"

scene sc516 with dissolve

mc "You're body is a work of art."
n "She knows she's bending down in front of me giving me a good view."

scene sc517 with dissolve

n "Oh. My. God. I want to jump her right now."

scene sc518 with dissolve

n "I would eat those panties right off that sweet ass."

scene sc519 with dissolve

n "Oh, I have to make her my girlfriend, I think she might actualy play along."

scene sc520 with dissolve

n "She already takes care of me, now if I can get her to take care of me sexually."

scene sc522 with dissolve

v "All done?"
mc "That was really good [vicky_nick]."

scene sc523 with dissolve

v "What are you planning on doing today?"
mc "Actualy, I want to kiss you."

scene sc524 with dissolve

v "Kiss me?"
mc "Yes and I mean a real kiss."

scene sc525 with dissolve

v "[player_name], you can't..."

scene sc526 with dissolve

v "No, please stop."
v "You can't be doing this."

scene sc527 with dissolve

mc "Oh, [vicky_nick] I love you so much."
mc "This feels so good."

scene sc528 with dissolve

n "Damn, she pushed me off hard."
v "[player_name], I said no."

scene sc529 with dissolve

mc "Why we've already kissed, I enjoyed it and I know you enjoyed it to."
v "Yeah but we can't."
mc "[vicky_nick], I need you. We've already crossed that line."
mc "Also, you're an amazing kisser."

scene sc530 with dissolve

v "Well thank you for telling me."

scene sc531 with dissolve

v "I gotta admit I was always a great kisser."
v "Your [vicky_ex_rel] never liked to make out."
mc "Y'know, whenever you want to make out, I'm here."

scene sc532 with dissolve

v "...And that's my que."
v "I'm going to take a shower."
mc "Just saying I will make out with you."

scene sc533 with dissolve

v "Alright I'm out of here."
mc "Can I take the car to town?"
v "Sure but stay out of trouble."
n "Man, what I wouldn't do to make out with her right now."



scene black with dissolve

show text "THE TOWN" with dissolve
pause

scene sc534 with dissolve

n "I should check out the locals around town."
n "Maybe find a cutie or two I can mess around with if things go sour with [vicky_nick]."

scene sc535 with dissolve

n "I don't even want to watch anything."





scene sc537 with dissolve

n "I hope this place isn't one of those sleepy towns."

scene sc538 with dissolve

n "Hell, what am I saying i'm pretty much a recluse myself."

scene sc539 with dissolve
pause

scene sc540 with dissolve
pause

scene sc541 with dissolve

n "This place looks cozy."
n "It's small but its got charm."

scene sc552 with dissolve
pause

scene sc542 with dissolve

n "Exactly what I thought, this place has a hidden Gem."
n "Smells like a bakery and she has great buns."

scene sc542 with dissolve
pause

scene sc543 with dissolve

n "That's a pretty short uniform."
mc "Ahem."

scene sc544 with dissolve

e "Oh, sorry I didn't hear you come in."
mc "That's ok, I was enjoying the view."
e "What can I get you?"
mc "Actually I'm new in town, just stopping by."
mc "But I don't want to leave empty handed."

scene sc545 with dissolve

e "Oh, Gosh, welcome."
e "The town is a little quiet, but we would like to think we know how to live."
mc "Have you lived here all your life?"
e "Pretty much, my mother owns the bakery so I kind of have help out before I go back to school."

scene sc546 with dissolve

e "How about you, do you go to school?"
mc "Yeah but not right now, we just moved in up the highway."
mc "Once I get settled in maybe I'll see you in class?"

scene sc547 with dissolve

e "That would be nice."
e "Well, I gotta get back to cleaning but let's get you something for the road."

scene sc548 with dissolve

e "How about these muffins we keep all the way up here..."
mc "Careful now..."

scene sc549 with dissolve

n "Nice legs but I feel like shes going to eat shit."

scene sc550 with dissolve

e "There ya go."
e "Y'know this town is very pretty, If you live up the highway you're very close to the lake."
mc "Oh, hey that's great I'll take my [vicky_nick] there."
e "Check it out, it's real pretty."
e "And do stop by again, once you're all settled in."
mc "Will do! See you around."

scene sc551 with dissolve
pause

scene sc552 with dissolve

n "She sure was nice, would love to see her again."
n "I should come back another time and check out her mom."

scene filler02 with dissolve
pause

scene black with dissolve

show text "BACK HOME" with dissolve
pause

scene sc553 with dissolve

n "Wonder what [vicky_nick] is up to?"

scene sc554 with dissolve
pause

scene sc555 with dissolve

n "Maybe she's masturbating? I can only hope to get a peek."

scene sc556 with dissolve

n "What is she doing?"
n "Damn! Look at that body."

scene sc557 with dissolve

n "She's reading a book."
n "Love her legs, her perfect ass."
mc "Hey [vicky_nick], whatcha doing?"

scene sc558 with dissolve

v "Are you trying to sneak up on me?"
mc "Maybe, you do look comfortable."

scene sc559 with dissolve

mc "What are you reading?"
v "Oh I found this book in one of the moving boxes, I think I started reading it a while back, thought maybe I could finish it."

scene sc560 with dissolve

n "Fuck I want to touch her so badly."
mc "Oh, is it a romance novel?"
mc "Are you all hot and bothered now?"

scene sc561 with dissolve

v "Hey! Easy now."
mc "I can't help it [vicky_nick], I want to touch you so badly."

scene sc562 with dissolve

v "Well, please don't."
mc "Sorry [vicky_nick], I think I'm getting those urges again..."

scene sc563 with dissolve

v "Honey, please I'm your [vicky_rel], stop being such a pervert."
mc "You are so hot [vicky_nick], I need it."

scene sc564 with dissolve

v "Hey! You little shit."
v "Don't you dare!"
n "Oh fuck, she's mad!"

scene sc565 with dissolve

n "Never seen her move this quickly."

scene sc566 with dissolve

v "oh, you're scared now?"
v "You think you can touch your [vicky_rel] all you want?"
mc "You trying to overpower me?"
v "You think I'm weak or something?"

scene sc567 with dissolve

n "She's actually pretty strong, but I definitely have the upper hand."
mc "You won't win this."
n "I can trip her easily."

scene sc568 with dissolve

"THUD"
v "EEEeeeee!"

scene sc569 with dissolve

mc "Not so fast."
n "I can feel my pelvis rub into her groin area, it's soft and warm."
v "Ok, ok. I give up!"
mc "I have you where I want you..."
v "What a strong boy you've become!"
mc "I'm your strong boy, [vicky_nick]."
v "Ok, you can let me go now."
mc "Not until I get what I want."
v "Wh...what? What do you want?"
n "Here's my chance."

scene sc570 with dissolve

v "[player_name], No...."

scene sc573 with dissolve

n "My god her lips are so soft."
mc "I love kissing you so much."

scene animation1 with dissolve

n "This feels so good grinding her crotch. I probably could cum this way."
n "Fuck, I'm so hard."
n "With every thrust I can feel her breathing heavier."

scene sc573 with dissolve
pause

scene sc574 with dissolve

n "She's kissing me back, they're very wet kisses."

scene animation1 with dissolve

n "She's whimpering, I think she's might be enjoying this."

scene sc574 with dissolve

v "You want to know something..?"
mc "Yeah, [vicky_nick]?"

scene sc575 with dissolve

v "I took wrestling in high school."
n "With a swift move she flips me over."
mc "Hey, easy!"

scene sc576 with dissolve

"THUD"
v "Hahah, got you!"
mc "I was really enjoying that."
v "I know you were."
mc "Gotta admit though, I do like you on top."

scene sc577 with dissolve

v "Naughty, boy!"
mc "C'mon, were just playing. don't you like this?"

scene sc578 with dissolve

v "This very inappropriate."
v "I should get off."
mc "No way, I want you to stay on. I love feeling your body on me."
n "I could feel the heat radiating from her crotch on my dick, she's probably wet."

scene sc577 with dissolve

mc "I really like it when you grind on me."
v "[player_name]...no."
mc "I know it feels good for you too, just give me a few minutes of this..."
v "Mmmm..."

scene sc579 with dissolve

v "You're so cute."
mc "Love this side of you, [vicky_nick]."
v "You really do make me feel young again."
v "Like a little school girl..."

scene animation2 with dissolve

n "Fuck she's starting to grind on me."

scene animation3 with dissolve

v "Mmm."
mc "Yes, that feels good."
n "Fuck this is what it would look like if we were fucking right now?"

scene animation2 with dissolve

n "She's trying to hide her moans."

scene animation3 with dissolve

v "Uuhh."
mc "Fuck [vicky_nick], I could cum this way."

scene sc585 with dissolve

n "Shoot as soon as I said that, she jumped off in a panic."
v "Oh no."
mc "What, what happened?"

scene sc586 with dissolve

v "[player_name], I'm sorry I can't"
v "I didn't know that you were going to...I didn't want it to happen."
v "We can't be doing that."
mc "[vicky_nick], it's ok, it felt really good."
v "I know that's why we can't. It's so wrong."
n "Damn, what the hell."
v "[player_name], we have to stop."
mc "But [vicky_nick]..."
v "I don't want to talk about it anymore."
v "And I gotta make dinner soon, so... yeah."

scene sc587 with dissolve
vi "Damn, what am I doing? How did I get carried away and start grinding on my [player_rel] like that?"
n "Damn, that was so nice."
n "She's still a little shy but I can tell we're making real progress."
n "Maybe she needs a little more foreplay? Maybe she's way more loose when she drinks. We shall find out."

scene black with dissolve

show text "DURING DINNER" with dissolve
pause

scene fill05 with dissolve
pause

scene sc588 with dissolve

n "She didn't say a word during dinner."
n "It was just awkard silence."

scene sc589 with dissolve

n "I felt bad, I'm going to have to make her feel safe with me."
n "I'm going to make it right by her."

scene black with dissolve

show text "THAT SAME NIGHT" with dissolve
pause

scene sc9023 with dissolve
pause

scene sc9024 with dissolve
pause

scene sc9025 with dissolve
pause

scene sc9026 with dissolve
pause

scene sc9027 with dissolve
pause

scene sc9028 with dissolve
pause

scene sc9029 with dissolve
pause

scene sc9030 with dissolve
pause

scene sc9031 with dissolve
pause

scene sc9032 with dissolve
pause

scene sc9033 with dissolve
pause

scene sc9034 with dissolve
pause

scene sc9035 with dissolve
pause

scene sc9037 with dissolve
pause

scene black with dissolve

show text "NEXT DAY" with dissolve
pause

scene fill06 with dissolve
pause

scene sc535 with dissolve

n "I need to patch it up with [vicky_nick], last nights dinner was awkward."
n "Somehow I need to convince her that all this sexual tension is good for us."

scene sc5118 with dissolve

v "Ahem."
mc "OH hey, [vicky_nick]."
v "Hey, yourself..."
n "Man its still awkward.."
mc "Uh, you want to go on a little trip?"

scene sc5119 with dissolve

v "Go on a trip? To where?"
n "I'm going to take her to the lake the bakery girl mentioned."
mc "The girl at the bakery, mentioned a lake near us."
v "That sounds good, let's go."

scene black with dissolve

show text "THE PROPOSAL" with dissolve
pause

scene filler02 with dissolve

n "The ride there was awkward too."

scene sc5116 with dissolve

v "Where are you taking me?"
mc "The bakery girl suggested we check out this lake."
v "Bakery girl, huh?"
v "Is she pretty?"
mc "Are you jealous?"
mc "She's not as pretty as you that's for sure."

scene sc5117 with dissolve

v "I'm just asking."
mc "C'mon, let's check this place out."

scene sc590 with dissolve

v "Oh my, it's so pretty here."

scene sc591 with dissolve

v "Race you to the water!"

scene sc592 with dissolve

v "Wow!"
v "It's so green here!"
mc "Real nice!"

scene sc593 with dissolve

v "Oh, [player_name] I'm so glad I came."
v "The air is so fresh!"

scene sc594 with dissolve

v "Breathe that air! You can tell the difference from the city air!"

scene sc595 with dissolve

n "Her cute excited voice echoed from one side of the lake to the other."

scene sc596 with dissolve

v "Oh [player_name], this is what I needed!"

scene sc598 with dissolve

n "Damn her ass in those shorts looks amazing."

scene sc597 with dissolve

mc "I'm glad [vicky_nick]."
v "I sure do love nature."
v "Next time lets have a picnic!"

scene sc598 with dissolve

n "I can make out a faint panty line."
n "That drives me absolutely insane."

scene sc599 with dissolve

mc "Hey [vicky_nick] I don't want things to be awkward between us."

scene sc5100 with dissolve

v "Are things awkward between us?"
mc "Yeah."

scene sc5101 with dissolve

v "Shit, I'm sorry."
v "I don't mean it to be awkward."
v "I just don't know what to say or do."
mc "I just want you to say what you feel."
v "Well, I feel so wrong about the way we've been acting around each other."
mc "How is it wrong?"
v "Because we're [vicky_rel] and [player_rel]!"
mc "Okay, then lets not be!"
v "What?"
mc "[vicky_nick], I want you to be my girlfriend."

scene sc5102 with dissolve

v "[player_name], what are you saying?"
mc "I want you to be my girlfriend."
v "I don't understand."
mc "I want to know what its like to be with you."

scene sc5103 with dissolve

v "Thats crazy."
mc "Nothing would change, only our titles and how you would act around me."
mc "I want you to be more comfortable with me."
mc "Express your needs and wants easily without having to uphold some title of [vicky_nick]."

scene sc5104 with dissolve

mc "Please [vicky_nick], I want to treat you good and go on dates like a couple."
mc "I want to take care of you and love you."

scene sc5105 with dissolve

v "[player_name]..."
mc "And listen if you don't like it we can break up and go back to being [vicky_nick] and [player_rel]."
v "This is nuts..."
mc "Don't say anything right now, just agree. Give it some time and then like I said."
mc "If you don't like it we go back to being [vicky_nick] and [player_rel]."

scene sc5106 with dissolve

v "I.., ok, ok."

scene sc5107 with dissolve

v "And I guess if this makes you a better man for the next girl then it can't do any harm right?"
mc "There is only you [vicky_nick]"
v "Oh, [player_name]"
v "You are something else, you know that?"

scene sc5108 with dissolve

v "Just please please, we can't let it get out of hand."
v "I mean it."
mc "What do you mean by out of hand?"
v "Just hugging and kissing, no, you know...sexual things."
mc "I promise [vicky_nick], I love you too much."

scene sc5109 with dissolve

mc "You're my girlfriend now, give me a real kiss."
n "My heart dropoped as I said that. I couldn't believe my own confidence."
v "Mmm, my boyfriend hehe."
n "And to my suprise she gave in."

scene sc5110 with dissolve

n "We shared a long passionate kiss."
n "I think this is what she wanted."
n "Some kind of agreement with boundries for her to be able to do what she wants without feeling like a monster."

scene sc5111 with dissolve

n "This is exactly what I needed."
n "But I will test those boundries..."
n "This is great."

scene sc5112 with dissolve

v "Thank you, [player_name]."
v "You make me feel new again."
mc "You don't have to thank me!"
v "Now let's go home."
v "Oh but since you're my boyfriend now you have to give me a piggy back ride back to the car."
mc "Deal, hop on!"

scene sc5113 with dissolve
pause

scene sc5114 with dissolve

n "Just feeling her embrace me, her weight on my shoulders, the smoothness of her thighs in my hands is such a turn on."
n "...to hold my own [vicky_nick] like a woman."

scene sc5115 with dissolve

n "...A woman that is just for me."
mc "How about we go out for dinner tonight?"
v "That sounds wonderful!"



scene black with dissolve

show text "BACK HOME" with dissolve
pause

scene sc601 with dissolve

n "I've been waiting for for hours now!"
n "Never knew how long it would take her to get ready."

scene sc602 with dissolve

n "I'm getting antsy."
n "How long does it take to get ready?"

scene sc603 with dissolve

n "Man I can just imagine her showering nude right now."

scene sc604 with dissolve

"PHONE VIBRATE"

call phone_start from _call_phone_start_6
call message_start ("SABRINA", "hey") from _call_message_start_5
call message ("SABRINA", "What's going on with [vicky_nick]?") from _call_message_75
call reply_message ("What do you mean?") from _call_reply_message_77
call message ("SABRINA", "She hasn't texted me in awhile?") from _call_message_76
call message ("SABRINA", "You guys ok over there?") from _call_message_77
call reply_message ("Yeah were really good") from _call_reply_message_78
call reply_message ("Is that why your texting or is there something else") from _call_reply_message_79
call message ("SABRINA", "lol I can't just text u?") from _call_message_78
call reply_message ("cuz I know youre not just texting me just b'cuz") from _call_reply_message_80
call message ("SABRINA", "lol whatever") from _call_message_79
call message ("SABRINA", "when can I come visit?") from _call_message_80
call reply_message ("so you can ruin things between me and [vicky_nick]?") from _call_reply_message_81
call message ("SABRINA", "Are you serious?") from _call_message_81
call reply_message ("Thats what happened last time, that's why you're with dad") from _call_reply_message_82
call message ("SABRINA", "I'm with dad because he has money") from _call_message_82
call reply_message ("There it is. The truth comes out") from _call_reply_message_83
call message ("SABRINA", "Whatever you're just jelous.") from _call_message_83
call reply_message ("Sure thing. How's your modeling career going?") from _call_reply_message_84
call message_img ("SABRINA", "How do you think its going?", "images/SC6/SC6145.png") from _call_message_img_6
call reply_message ("Low qualtiy pics") from _call_reply_message_85
call message ("SABRINA", "I know, I need a real photographer!") from _call_message_84
call reply_message ("Yeah you do.") from _call_reply_message_86
call message ("SABRINA", "I really hope you still have your camera") from _call_message_85
call reply_message ("Of course I do.") from _call_reply_message_87
call message ("SABRINA", "Good then you can take pics of me") from _call_message_86
call reply_message ("Not for free!") from _call_reply_message_88
call message ("SABRINA", "Yeah yeah. We'll work something out!") from _call_message_87
call message ("SABRINA", "Gotta run!") from _call_message_88
call reply_message ("bye") from _call_reply_message_89
call phone_end from _call_phone_end_6

scene sc605 with dissolve

n "Sabrina is such a weirdo, but I wouldn't mind taking pictures for her."

scene sc606 with dissolve

mc "Hurry up [vicky_nick]! We're going to be late!"
n "What is taking so long?"

scene sc607 with dissolve

n "I should check on her."

scene sc608 with dissolve

n "I can smell her from here, it smells like her shampoo. It's a mix of fruitiness and tart."

scene sc609 with dissolve

n "Oh what the hell, is she crazy leaving her door open around me?"
n "She should know by now, unless she's doing it on purpose."

scene sc610 with dissolve

n "No way, she probably totally spaced out and didn't lock it."
n "She's still not that comfortable around me."

scene sc611 with dissolve

n "I need to get a better look though, this is my chance."

scene sc612 with dissolve

n "Oh, what a view."
n "I could hear her humming along to some tune.."

scene sc613 with dissolve

n "Holy shit!"
n "Man, I love [vicky_nick]'s curves."
n "I can't tell if she shaves down there..."

scene sc614 with dissolve

n "I sure am glad shes not pencil thin, this woman is the right thickness."

scene sc615 with dissolve

n "Shit man, I need to tell her we're late or else she's going to be in there forever!"
n "She's going to think I was spying on her but oh well!"
mc "[vicky_nick]! hurry up!"

scene sc616 with dissolve

v "Ok, ok!"
v "Almost done!"

scene sc617 with dissolve

v "Hey what gives, [player_name]!?"
v "Close the door right now!"

scene sc618 with dissolve

v "Don't be a little creep!"

scene sc619 with dissolve

mc "OK, [vicky_nick] but hurry up I made reservations!"
mc "Looks like I wont even have time to shower!"

scene sc620 with dissolve

n "Man What the hell!?"

scene sc621 with dissolve

n "Freaking women."

scene sc622 with dissolve

n "We're going to be so late!"

scene sc623 with dissolve

n "Maybe I can see what she's planning on wearing..."

scene sc624 with dissolve

n "Oh looks like her dirty clothing, what a mess."

scene sc625 with dissolve

n "She's usually cleaner than this."

scene sc626 with dissolve

n "Her panties are just laying there."
n "Again, I think she under estimates how perverted I am."
n "Can't leave me alone with her panties like that."

scene sc627 with dissolve

n "Even her panties are cute."

scene sc628 with dissolve

n "I gotta at least touch 'em."

scene sc629 with dissolve

n "Oh they're so soft."
n "I wonder if they smell like her?"

scene sc630 with dissolve

n "Holy shit, I'm so horny right now."
n "Her scent alone is driving me insane."

scene sc631 with dissolve

n "I can hardly contain myself."
n "Y'know this is her fault for taking too long."

scene sc632 with dissolve

n "Ah, shit I'm so hard..."
n "I need to jerk off right now."

scene sc633 with dissolve

n "Fuck! her smell is delcious, a hint of roses and vanilla..."

scene sc634 with dissolve

n "Fuck, I need her."
n "Just trying to imagine these panties wrapped around her little pussy."

scene sc6142 with dissolve

n "That fucking smile..."
n "Her sweet scent.."

scene sc635 with dissolve

n "I want to cum all over her."
n "I need to unload..."

scene sc6141 with dissolve

v "Hey [player_rel]..."
n "Holy hell, I want to tear her apart with my mouth.."

scene sc6143 with dissolve

v "My panties are getting so wet..."
n "Oh [vicky_nick], I would eat those panties right off of you."

scene sc6144 with dissolve

v "I'm going to cum...."

scene sc636 with dissolve

n "Fuuuuuuccckkkkk....."

scene sc637 with dissolve
pause

scene sc638 with dissolve

n "My god, that was intense."

scene sc639 with dissolve
pause

scene sc640 with dissolve
pause

scene sc641 with dissolve

n "I might as well get ready, no time to shower now..."

scene sc642 with dissolve
pause

scene sc643 with dissolve

v "Look at you!"
v "What a handsome boy."
mc "Really?"

scene sc644 with dissolve

v "What, I think you're very handsome!"
mc "Just handsome?"

scene sc645 with dissolve

v "What else could I ask for?"

scene sc646 with dissolve

mc "Say you want me."

scene sc647 with dissolve

v "[player_name]..."
mc "I don't want to be just handsome to you."

scene sc649 with dissolve

v "You know I can't say that."
mc "Why not?"
mc "Do I not turn you on?"

scene sc647 with dissolve

v "It's not that, I just can't say that."
v "It's wrong."
v "But I'll say this though..."
v "No one makes me feel the way you make me feel."

scene sc649 with dissolve

mc "You didn't feel this way with [vicky_ex_nick]?"

scene sc648 with dissolve

v "Even he didn't make me feel this way "

scene sc650 with dissolve

v "Now c'mon."
v "We have a date."

scene sc651 with dissolve

vi "Hmmm, I am sure I did not leave my panties rumpled up on the bed like that..."

scene black with fade

scene sc652 with dissolve
pause

scene sc653 with dissolve

n "Oh here we go..."

scene sc654 with dissolve
pause

scene sc659 with dissolve

n "Let me take this in."

scene sc655 with dissolve

mc "Damn, [vicky_nick]."

scene sc656 with dissolve

v "Oh, I'm never going to get used to you looking at me like that."
mc "You are so hot."

scene sc657 with dissolve

v "It's not too much though is it?"
mc "No way, you look so good."

scene sc658 with dissolve

v "You're so good to me."
v "You really know what to say."

scene sc660 with dissolve

v "Come on, I'm starving."
mc "Well if you weren't showering for six hours we'd be eating right now!"
v "Oh hush! Let's go you're driving."

scene black with fade

scene sc661 with dissolve
pause

scene sc662 with dissolve
pause

scene black with fade

scene sc663 with dissolve

v "I haven't been on a date in ages!"
v "I'm actually nervous."

scene sc664 with dissolve

mc "I can tell your hand is a little clammy."
mc "Also, I don't know if you remember but youre my girlfriend now."
n "She's so cute, I wonder if I'm making her nervous."

scene sc665 with dissolve

v "Yes, yes I know."
v "But you better behave, we're in public after all."
mc "But I expect you to act accordingly."

scene sc666 with dissolve

v "I don't even remember how to be a girlfriend."
mc "You're doing fine."

scene sc667 with dissolve

v "I'm not even going to lie, I do like the feeling."
v "Feels so new."
mc "Exciting?"

scene sc668 with dissolve

v "Exciting...and wrong."
mc "This is just the start."
v "..."

scene sc669 with dissolve

n "We order some food."
n "I couldn't wait to get her drunk."
n "So I ordered myself a beer and got her endless supply of wine."

scene sc670 with dissolve
pause

scene sc671 with dissolve

n "The food came out and [vicky_nick] started on her wine."
n "Half a glass and her jacket came off."

scene sc672 with dissolve

v "That's better."
mc "How can you be so gorgeous, [vicky_nick]?"

scene sc673 with dissolve

v "Silly, you're such a charmer."
mc "It's true. You are very beautiful."

scene sc674 with dissolve

v "[player_name], please. Stop."
mc "Hang on, don't start now."

scene sc675 with dissolve

v "I'm not starting anything I just feel like someone knows, we're in public."
mc "You think people can tell who you are?"
v "I feel like they can!"
mc "You don't even look your age!"

scene sc677 with dissolve

v "You saying I look that young?"
mc "Young and hot."
mc "Honestly, I want to see you out of that dress."

scene sc676 with dissolve

v "Hey, what if someone hears you!"
v "See you're being a pervert again."
mc "I don't get what you don't understand about this?"
mc "There's no going back, [vicky_nick]."

scene sc675 with dissolve

v "I don't want this to get out of hand!"
mc "Define 'out of hand?"
v "Y'know!"
mc "No I don't know, tell me."

scene sc674 with dissolve

v "The kissing."
v "The touching."
v "The looking."
mc "You're telling me those are things you don't like doing with me?"
v "..."
v "..."
mc "Tell me you don't like it..."

scene sc677 with dissolve

v "...I enjoy your attention..."
v "Ok. There I said it."
mc "I know you do."
mc "I wish you'd stop acting like you don't."

scene sc674 with dissolve

v "But its also so wrong for us to act like this around each other."
mc "I think that makes it more exciting."
v "I.., I don't know..."
mc "You're just afraid of where this might take us."

scene sc675 with dissolve

v "Of course I'm afraid!"
v "We've already done things, irreversible things!"
v "And now you want me to be your girlfriend?"
v "Who knows what..."
mc "Who knows what we'll do tonight?"

scene sc678 with dissolve

v "..."
mc "Why don't you drink your wine and you'll find out."

scene sc679 with dissolve

v "[player_name], please."
n "I have her shook."
n "She doesn't know what to say."
mc "Don't even say anything [vicky_nick]."
mc "I'm going to treat you like you're my lady and you better get used to it."
mc "Get used to all of it."

scene sc680 with dissolve

v "I mean I'm speechless."
v "You've become a man overnight it seems."
v "I do love all this time we're spending together."

scene sc681 with dissolve

mc "It's all I look forward to everyday."
v "But I can't help but get the feeling you're only trying to get me drunk all the time."
mc "What makes you think that?"

scene sc682 with dissolve

mc "Here drink up."
v "Mhmmm..."

scene sc683 with dissolve

v "Oh! clumsy ole' me."
mc "I got it."

scene sc684 with dissolve
pause

scene sc685 with dissolve
pause

scene sc686 with dissolve

n "Holy shit she's spreading her legs!."

scene sc687 with dissolve

n "I'm a little taken by surprise."
n "But I see she's snickering."
n "Looks like the wine is working"

scene sc688 with dissolve

v "Did you see anything interesting?"

scene sc687 with dissolve

v "Hehe, Oh my, I might actually be drunk..."

scene sc689 with dissolve

mc "I think were about done here."
mc "I'll try and get the waiter."

scene sc690 with dissolve
pause

scene sc691 with dissolve

mc "Finish your wine [vicky_nick]"
n "I couldn't wait to get her home."



scene black with dissolve

show text "Back Home" with dissolve
pause

scene sc693 with dissolve

n "I'm actually nervous, I think she might actaully give me some action."
n "I feel like I said the right things, this feels good."

scene sc694 with dissolve

v "My feet are killing me!"

scene sc695 with dissolve

v "[player_name], that was really lovely..."
n "Holy shit my heart is beating fast."
n "I don't know what to say."

scene sc696 with dissolve

v "I had a good time."
mc "...You want to watch a movie?"
n "What the fuck am I thinking, a movie!?"
v "No, [player_name] I'm tired and was thinking of going to bed..."

scene sc697 with dissolve

n "She's trying to leave me dry."
n "I can't let her blue ball me now!"
v "Goodni..."

scene sc698 with dissolve

v "Hey!"
mc "You want me to take you to bed?"

scene sc699 with dissolve

v "Careful!"
v "You're going to drop me, I might have gained some weight recently."
mc "I shouldn't have taken you to an Italian restaraunt, huh?"

scene sc6100 with dissolve

v "Haha, see you're admitting I'm fat!"
mc "Well, let me see then."
v "Huh, what are you doing!?"

scene sc6101 with dissolve

v "Oh my god, put me down!"
n "She can't stop giggling."
n "I love her little uncontrollable laughter."

scene sc6102 with dissolve

n "Her legs wrapped around me and I could feel the warmth coming from her crotch."

scene sc6103 with dissolve

v "You're such a strong man."
mc "It was all those moving boxes."

scene sc6104 with dissolve

v "[player_name] put me down!"
mc "Give me a kiss and maybe I will!"

scene sc6105 with dissolve

n "She smells a little bit of alcohol."
v "Here!...muah....muah!"

scene sc6106 with dissolve

v "I gave you kisses now put me down!"
mc "As you wish!"

scene sc6107 with dissolve

n "I toss her on the bed and falls gracefully like she was anticipating it all along."
v "Mmm, so nice!"
v "I'm going to sleep so well."

scene sc6108 with dissolve

v "What are you doing?"
n "She sounds a little worried."

scene sc6109 with dissolve

mc "Last time I showed you my penis you ran off!"
mc "I can't have you running off on me like that!"
v "No, wait!"

scene sc6110 with dissolve

mc "Please, [vicky_nick] I need you!"
v "What hell do you mean by that?"

scene sc6111 with dissolve

mc "I want you to make me cum."
mc "I feel like I'm going to burst I need some kind of relesae, please!"
mc "Don't torture me."

scene sc6112 with dissolve

v "Listen, if you're in pain you can take care of that on your own or use the pictures you already have of me."
mc "But I'm here with you and why not end the perfect night together."
mc "Please, [vicky_nick] just touch it!"
v "Oh. My. God. Keep your voice down!"

scene sc6113 with dissolve

v "Don't dare tell anyone about this!"
mc "Oh, god mom I won't, please take care of me."

scene sc6114 with dissolve

n "I could feel the nails of her fingers gently on the tip of my penis."

scene sc6115 with dissolve

n "And then I finally felt skin on skin contact, my [vicky_rel] was touching my dick!"

scene sc6116 with dissolve

"THUD"
n "She swiftly threw me on the bed, I'm in total shock."

scene sc6118 with dissolve

v "You're going to cum, but you're going to cum my way."

scene sc6119 with dissolve

v "No funny business, and make it quick, got it?"
mc "Oh, fuck."
mc "Yes, please."

scene animation4 with dissolve

n "The room fell silent, all I could hear is her breathing and the sound of her masterbating my cock."
n "It feels really good, her hand is so soft and she knows how to stroke it."

scene sc6117 with dissolve
pause

scene sc6118 with dissolve

v "...Cum for me."
n "Holy shit, as she starts talking like that I immedietly start to feel a hot rush in my balls."
mc "Please, [vicky_nick]."
v "You can do it, cum for me ..."

scene animation4 with dissolve

n "Her breathing get's faster as my dick gets rock hard."

scene sc6123 with dissolve

n "She knows I'm getting close. I wonder if she is getting turned on."

scene animation5 with dissolve

mc "Oh, [vicky_nick] talk dirty to me!"

scene sc6122 with dissolve

v "Give me your hot cum."

scene animation5 with dissolve

mc "Yes [vicky_nick], I want to give it to you..."
v "I want you to cum."

scene sc6124 with dissolve

v "I want you to cum so hard."
mc "yes keep going!"
v "...I want you to cum all over me."
mc "Fuck, yes [vicky_nick]."

scene animation5 with dissolve

v "...I want it...I want it inside me..."
n "As I realized what she just said, I felt a surge in my balls, and before I knew it..."

scene sc6125 with dissolve

mc "I'm coming."
mc "Uhhhhh."

scene sc6126 with dissolve
pause

scene sc6127 with dissolve
pause

scene sc6128 with dissolve
pause

v "[player_name]?"
mc "Yeah, [vicky_nick]?"
mc "What's wrong?"

scene sc6129 with dissolve

v "What did we just do?"
n "Reality sets in real quick. A rush of fear to the gut."
n "I better make this right."
mc "You just made me feel so good."
mc "I don't want you to feel any certain way right now, nothing at all."

scene sc6130 with dissolve

mc "All you need to think about right now is how happy you made me."

v "[player_name]..."

scene sc6131 with dissolve

mc "Don't say a word. Come here."
n "I kiss her gently on her forehead."
n "I then ease us down as I feel a slight resistance but I assure her that I only want sleep."

scene sc6132 with dissolve
pause

scene sc6133 with dissolve
pause

scene sc6134 with fade
pause



scene black with dissolve

show text "THE NEXT MORNING" with dissolve
pause

scene sc737 with fade

n "I hear rustling."

scene sc738 with dissolve

n "Hmm, [vicky_nick]'s no longer in bed with me."

scene sc739 with dissolve

n "I think she's getting ready."

scene sc740 with dissolve

n "Not a bad view to wake up to!"

scene sc741 with dissolve

n "I could certainly get used to this."

scene sc742 with dissolve

n "She has such a great ass..."

scene sc743 with dissolve

n "Love watching her get ready."
mc "Loving the view, [vicky_nick]."

scene sc744 with dissolve

v "Hey, I thought you were sleeping..."
mc "How about you get back in bed and we continue what we started last night?"

scene sc745 with dissolve

v "Oh, my god, don't get me started."
v "Can we not talk about last night?"
mc "To be honest it's all I can think about."

scene sc746 with dissolve

v "That was so wrong!"
v "It's not fair, you got me drunk again!"
mc "Oh, please. I know you wanted it."

scene sc747 with dissolve

v "[player_name], it's not funny."
v "We really have to stop this."

scene sc748 with dissolve

v "I mean I feel terrible!"
mc "Hey [vicky_nick], relax!"
mc "I really enjoyed it and I have no regrets about last night."
v "Of course you don't. But I do."
mc "Look I mean it."
mc "It was the best night of my life, that has to mean something to you?"

scene sc749 with dissolve

v "Really? The best night?"

scene sc750 with dissolve

v "Do you mean that?"
mc "Yeah [vicky_nick]."
mc "Isn't it obvious?"
mc "I mean why would I want to spend so much time with you if I wasnt having a good time."

scene sc751 with dissolve

v "Well, I was getting worried you might be getting lonely out here."
v "You haven't really made any friends."
v "Plus I think youd be better off meeting a girl friend out there, someone your age..."
mc "Now why would I do something like that?"

scene sc752 with dissolve

n "Damn look at that cleavage! Is she trying to seduce me?."

scene sc751 with dissolve

v "[player_name], I want you to find someone."
mc "I have someone right here."

scene sc750 with dissolve

v "No, I mean some who can take care of you."

scene sc753 with dissolve

n "I can't listen to her try and back out of this again."
n "No better way to shut her up but with a kiss."
v "...Mmm.."
n "She has slight morning beath but its sexy."

scene sc754 with dissolve
pause

scene sc755 with dissolve

v "I can't keep up with you!"
mc "Sorry I couldn't help it."
mc "I just don't want you to feel like we did something wrong."
v "I know. I was just not preapared for this."
mc "You're doing fine."
v "I hope so."
mc "Ok, come now."
mc "Now you're just stalling."
v "What do you mean?"
mc "Go on, woman. Make me breakfast."
v "Oh, my gosh."

scene sc757 with dissolve

v "You men are all the same, I swear!"
mc "Hehe, You better go now or get back in bed with me."
v "Understood, I am out of here."

scene sc758 with dissolve

n "Holy shit, How did I get so lucky?"

menu:
    "Check on [vicky_nick] in the living room.":
        jump lvngroom
    "Go help [vicky_nick] with laundry":

        jump lndry




label lvngroom:

scene sc702 with dissolve
pause

scene sc703 with dissolve
pause

scene sc704 with dissolve

v "I got some groceries, fresh fruit you want some?"

scene sc705 with dissolve

v "There's a little store up the road."

scene sc706 with dissolve

v "Very cute, there's also a cute girl in there working."
mc "You keep mentioning other girls, I'm not interested."
v "You should get out and meet people."

scene sc707 with dissolve

v "I mean you can't be a shut in."
v "I'd hate that for you."
mc "I don't mind being a shut in with you."
v "I'm not a shut in. You are!"

scene sc708 with dissolve
pause

scene sc709 with dissolve
pause

scene sc710 with dissolve
pause

scene sc711 with dissolve

v "Come have a banana."
mc "I don't like bananas."

scene sc712 with dissolve

v "You know bananas have potassium and potassium is good for your...you know."
v "Manhood..."

scene sc725 with dissolve

menu:
    "All of the sudden I have an urge to smack her sweet ass..."
    "Smack her ass":

        jump smackbutt
    "don't smack her ass.":

        jump dontsmckbutt

label smackbutt:

scene sc726 with dissolve
pause

scene sc728 with dissolve

"SMAACKKKK!"

scene sc729 with dissolve

v "Ouch!"
v "Hey What gives!"

scene sc730 with dissolve

v "[player_name], what the hell!"
mc "Sorry [vicky_nick] but I couldn't help myself!"

scene sc731 with dissolve

n "She looks shook, is she getting aroused?"
v "Thats not okay, I want you to be able to control yourself."
mc "I'm just in a playful mood, what can I say?"

scene sc732 with dissolve

v "Oh my gosh. You sound so much like your [vicky_ex_rel] right now."
mc "Well, then you already know!"

jump cont

label dontsmckbutt:

scene sc713 with dissolve

mc "All the sudden your worried about my manhood?"

scene sc714 with dissolve

mc "I want to see you eat it, but make it sexy!"

menu:
    "Force her to eat the banana":
        jump nxt

label nxt:

scene sc715 with dissolve

v "Hey, what the..."

scene sc716 with dissolve
pause

scene sc717 with dissolve

v "HHHkkksss...."

scene sc718 with dissolve

v "Heyyyymmmm!"
mc "That wasn't very deep!"

scene animation6 with dissolve

mc "Let me help you a little..."

scene sc720 with dissolve

"SNAP!"

mc "Hey woah, easy!"

scene sc721 with dissolve

mc "Almost took my finger off."
v "Hmm!"

scene sc722 with dissolve

v "Don't mess with me, boy."
v "I got teeth."

scene sc723 with dissolve

v "It's good, you want a bite?"
mc "No, I'm good."

label cont:

scene sc725 with dissolve

mc "Oh by the way, let's have date night tonight."
mc "But let's stay in, I'll cook and set the table?"

scene sc733 with dissolve

v "Oh, that sounds real nice, [player_name]."
mc "Wear something cute..."

scene sc730 with dissolve

v "OH, I see. Is this going to turn into another wild night with you?"
v "Please, I can't have that again!"
mc "Oh would you relax, you really feel like things have been that bad?"

scene sc732 with dissolve

v "We've already done too much."
v "We've crossed so many lines already."
mc "Last couple of nights were amazing..."
mc "All this fun just means we're good company!"
mc "I really enjoy it!"

scene sc733 with dissolve

v "I enjoy being with you but, last night..."
mc "Now stop thinking about it, and I'll see you in a couple of hours."

scene sc734 with dissolve

v "OK."
mc "Go on..."

scene sc735 with dissolve

v "Yes. yes! Don't get so pushy..."
v "I think I will wear my red dress tonight..."
n "Oh she wants it, already teasing so that means she's not that worried about turning up the heat."

scene sc736 with dissolve

n "I love the way her ass jiggles as she walks away."

jump dinner

label lndry:

scene sc762 with dissolve
pause

scene sc763 with dissolve

n "She's an absolute angel."
n "I used to make excuses just to linger around her."

scene sc764 with dissolve

n "I'd sneak around as she did housework and try to look up her skirt."

scene sc765 with dissolve

n "I wouldn't even know what to do, I would just stand there."
v "I don't even know where these stains came from..."

scene sc766 with dissolve

n "I'm not even listening."

scene sc767 with dissolve

n "How can I even pay attention to what she's saying.."

scene sc768 with dissolve

mc "I have no idea, that's why I say we get rid of all the white sheets, they stain the most."
v "I know if it was up to you, you'd never do laundry."

scene sc769 with dissolve

v "Oh, [player_name] who's ever going to put up with you?"

scene sc771 with dissolve

mc "I just need you to put up with me."
mc "It's just laundry, I hate doing it but I love watching you do it."

scene sc768 with dissolve

v "Ah, makes sense. You're just here to keep me company then."
mc "Yeah, moral support."

scene sc769 with dissolve

v "Sure sure."
v "Y'know I can feel you staring at me."

scene sc770 with dissolve

v "You think I don't know you're being a perv?"
mc "Can you blame me?"
v "Next time you're doing the laundry."

scene black with fade
pause (2)

jump cont

label dinner:



scene black with dissolve

show text "LATER THAT NIGHT" with dissolve
pause

scene sc772 with dissolve

n "Ok, lets set the table and..."
n "Lets set the mood."

scene sc773 with dissolve
pause

scene sc774 with dissolve
pause


scene sc775 with dissolve
pause

scene sc776 with dissolve

n "Not bad."
n "I feel like this is going to be one romantic evening."

scene sc777 with dissolve

n "[vicky_nick] should really like this."

scene sc778 with dissolve
pause

scene sc779 with dissolve
pause

scene sc780 with dissolve

v "Wow!"
v "You really out did yourself!"
mc "Do you like it?"

scene sc781 with dissolve

v "Yes it's perfect!"
v "Smells so good too!"
v "You really put an effort into this!"

scene sc782 with dissolve

v "I'm really impressed by this!"
v "All this is for me?"
mc "Of course [vicky_nick]."
mc "I want you to know how special you are to me."
v "You're so sweet."

scene sc783 with dissolve

n "Oh wow, I love it when she just latches on like that!"
n "She smells so good, I think she put perfume on just for me."

scene sc784 with dissolve

v "Mmmm."
mc "I love your kisses."
v "I know you do!"

scene sc785 with dissolve

n "I can feel the skin on her back, she's burning up."

scene sc782 with dissolve

v "Hey, I'm actaully starving."
mc "Haha, Ok [vicky_nick]."
mc "Let's eat."

scene sc786 with fade

v "This is so nice!"
v "... looks delicious."
v "Thank you [player_name]!"
mc "I just wanted to show you that I care about you more than just the physical attraction."

scene sc786 with dissolve

v "I feel so spoiled rotten."
mc "You deserve this [vicky_nick]"

scene sc786 with dissolve

v "You know as wrong as it is, I gotta say I feel like a teenager with you."
mc "I knew you liked it [vicky_nick]."

scene sc790 with dissolve

v "I do love all the attention."
mc "[vicky_ex_nick] was never this attentive to you?"

scene sc791 with dissolve

v "Not this much!"
mc "I guess I get it from you?"

scene sc789 with dissolve

v "Maybe..."
v "I still think its weird you find me attractive."

scene sc790 with dissolve

mc "Oh, [vicky_nick] you have no idea."
v "It's still wrong."
mc "Yeah but you're my girlfriend now."

scene sc792 with fade

v "But not really right?"
v "I mean you're just saying that as an excuse to be perverted around me."
mc "Not at all. I really want us to act like a couple."
mc "With no boundaries."
mc "I want what [vicky_ex_nick] had."

scene sc793 with fade

v "I still don't think its right, and I feel like we crossed the point of no return already."
mc "Right and is it so bad?"
v "I guess it isn't as bad as I thought it would be."

scene sc794 with dissolve

mc "Then we just continue on doing what we do."

scene sc796 with fade

v "I'm really impressed how unfazed you are at the weirdness of this relationship."
mc "It's easy when you're so beautiful."

scene sc797 with dissolve

v "Stop it you're making me blush."

scene sc799 with dissolve

mc "I like that you're drinking."
mc "I want you to loosen up."

scene sc7100 with dissolve

v "I knew it, you're always trying to get me drunk."
mc "Sure I am. I want you to show me what you can do tonight."

scene sc7101 with dissolve

v "What am I doing tonight?!"
mc "I want you to forget that I am your [player_rel]."
mc "Let go and loosen up."

scene sc7102 with dissolve

v "What did you have in mind?"
mc "You're acting like you don't know."

scene sc797 with dissolve

v "I don't know."
mc "What would you like?"

scene sc799 with dissolve
pause

scene sc7101 with dissolve

v "Hmm, what would I like..."

scene sc7102 with dissolve

v "Mmm, well this might be a surprise but I do want to be kissed..."
n "Wow, I knew my charm would work on her! And a little wine."
mc "Yes... go on!"
v "Um, I want to be held."
mc "Yes, keep going."

scene sc7103 with dissolve

v "I should stop..."
mc "No way keep going."

scene sc7104 with dissolve

v "I like it when you look at me."
mc "Yesss."

scene sc7105 with dissolve

v "I do like knowing you desire me even though it's wrong."

scene sc7106 with dissolve

v "I love how you hold me."

scene sc7107 with dissolve

v "...I love that you can't keep your hands off of me."

scene sc7108 with dissolve

v "I am scared of what to do or say next..."
mc "Then can I ask you to keep an open mind?"

scene sc7109 with dissolve

mc "I want you."

scene sc7110 with dissolve

mc "I want you [vicky_nick]."

scene sc7111 with dissolve

v "[player_name]!"
n "I can taste the perfume on my lips but its not bitter it's actually delicious."

scene sc7112 with dissolve

v "...uhhh."

scene sc7113 with dissolve

v "Oh, god. That feels good."
n "I can feel her growing weaker in my embrace."

scene sc7115 with dissolve

v "uhhh mmm."
n "Feels like I'm holding her up."

scene sc7114 with dissolve

n "I can feel the outlines of her panties through the fabric of her dress."
v "Oh, fuck..."

scene sc7116 with dissolve

n "I dig deeper into her dress and slide my hand onto her groin."
n "I can feel the heat of her soft pussy mound."
v "Oh, [player_name]. Please..."

scene sc7117 with dissolve

n "I can feel her pushing away as I feel her get wetter."
v "...Kiss me."

scene sc7118 with dissolve
pause

scene sc7119 with dissolve
pause

scene sc7120 with dissolve
pause

scene sc7121 with dissolve

n "Wow! look at that nipple!"
mc "I want you to undess."
v "[player_name], no."
mc "Take your dress off..."

scene sc7122 with dissolve

mc "[vicky_nick], I want to see you out of that dress."
v "Can't we just have fun with it on?"
v "I thought you like dresses, you can look at my panties from underneath."
mc "No [vicky_nick], I want it off."
mc "Didn't we just talk about how we were going to let loose?"
mc "C'mon I thought we had an understanding? We were making so much progress..."
mc "Please don't ruin this night for us..."

scene sc7123 with dissolve

v "You're so persistant!"
v "I guess you've already seen most of it."
mc "Oh please [vicky_nick]."
v "Ok, ok, please don't beg. You're making it weird."

scene sc7124 with dissolve

mc "Damn, you're so beautiful!"
v "Please, don't gawk!"

scene sc7125 with dissolve
pause

scene sc7126 with dissolve

mc "Don't be shy!"
v "I'm not shy, you're my [player_rel]."
v "And I'm standing here naked in front of you."
mc "I'm your boyfriend, remember?"
mc "And you're not naked, you have panties on."

scene sc7127 with dissolve

v "This is still so wrong."
mc "My god, look at your body [vicky_nick]!"
v "Please... that's enough."

scene sc7128 with dissolve

mc "I want to kiss your hips, I need to feel your skin."
v "Oh!"
n "It's like an electric shock to my lips as I touch her skin with my lips."

scene sc7129 with dissolve

v "That tickles!"
mc "You smell so good."

scene sc7130 with dissolve

n "Finally I could taste her scent."
n "A mix of flowers and honey."

scene sc7131 with dissolve

v "OHHHHH, god...!"

scene sc7132 with dissolve
pause

scene animation7 with dissolve

n "This was turning me on so much, I pulled my dick out of my pants."

scene sc7135 with dissolve

v "Please, we can't do this!"
v "Can you please think about this!"
mc "This feels so right, and your body is responding, I can tell, [vicky_nick]!"

scene sc7136 with dissolve

mc "I love how fast you're breathing, I love your little whimpers."
v "...I'm sorry it's been awhile..."
v "I don't mean to...please..."
mc "I want to make you feel good like this always..."
n "She's shaking."

scene sc7137 with dissolve

v "Please you can't touch me there."
mc "You mean I shouldn't touch you there, becasue it's wrong."
v "Yes..."
mc "But it feels good so I am going to."

scene sc7138 with dissolve

mc "You made me cum, I want to make you cum too."

scene animation8 with dissolve

n "I can feel her swollen clit through the fabric, it's a little soft bump."
v "Mmm, Oh shit!"
mc "Wow you never cuss, see how good it feels."
mc "Grab my dick [vicky_nick]."


scene animation9 with dissolve

n "I feel her comply with my demands, it's like she's under a spell."

scene animation8 with dissolve

n "Her panties grow more damp as I continue rubbing her pussy"

scene animation9 with dissolve

n "Her strokes on my cock begin to quicken"

scene sc7145 with dissolve

n "Her tongue wrestles with mine, and I taste her saliva."
n "Her moans get deeper."


scene sc7144 with dissolve
pause

scene sc7138 with dissolve

v "Please cum, honey."
mc "I want you to cum first."
v "No, I can't like this..."
mc "You're afraid to cum!"
v "No, it's just a lot to process."
v "Please cum so we can sleep."

scene animation9 with dissolve

n "Her grip on me tightens, encourging me to cum."

scene sc7146 with dissolve

mc "I'll cum if you use your mouth, [vicky_nick]."

scene sc7147 with dissolve

v "What!?"
mc "Your mouth, you know, a blowjob..."

scene sc7148 with dissolve

v "I know what you mean, I just can't believe what you're asking me to do."
mc "Please, I want it so badly, it would be my first time and I want it to be with you."

scene sc7149 with dissolve

n "I feel her pull away."
v "Oh, my god!"
v "Don't pressure me like that!"
mc "C'mon and you know I wont last long!"
mc "It'll be quick."

scene sc7150 with dissolve

v "I can't belive this, I can't even believe I'm standing here naked in front of you while you ask for a blowjob!."
v "Jesus, I should stop drinking!"
v "This has to be the alcohol..."
mc "Hey! [vicky_nick] stop spiraling!"

scene sc7151 with dissolve

v "What are you doing!?"
mc "I'm just getting comfortable, relax..."
v "You're insane, you know that?"

scene sc7153 with dissolve

n "She wont stop looking at my dick, I feel like she's tempted."
mc "Please, the faster I cum the sooner this will be over."
mc "You can blame it on the alcohol all you want."
v "You realize what you're asking?"
mc "I'm sorry, but you do remember that you're now my girlfriend?"

scene sc7154 with dissolve

v "This is not how boyfriends treat their girfriends..."
mc "You're right, I shouldn't even have ask for a blow job!"
mc "Come on [vicky_nick], you're wasting time here..."

scene sc7155 with dissolve

n "Sounds like I went too far and blew this."
v "Jesus Christ, how do you not have any shame?"
v "...shit."
n "Holy shit, is she actually considering this?"
mc "[vicky_nick]..."
v "If I do this..."
mc "....y-yes?"
v "First of all..."
v "If I ever hear you say anything about this or tonight in general..."
v "I will disown you!"
n "I can't believe she's going to do it..."

scene sc7156 with dissolve

v "And you have to make it quick..."
v "And no touching!"
v "..."
n "My heart is in my stomach now..."

scene sc7157 with dissolve

v "I just want you to know how humiliating this is for me..."
mc "No way [vicky_nick], this is the hottest thing ever!"
n "I can feel the blood flowing through me as I watch her submit to me."

scene sc7158 with dissolve

v "What?...having your [vicky_rel] on her kness in front of you?"
mc "Yes, you look so hot."
mc "Show me what you got, [vicky_nick]."
v "I have not done this in so long!"

scene sc7159 with dissolve

v "Please, [player_name] we can stop right now and just cuddle, let's not do this..."
mc "..."
v "Is this really what you want?"
mc "Very much..."
mc "Oh and you can't use your hands..."
mc "...it was your rule right? You did say no touching."

scene sc7160 with dissolve

v "You're horrible..."
mc "Please stop stalling, I need your mouth!"
v "Ok, ok! Don't be so loud!"

scene sc7161 with dissolve

n "She takes a tentitive lick"
mc "Oh, fuck..."
v "...Hey...language..."

scene sc7162 with dissolve

n "I can feel her tongue slither across my shaft."
mc "*whispers* Holy shit..."
n "Everytime she speaks I can feel her warm breath."

scene sc7163 with dissolve

v "Ehhh, like this?"
mc "IN your mouth!"
n "She's flicking the top of my head with her tongue..."

scene sc7164 with dissolve

v "...Mmmok..."
n "She covers the head of my dick with her mouth, the heat and wetness feels amazing!."
n "I can feel her spit and tongue glide along my head."
n "Her sucktion is gentle and I feel the urge to cum building in my balls."

scene sc7165 with dissolve

mc "Oh [vicky_nick], your mouth is so warm!"

scene animation10 with dissolve

mc "I'm definitely not going to last!"
n "I am so hard in my [vicky_nick]'s mouth."

scene animation11 with dissolve

n "I think she's actually enjoying herself."
v "Mmm"
mc "Oh yeah, [vicky_nick]."

scene sc7169 with dissolve

n "She takes little breaks, but is giving all her effort."

scene animation10 with dissolve

mc "I can't believe this."
mc "It feels so good [vicky_nick]."

scene sc7173 with dissolve

n "The living room becomes quiet, and all that I hear are the slurps and smacks coming from her mouth."

scene animation10 with dissolve

mc "Fuck..."

scene sc7169 with dissolve

"slurp"

scene animation10 with dissolve

mc "Can you go deeper?"

scene sc7168 with dissolve

n "As she pulls my cock out of her mouth it makes a popping sound."

scene sc7171 with dissolve

v "I'll try but I can't promise anything..."

scene sc7170 with dissolve

v "Can you please cum already!"

scene sc7169 with dissolve

scene animation12 with dissolve

mc "Oh my god [vicky_nick]!"
n "She takes me deep and I can feel the back of her mouth."
n "I'm throbbing like crazy."

scene animation13 with dissolve

"gag"

scene animation14 with dissolve

mc "....Uhhh."
v "Mmmhmmm..."
n "The build up is incredible, the pressure in my balls and dick so tense I feel like my groin is going to explode."

scene sc7168 with dissolve

scene sc7169 with dissolve

scene sc7170 with dissolve

v "Ack...It's so big..."
mc "Im close, don't stop [vicky_nick]!"

scene sc7174 with dissolve
pause

scene animation15 with dissolve
pause

scene sc7177 with dissolve

v "Oh...uhhh...please hurry!"
n "She wraps her hands around my dick... I guess the no touching rule has been broken."

scene animation15 with dissolve
pause  

scene sc7178 with dissolve

n "I grab the back of her head and force her down on me deeper."
v "Hmmph, Hmmpph!"
n "I noticed she doesn't resist... much."

scene animation16 with dissolve

"cough"

scene sc7180 with dissolve

"gag"

scene animation16 with dissolve

n "I feel a tingle in my head and the throbbing gets intense, I realize I can't hold it any longer."
mc "Oh fucckkkk [vicky_nick], I'm coming!"
v "MmmHmmmm!"

menu:
    "Cum in [vicky_nick]'s mouth.":
        jump cumnmouth
    "Cum on [vicky_nick]'s face.":

        jump cumnface

label cumnface:

scene sc7184 with dissolve

n "I pull her off of me and guide my cock to her face."
v "Oh my... you made a mess..."

jump facewipe

label cumnmouth:

scene sc7181 with dissolve
pause

scene sc7182 with dissolve

v "HUUUKKKKCCCCCC."
n "I begin to pump hot cum into her mouth."

scene sc7183 with dissolve

v "Hmmp!"
mc "I tried warning you [vicky_nick]!"

label facewipe:

scene sc7185 with dissolve

mc "That was so good [vicky_nick]."

scene sc7186 with dissolve

v "I can't believe what we just did..."

scene sc7187 with dissolve

v "Things will never be the same will they?"
v "I'm a terrible person!"
mc "Sure things might not be the same but they are for the better."

scene sc7188 with dissolve

v "How can you think this is for the better?"
mc "Because look how close we are, and this is what I wanted for us."
mc "A connection between us that I know you feel too."
v "Maybe, I guess my fear is that I am a failure of a [vicky_rel]."

scene sc7189
mc "No, you're actually the best [vicky_nick] in the world."

scene sc7190 with dissolve

n "I feel a sort of relief from her as she embraces me."



jump chapter3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
