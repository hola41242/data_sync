image animation1:
    "SC5/sc571.png" with dissolve
    0.65
    "SC5/sc572.png" with dissolve
    0.65
    repeat


image animation2:
    "SC5/sc580.png" with dissolve
    0.65
    "SC5/sc581.png" with dissolve
    0.65
    repeat


image animation3:
    "SC5/sc582.png" with dissolve
    0.65
    "SC5/sc583.png" with dissolve
    0.65
    repeat


image animation4:
    "SC6/sc6120.png" with dissolve
    0.65
    "SC6/sc6121.png" with dissolve
    0.65
    repeat


image animation5:
    "SC6/sc6120.png" with dissolve
    0.5
    "SC6/sc6121.png" with dissolve
    0.5
    repeat


image animation6:
    "SC7/sc717.png" with dissolve
    0.5
    "SC7/sc719.png" with dissolve
    0.5
    repeat


image animation7:
    "SC7/sc7133.png" with dissolve
    0.65
    "SC7/sc7134.png" with dissolve
    0.65
    repeat


image animation8:
    "SC7/sc7140.png" with dissolve
    0.65
    "SC7/sc7141.png" with dissolve
    0.65
    repeat


image animation9:
    "SC7/sc7142.png" with dissolve
    0.65
    "SC7/sc7143.png" with dissolve
    0.65
    repeat


image animation10:
    "SC7/sc7164.png" with dissolve
    0.5
    "SC7/sc7165.png" with dissolve
    0.5
    repeat


image animation11:
    "SC7/sc7166.png" with dissolve
    0.5
    "SC7/sc7164.png" with dissolve
    0.5
    "SC7/sc7165.png" with dissolve
    0.5
    repeat


image animation12:
    "SC7/sc7164.png" with dissolve
    0.5
    "SC7/sc7165.png" with dissolve
    0.5
    "SC7/sc7168.png" with dissolve
    0.5
    "SC7/sc7167.png" with dissolve
    0.5
    repeat


image animation13:
    "SC7/sc7165.png" with dissolve
    0.5
    "SC7/sc7166.png" with dissolve
    0.5
    "SC7/sc7167.png" with dissolve
    0.5
    "SC7/sc7166.png" with dissolve
    0.5
    repeat


image animation14:
    "SC7/sc7166.png" with dissolve
    0.5
    "SC7/sc7167.png" with dissolve
    0.5
    repeat


image animation15:
    "SC7/sc7175.png" with dissolve
    0.5
    "SC7/sc7176.png" with dissolve
    0.5
    repeat


image animation16:
    "SC7/sc7179.png" with dissolve
    0.85
    "SC7/sc7180.png" with dissolve
    0.85
    repeat


image animation17:
    "SC8/scsc8b7.png" with dissolve
    0.85
    "SC8/scsc8b5.png" with dissolve
    0.85
    repeat


image animation18:
    "SC8/scsc8b9.png" with dissolve
    0.85
    "SC8/scsc8b8.png" with dissolve
    0.85
    repeat


image animation19:
    "SC8/scsc8b11.png" with dissolve
    0.85
    "SC8/scsc8b13.png" with dissolve
    0.85
    repeat


image animation20:
    "SC8/scsc8b14.png" with dissolve
    0.85
    "SC8/scsc8b15.png" with dissolve
    0.85
    repeat


image animation21:
    "SC8/scsc8a9.png" with dissolve
    0.85
    "SC8/scsc8a10.png" with dissolve
    0.85
    repeat


image animation22:
    "SC9/sc9e67.png" with dissolve
    0.85
    "SC9/sc9e68.png" with dissolve
    0.85
    repeat


image animation23:
    "SC9/sc9e74.png" with dissolve
    0.85
    "SC9/sc9e75.png" with dissolve
    0.85
    "SC9/sc9e76.png" with dissolve
    0.85
    repeat



image animation24:
    "SC10/sc1039.png" with dissolve
    0.85
    "SC10/sc1039.png" with dissolve
    0.85
    repeat



image animation25:
    "SC10/sc1043.png" with dissolve
    0.85
    "SC10/sc1044.png" with dissolve
    0.85
    repeat



image animation26:
    "SC10/sc10117.png" with dissolve
    0.85
    "SC10/sc10118.png" with dissolve
    0.85
    repeat



image animation27:
    "SC10/sc10119.png" with dissolve
    0.85
    "SC10/sc10120.png" with dissolve
    0.85
    repeat



image animation28:
    "SC10/sc10118.png" with dissolve
    0.85
    "SC10/sc10119.png" with dissolve
    0.85
    "SC10/sc10120.png" with dissolve
    0.85
    "SC10/sc10119.png" with dissolve
    0.85
    repeat


image animation29:
    "SC10/sc10121.png" with dissolve
    0.85
    "SC10/sc10122.png" with dissolve
    0.85
    repeat



image animation30:
    "SC10/sc10119.png" with dissolve
    0.85
    "SC10/sc10117.png" with dissolve
    0.85
    repeat



image animation31:
    "SC10/sc10120.png" with dissolve
    0.85
    "SC10/sc10119.png" with dissolve
    0.85
    "SC10/sc10117.png" with dissolve
    0.85
    repeat



image animation32:
    "SC10/sc10153.png" with dissolve
    0.85
    "SC10/sc10154.png" with dissolve
    0.85
    "SC10/sc10155.png" with dissolve
    0.85
    "SC10/sc10154.png" with dissolve
    0.85
    repeat



image animation33:
    "SC10/SC10157.png" with dissolve
    0.6
    "SC10/SC10156.png" with dissolve
    0.6
    "SC10/sc10159.png" with dissolve
    0.6
    "SC10/SC10158.png" with dissolve
    0.6
    "SC10/sc10159.png" with dissolve
    0.6
    "SC10/SC10158.png" with dissolve
    0.6
    "SC10/SC10159.png" with dissolve
    0.6
    "SC10/SC10156.png" with dissolve
    0.6
    repeat


image animation34:
    "SC10/SC10156.png" with dissolve
    0.6
    "SC10/SC10159.png" with dissolve
    0.6
    "SC10/SC10158.png" with dissolve
    0.6
    "SC10/SC10159.png" with dissolve
    0.6
    repeat


image animation35:
    "SC10/SC10170.png" with dissolve
    0.6
    "SC10/SC10171.png" with dissolve
    0.6
    repeat


image animation36:
    "SC10/SC10170.png" with dissolve
    0.4
    "SC10/SC10171.png" with dissolve
    0.4
    repeat


image animation37:
    "SC10/SC10174.png" with dissolve
    0.6
    "SC10/SC10175.png" with dissolve
    0.6
    repeat


image animation38:
    "SC10/SC10188.png" with dissolve
    0.6
    "SC10/SC10189.png" with dissolve
    0.6
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
