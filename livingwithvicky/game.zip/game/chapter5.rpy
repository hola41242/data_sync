label chapter5:

scene black with fade
show text "Chapter 5" with dissolve
pause

show text "THE NEXT MORNING."
pause

scene black with dissolve


n "I don't even remember falling asleep."
n "What a wild night, I can't believe what happened, but also I can't help but think I was out of control with her."

scene sc11f01 with dissolve

n "My dick feels like I came in buckets, and its also a little sore from how tight [vicky_nick]'s ass is."

scene sc11f02 with dissolve

n "Damn, I hear her in the kitchen, I know for sure I am going to be in trouble for last night."
n "I should get the day started."

scene black with dissolve

n "I hurriedly got dressed and went to see how mad she is about last night."

scene sc11c01 with dissolve

n "She's tinkering in the kitchen let's see."

scene sc11c02 with dissolve

n "I love that she can dress into anything and still look great."
n "Man she really is gorgeous all the time."
n "No matter what she wears, that ass is never going to look bad."

scene sc11c03 with dissolve

mc "Morning [vicky_nick]..."
n "Man I wish I did not sleep through her getting dressed this morning?"

scene sc11c04 with dissolve

v "Mmm?"
v "M-Morning..."
n "She muttered it under her breath, that means she is thinking about something..."

scene sc11c05 with dissolve

n "I knew there was something wrong, it was in the tone of her voice."
mc "Is something wrong?"
v "...[player_name].."
n "Here we go..."

scene sc11c06 with dissolve

mc "Look if its about last night, we've already had this conversation a million times."
v "What!?"
v "Are you serious right now, you took it to a whole new level of depravity last night!"
v "It was not like the other nights at all!"
mc "Well as alwyas I enjoyed it very much."

scene sc11c07 with dissolve

v "No way [player_name], stop right there."
v "You need to understand no, means NO!"
v "I raised you better than this!"
n "Shit, she is mad and most importantly she is right, I did go overboard last night."
v "We really need to set some boundaries here!"

scene sc11c08 with dissolve

mc "I'm sorry, I know I crossed the line."
v "Yes you did!"
v "...many times!"
mc "I know, I'm sorry ok?"

scene sc11c09 with dissolve

v "OK, [player_name]. Enough is enough."
v "I'm glad we talked about this."
mc "Consider it squashed!"
v "Yes, very good. I'll get back to cooking..."
v "...seems like I never have enough time in the day."
mc "Anyway I can help?"
n "Jesus that ass is tempting me."

scene sc11c010 with dissolve

mc "Let me help [vicky_nick]."
n "I can tell she is occupied with the dishes leaving her very vulnerable to my touch."
n "Her hips are so soft, her love handles are perfect for grabing."

scene sc11c011 with dissolve

n "This is really ballsy, she's already mad."
n "But I'll stop as soon as she tells me to stop."
n "... let's see how far I can get before she stops me."
v "HEY!"
n "I could feel her flesh past her dress as I raise it up revealing her warm skin."

scene sc11c012 with dissolve

v "[player_name], what the heck..."
v "Get out of there!"
n "I was expecting her to say stop, right away. But she didnt."

scene sc11c013 with dissolve

v "Hey! I'm talking to you!"
v "Haven't you heard anything we just talked about?"
mc "I heard plenty."
mc "What's the big deal I'm just playing."
v "Playing?"
v "C'mon [player_name] you know better, this is not a playing."
v "I'm being serious, you're losing control again!"

scene sc11c015 with dissolve

v "Hey what are you doing?"
v "This is what I'm talking about"
mc "I totally understand [vicky_nick], I promise."
v "Really, you need to behave."

scene sc11c016 with dissolve

n "Damn, she smells so good."
n "I have my face right in her crotch and I can smell her pussy."

scene sc11c017 with dissolve

v "Jeez, you're impossible, UGH."
n "I put my mouth over her crotch."

scene sc11c018 with dissolve

v "Oh, MY!"
n "I get my mouthfull of cotton panty and a faint taste of her pussy."

scene sc11c019 with dissolve

n "She grabs my wrists with a slight urgency."
n "I could feel her trembling."
v "Ok, ok stop it. This is not the time for that."

scene sc11c020 with dissolve

v "Cut it out, ok?"
v "This is not the time or the place!"
mc "I just want to touch you all the time."

scene sc11c022 with dissolve

v "What the heck?"
mc "What I'm just saying, I do."
v "I guess it's normal for someone your age..."
mc "We'll I'm telling you that I do! I can't stop thinking about you."
mc "...I can't stop looking at you."
mc "And I want to see more..."

scene sc11c021 with dissolve

v "My god [player_name], did you forget what happened last night."
mc "I'll never forget."
v "Well like I said it better not happen again."
v "I'm serious!"
v "If I say no, then I mean NO!"

scene sc11c023 with dissolve

mc "Of course. I didn't mean to hurt you or disrespect you."
mc "It was just the heat of the moment."
v "It was a bit scary."
v "...My fault if I never spoke to you about these things."
v "Like when you get a girlfriend you can't treat her like this."

scene sc11c024 with dissolve

v "It's very impotrtant that you understand this."
v "Otherwise I have failed you as your [vicky_rel]."
mc "I promise, I'll be more of a gentleman."
v "Good."
v "...All things considered."

scene sc11c025 with dissolve

n "I try and lean in for a kiss."
v "Stop right there."
v "There's time and a palce for everything."
mc "Ah, geez, [vicky_nick] you're playin hard to get, huh."

scene sc11c026 with dissolve

v "Boy that sure does sound familiar."
mc "What does that mean?"
v "Oh, nothing."
v "Just sounds like something your [vicky_ex_rel] would say."
n "I don't know why that felt like an insult."
n "But I was offended."

scene sc11c027 with dissolve

n "She actually hurt my feelings with that..."
mc "I'm not like dad..."
v "Oh, relax. I'm just messing with you."
n "Maybe there was some truth to that..."

scene black with fade
show text "phone vibrating."
pause

scene sc11c028 with dissolve


call phone_start from _call_phone_start_10
call message_start ("SABRINA", "hey!") from _call_message_start_9
call reply_message ("Hey!  What's going on?") from _call_reply_message_154
call message ("SABRINA", "Are you busy?") from _call_message_151
call reply_message ("No, acutally just hanging out, what's up?") from _call_reply_message_155
call message ("SABRINA", "Ok, so if you're not doing anything, I need a ride from my hair appointment.") from _call_message_152
call reply_message ("You just need me to drive you around? It feels like youre taking advantage of me.") from _call_reply_message_156
call message ("SABRINA", "No way, I just thought you'd want to") from _call_message_153
call reply_message (" Don't get me wrong, I'd love to.") from _call_reply_message_157
call message ("SABRINA", "Look, you get to spend time with me and I'll make it worthwhile, I promise.") from _call_message_154
call reply_message ("ok, where and when?") from _call_reply_message_158
call message ("SABRINA", "main street and first, 2:00, See you soon!.") from _call_message_155

call phone_end from _call_phone_end_10

scene sc11c029 with dissolve

n "This sounds promising."
n "I'm looking forward to spending time with her."

scene black with dissolve
show text "TO THE SALON."
pause

scene sc11c032 with dissolve

n "It didnt take me long to find the place."
n "It was off the main street that brought all the little stores together."

"DOOR BELL RING"

scene sc11c033 with dissolve

n "Walking into some whispering."

scene sc11c034 with dissolve

n "Looks like [sabrina_nick] is already getting her hair done."
n "Wonder what style she's going for."
n "Better not shave her head."

scene sc11c035 with dissolve

s "Hey! [player_name]!"
s "You should have texted me before you left, we're running a little late with my hair."

scene sc11c037 with dissolve

s "This is Sally!"
s "Sally, this is my [player_sab_rel] [player_name]"
s "She's kind of new here too, moved recently."

scene sc11c038 with dissolve

sal "Hi...nice to meet you."
mc "Hi..."
n "Mmm, she's kinda cute."
n "Kind of a regular face, nothing to write home about."
n "She must have some sort of a kink."

scene sc11c039 with dissolve

s "Oh my god, don't mind him."
s "I think he's drooling."
mc "Sorry I was thinking of something clever to say."

scene sc11c040 with dissolve

s "Mmm, you got him dead in his track, Sal."
n "Shucks."
mc "Caught me off gaurd, is all."

scene sc11c041 with dissolve

s "I feel jealous."
s "You never look at me like that."
n "She apprently doesnt care if Sally hears her."

scene sc11c042 with dissolve

mc "You know that's not true."
s "Is that so?"
s "I know how much you like to look."

scene sc11c043 with dissolve

mc "I just can't help myself sometimes."
s "Hah, I bet."
s "Then again I don't blame you."
n "Holy hell, sally actually has a nice ass."

scene sc11c044 with dissolve

sal "Ok Sabrina, I'm ready for you now."
s "Oh! The moment we've been waiting for."

scene sc11c045 with dissolve

n "I feel like this is going to take awhile, I'll just sit here and bide my time."
n "Sabrina sure does look good today, that skirt is driving me mad."

scene sc11c046 with dissolve

n "They took the next five minutes to decide what kind of hair style to go with."
n "Sabrina never could decide on things like this."
n "But it's nice to see Sally has a way with her indicisions."
s "[player_name] what do you think?"
mc "Huh?"

scene sc11c046 with dissolve

s "What do you think? Does this looks hot on me?"
sal "Yeah, lets get a man's decision."
n "What the hell would I know about girls hair."
mc "Jesus, I really wouldnt even know where to start."
sal "Not to say she is not hot though, am I right?"
mc "But of course!"

scene sc11c047 with dissolve

sal "Let's spin her around for ya!"
s "Hey you chill, Sal!"

scene sc11c048 with dissolve

n "I could see Sally start massaging Sabrina's head."
n "Anyone could see that Sabrina was enjoying the scalp massage."
s "Ugh, Sal you got the magic touch, you should have been a masseus!"
sal "Haha, yeah right you just havent been touched in a while!"
sal "We need to get you laid!"
s "Sal!"
sal "What?"

scene sc11c050 with dissolve

s "Not in front of my [player_sab_rel]!"
sal "oh, sorry, hehe."
n "She giggles like a school girl."

scene sc11c051 with dissolve

sal "What about you, [player_name]?"
sal "Do you have girlfriend?"
s "Chill out, Sal!"
mc "Uhh, not really..."
n "Sabrina looks awfully uncomoftable."
sal "What do you mean, not really?"

scene sc11c049 with dissolve

mc "Well, I'm not really sure."
n "What the hell am I talking about?"
s "Oh? I didn't know you had someone..."
mc "hah, Yeah well it's complicated..."
n "Am I talking about [vicky_nick]?"
sal "The plot thickens!"
mc "Meh, it's probably nothing."
n "I notice Sabrina is looking at me concerned."
n "I decide to wink at her."

scene sc11c052 with dissolve

n "She nervously smiles."
n "Can it be?"
n "Can she be thinking I was talking about her?"

scene sc11c053 with dissolve

n "I let my eyes move down to her skirt."
n "Her legs part a little bit and I can almost feel the warmth between her thighs."

scene sc11c054 with dissolve

n "I look back up and see Sabrina noticed where I was staring."
n "She wont break eye contact with me."

scene sc11c059 with dissolve

n "Is she messing with me?"
n "Pretty sure she is, her facial expression is that of shyness but with a twist of mischief."
n "It's an expression I rarely seen until recently..."

scene sc11c057 with dissolve

n "She gives me a smirk that sends blood to my groin."

scene sc11c054 with dissolve

n "She starts to mess with her skirt."

scene sc11c055 with dissolve

n "To my surpise she flips the skirt up to reveal her off white cotton panties."
n "My heart starts beating fast as I feel my cock starting to swell"

scene sc11c056 with dissolve

n "I am now extremely hard looking at her panties."

scene sc11c057 with dissolve

n "A devious smile emerges."
n "I can't believe her"

scene sc11c058 with dissolve
pause

scene sc11c059 with dissolve

n "What a little slut."

scene sc11c056 with dissolve

n "Jesus, what a tease!"

scene sc11c060 with dissolve

sal "Alright, what are we doing?"
s "What?"
sal "I said what are you we doing about your hair?"
n "Looks like Sabrina was just as startled as I was."

scene sc11c061 with dissolve

sal "Let me see what kind of magic I can whip up..."

scene sc11c062 with dissolve

s "Nothing crazy ok?"
sal "Have I ever done you wrong?"

scene sc11c063 with dissolve

s "[player_name], promise me you'll kill her if she fucks my hair up?"
sal "Oh my god, shut up before I chop it all off!"

scene sc11c064 with dissolve

n "I'm actually growing impatient."
n "They're kind of annoying."
n "I think they're just trying to get my attention."

scene sc11c065 with dissolve

n "Yep, they're both showing off."
n "Quite obviosly."

scene sc11c066 with dissolve

n "Yeah, they're not even trying to hide it anymore."
sal "Hold on a sec, where the heck are those towels?"
n "Sally has a great ass, and look at that thigh gap!"

scene sc11c067 with dissolve

sal "Here put the towel on, let that hair dry and I will style it."
s "I love it when you're so bossy."

scene sc11c068 with dissolve

s "Oh my god Sal, hurry up"
sal "Hold your horses!"

scene sc11c069 with dissolve

s "I can't wait to see my new hair [player_name]!"
mc "I bet it's going to look nice..."
s "It better be hot!"

scene sc11c070 with dissolve

sal "Alright, I'm going to style it now."
sal "It wont be much longer now, [player_name]."
sal "You've been so patient with us!"
mc "My pleasure, I enjoyed the view."

scene sc11c071 with dissolve

s "I told you he's a pervert!"
sal "Yeah I bet he's got that wondering eye!"

scene sc11c072 with dissolve

sal "Alright let's do this!"
s "No going back now."

scene sc11c072 with dissolve

n "Then there was silence."
n "I could feel the tension in the air."

scene sc11c073 with dissolve

sal "Sit still!"
s "Ok! Bitch."
n "I Could tell sabrina was getting a little nervous. This is how she lashes out when she feels tense."
sal "OK, are you ready?"

scene sc11c074 with dissolve

sal "Tada!"

scene sc11c075 with dissolve

s "Ohmygosh! [player_name], what do you think?"
mc "Wow!"
mc "That looks really good!"

scene sc11c076 with dissolve

s "Sal. You really out did yourself this time! I absolutely love it."
mc "Yeah that looks really good on you, [sabrina_nick]."

scene sc11c077 with dissolve

s "Oh, Sal, I love you."
n "[sabrina_nick] is looking a little emotional."
sal "I was ready for you to hate me."
s "No way!"

scene sc11c078 with dissolve

n "They went on for a couple of minues."
n "Two dumb broads, fussing over a haircut."
n "I'm sure the chatter could be heard for miles."

scene sc11c079 with dissolve

n "After the brief explosion of excitement, things settled back down."
n "Sabrina and Sally exchanged goodbyes as I kept my eye on the clock."
n "I think [vicky_nick] is going to be pissed it's getting pretty late."

scene sc11c080 with dissolve

n "After 30 more minutes Sabrina noticed I was inching towards the door."
s "Bye Sal!"
s "Thanks for everything."
sal "Bye guys, thanks for trusting me!"
sal "Bye [player_name], nice meeting you!"
mc "Bye Sally, it was a pleasure for sure."



scene black with fade
scene sc11c081 with dissolve

n "We shared a quiet ride through downtown."

scene sc11ad01 with dissolve

n "But as soon as we got into the woods Sabrina started talking."

scene sc11c082 with dissolve

s "...yeah I don't like college it just seems like such a waste of time."
n "I think she was just trying to break the silence."

scene sc11c083 with dissolve

n "Meanwhile all I could do is admire her body."

scene sc11c084 with dissolve
pause

scene sc11c086 with dissolve

mc "A higher education will give you an advantage in the job market."

scene sc11c085 with dissolve

n "The AC circulated her delicious perfume throughout the car."

scene sc11c087 with dissolve

n "Her skin somehow was glowing in the late afternoon sunshine."
n "In the back of my mind I keep thinking if this is how [vicky_nick] looked when she was younger."

scene sc11ad03 with dissolve

s "[player_name], can we talk a little bit?"
mc "Sure, about what?"

scene sc11ad02 with dissolve

s "I'm loosing subscribers on my Lonelypage. I am thinking of more revealing content to increase the fans."

scene sc11ad04 with dissolve

s "Do you remember me telling you that I have a friend that will let me use their photo studio?"
mc "Yes I do recall you saying that."

scene sc11ad05 with dissolve

s "I was wondering if you would't mind doing another photo shoot."

scene sc11ad07 with dissolve

s "I am afraid of having someone else, even my friend with the studio, taking these photos."

scene sc11ad06 with dissolve

s "You made me feel so comfortable the last photo shoot we did. I only feel comfortable with you."

scene sc11ad01 with dissolve

mc "Sure [sabrina_nick]. When will you want to do this?"

scene sc11ad02 with dissolve

s "I'll talk to my friend and see when their studio will be available."

scene sc11ad05 with dissolve

s "It will most likely be in the evening so it does not interfere with their regular business."

scene sc11c087 with dissolve

mc "Just let me know and we will get some nice photos that will bring back and even increase your fans. We will do whatever you are comfortable with."

scene sc11ad07 with dissolve

s "[player_name], I still can't pay you anything... If I had money I would move out of [vicky_ex_nick]'s house"

scene sc11ad08 with dissolve

n "This may work to my advantage, maybe I can her to exchange sexual favors for the photoshoots."
n "She did not totally reject me the night I kissed her. Maybe I could get a blowjob from her or even more, if there are more photoshoots she can't pay for."

scene sc11ad01 with dissolve

mc "You are still wanting to move out [vicky_ex_nick]'s house eh? Why are you so eager to get of there?"
mc "He is not charging you rent is he?"

scene sc11ad10 with dissolve

s "No, he is not charging me rent, but he is so controlling of what I do. I don't know what he would do if he found out about my Lonelypage!"

scene sc11ad11 with dissolve

s "And lately I feel like he has been watching me, I get a creepy feeling around him."
mc "What do you mean... creepy?"

scene sc11ad12 with dissolve

s "I get this creepy feeling like he is watching me undress in my room, or when I am getting ready for a shower."

scene sc11ad13 with dissolve

mc "Has he done anything to you?"
s "No, it's just a feeling I get when he is around. Have you talked to [vicky_nick] about me coming to live with you guys?"

scene sc11ad14 with dissolve

mc "Sabrina, we just don't have the room, maybe if we could renovate the attic into a room, but that will cost money and [vicky_nick] has not found work yet."
s "I'll give whatever I can from my Lonelypage income if that will help."

scene sc11c087 with dissolve

n "Damn, she is like a dog with a bone on this moving in with us issue, she just wont let it go. I can't allow it happen when I am so close with [vicky_nick]."
n "Wait! She just gave me an idea! I wonder if I could convince [vicky_nick] into posing for her own Lonelypage."
n "She is certainly sexy enough, I bet there is a fan base out there for some nice MILF material."

scene sc11ad14 with dissolve

mc "It would be better for you to save your money, who knows? Maybe your Lonelypage will take off and you will be able to afford your own place."
s "You really think so?"

scene sc11ad16 with dissolve

mc "Sure [sabrina_nick], you are pretty and you have a great figure. You just need to decide how far and how much you want to do for your fans."

scene sc11ad07 with dissolve

s "That's the problem, even if I post nudes, they will want more. I have seen Lonleypages where they are... doing stuff."
mc "Doing stuff?"

scene sc11ad13 with dissolve

s "Yeah, you know... stuff. Like sex acts between a guy and girl and some are even girl and girl. I am not sure I could go that far."
n "Damn... I'll have to work on her with that."
mc "Seems to me like you must decide how you are going to pay the bills. Either give the fans what they want or get a 9-5 job."

scene sc11ad15 with dissolve

mc "Whatever you decide, you can count on me to take the photos and do the editing."
s "I'm sure I can you perv. Hehe."

scene sc11c102 with dissolve

n "I continue driving her home, I know [vicky_nick] is going to be upset becasue I am out so long with the car."

scene sc11c093 with dissolve
pause

scene sc11c094 with dissolve

s "So, you're not taking me home right away are you?"
n "Damn! I can see her panties again."
mc "Yeah, [vicky_nick] asked me not to be out to late."

scene sc11c096 with dissolve

s "I see you looking."
s "I also saw you looking at the salon."

scene sc11c098 with dissolve
pause

scene sc11c099 with dissolve

mc "I ummmm... I... Well it's hard not to look, I'm a guy after all."

scene sc11c100 with dissolve

s "Sure, all guys look between their [sabrina_rel]'s legs, don't they?"
n "What the hell kind of teasing is this? Could it be that she thinks the same way I do about her?"
mc "..."

scene sc11c101 with dissolve

s "Are you sure you have to take me home right now?"
mc "I wish it was not getting late, and if [vicky_ex_nick] has been acting the way you say, then you better be getting home too."

scene sc11c105 with dissolve

s "I guess you're right. I just want you to know how much I appreciate you listening to me and being there for me."
n "She reaches over and I thought she was going to grab my hand but she kept going."
n "She rests her hand on my thigh."

scene sc11c091 with dissolve

n "Startled, I serve the car briefly, noting a devlish grin on her face as I recover the car."
mc "Sure. that's what [player_sab_rel]'s are for."

scene sc11c148 with dissolve

n "After dropping Sabrina off at home I start back for home hoping [vicky_nick] won't be mad because I awas gone too long."



scene black with fade

show text "BACK HOME"
pause

scene sc11c149 with dissolve

n "I came home to an empty feeling."
n "A cold one even..."
n "The air felt heavy, I kinda have a feeling I'm in trouble."

scene sc11c150 with dissolve

n "Shit there she is. Waiting for me."
mc "[vicky_nick]?"

scene sc11c151 with dissolve

v "Where the hell have you been?"
v "I tried calling you!"
v "I was really worried!"

scene sc11c152 with dissolve

mc "I'm sorry, I didn't think you'd be waiting up."
v "Well of course I am waiting up and worried."
v "See this is the problem with you, you don't think about others, you only think about yourself."
mc "Hey what's wrong? I feel like you're just mad for no reason."

scene sc11c153 with dissolve

v "Mad for no reason!"
v "No you've been absolute pain in the ass since we moved!"
mc "Like literally or..."
v "Don't get cute with me!"

scene sc11c154 with dissolve

v "This is part of the problem, you have very little respect for me!"
mc "Not true!"

scene sc11c155 with dissolve

v "I'm telling you right now. You've been terrible to me."
v "With your crazy demands and your borderline forcefull actions."
v "It's been non stop with you, and you've crossed the line multiple times."
mc "Wait..."
v "You don't even listen."
mc "I am though!"
v "You need to start treating me better!"
mc "OK!"

scene sc11c156 with dissolve

mc "I'm listening [vicky_nick]."
v "You say you're listening but then you do the same things."
v "You've been treating me like a piece of meat lately, and I don't need that from you."
mc "Well you're not, I love you very much."
v "I need you to show me."

scene sc11c157 with dissolve

v "I really need you to step it up."
mc "[vicky_nick]..."

scene sc11c158 with dissolve

v "No! [player_name]! You don't understand!"
v "You're my [player_rel] and we did things... you did things to me."
v "I feel like I've raised you all wrong!"

scene sc11c159 with dissolve

v "Why can't you understand this?"
mc "I do, [vicky_nick]."
v "No you obviously don't!"

scene sc11c160 with dissolve

v "You need to show me you're man enough and know how to treat a woman."
v "I am not raising a rapist pig."
n "Holy hell, she's never called me that!"
mc "I'm not!"
v "Well, I certainly was not ok with you fucking my ass like that."
n "She's still pissed, I thought we settled that issue this morning."

scene sc11c161 with dissolve

mc "IT SEEMED LIKE YOU ENJOYED IT!"
n "Now I'm yelling..."
v "I only went along with it to prevent you from doing the other thing. Just because I told you what you wanted to hear, doesn't mean I enjoyed it!"

scene sc11c162 with dissolve

vi "God, I can't believe I just said that."
mc "WHY ARE YOU SO ASHAMED OF IT?"

scene sc11c163 with dissolve

v "BECAUSE IT'S WRONG!"
mc "TO YOU!"
v "TO EVERYONE!"
mc "WELL I DON'T CARE ABOUT EVERYONE!"
mc "I ONLY CARE ABOUT YOU!"

scene sc11c164 with dissolve

v "OH MY GOD, [player_name]!"
mc "I'm sorry..."
mc "I love you..."
mc "...and I need you."

scene sc11c165 with dissolve

v "Jesus, [player_name]..."
n "Looks like she is calming down and I have her thinking again."
v "I love you too, but can you see my frustration?"
mc "I hear you [vicky_nick]!"

scene sc11c166 with dissolve

v "I just want us to be happy."
mc "I want that too!"
mc "Very much, trust me."
mc "And I'm trying, really hard."
v "I know you are."
mc "It's all new to me, you know."
mc "You were even my first kiss."
v "Jeez..."
mc "Stop that, I think it's great."
mc "You have the ability to mold me into the man you want me to be, and not some pervert."
v "I don't know, you're already a pervert."
mc "It's my hormones!"

scene sc11c168 with dissolve

mc "Trust me, I need this."
v "So you bascially want me to groom you?"
mc "Pfftt, I guess."

scene sc11c169 with dissolve

n "I could feel myself growing as I embrace her."
v "I can feel you!"
mc "I can't help it [vicky_nick]!"

scene sc11c170 with dissolve

v "How can you be horny while we are arguing?"
mc "You have no idea what you do to me..."

scene sc11c171 with dissolve

v "Your [vicky_ex_rel] would storm out."
mc "I'm not my [vicky_ex_nick]..."
mc "I'm not going anywhere..."

scene sc11c172 with dissolve

mc "I love you, please forgive me."
mc "Please know that my feelings for you are true and strong."

scene sc11c173 with dissolve

mc "Maybe that is why it's been so hard for you to accept."
mc "But as much as I am horny, I'm also in love."
v "[player_name], no..."

scene sc11c174 with dissolve

v "I might be able to go along with this if you treat the next girl the same way."

scene sc11c175 with dissolve

mc "I'm not even thinking about other girls."
n "How can I lie so easily? Sabrina, Tracy, Casandra, Sally... I'm thinking about them too."
v "Stop it..."

scene sc11c175 with dissolve

mc "Any other girl will have to be as gorgeous as you."

scene sc11c176 with dissolve

v "Charmer, is what you are..."

scene sc11c177 with dissolve

v "Seriously, who are you?"
mc "Your charming [player_rel]?"
v "MMmm, I don't know..."

scene sc11c178 with dissolve

mc "You don't seem to mind it."
v "I have my moments."
mc "Is that so? Are we having a moment now?"

scene sc11c179 with dissolve

v "I... I don't know..."

scene sc11c180 with dissolve

mc "It feels like we are..."
v "Mmm, [player_name]..."

scene sc11c181 with dissolve

v "You're getting awfully brave!"
menu:
    "Kiss her.":



        jump kissch05



label kissch05:
scene sc11c182 with dissolve

v "Hmmmp!"
n "I ease my tongue into her mouth."

scene sc11c183 with dissolve

n "My tongue explores the inside her mouth effortlessly."
n "It grazes her smoothe teeth, and even that sends me over the edge."

scene sc11c185 with dissolve

n "I pull her against me."
v "Hmmp."
n "There's very little resistance from her."

scene sc11c186 with dissolve

n "I can feel the heat radiating from her body."

scene sc11c187 with dissolve

n "I hold her closer."
n "I start to feel her push away as our tongues dance, I try to eat up any of her saliva."

scene sc11c188 with dissolve

v "Woah, there!"
v "Feels kinda of quick."

scene sc11c189 with dissolve

mc "I don't think so."
mc "Once again, it feels right!"
v "Mmm, so you say."

scene sc11c190 with dissolve

v "Y'know I'm still mad at you right?"
mc "Yeah yeah, I get it."
mc "You can't stay mad forver!"
v "I know! But we just talked!"
mc "Well let me make it up to you!"

scene sc11c191 with dissolve

v "Well, maybe!"
v "Maybe we can work something out?"
mc "Anything you wish!"

scene sc11c192 with dissolve

v "Well, I need to relax after all this..."
mc "I think I have an idea of what you want."

scene sc11c193 with dissolve

v "Is that so?"
v "Should I be worried?"
mc "No way, let me treat you!"

scene sc11c194 with dissolve

v "Wow, this is actually tempting!"
v "I don't know though, you've been a bad boy..."

scene sc11c195 with dissolve

mc "You are teasing and its killing me."
v "I'm sorry, I don't mean to tempt you..."
n "Fucking tease!"
mc "Please don't do this to me..."

scene sc11c196 with dissolve

v "I should punish you and make you keep sleeping on the couch."
mc "That would be cruel..."

scene sc11c197 with dissolve

v "The punishment should fit the crime. I don't really feel that you are sorry for what you did to me."
mc "[vicky_nick], c'mon please."
mc "...anything you wish."
v "Hmm..."

scene sc11c198 with dissolve

v "Fine, you can start by getting me a glass of wine."
mc "Yes, [vicky_nick]!"

scene sc11c199 with dissolve

n "I rush to grab the wine glass."

scene sc11c200 with dissolve
pause

scene sc11c201 with dissolve
pause

scene sc11c202 with dissolve

n "I'm literally shaking knowing what wine does to her, I can't pour the glass fast enough..."

scene sc11c203 with dissolve

n "Wine plus mom equals action."

scene sc11c204 with dissolve

n "I'm glad she's calmed down."

scene sc11c205 with dissolve

n "But something tells me even with wine, I won't be getting lucky tonight..."
n "Which is fine because Sabrina already took care of me."
n "Wow! She has changed into her nightie."

scene sc11c206 with dissolve

n "And she's not wearing any pants."

scene sc11c207 with dissolve

n "Is she getting more comfortable?"

scene sc11c208 with dissolve
pause

scene sc11c209 with dissolve

v "Don't just stand there."

scene sc11c210 with dissolve

mc "Here is you your drink, [vicky_nick]."

scene sc11c211 with dissolve
pause

scene sc11c212 with dissolve

v "I could get used to this!"

scene sc11c213 with dissolve

mc "I've told you this before."
mc "I'll treat you good."
v "I know, but you gotta understand."
v "There has to be limits."

scene sc11c214 with dissolve

mc "So what you're saying is no butt stuff?"

scene sc11c215 with dissolve

v "Jesus..."
v "Please don't ruin the mood."
mc "Im just kidding but ok."

scene sc11c216 with dissolve

n "I slightly press on her stiff shoulder."
v "Mmm"
v "Ah, yes a massage is overdue!"

scene sc11c217 with dissolve

mc "With pleasure!"
n "I start to knead her back gently."

scene sc11c218 with dissolve

v "Oh god, sweetie, that feels so good!"
n "She's gone from calling me a rapist pig to sweetie..."
n "I could feel her heart beat through her back."

scene sc11c219 with dissolve

mc "Do you want me to do your shoulders?"
v "Oh yes please, I'm very tense right now."

scene sc11c220 with dissolve

mc "And you shouldn't be."
v "I know, I know."
n "She's not wearing anything under her nightie."

scene sc11c221 with dissolve

n "Except panties."
n "Her skin looks so smooth, like a satin sheet."

scene sc11c222 with dissolve

v "Ok, if we're going to do this, we are going to do it right."
n "She puts her drink down."

scene sc11c223 with dissolve
pause

scene sc11c224 with dissolve

n "Then she lays down on her stomach."
v "I would like a massage, but no funny business."
mc "I understand."

scene sc11c225 with dissolve

mc "There's not much I can do, y'know."
v "I know you though."

scene sc11c226 with dissolve

n "Great view of her ass though."
mc "Why can't you trust me and relax?"
v "I'm trying ok?"
v "I trust you enough to be laying here in just my nightie and panties."

scene sc11c227 with dissolve

n "Jackpot! Confirmation on what's on underneath."
n "I will never grow tired of looking at her ass."
mc "Love your butt, [vicky_nick]."

scene sc11c228 with dissolve

v "I know you do."
v "A little too much."

scene sc11c229 with dissolve

n "Was that remark because I fucked her in the ass?"
n "I start slow and gentle, I could feel her relax as I knead the knots out of her muscles."

scene sc11c230 with dissolve

n "I start moving my hands down, I'd love to skip and go straight to her ass."

scene sc11c231 with dissolve

v "Mmmm, yes. My lower back has been so sore lately."
mc "Sorry."
v "It's ok my love."
n "Oh wow, my love?"

scene sc11c232 with dissolve

n "As I'm massaging her I notice her nightie is slowly riding up exposing her pink cotton panties."
n "I can feel that familair stir in my groin..."

scene sc11c233 with dissolve

n "My god."
n "This shirt is kind of bugging me, I'd love to get rid of it but I know she won't go for that yet."

scene sc11c234 with dissolve

n "I gather my courage and slowly run up my hands under her nightie just a little bit over her panties."

scene sc11c235 with dissolve

v "Huh?"

scene sc11c236 with dissolve

v "You're getting handsy!"
mc "I'm giving you a massage!"
v "You're making your way under my nightie though."
mc "Well it's in the way!"
mc "I know you wont take it off for me, so I'm just going to make my way under."

scene sc11c235 with dissolve

v "I'm wathcing you mister."

scene sc11c237 with dissolve

n "I move my way down to her thighs and give them some good squeezin."
n "She starts to hum a little to herself."

scene sc11c238 with dissolve

n "I can't take my eyes off of her ass."

scene sc11c239 with dissolve

v "You sure are spending a lot time down there..."
mc "Tell me you don't enjoy it and I will stop."
v "Hmmm."

scene sc11c240 with dissolve

mc "Well, I'm waiting..."
v "Go on..."
mc "Yes, ma'am!"

scene sc11c241 with dissolve

n "That's the ok I needed."
n "I'm inches away from her sweet pussy."

scene sc11c242 with dissolve

v "Mmmm."
n "She's not stopping me..."

scene sc11c243 with dissolve

n "I press deeper between her thighs, rubbing the panty line where it covers her cheek."
n "She's breathing harder."

scene sc11c244 with dissolve

v "Nnnnnng!"
mc "Yeah?"
v "Yeah..."

scene sc11c245 with dissolve

n "I wedge a hand between her thighs putting pressure on her crotch."
v "Sweetie..?"
mc "Yeah, [vicky_nick]?"

scene sc11c239 with dissolve

v "Can you give me a foot massage?"
mc "But of course!"
n "She must want me to stop."

scene sc11c246 with dissolve

n "I sit up on the bed and start on her foot."
v "Thank you for this, it feels so good."

scene sc11c247 with dissolve

mc "Your feet are so smooth [vicky_nick]."
v "Mmmhmm, I rub lotion on them every day."

scene sc11c248 with dissolve

n "Her toes look delicious."

scene sc11c249 with dissolve

v "Mmmm! That fees so good."

scene sc11c248 with dissolve

n "I knead and rub my way up her sole"

menu:
    "Rub her feet.":


        jump Rubfeetch05


label Rubfeetch05:
scene sc11c250 with dissolve

v "OH, fuck yes."
n "There's the cussing."
v "Mmm, GOD!"

scene sc11c251 with dissolve

n "Delicious."

scene sc11c252 with dissolve

n "Her shirt drapes her body, accentuating her curves."

scene sc11c253 with dissolve

n "I don't know why but I felt like putting her toe in my mouth."
v "Oh, jeez sweetie!"

scene sc11c254 with dissolve

mc "Yummy!"
v "Babe, what the heck!"

scene sc11c257 with dissolve

v "Isn't that's gross!"
mc "No way."
v "You're a strange boy, you know that?"

scene sc11c256 with dissolve

v "That tickles!"
n "Surpsingly her toes taste ok, and they taste clean which gave me the confidence to absolutely devour them."

scene sc11c256 with dissolve

v "Oh my god!"

scene sc11c259 with dissolve

v "Ok, sweetie enough with the toe eating!"
mc "Why?"
v "I don't know it's weird, I never had anyone do that!"
mc "Well I'm glad I was the first to do that to you."

scene sc11c258 with dissolve

mc "I want all the firsts with you."
v "Please, don't say that."
mc "No I mean it."
mc "But right now I want to make you feel good."

scene sc11c260 with dissolve

v "Oh, [player_name]."
mc "Please, its only fair."
mc "This is us making up."
v "Sweetie..."
v "Ok, maybe, umm just maybe..."
mc "Maybe what?"
v "Maybe this will help..."

scene sc11c261 with dissolve

v "I have a little something here..."
v "Just don't laugh!"
mc "I wont!"

scene sc11c262 with dissolve

v "Here it is..."

scene sc11c263 with dissolve

v "Tada!"
mc "A vibrator!?"

scene sc11c264 with dissolve

v "No silly, it's a personal massager!"
mc "Sure [vicky_nick]."
v "And it's great!"

scene sc11c265 with dissolve

v "Well this is how you make it up to me..."
v "You are so good with your hands, can't imagine how good you'll be with this thing."

scene sc11c266 with dissolve

v "This is how it works, just run it genlty on my muscles."

scene sc11c267 with dissolve

v "Want to try?"
mc "Sure, get back on your stomach."

scene sc11c268 with dissolve

"VIBRATION"

n "She's definitely horny, If play it cool and not seem eager, I bet can get her to cum."

scene sc11c269 with dissolve

v "Ok, I'm ready."
mc "Ok, relax and trust me."

scene sc11c270 with dissolve

n "I start easy on her back."

scene sc11c271 with dissolve

v "Mmmm, yeah that's good sweetie."

scene sc11c272 with dissolve

v "Um, you can go a little lower... it's my lower back that is sore."

scene sc11c273 with dissolve

mc "With pleasure."
mc "Your ass is so hot."
v "That's not how you talk to me, ok?"
n "Shit, maybe to soon for dirty talk."

scene sc11c274 with dissolve

mc "How else would I tell you?"
v "You shouldn't be..."
mc "I shouldn't be a lot of things but here we are..."

scene sc11c275 with dissolve

n "I move to her neck hoping it would shut her up a litte bit and make her relax more."

scene sc11c276 with dissolve

n "I move my hand to her thigh again."

menu:
    "Move your hand to her pussy.":


        jump movehandch05


label movehandch05:
scene sc11c277 with dissolve

n "This time I don't hesitate and move it right to her crotch."

scene sc11c279 with dissolve

v "Very naughty boy!"
mc "Yes, [vicky_nick]."

scene sc11c278 with dissolve

n "I slide my hand under her shirt, this time she doesn't say anything."
v "Mmmm."

scene sc11c280 with dissolve

n "I move the massager down to her back bone."
n "Her flesh jiggles slightly under the vibrations and I feel my cock begin to swell."

scene sc11c283 with dissolve

v "Mmmm, yes... so good..."
scene sc11c282 with dissolve

n "Throwing all caution and reason into the wind, I place it diercty on her crotch."

"BUZZZZZZ"

v "Uhnng Fuck!"

scene sc11c283 with dissolve

v "NNNNnnnnnnOOOOOOOOh."
mc "Fuck [vicky_nick], that's hot."
n "I could see her clentch the bed sheets into her fists and begin twisting them."

scene sc11c284 with dissolve

n "I move the massager lower bringing it to where her clit would be."
n "As soon as I do, her ass and thighs clench on to my hand and the vibrator."

scene sc11c285 with dissolve

v "Uh uh oh my... fuckkkkkk..."
v "sto.. st... yesss so good!"
n "she tries to tell me to stop then hissed out a long yes."

scene sc11c286 with dissolve

n "I apply pressure to her pussy, her breath catches and she starts breathing heavier."
n "I wonder if her panties are soaked..."

scene sc11c287 with dissolve

v "OH, GOD."
v "Ungh, how did I know that's what you were aiming for?"
mc "Hush and enjoy..."
v "Unngh. yes.... YES!"

scene sc11c288 with dissolve

n "She let's out a deep groan as she raises her hips up in the air."
v "YES, Yes, Uhhhh YES!"

scene sc11c289 with dissolve

n "As I press harder against her mound, she presses back even harder against it."
n "I tease her and remove the pressure, but each time she moves her hips and grinds up against it."
v "Right there, OH shit, Right there! Don't move!"

scene sc11c290 with dissolve

n "The room is filled with the sound of buzzing and [vicky_nick]'s moans and whimpers."
n "I could only imagine what it sounds like from the living room, if Sabrina was living here what would she think?"

scene sc11c291 with dissolve

n "Her feet start to curl as she gets louder."
v "Unnngh... Unnngh... Uh huh... Uh huh... Ohhhhhhh...!"
v "FUUUCK!"

scene sc11c292 with dissolve

v "Shit, I'm going to cummmm!"

scene sc11c294 with dissolve

v "Fuck, fuck, fuck, fuck!"
mc "Do it [vicky_nick], cum for me."
v "YESSSSSSS... YESSSSS... UNNNGH!"

scene sc11c293 with dissolve

v "Oh shit."
v "...so good."
mc "How was that [vicky_nick]?"

scene sc11c295 with dissolve

n "She falls over on her side, exhausted."

scene sc11c296 with dissolve

v "...jeez...that was... that felt incredible."

scene sc11c298 with dissolve

mc "Straight to sleep eh?"
v "I have not had an orgasm that strong in years, I feel so drained."

scene sc11c300 with dissolve

n "I crawl on to the bed behind her and start kissing her neck."
n "Maybe she'll take care of me."

scene sc11c299 with dissolve

mc "I love you."
v "I love you too."
v "Thank you."
mc "Are we even now?"

scene sc11c301 with dissolve

n "I cuddle up behind her and lay my arm across her."
v "Mmmm yes, cuddle me."

scene sc11c302 with dissolve

mc "Damn [vicky_nick], that was really something."
v "Yeah sweetie, can we not talk about it?"
mc "Sounds like someone has \"post-nut clarity...\""

scene sc11c305 with dissolve
pause

scene sc11c304 with dissolve

v "I don't even know what that means and I don't want to know!"
mc "Heh, it's a guy thing really."

scene sc11c303 with dissolve

v "Lets just cuddle, I feel so relaxed now."
mc "Look, I'm not asking for much but I think we should talk about it."
v "Talk about what?"
mc "Us having sex."

scene sc11c306 with dissolve

v "Look, I know you're worried about me not taking care of you sexually tonight..."
mc "No that's not it."
v "Well, I know you well enough by now. Don't worry."
mc "Don't worry? You're still my girlfriend?"

scene sc11c308 with dissolve

v "I don't know about girlfriend, I'd like to think I'm mostly educating you."
mc "Education with benefits?"

scene sc11c307 with dissolve

v "Haha, yes. Tonight I certainly benefited."
mc "Tomorrow... maybe I can benefit too?"

scene sc11c308 with dissolve

v "We will see."
mc "That's good enough, I won't push it any further."
v "Hehe, good boy."
v "Can we please get some rest now?"
v "I'm exhausted."
mc "Yes, [vicky_nick]."

scene sc11c305 with dissolve

n "We snuggled up, I keep my hips away from hers so she will not feel that I have a throbbing hardon. I calm myself and I begin to drift off listening to her slow content breathing."
n "Things happen to work out like this between us, maybe she needed to yell at me."
n "Either way I can't wait for what's to come."







scene splash with fade
"Thanks for playing"
"Come back for more updates."
pause

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
