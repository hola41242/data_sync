label chapter1:





show text "CHAPTER ONE" with dissolve
pause

scene sce01013 with dissolve

n "Man, look at [vicky_nick]'s ass, I can still make out her curves through her baggy clothes."
v "Look it even came with a TV!"
mc "I'm looking forward to movie nights!"
n "Or watch porn on the big screen. Shit, I'm such a pervert."

scene sce01014 with dissolve

v "Oh no! It looks like there's only one bedroom. That can't be right."
mc "Why would [vicky_ex_nick] give you a one bedroom house?"
v "This must be him getting back at me! What an old jerk."
mc "Or he thought I was going to stay with him."

scene sce01015 with dissolve

v "Can you believe this?"
v "He really had to have the last laugh. That man was always trying to get back at me."
mc "It's ok [vicky_nick], I can sleep out here on the couch."

scene sce01016 with dissolve

v "I'm so sorry. You're sure you will be ok on the couch for little bit until we figure something out? Maybe we can find a hide-a-bed couch or a fold up bed..."
mc "Of course, [vicky_nick]. I'm sure I can manage all summer, and your right here next door. So I can keep an eye on you."
n "Oh I'm for sure going to keep a close eye on her!"

scene sce01017 with dissolve

v "Oh you're the sweetest, I will make it worthwile. I'll treat my handsome [player_rel] so nice."
n "That sounds real good to me."

scene sce01018 with dissolve

v "I'm just so glad to be spending summer with you. We could really bond this year."
mc "I'm really glad I'm stuck with you [vicky_nick]."

scene sce01019 with dissolve

v "Oh so now your stuck with me!?"
mc "I'm just joking [vicky_nick], haha."
n "I really like teasing her, it really riles her up."

scene sce01020 with dissolve

v "Oh [player_name], where would I be with out you?"
mc "I don't know [vicky_nick], but im glad it's here with me."
n "The heck, why am I so corny."

scene sce01021 with dissolve

v "You're the sweetest, come here I want to give you a kiss."
n "Mmm, all the ass kissing is getting me somewhere."

menu:
    "Oh she's leaning in for a kiss."
    "Look down her shirt.":

        "I can try and look down her shirt."
        jump lookdownshirt

label lookdownshirt:

scene sce01022 with dissolve

n "Holy shit, I can see down her blouse, I can almost make out her tit."
n "She smells so nice, I'm having an urge to grab and hug her sweet soft body."
n "Man this is insane, what has come over me, I'm absolutely aroused by her. Everything she does is sexy to me."

scene sce01023 with dissolve

n "Her sweet warm lips on my cheek sends tingles down my spine."
n "I can't imagine what that mouth would feel like, I need to see if I can push the boundaries this summer."

scene sce01024 with dissolve

v "You ok?"
mc "Yeah [vicky_nick], just enjoying that kiss."
v "Don't be silly. Plenty of kisses to go around"
mc "I sure hope so!"
v "You're being silly. I'm going to get out of these stinky clothes and unpack. We should make somethiong to eat before bed."
n "She usually says I'm being silly when I'm making her uncomoftable."
v "We have cleaning to do in the morning. We need to make this place comfortable for us."

scene sce01025 with dissolve

n "Man I gotta try hard and not screw it up. But I need to see more of [vicky_nick]."
n "She is so damn sexy. I need to see more of her body. As a kid I only caught a glimpse here and there, maybe this will change things."
n "I need to play it cool, this is going to be a great summer."

scene black with dissolve

show text "FIRST NIGHT"
pause

scene black with dissolve

n "Night time came and it took [vicky_nick] a couple of hours to unpack."

scene sce01026 with dissolve

v "I smell Coffee..."
v "Are you crazy making coffee at this hour?"

scene sce01027 with dissolve

n "Man, she looks sexy as hell in her robe."
mc "Relax, it's decaf and it's all there was to make. We will have to go to the store as soon as possible."

scene sce01028 with dissolve

v "You're very creative. I would have never thought decaf coffee before bed, but I gotta admit it smells good."
v "It feels like we're newlyweds or something."
mc "Oh yeah? Is this giving you honeymoon vibes?"
v "All of this is very exciting and new."

scene sce01029 with dissolve

v "I will make grilled sandwhiches. Let me find some pans."
n "Her ass looks great in that robe, she really is in great shape."

scene sce01030 with dissolve

v "Found some pans!"

scene sce01031 with dissolve

v "We really need to go shopping, A.S.A.P."

scene sce01033 with dissolve

mc "Yes [vicky_nick], as soon as we unpack and clean."
v "I'll make a shopping list. Oh, I'm so excited!"

scene sce01034 with dissolve

v "I promise we will have such a good time. I won't bore you one bit I promise!"
n "She has always loved to please others, maybe she'll do anything to please me."
mc "I don't doubt it one bit, so far you seem like a pleasurable woman to be around."

scene sce01035 with dissolve

v "What's that supposed to mean?"
v "You're already starting to sound like your [vicky_ex_rel]."
v "Are you being sarcastic?"
mc "No way, I'm looking at you right now and I see a very vibrant woman. I want to be around you."
n "That was a little awkard, she might be catching on that I have the hots for my own [vicky_rel]."

scene sce01036 with dissolve

v "I'm going to take that as a compliment."
n "Is it me or is it getting hot in here?"
n "She usually dressed modestly, her robe is barely covering her. Looks like someone is getting comfortable with me."
n "I don't mind that one bit. I want her to wear skimpy outfits around the house."

scene sce01037 with dissolve

n "Jeez, those tits are in my face, she seems to be doing it on purpose."
n "That robe is really getting in the way of the goods."

scene sce01038 with dissolve

n "I need to make a move or something, I just want to undress her right here."

scene sce01039 with dissolve

mc "That was good [vicky_nick], let me help you with the dishes."
n "Here's my chance, maybe I can cop a feel."
v "That's ok, I can do the dishes."

scene sce01040 with dissolve

mc "Mmm, You smell good [vicky_nick]."
v "Don't be silly! I didn't even shower yet."
n "Here goes nothing."

menu:
    n "Lets see how comfortable she is..."
    "Lift her robe.":

        scene sce01041 with dissolve
        n "Let's see what we have here."
        jump liftrobe

label liftrobe:

v "[player_name], stop playing around."
n "I'm just going to catch my finger on her robe."

scene sce01042 with dissolve

n "And we have lift off."

scene sce01043 with dissolve

v "What are you doing back there?"
n "Oh shit."
mc "Huh, what, nothing."

scene sce01044 with dissolve

v "Hey what are you doing?!"
mc "Nothing, [vicky_nick]. What happeend?"

scene sce01045 with dissolve

v "Did you just lift up my robe?"
n "Oh shit, I'm so busted."
mc "Sorry [vicky_nick], it was an accident."
v "An accident?"
n "She's not buying it!"
n "Looks like I took it too far. She's not as comfortable as I imagined."
v "Looks like you're finishing the dishes."

scene sce01046 with dissolve

v "...I'm going to call it a night."
n "Man she sounds pissed, I haven't seen her this mad since those times [vicky_ex_nick] would come home drunk."

scene sce01047 with dissolve

v "Goodnight,,,, {i}{b}[player_rel]{/b}{/i}."
n "Damn, she turned on a dime."
n "The way she said \"[player_rel]\", she must be very upset."

scene sce01048 with dissolve

v "We will talk about this in the morning."
n "Oh, Shit, I really don't want to talk about it in the morning."
mc "Alright, [vicky_nick]."

scene sce01049 with dissolve

n "How am I supposed to sleep now? She's probably going to chew me out in the morning."
n "Great! It's going to be a long night."
n "I better appologize."

call phone_start from _call_phone_start_2
call reply_message ("Hey [vicky_nick] you sleeping?") from _call_reply_message_13
call message ("[vicky_nick]", "not yet...") from _call_message_13
call reply_message ("I just wanted to say im sorry and have a good night") from _call_reply_message_14
call message ("[vicky_nick]", "<3") from _call_message_14
call phone_end from _call_phone_end_2

scene black with dissolve

show text "NEXT MORNING"
pause

scene black with dissolve

v "Hey, wake up."

scene sce02001 with dissolve

v "[player_name]?"

scene sce02002 with dissolve

v "Wake up, [player_name]."

scene sce02003 with dissolve

v "Wake up, I want to talk to you."
n "Shit, here we go."

scene sce02004 with dissolve

v "Scooch over, let me sit next to you."
n "She looks nice."
v "You sleep ok?"

scene sce02005 with dissolve

mc "...Morning."
mc "It was a little uncomfortable, but yes"
n "Oh, man this isn't good."

scene sce02006 with dissolve

v "OK, I wan't to talk to you about last night."
mc "About that [vicky_nick], I'm sorry."
v "What got into you?"
n "I better think of something good."
mc "I don't know [vicky_nick]. It's been very difficult lately."

scene sce02007 with dissolve

v "What has been difficult? Did I do something wrong?"
mc "No, you did nothing wrong, as a matter a fact it's because you're doing it right."
v "What the hell does that mean?"

scene sce02006 with dissolve

mc "Well [vicky_nick], it's been very frustrating spending all this time with you."
v "I don't understand [player_rel], I thought you loved spending time with me."

scene sce02012 with dissolve

mc "I'm not a boy anymore and I have these feelings,,, these urges."
v "Spit it out, what's going on?"
n "I guess I'll just let it all out."

scene sce02007 with dissolve

mc "When I'm around you I get... aroused, there I said it."

scene sce02009 with dissolve

v "... I'm sorry, what was that?"
mc "I get really horny."
mc "I get a dizzy feeling. My heart beats faster."
mc "And I get these overwhelming urges, I don't know what to do with myself. I have no girlfriend and with all that has been going on with the move, I haven't had time for anyone else."
v "Oh [player_rel], that is a lot, I'm so sorry."

scene sce02010 with dissolve

v "...Jeez, [player_name] how long has this been going on?"
mc "As long as I can remember [vicky_nick]."

scene sce02011 with dissolve

v "But, I make you HORNY?!"
v "...But I'm your [vicky_rel]!"
mc "Yes, [vicky_nick], but not in a weird way."

scene sce02009 with dissolve

v "Not in a weird way?!"
mc "Yes, I mean no, I just think you're so beautiful. And I feel good when I look at you."

scene sce02011 with dissolve

v "Well, I don't know what to say."
n "I need to try and smooth things over with her."
mc "[vicky_nick], I don't want this to get between us, because I want us to bond so much. I want us to be happy and be close, and have nothing weird between us."

scene sce02009 with dissolve

v "This wont get between us, I promise."
v "I want you to know that It's normal...to feel like this..."

scene sce02006 with dissolve

mc "It wont get between us I wont let it, as long as I get my release everything will be just fine."

scene sce02009 with dissolve

v "Release?"
v "What does that mean? What do you mean by release?"
mc "I just feel like I need to go through with what I want, in order to feel this release."

scene sce02010 with dissolve

v "Well what does that mean, I'm confused."
v "It can't be anything inappropriate!"

scene sce02008 with dissolve

mc "It's nothing bad I promise, for example when you do house work I just want to look at you."
v "Ok, but what does this have to do with lifting my robe."
mc "I think it's physicality that allows us to bond, I need to get closer to you."
mc "I just wanted to look. It's no different if the wind came by and blew it up."

scene sce02010 with dissolve

v "Ok, I mean look all you want I guess. There's not much to see."
mc "Then there's no problem?"

scene sce02009 with dissolve

v "I guess not, I just don't want you to be frustrated with me."
v "And I get how hard it is with me being around you all the time."
n "Man she's going along with it."
mc "I just think you're so beautitful that I get these urges, it's beyond frustrating and I just need to get them out of the way so we can just spend time together."
v "You're so sweet."

scene sce02006 with dissolve

mc "You just do your thing [vicky_nick], and don't mind me, ok?"
v "I guess so. We do have a lot of chores!"
v "I need to vacuum and clean this place up before our stuff arrives."

scene sce02013 with dissolve

v "Ok, you ready?!"

scene sce02014 with dissolve

mc "Ready for what?!"

scene sce02013 with dissolve

v "Ready to vacuum!"
mc "Oh jeez, yes go ahead and start cleaning I guess."

scene sce02014 with dissolve

v "Ok, I'll go get the vacuum."

scene sce02015 with dissolve

n "She started vacuuming straight away, she seemed to be aware of me more than usual."
n "I kind of just sat there watching her. Already horny from the talk, my heart still racing."
n "It's almost like she gave me the green light to perv on her, and her every move seemed intentional."

scene sce02016 with dissolve

n "I was able to move around her doing various chores and setting stuff out. But mostly I was just trying to get a better look at her."
v "I have to wash the windows too. Hand me a rag please."

scene sce02017 with dissolve

n "I handed her the rag and she started cleaning the windows which was pleasant to watch."
v "Thanks, this is actually nice."
mc "You're really good at this."
v "Haha, What washing windows?"
mc "You look good doing anything."
n "I liked her in this pose, my heart started pounding in my chest, I knew I had to get closer."
n "What would she do?"

scene sce02018 with dissolve

v "[player_name], I can feel your eyes on me."
n "Oh man, she caught me. But I'm going to stand my ground."
mc "You have very nice legs [vicky_nick], I can't help but admire them."
v "...Thanks.., I gotta go clean the kitchen table now."
n "Oh man she's ok with it!"
mc "No problem, [vicky_nick]."

scene sce02019 with dissolve

v "Wow this table is surprisingly filthy."
v "And small! You think it's big enough for the two of us?"
mc "Yeah it's fine for now."
n "Feels like she's waiting to see if I perv out on her here too."
v "Yeah, I'm wondering what we'll do when your [sabrina_rel] comes to visit."

scene sce02020 with dissolve

n "She was busy scrubbing as I sat down behind her."
n "The view was better from here and I knew she suspected I was there, waiting to see what I'd do."
n "My heart is beating so fast right now, I want to see what kind of panties she's wearing this morning."

menu:
    n "Here I go."
    "Lift her skirt.":

        scene sce02021 with dissolve
        n "Let's see."
        jump liftskirt

label liftskirt:

n "Just a little fabric seperating her private parts. How tempting to rip them off of her."

scene sce02023 with dissolve

v "[player_name]! Again!?"

scene sce02021 with dissolve

mc "Sorry [vicky_nick], this is what I'm talking about. I need this release right now."
v "But [player_name] that's so wrong, I'm your [vicky_rel]. What about this is a release for you?"

scene sce02023 with dissolve

v "You're just looking up my skirt!"
mc "Yes I just had to see what panties you were wearing."

scene sce02024 with dissolve

v "You just want to see what panties I'm wearing?!"
mc "Yes, [vicky_nick]."
v "Jeez, I don't know..."
v "...Will it help if I show them to you?"

scene sce02025 with dissolve

v "If I show you my panties, will that give you release?"
mc "Yes, please [vicky_nick]. Show them to me."
v "[player_name], that's so wrong. On so many levels. If I show them to you will it help you release?"
mc "Do it slowly [vicky_nick]."
n "Man this is wild, she's going along with it. I can tell she's nervous her hands are slightly shaking."
v "This is so embarrassing."
mc "Oh god [vicky_nick], don't be embarrassed, you're so sexy."
v "Oh I don't know... it's so wrong."
v "I can't believe I'm doing this."

scene sce02026 with dissolve

n "I can't believe she's going along with this."
n "Her cute panties, and she's showing me where her naughty parts are."

scene sce02027 with dissolve

mc "Oh god, [vicky_nick]."
v "What!? What's wrong!?"
mc "Nothing you're perfect."
v "Ok [player_name], this is a little uncomfortable."

scene sce02028 with dissolve

v "That's it ok?"
v "...Are you satisfied?"
n "I better not creep her out now, I'm pretty satisfied as it is."
mc "Yes [vicky_nick], thanks for being so understanding with me, I feel very satisfied."

scene sce02029 with dissolve

v "You understand how weird this is, right?"
mc "I know [vicky_nick], I'm sorry I just have these urges."
v "That's fine [player_rel], but let's not make a habit of this and please don't tell anyone."
v "I can't imagine anyone understanding this, this is so wrong."
mc "I understand [vicky_nick], no one can know what a creep I am."
v "No, you're not a creep. This is perfectly natural for someone your age."
n "Nice, do you like how I played the sympathy card?"

scene sce02030 with dissolve

v "Alright, I'm glad that's over with. We gotta get ready and get some groceries."
mc "Ugh, Do I have to? Can't I just stay here?"

scene sce02031 with dissolve

v "Am I hearing you correctly? After how I just helped you with your \"release\", you really don't want to go shopping with your [vicky_rel]!?"
mc "Don't be mad I just want to relax..."
v "You mean you want play with yourself?"
mc "What? No I want to unpack and find my camera, I swear..."
v "Maybe this will change your mind?"

scene sce02032 with dissolve

n "What the hell? She's teasing me!"
v "Well are you going to go shopping with me?"
mc "Haha, now you're speaking my language!"

scene sce02033 with dissolve

v "Oh my gosh, you're such a little pervert."
n "Watching her run off like a little girl begging to get chased down and taken turned a switch in me."
n "I'm going to have her."
mc "You better watch yourself [vicky_nick]."

scene sce02034 with dissolve
n "I better get these boxes out of the way."
n "I can't believe she's teasing me with her ass."
n "That sweet sweet ass."

scene sce02035 with dissolve

n "Maybe there is hope yet, maybe I will get lucky with her this summer. I can't believe how much I desire her."

scene sce02036 with dissolve

n "This should be the last of our boxes."
n "One of these should hold my camera, I should find it and see if i can take some hot pictures of [vicky_nick]."

scene sce02037 with dissolve

n "Nice, here it is. No major damage."

scene sce02038 with dissolve

mc "[vicky_nick], I found my camera!"

scene sce02040 with dissolve

v "Thats great [player_name], we should go and get groceries"

scene sce02042 with dissolve

mc "Hey, [vicky_nick] what do you say we have a photo shoot?"
v "A photo shoot?"
v "I haven't been in front of a camera in ages, I'm what you call old school, hehe."
mc "What are you talking about [vicky_nick] youre so gorgeous. You'd be great for my portfolio."
v "Maybe another time we need to go get groceries."

scene sce02043 with dissolve

mc "I'll go get groceries with you if you promise we can do a photo shoot."

scene sce02044 with dissolve

v "We can discuss that after we get back."
mc "Also I get to pick what you wear!"
v "Oh, I don't know about that."
mc "Remember how you said you wanted to bond this summer, well this is it and you're going to have to trust me."
v "Ok but let's keep it PG."
mc "PG-13, maybe."

scene sce02045 with dissolve

v "You're going to get me in trouble, huh?"
mc "You're saying it like it's a bad thing."
v "Oh you're being silly, let's get moving."

scene black with dissolve

show text "TO THE GENERAL STORE AND BACK"
pause

scene filler02 with dissolve

n "The flirtatious vibe stayed in the car."

scene sce02046 with dissolve

n "I tried to mind my own buisiness looking out the window but found my eyes slowly creeping back to her."

scene sce02047 with dissolve

v "I can feel your eyes on me."
mc "Oh, shit, sorry [vicky_nick]. I can't help it."

scene sce02048 with dissolve

v "I didn't say it was a bad thing."
n "Man, she gets my heart going when she starts playing back."

scene sce02049 with dissolve

n "We arrived at the small market, the whole time I was staring at her skirt."

scene sce02050 with dissolve

n "Man, I'm so horny I need to cum."
n "It's the first thing I'm doing when I get back, going to unload a huge one thinking of my [vicky_rel]."

scene sce02051 with dissolve

n "Jeesus look at that ass, it's driving me insane."

scene sce02052 with dissolve

n "Shit, I think she's getting annoyed. I think it's pretty obvious I can't stop staring at her."

scene filler02 with dissolve
pause

scene black with dissolve

show text "BACK HOME"
pause

scene sce02053 with dissolve

n "I couldn't wait to get home and jerk off, I ran into the bathroom first thing."
n "I almost tore my pecker off with the zipper."
n "I was blue balled to hell."

scene sce02054 with dissolve

v "Hey [player_rel]."
mc "huh, [vicky_nick]?"
n "Am I fucking dreaming."
v "Let your [vicky_rel], help you with that."

scene sce02055 with dissolve

mc "Oh [vicky_nick], I need you please."
v "Take it out and show me where it hurts."

scene sce02056 with dissolve

v "Do you want your [vicky_rel] to use her mouth?"

scene sce02057 with dissolve

mc "Fuck yes, please suck me off."
n "Her mouth would feel so nice, her tongue, I can't even imagine."

scene sce02058 with dissolve

v "Mmmm,... pfft. pfft. "
mc "That's so nice, [vicky_nick]."

scene sce02057 with dissolve

mc "Deeper, [vicky_nick]."

scene sce02058 with dissolve

v "Mmmm, [player_name]."

scene sce02057 with dissolve

n "I want to fill her throat with cum."

scene sce02058 with dissolve

v "So sweet, mmm, Big cock."

scene sce02057 with dissolve

mc "Getting so close."

scene sce02058 with dissolve

mc "I'm going to cum.."

scene sce02057 with dissolve

v "Give it to [vicky_rel]."

scene sce02059 with dissolve

v "What a huge load!"
mc "Thanks [vicky_nick]."

scene sce02060 with dissolve

v " I love to swallow your huge load, I hope there's more for me."
mc "uhhhh......"

scene sce02061 with dissolve

n "Fuck!"
n "I made a mess of the floor."

scene sce02062 with dissolve

v "[player_name], everything ok in there?"
mc "Yes! I'll be out in a minute."

scene black with dissolve

show text "A LITTLE WHILE AFTER"
pause

scene black with dissolve

n "I ended up passing out on the couch, that load drained the life out of me."
n "I can hear her rustling around, now I can feel her eyes on me."

scene sce0301 with dissolve

v "I'm sorry, didn't mean to wake you from your nap, do you mind If I do do some stretching?"
mc "No I don't mind."
n "Nice she wants to show off, she could have easily done this in her room or while I was sleeping."

scene sce0302 with dissolve

v "I didn't know if you were watching the televesion or something."
mc "I rather watch you do your stretches!"

scene sce0303 with dissolve

v "Very well."
n "She drops down on her yoga mat, and I get the perfect look at her behind. It's glorious."
n "Amazing curves, she really did manage to stay in shape while being a full time [vicky_rel]."

scene sce0304 with dissolve

n "And if she does gain a little weight it goes straight to her hips."
v "You know it's wrong to look at your [vicky_rel] like this."

scene sce0305 with dissolve

mc "Can you blame me?"
v "You really need to find a girlfriend."

scene sce0306 with dissolve

mc "Yeah, they don't make girls like you anymore."
v "Haha!"

scene sce0308 with dissolve

v "Don't say things like that to me!"
mc "It's true, [vicky_nick]."
mc "You're the prettiest woman I've ever seen."

scene sce0309 with dissolve

v "I'll take it."
v "So bad talking to your [vicky_rel] like that, but I will allow it just this once."

scene sce03010 with dissolve

mc "I don't know [vicky_nick], I think you enjoy it more than you'd like to admit it."

scene sce0309 with dissolve

v "Ok, Ok, I'll admit I do enjoy the attention, but I don't want it to get out of hand."
mc "I do."

scene sce03011 with dissolve

v "What do you mean by that?"
mc "Uhhh, I do want it to get out of hand."
v "My god, talking to your [vicky_rel] like that, it's so inappropriate!"

scene sce03012 with dissolve

mc "Sorry, didn't mean to upset you."
v "Mhmm, Ok, [player_name]."
n "Oh shit, her titty popped out."

scene sce03013 with dissolve

n "Oh man, it's a nice little nipple."

scene sce03014 with dissolve

mc "Uh, Hey [vicky_nick]."

scene sce03015 with dissolve

v "Yes?"
v "What now?"
v "You got anymore perveted one liners to throw at your [vicky_rel]?"

scene sce03016 with dissolve

mc "Um, no not really."

scene sce03017 with dissolve

mc "Just uh, ....here."
v "Hey!"

scene sce03018 with dissolve

mc "There."

scene sce03019 with dissolve

v "I'm sorry, I didn't mean to snap..."
mc "Trust me, I wanted to lunge at that titty, really, really badly!"
v "[player_name]!"

scene black with dissolve

show text "AFTER DINNER"
pause

scene sce03020 with dissolve

n "She was washing dishes as usual, and even her comfy clothing didn't hide her beautiful ass."
mc "Hey [vicky_nick]."

scene sce03021 with dissolve

n "She promised me a photo shoot and she doesn't know it yet but I already laid out some clothes for her to try on."

scene sce03022 with dissolve

v "Yes?"
mc "You almost, done?"
mc "You promised me a photoshoot."
v "Really, tonight?"

scene sce03023 with dissolve

v "I don't know if I'm up to it."
v "It's getting kinda late and honestly, I don't know how I feel about the idea of my [player_rel] taking photos of me."

scene sce03024 with dissolve

mc "But you promised."

scene sce03025 with dissolve

v "And who's going to see these photos?"
mc "It's just for me [vicky_nick]."
v "That's what I'm worried about!"

scene sce03026 with dissolve

v "I don't know..."
mc "Strike a pose."
v "[player_name], please let me finnish the dishes."
mc "Alright, alright."

scene sce03027 with dissolve

mc "I picked out some clothes for you to pose in. They are in your room, you can go ahead and change when you're ready."

scene sce03028 with dissolve

v "You went into my room and picked out clothes for me to wear!?"
mc "Yeah Just like any photo shoot, it's my vision and I need you to look the part."

scene sce03029 with dissolve

v "This is an unhealthy [vicky_rel]-[player_rel] relatiopnship, do you understand what you're asking me?"
mc "I think you need to start treating me like an adult, [vicky_nick]."
mc "What are you afraid of?"

scene sce03030 with dissolve

v "You are crossing the line."
mc "No [vicky_nick], there's no line to cross here, were closer than that."

scene sce03031 with dissolve

v "Ok, but promise me this is nothing bad."
mc "If you feel like it's not right we can stop at anytime."
v "Fine, you can have your photoshoot. Just don't make me look ugly or I wont do it again."
mc "Impossible, I'll see you in a few."

scene sce03032 with dissolve

vi "What have I gotten myself into?"

scene black with dissolve

show text "THE PHOTOSHOOT"
pause

scene black with dissolve

n "My heart is racing. I can't wait to see her in the outfit I chose."

scene sce03033 with dissolve

v "ummm [player_name]..?"
n "Great, she sounds unsure, the outfit was a little much."
v "I don't know about this."
mc "I bet you look great [vicky_nick]."

scene sce03034 with dissolve

v "How did you even find this!? I didn't know I owned half of this!"
mc "Trust me I had to look hard, we gotta take you shopping."
v "Now you're talking dirty!"
scene sce03035 with dissolve

v "[player_name], please this is embarrassing."
mc "C'mon [vicky_nick], let's take a look."
scene sce03036 with dissolve
mc "Look at you!"

scene sce03037 with dissolve

v "I feel like a hooker."
mc "No way [vicky_nick], you are so sexy."
mc "If you were a hooker, you'd be a very expensive one."

scene sce03038 with dissolve

v "Please [player_name]!"
mc "Jesus [vicky_nick], you are fine."
v "Does the back look ok? I feel like it's showing too much. "
mc "You look amazing [vicky_nick]!"
v "Oh [player_name], you're being sweet!"

scene sce03039 with dissolve

v "These shoes are nice though, I like them!"
mc "Ok [vicky_nick], it's about you though not the shoes, start moving."
v "Don't make it pervy though."

scene sce03040 with dissolve

v "Been looking for this blouse for forever too! Thanks [player_name]."
mc "It all looks good [vicky_nick]!"
v "Oh, you already started, what do you want me to do?"

scene sce03041 with dissolve

mc "Start moving, [vicky_nick]. I know you've done this before!"
v "How's this?"

scene sce03041 with dissolve

mc "Dance I need some action shots!"

mc "Hop on the couch and do some celebrating!"

scene sce03042 with dissolve

v "I hope I don't ruin the couch!"

scene sce03043 with dissolve

n "Her skirt is barely covering her, this is great."

scene sce03044 with dissolve

n "I can barely keep her in focus!"

scene sce03045 with dissolve

n "Turn around!"

scene sce03044 with dissolve

mc "God you're hot!"
v "What!? I can't hear you!"

scene sce03045 with dissolve

v "I hope you're not only taking upskirt shots."
mc "Not just that [vicky_nick]."

scene sce03046 with dissolve

v "Phew! I'm friggin tired, that was a lot. Haha, let me catch my breath."

scene sce03047 with dissolve

v "Did you get the footage you wanted?"
mc "I did [vicky_nick], you looked great!"

scene sce03048 with dissolve

v "That was actually fun, you might have a future in this after all!"
mc "I can't wait to edit these."
v "Oh boy, I don't even want to know what you're going to do with them."

scene sce03049 with dissolve

v "[player_name]?"
mc "Yeah [vicky_nick]?"
v "I didn't say anything but along with the skirt, shoes and blouse you also picked out the panties..."
mc "I really thought the panties suited your curves."

scene sce03048 with dissolve

v "...Noted."

scene sce03038 with dissolve

v "Well, on that note...I'm going to go change now."
mc "Thanks, [vicky_nick]."
v "Mhmm, you're welcome."

scene black with dissolve

show text "MOVIE NIGHT"
pause

scene fil03 with dissolve

n "Man, what a day. [vicky_nick] sure has my blood boiling. That photoshoot was so hot."

scene fil05 with dissolve

v "Hey, are you already watching the movie with out me?"
mc "No way, just warming up the television."

scene fil06 with dissolve

n "She's so gorgeous."
v "Well, let's watch something then!"
mc "Want to watch soemthing sexy?"

scene fil07 with dissolve

v "[player_name], can we watch something appropriate please."

scene mn01 with dissolve

mc "What do you want to watch?"
v "Nothing super-hero related."

scene mn02 with dissolve
n "She propped her legs up on my thighs, I got the feeling she was hinting at a foot message."

menu:
    "Offer a foot massage.":

        jump footmassage

label footmassage:

mc "You want a foot massage?"
v "A foot massage? Oh, that sounds so good, my feet have been achy lately."
v "And I haven't had one in a long time."
mc "It'll feel good I promise."

scene mn03 with dissolve

v "You've been so good to me lately."
v "you really make me feel like woman lately, even if some of your actions are a little perverted, hehe."
n "Damn her robe is slipping and I can see a hint of her nipple!"
mc "I can't change how I feel about you [vicky_nick]."
v "Honestly [player_name], I don't know if I want you to change."

scene mn04 with dissolve

n "Her feet are so soft."
n "I'm going to start at her calf muscle and move up."
mc "You deserve to be treated like a queen [vicky_nick]."
v "I feel like one with you."

scene mn05 with dissolve

n "She's starting to relax and enjoy herself."
n "I can feel her body going limp and she's giving into me."

scene mn06 with dissolve

n "Oh wow, she's really relaxed now, her little moans are starting to get louder."
n "Her breathing is slowing down."
v "That feels good, you can add more pressure if you want."
mc "I love this new intimacy between us [vicky_nick]."
v "I am enjoying it as well, and I knew this move would be good."

scene mn07 with dissolve

n "She moaning like a little slut now."
v "Oh [player_name], that feels so good! You're hands are magical."
mc "I want you to feel this good all the time, [vicky_nick]."

scene mn08 with dissolve

n "Mmmm, God. It almost seems like she's going to cum."
v "I would trade one of your perverted photoshoots for a lovely massage anyday, just for your information, hehe."
mc "Don't worry, [vicky_nick]. I got more photoshoots planned out."
v "Just keep it PG, naughty boy."

scene mn09 with dissolve

mc "You're skin is so smooth [vicky_nick]."
v "Mmm, your hands are good."
n "I'm going to move my hand a little higher."
mc "You're upper leg mucles seem sore too."
v "So sore, so sore..."

scene mn10 with dissolve

n "She doesn't mind my hand being inches away from her pussy."
n "She's really letting her guard down as she lets out little whimpers."
v "Mmmmm..."

scene mn11 with dissolve

n "She's starting breathe faster, letting out little moans."
n "Her robe is falling apart on her too, what a beautiful sight."

scene mn12 with dissolve

v "Mmmmm."

menu:
    "Move hand closer.":
        n "I inch my hand slowly up the inside of her thigh."

        jump movehand

label movehand:

scene mn11 with dissolve

n "I start to rub up against the side of her labia, her panties feel a little damp."
n "As I'm massaging her inner thigh my fingers slowly come to the edge of her panties and...."

scene mn13 with dissolve

n "She jumps up on her feet adjusting her robe."
v "[player_name]!"
mc " What's wrong [vicky_nick]?"
v "I have stop this!"
mc "But why?!"
v "It's getting out of hand."
mc "But [vicky_nick] this was so nice."
v "It's very inappropriate. I'm going to bed."

scene fil01 with dissolve

n "Dang, so close."

scene fil02 with dissolve

n "But I swear I could feel the sexual tension between us."

scene black with fade

scene sce03050 with dissolve

mc "[vicky_nick]?"
v "Yes..?"

scene sce03051 with dissolve

mc "I'm sorry."
v "That was all my fault, it was very indecent of me."

scene sce03052 with dissolve

mc "How can it be indecent if it feels good?"
v "Becuase I'm your [vicky_rel]!"
mc "But I feel even closer to you!"
mc "I really enjoy being intimate with you."

scene sce03053 with dissolve

v "I know we've been bonding but imagine what people would think."
mc "I don't care about them! They're not here!"
mc "I don't want this to stop."
mc "I want to be able to touch you and kiss you without feeling like a creep!"

scene sce03054 with dissolve

v "You're not a creep!"
v "And I guess you can kiss and touch me, but I draw the lines!"
mc "That's fine [vicky_nick], I wouldn't do anything to make you feel bad I only want to make you feel good."

scene sce03055 with dissolve

mc "I feel safe with you and I want to be intimate."
v "And I feel safe with you too, I don't mean to over react, but it does not change that it is inappropiate."
mc "Don't be scared [vicky_nick], it's just us right now, and no one else."

scene sce03056 with dissolve

v "Come here and give me a kiss goodnight."

scene sce03057 with dissolve

n "Her mouth is open, this isn't just a kiss."

menu:
    "Kiss her passionately.":
        n "I lean in and press my lips against hers."

        jump kissher

label kissher:

scene sce03058 with dissolve

n "I feel her tongue glide past my lips, I'm going to meet it with mine."
n "Her lips plunge into mine, I taste [vicky_nick]'s spit for the first time."

scene sce03059 with dissolve

n "It becomes a long kiss and she moves her body to face mine."
n "She's getting comfortable..."

scene sce03060 with dissolve

n "Her tongue is swishing around in my mouth."
n "She's shaking and her hand rests on my head."

scene sce03061 with dissolve

v "Mmmm"
n "She's starting to moan again."
n "Her tongue is becoming violent."

scene sce03062 with dissolve

n "She tastes so good and her lips are so soft as I suck on them."
n "Can't believe we're making out..."

scene sce03063 with dissolve

n "She jumps off."
v "My god..!"
mc "That was so good [vicky_nick]!"
v "So wrong too, we can't be doing this!"


scene sce03064 with dissolve

mc "No [vicky_nick], this our bond now, I love this. No stopping."
v "I don't know.., you don't think it's too much?"
mc "Not at all, it feels so right."
mc "Don't worry, this is between us only."
v "I still don't know... We can't make a habit out of this, what if it gets out of hand?"

scene sce03065 with dissolve

mc "Don't worry [vicky_nick]. Get some sleep now, we got a beautful day together tomorrow."
mc "And everything will stay the same I promise, you'll see."
v "Goodnight."

scene black with dissolve
scene sc4061 with dissolve

n "I should check to make sure she's ok."

call phone_start from _call_phone_start_3
call message_start ("me", "Hey [vicky_nick]") from _call_message_start_2
call message ("[vicky_nick]", "Hey...") from _call_message_15
call reply_message ("That was really nice") from _call_reply_message_15
call message ("[vicky_nick]", "That is sweet of you to say, but we can't be doing this") from _call_message_16
call reply_message ("I enjoyed that and I hope you did too") from _call_reply_message_16
call message ("[vicky_nick]", "I did, I havent felt this young in so long") from _call_message_17
call reply_message ("Then I don't see a problem") from _call_reply_message_17
call message ("[vicky_nick]", "It just feels like it's getting out of hand with you") from _call_message_18
call reply_message ("I don't agree. I love you and I want us to be close. This feels so natural.") from _call_reply_message_18
call reply_message ("you drive me crazy, I've never felt like this before.") from _call_reply_message_19
call reply_message ("I think it's so important that I feel like this with you") from _call_reply_message_20
call message ("[vicky_nick]", "I just don't want to be a bad [vicky_rel]") from _call_message_19
call reply_message ("No way, you're the best") from _call_reply_message_21
call reply_message ("Now send me a sexy picture") from _call_reply_message_22
call message ("[vicky_nick]", "What?!") from _call_message_20
call reply_message ("Send me a sexy picture") from _call_reply_message_23
call message ("[vicky_nick]", "You took so many today already") from _call_message_21
call reply_message ("c'mon, send me a selfie") from _call_reply_message_24
call message ("[vicky_nick]", "[player_name]...") from _call_message_22
call reply_message ("c'mon, for me, please") from _call_reply_message_25
call message ("[vicky_nick]", "...") from _call_message_23
pause
n "Man, my heart is beating so fast right now. It almost sounds like she's going to send me something."

call message_img ("[vicky_nick]", "Please don't show this to anyone! I mean it!", "images/prologue/mompic.png") from _call_message_img_2
call reply_message ("omg [vicky_nick]!") from _call_reply_message_26
call message ("[vicky_nick]", "what?! you told me to send it") from _call_message_25
call reply_message ("I mean like omg, I can't believe how hot you are") from _call_reply_message_27
call message ("[vicky_nick]", "hehe, oh now I'm hot?") from _call_message_26
call reply_message ("Have you ever heard the term MILF?") from _call_reply_message_28
call message ("[vicky_nick]", "Yes I have, goodnight lol") from _call_message_27
call reply_message ("night [vicky_nick].") from _call_reply_message_29
call phone_end from _call_phone_end_3

scene black with dissolve

show text "THE NEXT DAY"
pause

scene sc401 with dissolve

n "The next day I decided to reward her and make her breakfast."

scene sc403 with dissolve

v "Mmm, what's that smell?"

scene sc404 with dissolve

mc "I made you breakfast."
v "You made me breakfast!?"

scene sc403 with dissolve

v "What's the occasion?"
mc "Just wanted to treat my beautiful [vicky_rel] today."

scene sc405 with dissolve

v "Oh you're the sweetest."
mc "Actually I was thinking maybe we can go shopping for you today?"

scene sc405 with dissolve

v "Oh but I don't need anymore clothes."
mc "Not what I saw when I rumaged through your clothes yesterday."
mc "You're gorgeous, no doubt, but I would like to see in more than just sweatpants around the house."

scene sc406 with dissolve

v "Hey! What's wrong with my outfit!"

scene sc407 with dissolve

mc "Nothing wrong with your outfit if you're going to stay in your room all day."
mc "I want to help you pick out some outfits, I think it'll be fun and we can hang out all day."

scene sc408 with dissolve

v "That sounds good."

scene sc409 with dissolve

v "Another day with your [vicky_rel], you sure you're not getting sick of me?"
mc "With the way things have been going, I think we're just getting started."

scene sc4010 with dissolve

v "Please... it's been weird enough already."
mc "How so?"
v "Well last night, the way we kissed."
v "...You know we can't be kissing like that."
mc "Nonsense, that was great!"
mc "And it made me feel so good [vicky_nick]."

scene sc4012 with dissolve

v "Ok, but let's not forget I'm your [vicky_rel] and it's wrong, so please if we go shopping you gotta keep it together."
mc "Sure I'll try..."
v "I mean it."
mc "Ok but if I'm good can we practice kissing tonight?"
v "Goodness, you're relentless."
mc "I need you to teach me to kiss, [vicky_nick]."
v "Teach you?"

scene sc4011 with dissolve

mc "Yeah teach me because I'm afraid I'm not going to be any good, [vicky_nick]."

scene sc4013 with dissolve

v "We can talk about it when we get back.."

scene sc4014 with dissolve

mc "Where are you going?"
v "I'm going to go get my purse."

scene sc4015 with dissolve

n "Holy Shit!"
n "She's got her cleavage in my face."

scene sc4016 with dissolve

v "We're going to break in your [vicky_ex_rel]'s new credit card."
scene sc4017 with dissolve

n "Great this will be my chance to change up her look."
n "And then tonight I'm getting my kiss and then some."

scene sc4018 with dissolve

n "That ass is going to be mine."

scene sc4019 with dissolve
pause

scene sc4020 with dissolve

n "I'll get her to try on clothes for me, Maybe I can find something more revealing for her to wear."

scene sc4021 with dissolve

v "Ok [player_name], I'm ready!"
mc "You barely touched your breakfast."

scene sc4022 with dissolve

v "C'mon let's go I can't wait."
n "She sure is in a hurry now."
mc "Ok, Ok, start the car."

scene black with fade

scene sc4023

v "It's been so long since I've gone clothes shopping!"

scene sc4024

mc "That's not good [vicky_nick], you gotta keep up with the current trends."
mc "You've got the body for it!"

scene sc4025

v "That's my [player_rel], always with the flattery!"

scene sc4026 with dissolve

mc "I'm just very observant."

scene black with dissolve

show text "SHOPPING MALL"
pause

scene sc4027 with dissolve

n "We got to the mall fairly quick. Turns out there's a shopping center some thirty miles out."
n "It's good to know for when I need something to progress my relationship with her."
sa "Hi, welcome."
v "Hello, I'd like to try on some clothes, could you point me to a changing room?"
sa "Right, this way."

scene sc4028 with dissolve

n "I couldn't wait to see her try on some new clothes."

scene sc4029 with dissolve

mc "ok [vicky_nick], I'm going to grab some outfits for you to try out."
v "Ok."

scene sc4059 with dissolve

n "OK, lets have her try somthing mild for starters, like some tight pants."

scene sc4030 with dissolve

v "This is cute!"

scene sc4031 with dissolve

v "How does it look?"
mc "Looks good [vicky_nick]."
v " I don't know, it looks like something your [sabrina_rel] would wear."
mc "Turn around, let me see."

scene sc4032 with dissolve

mc "Your butt looks good, [vicky_nick]."
v "Go find somthing else."

scene sc4059 with Pause(2)

scene sc4030 with dissolve

mc "Ok [vicky_nick], I found this nice skirt and blouse."

scene sc4033 with dissolve

v "I like it but it's very fancy."
v "Not something I would wear around the house."
mc "I want you to be comfortable wearing anything around the house."
mc "Now turn around and let me see the back."

scene sc4034 with dissolve

v "[player_name], we didn't come here so you can keep checking out my butt."
mc "It's definietly a perk."
v "Go find more stuff for me to wear."

scene sc4060 with Pause(2)

scene sc4030 with dissolve

mc "Try this one on."

scene sc4035 with dissolve

v "Oh I like it."
v "Where would you take me in this?"
mc "I would take you right here right now [vicky_nick]."

scene sc4036 with dissolve

v "[player_name]! What the hell?"
v "That's not what I meant!"

scene sc4030 with dissolve

mc "Whatever, hehe."

scene sc4037 with dissolve

v "Is your mind always in the gutter?"
mc "Can't help it [vicky_nick]. You look so sexy in everything."

scene sc4038 with dissolve

v "You mean it?"
v "Is this torture for you?"
mc "You're tempting me [vicky_nick]."
v "I'm sorry."

scene sc4030 with dissolve

n "She knows damn well that she teasing me."

scene sc4039 with dissolve

v "This outfit reminds me I have to look for a job."
mc "You and I both."
mc "You ever thought of modeling?"
v "Don't kid yourself, just because you find me attractive doesn't mean we need to punish everyone."

scene sc4040 with dissolve

mc "Are you out of your mind!?"
mc "I'm going to show you how wrong you are."
v "I don't like this one."

scene sc4030 with dissolve

mc "Ok try this last one, but you gotta try it with the panties I picked for you."
v "[player_name]...again with the panties?"
mc "It's part of the outfit, [vicky_nick]."
v "Fine, fine!"

scene sc4041 with dissolve

v "Oh wow, I really like this one!"
mc "It's perfect on you!"

scene sc4042 with dissolve

mc "Are you wearing the panties?"
v "[player_name], c'mon now stop it."

scene sc4043 with dissolve

mc "Show me you're wearing them."
v "We are in public!"
mc "Don't be stubborn I want to see how they fit on you."

scene sc4044 with dissolve

v "Here quick! before anyone sees."
n "Oh my god, she's giving into my demands!"
mc "Looks pretty good [vicky_nick], but I can't get a good view."

scene sc4045 with dissolve

mc "Let me get a better look."
v "Hey what are you doing?!"

scene sc4046 with dissolve

v "Hey stop it! Why are you getting on your knees."
mc "To get a better look!"

scene sc4048 with dissolve

v "No I told you to stop!"
v "You're embarrassing me."
mc "Cut it out [vicky_nick], nothing I haven't seen before."
mc "I really want to see the panties I picked out please."

scene sc4049 with dissolve

n "Time to see how much power I really have over her."

scene sc4050 with dissolve

v "What in the hell are you doing?!"
mc "Stop panicking, it's fine."
v "What if someone sees us?!"

scene sc4051 with dissolve

v "Stop, please don't do this."
mc "Relax [vicky_nick], I just want to take a look at you."

scene sc4052

mc "You are so beautiful."
v "Ok I get it."

scene sc4053 with dissolve

mc "No, you don't get it."
v "Can we please not do this here!"
mc "Where do you want to do this?"

scene sc4054 with dissolve

v "I didn't mean it like that!"
v "Please get out so I can get dressed?"

scene sc4055 with dissolve

mc "[vicky_nick], you've got the finest ass I've ever seen."
v "You can't say things like that!"

scene sc4056 with dissolve

v "What if someone hears us?!"
mc "So what, I'll just say you're my cougar girlfriend."
v "Very funny."
mc "That was also a compliment."

scene sc4057 with dissolve

sa "Did you need any help in there, Ma'am?"

scene sc4058 with dissolve

v "I'm,,. I'm almost done now, thank you."
n "Damn that was close."
n "Maybe [vicky_nick] is right, it's too risky."

scene black with fade

scene sc4024 with dissolve
n "The ride home I could tell [vicky_nick] was annoyed but as soon as we got home she was back to normal."

scene black with dissolve

show text "LATER THAT NIGHT"
pause

scene sc4061 with dissolve

n "Night rolled around and I got comfortable in my boxers."
n "Im going to see if I can get her to hang out watch a movie and maybe get a kiss."

call phone_start from _call_phone_start_4
call message_start ("me", "Hey") from _call_message_start_3
call message ("[vicky_nick]", "Hey yourself...") from _call_message_28
call reply_message ("Are you mad?") from _call_reply_message_30
call message ("[vicky_nick]", "No, but that was really close") from _call_message_29
call reply_message ("Im sorry I got a little carried away") from _call_reply_message_31
call message ("[vicky_nick]", "I just don't want anyone to see or hear") from _call_message_30
call reply_message ("Ok, ok I'm sorry, I'll be more careful") from _call_reply_message_32

call message ("[vicky_nick]", ":)") from _call_message_31
call reply_message ("I'm going to hang out and watch a movie. Want to join me?") from _call_reply_message_34
call message ("[vicky_nick]", "Oh I don't know...") from _call_message_32
call reply_message ("c'mon you promised me") from _call_reply_message_35
call message ("[vicky_nick]", "What did I promise you?!") from _call_message_33
call reply_message ("you were going to teach me to kiss") from _call_reply_message_36
call message ("[vicky_nick]", "My god!") from _call_message_34
call reply_message ("c'mon or else") from _call_reply_message_37
call message ("[vicky_nick]", "Or else what???") from _call_message_35
call reply_message ("Or else I'll break down that door and drag you out here myself") from _call_reply_message_38
call message ("[vicky_nick]", "Jesus! You're such a naughty young man.") from _call_message_36
call reply_message ("Sounds like you want me to come in there by force") from _call_reply_message_39
call message ("[vicky_nick]", "Maybe I like a man in charge ;)") from _call_message_37
call reply_message ("Oh you want me to be rough with you?") from _call_reply_message_40
call reply_message ("Coz you have no idea how much I'm holding back") from _call_reply_message_41
call message ("[vicky_nick]", "Mmmhmm how much?") from _call_message_38
call reply_message ("Every time I'm near you I want to take you by the hair") from _call_reply_message_42
call message ("[vicky_nick]", "Omg! Ok stop") from _call_message_39
call reply_message ("Does that mean you're coming out here [vicky_nick]?") from _call_reply_message_43
call message ("[vicky_nick]", "It's so naughty") from _call_message_40
call reply_message ("Come out here") from _call_reply_message_44
call message ("[vicky_nick]", "Oh alright, give me a minute") from _call_message_41
call phone_end from _call_phone_end_4

n "Holy shit that was hot. [vicky_nick] sounds like shes horny."

scene sc4062 with dissolve

mc "[vicky_nick]..."
v "Yes?..."

scene sc4063 with dissolve

n "She's wearing new pajamas."
mc "You look so good with your hair down."
v "...Thank you."
n "She seems nervous."

scene sc4064 with dissolve

mc "Where you going, [vicky_nick]?"

scene sc4065 with dissolve

v "I was going to get a drink."
mc " What's wrong, [vicky_nick]?"

scene sc4066 with dissolve

v "I don't know, this is a lot."
mc "It's fine [vicky_nick], it's just you and me now."
v "Thats what I'm afraid of."

scene sc4067 with dissolve

mc "Hey where you going?"

scene sc4068 with dissolve

v "I told you I'm going to get a drink!"
mc "I love your pajamas, [vicky_nick]."

scene sc4069 with dissolve

mc "Your butt looks so good in them."
v "Please don't touch me like that."
mc "What's the big deal, [vicky_nick]?"

scene sc4070 with dissolve

v "We've dicussed this, it's so inapropriate."
mc "Listen I can't help it when you're walking around in your little pajama shorts."

scene sc4071 with dissolve

mc "Now come here and kiss me like you promised."
v "Wait...let me...get my drink."

scene sc4072 with dissolve

v "Mmm..."

scene sc4073 with dissolve

mc "Isn't this nice?"

scene sc4074 with dissolve

n "Amazing, her mouth on mine. She's shivering in fear but her mouth wont let go of mine."

scene sc4075 with dissolve

n "Her saliva is delicious, her tongue is so soft."
v "Mmmm, mmhm."

scene sc4074 with dissolve

n "She's starting to moan a little, I can feel her body loosen up."

scene sc4075 with dissolve

n "I'm completely exploring her mouth now with my tongue."

scene sc4076 with dissolve

n "I can feel the heat coming off her crotch with my hand."
n "She doesn't resist."
n "I'm so close to her little pussy, I can feel the hem of her panties."

scene sc4075 with dissolve
pause

scene sc4077 with dissolve

n "My hand is exploring all on its own."

scene sc4078 with dissolve
pause

scene sc4079 with dissolve

n "She's so soft to the touch."

scene sc4074 with dissolve

v "Mmm...wait..."

scene sc4080 with dissolve

n "All of a sudden she pulls away"
v "Wait, please stop"
mc "What? Why what's wrong?"

scene sc4081 with dissolve

v "I really need that drink."

scene sc4082 with dissolve

mc "Since when do you drink this late?"

scene sc4083 with dissolve

v "Since when do I have a horny young boy stabbing me with his junk?"
mc "You don't hate it."
v "I don't but that young man is my [player_rel]."

scene sc4084 with dissolve

mc "Jeez, [vicky_nick]. Not even a glass."

scene sc4085 with dissolve

v "Mmm, that's good."
v "Now go sit on the couch."
mc "Yes, maam."

scene sc4061 with Pause(2)

scene sc4086 with dissolve

v "Well, here I am."

scene sc4087 with dissolve
pause

scene sc4088 with dissolve

v "So what did you want to do?"
n "Damn! [vicky_nick]'s tits are falling out of her top! What a view!"
mc "I want you to take off your pajama bottoms."

scene sc4089 with dissolve

v "Can't we just kiss?"
mc "Yes that too but I want to see you in your panties."
v "Under one condition."
v "You can't touch me anywhere inapropriate, ok?"
mc "You better take those shorts off before I do it myself."

scene sc4090 with dissolve

v "Ok, ok. No need for threats. No touching though..."
mc "Do it slow, too."

scene sc4091 with dissolve

v "This is so wrong."

scene sc4092 with dissolve

v "These panties are nothing special but they're comfy, ok."

scene sc4093 with dissolve

mc "You look great in them."

scene sc4094 with dissolve

mc "Let me see you."
v "Here I am."
mc "Oh god, [vicky_nick]."
v "...I..."

scene sc4095 with dissolve

v "I'm scared. We shouldn't be doing this."
mc "Nonsense, come here."

scene sc4096 with dissolve

mc "Don't worry about a thing."
mc "Just kiss me."

scene sc4097 with dissolve

v "Mmm, oh....mmm."

scene sc4098 with dissolve

n "Once more I was in her mouth."
n "This time with little hesitation."

scene sc4099 with dissolve

n "She started to embrace me."
n "Her breathing got heavier and she started stroking my face."

scene sc4098 with dissolve

v "Mm, let me get on top."

scene sc40100 with dissolve

mc "Wow, this is hot, [vicky_nick]."

scene sc40101 with dissolve

v "You can you kiss me here."

scene sc40103 with dissolve

v "Yes... that feels good."
v "Ahhh, mmmm....oh."

scene sc40102 with dissolve

mc "Your ass is so nice!"

scene sc40103 with dissolve

v "Ohh..."
mc "Maybe I should get comfrtable too."

scene sc40104 with dissolve

v "What are you doing?"

scene sc40105 with dissolve

v "[player_name]..! What..."

scene sc40106 with dissolve

v "Oh my god..."

scene sc40107 with dissolve

v "Are you crazy? Why is that out?"
mc "I couldn't keep it in my boxers, it was uncomfortable."

scene sc40108 with dissolve

v "No way. That's it."
mc "[vicky_nick], come on."

scene sc40109 with dissolve

v "I'm going to bed."

scene sc40110 with dissolve

mc "Wait, you can't leave me like this."

scene sc40111 with dissolve

n "Let's see if I can smooth it over."

call phone_start from _call_phone_start_5
call message_start ("me", "Why did you leave?") from _call_message_start_4
call message ("[vicky_nick]", "You know why I left!") from _call_message_42
call reply_message ("Is there something wrong with my penis?!") from _call_reply_message_45
call message ("[vicky_nick]", "Oh Gosh, no it's fine I just didn't want you to take it out") from _call_message_43
call reply_message ("So you're ashamed of my penis?") from _call_reply_message_46
call message ("[vicky_nick]", "No my gosh, that's not what I meant.") from _call_message_44
call message ("[vicky_nick]", "You just can't pull out your penis in front of your [vicky_rel] like that!") from _call_message_45
call reply_message ("I wanted to show you how hard you made me") from _call_reply_message_47
call message ("[vicky_nick]", "Do you realize what youre saying?") from _call_message_46
call reply_message ("Yes I do! I love you and my penis was hard for you") from _call_reply_message_48
call message ("[vicky_nick]", "Your penis was hard for me?") from _call_message_47
call reply_message ("yes! Thats why I showed it to you.") from _call_reply_message_49
call message ("[vicky_nick]", "Well that's very flattering but...") from _call_message_48
call reply_message ("Really?! Then why did yo leave?") from _call_reply_message_50
call message ("[vicky_nick]", "What did you expect me to do?") from _call_message_49
call reply_message ("You really want to know?") from _call_reply_message_51
call message ("[vicky_nick]", "Yes actually I really want to know") from _call_message_50
call reply_message ("youre going to pay for that information") from _call_reply_message_52
call message ("[vicky_nick]", "That so? What will it cost?") from _call_message_51
call reply_message ("What are you doing right now?") from _call_reply_message_53
call message ("[vicky_nick]", "I'm laying in bed why") from _call_message_52
call reply_message ("Are you touching yourself?") from _call_reply_message_54
call message ("[vicky_nick]", "That's none of your business") from _call_message_53
call reply_message ("Then I wont tell you what I'd do") from _call_reply_message_55
call message ("[vicky_nick]", "Ok ok, I might be touching myself") from _call_message_54
call reply_message ("Fuck that's hot") from _call_reply_message_56
call message ("[vicky_nick]", "Mmmmm... you naughty boy") from _call_message_55
call reply_message ("Describe to me what you're touching") from _call_reply_message_57
call message ("[vicky_nick]", "You're so bad!") from _call_message_56
call reply_message ("Please [vicky_nick] you left me so hard") from _call_reply_message_58
call message ("[vicky_nick]", "...") from _call_message_57
call message ("[vicky_nick]", "I'm touching my nipple") from _call_message_58
call reply_message ("Send me a picture") from _call_reply_message_59
call message ("[vicky_nick]", "... ok hold on") from _call_message_59
call message_img ("[vicky_nick]", "are you going to jerk off to this?", "images/SC4/sc40113.png") from _call_message_img_3
call reply_message ("Oh god, of course I'm going to jerk off to that") from _call_reply_message_60
call message ("[vicky_nick]", "ok now tell me") from _call_message_60
call reply_message ("You want me to tell you what I'd do to you?") from _call_reply_message_61
call message ("[vicky_nick]", "oh god...YES") from _call_message_61
call reply_message ("I want you to touch your pussy") from _call_reply_message_62
call message ("[vicky_nick]", "Ok I'm touching my pussy") from _call_message_62
call reply_message ("Are you wet?") from _call_reply_message_63
call message ("[vicky_nick]", "I've been wet") from _call_message_63
call reply_message ("Keep sending me pictures") from _call_reply_message_64
call message_img ("[vicky_nick]", "I hope you're not saving these", "images/SC4/sc40114.png") from _call_message_img_4
call reply_message ("mm [vicky_nick], you're so hot") from _call_reply_message_65
call message ("[vicky_nick]", "This is so naughty") from _call_message_64
call reply_message ("I want to make you feel good") from _call_reply_message_66
call message ("[vicky_nick]", "This does make me feel good") from _call_message_65
call reply_message ("Oh [vicky_nick]") from _call_reply_message_67
call message ("[vicky_nick]", "do you really think I'm a MILF?") from _call_message_66
call reply_message ("Do you even know what that means?") from _call_reply_message_68
call message ("[vicky_nick]", "maybe? You tell me") from _call_message_67
call reply_message ("I't means MOM I'D LIKE TO FUCK") from _call_reply_message_69
call message ("[vicky_nick]", "Is that what you think of me?") from _call_message_68
call reply_message ("I think a whole lot more of you") from _call_reply_message_70
call message ("[vicky_nick]", "Mmmmm") from _call_message_69
call reply_message ("Send me another picture I want to see all of you") from _call_reply_message_71
call message_img ("[vicky_nick]", "This is the last one", "images/SC4/sc40112.png") from _call_message_img_5
call reply_message ("God [vicky_nick], what's stopping me from going through that door and taking you?") from _call_reply_message_72
call message ("[vicky_nick]", "The fact that I'm your [vicky_rel] should be enough.") from _call_message_70
call reply_message ("I want you") from _call_reply_message_73
call message ("[vicky_nick]", "I'm getting sleepy") from _call_message_71
call reply_message ("You're really going to leave me with a hard on?") from _call_reply_message_74
call message ("[vicky_nick]", "I sent you those pictures, put them to good use ;)") from _call_message_72
call reply_message ("mmm I'm going to cum buckets to them") from _call_reply_message_75
call message ("[vicky_nick]", "Ok but don't make a mess and thanks for the exciting evening!") from _call_message_73
call reply_message ("night, [vicky_nick].") from _call_reply_message_76
call message ("[vicky_nick]", "night") from _call_message_74
call phone_end from _call_phone_end_5

jump chapter2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
