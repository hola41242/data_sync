label chapter4:

scene black with fade
show text "Chapter 4" with dissolve
pause

scene black with dissolve

n "Huh..."
n "What's going on..."

scene sc9t1 with dissolve
pause

n "Where am I?!"

scene sc9t2 with dissolve
pause

mc "[vicky_nick]...?"
mc "Hey!"
n "She can't hear me..."

scene sc9t3 with dissolve

mc "[vicky_nick]!"
n "Why does this feel weird..."

scene sc9t4 with dissolve

n "Damn, what fuck is going on..."
n "She seems so far away!."

scene sc9t5 with dissolve

mc "[vicky_nick]!"
mc "wait!"

scene sc9t6 with dissolve

n "Why is she acting weird..."

scene sc9t7 with dissolve

mc "Hey, why aren't you answering me?"

scene sc9t8 with dissolve

mc "SAY SOMETHING!"

scene sc9t9 with dissolve

mc "HEY!"

scene sc9t10 with dissolve

v "Are you proud of yourself?"
mc "What?"
v "You did this to me [player_rel]!"
mc "OH SHIT THIS HAS TO BE A DREAM!"



scene black with dissolve

show text "NEXT MORNING." with dissolve
pause

scene scm10101 with dissolve

n "Oh thank god, it was a dream..."
n "What a crazy night. I should treat her right, that was amazing."

scene scm10102 with dissolve
pause

scene scm10103 with dissolve
pause

scene scm10104 with dissolve
pause

scene scm10105 with dissolve
pause

scene scm10106 with dissolve

v "Hmm?"

scene scm10107 with dissolve

v "What's this?"
mc "Breakfast."

scene scm10108 with dissolve

v "Wow."
mc "Haha, I know [vicky_nick], I'm spoiling you."

scene scm10109 with dissolve

v "I can get used to this!"
mc "Well you better get used to this it's all you're going to get."
mc "I just thought that for everything you do for me this would the least I can do for you."

scene scm10110 with dissolve

v "Oh you absolute sweetheart."
v "Thank you."

scene scm10111 with dissolve

v "What are you going to do today?"
mc "I gotta edit some photos, for a friend..."
v "Oh! A friend?"
v "A girl friend?"
mc "You wish, haha."
v "I do actually."
mc "Yeah, yeah. Sorry not that kind of friend."
mc "You'r not off the hook yet..."
v "Darn."

scene scm10112 with dissolve

v "Well have fun!"
v "I might go into to town and scope out some beauty salons."
v "I might be due for a haircut soon."
n "I love how she's trying to ignore the fact that I had her cumming all over the living room floor last night."

show text "Phone Vibrate."
pause

scene sc1013 with dissolve

n "Sabrina is texting me, probably to bug me about the pictures."
n "I better finish up these edits."

call phone_start from _call_phone_start_9
call message_start ("SABRINA", "hey") from _call_message_start_8
call message_img ("SABRINA", "What you up to?", "images/SC10/SARAH02.png") from _call_message_img_9
call message ("SABRINA", "Are you done with the pics yet?") from _call_message_139
call reply_message ("Hey! I was just thinking about you...") from _call_reply_message_144
call message ("SABRINA", "Hehe, thought you would be.") from _call_message_140
call message ("SABRINA", "Would it be so wrong to say I miss you?") from _call_message_141
call reply_message ("Not at all, I really miss you too.") from _call_reply_message_145
call message ("SABRINA", "<3") from _call_message_142
call message ("SABRINA", "Do you think you'll be done with editing the pictures soon?") from _call_message_143
call reply_message ("Maybe yeah, I just need to get more motivated.") from _call_reply_message_146
call message ("SABRINA", "oh, maybe I can help?") from _call_message_144
call reply_message ("oh? Motivate me how?") from _call_reply_message_147
call message_img ("SABRINA", "Like this?", "images/SC10/SARAH01.png") from _call_message_img_10
call reply_message ("Yeah lol that would work!") from _call_reply_message_148
call message ("SABRINA", "You are such a pervert lol.") from _call_message_145
call reply_message ("You love it.") from _call_reply_message_149
call message ("SABRINA", "I don't mind it that's for sure.") from _call_message_146
call message ("SABRINA", "oh also, I can't wait for the next photo shoot because guess what?") from _call_message_147
call reply_message ("what?") from _call_reply_message_150
call message ("SABRINA", "My friend works at this photo studio and said we could use it!") from _call_message_148
call reply_message ("Oh nice! That's awesome.") from _call_reply_message_151
call message ("SABRINA", "Anyways! Send me those pics soon so we can get started on the next one!") from _call_message_149
call reply_message ("Yes, yes! I'm on it.") from _call_reply_message_152
call message_img ("SABRINA", "Ok, TTYL", "images/SC10/SARAH03.png") from _call_message_img_11
call reply_message ("Tease!") from _call_reply_message_153
call message ("SABRINA", "Hehe!") from _call_message_150
call phone_end from _call_phone_end_9

scene sc1014 with dissolve

n "Man, now I have to actaully finish these photos."



scene black with dissolve

show text "Later..." with dissolve
pause

scene sc1015 with dissolve

n "Damn I took a bunch of picture of Sabrina..."

scene sc1016 with dissolve

n "Huh?"

scene sc1017 with dissolve

mc "You're actually going out..?"
v "I told you, I'm going to town."
mc "Should I be worried?"
mc "Did you meet someone?"
mc "Or ARE you meeting someone?"

scene sc1018 with dissolve

v "Oh my gosh, are you jealous?"
v "I'm just going to explore town a little by myself is that ok?"
mc "Yeah that's fine you just look really nice is all."

scene sc1019 with dissolve

v "Don't be like that."
v "I'm not going to see anyone, trust me."
v "And if you want to be good boyfriend..."

scene sc1020 with dissolve

"...because I know that's what you want to be..."

scene sc1021 with dissolve

v "You will let me have my freedom."
mc "Ok, ok [vicky_nick]."
v "That's better, your future girlfriend's will love you for it."
mc "I rather you love me for it now."

scene sc1022 with dissolve

v "Ok, I'm heading out."
v "Be good. And don't burn the house down!"
mc "Yeah, yeah."
mc "Have a good one, see you soon."

scene sc1023 with dissolve

n "Damn, I got tons of pics to edit."
n "Better get started."



scene black with dissolve

show text "Some time later..." with dissolve
pause

scene sc1024 with dissolve
pause

scene sc1025 with dissolve
pause
n "I have been staring at Sabrina's ass for so long now."
n "Im trying to get things done but I'm getting horny just thinking about her."

scene sc1026 with dissolve
pause

scene sc1027 with dissolve

n "God she has a nice little ass."
n "I could stare at that all day."

scene sc1028 with dissolve

n "Jesus Christ!"
n "I gotta rub one out..."

scene sc1029 with dissolve

n "Fuck I'm so horny..."
n "I should have had [vicky_nick] take care of me before she left."

scene sc1030 with dissolve

n "Fuck, I'm going to fuck my [sabrina_rel] one of these days."

scene sc1037 with dissolve

n "I'd start it out slow and romantic at first."

scene sc1038 with dissolve

n "Take my time and warm her up."
n "I can feel her little lips on mine."

scene sc1031 with dissolve

n "Fuck yeah."

scene animation24 with dissolve

n "I will watch her little body bounce up and down on my dick."
n "Embrace her as I penetrate her little pussy"

scene sc1041 with dissolve

s "Shit, big [player_sab_rel]!"

scene sc1036 with dissolve

n "I bet her little pussy is tight as hell."

scene sc1042 with dissolve

n "I want to hear my balls smack against my [sabrina_rel]'s little ass"

scene sc1035 with dissolve

n "Fuck im so close..."

scene animation25 with dissolve

n "Oh man, I'd take her from behind so hard."

scene sc1045 with dissolve

s "Holy fuck, you're fucking me raw!"

scene animation25 with dissolve

mc "Your tight little pussy feels so good!"

scene sc1046 with dissolve

s "Oh fuck, I'm going to cum!"
n "I'd make her talk dirty when she's coming."
n "She's a little slut I just know it."
n "I Would not be surpised if I had her calling me 'daddy'!"
mc "Am I your daddy?"
s "Yes DADDY, Yes DADDy please!"
s "I'm daddy's little slut!"

scene sc1031 with dissolve
pause

scene sc1032 with dissolve

n "Holy fucking shit!"

scene sc1047 with dissolve

n "I cum all over her pretty backside."

scene sc1048 with dissolve

n "Holy fuck that was great."
n "I Can't wait for another photo shoot with her."
n "That was pretty intense, I feel like I shoud get some fresh air."



scene black with dissolve

show text "GOING FOR A WALK." with dissolve
pause

scene sc1049 with dissolve

n "I decided to take a stroll through the neighborhood and see what I can find."
n "Since [vicky_nick] took the car I went by foot, maybe I'd run into some trouble or something."
n "Anything to get my mind off that wank session."

scene sc1050 with dissolve

n "I found myself near a pretty run down trailer park."
n "You wouldn't even think there would be one around here considering the neighborhood is pretty high end."

scene sc1051 with dissolve

mc "Damn, what the hell is this place?"

scene sc1052 with dissolve
pause

scene sc1054 with dissolve

mc "Wait a minute is that?..."

scene sc1055 with dissolve

mc "A dirtbike! Looks pretty complete too!"

scene sc1056 with dissolve

n "I have to get a closer look."

scene sc1057 with dissolve

n "It was calling my name."

scene sc1058 with dissolve

mc "This thing is in great shape!"
mc "I bet I can get it running in no time."

scene sc1059 with dissolve

n "I felt like I was being watched but I was too mesmarized by the machine before me."

scene sc1060 with dissolve

t "Hey this is private property!"

scene sc1061 with dissolve

mc "Huh?"
t "This is private property and that's my dad's motorcycle!"
mc "Shit, I'm sorry, I did't know, I was just looking."

scene sc1062 with dissolve

t "Really? You didn't climb through the hole in that fence just now?"

scene sc1063 with dissolve

mc "Someone should really fix that fence."
mc "My name is [player_name] by the way..."
t "I'm Tracy, you must be the folks that recently moved in up the street."
mc "Yeah that's us."

scene sc1064 with dissolve

t "Exciting stuff."
t "Well I don't know how you do it where you're from but we don't tresspass around here."
mc "I didn't mean to. I just had to find out more about this motorcycle."

scene sc1065 with dissolve

t "Ah, yes."
t "Well, it's my dad's bike."
mc "Is it for sale?"

scene sc1067 with dissolve

t "You'll have to ask him."
mc "Is he around?"
t "No."
t "Not right now at least."

scene sc1066 with dissolve

t "You have to come back another time."
mc "Damn..."

scene sc1068 with dissolve

t "He would probably sell it to you."
mc "Really?"

scene sc1069 with dissolve

t "Yes, everything here has a price."
n "Hmm, everything?"
mc "Great, I will keep that in mind, and I will come back another time."

scene sc1070 with dissolve

mc "See you later then!"
n "She was cute, this getting out and getting some air turned out nice for me."
n "I really want that dirt bike..."

scene black with fade

scene sc1071 with dissolve
pause

scene sc1072 with dissolve

n "Oh, wow."
n "Another lady..."

scene sc1074 with dissolve

n "Man, this place is really filled with women."

scene sc1075 with dissolve
pause

scene sc1076 with dissolve
pause

scene sc1077 with dissolve

n "Shoot, looks like she noticed me."
n "I guess I'll have to say hi..."

scene sc1078 with dissolve

cas "oh! Goodness."

scene sc1079 with dissolve
pause

scene sc1080 with dissolve

cas "Hello how are you?"
mc "Good, how are you?"

scene sc1081 with dissolve

cas "I am well. You must be my new neighbor."
cas "I am Casandra. I noticed you guys moved in recently."
mc "Hi [cas] I'm [player_name]."
mc "Yeah me and my [vicky_rel]."
cas "That's so nice, I hope you two have been getting on fine."
mc "Yeah it's been different..."

scene sc1083 with dissolve

cas "Well I was hoping you guys would have come and said hi earlier but that's ok, I understand how moving can be."

mc "Sorry, yeah it's been pretty hectic."

scene sc1084 with dissolve

cas "You guys should stop by one of these days!"
cas "I would love to meet your [vicky_rel]."
mc "Oh absolutely, when we get settled in."
mc "I'll let [vicky_nick] know."
n "Lord knows she needs a few girlfriends."
cas "That's perfect!"
cas "Well nice to meet you [player_name], I better get back to my garden now."
cas "I really hope you guys come by soon."
cas "Bye fow now."

scene sc1085 with dissolve

mc "Bye, see you soon."

scene sc1086 with dissolve
pause

scene sc1089 with dissolve

n "Damn."
n "I could see her red thong."
n "That was unexpected..."
n "Maybe [vicky_nick] could make friends with her."

scene black with fade

scene sc1090 with dissolve

n "I decided to grab a drink from the gas station on the way back."

scene sc1091 with dissolve
pause

scene sc1092 with dissolve

b "Hi, welcome..."
n "This town is all women huh?"
mc "Hi."

scene sc1093 with dissolve

n "This one was so occupied with her phone."
n "I could have ransacked the place and she wouldn't even notice."

scene sc1094 with dissolve
pause

scene sc1095 with dissolve

b "Will that be all for you?"
mc "Yes, thanks."
n "I didn't feel like making small talk, I paid the cashier and left"
n "Honestly at this point I wanted to get home and jerk off again."

scene sc1097 with dissolve

n "I got out of there pretty quickly and headed right back hoping I wouldn't run into anyone else."



scene black with dissolve

show text "Back Home" with dissolve
pause

scene sc1098 with dissolve

n "[vicky_nick] is not even home yet."

scene sc1099 with dissolve

n "The first thing I wanted to do is go in her room and absorb all the smells again."

scene sc10100 with dissolve
pause

scene sc10101 with dissolve
pause

scene sc10102 with dissolve

n "As I lay in her bed, I could smell her aroma."

scene sc10103 with dissolve

n "I felt an urge that ran to the tip of my cock."

scene sc10104 with dissolve

n "I take my cock out as it begins to swell."

scene sc10105 with dissolve

n "Maybe I can cum again before [vicky_nick] comes home..."

scene sc10106 with dissolve

n "I hear the door open and the familiar heel stomp."

scene sc10107 with dissolve

v "[player_name], are you home?"

scene sc10108 with dissolve

v "What are you doing on my bed?"
n "I made no effort to hide what I was doing, I was confident, horny and I needed her to know I wasn't going anywhere."
mc "Oh, hey..."

scene sc10109 with dissolve

v "Oh my god, are you touching yourself on my bed?"
mc "Yes and I'm glad you're here, I could use your help..."

scene sc10110 with dissolve

v "What the hell do you mean?"
v "Stop that!"
mc "No, please, I need you to take care of me right now."
v "What the hell, [player_name]!?"

scene sc10111 with dissolve

v "I just got home!"
mc "So?"
mc "Come here relax."

scene sc10112 with dissolve

v "You can't just demand things like this whenever you want."
mc "I'm not demanding I just need you right now."
mc "Please [vicky_nick]."

scene sc10113 with dissolve

v "Ugh, I hate that you do this."
mc "It's not so bad come on."
mc "I love that we have this."
mc "You satisfying my urges keeps me out of trouble."
v "Jesus...!"
mc "What?"


scene sc10114 with dissolve

v "Nothing..."
v "...."
v "What do you want me to do?"
mc "Can you use your mouth again?"
v "Make it quick this time."

scene sc10115 with dissolve

mc "God yes, and you look so good in that dress, [vicky_nick]."
v "You're just saying that."
mc "Come on you know I'm not."
v "You're right I know you mean it."
mc "If you want me to finish faster, you will need to talk dirty to me."

scene sc10116 with dissolve

v "Talk dirty?"
mc "Yeah like last time, hearing you speak like that is so hot."
v "I'll do my best."

scene sc10117 with dissolve
pause

scene sc10118 with dissolve

v "Like this?"
mc "Yes [vicky_nick], your tongue feels so good!"

scene animation26 with dissolve

v "You..."
v "You like it when I use my mouth...?"
mc "Fuck yes..."
v "...I like it when you grow inside my mouth."

scene animation27 with dissolve

mc "Fuck!"

scene sc10117 with dissolve

v "I want you to cum in my mouth."
v "I want to swallow you."
mc "Fuck [vicky_nick] keep going talk dirtier!"

scene sc10123 with dissolve

v "How much more dirtier can this get?"
mc "Ugh, please [vicky_nick], don't stop."
v "Ok, just not sure what you want me to say!"
mc "Come on I can't believe that you can't think of naughty things to say."
mc "Come on try!"
v "Ok, ok relax!"

scene sc10118 with dissolve

v "Your cock is so big, it fills my mouth..."

scene animation27 with dissolve

mc "Yeah [vicky_nick]."

scene sc10117 with dissolve

v "I want it..."

scene animation28 with dissolve

mc "You want it what?"

scene animation29 with dissolve

v "mmmhm"
mc "I can't understand you."

scene sc10123 with dissolve

v "Such a big cock."
mc "You want it what?"
n "I know she's trying to say the dirtiest thing that she thinks I want to hear."
n "I can tell how nervous she is."

scene animation27 with dissolve

v "I..."

scene animation30 with dissolve

v "I want it inside of me..."
n "She can barely say it..."
mc "Oh fuck [vicky_nick]!"
mc "More!"

scene animation29 with dissolve
pause

scene sc10118 with dissolve

v "I want to feel it inside me."
v "...I want your cock inside me."

scene animation31 with dissolve
pause

scene sc10118 with dissolve

v "I want you to fuck me with your cock..."

scene animation27 with dissolve

mc "Oh, fuck I'd fuck you so good."

scene animation29 with dissolve
pause

scene sc10117 with dissolve

v "I want you to take me over and over..."
mc "Oh please, [vicky_nick]..."

scene animation27 with dissolve

mc "Can we please do it?"

scene sc10123 with dissolve

v "I'm talking dirty like you asked, what are you talking about?"
mc "I want it, [vicky_nick]."
mc "I want to be inside you just like you said."

scene sc10124 with dissolve

v "No! I'm just trying to do my best to please you..."
v "You said it will make you cum faster, I don't really mean any of that stuff."
mc "Right, but the more you say it, the more it makes me want you."
v "I can't believe we're even doing this."

scene sc10125 with dissolve

v "Can we please get this over with?"
mc "No, I need to have sex with you. I need to know what it feels like."

scene sc10126 with dissolve

v "I'm sorry but that is not happening!"
mc "You're going to have to choose, [vicky_nick]."
mc "Because I need to do this and I need it with you."
mc "You can't stop it so don't even fight it."
v "You are talking crazy."
v "I really need you to stop right now."

scene sc10127 with dissolve

v "Hey what the heck!"
v "[player_name]!"

scene sc10128 with dissolve

v "What are you doing?"
mc "You going to let me have you or not?"
v "What are you saying!?"

scene sc10129 with dissolve

v "Hey stop it! You're hurting me!"
mc "I need you, [vicky_nick]!"
mc "I need to experience sex with you."
v "NO! I can't risk getting pregnant!"
v "Let me finish you with my mouth..."
mc "I don't want your mouth anymore..."
v "Please wait!"

scene sc10130 with dissolve

v "Maybe you want me to dress up or something?"
mc "You know what I want!"
v "Stop it, we can't! I just told you!"

scene sc10131 with dissolve

v "Just let me use my mouth, let me make you cum!"
mc "No!"
mc "I already told you, I don't want your mouth."
v "Wait, wait, OUCH!"
v "You're biting my nipple!"

scene sc10132 with dissolve

v "Ok, OK, let's talk."
mc "No more talking..."
v "[player_name], please anything but that."
mc "Anything?"
v "Just about!"
mc "Ok then, I want your ass."
v "W-What?"
mc "You know, anal sex?"
mc "I want to try it. And you can't get pregnant that way."
v "GET OFF OF ME."
n "I let her sit up, feeling like I've crossed the line once again."
mc "You said anything"

scene sc10133 with dissolve

n "The room goes cold as she sits up and doesn't say a word."
n "I'm trying to hold her still just in case she decided to jet out of the room."
v "..."
v "I've never done it there..."
mc "Never?"
v "Never..."
mc "All the more reason to do it with me..."
mc "I want to know what it's like."
mc "And I want it with you."
v "I don't think so, that's too much!"
mc "Well, would you rather have it that way or your pussy."
v "Geez [player_name], you shouldn't talk to your [vicky_rel] like that."

scene sc10134 with dissolve

v "Is there no other way?"
mc "No."
v "If we do this, we do it my way."
mc "Holy shit, yes!"
mc "[vicky_nick] you're the best!"

scene sc10135 with dissolve

v "Obviously, just like all the things we do, this stays between us!"
mc "Duh!"
v "I'm not kidding!"
v "Jeez, you are so difficult and stubborn I can't believe I'm actually considering it."
mc "Stop it, you usually end up cumming and enjoying it too."

scene sc10136 with dissolve

v "Just because I cum doesn't mean I enjoyed it!"
v "I'm only doing this for you."

scene sc10137 with dissolve

v "And if we're going to do this then we will need little something to prepare..."

scene sc10138 with dissolve

mc "KY Jelly?"
mc "Why do you have that?"

scene sc10139 with dissolve

v "That's not your concern..."
v "Sometimes you need a little lubrican't."
n "Holy shit, she's really going to let me fuck her in the ass..."

scene sc10140 with dissolve

n "There no turning back now."
n "I watch as her dress drops to the floor."
mc "Jeez, [vicky_nick]."

scene sc10141 with dissolve

v "What?"
mc "You're just so beautiful."

scene sc10142 with dissolve

v "Oh, please..."

scene sc10143 with dissolve

mc "I'm serious."
mc "You are such a babe."
v "Yeah well, I wish you did not think like that about me."
mc "You don't mean that."
v "It's just really hard for me to accept this."

scene sc10144 with dissolve

v "Alright, how do you want to do this?"
mc "Hey, not like that."
mc "Gotta ease into it..."

scene sc10145 with dissolve

v "Yeah well, I'm over here preparing to have something in my ass."
mc "That's why you gotta ease into it."
mc "I want you to enjoy it..."
mc "Or at least try."

scene sc10146 with dissolve

n "I couldn't wait any longer, watching her just stand there."

scene sc10147 with dissolve

mc "God I love you..."
n "I start to kiss her abdomen."
mc "You are absolutely delicious."

scene sc10148 with dissolve

mc "Just, relax and let go of your worries."
mc "Just be with me, right now."

scene sc10149 with dissolve

n "I quickly found myself grabbing her tits and nibbling on her neck, as hungry as ever."
mc "Your tits are so firm!"
v "Mmm."

scene sc10150 with dissolve

n "I feel her hand run tentatively along the shaft of my dick, she's still unsure."
mc "Grab it."
n "She does and without hesitation she starts stroking it."
n "I immediately get rock hard."
v "Wow, so hard already..."
v "For me?"
mc "Yes, [vicky_nick]."

scene sc10151 with dissolve

v "God you are such a naughty boy..."
mc "Yes, and I want you to be naughty for me."
mc "Be free."
v "Ok, I will try."

scene sc10152 with dissolve

v "Sit on the bed, I want you in my mouth."
mc "Yes please."

scene sc10153 with dissolve

n "She gives me a slight push onto the bed."
n "Keeping a firm grip on my cock."
mc "Fuck..."
n "Suddenly I feel her mouth engulf the head of my dick."
n "That familiar suction sends waves of pleasure through my groin."
mc "I love your mouth [vicky_nick]."
v "You could always cum this way if you want..."
mc "Mmm, not today."
n "She starts bobbing her head as that motivates her to make me cum faster."

scene animation32 with dissolve

n "Her little slurps and moans echo faintly through the room."

scene sc10160 with dissolve

v "I do like how your cock fills my whole mouth."

scene animation32 with dissolve

n "She gags a little as she takes me deeper into her mouth."
v "Mmm."

scene sc10156 with dissolve

mc "Fuck, so good."

scene animation33 with dissolve
pause

scene sc10157 with dissolve

v "Ughh, fuck."

scene animation33 with dissolve
pause

scene sc10160 with dissolve

v "So big."

scene animation34 with dissolve

n "Damn, she's really trying to make me cum because I am getting extremely close..."

scene sc10161 with dissolve

mc "Ok I am ready for you now."

scene sc10161 with dissolve

v "..."
v "*whispers* please no..."
mc "What now?"
v "I don't know, I was trying real hard to make you cum."
v "I just wish you would have."
mc "No, because I want you."
v "..."
v "Go get the lube."

scene sc10162 with dissolve

mc "Ok."

scene sc10163 with dissolve

n "Holy fuck, watching her pull down her underwear for me is a crazy thought."

scene sc10164 with dissolve

v "Make sure to put a generous amount of lube on yourself."
n "I do as she says."

scene sc10165 with dissolve

v "Ok, now I think you get the idea of what to do."
v "Please go slow."

scene sc10166 with dissolve

mc "Ok, [vicky_nick] relax."
v "Oh, god here we go."
v "Can't believe this is happening."

scene sc10167 with dissolve

n "I put my dick to her asshole and start rubbing at the puckered ring of fleash, spreading lubrican't around the entrance."
v "Slowly!"
n "I could feel her tense up."

scene sc10168 with dissolve

n "I begin to apply pressure to her asshole feeling the resistant ring spasm at the intrusion."
v "Careful!"

scene sc10169 with dissolve

n "All the sudden I feel the head of my cock slip into the tight ring of muscle with a pop."
mc "Holy shit I'm in."
n "Fuck! So warm and tight!"

scene sc10172 with vpunch

v "Ahhhhh, geez!"
v "Slow, slow! SLOW!"

scene sc10170 with dissolve

n "I push in a little deeper."

scene sc10168 with dissolve

v "please, no more!"
v "you're too deep!"
v "Oh, my, god, this hurts!"
mc "You're ok, [vicky_nick]."
mc "Relax, you're really tense!"
mc "I am going to start moving now"

scene animation35 with dissolve
pause

scene sc10172 with dissolve

v "Fuck!"

scene animation35 with dissolve

mc "This feels so good!"

scene sc10173 with dissolve

v "Holy shit!"

scene animation35 with dissolve

mc "Talk dirty to me mom I almost there."

scene sc10173 with dissolve
v "Fuuh....fuck my ass."
v "Not so fast, easy!"

scene animation35 with dissolve

n "As unexpected as that was, it was also hot as hell."
n "She began grunting each time I bottomed out in her ass."

scene sc10172 with dissolve

v "Holy hell! Easy!"

scene animation35 with dissolve

mc "Fuck [vicky_nick], your ass is so tight and warm!"

scene sc10173 with dissolve

v "Oh god!"
mc "You like it, don't you?"
n "I wanted to see how far I can push the dirty talk. I wanted to call her so many naughty things, but for now I had to play it safe."
n "I gathered up the courage and these three little words slipped out..."
mc "...My little slut!"

scene animation36 with dissolve

n "I started to fuck her ass a little faster as I felt her loosen up"
n "At first she didn't make a sound as it felt like she was still processing what I just called her..."
v "....hnng, fuck."
v "...Yes!"
v "...I'm..."
v "I'm your little slut!"
mc "Fuck!"
n "This was unreal, I must be dreaming."
n "The hottest thing ever."
n "Was she giving into her lust and letting go? Or was she just saying what I want to hear?"
n "Either way it is driving me absolutley crazy"
mc "This is amazing, I love fucking your ass."

scene sc10168 with dissolve

v "Oh, god."
v "Please cum soon!"

scene sc10176 with dissolve

mc "I want to change positions!"
mc "I want to look at your face as I'm fucking you."

scene sc10177 with dissolve
v "Please... can we end this?"
mc "Not yet..."

scene animation37 with dissolve

v "Fuck, I don't know if this feels good or not."

scene animation37 with dissolve

v "I don't know how much more I can take."
v "Please cum, soon!"
mc "No way, [vicky_nick]."
mc "We've came this far and I'm going to enjoy you."
n "Suddenly animal lust just awoke inside of me..."
mc "I'm going to take you, [vicky_nick]..."
mc "I'm going to take this sweet ass!"
n "I pushed her down towards the pillows and mounted her from behind."

scene sc10178 with dissolve

v "Uhhh, no..!"
n "In this position I was able to go deeper in."
n "I felt her tighten up as I thrust back into her deeply."
n "I felt her try to get away..."

scene sc10190 with dissolve

n "I immediately put a stop to it by pinning her hands behind her..."
v "Eeekk, [player_name] not so rough!"
mc "I need this, [vicky_nick]!"


scene animation38 with dissolve

n "I started to thrust harder, and harder into her."
n "My balls made a slapping sound as I did."

scene sc10179
v "Oh fuck, oh fuck!"
n "I felt her tighten up at first and then I felt her let go..."
n "Then, she clenched her ass harder"
n "Her little sphincter muscle squezed my cock over and over."
mc "Fuck, I'm going to cum in your ass!"

scene animation38 with dissolve
pause

scene sc10179 with dissolve

v "Yes, yes, do it. Fuck me. Take me."
n "Looks like she's really trying to get me to cum."

scene sc10178 with dissolve

v "God, use me. Fuck me!"
v "Fill my ass with your cum!"

scene animation38 with dissolve
pause

scene sc10191 with dissolve

mc "Oh Fuck, I'm getting close!"

scene sc10179 with dissolve

v "Oh, god you're destroying my insides!"
mc "You like it when I fuck you like this?"
v "Yes... give it to me, fuck my ass!"
n "I knew she was probably just saying that to please me but I didn't care because I felt a sudden urge building in my balls."

scene sc10191 with dissolve

mc "Fuck I'm coming!"
mc "I'm coming in your ass, [vicky_nick]!"

scene sc10179 with dissolve

v "Ohhh, I feel it."
n "I felt her tighten up again."
n "Her ass hole was milking my cock."

scene sc10180 with dissolve

n "I unmounted myself from [vicky_nick]'s asshole."
n "As I pulled out it made a little popping sound."
n "She was breathing heavy, her face buried in the pillow."
mc "...Fuck"
n "As I just stared at her little hole."
n "I could see a little of my Jizz start to flow out."
v "...Jesus..."

scene sc10181 with dissolve

n "I took a closer look at her gaping hole, it was slowly beginning to close."

scene sc10182 with dissolve

n "Her breathing is heavy as if she's about to fall asleep..."

scene sc10183 with dissolve

n "I better not let her sleep before saying goodnight."
v "Mmmm..."

scene sc10184 with dissolve

n "Right away I slip her the tongue."

scene sc10185 with dissolve

v "Mmmm, stop it..."
mc "But I love you..."
v "Fuck..."

scene sc10186 with dissolve
pause

scene sc10187 with dissolve
pause 

jump chapter5
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
