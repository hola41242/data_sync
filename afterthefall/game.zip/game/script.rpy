﻿# The script of the game goes in this file.
image bg weeks = "images/weeks.webp"
image bg white = "images/whiteC.webp"
image bg adamAndAlice = "images/animation/alice+adam/0000.webp"
image bg horde1 = "images/RenderHorde1.webp"
image bg horde2 = "images/RenderHorde2.webp"
image bg horde3 = "images/RenderHorde3.webp"
image bg horde4 = "images/RenderHorde4.webp"
image bg fivemin = "images/fivemin.webp"
image bg aliceCuming = "images/Alicecumming.webp"
image bg aliceFucking = "images/AliceFucking.webp"
image bg adammei = "images/animation/creepers base/adam mei/render0000.webp"
image bg crep = "images/animation/creepers base/render0110.webp"
image bg Endofchap = "images/End of chapter.webp"
image bg PatronOnly = "images/Patreons only.webp"
image bg adamemei = "images/adam&mei.webp"
image bg cumInsideLuna = "images/DOGG3.webp0022.webp"

image bg ENDOF05 = "images/End Of 0.5.webp"
image bg warnin = "images/This game is being made by just one person. Please consider supporting me. (1).webp"
image bg 2min = "images/2 minutes earlier.webp"
image bg Patreonrd = "images/animation/Patreons only Luna/Luna.webp"
image bg Patreonrd1 = "images/animation/Patreons only Luna/Luna1.webp"
image bg Patreonrd2 = "images/animation/Patreons only Luna/Luna2.webp"
image bg Patreonrd3 = "images/animation/Patreons only Luna/Luna3.webp"
image bg Patreonrd4 = "images/animation/Patreons only Luna/Luna4.webp"
image bg Patreonrd5 = "images/animation/Patreons only Luna/Luna5.webp"
image bg Patreonrd6 = "images/animation/Patreons only Luna/Luna6.webp"
image bg Patreonrd9 = "images/animation/Patreons only Luna/Luna9.webp"
image bg Patreonrd10 = "images/animation/Patreons only Luna/Luna10.webp"
image bg Patreonrd11 = "images/animation/Patreons only Luna/Luna11.webp"
image bg Patreonrd12 = "images/animation/Patreons only Luna/Luna12.webp"
image bg Patreonrd13 = "images/animation/Patreons only Luna/Luna13.webp"
image bg Patreonrd14 = "images/animation/Patreons only Luna/Luna14.webp"
image bg Patreonrd16 = "images/animation/Patreons only Luna/Luna16.webp"
image bg Patreonrd17 = "images/animation/Patreons only Luna/Luna17.webp"
image bg Patreonrd18 = "images/animation/Patreons only Luna/Luna18.webp"
image bg Patreonrd19 = "images/animation/Patreons only Luna/Luna19.webp"



image bg renderOne = "images/render1.webp"
image bg render2 = "images/render2.webp"
image bg Anne3 = "images/Render2Anne.webp"
image bg Luna4 = "images/Render4Luna.webp"
image bg Luna5 = "images/Render5Luna.webp"
image bg Anne6 = "images/Render6anne.webp"
image bg Luna7 = "images/Render6Luna.webp"
image bg Luna8 = "images/Render7Luna.webp"
image bg Luna9 = "images/Render8Luna.webp"
image bg Anne10 = "images/Render11Anne.webp"
image bg Luna11 = "images/Render9Luna.webp"
image bg Luna12 = "images/Render12Luna.webp"
image bg Adam13 = "images/Render13 Adam.webp"
image bg Adam14 = "images/Render15AdamLuna.webp"
image bg Adam15 = "images/Render16AdamLuna.webp"
image bg Luna16 = "images/Render17Luna.webp"
image bg Luna17 = "images/Render18Luna.webp"
image bg Luna18 = "images/Render19Luna.webp"
image bg Adam19 = "images/Render20AdamLuna.webp"
image bg Adam20 = "images/Render21Adam.webp"
image bg AdamAndAnne = "images/Render22AdamAnne.webp"
image bg render23TomsHouse = "images/Render23.webp"
image bg render24TomsHouse = "images/Render24.webp"
image bg render25TomsHouse = "images/Render25.webp"
image bg render26TomsHouse = "images/Render26.webp"
image bg render27TomsHouse = "images/Render27.webp"
image bg render28TomsHouse = "images/Render28.webp"
image bg render29TomsHouse = "images/Render29.webp"
image bg render30TomsHouse = "images/Render30.webp"
image bg render31TomsHouse = "images/Render31.webp"
image bg render32TomsHouse = "images/Render32.webp"
image bg render33TomsHouse = "images/Render33.webp"
image bg render34TomsHouse = "images/Render34.webp"
image bg render35TomsHouse = "images/Render35.webp"
image bg render36TomsHouse = "images/Render36.webp"

image bg render37TomsHouse = "images/Render37.webp"
image bg render38TomsHouse = "images/Render38.webp"
image bg render39TomsHouse = "images/Render39.webp"
image bg render40TomsHouse = "images/Render40.webp"
image bg render41TomsHouse = "images/Render41.webp"
image bg render42TomsHouse = "images/Render42.webp"
image bg render43TomsHouse = "images/Render43.webp"
image bg render44TomsHouse = "images/Render44.webp"
image bg render45TomsHouse = "images/Render45.webp"
image bg render46TomsHouse = "images/Render46.webp"
image bg render47TomsHouse = "images/Render47.webp"
image bg render48TomsHouse = "images/Render48.webp"
image bg render49TomsHouse = "images/Render49.webp"
image bg render50TomsHouse = "images/Render50.webp"
image bg render51TomsHouse = "images/Render51.webp"
image bg render52TomsHouse = "images/Render52.webp"
image bg render53TomsHouse = "images/Render53.webp"

image bg render54TomsHouse = "images/Render54.webp"
image bg render55TomsHouse = "images/Render55.webp"
image bg render56TomsHouse = "images/Render56.webp"
image bg render57TomsHouse = "images/Render57.webp"
image bg render58TomsHouse = "images/Render58.webp"
image bg render59TomsHouse = "images/Render59.webp"
image bg render60TomsHouse = "images/Render60.webp"
image bg render61TomsHouse = "images/Render61.webp"
image bg render62TomsHouse = "images/Render62.webp"
image bg render63TomsHouse = "images/Render63.webp"
image bg render64TomsHouse = "images/Render64.webp"
image bg render65TomsHouse = "images/Render65.webp"
image bg render66TomsHouse = "images/Render66.webp"
image bg render67TomsHouse = "images/Render67.webp"
image bg render68TomsHouse = "images/Render68.webp"
image bg render69TomsHouse = "images/Render69.webp"
image bg render70TomsHouse = "images/Render70.webp"
image bg render71TomsHouse = "images/Render71.webp"
image bg render72TomsHouse = "images/Render72.webp"
image bg render73TomsHouse = "images/Render73.webp"
image bg render74TomsHouse = "images/Render74.webp"
image bg render75 = "images/Render75.webp"
image bg render76TomsHouse = "images/Render76.webp"
image bg render77TomsHouse = "images/Render77.webp"
image bg render78 = "images/Render78.webp"
image bg render79 = "images/Render79.webp"
image bg render80 = "images/Render80.webp"
image bg render81 = "images/Render81.webp"
image bg render82 = "images/Render82.webp"
image bg render83 = "images/Render83.webp"
image bg render84 = "images/Render84.webp"
image bg render85 = "images/Render85.webp"
image bg render86 = "images/Render86.webp"
image bg render87 = "images/Render87.webp"
image bg render88 = "images/Render88.webp"
image bg render88p2 = "images/render88p2.webp"
image bg Render88p3 = "images/Render88p3.webp"
image bg Render88p4 = "images/Render88p4.webp"
image bg Render88p5 = "images/Render88p5.webp"
image bg Render88p7 = "images/Render88p7.webp"
image bg Render88p8 = "images/Render88p8.webp"
image bg Render88p9 = "images/Render88p9.webp"
image bg Render88p10 = "images/Render88p10.webp"
image bg Render88p11 = "images/Render88p11.webp"
image bg Render88p12 = "images/Render88p12.webp"

image bg render89 = "images/Render89.webp"
image bg render90 = "images/Render90.webp"
image bg render91 = "images/Render91.webp"
image bg render92 = "images/Render92.webp"
image bg render93 = "images/Render93.webp"
image bg render94 = "images/Render94.webp"
image bg render95 = "images/Render95.webp"
image bg render96 = "images/Render96.webp"
image bg render97 = "images/Render97.webp"
image bg render98 = "images/Render98.webp"
image bg render99 = "images/Render99.webp"

image bg render100 = "images/Render100.webp"
image bg render101 = "images/Render101.webp"
image bg render102 = "images/Render102.webp"
image bg render103 = "images/Render103.webp"
image bg render104 = "images/Render104.webp"
image bg render105 = "images/Render105.webp"
image bg render106 = "images/Render106.webp"
image bg render107 = "images/Render107.webp"
image bg render108 = "images/Render108.webp"
image bg render109 = "images/Render109.webp"
image bg render110 = "images/Render110.webp"
image bg render111 = "images/Render111.webp"
image bg render112 = "images/Render112.webp"
image bg render113 = "images/Render113.webp"
image bg render114 = "images/Render114.webp"
image bg render115 = "images/Render115.webp"
image bg render116 = "images/Render116.webp"
image bg render117 = "images/Render117.webp"
image bg render118 = "images/Render118.webp"
image bg render119 = "images/Render119.webp"
image bg render120 = "images/Render120.webp"

image bg render121 = "images/Render121.webp"
image bg render122 = "images/Render122.webp"
image bg render123 = "images/Render123.webp"
image bg render124 = "images/Render124.webp"
image bg render125 = "images/Render125.webp"
image bg render126 = "images/Render126.webp"
image bg render127 = "images/Render127.webp"
image bg render129 = "images/Render129.webp"
image bg render130 = "images/Render130.webp"
image bg render131 = "images/Render131.webp"
image bg render132 = "images/Render132.webp"
image bg render133 = "images/Render133.webp"
image bg render134 = "images/Render134.webp"
image bg render135 = "images/Render135.webp"
image bg render136 = "images/Render136.webp"
image bg render137 = "images/Render137.webp"
image bg render138 = "images/Render138.webp"
image bg render139 = "images/Render139.webp"
image bg render140 = "images/Render140.webp"
image bg render141 = "images/Render141.webp"
image bg render142 = "images/Render142.webp"
image bg render143 = "images/Render143.webp"
image bg render144 = "images/Render144.webp"
image bg render145 = "images/Render145.webp"
image bg render146 = "images/Render146.webp"
image bg render147 = "images/Render147.webp"
image bg render148 = "images/Render148.webp"
image bg render149 = "images/Render149.webp"
image bg render150 = "images/Render150.webp"
image bg render151 = "images/Render151.webp"
image bg render152 = "images/Render152.webp"
image bg render153 = "images/Render153.webp"
image bg render154 = "images/Render154.webp"
image bg render155 = "images/Render155.webp"
image bg render156 = "images/Render156.webp"
image bg render157 = "images/Render157.webp"
image bg render158 = "images/Render158.webp"
image bg render159 = "images/Render159.webp"
image bg render159s2 = "images/Render159s2.webp"
image bg render159s3 = "images/Render159s3.webp"
image bg render160 = "images/Render160.webp"
image bg render161 = "images/Render161.webp"
image bg render162 = "images/Render162.webp"
image bg render163 = "images/Render163.webp"
image bg render164 = "images/Render164.webp"
image bg render165 = "images/Render165.webp"
image bg render166 = "images/Render166.webp"
image bg render167 = "images/Render167.webp"
image bg render168 = "images/Render168.webp"
image bg render169 = "images/Render169.webp"
image bg render170 = "images/Render170.webp"
image bg render171 = "images/Render171.webp"
image bg render172 = "images/Render172.webp"
image bg render173 = "images/Render173.webp"
image bg render174 = "images/Render174.webp"


image bg render175 = "images/Render175.webp"
image bg render176 = "images/Render176.webp"
image bg render177 = "images/Render177.webp"
image bg render178 = "images/Render178.webp"
image bg render179 = "images/Render179.webp"
image bg render180 = "images/Render180.webp"
image bg render181 = "images/Render181.webp"
image bg render182 = "images/Render182.webp"
image bg render183 = "images/Render183.webp"
image bg render184 = "images/Render184.webp"
image bg render185 = "images/Render185.webp"
image bg render186 = "images/Render186.webp"
image bg render187 = "images/Render187.webp"
image bg render189 = "images/Render189.webp"
image bg render190 = "images/Render190.webp"
image bg render191 = "images/Render191.webp"
image bg render192 = "images/Render192.webp"
image bg render193 = "images/Render193.webp"
image bg render194 = "images/Render194.webp"
image bg render195 = "images/Render195.webp"

image bg render198 = "images/Render198.webp"
image bg render199 = "images/Render199.webp"
image bg render200 = "images/Render200.webp"
image bg render201 = "images/Render201.webp"
image bg render202 = "images/Render202.webp"
image bg render203 = "images/Render203.webp"
image bg render204 = "images/Render204.webp"
image bg render205 = "images/Render205.webp"
image bg render206 = "images/Render206.webp"
image bg render207 = "images/Render207.webp"
image bg render208 = "images/Render208.webp"
image bg render209 = "images/Render209.webp"
image bg render210 = "images/Render210.webp"
image bg render211 = "images/Render211.webp"
image bg render212 = "images/Render212.webp"
image bg render213 = "images/Render213.webp"
image bg render214 = "images/Render214.webp"
image bg render215 = "images/Render215.webp"
image bg render216 = "images/Render216.webp"
image bg render217 = "images/Render217.webp"
image bg render218 = "images/Render218.webp"
image bg render219 = "images/Render219.webp"
image bg render220 = "images/Render220.webp"
image bg render221 = "images/Render221.webp"
image bg render222 = "images/Render222.webp"
image bg render223 = "images/Render223.webp"
image bg render224 = "images/Render224.webp"
image bg render225 = "images/Render225.webp"

image bg render223 = "images/Render223.webp"
image bg render224 = "images/Render224.webp"
image bg render225 = "images/Render225.webp"
image bg render226 = "images/Render226.webp"
image bg render227 = "images/Render227.webp"
image bg render228 = "images/Render228.webp"
image bg render229 = "images/Render229.webp"
image bg render230 = "images/Render230.webp"
image bg render231 = "images/Render231.webp"
image bg render232 = "images/Render232.webp"
image bg render233 = "images/Render233.webp"
image bg render234 = "images/Render234.webp"
image bg render235 = "images/Render235.webp"
image bg render236 = "images/Render236.webp"
image bg render237 = "images/Render237.webp"
image bg render238 = "images/Render238.webp"
image bg render239 = "images/Render239.webp"
image bg render240 = "images/Render240.webp"
image bg render241 = "images/Render241.webp"
image bg render242 = "images/Render242.webp"
image bg render243 = "images/Render243.webp"
image bg render244 = "images/Render244.webp"
image bg render245 = "images/Render245.webp"
image bg render246 = "images/Render246.webp"
image bg render247 = "images/Render247.webp"
image bg render248 = "images/Render248.webp"
image bg render249 = "images/Render249.webp"
image bg render250 = "images/Render250.webp"
image bg render251 = "images/Render251.webp"
image bg render252 = "images/Render252.webp"
image bg render253 = "images/Render253.webp"
image bg render254 = "images/Render254.webp"
image bg render255 = "images/Render255.webp"
image bg render256 = "images/Render256.webp"
image bg render257 = "images/Render257.webp"
image bg render258 = "images/Render258.webp"
image bg render259 = "images/Render259.webp"
image bg render260 = "images/Render260.webp"
image bg render261 = "images/Render261.webp"
image bg render262 = "images/Render262.webp"
image bg render263 = "images/Render263.webp"
image bg render264 = "images/Render264.webp"
image bg render265 = "images/Render265.webp"
image bg render266 = "images/Render266.webp"
image bg render267 = "images/Render267.webp"
image bg render268 = "images/Render268.webp"
image bg render269 = "images/Render269.webp"
image bg render270 = "images/Render270.webp"
image bg render271 = "images/Render271.webp"
image bg render272 = "images/Render272.webp"
image bg render273 = "images/Render273.webp"
image bg render274 = "images/Render274.webp"
image bg render275 = "images/Render275.webp"
image bg render276 = "images/Render276.webp"


image bg render277 = "images/Render277.webp"
image bg render278 = "images/Render278.webp"
image bg render279 = "images/Render279.webp"
image bg render280 = "images/Render280.webp"
image bg render281 = "images/Render281.webp"
image bg render282 = "images/Render282.webp"
image bg render283 = "images/Render283.webp"
image bg render284 = "images/Render284.webp"
image bg render285 = "images/Render285.webp"
image bg render286 = "images/Render286.webp"
image bg render287 = "images/Render287.webp"
image bg render288 = "images/Render288.webp"
image bg render289 = "images/Render289.webp"
image bg render290 = "images/Render290.webp"
image bg render291 = "images/Render291.webp"
image bg render292 = "images/Render292.webp"
image bg render293 = "images/Render293.webp"
image bg render294 = "images/Render294.webp"
image bg render295 = "images/Render295.webp"
image bg render296 = "images/Render296.webp"
image bg render297 = "images/Render297.webp"
image bg render298 = "images/Render298.webp"
image bg render299 = "images/Render299.webp"
image bg render300 = "images/Render300.webp"
image bg render301 = "images/Render301.webp"
image bg render302 = "images/Render302.webp"
image bg render303 = "images/Render303.webp"
image bg render304 = "images/Render304.webp"
image bg render305 = "images/Render305.webp"
image bg render306 = "images/Render306.webp"
image bg render307 = "images/Render307.webp"
image bg render308 = "images/Render308.webp"
image bg render309 = "images/Render309.webp"
image bg render310 = "images/Render310.webp"

image bg render310 = "images/Render310.webp"
image bg render311 = "images/Render311.webp"
image bg render312 = "images/Render312.webp"
image bg render313 = "images/Render313.webp"
image bg render314 = "images/Render314.webp"
image bg render315 = "images/Render315.webp"
image bg render316 = "images/Render316.webp"
image bg render317 = "images/Render317.webp"
image bg render318 = "images/Render318.webp"
image bg render319 = "images/Render319.webp"
image bg render320 = "images/Render320.webp"
image bg render321 = "images/Render321.webp"
image bg render322 = "images/Render322.webp"
image bg render323 = "images/Render323.webp"
image bg render324 = "images/Render324.webp"
image bg render325 = "images/Render325.webp"
image bg render326 = "images/Render326.webp"
image bg render327 = "images/Render327.webp"
image bg render328 = "images/Render328.webp"
image bg render329 = "images/Render329.webp"
image bg render330 = "images/Render330.webp"
image bg render331 = "images/Render331.webp"
image bg render332 = "images/Render332.webp"
image bg render333 = "images/Render333.webp"
image bg render334 = "images/Render334.webp"
image bg render335 = "images/Render335.webp"
image bg render336 = "images/Render336.webp"
image bg render337 = "images/Render337.webp"
image bg render338 = "images/Render338.webp"
image bg render339 = "images/Render339.webp"
image bg render340 = "images/Render340.webp"
image bg render341 = "images/Render341.webp"
image bg render342 = "images/Render342.webp"
image bg render343 = "images/Render343.webp"
image bg render344 = "images/Render344.webp"
image bg render345 = "images/Render345.webp"
image bg render346 = "images/Render346.webp"
image bg render347 = "images/Render347.webp"
image bg render348 = "images/Render348.webp"
image bg render349 = "images/Render349.webp"
image bg render350 = "images/Render350.webp"
image bg render351 = "images/Render351.webp"
image bg render352 = "images/Render352.webp"
image bg render353 = "images/Render353.webp"
image bg render354 = "images/Render354.webp"
image bg render355 = "images/Render355.webp"
image bg render356 = "images/Render356.webp"
image bg render357 = "images/Render357.webp"
image bg render358 = "images/Render358.webp"
image bg render359 = "images/Render359.webp"
image bg render360 = "images/Render360.webp"
image bg render361 = "images/Render361.webp"
image bg render362 = "images/Render362.webp"
image bg render363 = "images/Render363.webp"
image bg render364 = "images/Render364.webp"
image bg render365 = "images/Render365.webp"

image bg render366 = "images/Render366.webp"
image bg render367 = "images/Render367.webp"
image bg render368 = "images/Render368.webp"
image bg render369 = "images/Render369.webp"
image bg render370 = "images/Render370.webp"
image bg render371 = "images/Render371.webp"
image bg render372 = "images/Render372.webp"
image bg render373 = "images/Render373.webp"
image bg render374 = "images/Render374.webp"
image bg render375 = "images/Render375.webp"
image bg render376 = "images/Render376.webp"
image bg render377 = "images/Render377.webp"
image bg render378 = "images/Render378.webp"
image bg render379 = "images/Render379.webp"
image bg render380 = "images/Render380.webp"
image bg render381 = "images/Render381.webp"
image bg render382 = "images/Render382.webp"
image bg render383 = "images/Render383.webp"
image bg render384 = "images/Render384.webp"
image bg render385 = "images/Render385.webp"
image bg render386 = "images/Render386.webp"
image bg render387 = "images/Render387.webp"
image bg render388 = "images/Render388.webp"
image bg render389 = "images/Render389.webp"
image bg render390 = "images/Render390.webp"
image bg render391 = "images/Render391.webp"
image bg render392 = "images/Render392.webp"
image bg render393 = "images/Render393.webp"
image bg render394 = "images/Render394.webp"
image bg render395 = "images/Render395.webp"
image bg render396 = "images/Render396.webp"

image bg render396 = "images/Render396.webp"
image bg render397 = "images/Render397.webp"
image bg render398 = "images/Render398.webp"
image bg render399 = "images/Render399.webp"
image bg render400 = "images/Render400.webp"
image bg render401 = "images/Render401.webp"
image bg render402 = "images/Render402.webp"
image bg render403 = "images/Render403.webp"
image bg render404 = "images/Render404.webp"
image bg render405 = "images/Render405.webp"
image bg render406 = "images/Render406.webp"
image bg render407 = "images/Render407.webp"
image bg render408 = "images/Render408.webp"
image bg render409 = "images/Render409.webp"
image bg render410 = "images/Render410.webp"
image bg render411 = "images/Render411.webp"
image bg render412 = "images/Render412.webp"
image bg render413 = "images/Render413.webp"
image bg render414 = "images/Render414.webp"
image bg render415 = "images/Render415.webp"
image bg render416 = "images/Render416.webp"
image bg render417 = "images/Render417.webp"
image bg render418 = "images/Render418.webp"
image bg render419 = "images/Render419.webp"
image bg render420 = "images/Render420.webp"
image bg render421 = "images/Render421.webp"
image bg render422 = "images/Render422.webp"
image bg render423 = "images/Render423.webp"
image bg render424 = "images/Render424.webp"
image bg render425 = "images/Render425.webp"
image bg render426 = "images/Render426.webp"
image bg render427 = "images/Render427.webp"
image bg render428 = "images/Render428.webp"
image bg render429 = "images/Render429.webp"
image bg render430 = "images/Render430.webp"
image bg render431 = "images/Render431.webp"
image bg render432 = "images/Render432.webp"
image bg render433 = "images/Render433.webp"
image bg render434 = "images/Render434.webp"
image bg render435 = "images/Render435.webp"
image bg render436 = "images/Render436.webp"
image bg render437 = "images/Render437.webp"
image bg render438 = "images/Render438.webp"
image bg render439 = "images/Render439.webp"
image bg render440 = "images/Render440.webp"
image bg render441 = "images/Render441.webp"
image bg render443 = "images/Render443.webp"
image bg render444 = "images/Render444.webp"
image bg render445 = "images/Render445.webp"
image bg render446 = "images/Render446.webp"
image bg render447 = "images/Render447.webp"
image bg render448 = "images/Render448.webp"
image bg render449 = "images/Render449.webp"
image bg render450 = "images/Render450.webp"
image bg render451 = "images/Render451.webp"
image bg render452 = "images/Render452.webp"
image bg render453 = "images/Render453.webp"
image bg render454 = "images/Render454.webp"
image bg render455 = "images/Render455.webp"
image bg render456 = "images/Render456.webp"
image bg render457 = "images/Render457.webp"
image bg render458 = "images/Render458.webp"
image bg render459 = "images/Render459.webp"
image bg render460 = "images/Render460.webp"
image bg render461 = "images/Render461.webp"
image bg render462 = "images/Render462.webp"
image bg render463 = "images/Render463.webp"
image bg render464 = "images/Render464.webp"

image bg render465 = "images/Render465.webp"
image bg render466 = "images/Render466.webp"
image bg render467 = "images/Render467.webp"
image bg render468 = "images/Render468.webp"
image bg render469 = "images/Render469.webp"
image bg render470 = "images/Render470.webp"
image bg render471 = "images/Render471.webp"
image bg render472 = "images/Render472.webp"
image bg render473 = "images/Render473.webp"
image bg render474 = "images/Render474.webp"
image bg render475 = "images/Render475.webp"
image bg render476 = "images/Render476.webp"
image bg render477 = "images/Render477.webp"
image bg render478 = "images/Render478.webp"
image bg render479 = "images/Render479.webp"
image bg render480 = "images/Render480.webp"
image bg render481 = "images/Render481.webp"
image bg render482 = "images/Render482.webp"
image bg render483 = "images/Render483.webp"
image bg render484 = "images/Render484.webp"
image bg render485 = "images/Render485.webp"
image bg render486 = "images/Render486.webp"
image bg render487 = "images/Render487.webp"
image bg render488 = "images/Render488.webp"
image bg render489 = "images/Render489.webp"
image bg render490 = "images/Render490.webp"
image bg render491 = "images/Render491.webp"
image bg render492 = "images/Render492.webp"
image bg render493 = "images/Render493.webp"
image bg render494 = "images/Render494.webp"
image bg render495 = "images/Render495.webp"
image bg render496 = "images/Render496.webp"
image bg render497 = "images/Render497.webp"
image bg render498 = "images/Render498.webp"
image bg render499 = "images/Render499.webp"
image bg render500 = "images/Render500.webp"
image bg render501 = "images/Render501.webp"
image bg render502 = "images/Render502.webp"
image bg render503 = "images/Render503.webp"
image bg render504 = "images/Render504.webp"
image bg render505 = "images/Render505.webp"
image bg render506 = "images/Render506.webp"
image bg render507 = "images/Render507.webp"
image bg render508 = "images/Render508.webp"
image bg render509 = "images/Render509.webp"
image bg render510 = "images/Render510.webp"
image bg render511 = "images/Render511.webp"
image bg render512 = "images/Render512.webp"
image bg render513 = "images/Render513.webp"
image bg render514 = "images/Render514.webp"
image bg render515 = "images/Render515.webp"
image bg render516 = "images/Render516.webp"
image bg render517 = "images/Render517.webp"
image bg render518 = "images/Render518.webp"
image bg render519 = "images/Render519.webp"
image bg render520 = "images/Render520.webp"
image bg render521 = "images/Render521.webp"
image bg render522 = "images/Render522.webp"
image bg render523 = "images/Render523.webp"
image bg render524 = "images/Render524.webp"
image bg render525 = "images/Render525.webp"
image bg render526 = "images/Render526.webp"
image bg render527 = "images/Render527.webp"
image bg render528 = "images/Render528.webp"
image bg render529 = "images/Render529.webp"
image bg render530 = "images/Render530.webp"
image bg render531 = "images/Render531.webp"
image bg render532 = "images/Render532.webp"
image bg render533 = "images/Render533.webp"
image bg render534 = "images/Render534.webp"
image bg render535 = "images/Render535.webp"
image bg render536 = "images/Render536.webp"
image bg render537 = "images/Render537.webp"
image bg render538 = "images/Render538.webp"
image bg render539 = "images/Render539.webp"
image bg render540 = "images/Render540.webp"
image bg render541 = "images/Render541.webp"
image bg render542 = "images/Render542.webp"
image bg render543 = "images/Render543.webp"
image bg render544 = "images/Render544.webp"
image bg render545 = "images/Render545.webp"
image bg render546 = "images/Render546.webp"
image bg render547 = "images/Render547.webp"
image bg render548 = "images/Render548.webp"
image bg render549 = "images/Render549.webp"
image bg render550 = "images/Render550.webp"
image bg render551 = "images/Render551.webp"
image bg render552 = "images/Render552.webp"
image bg render553 = "images/Render553.webp"
image bg render554 = "images/Render554.webp"
image bg render555 = "images/Render555.webp"
image bg render556 = "images/Render556.webp"
image bg render557 = "images/Render557.webp"
image bg render558 = "images/Render558.webp"
image bg render559 = "images/Render559.webp"
image bg render560 = "images/Render560.webp"
image bg render561 = "images/Render561.webp"
image bg render562 = "images/Render562.webp"
image bg render563 = "images/Render563.webp"
image bg render564 = "images/Render564.webp"
image bg render565 = "images/Render565.webp"
image bg render566 = "images/Render566.webp"
image bg render567 = "images/Render567.webp"
image bg render568 = "images/Render568.webp"
image bg render569 = "images/Render569.webp"
image bg render570 = "images/Render570.webp"
image bg render571 = "images/Render571.webp"
image bg render572 = "images/Render572.webp"
image bg render573 = "images/Render573.webp"
image bg render574 = "images/Render574.webp"
image bg render575 = "images/Render575.webp"
image bg render576 = "images/Render576.webp"
image bg render577 = "images/Render577.webp"
image bg render578 = "images/Render578.webp"

image bg render579 = "images/Render579.webp"
image bg render580 = "images/Render580.webp"
image bg render581 = "images/Render581.webp"
image bg render582 = "images/Render582.webp"
image bg render583 = "images/Render583.webp"
image bg render584 = "images/Render584.webp"
image bg render585 = "images/Render585.webp"
image bg render585 = "images/Render585.webp"
image bg render586 = "images/Render586.webp"
image bg render587 = "images/Render587.webp"
image bg render588 = "images/Render588.webp"
image bg render589 = "images/Render589.webp"
image bg render590 = "images/Render590.webp"
image bg render591 = "images/Render591.webp"
image bg render592 = "images/Render592.webp"
image bg render593 = "images/Render593.webp"
image bg render594 = "images/Render594.webp"
image bg render595 = "images/Render595.webp"
image bg render596 = "images/Render596.webp"
image bg render597 = "images/Render597.webp"
image bg render598 = "images/Render598.webp"
image bg render599 = "images/Render599.webp"
image bg render600 = "images/Render600.webp"
image bg render601 = "images/Render601.webp"
image bg render602 = "images/Render602.webp"
image bg render603 = "images/Render603.webp"
image bg render604 = "images/Render604.webp"
image bg render605 = "images/Render605.webp"
image bg render606 = "images/Render606.webp"
image bg render607 = "images/Render607.webp"
image bg render608 = "images/Render608.webp"
image bg render609 = "images/Render609.webp"
image bg render610 = "images/Render610.webp"
image bg render611 = "images/Render611.webp"
image bg render612 = "images/Render612.webp"
image bg render613 = "images/Render613.webp"
image bg render614 = "images/Render614.webp"
image bg render615 = "images/Render615.webp"
image bg render616 = "images/Render616.webp"
image bg render617 = "images/Render617.webp"
image bg render618 = "images/Render618.webp"
image bg render619 = "images/Render619.webp"
image bg render620 = "images/Render620.webp"
image bg render621 = "images/Render621.webp"
image bg render622 = "images/Render622.webp"
image bg render623 = "images/Render623.webp"
image bg render624 = "images/Render624.webp"
image bg render625 = "images/Render625.webp"
image bg render626 = "images/Render626.webp"
image bg render627 = "images/Render627.webp"
image bg render628 = "images/Render628.webp"
image bg render629 = "images/Render629.webp"
image bg render630 = "images/Render630.webp"
image bg render631 = "images/Render631.webp"
image bg render632 = "images/Render632.webp"
image bg render633 = "images/Render633.webp"
image bg render634 = "images/Render634.webp"
image bg render635 = "images/Render635.webp"
image bg render636 = "images/Render636.webp"
image bg render637 = "images/Render637.webp"
image bg render638 = "images/Render638.webp"
image bg render639 = "images/Render639.webp"
image bg render640 = "images/Render640.webp"
image bg render641 = "images/Render641.webp"
image bg render642 = "images/Render642.webp"
image bg render643 = "images/Render643.webp"
image bg render644 = "images/Render644.webp"
image bg render645 = "images/Render645.webp"
image bg render646 = "images/Render646.webp"
image bg render647 = "images/Render647.webp"
image bg render648 = "images/Render648.webp"
image bg render649 = "images/Render649.webp"
image bg render650 = "images/Render650.webp"
image bg render651 = "images/Render651.webp"
image bg render652 = "images/Render652.webp"
image bg render653 = "images/Render653.webp"
image bg render654 = "images/Render654.webp"
image bg render655 = "images/Render655.webp"
image bg render656 = "images/Render656.webp"
image bg render657 = "images/Render657.webp"
image bg render658 = "images/Render658.webp"
image bg render659 = "images/Render659.webp"
image bg render660 = "images/Render660.webp"
image bg render661 = "images/Render661.webp"
image bg render662 = "images/Render662.webp"
image bg render663 = "images/Render663.webp"
image bg render664 = "images/Render664.webp"
image bg render665 = "images/Render665.webp"
image bg render666 = "images/Render666.webp"
image bg render667 = "images/Render667.webp"
image bg render668 = "images/Render668.webp"
image bg render669 = "images/Render669.webp"
image bg render670 = "images/Render670.webp"
image bg render671 = "images/Render671.webp"
image bg render672 = "images/Render672.webp"
image bg render673 = "images/Render673.webp"
image bg render674 = "images/Render674.webp"
image bg render675 = "images/Render675.webp"
image bg render676 = "images/Render676.webp"
image bg render677 = "images/Render677.webp"
image bg render678 = "images/Render678.webp"
image bg render679 = "images/Render679.webp"
image bg render680 = "images/Render680.webp"
image bg render681 = "images/Render681.webp"
image bg render682 = "images/Render682.webp"
image bg render683 = "images/Render683.webp"
image bg render684 = "images/Render684.webp"
image bg render685 = "images/Render685.webp"
image bg render686 = "images/Render686.webp"
image bg render687 = "images/Render687.webp"
image bg render688 = "images/Render688.webp"
image bg render689 = "images/Render689.webp"
image bg render690 = "images/Render690.webp"
image bg render691 = "images/Render691.webp"
image bg render692 = "images/Render692.webp"
image bg render693 = "images/Render693.webp"
image bg render694 = "images/Render694.webp"
image bg render695 = "images/Render695.webp"
image bg render696 = "images/Render696.webp"
image bg render697 = "images/Render697.webp"
image bg render698 = "images/Render698.webp"
image bg render699 = "images/Render699.webp"
image bg render700 = "images/Render700.webp"
image bg render701 = "images/Render701.webp"
image bg render702 = "images/Render702.webp"
image bg render703 = "images/Render703.webp"
image bg render704 = "images/Render704.webp"
image bg render705 = "images/Render705.webp"
image bg render706 = "images/Render706.webp"
image bg render707 = "images/Render707.webp"
image bg render708 = "images/Render708.webp"
image bg render709 = "images/Render709.webp"
image bg render710 = "images/Render710.webp"
image bg render711 = "images/Render711.webp"
image bg render712 = "images/Render712.webp"
image bg render713 = "images/Render713.webp"
image bg render714 = "images/Render714.webp"
image bg render715 = "images/Render715.webp"
image bg render716 = "images/Render716.webp"
image bg render717 = "images/Render717.webp"
image bg render718 = "images/Render718.webp"
image bg render719 = "images/Render719.webp"
image bg render720 = "images/Render720.webp"
image bg render721 = "images/Render721.webp"
image bg render722 = "images/Render722.webp"
image bg render723 = "images/Render723.webp"
image bg render724 = "images/Render724.webp"
image bg render725 = "images/Render725.webp"
image bg render726 = "images/Render726.webp"
image bg render727 = "images/Render727.webp"
image bg render728 = "images/Render728.webp"
image bg render729 = "images/Render729.webp"
image bg render730 = "images/Render730.webp"
image bg render731 = "images/Render731.webp"
image bg render732 = "images/Render732.webp"
image bg render733 = "images/Render733.webp"
image bg render734 = "images/Render734.webp"
image bg render735 = "images/Render735.webp"
image bg render736 = "images/Render736.webp"
image bg render737 = "images/Render737.webp"
image bg render738 = "images/Render738.webp"
image bg render739 = "images/Render739.webp"
image bg render740 = "images/Render740.webp"
image bg render741 = "images/Render741.webp"
image bg render742 = "images/Render742.webp"
image bg render743 = "images/Render743.webp"

image bg render744 = "images/Render744.webp"
image bg render745 = "images/Render745.webp"
image bg render746 = "images/Render746.webp"
image bg render747 = "images/Render747.webp"
image bg render748 = "images/Render748.webp"
image bg render749 = "images/Render749.webp"
image bg render750 = "images/Render750.webp"
image bg render751 = "images/Render751.webp"
image bg render752 = "images/Render752.webp"
image bg render753 = "images/Render753.webp"
image bg render754 = "images/Render754.webp"
image bg render755 = "images/Render755.webp"
image bg render756 = "images/Render756.webp"
image bg render757 = "images/Render757.webp"
image bg render758 = "images/Render758.webp"
image bg render759 = "images/Render759.webp"
image bg render760 = "images/Render760.webp"
image bg render761 = "images/Render761.webp"
image bg render762 = "images/Render762.webp"
image bg render763 = "images/Render763.webp"
image bg render764 = "images/Render764.webp"
image bg render765 = "images/Render765.webp"
image bg render766 = "images/Render766.webp"
image bg render767 = "images/Render767.webp"
image bg render768 = "images/Render768.webp"
image bg render769 = "images/Render769.webp"
image bg render770 = "images/Render770.webp"
image bg render771 = "images/Render771.webp"
image bg render772 = "images/Render772.webp"
image bg render773 = "images/Render773.webp"
image bg render774 = "images/Render774.webp"
image bg render775 = "images/Render775.webp"
image bg render776 = "images/Render776.webp"
image bg render777 = "images/Render777.webp"
image bg render778 = "images/Render778.webp"
image bg render779 = "images/Render779.webp"
image bg render780 = "images/Render780.webp"
image bg render781 = "images/Render781.webp"
image bg render782 = "images/Render782.webp"
image bg render783 = "images/Render783.webp"
image bg render784 = "images/Render784.webp"
image bg render785 = "images/Render785.webp"
image bg render786 = "images/Render786.webp"
image bg render787 = "images/Render787.webp"
image bg render788 = "images/Render788.webp"
image bg render789 = "images/Render789.webp"
image bg render790 = "images/Render790.webp"
image bg render791 = "images/Render791.webp"
image bg render792 = "images/Render792.webp"
image bg render793 = "images/Render793.webp"
image bg render794 = "images/Render794.webp"
image bg render795 = "images/Render795.webp"
image bg render796 = "images/Render796.webp"
image bg render797 = "images/Render797.webp"
image bg render798 = "images/Render798.webp"
image bg render799 = "images/Render799.webp"
image bg render800 = "images/Render800.webp"
image bg render801 = "images/Render801.webp"
image bg render802 = "images/Render802.webp"
image bg render803 = "images/Render803.webp"
image bg render804 = "images/Render804.webp"
image bg render805 = "images/Render805.webp"
image bg render806 = "images/Render806.webp"
image bg render807 = "images/Render807.webp"
image bg render808 = "images/Render808.webp"
image bg render809 = "images/Render809.webp"
image bg render810 = "images/Render810.webp"
image bg render811 = "images/Render811.webp"
image bg render812 = "images/Render812.webp"
image bg render813 = "images/Render813.webp"
image bg render814 = "images/Render814.webp"
image bg render815 = "images/Render815.webp"
image bg render816 = "images/Render816.webp"
image bg render817 = "images/Render817.webp"
image bg render818 = "images/Render818.webp"
image bg render819 = "images/Render819.webp"
image bg render820 = "images/Render820.webp"
image bg render821 = "images/Render821.webp"
image bg render822 = "images/Render822.webp"
image bg render823 = "images/Render823.webp"
image bg render824 = "images/Render824.webp"
image bg render825 = "images/Render825.webp"
image bg render826 = "images/Render826.webp"
image bg render827 = "images/Render827.webp"
image bg render828 = "images/Render828.webp"
image bg render829 = "images/Render829.webp"
image bg render830 = "images/Render830.webp"
image bg render831 = "images/Render831.webp"
image bg render832 = "images/Render832.webp"
image bg render833 = "images/Render833.webp"
image bg render834 = "images/Render834.webp"
image bg render835 = "images/Render835.webp"
image bg render836 = "images/Render836.webp"
image bg render837 = "images/Render837.webp"
image bg render838 = "images/Render838.webp"
image bg render839 = "images/Render839.webp"
image bg render840 = "images/Render840.webp"
image bg render841 = "images/Render841.webp"
image bg render842 = "images/Render842.webp"
image bg render843 = "images/Render843.webp"
image bg render844 = "images/Render844.webp"
image bg render845 = "images/Render845.webp"
image bg render846 = "images/Render846.webp"
image bg render847 = "images/Render847.webp"
image bg render848 = "images/Render848.webp"
image bg render849 = "images/Render849.webp"
image bg render850 = "images/Render850.webp"
image bg render851 = "images/Render851.webp"
image bg render852 = "images/Render852.webp"
image bg render853 = "images/Render853.webp"
image bg render854 = "images/Render854.webp"
image bg render855 = "images/Render855.webp"
image bg render856 = "images/Render856.webp"
image bg render857 = "images/Render857.webp"
image bg render858 = "images/Render858.webp"
image bg render859 = "images/Render859.webp"
image bg render860 = "images/Render860.webp"
image bg render861 = "images/Render861.webp"
image bg render862 = "images/Render862.webp"
image bg render863 = "images/Render863.webp"
image bg render864 = "images/Render864.webp"
image bg render865 = "images/Render865.webp"
image bg render866 = "images/Render866.webp"
image bg render867 = "images/Render867.webp"
image bg render868 = "images/Render868.webp"
image bg render869 = "images/Render869.webp"
image bg render870 = "images/Render870.webp"
image bg render871 = "images/Render871.webp"
image bg render872 = "images/Render872.webp"
image bg render873 = "images/Render873.webp"
image bg render874 = "images/Render874.webp"
image bg render875 = "images/Render875.webp"
image bg render876 = "images/Render876.webp"
image bg render877 = "images/Render877.webp"
image bg render878 = "images/Render878.webp"
image bg render879 = "images/Render879.webp"
image bg render880 = "images/Render880.webp"
image bg render881 = "images/Render881.webp"
image bg render882 = "images/Render882.webp"
image bg render883 = "images/Render883.webp"
image bg render884 = "images/Render884.webp"
image bg render885 = "images/Render885.webp"
image bg render886 = "images/Render886.webp"
image bg render887 = "images/Render887.webp"
image bg render888 = "images/Render888.webp"
image bg render889 = "images/Render889.webp"
image bg render890 = "images/Render890.webp"
image bg render891 = "images/Render891.webp"
image bg render892 = "images/Render892.webp"
image bg render893 = "images/Render893.webp"
image bg render894 = "images/Render894.webp"
image bg render895 = "images/Render895.webp"
image bg render896 = "images/Render896.webp"
image bg render897 = "images/Render897.webp"
image bg render898 = "images/Render898.webp"
image bg render899 = "images/Render899.webp"
image bg render900 = "images/Render900.webp"
image bg render901 = "images/Render901.webp"
image bg render902 = "images/Render902.webp"
image bg render903 = "images/Render903.webp"
image bg render904 = "images/Render904.webp"
image bg render905 = "images/Render905.webp"
image bg render906 = "images/Render906.webp"
image bg render907 = "images/Render907.webp"

image bg render908 = "images/Render908.webp"
image bg render908 = "images/Render908.webp"
image bg render909 = "images/Render909.webp"
image bg render910 = "images/Render910.webp"
image bg render911 = "images/Render911.webp"
image bg render912 = "images/Render912.webp"


image bg render913 = "images/Render913.webp"
image bg render914 = "images/Render914.webp"
image bg render915 = "images/Render915.webp"
image bg render916 = "images/Render916.webp"
image bg render917 = "images/Render917.webp"
image bg render918 = "images/Render918.webp"
image bg render919 = "images/Render919.webp"
image bg render920 = "images/Render920.webp"
image bg render921 = "images/Render921.webp"
image bg render922 = "images/Render922.webp"
image bg render923 = "images/Render923.webp"
image bg render924 = "images/Render924.webp"
image bg render925 = "images/Render925.webp"
image bg render926 = "images/Render926.webp"
image bg render927 = "images/Render927.webp"
image bg render928 = "images/Render928.webp"
image bg render929 = "images/Render929.webp"
image bg render930 = "images/Render930.webp"
image bg render931 = "images/Render931.webp"
image bg render932 = "images/Render932.webp"
image bg render933 = "images/Render933.webp"
image bg render934 = "images/Render934.webp"
image bg render935 = "images/Render935.webp"
image bg render936 = "images/Render936.webp"
image bg render937 = "images/Render937.webp"
image bg render938 = "images/Render938.webp"
image bg render939 = "images/Render939.webp"
image bg render940 = "images/Render940.webp"
image bg render941 = "images/Render941.webp"
image bg render942 = "images/Render942.webp"
image bg render943 = "images/Render943.webp"
image bg render944 = "images/Render944.webp"
image bg render945 = "images/Render945.webp"
image bg render946 = "images/Render946.webp"
image bg render947 = "images/Render947.webp"
image bg render948 = "images/Render948.webp"
image bg render949 = "images/Render949.webp"
image bg render950 = "images/Render950.webp"
image bg render951 = "images/Render951.webp"
image bg render952 = "images/Render952.webp"
image bg render953 = "images/Render953.webp"
image bg render954 = "images/Render954.webp"
image bg render955 = "images/Render955.webp"
image bg render956 = "images/Render956.webp"
image bg render957 = "images/Render957.webp"
image bg render958 = "images/Render958.webp"
image bg render959 = "images/Render959.webp"
image bg render960 = "images/Render960.webp"
image bg render961 = "images/Render961.webp"
image bg render962 = "images/Render962.webp"
image bg render963 = "images/Render963.webp"
image bg render964 = "images/Render964.webp"
image bg render965 = "images/Render965.webp"
image bg render966 = "images/Render966.webp"
image bg render967 = "images/Render967.webp"
image bg render968 = "images/Render968.webp"
image bg render969 = "images/Render969.webp"
image bg render970 = "images/Render970.webp"
image bg render971 = "images/Render971.webp"
image bg render972 = "images/Render972.webp"
image bg render973 = "images/Render973.webp"
image bg render974 = "images/Render974.webp"
image bg render975 = "images/Render975.webp"
image bg render976 = "images/Render976.webp"
image bg render977 = "images/Render977.webp"
image bg render978 = "images/Render978.webp"
image bg render979 = "images/Render979.webp"
image bg render980 = "images/Render980.webp"
image bg render981 = "images/Render981.webp"
image bg render982 = "images/Render982.webp"
image bg render983 = "images/Render983.webp"
image bg render984 = "images/Render984.webp"
image bg render985 = "images/Render985.webp"
image bg render986 = "images/Render986.webp"
image bg render987 = "images/Render987.webp"
image bg render988 = "images/Render988.webp"
image bg render989 = "images/Render989.webp"
image bg render990 = "images/Render990.webp"
image bg render991 = "images/Render991.webp"
image bg render992 = "images/Render992.webp"
image bg render993 = "images/Render993.webp"
image bg render994 = "images/Render994.webp"
image bg render995 = "images/Render995.webp"
image bg render996 = "images/Render996.webp"
image bg render997 = "images/Render997.webp"
image bg render998 = "images/Render998.webp"
image bg render999 = "images/Render999.webp"
image bg render1000 = "images/Render1000.webp"
image bg render1001 = "images/Render1001.webp"
image bg render1002 = "images/Render1002.webp"
image bg render1003 = "images/Render1003.webp"
image bg render1004 = "images/Render1004.webp"
image bg render1005 = "images/Render1005.webp"
image bg render1006 = "images/Render1006.webp"
image bg render1007 = "images/Render1007.webp"
image bg render1008 = "images/Render1008.webp"
image bg render1009 = "images/Render1009.webp"
image bg render1010 = "images/Render1010.webp"
image bg render1011 = "images/Render1011.webp"
image bg render1012 = "images/Render1012.webp"
image bg render1013 = "images/Render1013.webp"
image bg render1014 = "images/Render1014.webp"
image bg render1015 = "images/Render1015.webp"
image bg render1016 = "images/Render1016.webp"
image bg render1017 = "images/Render1017.webp"
image bg render1018 = "images/Render1018.webp"
image bg render1019 = "images/Render1019.webp"
image bg render1020 = "images/Render1020.webp"
image bg render1021 = "images/Render1021.webp"
image bg render1022 = "images/Render1022.webp"
image bg render1023 = "images/Render1023.webp"
image bg render1024 = "images/Render1024.webp"
image bg render1025 = "images/Render1025.webp"
image bg render1026 = "images/Render1026.webp"
image bg render1027 = "images/Render1027.webp"
image bg render1028 = "images/Render1028.webp"
image bg render1029 = "images/Render1029.webp"
image bg render1030 = "images/Render1030.webp"
image bg render1031 = "images/Render1031.webp"
image bg render1032 = "images/Render1032.webp"
image bg render1033 = "images/Render1033.webp"
image bg render1034 = "images/Render1034.webp"
image bg render1035 = "images/Render1035.webp"
image bg render1036 = "images/Render1036.webp"
image bg render1037 = "images/Render1037.webp"
image bg render1038 = "images/Render1038.webp"
image bg render1039 = "images/Render1039.webp"
image bg render1040 = "images/Render1040.webp"
image bg render1041 = "images/Render1041.webp"
image bg render1042 = "images/Render1042.webp"
image bg render1043 = "images/Render1043.webp"
image bg render1044 = "images/Render1044.webp"
image bg render1045 = "images/Render1045.webp"
image bg render1046 = "images/Render1046.webp"
image bg render1047 = "images/Render1047.webp"
image bg render1048 = "images/Render1048.webp"
image bg render1049 = "images/Render1049.webp"
image bg render1050 = "images/Render1050.webp"
image bg render1051 = "images/Render1051.webp"
image bg render1052 = "images/Render1052.webp"
image bg render1053 = "images/Render1053.webp"
image bg render1054 = "images/Render1054.webp"
image bg render1055 = "images/Render1055.webp"
image bg render1056 = "images/Render1056.webp"
image bg render1057 = "images/Render1057.webp"
image bg render1058 = "images/Render1058.webp"
image bg render1059 = "images/Render1059.webp"
image bg render1060 = "images/Render1060.webp"
image bg render1061 = "images/Render1061.webp"

image bg render1062 = "images/Render1062.webp"
image bg render1063 = "images/Render1063.webp"
image bg render1064 = "images/Render1064.webp"
image bg render1065 = "images/Render1065.webp"
image bg render1066 = "images/Render1066.webp"
image bg render1067 = "images/Render1067.webp"
image bg render1068 = "images/Render1068.webp"
image bg render1069 = "images/Render1069.webp"
image bg render1070 = "images/Render1070.webp"

image bg render1071 = "images/Render1071.webp"
image bg render1072 = "images/Render1072.webp"
image bg render1073 = "images/Render1073.webp"
image bg render1074 = "images/Render1074.webp"

image bg render1075 = "images/Render1075.webp"

image bg render1075 = "images/Render1075.webp"
image bg render1076 = "images/Render1076.webp"
image bg render1077 = "images/Render1077.webp"
image bg render1078 = "images/Render1078.webp"
image bg render1079 = "images/Render1079.webp"
image bg render1080 = "images/Render1080.webp"
image bg render1081 = "images/Render1081.webp"
image bg render1082 = "images/Render1082.webp"
image bg render1083 = "images/Render1083.webp"
image bg render1084 = "images/Render1084.webp"
image bg render1085 = "images/Render1085.webp"
image bg render1086 = "images/Render1086.webp"
image bg render1087 = "images/Render1087.webp"
image bg render1088 = "images/Render1088.webp"
image bg render1089 = "images/Render1089.webp"
image bg render1090 = "images/Render1090.webp"
image bg render1091 = "images/Render1091.webp"
image bg render1092 = "images/Render1092.webp"
image bg render1093 = "images/Render1093.webp"
image bg render1094 = "images/Render1094.webp"
image bg render1095 = "images/Render1095.webp"
image bg render1096 = "images/Render1096.webp"
image bg render1097 = "images/Render1097.webp"
image bg render1098 = "images/Render1098.webp"
image bg render1099 = "images/Render1099.webp"
image bg render1100 = "images/Render1100.webp"
image bg adamkillone = "images/Adam Action animations/adamKillone0040.webp"
image bg render1101 = "images/Render1101.webp"
image bg render1102 = "images/Render1102.webp"
image bg render1103 = "images/Render1103.webp"
image bg render1104 = "images/Render1104.webp"
image bg render1105 = "images/Render1105.webp"
image bg render1106 = "images/Render1106.webp"
image bg render1107 = "images/Render1107.webp"
image bg render1108 = "images/Render1108.webp"
image bg render1109 = "images/Render1109.webp"
image bg render1110 = "images/Render1110.webp"
image bg render1111 = "images/Render1111.webp"
image bg render1112 = "images/Render1112.webp"
image bg render1113 = "images/Render1113.webp"
image bg render1114 = "images/Render1114.webp"
image bg render1115 = "images/Render1115.webp"
image bg render1116 = "images/Render1116.webp"
image bg render1117 = "images/Render1117.webp"
image bg render1118 = "images/Render1118.webp"
image bg render1119 = "images/Render1119.webp"
image bg render1120 = "images/Render1120.webp"
image bg render1121 = "images/Render1121.webp"
image bg render1122 = "images/Render1122.webp"
image bg render1123 = "images/Render1123.webp"
image bg render1124 = "images/Render1124.webp"
image bg render1125 = "images/Render1125.webp"
image bg render1126 = "images/Render1126.webp"
image bg render1127 = "images/Render1127.webp"
image bg render1128 = "images/Render1128.webp"
image bg render1129 = "images/Render1129.webp"
image bg render1130 = "images/Render1130.webp"
image bg render1131 = "images/Render1131.webp"
image bg render1132 = "images/Render1132.webp"
image bg render1133 = "images/Render1133.webp"
image bg render1134 = "images/Render1134.webp"
image bg render1135 = "images/Render1135.webp"
image bg render1136 = "images/Render1136.webp"
image bg render1137 = "images/Render1137.webp"
image bg render1138 = "images/Render1138.webp"
image bg render1139 = "images/Render1139.webp"
image bg render1140 = "images/Render1140.webp"
image bg render1141 = "images/Render1141.webp"
image bg render1142 = "images/Render1142.webp"
image bg render1143 = "images/Render1143.webp"
image bg render1144 = "images/Render1144.webp"
image bg render1145 = "images/Render1145.webp"
image bg render1146 = "images/Render1146.webp"
image bg render1147 = "images/Render1147.webp"
image bg render1148 = "images/Render1148.webp"
image bg render1149 = "images/Render1149.webp"
image bg render1150 = "images/Render1150.webp"

image bg render1151 = "images/Render1151.webp"
image bg render1152 = "images/Render1152.webp"
image bg render1153 = "images/Render1153.webp"
image bg render1154 = "images/Render1154.webp"
image bg render1155 = "images/Render1155.webp"
image bg render1156 = "images/Render1156.webp"
image bg render1157 = "images/Render1157.webp"
image bg render1158 = "images/Render1158.webp"
image bg render1159 = "images/Render1159.webp"
image bg render1160 = "images/Render1160.webp"
image bg render1161 = "images/Render1161.webp"
image bg render1162 = "images/Render1162.webp"
image bg render1163 = "images/Render1163.webp"
image bg render1164 = "images/Render1164.webp"
image bg render1165 = "images/Render1165.webp"
image bg render1166 = "images/Render1166.webp"
image bg render1167 = "images/Render1167.webp"
image bg render1168 = "images/Render1168.webp"
image bg render1169 = "images/Render1169.webp"
image bg render1170 = "images/Render1170.webp"
image bg render1171 = "images/Render1171.webp"
image bg render1172 = "images/Render1172.webp"
image bg render1173 = "images/Render1173.webp"
image bg render1174 = "images/Render1174.webp"
image bg render1175 = "images/Render1175.webp"
image bg render1176 = "images/Render1176.webp"
image bg render1177 = "images/Render1177.webp"
image bg render1178 = "images/Render1178.webp"
image bg render1179 = "images/Render1179.webp"
image bg render1180 = "images/Render1180.webp"
image bg render1181 = "images/Render1181.webp"
image bg render1182 = "images/Render1182.webp"
image bg render1183 = "images/Render1183.webp"
image bg render1184 = "images/Render1184.webp"
image bg render1185 = "images/Render1185.webp"
image bg render1186 = "images/Render1186.webp"
image bg render1187 = "images/Render1187.webp"
image bg render1188 = "images/Render1188.webp"
image bg render1189 = "images/Render1189.webp"
image bg render1190 = "images/Render1190.webp"
image bg render1191 = "images/Render1191.webp"
image bg render1192 = "images/Render1192.webp"
image bg render1193 = "images/Render1193.webp"
image bg render1194 = "images/Render1194.webp"
image bg render1195 = "images/Render1195.webp"
image bg render1196 = "images/Render1196.webp"
image bg render1197 = "images/Render1197.webp"
image bg render1198 = "images/Render1198.webp"
image bg render1199 = "images/Render1199.webp"
image bg render1200 = "images/Render1200.webp"

image bg render1201 = "images/Render1201.webp"
image bg render1202 = "images/Render1202.webp"
image bg render1203 = "images/Render1203.webp"
image bg render1204 = "images/Render1204.webp"
image bg render1205 = "images/Render1205.webp"
image bg render1206 = "images/Render1206.webp"
image bg render1207 = "images/Render1207.webp"
image bg render1208 = "images/Render1208.webp"
image bg render1209 = "images/Render1209.webp"
image bg render1210 = "images/Render1210.webp"
image bg render1211 = "images/Render1211.webp"
image bg render1212 = "images/Render1212.webp"
image bg render1213 = "images/Render1213.webp"
image bg render1214 = "images/Render1214.webp"
image bg render1215 = "images/Render1215.webp"
image bg render1216 = "images/Render1216.webp"
image bg render1217 = "images/Render1217.webp"
image bg render1218 = "images/Render1218.webp"
image bg render1219 = "images/Render1219.webp"
image bg render1220 = "images/Render1220.webp"
image bg render1221 = "images/Render1221.webp"
image bg render1222 = "images/Render1222.webp"
image bg render1223 = "images/Render1223.webp"
image bg render1224 = "images/Render1224.webp"
image bg render1225 = "images/Render1225.webp"
image bg render1226 = "images/Render1226.webp"
image bg render1227 = "images/Render1227.webp"
image bg render1228 = "images/Render1228.webp"
image bg render1229 = "images/Render1229.webp"
image bg render1230 = "images/Render1230.webp"
image bg render1231 = "images/Render1231.webp"
image bg render1232 = "images/Render1232.webp"
image bg render1233 = "images/Render1233.webp"
image bg render1234 = "images/Render1234.webp"
image bg render1235 = "images/Render1235.webp"
image bg render1236 = "images/Render1236.webp"
image bg render1237 = "images/Render1237.webp"
image bg render1238 = "images/Render1238.webp"
image bg render1239 = "images/Render1239.webp"
image bg render1240 = "images/Render1240.webp"
image bg render1241 = "images/Render1241.webp"
image bg render1242 = "images/Render1242.webp"
image bg render1243 = "images/Render1243.webp"
image bg render1244 = "images/Render1244.webp"
image bg render1245 = "images/Render1245.webp"
image bg render1246 = "images/Render1246.webp"
image bg render1247 = "images/Render1247.webp"
image bg render1248 = "images/Render1248.webp"
image bg render1249 = "images/Render1249.webp"
image bg render1250 = "images/Render1250.webp"

image bg render1251 = "images/Render1251.webp"
image bg render1252 = "images/Render1252.webp"
image bg render1253 = "images/Render1253.webp"
image bg render1254 = "images/Render1254.webp"
image bg render1255 = "images/Render1255.webp"
image bg render1256 = "images/Render1256.webp"
image bg render1257 = "images/Render1257.webp"
image bg render1258 = "images/Render1258.webp"
image bg render1259 = "images/Render1259.webp"
image bg render1260 = "images/Render1260.webp"
image bg render1261 = "images/Render1261.webp"
image bg render1262 = "images/Render1262.webp"
image bg render1263 = "images/Render1263.webp"
image bg render1264 = "images/Render1264.webp"
image bg render1265 = "images/Render1265.webp"
image bg render1266 = "images/Render1266.webp"
image bg render1267 = "images/Render1267.webp"
image bg render1268 = "images/Render1268.webp"
image bg render1269 = "images/Render1269.webp"
image bg render1270 = "images/Render1270.webp"
image bg render1271 = "images/Render1271.webp"
image bg render1272 = "images/Render1272.webp"
image bg render1273 = "images/Render1273.webp"
image bg render1274 = "images/Render1274.webp"
image bg render1275 = "images/Render1275.webp"
image bg render1276 = "images/Render1276.webp"
image bg render1277 = "images/Render1277.webp"
image bg render1278 = "images/Render1278.webp"
image bg render1279 = "images/Render1279.webp"
image bg render1280 = "images/Render1280.webp"
image bg render1281 = "images/Render1281.webp"
image bg render1282 = "images/Render1282.webp"
image bg render1283 = "images/Render1283.webp"
image bg render1284 = "images/Render1284.webp"
image bg render1285 = "images/Render1285.webp"
image bg render1286 = "images/Render1286.webp"
image bg render1287 = "images/Render1287.webp"
image bg render1288 = "images/Render1288.webp"
image bg render1289 = "images/Render1289.webp"
image bg render1290 = "images/Render1290.webp"
image bg render1291 = "images/Render1291.webp"
image bg render1292 = "images/Render1292.webp"
image bg render1293 = "images/Render1293.webp"
image bg render1294 = "images/Render1294.webp"
image bg render1295 = "images/Render1295.webp"
image bg render1296 = "images/Render1296.webp"
image bg render1297 = "images/Render1297.webp"
image bg render1298 = "images/Render1298.webp"
image bg render1299 = "images/Render1299.webp"
image bg render1300 = "images/Render1300.webp"

image bg render1301 = "images/Render1301.webp"
image bg render1302 = "images/Render1302.webp"
image bg render1303 = "images/Render1303.webp"
image bg render1304 = "images/Render1304.webp"
image bg render1305 = "images/Render1305.webp"
image bg render1306 = "images/Render1306.webp"
image bg render1307 = "images/Render1307.webp"
image bg render1308 = "images/Render1308.webp"
image bg render1309 = "images/Render1309.webp"
image bg render1310 = "images/Render1310.webp"
image bg render1311 = "images/Render1311.webp"
image bg render1312 = "images/Render1312.webp"
image bg render1313 = "images/Render1313.webp"
image bg render1314 = "images/Render1314.webp"
image bg render1315 = "images/Render1315.webp"
image bg render1316 = "images/Render1316.webp"
image bg render1317 = "images/Render1317.webp"
image bg render1318 = "images/Render1318.webp"
image bg render1319 = "images/Render1319.webp"
image bg render1320 = "images/Render1320.webp"
image bg render1321 = "images/Render1321.webp"
image bg render1322 = "images/Render1322.webp"
image bg render1323 = "images/Render1323.webp"
image bg render1324 = "images/Render1324.webp"
image bg render1325 = "images/Render1325.webp"
image bg render1326 = "images/Render1326.webp"
image bg render1327 = "images/Render1327.webp"
image bg render1328 = "images/Render1328.webp"
image bg render1329 = "images/Render1329.webp"
image bg render1330 = "images/Render1330.webp"
image bg render1331 = "images/Render1331.webp"
image bg render1332 = "images/Render1332.webp"
image bg render1333 = "images/Render1333.webp"
image bg render1334 = "images/Render1334.webp"
image bg render1335 = "images/Render1335.webp"
image bg render1336 = "images/Render1336.webp"
image bg render1337 = "images/Render1337.webp"
image bg render1338 = "images/Render1338.webp"
image bg render1339 = "images/Render1339.webp"
image bg render1340 = "images/Render1340.webp"
image bg render1341 = "images/Render1341.webp"
image bg render1342 = "images/Render1342.webp"
image bg render1343 = "images/Render1343.webp"
image bg render1344 = "images/Render1344.webp"
image bg render1345 = "images/Render1345.webp"
image bg render1346 = "images/Render1346.webp"
image bg render1347 = "images/Render1347.webp"
image bg render1348 = "images/Render1348.webp"
image bg render1349 = "images/Render1349.webp"
image bg render1350 = "images/Render1350.webp"

image bg render1351 = "images/Render1351.webp"
image bg render1352 = "images/Render1352.webp"
image bg render1353 = "images/Render1353.webp"
image bg render1354 = "images/Render1354.webp"
image bg render1355 = "images/Render1355.webp"
image bg render1356 = "images/Render1356.webp"
image bg render1357 = "images/Render1357.webp"
image bg render1358 = "images/Render1358.webp"
image bg render1359 = "images/Render1359.webp"
image bg render1360 = "images/Render1360.webp"
image bg render1361 = "images/Render1361.webp"
image bg render1362 = "images/Render1362.webp"
image bg render1363 = "images/Render1363.webp"
image bg render1364 = "images/Render1364.webp"
image bg render1365 = "images/Render1365.webp"
image bg render1366 = "images/Render1366.webp"
image bg render1367 = "images/Render1367.webp"
image bg render1368 = "images/Render1368.webp"
image bg render1369 = "images/Render1369.webp"
image bg render1370 = "images/Render1370.webp"
image bg render1371 = "images/Render1371.webp"
image bg render1372 = "images/Render1372.webp"
image bg render1373 = "images/Render1373.webp"
image bg render1374 = "images/Render1374.webp"
image bg render1375 = "images/Render1375.webp"
image bg render1376 = "images/Render1376.webp"
image bg render1377 = "images/Render1377.webp"
image bg render1378 = "images/Render1378.webp"
image bg render1379 = "images/Render1379.webp"
image bg render1380 = "images/Render1380.webp"
image bg render1381 = "images/Render1381.webp"
image bg render1382 = "images/Render1382.webp"
image bg render1383 = "images/Render1383.webp"
image bg render1384 = "images/Render1384.webp"
image bg render1385 = "images/Render1385.webp"
image bg render1386 = "images/Render1386.webp"
image bg render1387 = "images/Render1387.webp"
image bg render1388 = "images/Render1388.webp"
image bg render1389 = "images/Render1389.webp"
image bg render1390 = "images/Render1390.webp"
image bg render1391 = "images/Render1391.webp"
image bg render1392 = "images/Render1392.webp"
image bg render1393 = "images/Render1393.webp"
image bg render1394 = "images/Render1394.webp"
image bg render1395 = "images/Render1395.webp"
image bg render1396 = "images/Render1396.webp"
image bg render1397 = "images/Render1397.webp"
image bg render1398 = "images/Render1398.webp"
image bg render1399 = "images/Render1399.webp"
image bg render1400 = "images/Render1400.webp"
image bg render1401 = "images/Render1401.webp"
image bg render1402 = "images/Render1402.webp"
image bg render1402 = "images/Render1402.webp"
image bg render1403 = "images/Render1403.webp"
image bg render1404 = "images/Render1404.webp"
image bg render1405 = "images/Render1405.webp"
image bg render1406 = "images/Render1406.webp"
image bg render1407 = "images/Render1407.webp"
image bg render1408 = "images/Render1408.webp"
image bg render1409 = "images/Render1409.webp"
image bg render1410 = "images/Render1410.webp"
image bg render1411 = "images/Render1411.webp"
image bg render1412 = "images/Render1412.webp"
image bg render1413 = "images/Render1413.webp"
image bg render1414 = "images/Render1414.webp"
image bg render1415 = "images/Render1415.webp"
image bg render1416 = "images/Render1416.webp"
image bg render1417 = "images/Render1417.webp"
image bg render1418 = "images/Render1418.webp"
image bg render1419 = "images/Render1419.webp"
image bg render1420 = "images/Render1420.webp"
image bg render1421 = "images/Render1421.webp"
image bg render1422 = "images/Render1422.webp"
image bg render1423 = "images/Render1423.webp"
image bg render1424 = "images/Render1424.webp"
image bg render1425 = "images/Render1425.webp"
image bg render1426 = "images/Render1426.webp"
image bg render1427 = "images/Render1427.webp"
image bg render1428 = "images/Render1428.webp"
image bg render1429 = "images/Render1429.webp"
image bg render1430 = "images/Render1430.webp"
image bg render1431 = "images/Render1431.webp"
image bg render1432 = "images/Render1432.webp"
image bg render1433 = "images/Render1433.webp"
image bg render1434 = "images/Render1434.webp"
image bg render1435 = "images/Render1435.webp"
image bg render1436 = "images/Render1436.webp"
image bg render1437 = "images/Render1437.webp"
image bg render1438 = "images/Render1438.webp"
image bg render1439 = "images/Render1439.webp"
image bg render1440 = "images/Render1440.webp"
image bg render1441 = "images/Render1441.webp"
image bg render1442 = "images/Render1442.webp"
image bg render1443 = "images/Render1443.webp"
image bg render1444 = "images/Render1444.webp"
image bg render1445 = "images/Render1445.webp"
image bg render1446 = "images/Render1446.webp"
image bg render1447 = "images/Render1447.webp"
image bg render1448 = "images/Render1448.webp"
image bg render1449 = "images/Render1449.webp"
image bg render1450 = "images/Render1450.webp"
image bg render1451 = "images/Render1451.webp"
image bg render1452 = "images/Render1452.webp"
image bg render1453 = "images/Render1453.webp"
image bg render1454 = "images/Render1454.webp"
image bg render1455 = "images/Render1455.webp"
image bg render1456 = "images/Render1456.webp"
image bg render1457 = "images/Render1457.webp"
image bg render1458 = "images/Render1458.webp"
image bg render1459 = "images/Render1459.webp"
image bg render1460 = "images/Render1460.webp"
image bg render1461 = "images/Render1461.webp"
image bg render1462 = "images/Render1462.webp"
image bg render1463 = "images/Render1463.webp"
image bg render1464 = "images/Render1464.webp"
image bg render1465 = "images/Render1465.webp"
image bg render1466 = "images/Render1466.webp"
image bg render1467 = "images/Render1467.webp"
image bg render1468 = "images/Render1468.webp"
image bg render1469 = "images/Render1469.webp"
image bg render1470 = "images/Render1470.webp"
image bg render1471 = "images/Render1471.webp"
image bg render1472 = "images/Render1472.webp"
image bg render1473 = "images/Render1473.webp"
image bg render1474 = "images/Render1474.webp"
image bg render1475 = "images/Render1475.webp"
image bg render1476 = "images/Render1476.webp"
image bg render1477 = "images/Render1477.webp"
image bg render1478 = "images/Render1478.webp"
image bg render1479 = "images/Render1479.webp"
image bg render1480 = "images/Render1480.webp"
image bg render1481 = "images/Render1481.webp"
image bg render1482 = "images/Render1482.webp"
image bg render1483 = "images/Render1483.webp"
image bg render1484 = "images/Render1484.webp"
image bg render1485 = "images/Render1485.webp"
image bg render1486 = "images/Render1486.webp"
image bg render1487 = "images/Render1487.webp"
image bg render1488 = "images/Render1488.webp"
image bg render1489 = "images/Render1489.webp"
image bg render1490 = "images/Render1490.webp"
image bg render1491 = "images/Render1491.webp"
image bg render1492 = "images/Render1492.webp"
image bg render1493 = "images/Render1493.webp"
image bg render1494 = "images/Render1494.webp"
image bg render1495 = "images/Render1495.webp"
image bg render1496 = "images/Render1496.webp"
image bg render1497 = "images/Render1497.webp"
image bg render1498 = "images/Render1498.webp"
image bg render1499 = "images/Render1499.webp"
image bg render1500 = "images/Render1500.webp"
image bg render1501 = "images/Render1501.webp"
image bg render1502 = "images/Render1502.webp"
image bg render1503 = "images/Render1503.webp"
image bg render1504 = "images/Render1504.webp"
image bg render1505 = "images/Render1505.webp"
image bg render1506 = "images/Render1506.webp"
image bg render1507 = "images/Render1507.webp"
image bg render1508 = "images/Render1508.webp"
image bg render1509 = "images/Render1509.webp"
image bg render1510 = "images/Render1510.webp"
image bg render1511 = "images/Render1511.webp"
image bg render1512 = "images/Render1512.webp"
image bg render1513 = "images/Render1513.webp"
image bg render1514 = "images/Render1514.webp"
image bg render1515 = "images/Render1515.webp"
image bg render1516 = "images/Render1516.webp"
image bg render1517 = "images/Render1517.webp"
image bg render1518 = "images/Render1518.webp"
image bg render1519 = "images/Render1519.webp"
image bg render1520 = "images/Render1520.webp"
image bg render1521 = "images/Render1521.webp"
image bg render1522 = "images/Render1522.webp"
image bg render1523 = "images/Render1523.webp"
image bg render1524 = "images/Render1524.webp"
image bg render1525 = "images/Render1525.webp"
image bg render1526 = "images/Render1526.webp"
image bg render1527 = "images/Render1527.webp"
image bg render1528 = "images/Render1528.webp"
image bg render1529 = "images/Render1529.webp"
image bg render1530 = "images/Render1530.webp"
image bg render1531 = "images/Render1531.webp"
image bg render1532 = "images/Render1532.webp"
image bg render1533 = "images/Render1533.webp"
image bg render1534 = "images/Render1534.webp"
image bg render1535 = "images/Render1535.webp"
image bg render1536 = "images/Render1536.webp"
image bg render1537 = "images/Render1537.webp"
image bg render1538 = "images/Render1538.webp"
image bg render1539 = "images/Render1539.webp"
image bg render1540 = "images/Render1540.webp"
image bg render1541 = "images/Render1541.webp"
image bg render1542 = "images/Render1542.webp"
image bg render1543 = "images/Render1543.webp"
image bg render1544 = "images/Render1544.webp"
image bg render1545 = "images/Render1545.webp"
image bg render1546 = "images/Render1546.webp"
image bg render1547 = "images/Render1547.webp"
image bg render1548 = "images/Render1548.webp"
image bg render1549 = "images/Render1549.webp"
image bg render1550 = "images/Render1550.webp"
image bg render1551 = "images/Render1551.webp"
image bg render1552 = "images/Render1552.webp"
image bg render1553 = "images/Render1553.webp"
image bg render1554 = "images/Render1554.webp"
image bg render1555 = "images/Render1555.webp"
image bg render1556 = "images/Render1556.webp"
image bg render1557 = "images/Render1557.webp"
image bg render1558 = "images/Render1558.webp"
image bg render1559 = "images/Render1559.webp"
image bg render1560 = "images/Render1560.webp"
image bg render1561 = "images/Render1561.webp"
image bg render1562 = "images/Render1562.webp"
image bg render1563 = "images/Render1563.webp"
image bg render1564 = "images/Render1564.webp"
image bg render1565 = "images/Render1565.webp"
image bg render1566 = "images/Render1566.webp"
image bg render1567 = "images/Render1567.webp"
image bg render1568 = "images/Render1568.webp"
image bg render1569 = "images/Render1569.webp"
image bg render1570 = "images/Render1570.webp"
image bg render1571 = "images/Render1571.webp"
image bg render1572 = "images/Render1572.webp"
image bg render1573 = "images/Render1573.webp"
image bg render1574 = "images/Render1574.webp"
image bg render1575 = "images/Render1575.webp"
image bg render1576 = "images/Render1576.webp"
image bg render1577 = "images/Render1577.webp"
image bg render1578 = "images/Render1578.webp"
image bg render1579 = "images/Render1579.webp"
image bg render1580 = "images/Render1580.webp"
image bg render1581 = "images/Render1581.webp"
image bg render1582 = "images/Render1582.webp"
image bg render1583 = "images/Render1583.webp"
image bg render1584 = "images/Render1584.webp"
image bg render1585 = "images/Render1585.webp"
image bg render1586 = "images/Render1586.webp"
image bg render1587 = "images/Render1587.webp"
image bg render1588 = "images/Render1588.webp"
image bg render1589 = "images/Render1589.webp"
image bg render1590 = "images/Render1590.webp"
image bg render1591 = "images/Render1591.webp"
image bg render1592 = "images/Render1592.webp"
image bg render1593 = "images/Render1593.webp"
image bg render1594 = "images/Render1594.webp"
image bg render1595 = "images/Render1595.webp"
image bg render1596 = "images/Render1596.webp"
image bg render1597 = "images/Render1597.webp"
image bg render1598 = "images/Render1598.webp"
image bg render1599 = "images/Render1599.webp"
image bg render1600 = "images/Render1600.webp"
image bg render1601 = "images/Render1601.webp"
image bg render1602 = "images/Render1602.webp"
image bg render1603 = "images/Render1603.webp"
image bg render1604 = "images/Render1604.webp"
image bg render1605 = "images/Render1605.webp"
image bg render1606 = "images/Render1606.webp"
image bg render1607 = "images/Render1607.webp"
image bg render1608 = "images/Render1608.webp"
image bg render1609 = "images/Render1609.webp"
image bg render1610 = "images/Render1610.webp"
image bg render1611 = "images/Render1611.webp"
image bg render1612 = "images/Render1612.webp"
image bg render1613 = "images/Render1613.webp"
image bg render1614 = "images/Render1614.webp"
image bg render1615 = "images/Render1615.webp"
image bg render1616 = "images/Render1616.webp"
image bg render1617 = "images/Render1617.webp"
image bg render1618 = "images/Render1618.webp"
image bg render1619 = "images/Render1619.webp"
image bg render1620 = "images/Render1620.webp"
image bg render1621 = "images/Render1621.webp"
image bg render1622 = "images/Render1622.webp"
image bg render1623 = "images/Render1623.webp"
image bg render1624 = "images/Render1624.webp"
image bg render1625 = "images/Render1625.webp"
image bg render1626 = "images/Render1626.webp"
image bg render1627 = "images/Render1627.webp"
image bg render1628 = "images/Render1628.webp"
image bg render1629 = "images/Render1629.webp"
image bg render1630 = "images/Render1630.webp"
image bg render1631 = "images/Render1631.webp"
image bg render1632 = "images/Render1632.webp"
image bg render1633 = "images/Render1633.webp"
image bg render1634 = "images/Render1634.webp"
image bg render1635 = "images/Render1635.webp"
image bg render1636 = "images/Render1636.webp"
image bg render1637 = "images/Render1637.webp"
image bg render1638 = "images/Render1638.webp"
image bg render1639 = "images/Render1639.webp"
image bg render1640 = "images/Render1640.webp"
image bg render1641 = "images/Render1641.webp"
image bg render1642 = "images/Render1642.webp"
image bg render1643 = "images/Render1643.webp"
image bg render1644 = "images/Render1644.webp"
image bg render1645 = "images/Render1645.webp"
image bg render1646 = "images/Render1646.webp"
image bg render1647 = "images/Render1647.webp"
image bg render1648 = "images/Render1648.webp"
image bg render1649 = "images/Render1649.webp"
image bg render1650 = "images/Render1650.webp"
image bg render1651 = "images/Render1651.webp"
image bg render1652 = "images/Render1652.webp"
image bg render1653 = "images/Render1653.webp"
image bg render1654 = "images/Render1654.webp"
image bg render1655 = "images/Render1655.webp"
image bg render1656 = "images/Render1656.webp"
image bg render1657 = "images/Render1657.webp"
image bg render1658 = "images/Render1658.webp"
image bg render1659 = "images/Render1659.webp"
image bg render1660 = "images/Render1660.webp"
image bg render1661 = "images/Render1661.webp"
image bg render1662 = "images/Render1662.webp"
image bg render1663 = "images/Render1663.webp"
image bg render1664 = "images/Render1664.webp"
image bg render1665 = "images/Render1665.webp"
image bg render1666 = "images/Render1666.webp"
image bg render1667 = "images/Render1667.webp"
image bg render1668 = "images/Render1668.webp"
image bg render1669 = "images/Render1669.webp"

image bg render1670 = "images/Render1670.webp"
image bg render1671 = "images/Render1671.webp"
image bg render1672 = "images/Render1672.webp"
image bg render1673 = "images/Render1673.webp"
image bg render1673 = "images/Render1673.webp"
image bg render1673 = "images/Render1673.webp"
image bg render1675 = "images/Render1675.webp"
image bg render1676 = "images/Render1676.webp"
image bg render1677 = "images/Render1677.webp"
image bg render1678 = "images/Render1678.webp"
image bg render1679 = "images/Render1679.webp"
image bg render1680 = "images/Render1680.webp"
image bg render1681 = "images/Render1681.webp"
image bg render1682 = "images/Render1682.webp"
image bg render1683 = "images/Render1683.webp"
image bg render1684 = "images/Render1684.webp"
image bg render1685 = "images/Render1685.webp"
image bg render1686 = "images/Render1686.webp"
image bg render1687 = "images/Render1687.webp"
image bg render1688 = "images/Render1688.webp"
image bg render1689 = "images/Render1689.webp"
image bg render1690 = "images/Render1690.webp"
image bg render1691 = "images/Render1691.webp"
image bg render1692 = "images/Render1692.webp"
image bg render1693 = "images/Render1693.webp"
image bg render1694 = "images/Render1694.webp"
image bg render1695 = "images/Render1695.webp"

image bg render1695 = "images/Render1695.webp"
image bg render1696 = "images/Render1696.webp"
image bg render1697 = "images/Render1697.webp"
image bg render1698 = "images/Render1698.webp"
image bg render1699 = "images/Render1699.webp"
image bg render1700 = "images/Render1700.webp"
image bg render1701 = "images/Render1701.webp"
image bg render1702 = "images/Render1702.webp"
image bg render1703 = "images/Render1703.webp"
image bg render1704 = "images/Render1704.webp"
image bg render1705 = "images/Render1705.webp"
image bg render1706 = "images/Render1706.webp"
image bg render1707 = "images/Render1707.webp"
image bg render1708 = "images/Render1708.webp"
image bg render1709 = "images/Render1709.webp"
image bg render1710 = "images/Render1710.webp"
image bg render1711 = "images/Render1711.webp"
image bg render1712 = "images/Render1712.webp"
image bg render1713 = "images/Render1713.webp"
image bg render1714 = "images/Render1714.webp"
image bg render1715 = "images/Render1715.webp"
image bg render1716 = "images/Render1716.webp"
image bg render1717 = "images/Render1717.webp"
image bg render1718 = "images/Render1718.webp"
image bg render1719 = "images/Render1719.webp"
image bg render1720 = "images/Render1720.webp"
image bg render1721 = "images/Render1721.webp"
image bg render1722 = "images/Render1722.webp"
image bg render1723 = "images/Render1723.webp"
image bg render1724 = "images/Render1724.webp"
image bg render1725 = "images/Render1725.webp"
image bg render1726 = "images/Render1726.webp"
image bg render1727 = "images/Render1727.webp"
image bg render1728 = "images/Render1728.webp"
image bg render1729 = "images/Render1729.webp"
image bg render1730 = "images/Render1730.webp"
image bg render1731 = "images/Render1731.webp"
image bg render1732 = "images/Render1732.webp"
image bg render1733 = "images/Render1733.webp"
image bg render1734 = "images/Render1734.webp"
image bg render1735 = "images/Render1735.webp"
image bg render1736 = "images/Render1736.webp"
image bg render1737 = "images/Render1737.webp"
image bg render1738 = "images/Render1738.webp"
image bg render1739 = "images/Render1739.webp"
image bg render1740 = "images/Render1740.webp"
image bg render1741 = "images/Render1741.webp"
image bg render1742 = "images/Render1742.webp"
image bg render1743 = "images/Render1743.webp"
image bg render1744 = "images/Render1744.webp"
image bg render1745 = "images/Render1745.webp"
image bg render1746 = "images/Render1746.webp"
image bg render1747 = "images/Render1747.webp"
image bg render1748 = "images/Render1748.webp"
image bg render1749 = "images/Render1749.webp"
image bg render1750 = "images/Render1750.webp"
image bg render1751 = "images/Render1751.webp"
image bg render1752 = "images/Render1752.webp"
image bg render1753 = "images/Render1753.webp"
image bg render1754 = "images/Render1754.webp"
image bg render1755 = "images/Render1755.webp"
image bg render1756 = "images/Render1756.webp"
image bg render1757 = "images/Render1757.webp"
image bg render1758 = "images/Render1758.webp"
image bg render1759 = "images/Render1759.webp"
image bg render1760 = "images/Render1760.webp"
image bg render1761 = "images/Render1761.webp"
image bg render1762 = "images/Render1762.webp"
image bg render1763 = "images/Render1763.webp"
image bg render1764 = "images/Render1764.webp"
image bg render1765 = "images/Render1765.webp"
image bg render1766 = "images/Render1766.webp"
image bg render1767 = "images/Render1767.webp"
image bg render1768 = "images/Render1768.webp"
image bg render1769 = "images/Render1769.webp"
image bg render1770 = "images/Render1770.webp"
image bg render1771 = "images/Render1771.webp"
image bg render1772 = "images/Render1772.webp"
image bg render1773 = "images/Render1773.webp"
image bg render1774 = "images/Render1774.webp"
image bg render1775 = "images/Render1775.webp"
image bg render1776 = "images/Render1776.webp"
image bg render1777 = "images/Render1777.webp"
image bg render1778 = "images/Render1778.webp"
image bg render1779 = "images/Render1779.webp"
image bg render1780 = "images/Render1780.webp"
image bg render1781 = "images/Render1781.webp"
image bg render1782 = "images/Render1782.webp"
image bg render1783 = "images/Render1783.webp"
image bg render1784 = "images/Render1784.webp"
image bg render1785 = "images/Render1785.webp"
image bg render1786 = "images/Render1786.webp"
image bg render1787 = "images/Render1787.webp"
image bg render1788 = "images/Render1788.webp"
image bg render1789 = "images/Render1789.webp"
image bg render1790 = "images/Render1790.webp"
image bg render1791 = "images/Render1791.webp"
image bg render1792 = "images/Render1792.webp"
image bg render1793 = "images/Render1793.webp"
image bg render1794 = "images/Render1794.webp"
image bg render1795 = "images/Render1795.webp"
image bg render1796 = "images/Render1796.webp"
image bg render1797 = "images/Render1797.webp"
image bg render1798 = "images/Render1798.webp"
image bg render1799 = "images/Render1799.webp"
image bg render1800 = "images/Render1800.webp"
image bg render1801 = "images/Render1801.webp"
image bg render1802 = "images/Render1802.webp"
image bg render1803 = "images/Render1803.webp"
image bg render1804 = "images/Render1804.webp"
image bg render1805 = "images/Render1805.webp"
image bg render1806 = "images/Render1806.webp"
image bg render1807 = "images/Render1807.webp"
image bg render1808 = "images/Render1808.webp"
image bg render1809 = "images/Render1809.webp"
image bg render1810 = "images/Render1810.webp"
image bg render1811 = "images/Render1811.webp"
image bg render1812 = "images/Render1812.webp"
image bg render1813 = "images/Render1813.webp"
image bg render1814 = "images/Render1814.webp"
image bg render1815 = "images/Render1815.webp"
image bg render1816 = "images/Render1816.webp"
image bg render1817 = "images/Render1817.webp"
image bg render1818 = "images/Render1818.webp"
image bg render1819 = "images/Render1819.webp"
image bg render1820 = "images/Render1820.webp"
image bg render1821 = "images/Render1821.webp"
image bg render1822 = "images/Render1822.webp"
image bg render1823 = "images/Render1823.webp"
image bg render1824 = "images/Render1824.webp"
image bg render1825 = "images/Render1825.webp"
image bg render1826 = "images/Render1826.webp"
image bg render1827 = "images/Render1827.webp"
image bg render1828 = "images/Render1828.webp"
image bg render1829 = "images/Render1829.webp"
image bg render1830 = "images/Render1830.webp"
image bg render1831 = "images/Render1831.webp"
image bg render1832 = "images/Render1832.webp"
image bg render1833 = "images/Render1833.webp"
image bg render1834 = "images/Render1834.webp"
image bg render1835 = "images/Render1835.webp"
image bg render1836 = "images/Render1836.webp"
image bg render1837 = "images/Render1837.webp"
image bg render1838 = "images/Render1838.webp"
image bg render1839 = "images/Render1839.webp"
image bg render1840 = "images/Render1840.webp"
image bg render1841 = "images/Render1841.webp"
image bg render1842 = "images/Render1842.webp"
image bg render1843 = "images/Render1843.webp"
image bg render1844 = "images/Render1844.webp"
image bg render1845 = "images/Render1845.webp"
image bg render1846 = "images/Render1846.webp"
image bg render1847 = "images/Render1847.webp"
image bg render1848 = "images/Render1848.webp"
image bg render1849 = "images/Render1849.webp"
image bg render1850 = "images/Render1850.webp"
image bg render1851 = "images/Render1851.webp"
image bg render1852 = "images/Render1852.webp"
image bg render1853 = "images/Render1853.webp"
image bg render1854 = "images/Render1854.webp"
image bg render1855 = "images/Render1855.webp"
image bg render1856 = "images/Render1856.webp"
image bg render1857 = "images/Render1857.webp"
image bg render1858 = "images/Render1858.webp"
image bg render1859 = "images/Render1859.webp"
image bg render1860 = "images/Render1860.webp"
image bg render1861 = "images/Render1861.webp"
image bg render1862 = "images/Render1862.webp"
image bg render1863 = "images/Render1863.webp"
image bg render1864 = "images/Render1864.webp"
image bg render1865 = "images/Render1865.webp"
image bg render1866 = "images/Render1866.webp"
image bg render1867 = "images/Render1867.webp"
image bg render1868 = "images/Render1868.webp"
image bg render1869 = "images/Render1869.webp"
image bg render1870 = "images/Render1870.webp"
image bg render1871 = "images/Render1871.webp"
image bg render1872 = "images/Render1872.webp"
image bg render1873 = "images/Render1873.webp"
image bg render1874 = "images/Render1874.webp"
image bg render1875 = "images/Render1875.webp"
image bg render1876 = "images/Render1876.webp"
image bg render1877 = "images/Render1877.webp"
image bg render1878 = "images/Render1878.webp"
image bg render1879 = "images/Render1879.webp"
image bg render1880 = "images/Render1880.webp"
image bg render1881 = "images/Render1881.webp"
image bg render1882 = "images/Render1882.webp"
image bg render1883 = "images/Render1883.webp"
image bg render1884 = "images/Render1884.webp"
image bg render1885 = "images/Render1885.webp"
image bg render1886 = "images/Render1886.webp"
image bg render1887 = "images/Render1887.webp"
image bg render1888 = "images/Render1888.webp"
image bg render1889 = "images/Render1889.webp"
image bg render1890 = "images/Render1890.webp"
image bg render1891 = "images/Render1891.webp"
image bg render1892 = "images/Render1892.webp"
image bg render1893 = "images/Render1893.webp"
image bg render1894 = "images/Render1894.webp"
image bg render1895 = "images/Render1895.webp"
image bg render1896 = "images/Render1896.webp"
image bg render1897 = "images/Render1897.webp"
image bg render1898 = "images/Render1898.webp"
image bg render1899 = "images/Render1899.webp"
image bg render1900 = "images/Render1900.webp"
image bg render1901 = "images/Render1901.webp"
image bg render1902 = "images/Render1902.webp"
image bg render1903 = "images/Render1903.webp"
image bg render1904 = "images/Render1904.webp"
image bg render1905 = "images/Render1905.webp"
image bg render1906 = "images/Render1906.webp"
image bg render1907 = "images/Render1907.webp"
image bg render1908 = "images/Render1908.webp"
image bg render1909 = "images/Render1909.webp"
image bg render1910 = "images/Render1910.webp"
image bg render1911 = "images/Render1911.webp"
image bg render1912 = "images/Render1912.webp"
image bg render1913 = "images/Render1913.webp"
image bg render1914 = "images/Render1914.webp"
image bg render1915 = "images/Render1915.webp"
image bg render1916 = "images/Render1916.webp"
image bg render1917 = "images/Render1917.webp"
image bg render1918 = "images/Render1918.webp"
image bg render1919 = "images/Render1919.webp"
image bg render1920 = "images/Render1920.webp"
image bg render1921 = "images/Render1921.webp"
image bg render1922 = "images/Render1922.webp"
image bg render1923 = "images/Render1923.webp"
image bg render1924 = "images/Render1924.webp"
image bg render1925 = "images/Render1925.webp"
image bg render1926 = "images/Render1926.webp"
image bg render1927 = "images/Render1927.webp"
image bg render1928 = "images/Render1928.webp"
image bg render1929 = "images/Render1929.webp"
image bg render1930 = "images/Render1930.webp"
image bg render1931 = "images/Render1931.webp"
image bg render1932 = "images/Render1932.webp"
image bg render1933 = "images/Render1933.webp"
image bg render1934 = "images/Render1934.webp"
image bg render1935 = "images/Render1935.webp"
image bg render1936 = "images/Render1936.webp"
image bg render1937 = "images/Render1937.webp"
image bg render1938 = "images/Render1938.webp"
image bg render1939 = "images/Render1939.webp"
image bg render1940 = "images/Render1940.webp"
image bg render1941 = "images/Render1941.webp"
image bg render1942 = "images/Render1942.webp"
image bg render1943 = "images/Render1943.webp"
image bg render1944 = "images/Render1944.webp"
image bg render1945 = "images/Render1945.webp"
image bg render1946 = "images/Render1946.webp"
image bg render1947 = "images/Render1947.webp"
image bg render1948 = "images/Render1948.webp"
image bg render1949 = "images/Render1949.webp"
image bg render1950 = "images/Render1950.webp"
image bg render1951 = "images/Render1951.webp"
image bg render1952 = "images/Render1952.webp"
image bg render1953 = "images/Render1953.webp"
image bg render1954 = "images/Render1954.webp"
image bg render1955 = "images/Render1955.webp"
image bg render1956 = "images/Render1956.webp"
image bg render1957 = "images/Render1957.webp"
image bg render1958 = "images/Render1958.webp"
image bg render1959 = "images/Render1959.webp"
image bg render1960 = "images/Render1960.webp"
image bg render1961 = "images/Render1961.webp"
image bg render1962 = "images/Render1962.webp"
image bg render1963 = "images/Render1963.webp"
image bg render1964 = "images/Render1964.webp"
image bg render1965 = "images/Render1965.webp"
image bg render1966 = "images/Render1966.webp"
image bg render1967 = "images/Render1967.webp"
image bg render1968 = "images/Render1968.webp"
image bg render1969 = "images/Render1969.webp"
image bg render1970 = "images/Render1970.webp"
image bg render1971 = "images/Render1971.webp"
image bg render1972 = "images/Render1972.webp"
image bg render1973 = "images/Render1973.webp"
image bg render1974 = "images/Render1974.webp"
image bg render1975 = "images/Render1975.webp"
image bg render1976 = "images/Render1976.webp"
image bg render1977 = "images/Render1977.webp"
image bg render1978 = "images/Render1978.webp"
image bg render1979 = "images/Render1979.webp"
image bg render1980 = "images/Render1980.webp"
image bg render1981 = "images/Render1981.webp"
image bg render1982 = "images/Render1982.webp"
image bg render1983 = "images/Render1983.webp"
image bg render1984 = "images/Render1984.webp"
image bg render1985 = "images/Render1985.webp"
image bg render1986 = "images/Render1986.webp"
image bg render1987 = "images/Render1987.webp"
image bg render1988 = "images/Render1988.webp"
image bg render1989 = "images/Render1989.webp"
image bg render1990 = "images/Render1990.webp"
image bg render1991 = "images/Render1991.webp"
image bg render1992 = "images/Render1992.webp"
image bg render1993 = "images/Render1993.webp"
image bg render1994 = "images/Render1994.webp"
image bg render1995 = "images/Render1995.webp"
image bg render1996 = "images/Render1996.webp"
image bg render1997 = "images/Render1997.webp"
image bg render1998 = "images/Render1998.webp"
image bg render1999 = "images/Render1999.webp"
image bg render2000 = "images/Render2000.webp"
image bg render2001 = "images/Render2001.webp"
image bg render2002 = "images/Render2002.webp"
image bg render2003 = "images/Render2003.webp"
image bg render2004 = "images/Render2004.webp"
image bg render2005 = "images/Render2005.webp"
image bg render2006 = "images/Render2006.webp"
image bg render2007 = "images/Render2007.webp"
image bg render2008 = "images/Render2008.webp"
image bg render2009 = "images/Render2009.webp"
image bg render2010 = "images/Render2010.webp"
image bg render2011 = "images/Render2011.webp"
image bg render2012 = "images/Render2012.webp"
image bg render2013 = "images/Render2013.webp"
image bg render2014 = "images/Render2014.webp"
image bg render2015 = "images/Render2015.webp"
image bg render2016 = "images/Render2016.webp"
image bg render2017 = "images/Render2017.webp"
image bg render2018 = "images/Render2018.webp"
image bg render2019 = "images/Render2019.webp"
image bg render2020 = "images/Render2020.webp"
image bg render2021 = "images/Render2021.webp"
image bg render2022 = "images/Render2022.webp"
image bg render2023 = "images/Render2023.webp"
image bg render2024 = "images/Render2024.webp"
image bg render2025 = "images/Render2025.webp"
image bg render2026 = "images/Render2026.webp"
image bg render2027 = "images/Render2027.webp"
image bg render2028 = "images/Render2028.webp"
image bg render2029 = "images/Render2029.webp"
image bg render2030 = "images/Render2030.webp"
image bg render2031 = "images/Render2031.webp"
image bg render2032 = "images/Render2032.webp"
image bg render2033 = "images/Render2033.webp"
image bg render2034 = "images/Render2034.webp"
image bg render2035 = "images/Render2035.webp"
image bg render2036 = "images/Render2036.webp"
image bg render2037 = "images/Render2037.webp"
image bg render2038 = "images/Render2038.webp"
image bg render2039 = "images/Render2039.webp"
image bg render2040 = "images/Render2040.webp"
image bg render2041 = "images/Render2041.webp"
image bg render2042 = "images/Render2042.webp"
image bg render2043 = "images/Render2043.webp"
image bg render2044 = "images/Render2044.webp"
image bg render2045 = "images/Render2045.webp"
image bg render2046 = "images/Render2046.webp"
image bg render2047 = "images/Render2047.webp"
image bg render2048 = "images/Render2048.webp"
image bg render2049 = "images/Render2049.webp"
image bg render2050 = "images/Render2050.webp"
image bg render2051 = "images/Render2051.webp"
image bg render2052 = "images/Render2052.webp"
image bg render2053 = "images/Render2053.webp"
image bg render2054 = "images/Render2054.webp"
image bg render2055 = "images/Render2055.webp"
image bg render2056 = "images/Render2056.webp"
image bg render2057 = "images/Render2057.webp"
image bg render2058 = "images/Render2058.webp"
image bg render2059 = "images/Render2059.webp"
image bg render2060 = "images/Render2060.webp"
image bg render2061 = "images/Render2061.webp"
image bg render2062 = "images/Render2062.webp"
image bg render2063 = "images/Render2063.webp"
image bg render2064 = "images/Render2064.webp"
image bg render2065 = "images/Render2065.webp"
image bg render2066 = "images/Render2066.webp"
image bg render2067 = "images/Render2067.webp"
image bg render2068 = "images/Render2068.webp"
image bg render2069 = "images/Render2069.webp"
image bg render2070 = "images/Render2070.webp"
image bg render2071 = "images/Render2071.webp"
image bg render2072 = "images/Render2072.webp"
image bg render2073 = "images/Render2073.webp"
image bg render2074 = "images/Render2074.webp"
image bg render2075 = "images/Render2075.webp"
image bg render2076 = "images/Render2076.webp"
image bg render2077 = "images/Render2077.webp"
image bg render2078 = "images/Render2078.webp"
image bg render2079 = "images/Render2079.webp"
image bg render2080 = "images/Render2080.webp"
image bg render2081 = "images/Render2081.webp"
image bg render2082 = "images/Render2082.webp"
image bg render2083 = "images/Render2083.webp"
image bg render2084 = "images/Render2084.webp"
image bg render2085 = "images/Render2085.webp"
image bg render2086 = "images/Render2086.webp"
image bg render2087 = "images/Render2087.webp"
image bg render2088 = "images/Render2088.webp"
image bg render2089 = "images/Render2089.webp"
image bg render2090 = "images/Render2090.webp"
image bg render2091 = "images/Render2091.webp"
image bg render2092 = "images/Render2092.webp"
image bg render2093 = "images/Render2093.webp"
image bg render2094 = "images/Render2094.webp"
image bg render2095 = "images/Render2095.webp"
image bg render2096 = "images/Render2096.webp"
image bg render2097 = "images/Render2097.webp"
image bg render2098 = "images/Render2098.webp"
image bg render2099 = "images/Render2099.webp"
image bg render2100 = "images/Render2100.webp"
image bg render2101 = "images/Render2101.webp"
image bg render2102 = "images/Render2102.webp"
image bg render2103 = "images/Render2103.webp"
image bg render2104 = "images/Render2104.webp"
image bg render2105 = "images/Render2105.webp"
image bg render2106 = "images/Render2106.webp"
image bg render2107 = "images/Render2107.webp"
image bg render2108 = "images/Render2108.webp"
image bg render2109 = "images/Render2109.webp"
image bg render2110 = "images/Render2110.webp"
image bg render2111 = "images/Render2111.webp"
image bg render2112 = "images/Render2112.webp"
image bg render2113 = "images/Render2113.webp"
image bg render2114 = "images/Render2114.webp"
image bg render2115 = "images/Render2115.webp"
image bg render2116 = "images/Render2116.webp"
image bg render2117 = "images/Render2117.webp"
image bg render2118 = "images/Render2118.webp"
image bg render2119 = "images/Render2119.webp"
image bg render2120 = "images/Render2120.webp"
image bg render2121 = "images/Render2121.webp"
image bg render2122 = "images/Render2122.webp"
image bg render2123 = "images/Render2123.webp"
image bg render2124 = "images/Render2124.webp"
image bg render2125 = "images/Render2125.webp"
image bg render2126 = "images/Render2126.webp"
image bg render2127 = "images/Render2127.webp"
image bg render2128 = "images/Render2128.webp"
image bg render2129 = "images/Render2129.webp"
image bg render2130 = "images/Render2130.webp"
image bg render2131 = "images/Render2131.webp"
image bg render2132 = "images/Render2132.webp"
image bg render2133 = "images/Render2133.webp"
image bg render2134 = "images/Render2134.webp"
image bg render2135 = "images/Render2135.webp"
image bg render2136 = "images/Render2136.webp"
image bg render2137 = "images/Render2137.webp"
image bg render2138 = "images/Render2138.webp"
image bg render2139 = "images/Render2139.webp"
image bg render2140 = "images/Render2140.webp"
image bg render2141 = "images/Render2141.webp"
image bg render2142 = "images/Render2142.webp"
image bg render2143 = "images/Render2143.webp"
image bg render2144 = "images/Render2144.webp"
image bg render2145 = "images/Render2145.webp"
image bg render2146 = "images/Render2146.webp"
image bg render2147 = "images/Render2147.webp"
image bg render2148 = "images/Render2148.webp"
image bg render2149 = "images/Render2149.webp"
image bg render2150 = "images/Render2150.webp"
image bg render2151 = "images/Render2151.webp"
image bg render2152 = "images/Render2152.webp"
image bg render2153 = "images/Render2153.webp"
image bg render2154 = "images/Render2154.webp"
image bg render2155 = "images/Render2155.webp"
image bg render2156 = "images/Render2156.webp"
image bg render2157 = "images/Render2157.webp"
image bg render2158 = "images/Render2158.webp"
image bg render2159 = "images/Render2159.webp"
image bg render2160 = "images/Render2160.webp"
image bg render2161 = "images/Render2161.webp"
image bg render2162 = "images/Render2162.webp"
image bg render2163 = "images/Render2163.webp"
image bg render2164 = "images/Render2164.webp"
image bg render2165 = "images/Render2165.webp"
image bg render2166 = "images/Render2166.webp"
image bg render2167 = "images/Render2167.webp"
image bg render2168 = "images/Render2168.webp"
image bg render2169 = "images/Render2169.webp"
image bg render2170 = "images/Render2170.webp"
image bg render2171 = "images/Render2171.webp"
image bg render2172 = "images/Render2172.webp"
image bg render2173 = "images/Render2173.webp"
image bg render2174 = "images/Render2174.webp"
image bg render2175 = "images/Render2175.webp"
image bg render2176 = "images/Render2176.webp"
image bg render2177 = "images/Render2177.webp"
image bg render2178 = "images/Render2178.webp"
image bg render2179 = "images/Render2179.webp"
image bg render2180 = "images/Render2180.webp"
image bg render2181 = "images/Render2181.webp"
image bg render2182 = "images/Render2182.webp"
image bg render2183 = "images/Render2183.webp"
image bg render2184 = "images/Render2184.webp"
image bg render2185 = "images/Render2185.webp"
image bg render2186 = "images/Render2186.webp"
image bg render2187 = "images/Render2187.webp"
image bg render2188 = "images/Render2188.webp"
image bg render2189 = "images/Render2189.webp"
image bg render2190 = "images/Render2190.webp"
image bg render2191 = "images/Render2191.webp"
image bg render2192 = "images/Render2192.webp"
image bg render2193 = "images/Render2193.webp"
image bg render2194 = "images/Render2194.webp"
image bg render2195 = "images/Render2195.webp"
image bg render2196 = "images/Render2196.webp"
image bg render2197 = "images/Render2197.webp"
image bg render2198 = "images/Render2198.webp"
image bg render2199 = "images/Render2199.webp"
image bg render2200 = "images/Render2200.webp"
image bg render2201 = "images/Render2201.webp"
image bg render2202 = "images/Render2202.webp"
image bg render2203 = "images/Render2203.webp"
image bg render2204 = "images/Render2204.webp"
image bg render2205 = "images/Render2205.webp"
image bg render2206 = "images/Render2206.webp"
image bg render2207 = "images/Render2207.webp"
image bg render2208 = "images/Render2208.webp"
image bg render2209 = "images/Render2209.webp"
image bg render2210 = "images/Render2210.webp"
image bg render2211 = "images/Render2211.webp"
image bg render2212 = "images/Render2212.webp"
image bg render2213 = "images/Render2213.webp"
image bg render2214 = "images/Render2214.webp"
image bg render2215 = "images/Render2215.webp"
image bg render2216 = "images/Render2216.webp"
image bg render2217 = "images/Render2217.webp"
image bg render2218 = "images/Render2218.webp"
image bg render2219 = "images/Render2219.webp"
image bg render2220 = "images/Render2220.webp"
image bg render2221 = "images/Render2221.webp"
image bg render2222 = "images/Render2222.webp"
image bg render2223 = "images/Render2223.webp"
image bg render2224 = "images/Render2224.webp"
image bg render2225 = "images/Render2225.webp"
image bg render2226 = "images/Render2226.webp"
image bg render2227 = "images/Render2227.webp"
image bg render2228 = "images/Render2228.webp"
image bg render2229 = "images/Render2229.webp"
image bg render2230 = "images/Render2230.webp"
image bg render2231 = "images/Render2231.webp"
image bg render2232 = "images/Render2232.webp"
image bg render2233 = "images/Render2233.webp"
image bg render2234 = "images/Render2234.webp"
image bg render2235 = "images/Render2235.webp"
image bg render2236 = "images/Render2236.webp"
image bg render2237 = "images/Render2237.webp"
image bg render2238 = "images/Render2238.webp"
image bg render2239 = "images/Render2239.webp"
image bg render2240 = "images/Render2240.webp"
image bg render2241 = "images/Render2241.webp"
image bg render2242 = "images/Render2242.webp"
image bg render2243 = "images/Render2243.webp"
image bg render2244 = "images/Render2244.webp"
image bg render2245 = "images/Render2245.webp"
image bg render2246 = "images/Render2246.webp"
image bg render2247 = "images/Render2247.webp"
image bg render2248 = "images/Render2248.webp"
image bg render2249 = "images/Render2249.webp"
image bg render2250 = "images/Render2250.webp"
image bg render2251 = "images/Render2251.webp"
image bg render2252 = "images/Render2252.webp"
image bg render2253 = "images/Render2253.webp"
image bg render2254 = "images/Render2254.webp"
image bg render2255 = "images/Render2255.webp"
image bg render2256 = "images/Render2256.webp"
image bg render2257 = "images/Render2257.webp"
image bg render2258 = "images/Render2258.webp"
image bg render2259 = "images/Render2259.webp"
image bg render2260 = "images/Render2260.webp"
image bg render2261 = "images/Render2261.webp"
image bg render2262 = "images/Render2262.webp"
image bg render2263 = "images/Render2263.webp"
image bg render2264 = "images/Render2264.webp"
image bg render2265 = "images/Render2265.webp"
image bg render2266 = "images/Render2266.webp"
image bg render2267 = "images/Render2267.webp"
image bg render2268 = "images/Render2268.webp"
image bg render2269 = "images/Render2269.webp"
image bg render2270 = "images/Render2270.webp"
image bg render2271 = "images/Render2271.webp"
image bg render2272 = "images/Render2272.webp"
image bg render2273 = "images/Render2273.webp"
image bg render2274 = "images/Render2274.webp"
image bg render2275 = "images/Render2275.webp"
image bg render2276 = "images/Render2276.webp"
image bg render2277 = "images/Render2277.webp"
image bg render2278 = "images/Render2278.webp"
image bg render2279 = "images/Render2279.webp"
image bg render2280 = "images/Render2280.webp"
image bg render2281 = "images/Render2281.webp"
image bg render2282 = "images/Render2282.webp"
image bg render2283 = "images/Render2283.webp"
image bg render2284 = "images/Render2284.webp"
image bg render2285 = "images/Render2285.webp"
image bg render2286 = "images/Render2286.webp"
image bg render2287 = "images/Render2287.webp"
image bg render2288 = "images/Render2288.webp"
image bg render2289 = "images/Render2289.webp"
image bg render2290 = "images/Render2290.webp"
image bg render2291 = "images/Render2291.webp"
image bg render2292 = "images/Render2292.webp"
image bg render2293 = "images/Render2293.webp"
image bg render2294 = "images/Render2294.webp"
image bg render2295 = "images/Render2295.webp"
image bg render2296 = "images/Render2296.webp"
image bg render2297 = "images/Render2297.webp"
image bg render2298 = "images/Render2298.webp"
image bg render2299 = "images/Render2299.webp"
image bg render2300 = "images/Render2300.webp"
image bg render2301 = "images/Render2301.webp"
image bg render2302 = "images/Render2302.webp"
image bg render2303 = "images/Render2303.webp"
image bg render2304 = "images/Render2304.webp"
image bg render2305 = "images/Render2305.webp"
image bg render2306 = "images/Render2306.webp"
image bg render2307 = "images/Render2307.webp"
image bg render2308 = "images/Render2308.webp"
image bg render2309 = "images/Render2309.webp"
image bg render2310 = "images/Render2310.webp"
image bg render2311 = "images/Render2311.webp"
image bg render2312 = "images/Render2312.webp"
image bg render2313 = "images/Render2313.webp"
image bg render2314 = "images/Render2314.webp"
image bg render2315 = "images/Render2315.webp"
image bg render2316 = "images/Render2316.webp"
image bg render2317 = "images/Render2317.webp"
image bg render2318 = "images/Render2318.webp"
image bg render2319 = "images/Render2319.webp"
image bg render2320 = "images/Render2320.webp"
image bg render2321 = "images/Render2321.webp"
image bg render2322 = "images/Render2322.webp"
image bg render2323 = "images/Render2323.webp"
image bg render2324 = "images/Render2324.webp"
image bg render2325 = "images/Render2325.webp"
image bg render2326 = "images/Render2326.webp"
image bg render2327 = "images/Render2327.webp"
image bg render2328 = "images/Render2328.webp"
image bg render2329 = "images/Render2329.webp"
image bg render2330 = "images/Render2330.webp"
image bg render2331 = "images/Render2331.webp"
image bg render2332 = "images/Render2332.webp"
image bg render2333 = "images/Render2333.webp"
image bg render2334 = "images/Render2334.webp"
image bg render2335 = "images/Render2335.webp"
image bg render2336 = "images/Render2336.webp"
image bg render2337 = "images/Render2337.webp"
image bg render2338 = "images/Render2338.webp"
image bg render2339 = "images/Render2339.webp"
image bg render2340 = "images/Render2340.webp"
image bg render2341 = "images/Render2341.webp"
image bg render2342 = "images/Render2342.webp"
image bg render2343 = "images/Render2343.webp"
image bg render2344 = "images/Render2344.webp"
image bg render2345 = "images/Render2345.webp"
image bg render2346 = "images/Render2346.webp"
image bg render2347 = "images/Render2347.webp"
image bg render2348 = "images/Render2348.webp"
image bg render2349 = "images/Render2349.webp"
image bg render2350 = "images/Render2350.webp"
image bg render2351 = "images/Render2351.webp"
image bg render2352 = "images/Render2352.webp"
image bg render2353 = "images/Render2353.webp"
image bg render2354 = "images/Render2354.webp"
image bg render2355 = "images/Render2355.webp"
image bg render2356 = "images/Render2356.webp"
image bg render2357 = "images/Render2357.webp"
image bg render2358 = "images/Render2358.webp"
image bg render2359 = "images/Render2359.webp"
image bg render2360 = "images/Render2360.webp"
image bg render2361 = "images/Render2361.webp"
image bg render2362 = "images/Render2362.webp"
image bg render2363 = "images/Render2363.webp"
image bg render2364 = "images/Render2364.webp"
image bg render2365 = "images/Render2365.webp"
image bg render2366 = "images/Render2366.webp"
image bg render2367 = "images/Render2367.webp"
image bg render2368 = "images/Render2368.webp"
image bg render2369 = "images/Render2369.webp"
image bg render2370 = "images/Render2370.webp"
image bg render2371 = "images/Render2371.webp"
image bg render2372 = "images/Render2372.webp"
image bg render2373 = "images/Render2373.webp"
image bg render2374 = "images/Render2374.webp"
image bg render2375 = "images/Render2375.webp"
image bg render2376 = "images/Render2376.webp"
image bg render2377 = "images/Render2377.webp"
image bg render2378 = "images/Render2378.webp"
image bg render2379 = "images/Render2379.webp"
image bg render2380 = "images/Render2380.webp"
image bg render2381 = "images/Render2381.webp"
image bg render2382 = "images/Render2382.webp"
image bg render2383 = "images/Render2383.webp"
image bg render2384 = "images/Render2384.webp"
image bg render2385 = "images/Render2385.webp"
image bg render2386 = "images/Render2386.webp"
image bg render2387 = "images/Render2387.webp"
image bg render2388 = "images/Render2388.webp"
image bg render2389 = "images/Render2389.webp"
image bg render2390 = "images/Render2390.webp"
image bg render2391 = "images/Render2391.webp"
image bg render2392 = "images/Render2392.webp"
image bg render2393 = "images/Render2393.webp"
image bg render2394 = "images/Render2394.webp"
image bg render2395 = "images/Render2395.webp"
image bg render2396 = "images/Render2396.webp"
image bg render2397 = "images/Render2397.webp"
image bg render2398 = "images/Render2398.webp"
image bg render2399 = "images/Render2399.webp"
image bg render2400 = "images/Render2400.webp"
image bg render2401 = "images/Render2401.webp"
image bg render2402 = "images/Render2402.webp"
image bg render2403 = "images/Render2403.webp"
image bg render2404 = "images/Render2404.webp"
image bg render2405 = "images/Render2405.webp"
image bg render2406 = "images/Render2406.webp"
image bg render2407 = "images/Render2407.webp"
image bg render2408 = "images/Render2408.webp"
image bg render2409 = "images/Render2409.webp"
image bg render2410 = "images/Render2410.webp"
image bg render2411 = "images/Render2411.webp"
image bg render2412 = "images/Render2412.webp"
image bg render2413 = "images/Render2413.webp"
image bg render2414 = "images/Render2414.webp"
image bg render2415 = "images/Render2415.webp"
image bg render2416 = "images/Render2416.webp"
image bg render2417 = "images/Render2417.webp"
image bg render2418 = "images/Render2418.webp"
image bg render2419 = "images/Render2419.webp"
image bg render2420 = "images/Render2420.webp"
image bg render2421 = "images/Render2421.webp"
image bg render2422 = "images/Render2422.webp"
image bg render2423 = "images/Render2423.webp"
image bg render2424 = "images/Render2424.webp"
image bg render2425 = "images/Render2425.webp"
image bg render2426 = "images/Render2426.webp"
image bg render2427 = "images/Render2427.webp"
image bg render2428 = "images/Render2428.webp"
image bg render2429 = "images/Render2429.webp"
image bg render2430 = "images/Render2430.webp"
image bg render2431 = "images/Render2431.webp"
image bg render2432 = "images/Render2432.webp"
image bg render2433 = "images/Render2433.webp"
image bg render2434 = "images/Render2434.webp"
image bg render2435 = "images/Render2435.webp"
image bg render2436 = "images/Render2436.webp"
image bg render2437 = "images/Render2437.webp"
image bg render2438 = "images/Render2438.webp"
image bg render2439 = "images/Render2439.webp"
image bg render2440 = "images/Render2440.webp"
image bg render2441 = "images/Render2441.webp"
image bg render2442 = "images/Render2442.webp"
image bg render2443 = "images/Render2443.webp"
image bg render2444 = "images/Render2444.webp"
image bg render2445 = "images/Render2445.webp"
image bg render2446 = "images/Render2446.webp"
image bg render2447 = "images/Render2447.webp"
image bg render2448 = "images/Render2448.webp"
image bg render2449 = "images/Render2449.webp"
image bg render2450 = "images/Render2450.webp"
image bg render2451 = "images/Render2451.webp"
image bg render2452 = "images/Render2452.webp"
image bg render2453 = "images/Render2453.webp"
image bg render2454 = "images/Render2454.webp"
image bg render2455 = "images/Render2455.webp"
image bg render2456 = "images/Render2456.webp"
image bg render2457 = "images/Render2457.webp"
image bg render2458 = "images/Render2458.webp"
image bg render2459 = "images/Render2459.webp"
image bg render2460 = "images/Render2460.webp"
image bg render2461 = "images/Render2461.webp"
image bg render2462 = "images/Render2462.webp"
image bg render2463 = "images/Render2463.webp"
image bg render2464 = "images/Render2464.webp"
image bg render2465 = "images/Render2465.webp"
image bg render2466 = "images/Render2466.webp"
image bg render2467 = "images/Render2467.webp"
image bg render2468 = "images/Render2468.webp"
image bg render2469 = "images/Render2469.webp"
image bg render2470 = "images/Render2470.webp"
image bg render2471 = "images/Render2471.webp"
image bg render2472 = "images/Render2472.webp"
image bg render2473 = "images/Render2473.webp"
image bg render2474 = "images/Render2474.webp"
image bg render2475 = "images/Render2475.webp"
image bg render2476 = "images/Render2476.webp"
image bg render2477 = "images/Render2477.webp"
image bg render2478 = "images/Render2478.webp"
image bg render2479 = "images/Render2479.webp"
image bg render2480 = "images/Render2480.webp"
image bg render2481 = "images/Render2481.webp"
image bg render2482 = "images/Render2482.webp"
image bg render2483 = "images/Render2483.webp"
image bg render2484 = "images/Render2484.webp"
image bg render2485 = "images/Render2485.webp"
image bg render2486 = "images/Render2486.webp"
image bg render2487 = "images/Render2487.webp"
image bg render2488 = "images/Render2488.webp"
image bg render2489 = "images/Render2489.webp"
image bg render2490 = "images/Render2490.webp"
image bg render2491 = "images/Render2491.webp"
image bg render2492 = "images/Render2492.webp"
image bg render2493 = "images/Render2493.webp"
image bg render2494 = "images/Render2494.webp"
image bg render2495 = "images/Render2495.webp"
image bg render2496 = "images/Render2496.webp"
image bg render2497 = "images/Render2497.webp"
image bg render2498 = "images/Render2498.webp"
image bg render2499 = "images/Render2499.webp"
image bg render2500 = "images/Render2500.webp"
image bg render2501 = "images/Render2501.webp"
image bg render2502 = "images/Render2502.webp"
image bg render2503 = "images/Render2503.webp"
image bg render2504 = "images/Render2504.webp"
image bg render2505 = "images/Render2505.webp"
image bg render2506 = "images/Render2506.webp"
image bg render2507 = "images/Render2507.webp"
image bg render2508 = "images/Render2508.webp"
image bg render2509 = "images/Render2509.webp"
image bg render2510 = "images/Render2510.webp"
image bg render2511 = "images/Render2511.webp"
image bg render2512 = "images/Render2512.webp"
image bg render2513 = "images/Render2513.webp"
image bg render2514 = "images/Render2514.webp"
image bg render2515 = "images/Render2515.webp"
image bg render2516 = "images/Render2516.webp"
image bg render2517 = "images/Render2517.webp"
image bg render2518 = "images/Render2518.webp"
image bg render2519 = "images/Render2519.webp"
image bg render2520 = "images/Render2520.webp"
image bg render2521 = "images/Render2521.webp"
image bg render2522 = "images/Render2522.webp"
image bg render2523 = "images/Render2523.webp"
image bg render2524 = "images/Render2524.webp"
image bg render2525 = "images/Render2525.webp"
image bg render2526 = "images/Render2526.webp"
image bg render2527 = "images/Render2527.webp"
image bg render2528 = "images/Render2528.webp"
image bg render2529 = "images/Render2529.webp"
image bg render2530 = "images/Render2530.webp"
image bg render2531 = "images/Render2531.webp"
image bg render2532 = "images/Render2532.webp"
image bg render2533 = "images/Render2533.webp"
image bg render2534 = "images/Render2534.webp"
image bg render2535 = "images/Render2535.webp"
image bg render2536 = "images/Render2536.webp"
image bg render2537 = "images/Render2537.webp"
image bg render2538 = "images/Render2538.webp"
image bg render2539 = "images/Render2539.webp"
image bg render2540 = "images/Render2540.webp"
image bg render2541 = "images/Render2541.webp"
image bg render2542 = "images/Render2542.webp"
image bg render2543 = "images/Render2543.webp"
image bg render2544 = "images/Render2544.webp"
image bg render2545 = "images/Render2545.webp"
image bg render2546 = "images/Render2546.webp"
image bg render2547 = "images/Render2547.webp"
image bg render2548 = "images/Render2548.webp"
image bg render2549 = "images/Render2549.webp"
image bg render2550 = "images/Render2550.webp"
image bg render2551 = "images/Render2551.webp"
image bg render2552 = "images/Render2552.webp"
image bg render2553 = "images/Render2553.webp"
image bg render2554 = "images/Render2554.webp"
image bg render2555 = "images/Render2555.webp"
image bg render2556 = "images/Render2556.webp"
image bg render2557 = "images/Render2557.webp"
image bg render2558 = "images/Render2558.webp"
image bg render2559 = "images/Render2559.webp"
image bg render2560 = "images/Render2560.webp"
image bg render2561 = "images/Render2561.webp"
image bg render2562 = "images/Render2562.webp"
image bg render2563 = "images/Render2563.webp"
image bg render2564 = "images/Render2564.webp"
image bg render2565 = "images/Render2565.webp"
image bg render2566 = "images/Render2566.webp"
image bg render2567 = "images/Render2567.webp"
image bg render2568 = "images/Render2568.webp"
image bg render2569 = "images/Render2569.webp"
image bg render2570 = "images/Render2570.webp"
image bg render2571 = "images/Render2571.webp"
image bg render2572 = "images/Render2572.webp"
image bg render2573 = "images/Render2573.webp"
image bg render2574 = "images/Render2574.webp"
image bg render2575 = "images/Render2575.webp"
image bg render2576 = "images/Render2576.webp"
image bg render2577 = "images/Render2577.webp"
image bg render2578 = "images/Render2578.webp"
image bg render2579 = "images/Render2579.webp"
image bg render2580 = "images/Render2580.webp"
image bg render2581 = "images/Render2581.webp"
image bg render2582 = "images/Render2582.webp"
image bg render2583 = "images/Render2583.webp"
image bg render2584 = "images/Render2584.webp"
image bg render2585 = "images/Render2585.webp"
image bg render2586 = "images/Render2586.webp"
image bg render2587 = "images/Render2587.webp"
image bg render2588 = "images/Render2588.webp"
image bg render2589 = "images/Render2589.webp"
image bg render2590 = "images/Render2590.webp"
image bg render2591 = "images/Render2591.webp"
image bg render2592 = "images/Render2592.webp"
image bg render2593 = "images/Render2593.webp"
image bg render2594 = "images/Render2594.webp"
image bg render2595 = "images/Render2595.webp"
image bg render2596 = "images/Render2596.webp"
image bg render2597 = "images/Render2597.webp"
image bg render2598 = "images/Render2598.webp"
image bg render2599 = "images/Render2599.webp"
image bg render2600 = "images/Render2600.webp"
image bg render2601 = "images/Render2601.webp"
image bg render2602 = "images/Render2602.webp"
image bg render2603 = "images/Render2603.webp"
image bg render2604 = "images/Render2604.webp"
image bg render2605 = "images/Render2605.webp"
image bg render2606 = "images/Render2606.webp"
image bg render2607 = "images/Render2607.webp"
image bg render2608 = "images/Render2608.webp"
image bg render2609 = "images/Render2609.webp"
image bg render2610 = "images/Render2610.webp"
image bg render2611 = "images/Render2611.webp"
image bg render2612 = "images/Render2612.webp"
image bg render2613 = "images/Render2613.webp"
image bg render2614 = "images/Render2614.webp"
image bg render2615 = "images/Render2615.webp"
image bg render2616 = "images/Render2616.webp"
image bg render2617 = "images/Render2617.webp"
image bg render2618 = "images/Render2618.webp"
image bg render2619 = "images/Render2619.webp"
image bg render2620 = "images/Render2620.webp"
image bg render2621 = "images/Render2621.webp"
image bg render2622 = "images/Render2622.webp"
image bg render2623 = "images/Render2623.webp"
image bg render2624 = "images/Render2624.webp"
image bg render2625 = "images/Render2625.webp"
image bg render2626 = "images/Render2626.webp"
image bg render2627 = "images/Render2627.webp"
image bg render2628 = "images/Render2628.webp"
image bg render2629 = "images/Render2629.webp"
image bg render2630 = "images/Render2630.webp"
image bg render2631 = "images/Render2631.webp"
image bg render2632 = "images/Render2632.webp"

image bg render2633 = "images/Render2633.webp"
image bg render2634 = "images/Render2634.webp"
image bg render2635 = "images/Render2635.webp"
image bg render2636 = "images/Render2636.webp"
image bg render2637 = "images/Render2637.webp"
image bg render2638 = "images/Render2638.webp"
image bg render2639 = "images/Render2639.webp"
image bg render2640 = "images/Render2640.webp"
image bg render2641 = "images/Render2641.webp"
image bg render2642 = "images/Render2642.webp"
image bg render2643 = "images/Render2643.webp"
image bg render2644 = "images/Render2644.webp"
image bg render2645 = "images/Render2645.webp"
image bg render2646 = "images/Render2646.webp"
image bg render2647 = "images/Render2647.webp"
image bg render2648 = "images/Render2648.webp"
image bg render2649 = "images/Render2649.webp"
image bg render2650 = "images/Render2650.webp"
image bg render2651 = "images/Render2651.webp"
image bg render2652 = "images/Render2652.webp"
image bg render2653 = "images/Render2653.webp"
image bg render2654 = "images/Render2654.webp"
image bg render2655 = "images/Render2655.webp"
image bg render2656 = "images/Render2656.webp"
image bg render2657 = "images/Render2657.webp"
image bg render2658 = "images/Render2658.webp"
image bg render2659 = "images/Render2659.webp"
image bg render2660 = "images/Render2660.webp"
image bg render2661 = "images/Render2661.webp"
image bg render2662 = "images/Render2662.webp"
image bg render2663 = "images/Render2663.webp"
image bg render2664 = "images/Render2664.webp"
image bg render2665 = "images/Render2665.webp"

image bg adamxNightmare = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare.webp"
image bg adamxNightmare1 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare1.webp"
image bg adamxNightmare2 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare2.webp"
image bg adamxNightmare3 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare3.webp"
image bg adamxNightmare4 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare4.webp"
image bg adamxNightmare5 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare5.webp"
image bg adamxNightmare6 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare6.webp"
image bg adamxNightmare7 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare7.webp"
image bg adamxNightmare8 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare8.webp"
image bg adamxNightmare9 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare9.webp"
image bg adamxNightmare10 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare10.webp"
image bg adamxNightmare11 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare11.webp"
image bg adamxNightmare12 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare12.webp"
image bg adamxNightmare13 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare13.webp"
image bg adamxNightmare14 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare14.webp"
image bg adamxNightmare15 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare15.webp"
image bg adamxNightmare16 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare16.webp"
image bg adamxNightmare17 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare17.webp"
image bg adamxNightmare18 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare18.webp"
image bg adamxNightmare19 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare19.webp"
image bg adamxNightmare20 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare20.webp"
image bg adamxNightmare21 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare21.webp"
image bg adamxNightmare22 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare22.webp"
image bg adamxNightmare23 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare23.webp"
image bg adamxNightmare24 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare24.webp"
image bg adamxNightmare25 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare25.webp"
image bg adamxNightmare26 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare26.webp"
image bg adamxNightmare27 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare27.webp"
image bg adamxNightmare28 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare28.webp"
image bg adamxNightmare29 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare29.webp"
image bg adamxNightmare30 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare30.webp"
image bg adamxNightmare31 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare31.webp"
image bg adamxNightmare32 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare32.webp"
image bg adamxNightmare33 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare33.webp"
image bg adamxNightmare34 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare34.webp"
image bg adamxNightmare35 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare35.webp"
image bg adamxNightmare36 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare36.webp"
image bg adamxNightmare37 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare37.webp"
image bg adamxNightmare38 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare38.webp"
image bg adamxNightmare39 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare39.webp"
image bg adamxNightmare40 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare40.webp"
image bg adamxNightmare41 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare41.webp"
image bg adamxNightmare42 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare42.webp"
image bg adamxNightmare43 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare43.webp"
image bg adamxNightmare44 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare44.webp"
image bg adamxNightmare45 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare45.webp"
image bg adamxNightmare46 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare46.webp"
image bg adamxNightmare47 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare47.webp"
image bg adamxNightmare48 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare48.webp"
image bg adamxNightmare49 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare49.webp"
image bg adamxNightmare50 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare50.webp"
image bg adamxNightmare51 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare51.webp"
image bg adamxNightmare52 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare52.webp"
image bg adamxNightmare53 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare53.webp"
image bg adamxNightmare54 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare54.webp"
image bg adamxNightmare55 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare55.webp"
image bg adamxNightmare56 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare56.webp"
image bg adamxNightmare57 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare57.webp"
image bg adamxNightmare58 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare58.webp"
image bg adamxNightmare59 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare59.webp"
image bg adamxNightmare60 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare60.webp"
image bg adamxNightmare61 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare61.webp"
image bg adamxNightmare62 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare62.webp"
image bg adamxNightmare63 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare63.webp"
image bg adamxNightmare64 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare64.webp"
image bg adamxNightmare65 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare65.webp"
image bg adamxNightmare66 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare66.webp"
image bg adamxNightmare67 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare67.webp"
image bg adamxNightmare68 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare68.webp"
image bg adamxNightmare69 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare69.webp"
image bg adamxNightmare70 = "images/Adam Action animations/Adam vs Nightmare last renders/NightMare70.webp"




default meipts = 0
default meipath = False
default SaraPath = False
default kissedSara = False
default LunaPathIncest = False
default HadSexWithAliceStorageRoom = False

default AlanDead = False
default JonathanAlive = False

image bg thanks = "images/Thank you for play version 0.2.webp"
image bg thankSup = "images/ThankSupporter.webp"

image bg AliceAndAdam = "images/DOOVER/Alice And Adam.webp"
image bg AliceAndAdam2 = "images/DOOVER/Alice And Adam2.webp"
image bg AliceAndAdam3 = "images/DOOVER/Alice And Adam3.webp"
image bg adamDoOver = "images/DOOVER/Adam.webp"
image bg adamDoOver2 = "images/DOOVER/Adam1.webp"

image bg emi = "images/DOOVER/emi.webp"
image bg emi2 = "images/DOOVER/emi2.webp"
image bg emi3 = "images/DOOVER/emi3.webp"
image bg emi4 = "images/DOOVER/emi4.webp"
image bg emi5 = "images/DOOVER/emi5.webp"
image bg emi6 = "images/DOOVER/emi6.webp"
image bg emi7 = "images/DOOVER/emi7.webp"
image bg emi8 = "images/DOOVER/emi8.webp"
image bg emi9 = "images/DOOVER/emi9.webp"
image bg emi10 = "images/DOOVER/emi10.webp"
image bg emi11 = "images/DOOVER/emi11.webp"
image bg emi12 = "images/DOOVER/emi12.webp"
image bg emi13 = "images/DOOVER/emi13.webp"
image bg emi14 = "images/DOOVER/emi14.webp"
image bg emi15 = "images/DOOVER/emi15.webp"
image bg emi16 = "images/DOOVER/emi16.webp"
image bg emi17 = "images/DOOVER/emi17.webp"
image bg emi18 = "images/DOOVER/emi18.webp"
image bg emi19 = "images/DOOVER/emi19.webp"
image bg emiAlicpc = "EmiAndAlice.webp"
image bg Lunapc = "images/Luna.webp"


image bg inicio = "images/DOOVER/emilyFirstScene.webp"
image bg inicio1 = "images/DOOVER/emilyFirstScene1.webp"
image bg inicio2 = "images/DOOVER/emilyFirstScene2.webp"
image bg inicio3 = "images/DOOVER/emilyFirstScene3.webp"
image bg inicio4 = "images/DOOVER/emilyFirstScene4.webp"
image bg inicio5 = "images/DOOVER/emilyFirstScene5.webp"
image bg inicio6 = "images/DOOVER/emilyFirstScene6.webp"
image bg inicio7 = "images/DOOVER/emilyFirstScene7.webp"
image bg inicio8 = "images/DOOVER/emilyFirstScene8.webp"

define dissolve_suave = Dissolve(1.5)
define Adam = Character("Adam", color="#16b5e6")
define Unknown = Character("Unknown", color="#f7f8f8")
define Samuel = Character("Samuel", color="#f7f8f8")
define Anne = Character("Anne", color="#c0d40c")
define Luna = Character("Luna", color="#f1eeee")
define Tom = Character("Tom", color="#c9610d")
define Sara = Character("Sara", color="#0abb31a4")
define Emily = Character("Emily", color="#0c72f8e8")
define Alice = Character("Alice", color="#f81010dc")
define Mei = Character("Mei", color="#55fa22de")
define Rim = Character("Rim", color="#f50964de")

define Lucy = Character("Lucy", color="#0becdaea")
define Elen = Character("Elen", color="#9bf5097e")
define Woman = Character("Woman", color="#9bf5097e")







define Cole = Character("Cole", color="#c9b4a0f3")
define Thomas = Character("Thomas", color="#e05e12de")
define Alan = Character("Alan", color="#2327f3de")

define Sam = Character("Sam", color="#7e80ecde")
define Miller = Character("Miller", color="#d40420de")
define Yuri = Character("Yuri", color="#b9430cde")
define Williams = Character("Williams", color="#f72500de")
define Graves = Character("Graves", color="#ffffffde")


define Jonathan = Character("Jonathan", color="#6d3be2de")
define Mitcher = Character("Mitcher", color="#da1c1cde")


define bōsa  = Character("bōsa", color="#0c0508de")

default emipts = False
default EmilyAndSara = False

default EmilyIsPregnant = False
default AnneIsPregnant = False
default HadThreesomeWithAnneEmily = False


label start:
    scene black
    $ player_name = renpy.input("What is your name? (Default: Adam)")
    $ player_name = player_name.strip()

    if player_name == "":
        $ player_name = "Adam"  
    define p = Character("[player_name]")

    "Nice to meet you, [p]!"

    scene black
    with fade
    
    "Are you over 18 years old?"
    menu:
        "Yes":
            jump maior_de_idade

        "No":
            jump menor_de_idade

label maior_de_idade:
    stop music
    scene bg Lunapc
    $ Luna_relation = renpy.input("This is Luna, she lives with you and your wife. How do you call her?")
    $ Luna_relation = Luna_relation.strip()

    if Luna_relation == "":
        $ Luna_relation = "Ward"  
        define LunaRelation = Character("[Luna_relation]")

    $ MainLunaRelation = renpy.input("How does she call you?")
    $ MainLunaRelation = MainLunaRelation.strip()

    if MainLunaRelation == "":
        $ MainLunaRelation = "Guardian "  
        define AdamLunaR = Character("[MainLunaRelation]")

    scene bg emiAlicpc
    $ EmiAliceRelation = renpy.input("Alice and Emily, they both live with your brother and his wife. How do they call you?")
    $ EmiAliceRelation = EmiAliceRelation.strip()

    if EmiAliceRelation == "":
        $ EmiAliceRelation = "Friend"  
        define EmiAliceRelation = Character("[EmiAliceRelation]")
    scene black
    "Luna is your [LunaRelation]. Alice and Emily call you [EmiAliceRelation]"

    play music "audio/static.mp3"
    scene bg renderOne with fade
    window hide
    pause
    scene bg render2
    window hide
    pause

    scene bg Anne3 with fade
    window hide
    pause

    play music "audio/first song.mp3" fadein 0.8
    scene bg Anne3
    Anne "Sweetie, are you sure this outfit is appropriate for a family meeting?"

    scene bg Luna4
    window hide
    pause

    scene bg Luna4 
    Luna "Can you be more specific?"

    scene bg Luna5
    Anne "I think you might be showing a bit too much for a girl your age."

    scene bg Anne6 with dissolve
    Anne "You could be left naked with the smallest accident."

    scene bg Luna7
    Anne "Maybe you should have brought a coat."

    scene bg Luna8
    Luna "..."

    play sound "audio/zapsplat_household_chair_sofa_couch_leather_sit_down_002_46594.mp3"
    scene bg Luna9
    pause

    scene bg Anne10
    Luna "Well, I think you are showing way more cleavage than I am."

    scene bg Luna11
    Luna "And [MainLunaRelation] said I looked cute."

    scene bg Luna12
    pause

    scene bg Adam13
    pause

    scene bg Adam14
    p "I remember saying that you looked cute in everything — and that was last week."

    scene bg Adam15 with dissolve
    Luna "I guess this is part of everything."

    scene bg Luna16
    pause

    scene bg Luna17 with dissolve
    Luna "And it's not like there will be plenty of guys there."

    scene bg Anne6
    Anne "Sam will."

    Luna "MOM!"

    scene bg Adam20
    p "Nah, Sam will be playing his games."

    scene bg Adam20
    Anne "Maybe he has changed."

    p "I hope so, but I doubt it."

    scene bg Luna18 
    Luna "They are saying that the Apophis-17 is changing its route and that it could be dangerous."

    scene bg Adam19
    p "They always say that. Don't worry about it, baby."

    scene bg AdamAndAnne
    p "We are almost there."

    play sound "audio/Engine stops.mp3"
    scene bg render23TomsHouse with fade
    pause

    scene bg render24TomsHouse 
    pause

    scene bg render25TomsHouse 
    play sound "audio/car-door-close-6929.mp3"
    pause

    menu:
        "Open the door for them":
            jump carDoor

        "Don't open the door for them":
            jump door

label carDoor:
    scene bg render26TomsHouse
    play sound "audio/car-door-close-6929.mp3"
    pause

    scene bg render26TomsHouse
    menu:
        "Gentle slap":
            jump assSlap

        "Don't":
            jump door

label assSlap:
    scene bg render27TomsHouse 
    pause
    play sound "audio/smack-107626.mp3"
    scene bg render28TomsHouse with dissolve
    pause

    jump door

    return

label door:
    scene bg render29TomsHouse 
    pause
    scene bg render30TomsHouse
    play sound "audio/doorbell-223669.mp3"
    pause
    scene bg render31TomsHouse
    pause
    scene bg render32TomsHouse
    pause
    scene bg render33TomsHouse with dissolve
    play sound "audio/door-opening-78648.mp3"
    pause
    scene bg render34TomsHouse
    pause
    scene bg render35TomsHouse
    Emily "Luna! finally, i was waiting for you guys"
    scene bg render36TomsHouse
    Luna "Emily, it's so good to see you, it's been a while"
    scene bg render37TomsHouse
    Emily "We have so much catching up to do"
    scene bg render38TomsHouse
    Luna "Mom said we're crashing here tonight"
    scene bg render40TomsHouse
    Anne "You look so adorable sweetie, You've grown into quite a pretty girl"
    Anne "I bet the boys must be all over you"
    scene bg render41TomsHouse
    play sound "audio/mixkit-little-cute-kiss-2192.wav"
    pause
    scene bg render42TomsHouse with fade
    pause
    scene bg render43TomsHouse
    pause
    scene bg render44TomsHouse
    Emily "[EmiAliceRelation] [p]!"

    scene bg render45TomsHouse
    pause
    scene bg render47TomsHouse
    pause
    scene bg render46TomsHouse
    pause
    scene bg render46TomsHouse
    Emily "You promised to visit more often"
    p "Sorry Emi, I was busy with work. You know how it is"
    scene bg render48TomsHouse
    Emily "I forgive you"
    p "That easy?"

    scene bg render49TomsHouse
    Emily "Well, maybe you could give me something, just to make sure you are completely absolved"
    p "And what would that be?"
    pause
    scene bg render50TomsHouse with dissolve
    play sound "audio/heartbeat-sound-372448.mp3"
    Emily "Just stand still"
    scene bg render51TomsHouse
    Emily "And do nothing"
    pause
    scene bg render52TomsHouse
    pause
    menu:
        "Do nothing":
            jump callOut

        "Stand still":
            jump callOut

    label callOut:
    scene bg render53TomsHouse
    stop sound
    Sara "EMILY! COME HELP ME WITH THE DISHES."
    pause
    scene bg render54TomsHouse with fade
    Tom "Hey man, how is it going?"
    scene bg render56TomsHouse
    p "Wasup"

    scene bg render57TomsHouse
    Sara "[player_name]! I'll be there in a second"
    scene bg render58TomsHouse
    Sara "Just let me finish here"
    p "No problem"
    scene bg render55TomsHouse with fade
    pause
    scene bg render59TomsHouse
    p "Hey, What are you up to?"
    scene bg render60TomsHouse
    Tom "You know, just fixing some issues in the company."
    Tom "We just got a new client"
    Tom "And it's quite a big deal"
    scene bg render61TomsHouse
    p "I thought you were quitting the private security business"
    scene bg render62TomsHouse
    Tom "Yeah, you first."
    Tom "We both know that once you do what we used to, it's never really the same anymore"
    scene bg render63TomsHouse
    Tom "And I can't just say no to all this income"
    p "I guess you are right"
    scene bg render64TomsHouse
    Sara "Come here"
    scene bg render65TomsHouse
    Sara "I thought you guys would show up more often"
    play sound "audio/mixkit-little-cute-kiss-2192.wav"
    scene bg render66TomsHouse
    Sara "Dinner will be ready in a few, Alice is in her room and you know where Samuel is."
    p "Okay"
    scene bg render67TomsHouse with fade
    pause
    scene bg render68TomsHouse with dissolve
    pause
    scene bg render69TomsHouse
    pause
    scene bg render70TomsHouse with dissolve
    pause
    scene bg render71TomsHouse
    
    Emily "[EmiAliceRelation] [player_name], come sit with me"
    p "Let me catch up with Alice first baby"
    scene bg render72TomsHouse with dissolve
    pause
    scene bg render72TomsHouse
    Luna "So you are saying that he just pissed himself and left?"
    p "Hi girls"
    pause
    
    scene bg render78
    pause
    scene bg render75
    Alice "Hey"
    scene bg render77TomsHouse
    Alice "It's been a while old man"
    pause
    scene bg render80 with dissolve
    p "Who are you calling old?"
    "."
    ".."
    "..."
    scene bg render81 with dissolve
    Alice "This hot guy in front of me"
    scene bg render82 with dissolve
    Alice "Come here you big dummy"
    Alice "I thought you and Emily would've run away already"
    scene bg render84 with dissolve
    p "What are you talking about?"
    scene bg render85 with dissolve
    Alice "I even heard her saying something about marrying you HaHa!"
    scene bg render86 with dissolve
    p "Hah, I can't with you two"
    scene bg render87 with dissolve
    Alice "You know how she is"
    scene bg render88 with dissolve
    Alice "Well, she's got competition"
    scene bg render88p2 with dissolve
    pause
    scene bg Render88p3 with dissolve
    p "I believe I could handle both of you just fine"
    scene bg Render88p4 with dissolve
    Alice "Be careful with what you wish for"
    Alice "And where you place your hands"
    scene bg Render88p5 with dissolve
    Alice "Where do you think you are touching, old man?"
   
    scene bg Render88p7 with fade
    Alice "I hurt my back playing last week and it still hurts a bit"
    scene bg Render88p8 with dissolve
    Alice "Especially when I try to flex"
    scene bg Render88p9 with dissolve
    p "gimme a few minutes and a body lotion and I'll fix that"
    scene bg Render88p10 with dissolve
    Alice "I just might"
    scene bg Render88p9 with dissolve
    p "You should go greet your aunt, you know"
    scene bg Render88p11 with dissolve
    Alice "Shit, yeah, sorry"
    scene bg Render88p12 with dissolve
    pause
   



    scene bg render83 with fade
    pause
    scene bg render90 with dissolve
    pause
    
    menu:
        "Do it":
            jump grope

        "I guess not":
            jump gropNt



    label grope:
    scene bg render90 with dissolve
    pause
    scene bg render91 with dissolve
    pause
    scene bg render92 with dissolve
    pause
    scene bg render93 with dissolve
    pause
    scene bg render94
    Luna "[MainLunaRelation], what are you doing"
    p "My bad, guess I just couldn't resist"
    Luna "I don't mind to be honest"
    scene bg render96 with dissolve
    Luna "But not like this in the open"
    scene bg render97 with dissolve
    Luna "Okay?"
    p "Hm, baby"
    scene bg render99 with dissolve
    Luna "Shit"
    scene bg render100 with dissolve
    pause
    scene bg render101 with dissolve
    pause
    scene bg render102 with dissolve
    pause
    scene bg render103 with dissolve
    Luna "I don't wanna hear one word"
    scene bg render104 with dissolve
    p "Don't worry baby, I'll save you from the biggest 'I told you so' ever"
    scene bg render105 with fade
    p "So, what were you saying about doing things in private"
    scene bg render106 with dissolve
    Luna "Hah, you are so funny [MainLunaRelation]"
    scene bg render107 with dissolve
    p "What if I am not joking this time"
    scene bg render108 with dissolve
    Luna "Well, if that was the case, then..."
    scene bg render109 with dissolve
    Luna "Maybe"
    scene bg render109 with dissolve
    Luna "We could"
    scene bg render110 with dissolve
    Emily "[EmiAliceRelation] [player_name], come sit with me!"
    pause
    scene bg render111 with dissolve
    Emily "You said you were only catching up, come on"

    label gropNt:
    scene bg render112 with dissolve
    p "Hey, little minx do you think there's room for me in there?"
    scene bg render113 with dissolve
    Emily "Of course, you could watch me play"
    scene bg render114 with dissolve
    play sound "audio/zapsplat_household_chair_sofa_couch_leather_sit_down_002_46594.mp3"
    Emily "It will be like old times"

    scene bg render115 with dissolve
    Emily "This is quite comfy"
    scene bg render116 with dissolve
    Emily "You know..."
    
    scene bg render117 with dissolve
    Emily "I don't feel like playing anymore"
    scene bg render118 with dissolve
    Emily "Can you remember where were we?"
    p "I think that it had something to do with standing still"
    scene bg render119 with dissolve
    Emily "Yeah!"
    scene bg render120 with dissolve 
    play sound "audio/kiss-67648.mp3"
    pause
    scene bg render121 with dissolve
    pause
    scene bg render122 with dissolve
    pause
    scene bg render123 with dissolve
    pause
    scene bg render124 with dissolve
    pause
    scene bg render125 with dissolve
    stop sound
    pause
    scene bg render126 with dissolve
    Emily "Wait, Luna is still here"
    scene bg render127 with dissolve
    pause
    scene bg render129 with dissolve
    p "It's okay"
    scene bg render130 with dissolve
    p "Come here"
    scene bg render131 with dissolve
    pause
    scene bg render132 with dissolve
    pause
    scene bg render133 with dissolve
    pause
    scene bg render135 with dissolve
    pause
    scene bg render136 with dissolve
    Emily "I think we should stop"
    scene bg render134 with fade
    p "I got carried away, sorry"
    Emily "I liked it, maybe we can do it again later"
    p "Come find me in my room later"
    scene bg render137 with dissolve
    Emily "Holy shit!"
    scene bg render139 with dissolve
    pause
    stop music fadeout 1.                   
    scene bg render140 with dissolve
    play sound "audio/close-door-sound-247450.mp3"
    pause
    scene bg render141 with dissolve
    p "* I almost lost it this time * "

    
    scene bg render142 with dissolve
    pause
    scene bg render143 with dissolve
    Anne "Hey love, I was looking for you"
    scene bg render144 with dissolve
    Anne "Have you seen what a wonderful girl Alice has become?"
    scene bg render145 with dissolve
    Anne "I was thinking that maybe we've spent too much time without visiting them"
    scene bg render146 with dissolve
    Anne "And maybe we shou... Honey, where are we going?"
    scene bg render147 with dissolve
    Anne "What happened? "
    scene bg render148 with dissolve
    pause
    play music "audio/sensual.mp3"
    scene bg render149 with dissolve
    pause
    scene bg render150 with dissolve
    Anne "Dirty boy, I know that look"
    scene bg render150 with dissolve
    pause
    scene bg render151 with dissolve
    pause
    scene bg render152 with dissolve
    Anne "Straight to business, what got you so horny?"
    scene bg render153 with dissolve
    Anne "Let's take these off"
    scene bg render154 with dissolve
    pause
    scene bg render155 with dissolve
    p "I missed them"
    scene bg render156 with dissolve
    Anne "We had a quickie before leaving, what are you talking about?"
    scene bg render157 with dissolve
    p "Belive me, that's too much time not beeing between those legs"
    Anne "Shit, now you did it"
    scene bg render158 with dissolve
    Anne "Come here"

    scene bg render159 with dissolve
    pause
    scene bg render159s2 with dissolve
    pause
    scene bg render159s3 with dissolve
    pause

    scene bg render160 with dissolve
    pause

    scene bg render161 with dissolve
    pause
    scene bg render162 with dissolve
    Anne "Always hard and big for me"
    scene bg render163 with dissolve
    p "How could I not be?"
    scene bg render164 with dissolve
    p "Enough teasing baby"
    scene bg render165 with dissolve
    Anne "Take me"
    scene bg render166 with dissolve
    pause
    scene bg render167 with dissolve
    pause
    scene bg render168 with dissolve
    pause
    scene bg render169 with dissolve
    pause
    scene bg render170 with dissolve
    pause
    scene bg render171 with dissolve
    Anne "Fuuck!"

    play sound "audio/wettt.mp3" loop
    image sexloop = Movie(play="images/animation/anne/anne10001-0080-ndajc4.webm", loop=True)
    show sexloop with fade
    pause 
    
    Anne "Fuck me"
    p "I love this tight little pussy"
    pause

    stop sound  
    scene bg render173 with dissolve
    pause
    scene bg render174 with dissolve
    pause
    scene bg render172 with dissolve
    pause
    Anne "I am almost there"
    
    stop sound
    image sex_loop_two = Movie(play="images/animation/anne/anne20001-0060-njb5ah.webm", loop=True)
    show sex_loop_two with fade
    pause 
    
    pause
    Anne "Fuck me harder"

    play sound "audio/sexSound.mp3" loop

    image sex_loop_five = Movie(play="images/animation/anne/anne40001-0060-7sx1xy.webm", loop=True)
    show sex_loop_five with fade
    pause
    p "I wanna fill you up so fucking bad"
    Anne "I don't think I.. shiiiit"
    p "I love when you moan"
    pause
    scene bg render174 with dissolve
    stop sound
    Anne "Don't stop baby I am..."
    scene bg render175 with dissolve
    Anne "Fuuuck"
    scene bg render176 with dissolve
    pause
    scene bg render177 with dissolve
    Anne "Wait I am too sensitive"
    scene bg render178 with dissolve
    Anne "Jesus, let's wrap it up okay?"
    scene bg render179 with dissolve
    Anne "I hope my mouth is enough"
    scene bg render180 with dissolve
    p "I am close honey"
    scene bg render181 with dissolve
    pause
    scene bg render182 with dissolve
    pause
    scene bg render183 with dissolve
    p "I fucking love those lips"
    scene bg render184 with dissolve
    p "Shit, I am cumming"
    scene bg render185 with dissolve
    pause
    scene bg render186 with dissolve
    pause
    scene bg render187 with dissolve
    pause
    scene bg render189 with dissolve
    pause
    scene bg render190 with dissolve
    play sound "audio/gulp.mp3"
    pause
    scene bg render191 with dissolve
    pause
    scene bg render192 with dissolve
    pause

    stop music
    play sound "audio/fast-knocking-on-door-352704.mp3"
    Luna "Mom? [MainLunaRelation]? Are you there?"
    scene bg render193 with dissolve
    p "Yeah honey, we'll be there in a second"
    Luna "Okay, dinner is ready"
    scene bg render194 with fade
    pause
    Sara "I think we'll be going next year, you should join us"
    scene bg render195 with dissolve
    Sara "I'll tell [player_name] to let you come with us"
    scene bg render198 with dissolve
    pause
    scene bg render199 with dissolve
    Anne "I had a small problem with my dress, sorry guys"
    scene bg render200 with dissolve
    pause
    scene bg render201 with dissolve
    Sara "I am really happy to have you guys join us today"
    play music "images/dishes-clearing-73302.mp3"
    scene bg render202 with dissolve
    Sara "Well, I believe we are all starving so let's eat"
    scene bg render203 with dissolve
    Luna "Where is Samuel?"
    scene bg render204 with dissolve
    Sara "He said his match was almost done"
    play sound "audio/mobile-vibrate-sfx-323777.mp3"
    scene bg render205 with dissolve
    Sara "I've never seen a game where a single match lasts 40 minutes before"
    play sound "audio/mobile-vibrate-sfx-323777.mp3"
    scene bg render206 with dissolve
    play sound "audio/mobile-vibrate-sfx-323777.mp3"
    p "He must be playing Rift's champions"
    scene bg render207 with dissolve
    play sound "audio/mobile-vibrate-sfx-323777.mp3"
    Luna "Yeah"
    scene bg render210 with dissolve
    play sound "audio/mobile-vibrate-sfx-323777.mp3"
    Sara "Well, whatever it is I hate it"
    Tom "Dear God"
    Sara "Honey?"
    stop music
    scene bg render211 with dissolve
    Tom "Holy Shit"
    scene bg render212 with dissolve
    Tom "[player_name]!"
    scene bg render213 with dissolve
    Tom "[player_name], listen to me"
    scene bg render214 with dissolve
    play music "audio/EyesInTheVoid-chosic.com_.mp3"
    Tom "Syria, 12 years ago"
    scene bg render215 with dissolve
    p "Wha- why are you bringing that up?"
    scene bg render219 with dissolve
    Tom "We've got incoming"
    scene bg render218 with dissolve
    p "Everyone to the basement now!"
    scene bg render221 with dissolve
    Sara "What kind of joke is this?"
    scene bg render220 with dissolve
    p "NOW! THIS IS NOT A JOKE"
    scene bg render222 with dissolve
    p "LET'S GO NOW! GO GO GO"
    scene bg render223 with dissolve
    Luna "[p]!"
    scene bg render224 with dissolve
    Alice "What is going on?"
    scene bg render225 with dissolve
    Tom "Later honey, come on"

    scene bg render225 with dissolve
    pause
    scene bg render226 with dissolve
    pause
    scene bg render227 with dissolve
    p "Let's go"
    scene bg render228 with dissolve
    p "Hurry"
    scene bg render229 with dissolve
    p "Wait for us down there"
    scene bg render230 with dissolve
    Anne "Honey, what is going on?"
    p "We'll talk later baby, trust me"
    scene bg render231 with dissolve
    Tom "[player_name]"
    scene bg render232 with dissolve
    Tom "Samuel is upstairs, I'll be right back"
    scene bg render233 with dissolve
    p "I'll wait here"
    
    scene bg render239 with fade
    pause
    scene bg render238 with dissolve
    pause
    scene bg render240 with dissolve
    Tom "Samuel, I don't have time to explain but I need you to come with me now"
    scene bg render241 with dissolve
    Samuel "What?"
    Tom "We are in danger, come with me"
    scene bg render242 with dissolve
    play sound "audio/nuclear-explosion-386181.mp3"
    Samuel "What happe..."
    scene bg render243 with dissolve
    Samuel "What the fuck was that"
    scene bg render244 with dissolve
    Tom "The reason why we need to go right now"
    Tom "I don't know how long the shockwave will take to get here"
    scene bg render245 with dissolve
    Tom "Shockwave?"
    play sound "audio/052256_cracking-earthquake-cracking-soil-cracking-stone-86770.mp3"
    scene bg render246 with dissolve
    Samuel "AAAH!"
    scene bg render247 with dissolve
    Tom "GET DOWN!"
    scene bg render248 with dissolve
    scene bg render257 with dissolve
    pause

    stop sound
    scene bg render234 with dissolve
    
    pause

    scene bg render235 with dissolve
    play sound "audio/nuclear-explosion-386181.mp3"
    pause
    scene bg render236 with dissolve
    pause
    scene bg render249 with dissolve
    Emily "We should at least go check"
    scene bg render250 with dissolve
    Emily "What if they are in danger?"
    Alice "Our dad is almost a trained assassin dude"
    scene bg render251 with dissolve
    Alice "Look"
    scene bg render252 with dissolve
    Luna "Is everything alright?"
    scene bg render253 with dissolve
    Anne "Honey? I've never seen you like this"
    scene bg render254 with dissolve
    p "I don't think they will make it"
    play sound "audio/earthquake.mp3"
    scene bg render255 with dissolve
    pause
    scene bg render256 with dissolve
    p "Stay together"
    Emily "Aaaah!"
    scene bg render257 with dissolve
    pause
    stop sound
    stop music
    pause

    scene bg render258 with dissolve
    pause
    Luna "[MainLunaRelation]?"
    p "Are you okay honey?"
    Luna "I guess"
    scene bg render259 with dissolve
    p "Is that..."
    scene bg render260 with dissolve
    p "Let's hope it works"
    scene bg render261 with dissolve
    play sound "audio/button-press-3-386171.mp3"
    play music "audio/big-motor-90117.mp3" fadein 1
    pause
    scene bg render262 with dissolve
    p "Yeah"
    scene bg render263 with dissolve
    pause
    scene bg render264 with dissolve
    p "That will have to do"
    scene bg render265 with dissolve
    stop music
    pause
    scene bg render266 with dissolve
    p "Hey pretty, come on, get up"
    scene bg render267 with dissolve
    pause
    scene bg render268 with dissolve
    Sara "Did I just lose both my husband and son?"
    scene bg render269 with dissolve
    pause
    scene bg render270 with dissolve
    p "I am not sure, but I need you to stay strong, you have two girls to take care of"
    p "We need to figure out what to do next"
    scene bg render271 with dissolve
    Sara "You know your brother"
    scene bg render272 with dissolve
    Sara "He is always ready for everything"
    scene bg render273 with dissolve
    Sara "Come on girls, we are safe here"
    pause
    scene bg render288 with dissolve
    pause

    scene bg render278 with fade
    pause
    scene bg render277 with dissolve
    pause
    play sound "audio/rattlinglockeddoor-100095.mp3"
    scene bg render279 with dissolve
    pause

    scene bg render280 with dissolve
    stop sound
    p "I can't open it"
    scene bg render281 with dissolve
    p "I guess we'll have to find another way"
    scene bg render282 with dissolve
    pause
    p "They must be fine"
    scene bg render283 with dissolve
    p "Don't worry"
    scene bg render284 with dissolve
    Alice "That's bullshit"
    scene bg render285 with dissolve
    p "I'll talk to her later"
    scene bg render286 with dissolve
    pause
    scene bg render287 with dissolve
    pause
    scene bg render289 with fade
    pause
    Emily "What the... I had no idea we had all this stuff down here"
    scene bg render290 with dissolve
    Alice "I forgot how big this place was"
    Sara "Your father keeps the door locked"

    scene bg render274 with dissolve
    Alice "Why would he build this place?"
    scene bg render275 with dissolve
    pause
    Sara "To protect us"
    scene bg render276 with fade
    Luna "Wow"
    scene bg render291 with dissolve
    Luna "Uncle Tom must've  worked really hard"
    scene bg render292 with dissolve
    pause
    scene bg render293 with dissolve
    p "You think this is cool? Come check this out"
    scene bg render299 with dissolve
    Emily "How did he do this without us seeing shit?"

    scene bg render294 with fade
    pause
    play music "audio/sad-documentary-background-music-365827.mp3"

    scene bg render295 with dissolve
    Luna "Holy shit"
    scene bg render296 with dissolve
    Luna "What is that?"
    scene bg render297 with dissolve
    p "I have no idea"
    p "Tom was always the brains"
    p "My thing was guns and close combat"
    scene bg render298 with dissolve
    Luna "Was he expecting to fight a whole country or something like that?"
    scene bg render300 with dissolve
    Luna "I think that this is something related to the atmosphere"
    scene bg render301 with dissolve
    Luna "What are those?"
    scene bg render302 with dissolve
    p "I am not sure, just some numbers"
    scene bg render303 with dissolve
    Luna "He must've written something useful somewhere"
    scene bg render304 with fade
    pause
    Anne "At least there's another way out"
    scene bg render305 with dissolve
    Anne "Honey, the girls need you right now"
    Anne "Can you come with me?"
    scene bg render306 with fade
    pause
    scene bg render307 with dissolve
    pause
    scene bg render308 with dissolve
    pause
    scene bg render309 with dissolve
    pause
    scene bg render310 with dissolve
    pause
    scene bg render311 with dissolve
    pause
        
    scene bg render312 with dissolve
    pause
    scene bg render313 with dissolve
    pause
    scene bg render314 with dissolve
    pause
    scene bg render315 with dissolve
    pause
    scene bg render316 with dissolve
    pause
    scene bg render317 with dissolve
    pause
    scene bg render318 with dissolve
    pause
    scene bg render319 with dissolve
    pause
    scene bg render320 with dissolve
    pause
    scene bg render321 with dissolve
    pause

    scene bg render323 with dissolve
    Luna "No way!"
    scene bg render324 with dissolve
    pause
    scene bg render325 with dissolve
    stop music fadeout 0.8
    play sound "audio/sound-effect-door-knock-single-200531.mp3"
    pause
    p "Sara, we have a problem"
    Sara "What's wrong?"
    scene bg render326 with dissolve
    p "We'll have to stay here for a while"
    p "There's something wrong with the air outside"
    pause
    scene bg weeks
    pause
    
    scene bg render327 with fade
    pause
    scene bg render328 with dissolve
    pause
    scene bg render329 with dissolve
    pause
    p "Morning!"
    scene bg render330 with dissolve
    p "Did you sleep well?"
    scene bg render331 with dissolve
    Alice "I miss my dad"
    scene bg render332 with dissolve
    play sound "audio/audio-editor-output (1).mp3"
    p "I know honey, I miss him too"
    p "* I need to talk about something else*"
    scene bg render333 with dissolve
    p "*She is too close*"
    p "What are you wearing?"
    Alice "This place is so hot, it sucks"
    scene bg render334 with dissolve
    p "I guess I am used to it, after all those years.."
    scene bg render335 with dissolve
    p "*Shit, I haven't had sex since we got here, and she is too close"
    scene bg render336 with dissolve
    Alice "[EmiAliceRelation] [player_name], there's.."
    Alice "Something is poking my leg"

    play music "audio/sensual.mp3"
    scene bg render337 with dissolve
    Alice "WOW!"
    scene bg render338 with dissolve
    Alice "What the fuck, that's a whole fucking arm right there"

    menu:
        "Hide it":
            call hides from _call_hides

        "Don't hide it":
            call sexscene from _call_sexscene

    return
    label sexscene: 
    scene bg render339 with dissolve
    Alice "This thing could kill someone"
    p "Baby, I don't think this is clever"
    scene bg render340 with dissolve
    Alice "Come on, the world just went to shit and we might die tomorrow"
    scene bg render341 with dissolve
    Alice "Let's enjoy the ride"
    scene bg render342 with dissolve
    
    menu:
        "Give in":
            call tightjob from _call_tightjob

        "Don't":
            call hides from _call_hides_1


    return
    label tightjob:
    scene bg adamAndAlice with dissolve
    Alice "How does my hand feel?"
    
    image alicehand = Movie(play="images/animation/Vids ALICE/hand0001-0040-goqtam.webm", loop=True)
    show alicehand 

    p "I haven't had sex in a while"
    p "I might not be able to hold myself"
    Alice "And why would you?"
    pause
    scene bg render343 with dissolve
    Alice "You can do whatever you want with me"
    pause
    scene bg render344 with dissolve
    p "Come here"
    

    image alicetight = Movie(play="images/animation/Vids ALICE/tight0001-0039-eoluyl.webm", loop=True)
    show alicetight 
    
    pause
    p "FUCK!"
    Alice "Yeah [p], fuck my tighs"
    Alice "This is making me so wet, don't stop"

    

    
    image alicetighttwo = Movie(play="images/animation/Vids ALICE/tight20001-0040-bgutya.webm", loop=True)
    show alicetighttwo 
    p "Fuck, can we..."
    Alice "No!"
    p "Just the tip..."
    Alice "Hmmm!"
    p "Shit I am cumming"
    pause

    scene bg render345 with dissolve
    pause
    scene bg render346 with dissolve
    pause
    scene bg render347 with dissolve
    pause
    scene bg render346 with dissolve
    pause
    scene bg render348 with dissolve
    Alice "That was... quite fun"
    Alice "Too bad you came so fast... maybe next time"
    scene bg render349 with dissolve
    Alice "Don't forget to clean this mess"
    scene bg AliceAndAdam3 with dissolve
    p "Fuck..." 
    jump game

    label hides:
    scene bg AliceAndAdam with dissolve
    p "Sorry, I can't"
    scene bg AliceAndAdam2 with dissolve
    Alice "Oh..."
    Alice "Okay, my bad"
    scene bg AliceAndAdam3 with dissolve
    p "Shit"
    

    label game:


    play music "audio/ambient-noise-236388.mp3"
    scene bg emi with fade
    pause
    scene bg emi2 with dissolve
    pause
    scene bg emi3 with dissolve
    pause
    scene bg emi4 with dissolve
    p "Hey!"
    scene bg emi5 with dissolve
    p "How is my favorite person?"
    scene bg emi6 with dissolve
    p "How can you look so pretty even trapped here for months?"
    scene bg emi7 with dissolve
    Emily "Aren't you forgetting something?"
    scene bg emi8 with dissolve
    p "Of course, your good morning kiss"
    scene bg emi9 with dissolve
    pause
    scene bg emi10 with dissolve
    play sound "audio/kisst.mp3"
    pause
    scene bg emi12 with dissolve
    pause
    scene bg emi13 with dissolve
    Sara "I didn't know you guys were so close"
    Sara "That's cute."
    scene bg emi14 with dissolve
    p "Don't worry, I have good morning kisses for you too"
    scene bg emi15 with dissolve
    pause
    p "* Shit, she must be missing him so much *"
    scene bg emi16 with dissolve
    p "Sara, I'm sorry"
    scene bg emi17 with dissolve
    p "We all miss them but let's focus on surviving okay."
    scene bg emi18 with dissolve
    pause
    scene bg emi19 with dissolve
    pause
    scene bg render350 with dissolve
    stop music
    play music "audio/spooky-vending-machine-hum-20000.mp3"
    pause
    scene bg render351 with dissolve
    Luna "Hum hum hum"
    scene bg render352 with dissolve
    Luna "Hmm, that's new"
    scene bg render353 with dissolve
    p "Okay.."
    scene bg render354 with dissolve
    Luna "Ah! [MainLunaRelation]"
    scene bg render355 with dissolve
    p "Why is everyone walking naked around the house?"
    scene bg render356 with dissolve
    pause
    scene bg render357 with dissolve
    Luna "THIS PLACE IS FUCKING HOT"
    Luna "Uncle Tom, forgot to put some AC down here"
    scene bg render358 with dissolve
    Luna "But that's not important right now"
    Luna"Running diagnosis"
    

    
    image assShaking = Movie(play="images/animation/Vids ALICE/lunaassshake0001-0030-qtkma5.webm", loop=True)
    scene black
    show assShaking 
    pause
    Luna "Hum hum hum"
    Luna "Just a little while longer"
    
    scene bg render359 with dissolve
    Luna "Ah! NO WAY!"
    scene bg render360 with dissolve
    Luna "Do you know what that means?"
    scene bg render361 with dissolve
    pause
    scene bg render362 with dissolve
    pause
    scene bg render363 with dissolve
    pause
    scene bg render364 with dissolve
    p "It means let's get the fuck out of here"
    stop music
    scene bg render365 with dissolve
    Emily "I don't think our food is going to last much longer"
 
    scene bg render367 with dissolve
    Emily "We should start talking about what to do"
    scene bg render368 with dissolve
    pause
    scene bg render369 with dissolve
    Sara "I am sure [player_name] knows what to do"
    scene bg render370 with dissolve
    Anne "Our food?"
    scene bg render371 with dissolve
    Anne "What could we do?"
    scene bg render372 with dissolve
    Sara "it's not like we didn't know it would come to this point"
    scene bg render373 with dissolve
    p "Well, how do I put this"
    scene bg render374 with dissolve
    p "Let's leave this place"
    scene bg render375 with fade
    play music "audio/spooky-vending-machine-hum-20000.mp3"
    Luna "As we all know, whatever happened up there made the atmosphere unbreathable"
    scene bg render376 with dissolve
    Luna "But this morning when I ran Uncle Tom's software it showed that it's safe to leave this bunker"
    scene bg render377 with dissolve
    Luna "Now we just need to figure out when and where to go"
    scene bg render378 with dissolve
    p "Let's pack everything we might need."
    p "I know exactly where to go"
    stop music
    scene bg render379 with fade
    pause
    p "My dad's house."
    scene bg render380 with dissolve
    p "It's far from the city, there are mountains nearby, perfect for planning and I know there's a lot of resources there"
    scene bg render381 with dissolve
    p "I don't know how are things up there, we lost signal the moment we got here"
    p "So we better be ready for everything"
    scene bg render382 with dissolve
    p "But one thing I know. I will protect all of you, I promise."
    scene bg render383 with dissolve
    Anne "Honey!"
    scene bg render384 with dissolve
    pause
    scene bg render385 with dissolve
    pause
    scene bg render386 with dissolve
    p "It's okay baby, I'll keep us safe"
    scene bg render387 with dissolve
    Anne "Are you okay Emily? I'll help you pack"
    scene bg render388 with dissolve
    Emily "Yeah, I am just happy to leave this place"
    scene bg render389 with dissolve
    Emily "It's been a while since I went to grandpa's house"
    Anne "Let's hope it's still there"
    scene bg render390 with dissolve

    play music "audio/sensual-night-sexy-music-nights-311624.mp3" fadein 0.8
    p "I thought I would never do this again"
    p "This time is different"
    scene bg render391 with fade
    Emily "How exactly are we getting there?"
    Emily "On foot?"
    scene bg render392 with dissolve
    Emily "It could take days"
    scene bg render393 with dissolve
    Luna "Don't worry about it, your dad has figured that out for us"
    Emily "What are you talking a-"
    scene bg render394 with dissolve
    pause
    scene bg render395 with dissolve
    Emily "Wow!"
    pause
    scene bg render396 with dissolve
    pause

    scene bg render397 with dissolve
    p "I need to be ready for anything"
    scene bg render399 with dissolve
    play sound "audio/password-lock-noise-362605.mp3"
    Luna "Okay, let's see if I got it right"
    scene bg render400 with dissolve
    Luna "Thanks Uncle Tom"
    scene bg render401 with dissolve
    Luna "Let's go"
    scene bg render402 with dissolve
    stop music fadeout 0.6
    pause
    scene bg render403 with dissolve
    pause
    scene bg render404 with dissolve
    pause
    scene bg render405 with dissolve
    play music "audio/motor-loop-83480.mp3"
    pause
    scene bg render406 with dissolve
    pause
    scene bg render407 with dissolve
    stop music 
    pause
    scene bg render408 with dissolve
    pause
    scene bg render409 with dissolve
    pause
    scene bg render410 with dissolve
    pause
    scene bg render411 with dissolve
    pause
    scene bg render412 with dissolve
    p "There's no time to waste"
    scene bg render413 with dissolve
    p "Get in the car, I'll be there in a sec"
    scene bg render414 with dissolve
    play sound "audio/walk.mp3"
    play sound "audio/running-363346.mp3" 
    pause
    scene bg render415 with dissolve
    play music "audio/014815_building-tension-56926.mp3"
    pause
    Emily "* Dad *"

    pause
    scene bg render416 with dissolve
    Alice "EMILY! LET'S GO. NOW!"
    scene bg render417 with dissolve
    play sound "audio/garage.mp3"
    pause
    play sound "audio/car-door-close-6929.mp3"
    scene bg render418 with dissolve
    pause
    play sound "audio/car-door-close-6929.mp3"
    scene bg render419 with dissolve
    pause
    scene bg render420 with dissolve
    p "Everyone ready?"
    scene bg render421 with dissolve
    play sound "audio/car-engine-start-outside-72279.mp3"
    pause
    scene bg render422 with dissolve
    pause
    scene bg render423 with dissolve
    pause
    scene bg render424 with dissolve
    pause
    scene bg render425 with dissolve
    stop music fadeout 0.6
    play music "audio/car-driving-ambience-6365.mp3"
    pause
    scene bg render426 with dissolve
    p "Things went pretty bad up here"
    scene bg render427 with dissolve
    p "Don't worry girls I know what to do"
    p "Baby, did your Uncle wrote anything about Dad's house on that diary?"
    
    scene bg render428 with dissolve
    Luna "Actually yeah, he did"
    scene bg render429 with dissolve
    p "Great, let's hope the house is still there"
    play sound "audio/car.mp3" fadein 0.4
    scene bg render431 with dissolve
    play music "audio/tension-443113.mp3"
    pause
    scene bg render432 with dissolve
    pause
    p "What the fuck happened here?"
    scene bg render433 with dissolve
    Anne "Oh my god... Wha-"
    scene bg render434 with dissolve
    Emily "Mom, what is going on?"
    scene bg render435 with dissolve
    Sara "It's okay sweety"
    scene bg render436 with dissolve
    Anne "Did everyone..."
    scene bg render438 with dissolve
    play sound "audio/monster-roar-02-102957.mp3"
    "*Scream*"
    scene bg render439 with dissolve
    Emily "WHAT IS THIS?"
    Anne "DRIVE!"
    Alice "WE NEED TO GO."
    p "I know."
    play sound "audio/car-engine-roaring-376881.mp3"
    scene bg render440 with fade
    pause
    scene bg render441 with dissolve
    pause
    scene bg render443 with dissolve
    pause
    scene bg render444 with dissolve
    play sound "audio/car.mp3" fadein 0.5
    pause
    scene bg render445 with dissolve
    pause
    scene bg render446 with dissolve
    pause
    scene bg render447 with dissolve
    pause
    scene bg render448 with dissolve
    p "Okay"
    scene bg render449 with dissolve
    p "You are going to stay here while I go check the house"
    scene bg render450 with dissolve
    p "Don't leave this car until I say so."
    p "Especially if you hear gunshots"
    scene bg render451 with dissolve
    play sound "audio/car-door-close-6929.mp3"
    pause
    play sound "audio/concrete-footsteps-1-6265.mp3"
    scene bg render452 with dissolve
    pause
    scene bg render453 with dissolve
    play sound "audio/door-creaking-335491.mp3"
    pause
    scene bg adamDoOver with dissolve
    play sound "images/st2-footstep-sfx-323055.mp3"
    pause
    scene bg adamDoOver2 with dissolve
    pause
    scene bg render454 with dissolve
    play sound "images/st2-footstep-sfx-323055.mp3"
    pause
    scene bg render455 with dissolve
    play sound "images/st2-footstep-sfx-323055.mp3"
    pause
    scene bg render456 with dissolve
    play sound "images/st2-footstep-sfx-323055.mp3"
    pause
    scene bg render457 with dissolve
    play sound "images/st2-footstep-sfx-323055.mp3"
    stop music
    play sound "audio/susto.mp3"
    pause
    p "FUCK!"
    scene bg render458 with dissolve
    play music "audio/jump-scare_6-28636.mp3"
    pause
    scene bg render459 with dissolve
    play sound "audio/zombie-sound-2-357976.mp3"
    pause
    play sound "audio/zombatack.mp3"
    scene bg render460 with dissolve
    pause 
    scene bg render461 with dissolve
    play sound "audio/gun-shot-1-7069.mp3"
    pause
    stop music
    play sound "audio/freesound_community-body-fall-47877.mp3"
    scene bg render462 with dissolve
    pause
    scene bg render463 with dissolve
    play music "audio/scary-sound-suspense-314626.mp3" 
    p "Shit"
    scene bg render464 with dissolve
    p "This is worst then I thought"
    stop music

    scene bg render464 with dissolve
    pause

    scene black 
    pause 0.5
    scene bg render465 with dissolve
    play sound "audio/st2-footstep-sfx-323055.mp3"
    pause
    scene bg render466 with dissolve
    play sound "audio/st2-footstep-sfx-323055.mp3"
    pause
    scene bg render467 with dissolve
    play sound "audio/st2-footstep-sfx-323055.mp3"
    pause
    play sound "audio/alesiadavina-horror-sound-lurking-horror-monster-189948.mp3"
    scene bg render468 with fade
    pause
    stop sound
    scene bg render469 with dissolve
    pause
    scene bg render470 with dissolve
    p "This place is weird"
    scene bg render471 with dissolve
    play sound "audio\freesound_community-indoor-footsteps-6385.mp3"
    pause
    scene bg render472 with dissolve
    pause
    scene bg render473 with dissolve
    pause
    play sound "audio/universfield-computer-mouse-click-352734.mp3"
    scene bg render474 with dissolve
    p "Come on"
    scene bg render475 with dissolve
    play music "audio/freesound_community-generator-87782.mp3"
    pause
    p "YES"
    pause
    scene bg render476 with dissolve
    pause
    scene bg render477 with dissolve
    p "Okay... This is something"
    scene bg render478 with dissolve
    play sound "audio/st2-footstep-sfx-323055.mp3"
    pause
    scene bg render479 with dissolve
    play sound "audio/st2-footstep-sfx-323055.mp3"
    pause
    scene bg render480 with dissolve
    stop music
    pause
    scene bg render481 with dissolve
    pause
    scene bg render482 with dissolve
    p "So many memories"
    scene bg render483 with dissolve
    p "*THINKING* Mom..."
    scene bg render484 with dissolve
    pause

    scene bg render485 with dissolve
    pause
    scene black 
    pause 0.5
    scene bg render486 with dissolve
    Emily "Am I the only one that thinks we should look for him?"   
    scene bg render487 with dissolve
    Anne "Honey, we have to trust him"
    scene bg render488 with dissolve
    Anne "If we go in we will only make things harder for him right know"
    scene bg render489 with dissolve
    Emily "But how can you know that? "
    scene bg render490 with dissolve
    Emily "What if he is stuck or got shot?"
    scene bg render491 with dissolve
    Emily "He could be in danger"
    Luna "Emi, calm down"
    scene bg render492 with dissolve
    Alice "He's back"
    scene bg render493 with dissolve
    pause
    Sara "Finally!"
    scene bg render494 with dissolve
    pause
    play sound "audio/car-door-close-6929.mp3"
    scene bg render495 with dissolve
    Alice "[player_name], What happened? we heard a gunshot"
    scene bg render496 with dissolve
    p "Hey pretty, don't worry. Everything is fine"
    scene bg render497 with dissolve
    Anne "Honey, what happened?"
    scene bg render498 with dissolve
    p "I believe it will be easier if I show you"
    p "Come on in"
    scene bg render499 with dissolve
    pause
    scene bg render500 with dissolve
    p "Here"
    scene bg render501 with dissolve
    p "When I got here, it was dark but I saw..."
    scene bg render502 with dissolve
    p "A creature, it looked like human but dead and alive at the same time."
    scene bg render503 with dissolve
    p "And when it attacked me I shot it"
    scene bg render504 with dissolve
    p "I have no idea how he got inside but something tells me it's been here for a while"
    scene bg render505 with dissolve
    Alice  "But... where is it?"
    scene bg render506 with dissolve
    Anne "Don't tell me it came back to life"
    scene bg render507 with dissolve
    p "Don't worry, it's as dead as it gets. I also cleared the rest of the house"
    scene bg render508 with dissolve
    p "It's safe, come with me"
    scene bg render509 with dissolve
    pause
    scene bg render510 with dissolve
    pause
    Luna "No way I am ever going down there"
    pause
    Alice "Did you move his body to the backyard?"
    scene bg render511 with dissolve
    pause
    scene bg render512 with dissolve
    Anne "How come this place is so clean?"
    scene bg render513 with dissolve
    p "You can explore the house later, come"


    scene bg render514 with dissolve
    pause




    scene black
    play movie "images/0001-0442.ogv"
    $ renpy.pause(15, hard=True)
    stop movie




    scene bg render515 with dissolve
    pause
    scene bg render516 with dissolve
    pause
    Emily "Let's go sis"
    scene bg render517 with dissolve
    pause
    scene bg render518 with dissolve
    Anne "Oh my god!"
    scene bg render519 with dissolve
    pause
    scene bg render520 with dissolve
    pause
    scene bg render521 with dissolve
    Emily "Is this a freaking-"
    scene bg render522 with dissolve
    Luna "Zombie"
    scene bg render523 with dissolve
    pause
    scene bg render524 with dissolve
    Sara "I think we should all head inside"
    scene bg render525 with dissolve
    pause
    scene bg render526 with dissolve
    p "Yeah, I'll be right there. Let me deal with this"
    scene bg render527 with dissolve
    Sara "Girls, listen to everything your [EmiAliceRelation] says and stay close to each other"
    scene bg render528 with dissolve
    Sara "Things were difficult enough without monsters running around"
    scene bg render529 with dissolve
    Emily "Alice said everyone we knew is dead"
    scene bg render530 with dissolve
    Sara "Honey, we can't know that, stop saying things"
    scene bg render531 with dissolve
    Sara "The only thing that matters is that we have each other"
    scene bg render532 with dissolve
    p "Can I join?"

    label choice_scene:
        menu:
            "Take advantage":
                jump take_advantage

            "Don't":
                jump dont_take

    label take_advantage:
    scene bg render533 with dissolve
    pause
    scene bg render534 with dissolve
    pause
    scene bg render535 with dissolve
    pause
    scene bg render536 with dissolve
    pause
    scene bg render537 with dissolve
    pause
    scene bg render538 with dissolve
    pause
    scene bg render539 with dissolve
    Sara "* Is he hard? *"  
    scene bg render540 with dissolve
    Sara "* That's quite big *"
    pause

    label dont_take:
    scene bg render541 with dissolve
    p "Hey pretty!"
    label kissLuna:
        menu:
            "Kiss your [LunaRelation]":
                jump Kis

            "Don't":
                jump DontK

    
    label Kis:
    scene bg render542 with dissolve
    pause
    scene bg render543 with dissolve
    pause 
    play sound "audio/kisst.mp3"
    scene bg render544 with dissolve
    pause
    scene bg render545 with dissolve

        

    label DontK:
    scene bg render546 with dissolve
    p "Okay, I wanna make a few things clear."
    p "There are Three bedrooms upstairs and one behind me."
    scene bg render547 with dissolve
    p "There is no need to say that we are all sleeping on the second floor close to each other."
    p "Tomorrow, I am going to the city. I need a few things to keep us safer for longer"
    scene bg render548 with dissolve
    p "I won't be able to keep an eye on you all the time, so when I am not around you are only doing things in pairs or more, NEVER alone"
    scene bg render549 with dissolve
    p "There are still a few things left on the car, we brought food but there is plenty here as well. make yourselves comfortable, we are staying for a while."
    scene black 
    pause 0.5
    scene bg render550 with dissolve
    Anne "Where is this food he was talking about?"
    scene bg render551 with dissolve
    Anne "There is nothing here"
    scene bg render552 with dissolve
    pause
    scene bg render553 with dissolve
    pause
    scene bg render554 with dissolve
    p "Hey cupcake, how you doing?"
    scene bg render555 with dissolve
    Alice "Hi, it's alright I guess, the bed is a bit small but it's fine"
    scene bg render556 with dissolve
    Alice "There's a lot of clean clothes here so that's nice."
    p "Tell me if you need anything. Where is your sister?"
    scene bg render557 with dissolve
    Alice "Well, she just realized there's water running"
    scene bg render558 with dissolve
    Alice "I am waiting for her to shower next"
    scene bg render559 with dissolve
    pause
    scene bg render560 with dissolve
    Emily "Hum Hum Hum"
    scene bg render561 with dissolve
    play sound "audio/fast-knocking-on-door-352704.mp3"
    pause
    Emily "Come on in, I'm done"
    play sound "audio/soundreality-opening-door-411632.mp3"
    scene bg render562 with dissolve
    Emily "Sorry I took a while, the water was so nice"
    scene bg render563 with dissolve
    Emily "I won't take long"
    scene bg render564 with dissolve
    pause
    scene bg render565 with dissolve
    Emily "Ahh!"
    scene bg render566 with dissolve
    Emily "[EmiAliceRelation] [player_name], I didn't know it was you."
    Emily "I.."
    scene bg render567 with dissolve
    Emily "THINKING *Why is he taking his gloves off?*"

    play music "audio/elijah_k-sensual-fire-337750.mp3"

    scene bg render568 with dissolve
    Emily "Hmm"
    scene bg render569 with dissolve
    Emily "You really like them, don't you"
    scene bg render570 with dissolve
    pause
    scene bg render571 with dissolve
    p "Baby, are you sure?"
    scene bg render572 with dissolve
    Emily "Shhh, I know you want this too"
    Emily "Sit right there"
    scene bg render573 with dissolve
    Emily "Wow!"
    Emily "That is so big, I'm not sure it fits in my mouth"
    scene bg render574 with dissolve
    Emily "I bet it probably fits here"
    Emily "Let me try"
    scene bg render575 with dissolve
    pause
    
    scene bg render576 with dissolve
    Emily "How does Aunt Anne do it?"


    image intro_video = Movie(play="images/emilys/boobs0001-0120-yrxcla.webm", loop=True)
   
    show intro_video with dissolve
    $ renpy.pause(10)
    Emily "Does it feels good?"
    p "Yeah!"
    Emily "I've never done this before. At least I know I can make you feel good like this"
    Emily "But I wanna taste it"
    

    scene bg render577 with dissolve
    Emily "Can I?"
    p "Yeah!"

    play sound "audio/sucking.mp3" loop
    scene black



    play movie "images/emilys/start0001-0034-it22aj.webm"
    $ renpy.pause(1)
    image EmiBlow = Movie(play="images/emilys/blowjob-n3agrt.webm", loop=True)
    with dissolve
    scene black
    show EmiBlow
    with dissolve
    pause
    p "Fuck!"
    p "Don't stop baby"

    image EmiBelow = Movie(play="images/emilys/below-ekkdqi.webm", loop=True)
    with dissolve
    scene black
    show EmiBelow
    with dissolve
    p "I might get addicted to fucking this pretty mouth"


    image FuckingLips = Movie(play="images/emilys/fuckinglips-vhbc7r.webm", loop=True)
    scene black
    show FuckingLips
    p "You are doing great sweetie"
    p "*It's taking all my willpower not to shove it down her throat*"
    p "I am almost cumming"
    stop sound
    pause
    play sound "audio/slurp.mp3" loop

   
    image Cumming = Movie(play="images/emilys/cumming0001-0120-mfyf4y.webm", loop=True)
    scene black
    show Cumming
    Emily "Cum for me"
    pause
    p "Shit, i'm cumming"

    label Cum:
        menu:
            "Cover her face":
                jump Facial

            "Let her swallow":
                jump drinkIt


    label Facial:
    stop sound
    play sound "audio/jet.mp3"
    scene bg render579 
    with dissolve
    pause .2
    scene bg white
    pause 0.2
    play sound "audio/jet.mp3"
    scene bg render579 
    with dissolve
    pause .2
    play sound "audio/jet.mp3"
    scene bg white
    pause 0.2

    scene bg render580 
    with dissolve
    pause
    scene bg render581 
    with dissolve
    Emily "Wow, So much!"
    pause
    scene bg render586
    with dissolve
    pause
    scene bg render587
    with dissolve
    pause
    scene bg render588
    with dissolve
    pause
    scene bg render589
    with dissolve
    pause
    scene bg render590
    with dissolve
    pause
    scene bg render591
    with dissolve
    jump Fac

    label drinkIt:
    stop sound
    play sound "audio/jet.mp3"
    scene bg render582 
    with dissolve
    pause
    scene bg render583 
    pause
    play sound "audio/gulp.mp3"
    with dissolve
    pause 2
    scene bg render584 
    with dissolve
    Emily "Did you enjoy it?"
    Emily "It was my first time doing something like this"
    scene bg render585 
    with dissolve
    p "I loved it baby. "
    pause

    label Fac:
    scene bg render592
    with dissolve
    Emily "Since you are here i need you to help me chose one of those outfits"
    p "*Shit, i'm still rock hard*  "
    scene bg render593
    with dissolve
    Emily "Wha- you are..."

    image Emirub = Movie(play="images/emilys/emilysex0001-0054-yxcugi.webm", loop=True)
    show Emirub
    pause
    Emily "It's so hot and hard"
    pause

    scene bg render594
    with dissolve
    Emily "*Fuuuck! Why being choked feels so good?*"
    scene bg render595
    with dissolve
    p "Can you help me again baby?"
    scene bg render596
    with dissolve
    Emily "You can do whatever you want with me" 
    scene bg render597
    with dissolve
    p "*Her body is so soft, I'm going to lose it*"


    image EmiTighs = Movie(play="images/emilys/tigh.webm", loop=True)
    show EmiTighs
    pause
    Emily "Hmmm This feels so good"
    Emily "You are rubbing all the right places"
    pause
    image EmiTigh = Movie(play="images/emilys/tighs.webm", loop=True)
    show EmiTigh
    pause
  
    scene bg render598
    with dissolve
    pause
    scene bg render599
    with dissolve
    Emily "Are you going to take my first time?"
    scene bg render600
    with dissolve
    pause
    scene bg render601
    with dissolve
    pause
      
    label EmiFirst:
    menu:
        "Take her first time in the bathroom right now":
            jump Bathtub

        "Her first time shouldn't be in a bathroom.":
            jump Wait


    label Bathtub:
    scene black
    scene bg render602
    with dissolve
    pause
    scene bg render603
    with dissolve
    pause
    scene bg render604
    with dissolve
    pause
    scene bg render605
    with dissolve
    pause 
    scene bg render606
    with dissolve
    Emily "What are you waiting for?"
    scene bg render607
    with dissolve
    pause
    play sound "audio/knocking-door-wc-394936.mp3"
    scene bg render608
    with dissolve
    Alice "Emily! How much longer are you going to make me wait?"
    scene bg render609
    with dissolve
    p "Emily is not here baby, I'll be out in a minute."
    Alice "Oh, okay. Sorry"
    scene bg render610
    with dissolve
    pause
    scene bg render611
    with dissolve
    p "Sorry baby. I guess we'll have to wait for a better chance"
    p "Such a shame."
    image Emirubp = Movie(play="images/emilys/emilysextwo0001-0043-zt9p2f.webm", loop=True)
    show Emirubp
    p "I'm really turned on"
    Emily "Hmmm"
    Emily "Just the tip, put it in"
    p "If I do that we are not leaving anytime soon baby."
    pause



    scene bg render612
    with dissolve
    p "let's go before someone misses us"
    scene bg render613
    with dissolve
    pause
    stop music fadeout 1.5
    jump Keepgoing

    label Wait:
    scene bg render599
    with dissolve
    p "Not right now okay baby? I want to make it special"
    $ renpy.notify("Emily Will remember this")
    Emily "Right, I love you"
    p "I love you too baby"
    $ emipts = True
    pause 2
    stop music

    label Keepgoing:
    scene bg render614
    with dissolve
    pause
    scene bg render615
    with dissolve
    pause
    scene  black
    pause .9
    scene bg render616
    with dissolve
    Anne "I was looking for you"
    scene bg render617
    with dissolve
    p "What happened?"
    Anne "Nothing I just-"
    scene bg render618
    with dissolve
    p "When was the last time we had fun?"
    scene bg render619
    with dissolve
    Anne "I... Honey I "
    scene bg render620
    with dissolve
    Anne "I need to talk to you stop distracting me"
    Anne "You said there's planty of food here but I couldn't find any"
    scene bg render621
    with dissolve
    p "Is that so?"
    p "Follow me."

    scene bg render622
    with dissolve
    pause
    scene bg render623
    with dissolve
    pause
    scene bg render624
    with dissolve
    pause
    Anne "What are we doing here?"
    scene bg render625
    with dissolve
    pause
    scene bg render626
    with dissolve
    Anne "What the-"
    scene bg render627
    with dissolve
    pause
    scene bg render628
    with dissolve
    p "Where do you think Tom learned to build a bunker?"
    scene bg render629
    with dissolve
    p "Dad was just as paranoid as he was"
    scene bg render631
    with dissolve
    pause
    scene black
    pause .9
    play music "audio/audiopapkin-rain-and-little-storm-298087.mp3"
    scene bg render632
    with dissolve
    pause
    scene bg render634
    with dissolve
    Alice "It makes sense"
    scene bg render635
    with dissolve
    pause
    scene bg render636
    with dissolve
    Emily "So you are saying that everyone else except us is dead?"
    scene bg render637
    with dissolve
    Emily "I can't believe that"
    scene bg render638
    with dissolve
    Alice "The sooner we accept it, the better"
    scene bg render639
    with dissolve
    Alice "Think about it, on the way here we heard nothing but that weird scream"
    scene bg render640
    with dissolve
    Alice "I am sure it was one of those monster like the one [p] killed"
    scene bg render641
    with dissolve
    Alice "We need to assume the worst case scenario"
    scene bg render642
    pause 1.0
    play sound "audio/thunder.mp3"
    scene bg render643
    with dissolve
    Emily "Aaaaargh!" 
    pause .5
    scene bg render644
    with dissolve
    Emily "Shit" 
    scene bg render645
    with dissolve
    Alice "Emily, chill out."
    scene bg render646
    with dissolve
    Luna "The power is back, good"
    scene bg render647
    with dissolve
    Sara "Girls, time to sleep, come on. Luna, you are sleeping with me"
    scene bg render648
    with dissolve
    Luna "Good night girls"
    stop music
    scene black
    pause .5
    scene bg render649
    with dissolve
    pause
    Emily "*I can't sleep*"
    scene bg render650
    with dissolve
    Emily "*I wonder if they would let me sleep with them *"
    Emily "*I would feel better cuddling with him*"
    scene bg render651
    with dissolve
    pause
    scene bg render652
    with dissolve
    pause
    play music "audio/moaning wife.mp3"
    scene bg render653
    with dissolve
    pause 
    scene bg render654
    with dissolve
    pause

    image Annes = Movie(play="images/Annes/anne0001-0039-fiib87.webm", loop=True)
    show Annes
    pause
    Anne "I'm cumming"
    pause


    scene bg render656
    with dissolve
    pause

    scene bg render655
    with dissolve
    pause


    stop music
    scene bg render657
    with dissolve
    pause
    p "You are perfect"
    
    play music "audio/wet slow.mp3"

    image AnneMiss = Movie(play="images/Annes/annemissionary0001-0040-f5layy.webm", loop=True)
    show AnneMiss
    pause
    Anne "Fuck! I love you so much honey"
    pause
    Anne "Harder please"
    
    image AnneMissBetter = Movie(play="images/Annes/annemissionarybetter0001-0052-ckaqt0.webm", loop=True)
    show AnneMissBetter
    play sound "audio/moaning wife.mp3"
    pause

        
    image AnneMissPov = Movie(play="images/Annes/annemissionarypov0001-0039-ecjttr.webm", loop=True)
    show AnneMissPov
    pause
    p "I'm close"
    Anne "You're gonna make me cum again"
    pause

    scene bg render658
    with dissolve
    pause

    scene bg render659
    with dissolve
    pause
    Emily "* That must be really good *"
    scene bg render660
    with dissolve
    pause
    p "Fuuuuuck!"

    stop music
    stop sound
    scene bg render661
    with dissolve
    pause
    scene bg render662
    with dissolve
    pause
    scene bg render663
    with dissolve
    pause
    scene bg render664
    with dissolve
    pause
    scene bg render665
    with dissolve
    pause
    Anne "Do you really need to leave so early?"
    p "The sooner I go, the sooner I'll be back"
    scene bg render666
    with dissolve
    Anne "You didn't even get a chance to say goodbye to the girls."
    scene bg render667
    with dissolve
    Anne "What is so important for you to risk our lives in it?"
    scene bg render668
    with dissolve
    p "Love, i told you. I need one of Tom's tech to keep us safe for longer"
    p "I'll be back before the girls wake up."
    p "Love you!"
    play music "audio/car-driving-ambience-6365.mp3"
    scene bg render669
    with dissolve
    pause
    scene bg render670
    with dissolve
    pause

    scene bg horde1 with dissolve
    pause
    scene bg horde2 with dissolve
    pause
    scene bg horde3 with dissolve
    pause
    scene bg horde4 with dissolve
    Unknown "Another asshole thinkig this is Disneyland"
    
    scene black
    pause 0.5

    scene bg render671
    with dissolve
    pause
    scene bg render672
    with dissolve
    pause
    scene bg render673
    with dissolve
    stop music
    play music "audio/india_happy-a-suspense-suspense-music-494843.mp3"
    pause
    scene bg render674
    with dissolve
    pause
    p "*No movement since I left*"
    scene bg render675
    with dissolve
    p "Let's get this over with"
    scene bg render676
    with dissolve
    pause
    scene bg render677
    with dissolve
    pause
    scene bg render678
    with dissolve
    pause
    scene bg render679
    with dissolve
    pause
    scene bg render680
    with dissolve
    pause
    scene bg render681
    with dissolve
    pause
    scene bg render682
    with dissolve
    pause
    play sound "audio/floraphonic-exploding-building-1-185114.mp3"
    stop music
    scene bg render683
    with dissolve
    pause 0.5
    scene bg render684
    with dissolve
    pause 0.5
    play music "audio/WARLORD.mp3"
    scene black
    pause
    scene bg render686
    with dissolve
    pause
    scene bg render687
    pause
    p "* Shit! *"
    scene bg render688
    with dissolve
    pause
    scene bg render689
    with dissolve
    p "Water?"
    pause
    play sound "audio/water.mp3"
    scene bg render690
    with dissolve
    pause
    scene bg render691
    with dissolve
    p "This place is flooded"
    scene bg render692
    with dissolve
    pause
    p "How the hell am I getting back up?"
    scene bg render693
    with dissolve
    pause
    play sound "audio/freesound_community-zombie-growl-3-6863.mp3"
    scene bg render694
 
    pause
    scene bg render695
  
    p "Fuck!"
    scene bg render696
  
    p "Here we go again"
    scene bg render697

    p "Sleep tight"
    play sound "audio/dragon-studio-zombie-screech-sound-effect-312865.mp3"
    scene bg render698

    pause 0.5
    scene bg render700

    pause 0.5
    play sound "audio/ribhavagrawal-gun-shots-230534.mp3"
    scene bg render701
  
    pause
    scene bg render702
  
    pause
    play sound "audio/dragon-studio-zombie-scream-324752.mp3"
    scene bg render703
  
    pause
    play sound "audio/fires.mp3"
    scene bg render704

    pause
    play sound "audio/laugh.mp3"
    scene bg render706
  
    pause
    play sound "audio/fires.mp3"
    scene bg render705

    pause
    scene bg render707
 
    pause
    scene bg render708
  
    pause .5
    play sound "audio/freesound_community-holster-pistol-7132.mp3"
    scene bg render709

    pause 0.5
    scene bg render710

    pause
    play sound "audio/freesound_community-single-pistol-gunshot-3-101923.mp3"
    scene bg render711
  
    pause
    scene bg render712

    pause
    scene bg render713

    pause
    play sound "audio/freesound_community-single-pistol-gunshot-3-101923.mp3"
    scene bg render714

    pause .5
    scene bg render713

    pause
    play sound "audio/freesound_community-holster-pistol-7132.mp3"
    scene bg render715

    pause
    scene bg render716

    pause
    p "Okay... That was easier then i-"
    play sound "audio/muckMonster.mp3"
    scene bg render717
    pause
    scene bg render718
    pause
    scene bg render719
  
    pause
    scene bg render720

    pause
    p "What in the fucking..."
    scene bg render721

    pause
    play sound "audio/Muck.mp3"
    scene bg render722

    pause
    scene bg render723

    pause
    



    scene bg render725
    pause
    scene bg render726
    pause
    scene bg render727
    pause
    p "Fuck no"
    scene bg render728
    pause
    play sound "audio/jammed.mp3"
    pause
    scene bg render729
    pause
    p "No fucking way it's jammed"
    scene bg render730
    pause
    Unknown "HEY Asshole. CATCH!"
    play sound "images/dragon-studio-sword-slice-2-393845.mp3"
    scene bg render731
  
    pause
    p "A sword?"
    p "FUCK IT!"
    scene bg render732

    p "AAAAHh!"
    scene bg render733

    pause
    scene bg render734
    with dissolve
    pause
    scene bg render735
    with dissolve
    pause
    play sound "audio/dragon-studio-violent-sword-slice-393839.mp3"
    scene bg render736
    with dissolve
    pause
    scene bg render737
    with dissolve
    pause




    
    scene bg render738
    with dissolve
    pause
    scene bg render739
    with dissolve
    pause
    scene bg render740
    with dissolve
    pause
    scene bg render741
    with dissolve
    pause
    scene bg render742
    with dissolve
    pause 0.5
    play sound "images/dragon-studio-sword-slice-2-393845.mp3"
    scene bg render743
    with dissolve
    pause .5

    scene bg render744
    with dissolve
    pause .5

    scene bg render745 with dissolve
  
    scene bg render746 with dissolve
    pause
    stop music fadeout 1.5
    Unknown "Hey, wanna take a nap? There might be more" 
    scene bg render747 with dissolve
    pause
    scene bg render748 with dissolve
    pause
    scene bg render749 with dissolve
    Unknown "I'll help you up come on"
    scene bg render750 
    p "Thank you"
    scene bg render751 
    pause
    scene bg render752 
    pause
    scene bg render753
    pause
    scene bg render754 
    pause
    p "Thanks for saving me, my name is [p]"
    scene bg render755 
    p "How should I call you?"
    scene bg render756
    pause
    "..."
    scene bg render757 
    pause
    Mei "You can call me Mei"
    scene bg render758 
    Mei "Can you give me back my sword?"
    scene bg render759 
    p "Yeah sorry, here"
    scene bg render760 
    Mei "[p], whatever you are looking for here you won't find it"
    scene bg render761 
    p "What?"
    scene bg render762 
    Mei "This place has been looted at least a dozen times"
    Mei "I did it myself once"
    Mei "This is creeper territory."
    scene bg render763 
    Mei "To be honest I didn't save you out of mere kindness."
    scene bg render764 
    Mei "But this is not a good place to talk"
    scene bg render765
    Mei "Can you come with me?"
    scene bg render766 
    pause
    Unknown "* I've got your back sis *"
    scene bg render767
    pause
    play music "audio/Draknar.mp3" fadein 1.5

    scene bg render768
    Mei "So... As i was saying"
    scene bg render769
    pause
    scene bg render770
    p "Wait, you said something about Creepers, is that a group of survivors?"
    scene bg render771
    Mei "Y-Yeah... You've never met them? lucky you I guess. It's the worst local group and the strongest "
    scene bg render772
    Mei "kidnapping, rape, torture, you name it. "

    scene bg adamemei
    Mei "They have a base to the south"
    play sound "audio/soundreality-wind-blowing-457954.mp3" fadein 0.5
    image creep = Movie(play="images/animation/creepers base/vid/creeper0001-0152-fp50ud.webm", loop=False)
    show creep 
    pause 5.5

    scene bg crep 
    Mei "If they see you they might kill you or try to recruit you"
    Mei "You can't tell"
    pause
    scene bg render1071 with dissolve
    pause
    scene bg render1072 with dissolve
    Mei "But to be honest, it's usually the first option"
    scene bg render1074 with dissolve
    pause
    scene bg render1073 with dissolve
    pause



    stop music fadeout 2.0
    scene bg render773 with dissolve
    player_name "Are you part of a group?"
    Mei "Nah, it's just me against the world"
    scene bg render774 with dissolve
    Mei "I am surprised you know so little about this area, where are you from?"
    scene bg render775 with dissolve
    player_name "I was in a bunker when the sky started falling"
    Mei "Oh, a bunker guy, I've met a few folks like you. How many are in your group?"
    scene bg render776 with dissolve

    menu:
        "It's just me":
            jump mei

        "Me and my family":
            $ meipts = 1
            $ renpy.notify("Mei trusts you more")
            jump mei



    label mei:
    player_name "* Why is she... *"
    scene bg render777 with dissolve
    Mei "[p], the reason I saved you is because I saw the way you handled those infected, like it was nothing"
    Mei "You had some problems with the big guy but you still fought. most don't even try"
    scene bg render787 with dissolve
    Mei "I need guys like you to help me with something."
    scene bg render788 with dissolve
    player_name "* Dear god *"
    scene bg render789 with dissolve
    Mei "You could think of it as an alliance"
    scene bg render790 with dissolve
    Mei "You help me and I help you"
    scene bg render791 with dissolve
    Mei "How does it sound?"
    player_name "What do you need my help for?"
    scene bg render792 with dissolve
    Mei "I need to save someone from the creepers."
    scene bg render793 with dissolve
    player_name "A rescue mission."
    Mei "You could put it that way"
    scene bg render794 with dissolve
    player_name "How do we get in touch?"
    Mei "Do you have a long distance radio?"
    player_name "What frequency?"
    scene bg render795 with dissolve
    Mei "Every midnight, 5.3"
    player_name "Okay"
    scene bg render796 with dissolve
    Mei "Well, then I guess this is a goodbye for now"
    scene bg render797 with dissolve
    player_name "Thanks again for saving me"
    Mei "You'll have all the chances to pay me back"
    Mei "Oh since you know so little, let me warn you. During the day is safe to walk around like that"
    Mei "But at night, you won't last 3 minutes"
    scene bg render798 with dissolve
    Mei "Now leave, I need to change these clothes"
    scene bg render799 with dissolve
    player_name "Right"
    scene bg render800 with dissolve
    player_name "*What is she up to? *"
    scene bg render801 with dissolve
    pause
    scene black with dissolve
    pause .5


    scene bg render778 with dissolve
    Unknown "What the hell were you doing?"
    scene bg render779 with dissolve
    Unknown "Taking your clothes off like that, are you crazy?"
    scene bg render780 with dissolve
    Unknown "Have you lost your mind?"
    scene bg render781 with dissolve
    Mei "Rim, Relax it was part of the plan"
    scene bg render782 with dissolve
    Mei "Trust me, silly"
    scene bg render783 with dissolve
    Mei "How many times did we had to deal with rapists and scumbags?"
    scene bg render784 with dissolve
    Mei "All i did was test him. I needed to see what kind of man he was"
    scene bg render785 with dissolve
    Mei "And if he had no self control I knew my cute sister would be watching over me"
    scene bg render786 with dissolve
    Mei "Now, shall we head home?"
    pause
    stop sound
    scene black
    pause .5
    scene bg render802 with dissolve
    pause
    Rim "Do you really think we can trust him?"
    Mei "I don't but he seems okay"
    pause
    scene black with dissolve
    pause .5
    play sound "audio/leberch-lo-fi-chill-524418.mp3" fadein 1.5
    scene bg render803 with dissolve
    pause
    scene bg render804 with dissolve
    pause
    scene bg render805 with dissolve
    pause
    scene bg render806 with dissolve
    pause
    scene bg render807 with dissolve
    pause
    scene bg render808 with dissolve
    Luna "You are back"
    scene bg render809 with dissolve
    player_name "Hey cutie, do you come here often?"
    scene bg render810 with dissolve
    Luna "Only when I am looking for dumb stupid [MainLunaRelation]s"
    scene bg render811 with dissolve
    Luna "Do you have any idea how worried we were?"
    scene bg render812 with dissolve
    pause
    scene bg render813 with dissolve
    pause
    scene bg render814 with dissolve
    Luna "Did you find what you were looking for?"
    scene bg render815 with dissolve
    Emily "[p]"
    scene bg render816 with dissolve
    Emily "Where did you go?"
    scene bg render817 with dissolve
    player_name "Hi baby, don't worry. I am here now"
    scene bg render818 with dissolve
    pause
    scene bg render819 with dissolve
    Alice "* He's back *"
    Alice "* Wait... HE IS BACK! *"
    scene bg render820 with dissolve
    pause
    Alice "Why would you leave without saying goodbye?"
    scene bg render822 with dissolve
    player_name "Well.. I needed to leave as soon as poss-"
    scene bg render823 with dissolve
    Alice "Bullshit!"
    Alice "You know what. I don't wanna hear it"
    scene bg render824 with dissolve
    Alice "Liar."
    scene bg render825 with dissolve
    Emily "Don't worry about her, she was just scared like us"
    player_name "Where is your mother?"
    scene black
    pause 0.5
    stop sound fadeout 1.0
    scene bg render826 with dissolve
    pause
    player_name "* That is a nice view *"
    scene bg render827 with dissolve
    pause
    scene bg render828 with dissolve
    pause
    scene bg render829 with dissolve
    pause
    scene bg render830 with dissolve
    pause
    scene bg render831 with dissolve
    Sara "What?"
    scene bg render832 with dissolve
    pause
    scene bg render833 with dissolve
    pause
    scene bg render834 with dissolve
    Sara "[p], baby you are home"
    scene bg render835 with dissolve
    Sara "We were worried sick"
    player_name "I know, sorry"
    scene bg render836 with dissolve
    player_name "But I am here now"
    pause
    play sound "audio/kissing-6174.mp3"
    scene bg render837 with dissolve
    pause
    play sound "audio/kissing-6174.mp3"
    scene bg render838 with dissolve
    pause
    Sara "Hmm"
    Sara "That's nice"
    scene bg render839 with dissolve
    Luna "[MainLunaRelation], are you here?"
    scene bg render840 with dissolve
    player_name "Yeah baby"
    scene bg render841 with dissolve
    Luna "Have you talked with mom yet?"
    Luna "She said she would be down stairs"
    player_name "I am going there right now"
    scene bg render842 with dissolve
    Luna "Okay"
    scene bg render844 with dissolve
    pause
    player_name "A really nice view"
    scene black
    pause 0.5
    scene bg render845 with dissolve
    pause
    scene bg render846 with dissolve
    pause
    player_name "Waiting for me?"
    scene bg render847 with dissolve
    pause
    scene bg render848 with dissolve
    pause
    scene black
    pause 0.5
    scene bg render849 with dissolve
    pause
    scene bg render850 with dissolve
    pause
    scene bg render851 with dissolve
    pause
    play sound "audio/knocking-door-wc-394936.mp3"
    scene bg render852 with dissolve
    pause
    scene bg render853 with dissolve
    pause
    Alice "Leave me alone"
    play sound "audio/door-opening-78648.mp3"
    scene bg render854 with dissolve
    pause
    scene bg render855 with dissolve
    pause
    scene bg render856 with dissolve
    player_name "Can we talk?"
    scene bg render857 with dissolve
    Alice "No"
    scene bg render858 with dissolve
    Alice "I don't need to hear more lies"
    scene bg render860 with dissolve
    pause
    scene bg render861 with dissolve
    player_name "Okay, I'll give you some space. But I'll always be here for you"
    scene bg render862 with dissolve
    Alice "Wait"
    scene bg render863 with dissolve
    Alice "We can talk.."
    scene bg render864 with dissolve
    Alice "Where did you even go?"
    player_name "Your father's company. I was looking for a special notebook"
    scene bg render865 with dissolve
    player_name "It's solar energy based and it's suposed to work even during world crysis"
    pause
    scene bg render866 with dissolve
    player_name "It's linked to a satelite, we would be able to see any threat coming miles away"
    player_name "But i couldn't find it"
    pause
    scene bg render867 with dissolve
    player_name "Sorry for making you worry so much"
    player_name "Can you forgive me?"
    pause
    scene bg render868 with dissolve
    Alice "I guess..."
    player_name "Can I get a hug?"
    scene bg render869 with dissolve
    pause
    play music "audio/ALICE.mp3"
    scene bg render870 with dissolve
    Alice "If you leave without telling us again I'll kill you"
    scene bg render871 with dissolve
    player_name "I promise I won't"
    scene bg render872 with dissolve
    pause

    scene bg render874 with dissolve
    pause
    scene bg render875 with dissolve
    pause 
    scene bg render876 with dissolve
    pause 1.5
    scene bg render877 with dissolve
    pause 1.5
    scene bg render878 with dissolve
    pause
    scene bg render879 with dissolve
    pause
    scene bg render880 with dissolve
    pause
    player_name "Can I take these off?"
    scene bg render881 with dissolve
    pause
    scene bg render882 with dissolve
    pause
    scene bg render883 with dissolve
    player_name "So gorgeous"
    scene bg render884 with dissolve
    pause
    scene bg render885 with dissolve
    Alice "Where are you going?"
    scene bg render886 with dissolve
    pause

    scene bg render888 with dissolve
    pause
    scene bg render889 with dissolve
    Alice "Fuuuu- Oh my fricking"
    scene bg render890 with dissolve
    pause
    scene bg render891 with dissolve
    Alice "And now you are sucking my clit.. Fuuuuck"
    scene bg render892 with dissolve
    Alice "I've never been... shhhit"
    scene bg render893 with dissolve
    Alice "I can get used to it"
    scene bg render894 with dissolve
    Alice "Oh dear"
    Alice "No, That won't do it."
    scene bg render895 with dissolve
    Alice "Take me from behind"
    scene bg render896 with dissolve
    player_name "You are so fucking hot, you know that right?"
    scene bg render898 with dissolve
    Alice "Yeahhh- Fuck, slowly please"
    scene bg render900 with dissolve
    Alice "FUCK, I said slowly, you are too big"
    player_name "My bad"
    pause

    play sound "audio/ALICE MOANING.mp3"
    image AliceOne = Movie(play="images/animation/Alice First Sex scene/anime/doggy1-6s2s2u.webm", loop=True)
    show AliceOne with dissolve
    Alice "Yeah, slowly"
    Alice "Let me get used to it"
    player_name "You are so tight"
    Alice "Harder"
    pause
    play sound "audio/ALICE MOANING.mp3" loop
    image AliceTwo = Movie(play="images/animation/Alice First Sex scene/anime/doggy-harder2-xqitkp.webm", loop=True)
    show AliceTwo with dissolve
    Alice "Oh Yeah, I can feel all of you"
    Alice "So good, don't stop"
    player_name "That's not all of it."
    Alice "What? are you kidding? fuck me all the way then"
    pause
    
    image AliceAbov = Movie(play="images/animation/Alice First Sex scene/anime/doggy-from-abov-3-frt2r7.webm", loop=True)
    show AliceAbov with dissolve
    pause
    Alice "God! Fuck..."
    pause
    image AliceThree = Movie(play="images/animation/Alice First Sex scene/anime/doggy-close-up-4-werlua.webm", loop=True)
    show AliceThree with dissolve
    Alice "My Fucking God, yes!"
    Alice "I love it! Don't you stop. please keep going"
    player_name "The way you match with my thrust is so good baby"
    Alice "I'M CUMMING!"
    pause
    scene bg aliceCuming
    Alice "FUUUUCK!"
    stop sound fadeout 1.0
    scene bg render901 with dissolve
    Alice "I need some rest" 

    scene bg render902 with dissolve
    pause
    image Alicefour = Movie(play="images/animation/Alice First Sex scene/anime/slaping-dick-on-her-ass-50001-0068-0hrm40.webm", loop=True)
    show Alicefour with dissolve
    pause
    player_name "Do you?"
    player_name "I bet you can keep going"
    pause
    scene bg render903 with dissolve
    Alice "Fuck, wait, I am sensitive"
    scene bg aliceFucking 
    pause
    Alice "Wait!"
    scene bg render904 with dissolve
    pause
    scene bg render905 with dissolve
    pause
    Alice "Now it's better. Give it to me"
    image Alicefive = Movie(play="images/animation/Alice First Sex scene/anime/second-position-60001-0041-0t2ndd.webm", loop=True)
    show Alicefive with dissolve
    pause
    scene black 
    pause 0.5
    scene bg render906 with dissolve
    pause

    scene bg render907 with dissolve
    pause
    Alice "That's fucking deep"
    play sound "audio/ALICE MOANING.mp3" loop
    image AliceSix = Movie(play="images/animation/Alice First Sex scene/anime/cow-girl0001-0121-hdh8su.webm", loop=True)
    show AliceSix with dissolve
    pause
    Alice "That's so deep. I've never felt so full"
    Alice "I love your dick, i fucking love it"
    player_name "Don't worry, I'll fuck you anytime you need"
    Alice "I'm gonna cum again"
    pause

    
    image AliceSeven = Movie(play="images/animation/Alice First Sex scene/cow-girl-2-fixed0001-0121-hnlb6x.webm", loop=True)
    show AliceSeven with dissolve
    Alice "I'm gonna look for you everyday from now on."
    Alice "I hope Aunt Anne won't mind sharing"
    player_name "She won't, she loves sharing."
    Alice "Fuck me, i'm getting close"
    player_name "Me Too"
    Alice "This pussy is yours baby, just cum"
    pause

    stop sound
    stop music
    scene bg render908 with dissolve
    play sound "audio/ALICE SQUIRTmp3.mp3"
    Alice "FUUUUUCK!"
    Alice "Hmm"
    pause
    scene bg render909 with dissolve
    Alice "I've never came that hard "
    player_name "Yeah? then you better get used to it"
    pause
    scene bg render910 with dissolve
    Alice "I was kinda hoping you were cumming inside"
    player_name "You know how dangerous it would be right?"
    Alice "I know... I just, never mind"
    pause
    scene bg render911 with dissolve
    player_name "You can talk with me"
    Alice "Yeah, I was beeing silly. Forget it"
    pause
    scene bg render912 with dissolve
    player_name "Okay, We should get dressed and hope no one heard you moaning"
    Alice "So what if they hear?"
    player_name "Things don't work like that baby"
    pause

    scene bg render913 with dissolve
    Alice "I really don't mind"

    scene bg render914 with dissolve
    Alice "But if you wanna keep this a secret... I guess it works too"
    pause
    stop music fadeout 1.5
    scene bg render915 with dissolve
    pause

    scene bg render916 with dissolve
    player_name "Thank you for understanding, this is not the right time"


    scene bg fivemin with dissolve
    pause
    play sound "audio/ALICE MOANING.mp3" fadein 1.5
    scene bg render917 with dissolve
    pause

    scene bg render918 with dissolve
    Alice "Hmmm, fuck"
    pause

    scene bg render919 with dissolve
    Alice "Yes daddy fill me up"

    scene bg render920 with dissolve
    player_name "Keep it down baby"

    scene bg render921 with dissolve
    pause
    Alice "Such a thick dick, how can I keep it down?"

    scene bg render922 with dissolve
    Alice "Yeah, harder!"

    scene bg render923 with dissolve
    stop sound fadeout 1.0
    Sara "Oh God"
    scene bg render924 with dissolve
    pause

    scene bg render925 with dissolve
    Anne "Hey, did you manage to clean all of it?"
   
    scene bg render926 with dissolve
    pause
    Sara "Can I ask you something?"

    scene bg render927 with dissolve
    Anne "Sure honey, spit it out"

    scene bg render928 with dissolve
    Anne "What happened?"

    scene bg render930 with dissolve
    Sara "H-How would you feel if [player_name]... "

    scene bg render931 with dissolve
    Sara "Sleept with another woman?"

    scene bg render932 with dissolve
    pause

    scene bg render933 with dissolve
    pause

    scene bg render934 with dissolve
    pause

    scene bg render935 with dissolve
    Anne "I..."

    scene bg render936 with dissolve
    pause

    scene bg render937 with dissolve
    Anne "I can't say that I've never thought about it"
    Anne "[player_name] always had a sex drive stronger then mine and I always knew that he could grow tired of me someday"

    scene bg render938 with dissolve
    Anne "And now after all these things happening I don't think I could blame him for having some fun I guess"

    scene bg render939 with dissolve
    Anne "But I know that he would still love me and protect me even if he were to have sex with someone else"

    scene bg render940 with dissolve
    Sara "So you would allow it?"

    scene black
    pause
    play music "audio/Lunas.mp3" fadein 1.5
    play sound "audio/freesound_community-shower-in-bathroom-62910.mp3"
    scene bg render941 with dissolve
    pause
    Luna "Hum Hum Humm"

    scene bg render942 with dissolve
    pause

    scene bg render943 with dissolve
    pause

    scene bg render944 with dissolve
    pause

    scene bg render945 with dissolve
    pause

    stop sound

    scene bg Patreonrd with dissolve
    pause

    scene bg Patreonrd1 with dissolve
    pause
    scene bg Patreonrd2 with dissolve
    pause
 
    scene bg Patreonrd3 with dissolve
    pause
    scene bg Patreonrd4 with dissolve
    pause
    scene bg Patreonrd5 with dissolve
    pause
    Luna "It's been a while..."
    scene bg Patreonrd6 with dissolve
    pause
    image Lunes = Movie(play="images/animation/Patreons only Luna/vids/lunes0001-0091-fnqukb.webm", loop=True)
    show Lunes with dissolve
    pause
    Luna "Hearing Mom moaning every night doesn't help either."
    Luna "And here i thought there would be less of that"
    image Lunes2 = Movie(play="images/animation/Patreons only Luna/vids/lunes20001-0091-7yjuwd.webm", loop=True)
    show Lunes2 with dissolve
    pause
    Luna "God, I was wrong!"
    Luna "They might be doing it even more now"
    Luna "Sleeping next to them I can even hear the slap sounds"
    scene bg Patreonrd9 with dissolve
    pause
    scene bg Patreonrd10 with dissolve
    Luna "This won't do it, I need something bigger"
    pause
    scene bg Patreonrd11 with dissolve
    pause
    scene bg Patreonrd12 with dissolve
    pause
    scene bg Patreonrd13 with dissolve
    pause
    image Lunes3 = Movie(play="images/animation/Patreons only Luna/vids/lunes30001-0060-juhmgg.webm", loop=True)
    show Lunes3 with dissolve
    pause
    Luna "Sometimes I think I can tell what position they're in"
    Luna "With Aunt Sara sleeping next to me I can't do nothing about it"
    Luna "I am sure she can hear it too"
    scene bg Patreonrd16 with dissolve
    play sound "audio/knocking-door-wc-394936.mp3"
    pause
    Alice "Luna, is that you?"
    scene bg Patreonrd17 with dissolve
    pause
    Luna "Y-Yeah, I am... I'm in the middle of something"
  
    image Lunes4 = Movie(play="images/animation/Patreons only Luna/vids/last0001-0060-rg4ohh.webm", loop=True)
    show Lunes4 with dissolve
    pause
    Luna "Just give it to me."
    Alice "What?"
    Luna "Just give me a second, okay?"
    Alice "Okay, can you let me know when you're out?"
    Luna "Fuu.. Sure"
    scene bg Patreonrd18 with dissolve
    Luna "Ahnn Almost there"
    pause
    scene bg Patreonrd19 with dissolve
    Luna "Ahhh ♡"
    pause
    scene black
    pause 1.0







    stop sound

    scene bg render948 with dissolve
    pause

    scene bg render949 with dissolve
    Luna "Move your leg"

    scene bg render950 with dissolve
    pause

    scene bg render951 with dissolve
    Luna "So, how were things out there?"

    scene bg render952 with dissolve
    player_name "well, were do i start?"
    stop music fadeout 2.0
    scene black with dissolve
    pause 1.0

    scene bg render953 with dissolve
    Luna "Really? were you scared?"

    scene bg render954 with dissolve
    player_name "There's no time for fear when the adrenaline hits you"

    scene bg render955 with dissolve
    Anne "Luna, let your father eat. He must be starving"
    Luna "Just give me a second"

    scene bg render956 with dissolve
    Luna "Actually, you can give it to me. I could feed him"

    scene bg render957 with dissolve
    Luna "Humf"
    scene bg render958 with dissolve
    player_name "Get out of here, I can feed myself"
    Luna "[MainLunaRelation]!"
    scene bg render959 with dissolve
    player_name "Hey babe, do you know if that room is clean?"
    Anne "Yeah. I cleaned it myself, why?"
    scene bg render960 with dissolve
    player_name "Nothing, just asking"

    scene bg render961 with dissolve
    pause
    Alice "Where are you going?"

    scene bg render962 with dissolve
    player_name "Oh, hey sexy"
    player_name "I'll just take a look around, i'll be back in 10 minutes"

    scene bg render963 with dissolve
    Alice "Okay, come find me when you are done"
    play sound "audio/freesound_community-birds-19624.mp3"
    scene bg render964 with dissolve
    pause

    scene bg render965 with dissolve
    pause

    scene bg render967 with dissolve
    pause

    scene bg render966 with dissolve
    pause

    
    scene black
    pause 1.0
    stop sound
    stop music
    play music "audio/kodiakid-bathroom-fan-271527.mp3"
    scene bg render1064 with dissolve
    pause
    scene bg render1065 with dissolve
    pause
    scene bg render1066 with dissolve
    pause
    Mei "I hope you are still alive mom"
    pause
    scene bg render1068 with dissolve
    pause
    stop music 
    scene bg render1062 with dissolve
    pause
    play sound "audio/freesounds123-walking-on-grass-363353.mp3"
    scene bg render1063 with dissolve
    pause
    Unknown "Is this the place?"
    Unknown "YEAH!"

    scene bg render976 with dissolve
    pause

    scene bg render977 with dissolve
    pause
    scene bg render978 with dissolve
    Emily "[EmiAliceRelation] [player_name], wake up"

    scene bg render980 with dissolve
    player_name "What's wrong?"
    Emily "Nothing"

    scene bg render981 with dissolve
    Emily "I was wondering if I...."

    scene bg render982 with dissolve
    Emily "Could sleep here"

    scene bg render983 with dissolve
    pause

    scene bg render984 with dissolve
    pause

    scene bg render985 with dissolve
    pause

    scene bg render986 with dissolve
    player_name "I have a better idea"

    scene bg render987 with dissolve
    pause

    scene bg render988 with dissolve
    pause

    scene bg render989 with dissolve
    pause

    scene black
    pause
    play sound "audio/dragon-studio-light-switch-382712.mp3"
    scene bg render990 with dissolve
    pause

    scene bg render991 with dissolve
    Emily "This..."

    scene bg render992 with dissolve
    Emily "This is quite nice"

    scene bg render993 with dissolve
    pause
    scene bg render994 with dissolve
    pause

    play sound "audio/siting on couch or bed.mp3"
    scene bg render995 with dissolve
    pause

    scene bg render996 with dissolve
    Emily "Why am I sleeping on that tiny bed with this here?"

    scene bg render997 with dissolve
    pause

    scene bg render998 with dissolve
    player_name "Because I need you close to mine"

    scene bg render999 with dissolve
    Emily "Then we can just sleep here tonight"

    scene bg render1000 with dissolve
    Emily "Or not"

    scene bg render1001 with dissolve
    pause
    play music "audio/Emily song.mp3"
    scene bg render1002 with dissolve
    Emily "Hmm I like it when you touch me"
    
    image dry = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/1-dry-rump0001-0041-akl7g3.webm", loop=True)
    scene black
    show dry    
    pause 1.5
    Emily "But I'll do the touching now"
    player_name "hmm"
    player_name "I won't complain"
    pause


    scene bg render1003 with dissolve
    pause

    scene bg render1004 with dissolve
    pause

    scene bg render1005 with dissolve
    pause

    scene bg render1006 with dissolve
    pause

    scene bg render1007 with dissolve
    pause

    scene bg render1008 with dissolve
    pause

    scene bg render1009 with dissolve
    pause

    scene bg render1010 with dissolve
    pause

    scene bg render1011 with dissolve
    pause

    scene bg render1012 with dissolve
    pause

    scene bg render1013 with dissolve
    pause

    scene bg render1014 with dissolve
    pause

    scene bg render1015 with dissolve
    pause

    scene bg render1016 with dissolve
    pause

    scene bg render1017 with dissolve
    pause
    Emily "It's so warm against me"
    pause

    scene bg render1018 with dissolve
    pause 0.5

    scene bg render1019 with dissolve
    pause

    image drynakd = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/2-naked-dry-rump0001-0041-1aahxk.webm", loop=True)
    scene black
    show drynakd   
    pause
    player_name "Oh god that's even better"
    Emily "I didn't know I could get so wet"
    player_name "You are perfect baby"
    player_name "I'm so lucky"
    pause




    scene bg render1020 with dissolve
    pause

    scene bg render1021 with dissolve
    pause

    scene bg render1022 with dissolve
    Emily "Does it feels good?"


    image tighss = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/3-tigh-fuck0001-0041-rnpdfh.webm", loop=True)
    scene black
    show tighss   
    pause
    player_name "Hmm, you keep surprising me"
    Emily "kiss me"

    scene bg render1023 with dissolve
    pause

    scene bg render1024 with dissolve
    pause
    scene bg render1025 with dissolve
    pause
    Emily "OH my, it's massive "



    scene bg render1027 with dissolve
    pause
    player_name "It might hurt a little at first but I promise it will feel amazing later"

    scene bg render1028 with dissolve
    Emily "It already feels amazing."

    scene bg render1029 with dissolve
    pause

    scene bg render1030 with dissolve
    pause

    scene bg render1031 with dissolve
    pause
    Emily "Hm"

    image rubb = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/5-rubbing0001-0060-ouvrmv.webm", loop=True)
    scene black
    show rubb   
    pause
    Emily "All this foreplay is killing me"
    Emily "Do it"
    pause


    scene bg render1032 with dissolve
    pause

    scene bg render1033 with dissolve
    pause

    scene bg render1034 with dissolve
    pause

    image tip = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/6-tip0001-0060-1fnsvq.webm", loop=True)
    scene black
    show tip 
    player_name "Wow, you are so wet it went right in"
    Emily "hmf hmmmf"
    Emily "Thick... hmmm"
    player_name "Can i go faster?"
    Emily "Take me"
    pause
    scene bg render1035 with dissolve
    Emily "I'm loving it"


    image Morethentip = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/7-sex0001-0080-cxt8rq.webm", loop=True)
    scene black
    show Morethentip 
    pause
    player_name "Good God you are so wet."
    player_name "So tight, I might get addicted"
    Emily "HMMMM FFuuu"
    pause

    scene bg render1036 with dissolve
    pause



    image sidestwo = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/9-side-fuck0001-0080-9zpgca.webm", loop=True)
    scene black
    show sidestwo 
    player_name "I guess you are starting to feel it"
    Emily "Starting??"
    player_name "Good girl, you are doing great"

    pause

    image sidesthree = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/10-side-fuck0001-0040-jqdjq4.webm", loop=True)
    scene black
    show sidesthree 
    Emily "You are going deeper and deeper"
    player_name "Yeah, do you like it?"
    Emily "I wanna know how deep you can go. "
    Emily "Lay on your back for me"
    pause

    scene bg render1037 with dissolve
    player_name "Are you sure?"

    scene bg render1038 with dissolve
    pause

    scene bg render1039 with dissolve
    Emily "N-No but I am so fucking horny right now"

    scene bg render1040 with dissolve
    pause

    scene bg render1041 with dissolve
    pause

    scene bg render1042 with dissolve
    pause

    scene bg render1043 with dissolve
    Emily "Holy"

    scene bg render1044 with dissolve
    Emily "Shit"
    Emily "How can this feel even... Bigger?"
    
    image cow = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/11-cow-girl0001-0050-rffwkb.webm", loop=True)
    scene black
    show cow 
    pause
    Emily "Ahnn so good. It's stretching me so good"
    player_name "Fuck... Take your time, we have all night"
    Emily "Hmmm hear you say that makes me so happy"
    pause



    scene bg render1045 with dissolve
    Emily "I love this"
    player_name "And I love you"

    scene bg render1046 with dissolve
    pause

    scene bg render1047 with dissolve
    pause

    image cow2 = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/12-cow-girl0001-0050-db6wx2.webm", loop=True)
    scene black
    show cow2 
    Emily "SO Deep, Ahhhnnn"
    player_name "watch you take control it's such a turn on"
    Emily "I think I like it but having you pressing me down must be even better"
    player_name "I guess we'll have to test that"
    
    pause

    image cow3 = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/13-cow-girl0001-0050-mpjssb.webm", loop=True)
    scene black
    show cow3
    Emily  "I was thinking the same"
    Emily "But now I can't get off your lap"
    Emily "It's so fucking good"

    image cow4 = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/14-cow-girl0001-0050-wzvmta.webm", loop=True)
    scene black
    show cow4
    pause
    Emily "Humf.... I few weird, something is coming"
    player_name "Don't stop baby"
    Emily "I would never"
    player_name "Faster!"
    play sound "audio/EMILY SITTING ON DICKmp3.mp3" loop
    image cow5 = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/15cow-girl0001-0060-s2x3lb.webm", loop=True)
    scene black
    show cow5
    pause

    Emily "Oh SHIT!"
    Emily "I love your dick so FUCKING much Fuck!"
    player_name "I can feel you getting tighter"
    Emily "Shit something is...."
    player_name "Cum for me!"

    stop sound
    image cumin = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/16-cuming0001-0088-qgmlyr.webm", loop=False)
    scene black
    show cumin
    pause 

    image lastt = Movie(play="images/animation/Emily First time/ALL ANIMATIONS/WEMP/17-last-position0001-0060-mfut75.webm", loop=True)
    scene black
    show lastt with fade
    pause 
    Emily "Fuck it's too much but don't stop"
    player_name "I am close baby"
    pause

    menu:
        " Cum inside her":
            jump inside

        "Cover her":
            jump coverh




    label inside:
    scene bg render1048 with dissolve
    pause

    scene bg render1049 with dissolve
    pause

    scene bg render1050 with dissolve
    pause
    scene bg render1051 with dissolve
    Emily "Your milk is so warm"
    jump go
    
        
    label coverh:
    scene bg render1053 with dissolve
    pause 1.0

    scene bg render1054 with dissolve
    pause 1.0

    scene bg render1055 with dissolve
    pause 1.0

    scene bg render1056 with dissolve
    pause

    scene bg render1057 with dissolve
    pause
    Emily "Can I taste it?"

    

    label go:
    scene bg render1052 with dissolve
    Emily "I loved it"
    stop music fadeout 1.5
    stop sound fadeout 1.5
    scene bg render1058 with dissolve
    pause
    Emily "I am a bit sore but in a good way"
    Emily "It's fine, really"
    play music "audio/vikingmusic-epic-war-background-music-for-cinematic-battles-and-action-scenes-344068.mp3" fadein 1.5
    play sound "audio/alexis_gaming_cam-radio-338296.mp3"
    scene bg render1059 with dissolve
    pause

    scene bg render1060 with dissolve
    pause
    play sound "audio/alexis_gaming_cam-radio-338296.mp3"
    Rim "Hello? PLEASE anwser me."
    Emily "Who is that?"

    scene bg render1061 with dissolve
    pause
    play sound "audio/alexis_gaming_cam-radio-338296.mp3"
    Rim "THEY TOOK MY SISTER! I NEED YOUR HELP"
    pause 
    scene bg render1077 with dissolve
    pause
    scene bg render1078 with dissolve
    pause
    player_name "I'm listening!"
    play sound "audio/alexis_gaming_cam-radio-338296.mp3"
    Rim "The girl you met earlier today—I'm her sister."
    Rim "There were so many of them; I had no choice. They just came in and took her"
    Rim "I need your help"
    scene bg render1079 with dissolve
    player_name "Tell me where you are, I'm on my way"
    scene bg render1080 with dissolve
    play sound "audio/alexis_gaming_cam-radio-338296.mp3"
    Rim "W- What? But it's still dark. You won't make it here"
    Rim "Listen, When it gets dark, the streets turn into a nightmare—even
    if you avoid the city center, where it's worst-"
    scene bg render1081 with dissolve
    player_name "Even better. If that's true, then it means
    the guys who kidnapped your sister must still be close by."
    player_name "Otherwise, they wouldn't be able to attack at night."
    player_name "If we wait until dawn, they'll have enough time 
    to reach their base, and then it's game over."
    Rim "That... That makes sense."
    scene bg render1082 with dissolve
    player_name "Go get my things."
    scene bg render1083 with dissolve
    Emily "Should I wake everyone up?"
    scene bg render1084 with dissolve
    player_name "No, we don't have much time. I need to be quick"
    scene bg render1085 with dissolve
    player_name "Any idea where they might be?"
    scene bg render1086 with dissolve
    play sound "audio/alexis_gaming_cam-radio-338296.mp3"
    Rim "It's a shot in the dark but I might know"
    scene bg render1087 with dissolve
    Rim "There's this place—Mei and I followed a group there once. It's close by."
    scene bg render1088 with dissolve
    player_name "I need you to give me the directions."
    scene bg render1089 with dissolve
    Rim "When you reach the city, you need to go around it. I'll give you further instructions there."
    scene bg render1090 with dissolve
    Rim "But I'm almost certain. They must be there."
    scene bg render1091 with dissolve
    player_name "When you get there, wait for me."
    scene bg render1092 with dissolve
    Emily "Are you sure this is a good idea?"
    pause
    scene bg render1093 with dissolve
    player_name "The person who saved my life is now in danger."
    scene bg render1094 with dissolve
    player_name "I need to go."
    scene bg render1095 with dissolve
    player_name "And I need you to trust me"
    scene bg render1096 with dissolve
    player_name "I won't let you down."
    scene bg render1097 with dissolve
    pause
    scene bg render1098 with dissolve
    player_name "Hey, why the long face?"
    scene bg render1099 with dissolve
    Emily "What do I even tell them?"
    scene bg render1100 with dissolve
    player_name "Nothing"
    player_name "I'll be back before the sunrise"
    scene bg render1101 with dissolve
    Emily "You can't know that"
    player_name "Wanna bet?"
    scene bg render1102 with dissolve
    player_name "I promise I'll be back"
    scene bg render1103 with dissolve
    pause
    scene bg render1104 with dissolve
    pause
    scene bg render1105 with dissolve
    pause
    stop music fadeout 1.5
    scene bg render1106 with dissolve
    pause
    play sound "audio/car-driving-ambience-6365.mp3"
    scene bg render1107 with dissolve
    pause
  
    scene bg render1114 with dissolve
    pause
    scene bg render1115 with dissolve
    pause
    scene bg render1108 with dissolve
    pause
    scene bg render1109 with dissolve
    pause
    scene bg render1110 with dissolve
    pause
    player_name "I think this will be enough."
    scene bg render1111 with dissolve
    pause
    scene bg render1112 with dissolve
    pause
    scene bg render1113 with dissolve
    player_name "Hm?"
    scene bg render1116 with dissolve
    pause
    scene bg render1117 with dissolve
    pause
    play music "audio/0.4 soundtrack/Adam Vs Nightmare (2).mp3"
    play sound "audio/0.4/u_5i70lx023u-person-eating-216440.mp3"
    scene bg render1118 with dissolve
    pause
    scene bg render1119 with dissolve
    pause
    scene bg render1120 with dissolve
    pause
    scene bg render1121 with dissolve
    pause
    scene bg render1122 with dissolve
    pause
    stop sound
    scene bg render1123 with dissolve
    pause
    scene bg render1124 with dissolve
    pause
    scene bg render1125 with dissolve
    pause
    scene bg render1126 with dissolve
    pause
    player_name "Eating your own kind. So mean"
    scene bg render1127 with dissolve
    pause
    scene bg render1128 with dissolve
    player_name "Let me just grab this gift for you"
    scene bg render1129 with dissolve
    pause
    scene bg render1130 with dissolve
    pause
    scene bg render1131 with dissolve
    pause
    player_name "Where the..."
    scene bg render1132 with dissolve
    pause
    play sound "audio/0.4/dragon-studio-bush-rustling-467467.mp3"
    scene bg render1133 with dissolve
    pause
    play sound "audio/0.4/freesound_community-086108_jumping-on-car-hood-45556.mp3"
    scene bg render1134 with dissolve
    player_name "Did he-"
    scene bg render1135 with dissolve
    pause 2.0
    play sound "audio/0.4/window.mp3"
    scene bg render1136 with dissolve
    pause 0.5
    scene bg render1137 with dissolve
    pause
    scene bg render1138 with dissolve
    pause
    play sound "audio/0.4/dragon-studio-open-car-door-372469.mp3"
    scene bg render1139 with dissolve
    pause

    scene bg render1140 with dissolve
    pause
    scene bg render1141 with dissolve
    play sound "audio/0.4/dragon-studio-bush-rustling-467467.mp3"
    pause
    scene bg render1142 with dissolve
    pause

    scene bg render1143 with dissolve
    pause
    play sound "audio/0.4/dragon-studio-whoosh-cinematic-376875.mp3"
    scene bg render1144 with dissolve
    pause
    play sound "audio/0.4/u_62htdrvg4y-gun-shot-359196.mp3"
    scene bg render1145 with dissolve
    pause
    scene bg render1146 with dissolve
    pause
    scene bg render1147 with dissolve
    pause
    scene bg render1148 with dissolve
    pause
    scene bg render1149 with dissolve
    pause
    scene bg render1150 with dissolve
    pause
    player_name "Fucking son of a bitch. Broke my window"

    scene bg adamxNightmare with dissolve
    pause
    play sound "audio/0.4/dragon-studio-monster-growl-376892.mp3"
    scene bg adamxNightmare1 with dissolve
    pause
    scene bg adamxNightmare2 with dissolve
    pause
    scene bg adamxNightmare3 with dissolve
    pause
    play sound "audio/0.4/dragon-studio-monster-growl-376892.mp3"
    scene bg adamxNightmare4 with dissolve
    pause
    scene bg adamxNightmare5 with dissolve
    pause
    scene bg adamxNightmare6 with dissolve
    pause
    scene bg adamxNightmare7 with dissolve
    pause
    play sound "audio/0.4/u_62htdrvg4y-gun-shot-359196.mp3"

    scene bg adamxNightmare8 with dissolve
    pause
    scene bg adamxNightmare9 with dissolve
    pause
    scene bg adamxNightmare10 with dissolve
    pause
    scene bg adamxNightmare11 with dissolve
    pause
    stop music fadeout 1.0
    player_name "Okay.."
    play sound "audio/0.4/universfield-heavy-body-fall-352446.mp3"
    scene bg adamxNightmare12 with dissolve
    pause

    scene bg adamxNightmare13 with dissolve
    pause
    play sound "audio/0.4/dragon-studio-bush-rustling-467467.mp3"
    scene bg adamxNightmare14 with dissolve
    pause
    player_name "What now"
    scene bg adamxNightmare16 with dissolve
    pause
    play music "audio/0.4 soundtrack/FireAndBlood.mp3"
    scene bg adamxNightmare17 with dissolve
    pause
    scene bg adamxNightmare18 with dissolve
    pause
    scene bg adamxNightmare19 with dissolve
    player_name "Wow! A tree guy"
    scene bg adamxNightmare20 with dissolve
    player_name "Sorry buddy, I'm in a hurry"
    scene bg adamxNightmare21 with dissolve
    player_name "No time to dance"
    pause
    scene bg adamxNightmare22 with dissolve
    play sound "audio/0.4/u_62htdrvg4y-gun-shot-359196.mp3"
    pause 0.5

    scene bg adamxNightmare23 with dissolve
    pause 0.5
    scene bg adamxNightmare24 with dissolve
    player_name "What the fu-"
    play sound "audio/0.4/freesound_community-bone-crack-1-84755.mp3"
    scene bg adamxNightmare25 with dissolve
    pause
    scene bg adamxNightmare26 with dissolve
    player_name "uugh!"
    pause
    scene bg adamxNightmare27 with dissolve
    player_name "EAT SHIT!"
    play sound "audio/0.4/u_62htdrvg4y-gun-shot-359196.mp3"

    scene bg adamxNightmare28 with dissolve
    pause
    scene bg adamxNightmare29 with dissolve
    pause
    scene bg adamxNightmare30 with dissolve
    pause
    scene bg adamxNightmare31 with dissolve
    pause
    scene bg adamxNightmare32 with dissolve
    pause
    play sound "audio/0.4/freesound_community-deep-monster-growl-86780.mp3"
    scene bg adamxNightmare33 with dissolve
    bōsa  "eeEeEatT"
    
    scene bg adamxNightmare34 with dissolve
    bōsa  "sSHhhhIit"


    scene bg adamxNightmare35 with dissolve
    pause

    scene bg adamxNightmare36 with dissolve
    pause
    scene bg adamxNightmare37 with dissolve
    player_name "What the-"
    scene bg adamxNightmare38 with dissolve
    player_name "Fuuuu"
    play sound "audio/0.4/freesound_community-086108_jumping-on-car-hood-45556.mp3"

    scene bg adamxNightmare40 with dissolve
    pause
    scene bg adamxNightmare41 with dissolve
    pause
    scene bg adamxNightmare42 with dissolve
    pause
    scene bg adamxNightmare43 with dissolve
    pause
    player_name "Son of a.."
    scene bg adamxNightmare44 with dissolve
    player_name "You wanna throw me around like a fucking bag?"
    scene bg adamxNightmare45 with dissolve
    pause
    play sound "audio/0.4/dragon-studio-open-car-door-372469.mp3"

    scene bg adamxNightmare46 with dissolve
    pause
    scene bg adamxNightmare47 with dissolve
    pause
    scene bg adamxNightmare48 with dissolve
    player_name "Let's see who gets thrown farther"
    scene bg adamxNightmare49 with dissolve
    pause
    scene bg adamxNightmare50 with dissolve
    pause
    scene bg adamxNightmare51 with dissolve
    pause
    play sound "audio/0.4/freesound_community-bone-crack-1-84755.mp3"
    scene bg adamxNightmare52 with dissolve
    pause

    scene bg adamxNightmare53 with dissolve
    pause
    play sound "audio/0.4/freesound_community-086108_jumping-on-car-hood-45556.mp3"

    scene bg adamxNightmare54 with dissolve
    pause
    scene bg adamxNightmare55 with dissolve
    pause
    scene bg adamxNightmare56 with dissolve
    pause
    scene bg adamxNightmare57 with dissolve
    pause

    scene bg adamxNightmare58 with dissolve
    pause
    scene bg adamxNightmare59 with dissolve
    pause
    scene bg adamxNightmare60 with dissolve
    player_name "Please, don't surprise me again."
    scene bg adamxNightmare61 with dissolve
    pause
    play sound "audio/0.4/freesound_community-gun-shots-from-a-distance-14-39756.mp3"
    scene bg adamxNightmare62 with dissolve
    pause
    scene bg adamxNightmare63 with dissolve
    pause
    scene bg adamxNightmare64 with dissolve
    pause
    play sound "audio/0.4/head blown.mp3"
    scene bg adamxNightmare65 with dissolve
    pause
    scene bg adamxNightmare66 with dissolve
    pause
    scene bg adamxNightmare67 with dissolve
    pause
    scene bg adamxNightmare68 with dissolve
    pause
    scene bg adamxNightmare69 with dissolve
    pause

    scene bg adamxNightmare70 with dissolve
    player_name "Just look at him... In little pieces."
    pause








    scene bg render1151 with dissolve
    pause
    player_name "That wasn't so bad."
    play sound "audio/car-door-close-6929.mp3"
    scene bg render1152 with dissolve
    pause
    scene bg render1153 with dissolve
    pause
    scene bg render1154 with dissolve
    pause
    scene bg render1155 with dissolve
    pause
    scene bg render1156 with dissolve
    pause
    stop music fadeout 2.0
    scene bg render1157 with dissolve
    pause
    play music "audio/car-driving-ambience-6365.mp3"
    player_name "Jesus. I'm glad I don't need to go there"
    play music "audio/0.4 soundtrack/the_mountain-horror-487014.mp3"
    scene bg render1158 with dissolve
    pause

    play sound "audio/0.4/dragon-studio-deep-sea-monster-roar-329857.mp3"
    scene bg render1159 with dissolve
    pause
    scene bg render1670 with dissolve
    pause
    scene bg render1671 with dissolve
    pause

    stop music fadeout 1.0
    play sound "audio/car-driving-ambience-6365.mp3" loop

    scene bg render1161 with dissolve
    pause
    scene bg render1160 with dissolve
    pause
    scene bg render1162 with dissolve
    pause
    scene bg render1165 with dissolve
    pause
    scene bg render1166 with dissolve
    pause
    player_name "Hey, can you hear me? I'm here"

    scene bg render1169 with dissolve
    pause
    stop sound fadeout 1.0
    scene bg render1168 with dissolve
    pause
    play sound "audio/0.4/u_q2hb2391vb-thunder-clap-521194.mp3"
    scene bg render1167 with dissolve
    pause

    scene bg render1168 with dissolve
    pause
    scene bg render1171 with dissolve
    pause
    scene bg render1170 with dissolve
    pause
    scene bg render1172 with dissolve
    player_name "There she is."
    scene bg render1173 with dissolve
    pause
    play sound "audio/car-door-close-6929.mp3"
    scene bg render1174 with dissolve
    pause
    scene bg render1175 with dissolve
    pause
    scene bg render1176 with dissolve
    pause
    scene bg render1177 with dissolve
    Rim "Thanks for coming."
    scene bg render1178 with dissolve
    pause
    scene bg render1179 with dissolve
    player_name "Is this the place?"
    scene bg render1180 with dissolve
    Rim "Right up ahead"
    play sound "audio/0.4/universfield-thunder-strike-124463.mp3"
    scene bg render1181 with dissolve
    pause
    player_name "We need to hurry"
    scene bg render1182 with dissolve
    player_name "Let's go"
    scene bg render1183 with dissolve
    pause
    scene bg render1184 with dissolve
    player_name "If you don't mind me asking..."
    scene bg render1185 with dissolve
    player_name "Why did they took just her?"
    scene bg render1186 with dissolve
    Rim "When I heard them coming I looked outside and they were too many for us to fight"
    Rim "And if we did, it would only attract those things so I.."
    Rim "Had to hide"
    scene bg render1187 with dissolve
    player_name "You did the right thing."
    player_name "Is this the place?"
    scene bg render1188 with dissolve
    pause
    scene bg render1189 with dissolve
    pause
    scene bg render1190 with dissolve
    pause
    play sound "audio/0.4/pwlpl-loud-thunder-sound-effect-359272.mp3"
    scene bg render1191 with dissolve
    pause 0.5
    scene bg render1192 with dissolve
    pause
    scene bg render1193 with dissolve
    player_name "Wait here."
    play sound "audio/0.4/dragon-studio-gentle-rain-07-437321.mp3" loop fadein 1.0
    scene bg render1194 with dissolve
    Rim "What? But I can help"
    player_name "Wait here."
    play music "audio/0.4 soundtrack/Adam vs creepers saving Mei.mp3" fadein 1.0
    scene bg render1195 with dissolve
    pause
    

    image AdamvsCreepers = Movie(play="images/Adam Action animations/download-qegc0p.webm", loop=False)
    show AdamvsCreepers with dissolve
    pause 9.0

    scene bg adamkillone
    pause
    play sound "audio/freesound_community-body-fall-47877.mp3"
    scene bg render1196 with dissolve
    pause
    scene bg render1197 with dissolve
    pause
    play sound "audio/0.4/dragon-studio-violent-sword-slice-2-393841.mp3"
    scene bg render1198 with dissolve
    pause
    scene bg render1199 with dissolve
    pause
    scene bg render1200 with dissolve
    pause
    play sound "audio/0.4/dragon-studio-violent-sword-slice-393848.mp3"
    scene bg render1201 with dissolve
    pause
    scene bg render1202 with dissolve
    pause
    scene bg render1203 with dissolve
    pause
    scene bg render1204 with dissolve
    pause
    scene bg render1205 with dissolve
    pause
    scene bg render1206 with dissolve
    pause
    play sound "audio/0.4/pwlpl-loud-thunder-sound-effect-359272.mp3"

    scene bg render1207 with dissolve
    pause
    play sound "audio/0.4/universfield-sword-blade-slicing-flesh-352708.mp3"
    scene bg render1208 with dissolve
    pause
    scene bg render1209 with dissolve
    pause
    scene bg render1210 with dissolve
    pause
    Cole "Do you really think you can take a Night Lord down?"
    scene bg render1211 with dissolve
    Cole "Alone?"
    pause
    scene bg render1212 with dissolve
    Thomas "Well.. Yeah! What can I say?"
    scene bg render1213 with dissolve
    Thomas "I'm pretty tough"
    scene bg render1214 with dissolve
    Cole "HaHaHa!"
    scene bg render1215 with dissolve
    Cole "Cut the bullshit. I've seen one myself"
    scene bg render1216 with dissolve
    Cole "And all I could do was try to tell my brain that
    everything was okay, that I could breathe—and it wouldn't listen."
    scene bg render1217 with dissolve
    Cole "All I did was breath and try to make my legs stop shaking"
    scene bg render1218 with dissolve
    Cole "That's how I know."
    Cole "That thing can't be killed."
    scene bg render1219 with dissolve
    pause
    scene bg render1220 with dissolve
    Thomas "Nah, I'd win"
    scene bg render1221 with dissolve
    pause
    play sound "audio/0.4/u_68csiaifb5-bulletimpact3-442719.mp3"

    scene bg render1222 with dissolve
    pause
    scene bg render1223 with dissolve
    pause
    scene bg render1224 with dissolve
    pause
    scene bg render1225 with dissolve
    Cole "Wha-"
    play sound "audio/0.4/freesound_community-gun-shots-from-a-distance-14-39756.mp3"
    scene bg render1226 with dissolve
    pause
    play sound "audio/0.4/u_68csiaifb5-bulletimpact3-442719.mp3"
    scene bg render1227 with dissolve
    pause
    scene bg render1228 with dissolve
    pause
    scene bg render1229 with dissolve
    pause
    scene bg render1230 with dissolve
    player_name "Where is the girl?"
    pause
    scene bg render1231 with dissolve
    pause
    Cole "She's... The basement"
    scene bg render1232 with dissolve
    pause
    scene bg render1233 with dissolve
    pause
    play sound "audio/0.4/freesound_community-gun-shots-from-a-distance-14-39756.mp3"
    scene bg render1234 with dissolve
    pause 0.1
    scene black 
    pause





    scene bg render1235 with dissolve
    pause
    scene bg render1236 with dissolve
    pause
    Unknown "I'm going to ask one last time.. Where is your sister and how much does she know?"
    scene bg render1237 with dissolve
    pause
    Unknown "Okay. I guess I have no choice them."
    scene bg render1238 with dissolve
    pause
    scene bg render1239 with dissolve
    pause
    scene bg render1240 with dissolve
    Unknown "I'll have to use other means to make you talk"
    scene bg render1241 with dissolve
    Unknown "Just remember, you made me do this."
    scene bg render1242 with dissolve
    Unknown "You left me no choice"
    play sound "audio/0.4/u_62htdrvg4y-gun-shot-359196.mp3"
    scene bg render1243 with dissolve
    pause
    scene bg render1244 with dissolve
    pause
    scene bg render1245 with dissolve
    Mei "[p]"

    scene bg render1259 with dissolve
    pause
    play sound "audio/0.4/freesound_community-realistic-shotgun-cocking-sound-38640.mp3"
    scene bg render1260 with dissolve
    pause
    stop music 
    play sound "audio/0.4/freesound_community-shotgun-03-38220.mp3"
    play music "audio/0.4/freesound_community-tinnitus-71517.mp3"
    scene bg render1261 with dissolve
    pause
    scene bg render1262 with dissolve
    pause
    play sound "audio/0.4/freesound_community-gun-shots-from-a-distance-14-39756.mp3"
    scene bg render1263 with dissolve
    pause
    play sound "audio/0.4/freesound_community-gun-shots-from-a-distance-14-39756.mp3"

    scene bg render1264 with dissolve
    pause
    play sound "audio/0.4/freesound_community-gun-shots-from-a-distance-14-39756.mp3"
    scene bg render1265 with dissolve
    pause
    
    scene bg render1266 with dissolve
    pause
    scene bg render1267 with dissolve
    pause
    stop music fadeout 1.5
    play sound "audio/0.4/freesound_community-metallic-door-shut-98740.mp3"
    
    scene bg render1268 with dissolve
    Mei "It's okay. let him go. Just.. Get me out of here."
    
    label MeiPath:
        menu:
            "Save Mei":
                jump MeiPathOpen

            "Leave her behind and go after him":
                jump MeiPathClosed


    label MeiPathClosed:
    $ AlanDead = True
    scene bg render1269 with dissolve
    pause
    play sound "audio/0.4/koiroylers-door-opening-356028.mp3"
    scene bg render1270 with dissolve
    pause
    Alan "Fuck!"
    scene bg render1271 with dissolve
    Alan "I need to tell boss"
    play sound "audio/0.4/koiroylers-door-opening-356028.mp3"
    scene bg render1272 with dissolve
    pause
    play sound "audio/0.4/Alan Dead.mp3"
    scene bg render1273 with dissolve
    pause
    scene black
    pause
    scene bg render1248 with dissolve
    Mei "Where did you go?"
    player_name "Finish the job."
    scene bg render1249 with dissolve
    player_name "Can you walk?"
    Mei "Yeah!"
    Mei "You..."
    scene bg render1250 with dissolve
    Mei "Never mind."
    player_name "We need to go."
    Mei "Ok"
    pause
    jump Meisaved
    




    label MeiPathOpen:
    $ meipath = True
    $ meipts = 2

    scene bg render1246 with dissolve
    Mei "You came for me!"
    scene bg render1247 with dissolve
    Mei "I knew you were the right guy"
    scene bg render1248 with dissolve
    player_name "Are you hurt anywhere?"
    player_name "Did they touch you?"
    Mei "No. I guess I'm lucky"
    scene bg render1249 with dissolve
    player_name "Okay, stand up princess. Your sister is waiting for us outside"
    scene bg render1250 with dissolve
    player_name "And there might be more of these fuckers somewhere"
    player_name "I came straight to you so someone might be hid- "
    scene bg render1251 with dissolve
    pause
    Mei "Thank you!"
    player_name "It's okay, it's okay."
    scene black with dissolve
    player_name "You are safe now"
    jump Meisaved
        

    label Meisaved:
    scene bg render1252 with fade
    Mei "Can I keep this?"
    scene bg render1253 with dissolve
    player_name "Sure!"
    scene bg render1254 with dissolve
    Mei "Rim!"
    scene bg render1255 with dissolve
    Rim "Oh god!"
    scene bg render1256 with dissolve
    Rim "You're safe!"
    Mei "Thanks to you. I knew you had my back"
    scene bg render1257 with dissolve
    Mei "Ready to go home now?"
    Rim "But... Now they know where we live. Where are we going?"
    scene bg render1258 with dissolve
    pause
    Mei "Hmm"
    play music "audio/car-driving-ambience-6365.mp3"

    scene bg render1274 with fade
    pause
    scene bg render1275 with dissolve
    Mei "Thank you again [p]"
    scene bg render1276 with dissolve
    Rim "Not just for saving my sister, but for letting us stay with you for a while"
    Rim "We owe you a lot"
    scene bg render1277 with dissolve
    Mei "I know I helped you that time, but what you did for us today went beyond that."
    scene bg render1278 with dissolve
    Rim "You had to see him taking out those idiots like it was nothing"
    player_name "I'm happy to help."
    scene bg render1279 with dissolve
    player_name "You were the first people I’ve met in months, but I could tell you were good people."
    scene bg render1280 with dissolve
    player_name "Changing the subject. What do you guys know about these monsters? I was attacked by some of them yesterday."
    player_name "You didn't call them nightmares for nothing."
    scene bg render1281 with dissolve
    pause
    scene bg render1282 with dissolve
    pause
    scene bg render1283 with dissolve
    pause
    Mei "Well.. I don't have all the answers, but what I do know is that the meteor 
    that crashed was just the beginning"
    Mei "I don't know what it carried, but something about it contaminated the air
    for months, turning ordinary people into those things."
    scene bg render1284 with dissolve
    Mei "I saw parents devouring their children."
    Mei "Hiding in a bunker probably saved you from turning"
    scene bg render1285 with dissolve
    Mei "Me, Rim and my mom... We"
    Mei "We've been through a lot."
    player_name "Is that who you're trying to save from the creepers?"
    scene bg render1286 with dissolve
    Mei "I-"
    scene bg render1287 with dissolve
    Mei "Yes."
    scene bg render1288 with dissolve
    pause
    stop music
    play music "audio/0.4/freesound_community-43-ambiente-dia-day-morning-ambient-29881.mp3"
    scene bg render1289 with fade
    pause
    scene bg render1290 with dissolve
    pause
    scene bg render1291 with dissolve
    pause
    scene bg render1292 with dissolve
    pause
    scene bg render1293 with dissolve
    pause
    scene bg render1294 with dissolve
    pause
    scene bg render1295 with dissolve
    pause
    scene bg render1296 with dissolve
    pause
    scene bg render1297 with dissolve
    pause

    scene bg render1298 with dissolve
    pause
    Luna "That makes absolutely no sense."
    scene bg render1299 with dissolve
    Sara "I'm sure there's an explanation."
    scene bg render1300 with dissolve
    Sara "We just have to know where to look for it"
    scene bg render1301 with dissolve
    Luna "Where?"
    scene bg render1302 with dissolve
    Luna "Even if we-"
    scene bg render1303 with dissolve
    Anne "Morning girls."
    scene bg render1304 with dissolve
    Anne "Sorry to interrupt"
    Anne "I was just looking for [p]"
    scene bg render1305 with dissolve
    Anne "I'll make breakfast, don't take too long"
    scene bg render1306 with dissolve
    Luna "Should we go?"
    scene bg render1307 with dissolve
    Sara "Yeah, let's help her"
    scene bg render1308 with dissolve
    pause
    Anne "Hmm honey, what are you doing?"
    scene bg render1309 with dissolve
    pause
    scene bg render1310 with dissolve
    Emily "He's back"
    scene bg render1311 with dissolve
    Anne "Who's back?"
    Emily "[p]. I need to put on something nice."
    scene bg render1312 with dissolve
    pause
    scene bg render1313 with dissolve
    Mei "This place."
    scene bg render1314 with dissolve
    Rim "Feels warm"
    player_name "Come on. I need to talk to them"
    scene bg render1315 with dissolve
    player_name "Wait here I'll talk with-"
    scene bg render1316 with dissolve
    pause
    scene bg render1317 with dissolve
    pause
    scene bg render1318 with dissolve
    Anne "What's going on?"
    scene bg render1319 with dissolve
    Anne "Who are these people"
    scene bg render1320 with dissolve
    Anne "Emily said you left at night"
    player_name "These two behind me were in trouble so I went to help them "
    scene bg render1321 with dissolve
    player_name "I told them they could stay with us for a while."
    player_name "Can you call everyone?"
    scene black with fade
    pause
    scene bg render1336 with dissolve
    pause
    scene bg render1322 with dissolve
    pause
    Emily "You kept your promise."
    player_name "I told you."
    scene bg render1323 with dissolve
    Emily "Is that the girl that got kidnaped?"
    player_name "Yes."
    scene bg render1324 with dissolve
    Emily "She is pretty."
    scene bg render1325 with dissolve
    player_name "You are pretty!"
    scene bg render1326 with dissolve
    Luna "[MainLunaRelation]?"
    scene bg render1327 with dissolve
    Luna "Mom said you left at night and just came back"
    scene bg render1328 with dissolve
    Luna "And that you brought guests."
    scene bg render1335 with dissolve
    Mei "Hi!"
    scene bg render1329 with dissolve
    Luna "Hi!"
    scene bg render1330 with dissolve
    player_name "Everything's alright, sweetheart, I'll explain."
    scene bg render1331 with fade
    pause
    player_name "... After Mei saved my life I had no choice but to help her and save her back and that's why I left tonight"
    scene bg render1332 with dissolve
    Luna "Can you get that fat ass out of my face?"
    scene bg render1334 with dissolve
    Mei "Hah!"
    scene bg render1333 with dissolve
    player_name "I know this is sudden but I trust them"
    scene bg render1337 with dissolve
    Rim "* It's been so long since we saw a group of people who weren't trying to kill us *"
    scene bg render1338 with dissolve
    Rim "* We could really stay here. *"
    scene bg render1339 with dissolve
    player_name "That said. It would be cool if you guys could get along"
    player_name "I had a long night. All I want is a shower and a bed."
    stop music
    scene bg render1340 with fade
    pause
    scene bg render1341 with dissolve
    Luna "[MainLunaRelation]!"
    scene bg render1342 with dissolve
    Luna "You must be really tired. I can tell."
    scene bg render1343 with dissolve
    Luna "So I came to ask if you want me to help you clean"
    Luna "It's been a while since the last time we shared a bath"
    
    menu:
        "Take a bath with your [LunaRelation]":
            $ LunaPathIncest=True
            jump BathLuna

        "I'm tired":
            jump NoBathLuna



    label BathLuna:
    scene bg render1344 with dissolve
    Luna "Yey!"
    scene bg render1346 with dissolve
    pause
    play sound "audio/0.4/freesound_community-filling-bathtub-with-water-70449.mp3"
    scene bg render1347 with dissolve
    pause
    scene bg render1348 with dissolve
    pause
    scene bg render1349 with dissolve
    pause
    scene bg render1350 with dissolve
    pause
    player_name "..."
    Luna "All set"
    scene bg render1351 with dissolve
    pause
    stop sound
    scene bg render1352 with dissolve
    pause
    scene bg render1353 with dissolve
    Luna "Why are you still with your pants on?"
    scene bg render1354 with dissolve
    Luna "Come on, take it off"
    scene bg render1355 with dissolve
    player_name "Hey!"
    scene bg render1356 with dissolve
    player_name "I can undress myself"
    scene bg render1357 with dissolve
    Luna "It doesn't look like you're very good at it."
    player_name "I'll show you what I'm good at.."
    scene bg render1358 with dissolve
    Luna "Spare me the empty threats."
    scene bg render1359 with dissolve
    pause
    scene bg render1360 with dissolve
    pause
    scene bg render1361 with dissolve
    pause
    player_name "* I’ve always had a high libido. *"
    scene bg render1362 with dissolve
    pause
    player_name "* In my younger years, I channeled that energy into other things—making money, 
    dedicating myself to the army.*"
    player_name "*  But lately, I’ve felt less and less inclined to hold back. *"

    play sound "audio/0.4/tub.mp3"
    scene bg render1363 with dissolve
    pause
    play music "audio/0.4 soundtrack/onaldin_music-rnb-afro-chill-free-as-the-wind-341183.mp3"
    scene bg render1364 with dissolve
    pause
    scene bg render1365 with dissolve
    pause
    player_name "* It's really been a long time since the last time we did this *"
    scene bg render1366 with dissolve
    pause
    player_name "* I'm not even sure I can hold back anymore *"
    play sound "audio/0.4/tub.mp3"
    scene bg render1367 with dissolve
    pause
    scene bg render1368 with dissolve
    Luna "Hey! Are you okay?"
    scene bg render1369 with dissolve
    Luna "I know you risked your life out there. I know that look."
    scene bg render1370 with dissolve
    Luna "When I was little you were always my hero."
    Luna "Whenever you left, we were afraid. But somehow I always knew you were coming back."
    scene bg render1371 with dissolve
    Luna "I know that things are really bad out there but if I have you with me"
    Luna "I know I'm safe."
    scene bg render1372 with dissolve
    pause
    scene bg render1373 with dissolve
    pause
    play sound "audio/0.4/freesound_community-kissing-6174.mp3" fadein 1.0

    scene bg render1374 with dissolve
    pause
    scene bg render1375 with dissolve
    Luna "We should get you cleaned up"
    scene bg render1376 with dissolve
    Luna "I know there's a sponge somewhere in here"
    scene bg render1377 with dissolve
    Luna "Is that it?"
    scene bg render1379 with dissolve
    Luna "There you are."
    scene bg render1378 with dissolve
    pause
    player_name "* Damn... Fuck self-control.*"

    scene bg render1380 with dissolve
    pause
    scene bg render1381 with dissolve
    Luna "Aahng!"
    pause
    scene bg render1382 with dissolve
    pause
    player_name "* Her ass is soft but firm *"
    scene bg render1383 with dissolve
    Luna "Hm!"
    pause
    scene bg render1384 with dissolve
    Luna "You just can't keep your hands to yourself can you?"
    scene bg render1386 with dissolve
    Luna "Are you having fun back there?"
    scene bg render1387 with dissolve
    player_name "YES! You can't just throw that ass in my face and think there won't be consequences."
    scene bg render1388 with dissolve
    player_name "Wha-"
    Luna "Two can play that game, you know."
    pause
    scene bg render1389 with dissolve
    Luna "And we both know I always beat you"
    pause
    scene bg render1390 with dissolve
    Luna "What happened?"
    Luna "Cat got your tongue?"
    pause

    
    image LunaAdamass = Movie(play="images/animation/0.4anime/luna/luna10001-0080-yf3jji.webm", loop=True)
    show LunaAdamass with dissolve
    pause
    player_name "Dear god."
    Luna "What's wrong? Is something distracting you?"
    player_name "Maybe..."
    pause
       
    image LunaAdamrub = Movie(play="images/animation/0.4anime/luna/luna20001-0080-rdqeql.webm", loop=True)
    show LunaAdamrub with dissolve
    Luna "Humf"
    player_name "I'll show you who's in control."
    Luna "[MainLunaRelation]! That's not fair"
    player_name "You started it."
    Luna "Okay then, let me finish it"


    scene bg render1391 with dissolve
    pause
    player_name "Are you sure?"
    scene bg render1392 with dissolve
    Luna "God! It's huge."
    scene bg render1393 with dissolve
    Luna "What did you feed this thing?"

    image LunaAdamhand = Movie(play="images/animation/0.4anime/luna/luna30001-0080-kbjf02.webm", loop=True)
    show LunaAdamhand with dissolve
    pause
    player_name "Fuck! I love your tiny little hand."
    Luna "Yeah? You like how small my hand is compared to your dick?"
    Luna "Such a dirty daddy."
    player_name "Hmmm! baby if you keep saying this..."
    Luna "What? are you going to cum on me?"
    player_name "God, You know how to get me."
    scene bg render1394 with dissolve
    Luna "Can I"
    Luna "Taste it?"

    menu:
        "Let her taste it":
            jump LunaTaste

        "That's too much":
            jump NoTasteLuna




    label NoTasteLuna:
    scene bg render1402 with dissolve
    Luna "Awmmm, you can't just show me a piece of cake then say no that's mean."
    pause
    scene black
    pause

    jump EndofLunaAndAdam


    label LunaTaste:
    scene bg render1395 with dissolve
    pause
    scene bg render1396 with dissolve
    pause
    scene bg render1397 with dissolve
    pause
    scene bg render1398 with dissolve
    pause
    scene bg render1399 with dissolve
    pause
    scene bg render1400 with dissolve
    pause
    scene bg render1401 with dissolve
    pause
    image LunaAdamsuck = Movie(play="images/animation/0.4anime/luna/luna40001-0080-txbtfr.webm", loop=True)
    show LunaAdamsuck with dissolve
    pause
    player_name "Oh my fucking god."
    player_name "Why does it feel so good?"
    player_name "You are driving me fucking..."
    
    image LunaAdamsucks = Movie(play="images/animation/0.4anime/luna/luna50001-0080-qlp4ae.webm", loop=True)
    show LunaAdamsucks with dissolve
    pause
    player_name "Hmmm! My legs are shaking."
    Luna "Hhmmm"
    player_name "I love your tongue. Shit!"
    pause

    scene bg render1402 with dissolve
    player_name "* Why does it feel 100 times better then any blowjob I've ever had? *"
    player_name "* Is it the fact that she is my [LunaRelation]? It feels like my first time*"

    player_name "I'm cumming baby!"
    scene bg render1403 with dissolve
    pause

    scene bg render1404 with dissolve
    pause

    scene bg render1405 with dissolve
    pause

    scene bg render1406 with dissolve
    pause


    scene bg render1408 with dissolve
    pause
    Luna "That was good."
    Luna "Maybe we should go back to cleaning you."
    player_name "Yeah. That was amazing"
    stop music fadeout 2.0
    jump EndofLunaAndAdam


    label NoBathLuna:
    scene bg render1345 with dissolve
    Luna "Yeah, okay, sorry."
    jump Breakfast
   
    label EndofLunaAndAdam:

    scene bg render1409 with dissolve
    pause

    scene bg render1410 with dissolve
    pause

    scene bg render1411 with dissolve
    Rim "Ah! Sorry"

    scene bg render1412 with dissolve
    Rim "I was looking for the bathroom"
    player_name "Don't worry. You found it"

    scene bg render1413 with dissolve
    Rim "Hi, your name is Luna right? Your mom told me to come look for you"
    Rim "Could you help me with my hair? I usually ask my sister but she had a long night."
    label Breakfast:
    scene bg render1414 with dissolve
    pause
    Alice "Is this bread?"
    Anne "Yes, I made it myself"
    scene bg render1415 with dissolve
    Emily "It looks so good."
    pause
    scene bg render1416 with dissolve
    player_name "Hi sexy, I'm sorry I couldn't really talk to you earlier. "
    play sound "audio/kisst.mp3"

    scene bg render1417 with dissolve
    pause

    scene bg render1418 with dissolve
    player_name "You too, sweetie."

    scene bg render1419 with dissolve
    player_name "my lovely girl"

    scene bg render1420 with dissolve
    pause

    scene bg render1421 with dissolve
    pause
    Anne "I almost thought you had forgotten about me."

    scene bg render1422 with dissolve
    player_name "Never."

    scene bg render1423 with dissolve
    pause

    scene bg render1424 with dissolve
    Anne "Let's eat."

    scene bg render1425 with dissolve
    pause
    player_name "Wow! It does look good"

    scene bg render1487 with dissolve
    pause
    Luna "Did you like it?"

    scene bg render1488 with dissolve
    Rim "I loved it! Thank you"

 
    scene bg render1509 with dissolve
    pause

    scene bg render1510 with dissolve
    pause
    Anne "He looks so peaceful."
    Anne "I guess he needs some rest"


    scene bg render1426 with fade
    pause

    scene bg render1427 with dissolve
    pause
    player_name "..."

    scene bg render1428 with dissolve
    Emily "There you are."

    scene bg render1429 with dissolve
    pause
    Emily "You seem so lost in your own thoughts."

    scene bg render1430 with dissolve
    Emily "Is everything ok?"

    scene bg render1431 with dissolve
    player_name "Well, it is now"

    scene bg render1432 with dissolve
    player_name "There are no problems when you're around"

    scene bg render1433 with dissolve
    Emily "Really? Should I get even closer then?"

    scene bg render1434 with dissolve
    player_name "I won't ever say no to that."

    scene bg render1435 with dissolve
    Emily "Even when there's someone else here?"

    scene bg render1436 with dissolve
    pause
    player_name "What is she doing?"

    scene bg render1437 with dissolve
    Emily "She explained it to me, but I didn't understand a thing."

    scene bg render1438 with dissolve
    Emily "Anyway"
    Emily "Hearing you say that you'll never refuse me makes me want to test it"
    play sound "audio/kisst.mp3"

    scene bg render1439 with dissolve
    pause

    scene bg render1440 with dissolve
    player_name "Are you sure?"

    scene bg render1441 with dissolve
    pause

    scene bg render1442 with dissolve
    pause
    scene bg render1443 with dissolve
    pause

    scene bg render1444 with dissolve
    pause
    play music "audio/0.4 soundtrack/Emi sneak sext.mp3" fadein 1.0 volume 0.5

    scene bg render1445 with dissolve
    pause

    scene bg render1446 with dissolve
    pause

    scene bg render1447 with dissolve
    pause

    scene bg render1448 with dissolve
    pause

    scene bg render1449 with dissolve
    Emily "Don't be shy."

    scene bg render1450 with dissolve
    player_name "Then show me"

    scene bg render1451 with dissolve
    pause
  

    scene bg render1454 with dissolve
    pause

    scene bg render1455 with dissolve
    pause

    scene bg render1456 with dissolve
    pause

    scene bg render1457 with dissolve
    pause

    scene bg render1458 with dissolve
    pause

    scene bg render1459 with dissolve
    pause

    scene bg render1460 with dissolve
    pause

    scene bg render1462 with dissolve
    pause


    scene bg render1464 with dissolve
    pause

    scene bg render1465 with dissolve
    pause

    scene bg render1466 with dissolve
    pause

    scene bg render1467 with dissolve
    pause

    scene bg render1469 with dissolve
    pause

    scene bg render1470 with dissolve
    pause

    scene bg render1471 with dissolve
    pause


    scene bg render1473 with dissolve
    pause
    image EmiSneak = Movie(play="images/animation/0.4anime/emi/emi10001-0079-sphitb.webm", loop=True)
    show EmiSneak with dissolve
    pause
    player_name "Hmmm! Did I pass your test?"
    Emily "No, not yet."
    Emily "Yeah! Slowly"
    Emily "I still haven't gotten used to the size."
    player_name "Don't worry, we're going to train a lot."
    pause
    image EmiSneak2 = Movie(play="images/animation/0.4anime/emi/emi20001-0079-t2frvn.webm", loop=True)
    show EmiSneak2 with dissolve
    pause
    Emily "What do you think she'd say if she caught us?"
    player_name "I hope we don't find out."
    pause

    image EmiSneak3 = Movie(play="images/animation/0.4anime/emi/emi30001-0079-juqst1.webm", loop=True)
    show EmiSneak3 with dissolve
    pause
    Emily "Yeah! Stretch my pussy."

    scene bg render1474 with dissolve
    pause

    scene bg render1475 with dissolve
    pause
    Sara "* I think we have enough for a few years.*"
    scene bg render1476 with dissolve
    Sara "*I hope *"

    scene bg render1675 with dissolve
    pause

    image EmiSneak6 = Movie(play="images/animation/0.4anime/emi/emi60001-0080-xe0az1.webm", loop=True)
    show EmiSneak6 with dissolve
    pause
    player_name "This tight little pussy is squeezing me."
    Emily "...."
    player_name "I can't control myself."
    player_name "Even if she sees us. I don't care anymore."
    pause


    image EmiSneak8 = Movie(play="images/animation/0.4anime/emi/emi80001-0079-0uqt9h.webm", loop=True)
    show EmiSneak8 with dissolve
    pause
    Emily "I can't think straight anymore either."
    Emily "This cock feels so good."
    Emily "Don't stop"
    Emily "Even if someone cathes us."
    Emily "Don't take it out."
    pause

    image EmiSneak7 = Movie(play="images/animation/0.4anime/emi/emi70001-0079-mnmuqj.webm", loop=True)
    show EmiSneak7 with dissolve
    pause
    player_name "Oh God!"
    player_name "I don't think I-"
    pause

    scene bg render1477 with dissolve
    pause

    scene bg render1478 with dissolve
    pause

    scene bg render1479 with dissolve
    Emily "Hi Mom"
    Sara "Hey guys. I'll head outside do you guys need anything?"

    scene bg render1480 with dissolve
    pause
    Emily "N- No, we are talking about a few things"
    Sara "Okay!"
    scene bg render1481 with dissolve
    Emily "That was close"

    image EmiSneak4 = Movie(play="images/animation/0.4anime/emi/emi40001-0079-y5brf9.webm", loop=True)
    show EmiSneak4 with dissolve
    pause
    Emily "Having you inside me with her so close made me so wet"
    player_name "I could feel your grip tightening around me."
    player_name "Did it turn you on being watched?"
    Emily "Maybe."
    image EmiSneak5 = Movie(play="images/animation/0.4anime/emi/emi50001-0079-y14vmz.webm", loop=True)
    show EmiSneak5 with dissolve
    pause
    player_name "Maybe?"
    player_name "You should be honest with me"
    player_name "Otherwise, I'm going to punish you."
    Emily "Punish me daddy."
    scene bg render1482 with dissolve
    pause

    scene bg render1483 with dissolve
    pause

    scene bg render1484 with dissolve
    Emily "Aahng! I'm cumming!"
    player_name "Fuck. I ended up doing it inside."
    Emily "Good!"
    stop music fadeout 1.5

    scene bg render1495 with fade
    pause
    scene bg render1495 with fade
    pause


    scene bg render1495 with dissolve
    pause

    scene bg render1496 with dissolve
    pause

    scene bg render1497 with dissolve
    pause

    scene bg render1498 with dissolve
    Mei "RIM!!"

    scene bg render1499 with dissolve
    pause

    scene bg render1500 with dissolve
    pause
    play sound "audio/0.4/pool water.mp3"
    Rim "Hahaha!"
    Luna "Are you giving up?"

    scene bg render1501 with dissolve
    pause
    Rim "I need a break"

    scene bg render1502 with dissolve
    pause

    scene bg render1503 with dissolve
    pause
    Sara "They look so cute"

    scene bg render1504 with dissolve
    pause

    scene bg render1506 with dissolve
    Rim "I don't remember the last time I swam in a pool."

    scene bg render1507 with dissolve
    pause
    Rim "I needed that"

    scene bg render1508 with dissolve
    pause
    scene bg render1505 with dissolve
    pause
    Mei "Looks like someone is having fun"

    scene bg render1677 with fade
    pause
    Mei "[p]."
    scene bg render1678 with dissolve
    pause
    scene bg render1679 with dissolve
    Mei "Can I talk with you for a sec?"
    pause
    scene bg render1680 with dissolve
    Mei "As I said before"
    scene bg render1681 with dissolve
    Mei "I couldn't be more grateful."
    Mei "You've already done enough for us."
    scene bg render1682 with dissolve
    pause
    Mei "But I still have to ask for your help with this"
    scene bg render1683 with dissolve
    Mei "I know it's not fair."
    scene bg render1684 with dissolve
    Mei "But I still have to try"
    scene bg render1685 with dissolve
    Mei "Even if it costs me everything I have"
    scene bg render1686 with dissolve
    Mei "So..."
    play music "audio/0.4 soundtrack/the plan.mp3" fadein 1.0 volume 0.5

    scene bg render1687 with dissolve
    Mei "Will you help us?"

    scene bg render1688 with dissolve
    pause
    player_name "I'm in."
    scene bg render1689 with dissolve
    player_name "We're together now."
    pause
    scene bg render1690 with dissolve
    pause
    stop music fadeout 2.0
    scene bg render1691 with dissolve
    pause

    label MeipathOpennight:
    if meipath:
        jump MeiAndAdamLateNight

    else:
        jump Latenight
  

    label MeiAndAdamLateNight:
    scene bg render1511 with fade
    pause
    Mei "I just wanted to thank you again"

    scene bg render1512 with dissolve
    pause
    Mei "It's been a while since the last time I saw Rim having fun"

    scene bg render1513 with dissolve
    Mei "And everyone was so kind to us."

    scene bg render1514 with dissolve
    Mei "Thank you."

    scene bg render1515 with dissolve
    pause

    scene bg render1516 with dissolve
    pause

    scene bg render1517 with dissolve
    pause
    player_name "Let me know if you need anything."

    scene bg render1518 with dissolve
    pause
    Mei "Okay"

    scene bg render1519 with dissolve
    Mei "Good Night!"

    label Latenight:
    scene bg render1520 with dissolve
    pause
    Alice "Come on, you know that's not true"

    scene bg render1521 with dissolve
    pause
    Sara "I like them"

    scene bg render1522 with dissolve
    pause

    scene bg render1523 with dissolve
    Emily "Hi!"

    scene bg render1524 with dissolve
    Sara "Do you-"

    scene bg render1525 with dissolve
    pause

    scene bg render1526 with dissolve
    player_name "Hey girls I just came to give you guys a proper good night"

    scene bg render1527 with dissolve
    pause

    scene bg render1528 with dissolve
    Sara "*Oh!*"

    scene bg render1529 with dissolve
    pause
    Sara "* He doesn't even try to hide it anymore. *"

    scene bg render1530 with dissolve
    Emily "Hey!"
    scene bg render1531 with dissolve
    Emily "Why am I the second?"

    scene bg render1532 with dissolve
    player_name "So I can have more time with you"

    scene bg render1533 with dissolve
    Emily "Liar"

    scene bg render1534 with dissolve
    pause

    scene bg render1535 with dissolve
    pause

    scene bg render1536 with dissolve
    pause

    scene bg render1537 with dissolve
    pause
    player_name "Now it's your turn"

    scene bg render1538 with dissolve
    Sara "Ah!"

    scene bg render1539 with dissolve
    Sara "No, No, I'm Okay"

    scene bg render1540 with dissolve
    Sara "I don't need it"

    scene bg render1541 with dissolve
    Sara "There's no need for that"

    label KissOrNot:
        menu:
            "Kiss her anyway":
                $ kissedSara = True
                jump KissSara

            "Leave her alone":
                jump Bedtime


    label KissSara:
    scene bg render1542 with dissolve
    pause
    Sara "W- Wait honey I.."

    scene bg render1543 with dissolve
    Sara "Hahah! You won't take no for an answer."

    scene bg render1544 with dissolve
    Sara "You can't just do that, you know"

    scene bg render1545 with dissolve
    pause
    player_name "Watch me"

    scene bg render1546 with dissolve
    pause

    scene bg render1547 with dissolve
    pause

    scene bg render1548 with dissolve
    Sara "Humf"

    scene bg render1549 with dissolve
    Sara "* Oh God, He...*"
    pause

    scene bg render1550 with dissolve
    pause

    scene bg render1551 with dissolve
    pause


    scene bg render1552 with dissolve
    pause

    scene bg render1553 with dissolve
    pause
    Sara "There, you gave me your goodnight kiss."
    Sara "Are you happy now?"
    player_name "Is it that obvious?"

    scene bg render1554 with dissolve
    pause
    Alice "Get a room you two. What the hell?"


    label Bedtime:
    scene bg render1555 with fade
    pause
    scene bg render1556 with dissolve
    pause

    scene bg render1557 with dissolve
    pause
    Luna "So she said that sick people started turning into monsters overnight."

    scene bg render1558 with dissolve
    Luna "She said that random people would turn into bizarre things inside the camps without having even been injured beforehand."

    scene bg render1559 with dissolve
    Luna "Her sister, and her mother slept in different rooms every night with the doors locked, not knowing if they would make it through the night."

    scene bg render1560 with dissolve
    Luna "Even without getting sick, they were still afraid because they didn't understand what was happening."

    scene bg render1561 with dissolve
    Luna "I think we were very lucky."

    scene bg render1562 with dissolve
    Luna "Can you imagine living like that?"

    scene bg render1563 with dissolve
    Luna "I don't think that we-"

    scene bg render1564 with dissolve
    Luna "AAh! Ahahaha S-"

    scene bg render1565 with dissolve
    Luna "Stop [MainLunaRelation], Wait I am- Ah!"

    scene bg render1566 with dissolve
    Luna "OH MY GOD! You are killing me [MainLunaRelation]! I'm Gonna die stop"
    Luna "MOM HELP ME!"

    scene bg render1567 with dissolve
    Luna "NOOO TWO AGAINST ONE? YOU ARE KILLING ME HAHAHA! I'M DYING."
    scene black with fade
    pause

    label LunaIncestPath:
    if LunaPathIncest:
        jump LunaBedtimeSex

    else:
        jump skipTheNight
  

    label LunaBedtimeSex:
    scene bg render1568 with fade
    pause
    scene bg render1569 with dissolve
    pause
    Luna "Thank you for letting me sleep here"

    scene bg render1570 with dissolve
    player_name "What? of course you can sleep here. What are you talking about?"

    scene bg render1571 with dissolve
    Luna "Well. I know that you and mom would be..."

    scene bg render1572 with dissolve
    Luna "Doing naughty things right now."

    scene bg render1573 with dissolve
    player_name "How do you know that?"

    scene bg render1574 with dissolve
    Luna "Well, maybe because you do it every night?"

    scene bg render1575 with dissolve
    Luna "You think we can't hear my mom moaning?"

    scene bg render1576 with dissolve
    player_name "WE?"

    scene bg render1577 with dissolve
    player_name "Me and Aunt Sara. I bet she can hear it even though she is good at hiding it"

    scene bg render1578 with dissolve
    Luna "We can hear everything. Whenever she's close to cumming, you thrust harder."
    Luna "And faster"

    scene bg render1579 with dissolve
    pause
    Luna "She keeps saying how big it is. My guess is that hearing mom saying that turns you on. That's why she keeps saying it"
    play music "audio/0.4 soundtrack/johnnyzet666-johnnyzet666-sensual-system-error-502056.mp3"  fadein 1.0
    Luna "Also. Something tells me that you could keep going over and over again but you don't because you don't wanna hurt her"
    Luna "You know... Earlier in the bathtub.. You finished, but I didn't... "
    scene bg render1580 with dissolve
    pause
    Luna "Maybe we could..."
    player_name "Let's do it"

    scene bg render1581 with dissolve
    pause

    scene bg render1582 with dissolve
    pause

    scene bg render1583 with dissolve
    pause
 
    scene bg render1586 with dissolve
    pause

    scene bg render1587 with dissolve
    pause

    scene bg render1588 with dissolve
    pause
    player_name "You are perfect baby girl"

    scene bg render1589 with dissolve
    pause

    scene bg render1590 with dissolve
    pause

    scene bg render1591 with dissolve
    Luna "I wanna try something"
    pause


    scene bg render1592 with dissolve
    Luna "Is everything okay?"

    scene bg render1593 with dissolve
    player_name "Yeah, go ahead."

    scene bg render1594 with dissolve
    Luna "Humm"
    pause

    scene bg render1595 with dissolve
    pause
    Luna "Oh! Your tongue is- Fuck "

    scene bg render1596 with dissolve
    Luna "I've never Geez  that's good."

    image LunaBedtime = Movie(play="images/animation/0.4anime/luna sleep/lunes10001-0079-bokitn.webm", loop=True)
    show LunaBedtime with dissolve
    pause
    Luna "Oh God I'm gonna cum so fucking fast"
    Luna "Why didn't we do this before?"
    pause
    Luna "If I had known it was so good, I would have given it to you already."
    Luna "Eat me up Daddy"
    pause
    image LunaBedtime2 = Movie(play="images/animation/0.4anime/luna sleep/lunes20001-0079-4wsfmw.webm", loop=True)
    show LunaBedtime2 with dissolve
    pause
    Luna "* I wanted to suck it while he eats me but I just can't think straight*"
    Luna "You are so good [MainLunaRelation]."


    scene bg render1597 with dissolve
    Luna "I'm cumming!"
    pause

    scene bg render1598 with dissolve
    pause

    scene bg render1599 with dissolve
    pause

    scene bg render1600 with dissolve
    Luna "Ah! Shit"

    
    scene bg render1615 with dissolve
    pause
    Luna "* Let me at least taste it again*"

    scene bg render1616 with dissolve
    player_name "Come here baby"
    pause

    
    scene bg render1617 with dissolve
    pause

    scene bg render1618 with dissolve
    pause

    scene bg render1619 with dissolve
    pause

    scene bg render1620 with dissolve
    pause

    scene bg render1622 with dissolve
    pause

    scene bg render1621 with dissolve
    Luna "Do it"
    pause

    scene bg render1623 with dissolve
    pause

    scene bg render1624 with dissolve
    pause

    scene bg render1625 with dissolve
    pause

    scene bg render1626 with dissolve
    pause
    image LunaBedtime3 = Movie(play="images/animation/0.4anime/luna sleep/lunes30001-0095-r3mo7b.webm", loop=True)
    show LunaBedtime3 with dissolve
    pause
    player_name "Dear God. So tight"
    player_name "Don't worry baby, I'll take care of you"
    Luna "It hurts but I trust you."
    pause

    image LunaBedtime4 = Movie(play="images/animation/0.4anime/luna sleep/lunes40001-0095-me7ysw.webm", loop=True)
    show LunaBedtime4 with dissolve
    pause
    player_name "You are killing me you know."
    Luna "Is taking you [LunaRelation]'s first time turning you on too much?"
    player_name "Fuck baby if you talk like that I'll cum even faster"
    Luna "And? why would that be bad? Just make sure you cum inside me"
    player_name "You are gonna get us in trouble"

    scene bg render1627 with dissolve
    pause

    scene bg render1628 with dissolve
    pause
    Luna "Why did you stop?"

    scene bg render1629 with dissolve
    pause
    player_name "Nothing baby"

    scene bg render1630 with dissolve
    pause
    player_name "I'll do it harder now"
    Luna "Please."

    
    image LunaBedtime5 = Movie(play="images/animation/0.4anime/luna sleep/lunes50001-0080-svkobg.webm", loop=True)
    show LunaBedtime5 with dissolve
    pause
    player_name "Fuck!"
    Luna "Ahn! Ahhnnn!"
    player_name "Calm down baby. Don't wake your mother"
    Luna "Then don't fuck me so good"

    image LunaBedtime6 = Movie(play="images/animation/0.4anime/luna sleep/lunes60001-0080-esinaj.webm", loop=True)
    show LunaBedtime6 with dissolve
    pause
    Luna "Hhmf Humf hmmm"
    Luna "I'm close Daddy"
    Luna "I'm cumming"

    scene bg render1631 with dissolve
    pause

    scene bg render1632 with dissolve
    Luna "Aahhnnng ♥"
    pause

    scene bg render1633 with dissolve
    Luna "Fuuuu"
    player_name "Shhh! Not so loud"
    pause

    scene bg render1634 with dissolve
    Luna "That was out of this world."





    scene bg render1601 with fade
    pause
    Luna "I never came that hard in my life"

    scene bg render1602 with dissolve
    Luna "Now..."

    scene bg render1603 with dissolve
    Luna "I want you to take me from behind"

    scene bg render1604 with dissolve
    player_name "I don't know, the bed is going to shake a lot."

    scene bg render1605 with dissolve
    Luna "If that's the problem.."

    scene bg render1606 with dissolve
    pause

    scene bg render1607 with dissolve
    pause

    scene bg render1608 with dissolve
    pause

    scene bg render1609 with dissolve
    pause

    scene bg render1610 with dissolve
    pause

    scene bg render1611 with dissolve
    pause

    scene bg render1612 with dissolve
    pause

    scene bg render1613 with dissolve
    player_name "You are really going to get us in trouble"
    
    image LunaBedtime7 = Movie(play="images/animation/0.4anime/luna sleep/lunes70001-0080-j0jcbl.webm", loop=True)
    show LunaBedtime7 with fade
    pause
    Luna "Oh Yeah! That's fucking better"
    player_name "You are taking it so good baby"
    Luna "You make me wet like nothing else"

    image LunaBedtime8 = Movie(play="images/animation/0.4anime/luna sleep/lunes80001-0060-ewtem6.webm", loop=True)
    show LunaBedtime8 with fade
    pause
    Luna "Hm [MainLunaRelation] you are reaching so deep"
    Luna "I'm in love with your dick"
    Luna "It's so thick"
    pause
    Luna "It's twitching. Are you close?"
    player_name "Yeah baby, I'm gonna cum"
   
    image LunaBedtime9 = Movie(play="images/animation/0.4anime/luna sleep/lunes90001-0098-rr6l1u.webm", loop=True)
    show LunaBedtime9 with fade
    pause
    Luna "Cum for me"
    Luna "Don't worry about me. I just came twice."
    Luna "Cum wherever you want."

    label CumInLuna:
    menu:
        "Cum inside your baby girl":
            jump insideLuna

        "Paint your [LunaRelation]'s back white":
            jump lunasBackCum
            
   


    label insideLuna:
    scene bg cumInsideLuna with dissolve
    pause
    Luna "Aahnn!"
    Luna "You are filling me up"
    Luna "Fuck!"
    scene bg render1636 with dissolve
    Luna "I'm cumming again"

    scene bg render1635 with dissolve
    pause
    player_name "Did getting filled up made you cum?"
    pause
    Luna "... ♥"
    scene bg render1642 with dissolve
    pause
    Luna "What's wrong?"
    stop music fadeout 1.5

    scene bg render1643 with dissolve
    player_name "Nothing baby I'm just cathing my breath"

    scene bg render1644 with dissolve
    player_name "It's been a while since I came that hard."
    Luna "Hah. Is that so?"
    scene black with fade
    pause

    jump skipTheNight


    label lunasBackCum:

    scene bg render1638 with dissolve
    pause

    scene bg render1639 with dissolve
    pause 0.5

    
    scene bg render1638 with dissolve
    pause 0.5

    scene bg render1640 with dissolve
    pause

    scene bg render1641 with dissolve
    pause
    player_name "That was quite the load"
    scene bg render1635 with dissolve
    pause
    scene bg render1642 with dissolve
    pause
    Luna "What's wrong?"
    stop music fadeout 1.5
    scene bg render1643 with dissolve
    player_name "Nothing baby I'm just cathing my breath"

    scene bg render1644 with dissolve
    player_name "It's been a while since I came that hard."
    Luna "Hah. Is that so?"
    
    scene black with fade
    pause

    label skipTheNight:
    scene bg render1676 with fade
    pause
    scene bg render1692 with dissolve
    pause
    scene bg render1693 with dissolve
    pause
    
    
    scene bg render1645 with fade
    pause
    Sam "I found that group that was causing trouble."
    play music "audio/0.4 soundtrack/Creepers Leaders THEME.mp3"

    scene bg render1646 with dissolve
    pause
    Sam "I was surprised by their numbers. I thought they were smaller."

    scene bg render1647 with dissolve
    Sam "I can't say it was a struggle. Such a shame"

    scene bg render1648 with dissolve
    Sam "They had some good supplies though"
    Miller "Did you do it?"
    scene bg render1649 with dissolve
    Sam "What?"
    Miller "Did you rape them?"
    Sam "No you sick fuck. I didn't rape them, Is that all you think about?"
    scene bg render1650 with dissolve
    pause
    Yuri "What are you pussies talking about?"
    Sam "Nothing. That guy is fucking weird"

    scene bg render1651 with dissolve
    pause
    Williams "What a pain."

    scene bg render1652 with dissolve
    pause

    scene bg render1653 with dissolve
    Williams "Spare me from your high-level conversation."

    scene bg render1654 with dissolve
    pause

    scene bg render1655 with dissolve
    pause

    scene bg render1656 with dissolve
    pause

    scene bg render1657 with dissolve
    pause

    scene bg render1658 with dissolve
    pause

    scene bg render1659 with dissolve
    Graves "We have a lot to do."

    scene bg render1660 with dissolve
    pause

    scene bg render1661 with dissolve
    pause

    scene bg render1662 with dissolve
    pause

    scene bg render1663 with dissolve
    pause
    Graves "I won't repeat myself."

    
    label AlanAlive:
    if AlanDead:
        jump alandeeaad

    else:
        jump alanAlive
  

    label alanAlive:
    Alan "Boos"
    scene bg render1665 with dissolve
    pause
    Alan "We have a problem"
    pause

    label alandeeaad:
        scene black
        pause

    stop music
    play sound "audio/freesound_community-birds-19624.mp3"

    scene bg render1696 with dissolve
    pause

    scene bg render1697 with dissolve
    pause
    scene bg render1698 with dissolve
    pause
    scene bg render1699 with dissolve
    pause

    label MorningSexWithLun:
        if LunaPathIncest:
            jump LunaSexMorn
        else: 
            jump SkipLunaSexMorn




    label LunaSexMorn:
    stop sound
    play music "audio/0.5 soundtrack/sex/vicatestudio-fashion-deep-492457.mp3"
    scene bg render1700 with dissolve
    pause

    scene bg render1701 with dissolve
    Luna "Ahhng!"
    pause

    scene bg render1702 with dissolve
    pause

    scene bg render1703 with dissolve
    player_name "Good Morning!"
    

    scene bg render1704 with dissolve
    Luna "Hey!"
    pause

    scene bg render1705 with dissolve
    Luna "This is a nice way to wake up."
    pause

    scene bg render1706 with dissolve
    Luna "But you might regret it."
    pause

    scene bg render1707 with dissolve
    pause
    player_name "Is that so?"

    scene bg render1708 with dissolve
    Luna "Don't start what you can't finish."
    

    scene bg render1709 with dissolve
    pause

    scene bg render1710 with dissolve
    player_name "Funny, your first time was yesterday and you're already full of yourself."
    pause

    scene bg render1711 with dissolve
    pause
    player_name "I'm going to put you in your place."

    scene bg render1712 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/slimySoundmp3.mp3"
    scene bg render1713 with dissolve
    Luna "Hhmmm!"
    pause

    stop sound
    scene bg render1714 with dissolve
    Luna "Put me in my place, you said"
    pause
    play sound "audio/0.5 soundtrack/general/LunaMoan.mp3" loop

    image LunaMorningSex = Movie(play="images/animation/0.5 ALL ANIMATIONS/lUNA/webm/first0001-0080-ok4fu3.webm", loop=True)
    show LunaMorningSex 
    pause
    Luna "I guess you need to take control for that, don't you?"
    player_name "God! It's so tight"
    Luna "Hm? I can't hear you"
    player_name "Don't stop"
    
    image LunaMorningSex2 = Movie(play="images/animation/0.5 ALL ANIMATIONS/lUNA/webm/second0001-0080-1zxjuo.webm", loop=True)
    show LunaMorningSex2 with dissolve
    pause
    Luna "Stop? me?"
    Luna "You never learn, do you?"
    player_name "Fuck baby, so good."
    player_name "Come here."

    image LunaMorningSex3 = Movie(play="images/animation/0.5 ALL ANIMATIONS/lUNA/webm/third0001-0080-wpwk05.webm", loop=True)
    show LunaMorningSex3 with dissolve
    pause
    Luna "Humf Humf Hhhmmmn"
    player_name "* I could stay here all day fucking her *"
    player_name "* I never thought we’d actually do this. *"
    Luna "Do me harder!"
    player_name "* But now I regret not doing it sooner. *"
    scene bg render1715 with dissolve
    pause
    Luna "* I'm gonna fucking cum all over his dick *"

    scene bg render1716 with dissolve
    pause

    image LunaMorningSex4 = Movie(play="images/animation/0.5 ALL ANIMATIONS/lUNA/webm/forth0001-0080-wdxnnn.webm", loop=True)
    show LunaMorningSex4 with dissolve
    pause
    player_name "You went quiet, huh?"
    player_name "Perhaps you have understood your place?"
    Luna "Hmf Hmf N- No. I haven't lost yet."
    player_name "Is that so?"

    image LunaMorningSex5 = Movie(play="images/animation/0.5 ALL ANIMATIONS/lUNA/webm/fith0001-0080-erbvfw.webm", loop=True)
    show LunaMorningSex5 with dissolve
    pause
    player_name "I wonder how long you'll take"
    player_name "I might not stop even when you beg me, just for challenging me."
    player_name "Went quient again?"
    player_name "You're getting tighter, it's coming."
    image LunaMorningSex6 = Movie(play="images/animation/0.5 ALL ANIMATIONS/lUNA/webm/six0001-0070-8b3vc8.webm", loop=True)
    show LunaMorningSex6 with dissolve
    stop sound
    play sound "audio/0.5 soundtrack/general/clapsoun.mp3" loop
    pause
    Luna "Ahn Ahn Ahnnn"
    player_name "Cum for me baby"
    Luna "Hmmmm FUuuuuu-"
    image LunaMorningSex7 = Movie(play="images/animation/0.5 ALL ANIMATIONS/lUNA/webm/sevencumming0001-0042-dxlswv.webm", loop=False)
    show LunaMorningSex7 with dissolve
    pause 0.8
    stop sound
    scene bg render1717 with dissolve
    pause
    Luna "Hmmm! ♡"

    scene bg render1718 with dissolve
    Luna "just because I came, It doesn't mean I lost."
    pause



    scene bg render1720 with dissolve
    pause
    Luna "How does it feel to be dominated?"
    player_name "You think I can't fuck you in this position?"


    scene bg render1724 with dissolve
    Luna "Haha! You never let me win "

    scene bg render1725 with dissolve
    Luna "Dummy."

    scene bg render1726 with dissolve
    player_name "I don't think we have much time before someone comes. "

    scene bg render1727 with dissolve
    Luna "If that's the case..."

    play sound "audio/0.5 soundtrack/general/LunaMoan2.mp3" loop
    image LunaMorningSex8 = Movie(play="images/animation/0.5 ALL ANIMATIONS/lUNA/webm/last0001-0096-qgt4te.webm", loop=True)
    show LunaMorningSex8 with dissolve
    pause
    Luna "Shit!"
    Luna "It feels like I'm impaling myself."
    Luna "And it's SO FUCKING good!"
    Luna "Tell me you'll pump me full of cum daddy."
    Luna "I need to hear it"
    player_name "I'll fill you up so good baby"
    scene bg render1728 with dissolve
    stop sound
    Luna "I'm so horny!"
    Luna "I wanna try something."
    pause
    scene bg render1729 with dissolve
    pause

    scene bg render1730 with dissolve
    pause

    scene bg render1731 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/tongueSuck.mp3" loop

    scene bg render1732 with dissolve
    pause


    scene bg render1734 with dissolve
    pause

    scene bg render1735 with dissolve
    pause
    Luna "Hmmmm"
    stop sound
    scene bg render1736 with dissolve
    pause

    scene bg render1737 with dissolve
    Luna "I can feel you are close."
    stop music
    scene bg render1738 with dissolve
    Emily "Alice, where are you going?"
    Alice "Wake them up."
    Emily "Let them sleep."
    pause
    label SkipLunaSexMorn:

    scene bg render1739 with dissolve
    Alice "Shut up!"
    Alice "I'm gonna wake them up!"
    pause

    scene bg render1740 with dissolve
    pause

    scene bg render1741 with dissolve
    Alice "* I wanna wake him up in a special way *"
    pause

    scene bg render1742 with dissolve
    pause

    scene bg render1743 with dissolve
    Alice "Owm! you are awake"
    pause

    scene bg render1744 with dissolve
    Luna "Morning."

    scene bg render1745 with dissolve
    player_name "Did you sleep well?"
    

    scene bg render1746 with dissolve
    Alice "Could've been better"

    scene bg render1747 with dissolve
    player_name "I'm starving"
    Luna "Alice, come here"

    scene bg render1748 with dissolve
    Luna "[p] says I'm too big for piggyback rides."
    player_name "I never-"
    Luna "Shhh!"
    pause

    scene bg render1749 with dissolve
    player_name "Hey look."

    scene bg render1750 with dissolve
    player_name "Two floors of ass"
    Alice "If you're not going to climb, hands off."

    scene bg render1751 with dissolve
    player_name "Good morning!"

    scene bg render1752 with dissolve
    Sara "Morning sweetie."

    scene bg render1753 with dissolve
    Sara "How did it go? Did Luna kick you out of bed?"

    scene bg render1754 with dissolve
    Emily "If she did, we would've heard it"

    scene bg render1755 with dissolve
    Sara "Hmm."

    scene bg render1756 with dissolve
    Sara "I guess you are right. After all, he's a huge goofball."

    scene bg render1757 with dissolve
    player_name "Hah! Alright, since I'm being bullied, I'm out of here."

    scene bg render1758 with dissolve
    Mei "How long are you going to sleep?"
    pause

    scene bg render1759 with dissolve
    Rim "With you talking non-stop, not for long."


    scene bg render1761 with dissolve
    Mei "Don't make me come back there."


    scene bg render1763 with dissolve
    Rim "Give it a rest; I know you're dying to go see your boyfriend."

    scene bg render1764 with dissolve
    Mei "Wha- S-shut up."

    scene bg render1772 with dissolve
    Mei "He is a married man, and I am not interested."
    pause



    scene bg render1777 with dissolve
    Mei "Get off that bed bofere I make you."

    scene bg render1778 with dissolve
    play music "audio/0.5 soundtrack/general/soul_serenity_sounds-ambient-noise-236388.mp3"
    Rim "So, tomorrow."

    scene bg render1779 with dissolve
    Mei "Yeah, I'll speak to his wife; you have no sensitivity."

    scene bg render1780 with dissolve
    Rim "What do you mean? I do have-"
    Mei "Shhh!"
    scene bg render1781 with dissolve
    pause

    scene bg render1782 with dissolve
    Anne "Hi girls, morning!"
    pause

    scene bg render1783 with dissolve
    Anne "Are you hungry?"
    play sound "audio/0.5 soundtrack/general/dragon-studio-opening-door-450444.mp3"
    player_name "I am"

    scene bg render1784 with dissolve
    pause

    scene bg render1785 with dissolve
    pause

    scene bg render1786 with dissolve
    Luna "Mom, Alice called me fat"
    Alice "Your mother trusts me more. She won't buy that story."

    scene bg render1788 with dissolve
    Anne "Hi!"
    player_name "Hey!"
    Mei "[p]."

    scene bg render1789 with dissolve
    pause

    scene bg render1790 with dissolve
    Mei "Good morning!"

    scene bg render1791 with dissolve
    Rim "Morning!"

    stop music
    scene bg render1793 with fade
    Emily "So they are going to live with us"

    scene bg render1794 with dissolve
    Emily "I'm happy to know we are not alone"

    scene bg render1795 with dissolve
    Emily "Right?"
    Sara "Well.. I like them too, but not everyone is good."

    scene bg render1797 with dissolve
    Emily "I know"
    scene bg render1798 with dissolve
    pause
    play music "audio/0.5 soundtrack/general/ob-lix-freyja-viking-nordic-background-music-110931.mp3"
    Emily "There must be a lot of bad people out there."

    scene bg render1799 with dissolve
    pause

    scene bg render1800 with dissolve
    pause

    scene bg render1801 with dissolve
    pause

    scene bg render1802 with dissolve
    pause

    scene bg render1803 with dissolve
    pause

    play sound "audio/0.5 soundtrack/general/spinopel-passing-car-393073.mp3"
    scene bg render1804 with dissolve
    pause

    scene bg render1805 with dissolve
    pause

    scene bg render1807 with dissolve
    pause

    scene bg render1806 with dissolve
    pause

    scene bg render1808 with dissolve
    pause

    scene bg render1809 with dissolve
    pause

   

    scene bg render1811 with dissolve
    pause

    scene bg render1814 with dissolve
    pause
    scene bg render1813 with dissolve
    pause
    Sam "* I must be close *"


    scene bg render1815 with dissolve
    pause
    stop music fadeout 1.0
    scene bg render1816 with dissolve
    pause

    scene bg render1817 with dissolve
    pause

    scene bg render1818 with dissolve
    pause
    player_name "* It's been a while since I went there*"
    play sound "audio/0.5 soundtrack/general/alex_jauk-something-falls-down-noise-196257.mp3"
    scene bg render1819 with dissolve
    player_name "Huh?"
    play music "audio/0.5 soundtrack/general/freesound_community-tension-29289.mp3"
    scene bg render1820 with dissolve
    pause

    scene bg render1821 with dissolve
    pause

    scene bg render1822 with dissolve
    pause 0.5
    play sound "audio/0.5 soundtrack/general/freesound_community-box-of-stuff-fallswav-14524.mp3"
    scene bg render1823 with dissolve
    stop music

    scene bg render1824 with dissolve
    pause

    scene bg render1825 with dissolve
    play sound "audio/0.5 soundtrack/general/dragon-studio-creaky-old-door-472357.mp3"
    pause

    scene bg render1826 with dissolve
    pause

    scene bg render1827 with dissolve
    pause
    player_name "Huh! It's just you"

    scene bg render1828 with dissolve
    player_name "Hmm"

    scene bg render1829 with dissolve
    pause

    scene bg render1830 with dissolve
    player_name "What are you doing baby?"
    Alice "You look pale."
    scene bg render1832 with dissolve
    player_name "Me? No, I... no, I'm not."

    scene bg render1833 with dissolve
    Alice "Okay."

    scene bg render1834 with dissolve
    Alice "Well I am..."

    scene bg render1835 with dissolve
    Alice "I have no idea what I'm going"

    scene bg render1836 with dissolve
    Alice "I saw a bunch of boxes and I was like, why not see what's in here since there's nothing else to do?"
    play sound "audio/0.5 soundtrack/general/oxidvideos-dropping-cardboard-box-453026.mp3"
    scene bg render1837 with dissolve
    pause 0.2

    scene bg render1838 with dissolve
    pause
    Alice "I didn't find anything cool here."

    scene bg render1839 with dissolve
    player_name "Hahaha!"

    scene bg render1840 with dissolve
    player_name "Since you are so bored..."

    scene bg render1841 with fade
    pause
    Alice "I know some time has passed, but to me, it feels like yesterday. And I feel like I could fall apart at any moment."

    scene bg render1842 with dissolve
    Alice "All of this. I feel like I’m still living in a never-ending nightmare.
    And the weirdest part is that there are moments when I hope I’ll wake up, and that’s when a sense of desperation hits me."

    scene bg render1843 with dissolve
    Alice "Because I know that all of this is real. There is no waking up from this"

    scene bg render1844 with dissolve
    Alice "But the only thing that gives me any sense of security is you."

    scene bg render1845 with dissolve
    player_name "..."

    scene bg render1846 with dissolve
    player_name "I know it’s not easy to stay motivated after all this, but even in the toughest moments, you can be sure that I will protect you."

    scene bg render1847 with dissolve
    player_name "And there is nothing in this world, alive or dead, that can hurt you while I am here."

    scene bg render1848 with dissolve
    pause
    Alice "I know."

    scene bg render1849 with dissolve
    pause

    scene bg render1850 with dissolve
    pause

    scene bg render1851 with dissolve
    Alice "But thank you for saying it."

    scene bg render1852 with dissolve
    pause

    scene bg render1853 with dissolve
    pause

    scene bg render1854 with dissolve
    pause

    label choice_scene_alice:
        menu:
            "Make her think about something else 😈":
                $ HadSexWithAliceStorageRoom = True
                jump alicescene05

            "Don't":
                jump skipAlice05


    label alicescene05:
    
    scene bg render1855 with dissolve
    pause

    scene bg render1856 with dissolve
    pause
    Alice "Hmmm! If this is your way of comforting me, I need to open up to you more."

    scene bg render1857 with dissolve
    pause
    scene bg render1858 with dissolve
    pause

    scene bg render1859 with dissolve
    play music "audio/0.5 soundtrack/sex/wbmstudio-prohibida-latin-reggaeton-pop-466601.mp3" fadein 0.5 volume 0.5
    Alice "Stand up!"

    scene bg render1860 with dissolve
    pause
    Alice "I'm always startled by the size."

    scene bg render1861 with dissolve
    Alice "So thick."
    pause

    scene bg render1862 with dissolve
    player_name "I wanna feel those lips."
    pause

    scene bg render1863 with dissolve
    pause
    player_name "Yes, like that."

    image AliceStorageRoom = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/one0001-0080-hrozj0.webm", loop=True)
    show AliceStorageRoom with dissolve
    pause
    player_name "Fuck! Yeah use that tongue baby"
    player_name "Hmf So good!"
    pause

    scene bg render1864 with dissolve
    pause

    image AliceStorageRoom2 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/two0001-0080-zsueqv.webm", loop=True)
    show AliceStorageRoom2 with dissolve
    pause
    player_name "Yeah suck that dick. Good girl"
    player_name "Hmm you are so good at this."
    pause

    scene bg render1865 with dissolve
    pause

    scene bg render1866 with dissolve
    pause
    
    scene bg render1867 with dissolve
    pause
    play sound "audio/0.5 soundtrack/sex/AliceMoant.mp3" loop
    image AliceStorageRoom3 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/three0001-0059-f0qyt3.webm", loop=True)
    show AliceStorageRoom3 with dissolve
    pause
    player_name "God. You look so sexy"
    player_name "You know how to tease me"
    player_name "You must be so wet right now"
    pause
    image AliceStorageRoom4 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/four0001-0059-3bhpsm.webm", loop=True)
    show AliceStorageRoom4 with dissolve
    pause
    player_name "Fuuuck. I'm almost fucking your throat"
    player_name "You keep going deeper. You are so good."
    Alice "Ghk Ghk hmm"
    pause
   
    stop sound
    scene bg render1867 with dissolve
    pause

    scene bg render1868 with dissolve
    pause

    scene bg render1869 with dissolve
    pause

    scene bg render1870 with dissolve
    pause

    scene bg render1871 with dissolve
    pause

    scene bg render1872 with dissolve
    pause

    scene bg render1873 with dissolve
    pause

    scene bg render1874 with dissolve
    pause

    scene bg render1875 with dissolve
    Alice "Will you do the honors?"

    scene bg render1876 with dissolve
    player_name "No need to say twice"

    scene bg render1877 with dissolve
    pause

    scene bg render1878 with dissolve
    pause

    scene bg render1879 with dissolve
    pause
    player_name "Fuck! Sometimes I forget how hot you are."

    scene bg render1880 with dissolve
    Alice "Let me remind you"

    scene bg render1881 with dissolve
    Alice "Aaaghnn! It went right in"
    pause
    play sound "audio/0.5 soundtrack/sex/AliceAndAdamSexmp3.mp3" loop
    image AliceStorageRoom5 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/five0001-0059-sarww2.webm", loop=True)
    show AliceStorageRoom5 with dissolve
    pause
    Alice "Oh Shit! Yeah, from behind is perfect."
    player_name "I love this pussy so much"
    Alice "She loves you too! Fuck me harder."
    pause
    image AliceStorageRoom6 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/six0001-0080-oo9awc.webm", loop=True)
    show AliceStorageRoom6 with dissolve
    pause
    player_name "I wanna take my time with you"
    Alice "Now I know why Anne moans so much."
    Alice "You keep teasing her until she can't take it anymore."
    pause
    image AliceStorageRoom7 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/seven0001-0080-enmyo9.webm", loop=True)
    show AliceStorageRoom7 with dissolve
    pause
    player_name "Or maybe I just like teasing you."
    player_name "How am I supposed to rush with that ass as the view?"
    Alice "Ohhhnnn! I'm close. Please pound me harder."
    pause
    stop sound
    play sound "audio/0.5 soundtrack/general/FROMBEHINDALICE.mp3" loop
    image AliceStorageRoom8 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/eight0001-0080-nfmjre.webm", loop=True)
    show AliceStorageRoom8 with dissolve
    pause
    Alice "Oh God! Oh God! Oh my fricking..."
    Alice "Ahn Ahnn Ahn"
    Alice "Hhmmm Ssss- so Thiick"
    player_name "Cum for me"
    pause
    stop sound
    scene bg render1882 with dissolve
    pause
    Alice "Ah! Ah! Ahh!"
    Alice "I came so hard."

    scene bg render1883 with dissolve
    pause

    scene bg render1884 with dissolve
    pause
    Alice "This position looks dangerous"
    scene bg render1885 with dissolve
    Alice "I might scream."
    pause
    image AliceStorageRoom9 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/nine0001-0059-pv74wc.webm", loop=True)
    show AliceStorageRoom9 with dissolve
    pause
    player_name "I hope you don't "
    player_name "Your moans are only mine to hear"
    Alice "After fucking my brains out, you get romantic?"
    Alice "I might wanna marry you"
    pause
    image AliceStorageRoom10 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/ten0001-0080-gvjqrj.webm", loop=True)
    show AliceStorageRoom10 with dissolve
    pause
    player_name "I'll be happy to"
    Alice "Just imagining being able to sit on that cock every night..."
    Alice "Fuck me!"
    pause
    image AliceStorageRoom11 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/110001-0080-wgrp3l.webm", loop=True)
    show AliceStorageRoom11 with dissolve
    pause
    player_name "Baby, we don't need to marry for that."
    Alice "Are you inviting me to a threesome?"
    player_name "Maybe I am"
    pause
    image AliceStorageRoom12 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/120001-0080-oobogo.webm", loop=True)
    show AliceStorageRoom12 with dissolve
    pause
    Alice "I don't wanna share this dick"
    Alice "This dick is mine, you hear me?"
    player_name "Hah! Did you forget who's in charge?"
    pause
    stop sound
    scene bg render1887 with dissolve
    Alice "Ssshiit! So good!"
    pause

    scene bg render1888 with dissolve
    Alice "Ahn?"

    scene bg render1889 with dissolve
    Alice "What are you-"

    scene bg render1890 with dissolve
    Alice "Gez, take it easy on me."

    scene bg render1891 with dissolve
    pause
    player_name "Take it easy?"
    play sound "audio/0.5 soundtrack/general/freesound_community-cabinet-7-90153.mp3"
    scene bg render1892 with dissolve
    pause

    scene bg render1893 with dissolve
    pause

    scene bg render1894 with dissolve
    pause
    play sound "audio/0.5 soundtrack/sex/almostcumingAlice.mp3" loop
    image AliceStorageRoom13 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/130001-0100-ntirmc.webm", loop=True)
    show AliceStorageRoom13 with dissolve
    pause
    Alice "OH MY FUuuuuu-"
    Alice "GOD! Fuuck!"
    player_name "Is this easy enough for you?"
    pause
    image AliceStorageRoom14 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/140001-0079-dekwnr.webm", loop=True)
    show AliceStorageRoom14 with dissolve
    pause
    Alice "Ahhnnn!"
    Alice "Don't stop please, don't you stop"
    pause

    scene bg render1895 with dissolve
    pause

    scene bg render1896 with dissolve
    pause

    scene bg render1897 with dissolve
    pause
    Emily "Oh my god!"

    scene bg render1898 with dissolve
    pause
    Emily "* They are really doing it *"
    Alice "Yes, [p] Fuck this pussy!"

    scene bg render1899 with dissolve
    pause
    Alice "You'll make me cum again"
    stop sound
    scene bg render1900 with dissolve
    Emily "Are you serious?"

    scene bg render1901 with dissolve
    pause
    player_name "* FUCK! *"
    
    scene bg render1902 with dissolve
    Emily "Why are you doing this to her?"

    scene bg render1903 with dissolve
    Emily "You could have just..."

    scene bg render1904 with dissolve
    Emily "Asked me."
    Alice "What?"
    scene bg render1905 with dissolve
    Alice "Emi, Sis. Could you just wait a few more seconds?"
    Alice "I'm so fucking close"

    scene bg render1906 with dissolve
    pause

    scene bg render1907 with dissolve
    Emily "Fine"

    scene bg render1908 with dissolve
    Emily "But I'm next."

    scene bg render1909 with dissolve
    Alice "What does she mean by th-"

    scene bg render1910 with dissolve
    Emily "Enough talk."

    scene bg render1911 with dissolve
    Emily "Just cum already."
    player_name "* Holy shit! This is the hottest thing I've ever saw *"
    Alice "[p], what doe she mean by-"
    play sound "audio/0.5 soundtrack/sex/AliceFUcking.mp3" loop
    image AliceStorageRoom15 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/150001-0100-4vl5pr.webm", loop=True)
    show AliceStorageRoom15 with dissolve
    Alice "Ahhnn!"
    play sound "audio/0.5 soundtrack/sex/Alice Cummingt.mp3"
    pause
    Alice "Wait... Ahn Ahn Hmm. Fuck!"
    Alice "Yeah! Yeah! I'm close"
    Alice "Yeah I'm gonna fucking cum."
    pause
    image AliceStorageRoom16 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ALICE/webm/160001-0080-jmfhvv.webm", loop=True)
    show AliceStorageRoom16 with dissolve
    pause
    Alice "Ahhhhnn!"
    pause
    stop sound

    scene bg render1912 with dissolve
    pause
    Sara "EMILY! Where are you?"

    scene bg render1913 with dissolve
    Emily "SHIT!"

    scene bg render1914 with dissolve
    Emily "I left the door opened"

    scene bg render1915 with dissolve
    pause

    scene bg render1916 with dissolve
    pause
    player_name "Fuck!"

    scene bg render1917 with dissolve
    pause

    scene bg render1918 with dissolve
    pause

    scene bg render1919 with dissolve
    pause
    Emily "HEY! Did you cum too?"

    scene bg render1920 with dissolve
    pause
    player_name "Sorry baby, I couldn't hold it back."
    Emily "No way. I told you I was next."
    Emily "Argh!"
    scene bg render1921 with dissolve
    Alice "What the fuck?"
    pause

    scene bg render1922 with dissolve
    Alice "What are you doing?"

    scene bg render1923 with dissolve
    Alice "You can't just- What the hell?"
    stop music

    scene bg render1924 with dissolve
    player_name "HAH!"

    
    label skipAlice05:
    play music "audio/0.5 soundtrack/general/freesound_community-food-cooking-in-frying-pan-71250.mp3"
    scene bg render1925 with dissolve
    pause

    scene bg render1926 with dissolve
    pause

    scene bg render1927 with dissolve
    pause

    scene bg render1928 with dissolve
    pause
    scene bg render1929 with dissolve
    Anne "Hi sweetie."


    scene bg render1930 with dissolve
    Anne "Do you need something?" 

    scene bg render1931 with dissolve
    Mei "No, actually, I wanted to ask if you need help with anything here in the kitchen."

    scene bg render1932 with dissolve
    pause
    Mei "And also, there's something I wanted to talk to you about."

    scene bg render1933 with dissolve
    pause
    Mei "It's about your husband."
    stop music
    label reunion:
    if HadSexWithAliceStorageRoom:
        jump hadSex
    else:
        jump NosexAlice

    label hadSex:
   
    scene bg render1934 with dissolve
    pause
    Emily "I KNOW YOU MADE HIM DO IT!"
    Alice "What?"
    scene bg render1935 with dissolve
    Emily "You didn't want to share him, so you made him cum."

    scene bg render1936 with dissolve
    Alice "That’s no excuse to stick a finger inside me."

    scene bg render1937 with dissolve
    Emily "Too bad for you—I did, and it was delicious."
    Emily "GET OVER IT!"

    scene bg render1938 with dissolve
    Emily "I told you I was next."
    Rim "Hey guys."
    scene bg render1939 with dissolve
    Emily "WHAT?"

    scene bg render1940 with dissolve
    Rim "Maybe we came at a bad time."
    Sara "No, they fight all the time"

    scene bg render1941 with dissolve
    pause

    scene bg render1942 with dissolve
    Sara "The only thing that changes is what they are fighting over."

    scene bg render1943 with dissolve
    pause

    scene bg render1944 with dissolve
    Emily "Ahm... Did you hear us?"
    scene bg render1945 with dissolve
    Sara "The whole house must have heard two hoarse cats fighting."
    player_name "* Damn what is she wearing? *"

    label NosexAlice:
    scene bg render1946 with dissolve
    Rim "I wanted to get everyone together to discuss things as a group."

    scene bg render1947 with dissolve
    Rim "It wouldn't be fair to leave anyone out but Luna said she was busy."

    scene bg render1948 with fade
    pause
    Sara "So, basically"

    scene bg render1949 with dissolve
    Sara "You are saying that you are going to risk your life and ours"
    Sara "To save someone you never met and don't even know if she is there."

    scene bg render1950 with dissolve
    Sara "I'm sorry, Rim, I know she's your mother but [p], that makes absolutely no sense."

    scene bg render1951 with dissolve
    Sara "I AM NOT-"

    scene bg render1952 with dissolve
    Sara "I don't think you should go."

    scene bg render1953 with dissolve
    Sara "I know you. You are just like your brother."

    scene bg render1954 with dissolve
    Sara "Always trying to do the right thing"

    scene bg render1955 with dissolve
    Sara "But you need to drop that Boy Scout shit."

    scene bg render1956 with dissolve
    Rim "Excuse me, I don't think that's entirely true."

    scene bg render1957 with dissolve
    pause
    Rim "My sister, [p], and I came up with a great plan. We’ll barely be exposing ourselves to any risk."

    scene bg render1958 with dissolve
    pause
    Rim "Mei and I have been watching them for days. We know the routine of every guard. We’ll go in the morning, when there’s less activity."

    scene bg render1959 with dissolve
    Rim "We captured one of them once. We have inside information."
    pause

    scene bg render1960 with dissolve
    Rim "He said that their prison is divided into male and female sections."
    Rim "They don't let guards near the women so they won't get raped before acquiring an 'Owner'."
    Rim "And in the event of any unforeseen issues, [p] has already shown himself to be very capable of handling improvisation."
    scene bg render1961 with dissolve
    player_name "Thank you"

    scene bg render1962 with dissolve
    pause

    scene bg render1963 with dissolve
    Rim "So.. We wouldn't throw ourselves into a suicide mission. My mother wouldn't want that."

    scene bg render1964 with dissolve
    pause

    scene bg render1965 with dissolve
    player_name "Tom usually handled our battle plans."

    scene bg render1966 with dissolve
    player_name "I think he would approve this one"
    Anne "I think you should go"
    scene bg render1967 with dissolve
    pause

    scene bg render1968 with dissolve
    pause

    scene bg render1969 with dissolve
    Anne "If there’s a girl out there suffering at the hands of bad people, you should go and do what you do best."

    scene bg render1970 with dissolve
    play music "audio/0.5 soundtrack/general/dmassaiii-ready-the-defenses-375883.mp3" fadein 1.0
    Anne "Be the man I fell in love with"
    pause
    
    scene bg render1971 with dissolve
    pause

    scene bg render1972 with dissolve
    pause

    scene bg render1973 with dissolve
    pause

    scene bg render1974 with dissolve
    pause

    scene bg render1975 with dissolve
    pause

    scene bg render1976 with dissolve
    pause
    play sound "audio/dragon-studio-light-switch-382712.mp3"
    scene bg render1977 with dissolve
    pause

    scene bg render1978 with dissolve
    pause

    scene bg render1979 with dissolve
    pause

    scene bg render1980 with dissolve
    Rim "[p]"
    scene bg render1981 with dissolve
    Rim "Do you need a hand?"
    stop music fadeout 1.0
    

    scene bg render1982 with dissolve
    player_name "Nah, I'm just getting a few things ready for tomorrow."

    scene bg render1983 with dissolve
    player_name "But if you want, you can join me on patrol."

    scene bg render1984 with dissolve
    pause

    scene bg render1985 with dissolve
    Rim "I'd love that. Let me put on something else"

    play sound "audio/0.5 soundtrack/general/dragon-studio-soothing-river-flow-372456.mp3" loop
    scene bg render1986 with dissolve
    pause

    scene bg render1987 with dissolve
    pause

    scene bg render1988 with dissolve
    pause

    scene bg render1989 with dissolve
    pause

    scene bg render1990 with dissolve
    pause

    scene bg render1991 with dissolve
    Rim "This place is really nice"

    scene bg render1992 with dissolve
    player_name "I usually don't come this far, but I want to show you something."
    
    scene bg render1996 with dissolve
    pause
    player_name "My dad used to bring me here"
    player_name "We used to laugh for no reason back then."

    scene bg render1993 with dissolve
    Rim "Thank you for bringing me here."
    pause

    scene bg render1994 with dissolve
    Rim "I could stay here all day"
    pause
    scene bg render1995 with dissolve
    pause
    stop sound


    scene bg render1997 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/dishes.mp3"
    scene bg render1998 with dissolve
    Luna "Seriously? Do you really expect me to believe that you've never dated anyone?"
    Luna "How old you said you were?"
    

    scene bg render2000 with dissolve
    player_name "Be polite to Mei, my dear."

    scene bg render2001 with dissolve
    Luna "I was just curious."

    scene bg render2002 with dissolve
    pause
    Anne "Where were you honey?"

    scene bg render2003 with dissolve
    player_name "I went to check the perimeter, as always. I just took a little longer than usual."

    scene bg render2004 with dissolve
    Anne "You could have warned me"
    player_name "Sorry"
    scene bg render2005 with dissolve
    pause
    stop sound
    scene bg render2006 with dissolve
    pause

    scene bg render2007 with dissolve
    pause

    scene bg render2008 with dissolve
    pause

    play music "audio/0.5 soundtrack/general/freesound_community-night-ambience-17064.mp3"
    scene bg render2009 with dissolve
    pause

    scene bg render2010 with dissolve
    pause

    scene bg render2011 with dissolve
    pause

    scene bg render2012 with dissolve
    pause


    scene bg render2014 with dissolve
    pause

    scene bg render2015 with dissolve
    pause

    scene bg render2016 with dissolve
    player_name "Can't sleep?"
    pause

    scene bg render2017 with dissolve
    pause

    scene bg render2018 with dissolve
    player_name "Neither do I"

    scene bg render2019 with dissolve
    Sara "If I didn't know you, I'd think you were nervous."

    scene bg render2020 with dissolve
    Sara "Are you okay?"

    scene bg render2021 with dissolve
    player_name "Don't mind me. How are you holding up?"

    scene bg render2022 with dissolve
    pause
    Sara "Me? I'm not even sure to be honest"
    player_name "Come here"

    scene bg render2023 with dissolve
    pause

    scene bg render2024 with dissolve
    Sara "I hope you understand why I opposed you going tomorrow. Losing Tom was hard enough. I could never bear to lose you."

    scene bg render2025 with dissolve
    Sara "Sometimes I find myself feeling angry at him for leaving us."

    scene bg render2026 with dissolve
    Sara "How could he?"

    scene bg render2027 with dissolve
    player_name "Listen, knowing my brother he would want you to..."

    menu:
        "Move on and enjoy life":
            $ SaraPath = True
            jump SaraPath
        "keep his memory alive":
            jump NoSaras



    label SaraPath:
    if SaraPath:
        jump Sarass

    else:
        jump NoSaras


    label Sarass:
    scene bg render2028 with dissolve
    Sara "I know that."

    scene bg render2029 with dissolve
    pause

    scene bg render2030 with dissolve
    Sara "But that's hard"

    scene bg render2031 with dissolve
    player_name "Leave it to me."

    scene bg render2032 with dissolve
    player_name "I can help you move on"

    scene bg render2033 with dissolve
    Sara "[p], I don't know if we should"

    scene bg render2034 with dissolve
    Sara "I need some time"

    scene bg render2035 with dissolve
    pause

    scene bg render2036 with dissolve
    player_name "Listen, You'll never feel ready"

    scene bg render2037 with dissolve
    player_name "Until you make the jump"

    scene bg render2038 with dissolve
    player_name "Trust me on that"

    scene bg render2039 with dissolve
    pause
    stop music
    scene bg render2040 with dissolve
    pause
    player_name "* She's not saying anything. She is just starring *"

    scene bg render2041 with dissolve
    player_name "* It's now or never *"

    scene bg render2042 with dissolve
    pause

    scene bg render2043 with dissolve
    pause
    scene bg render2044 with dissolve
    pause
    play music "audio/0.5 soundtrack/sex/vicatestudio-fashion-deep-492457.mp3"

    scene bg render2045 with dissolve
    pause

    scene bg render2046 with dissolve
    Sara "Hmmf"

    scene bg render2047 with dissolve
    Sara "Ahn?"

    scene bg render2048 with dissolve
    pause

    scene bg render2049 with dissolve
    pause

    scene bg render2050 with dissolve
    Sara "Hm, is this what you wanted?"
    Sara "Take a look at my panties?"

    scene bg render2051 with dissolve
    Sara "Wha- Wait."

    scene bg render2052 with dissolve
    Sara "Wow, you're quick at undressing me."
    pause

    scene bg render2055 with dissolve
    Sara "You don't need to rush"


    scene bg render2057 with dissolve
    player_name "*INHALE*"
    pause


    scene bg render2058 with dissolve
    pause
    Sara "Hmm God! It's been a while."

    image SaraFirst = Movie(play="images/animation/0.5 ALL ANIMATIONS/SARA/Webm/10001-0080-ssscew.webm", loop=True)
    show SaraFirst with dissolve
    pause
    Sara "Slow down. I'm very sensitive."
    Sara "I- I get there very easily."
    player_name "* Fuck, I can already picture her cumming non-stop on my cock. *"
    player_name "* I can't wait. *"
    pause
    scene bg render2059 with dissolve
    Sara "I'm close, don't stop"

    scene bg render2060 with dissolve
    pause

    scene bg render2061 with dissolve
    player_name "sluuurp!"
    Sara "Aaghn"
    Sara "Shit!"
    pause

    scene bg render2062 with dissolve
    Sara "Stop please!"
    pause

    scene bg render2063 with dissolve
    Sara "That's enough for now"
    Sara "My turn"
    scene bg render2064 with fade
    Sara "I've never seen anything like it"

    scene bg render2065 with dissolve
    Sara "H- How am I..."
    pause
    scene bg render2066 with dissolve
    Sara "Can I touch it?"

    scene bg render2067 with dissolve
    Sara "Ahh!"

    scene bg render2068 with dissolve
    Sara "Hahaha I'll take that as a yes."

    scene bg render2069 with dissolve
    pause
    Sara "Jesus!"

    image SaraFirst2 = Movie(play="images/animation/0.5 ALL ANIMATIONS/SARA/Webm/20001-0080-m58ovg.webm", loop=True)
    show SaraFirst2 with dissolve
    pause
    Sara "Hmmm"
    Sara "This... It's twice-No... Three times bigger then Tom's"
    Sara "Actually, if you take into account how thick it is, that comparison is also wrong."
    player_name "Am I a bad person if I say that hearing that turned me on even more?"
    Sara "Then we are both bad."
    scene bg render2070 with dissolve
    player_name "Can I see them?"
    pause
    

    scene bg render2071 with dissolve
    Sara "Hm? OW..."

    scene bg render2072 with dissolve
    Sara "Hmmm... I'm not sure you can"

    scene bg render2073 with dissolve
    Sara "Should I let you see?"

    scene bg render2074 with dissolve
    pause

    scene bg render2075 with dissolve
    pause

    scene bg render2076 with dissolve
    pause

    scene bg render2077 with dissolve
    pause

    scene bg render2078 with dissolve
    player_name "Holy Shit!"

    scene bg render2079 with dissolve
    player_name "That might be the most erotic body I've ever seen."
    player_name "Everything about you drives me crazy."
    scene bg render2080 with dissolve
    player_name "I can't take it anymore"

    scene bg render2081 with dissolve
    player_name "Come, I wanna hear you moaning my name"

    scene bg render2082 with dissolve
    pause
    Sara "Hm!"
    scene bg render2083 with dissolve
    Sara "I'm sorry"
    Sara "I'm not ready for sex yet."

    scene bg render2084 with dissolve
    Sara "But I still wanna make you cum"

    scene bg render2085 with dissolve
    Sara "I know how to make you feel good"
    scene bg render2086 with dissolve
    Sara "There."
    pause

    scene bg render2087 with dissolve
    Sara "Hmmm. So warm and thick"

    scene bg render2088 with dissolve
    Sara "You know what to do."
    play sound "audio/0.5 soundtrack/general/SaraClapt.mp3" loop
    image SaraFirst3 = Movie(play="images/animation/0.5 ALL ANIMATIONS/SARA/Webm/30001-0080-qr17e5.webm", loop=True)
    show SaraFirst3 with dissolve
    pause
    player_name "Aah! You are so wet"
    Sara "I know."
    player_name "I feel like you are holding yourself back"
    Sara "Is that so? Humf-Don't stop"
    Sara "You are rubbing my clit so good"

    scene bg render2089 with dissolve
    pause

    scene bg render2090 with dissolve
    Sara "God! I missed this"
    Sara "Hearing you have sex every night turned me into a total slut. I could barely hold myself back anymore. "
    player_name "You didn't have to. You just had to ask."
    image SaraFirst4 = Movie(play="images/animation/0.5 ALL ANIMATIONS/SARA/Webm/40001-0080-vzvdey.webm", loop=True)
    show SaraFirst4 with dissolve
    player_name "I've always had a crush on you."
    Sara "Your brother's wife? What a dirty boy."
    Sara "You were right about me holding myself"
    Sara "Tom could never keep up with my sex drive, so I had to learn to control myself."
    player_name "Fuuu-I'm gonna cum."
    Sara "Where do you want?"
    pause
    image SaraFirst3 = Movie(play="images/animation/0.5 ALL ANIMATIONS/SARA/Webm/30001-0080-qr17e5.webm", loop=True)
    show SaraFirst3 with dissolve
    pause
    menu:
        "Fuck her tighs until you cum":
            jump tighCum

        "Cum on her breasts":
            jump breastCum


    label tighCum:
    stop sound

    scene bg render2091 with dissolve
    pause

    scene bg render2092 with dissolve
    pause


    scene bg render2093 with dissolve
    pause

    scene bg render2094 with dissolve
    pause

    scene bg render2095 with dissolve
    pause

    scene bg render2096 with dissolve
    Sara "That was quite a load"

    scene bg render2097 with dissolve
    Sara "Maybe next time we can have more fun"
    Sara "You need to sleep, you have a big day ahead"
    player_name "Right.."
    stop music
    pause
    jump endofSceneSara

    label breastCum:
    stop sound
    scene bg render2098 with dissolve
    pause
    player_name "Fuck! Looking down on you waiting for my cum is-"

    scene bg render2099 with dissolve
    player_name "OOuhh"

    scene bg render2100 with dissolve
    pause

    scene bg render2101 with dissolve
    pause

    scene bg render2102 with dissolve
    pause

    scene bg render2103 with dissolve
    Sara "Wow!"

    scene bg render2104 with dissolve
    Sara "Your aim is terrible. HAhaha!"
    player_name "Sorry I just-"
    pause

    scene bg render2105 with dissolve
    Sara "It's okay silly. I don't mind"

    scene bg render2106 with dissolve
    Sara "I was kind of hopping for it."
    player_name "Wait-What?"
    stop music
    pause

    jump endofSceneSara
    
    label NoSaras:
    scene bg render2028 with dissolve
    Sara "I think..."

    scene bg render2029 with dissolve
    Sara "You might be right"

    scene bg render2030 with dissolve
    Sara "..."

    scene bg render2031 with dissolve
    player_name "He is still alive in our hearts"

    scene bg render2032 with dissolve
    player_name "Let's honor him"

    scene bg render2033 with dissolve
    Sara "Thank you! I needed that."

    scene bg render2023 with dissolve
    pause
    stop music
    

    label endofSceneSara:
    scene bg render2107 with dissolve
    pause
    play sound "audio/sound-effect-door-knock-single-200531.mp3"
    pause


    scene bg render2108 with dissolve
    pause
    play sound "audio/sound-effect-door-knock-single-200531.mp3"
    pause
    Rim "Do you think we came too early?"
    Mei "We have no choice"
    scene bg render2109 with dissolve
    pause
    play sound "audio/0.4/koiroylers-door-opening-356028.mp3"
    scene bg render2110 with dissolve
      

    scene bg render2111 with dissolve
    play sound "audio/0.5 soundtrack/Solo guitar.mp3"
    Rim "Are you ready?"
    pause

    player_name "Let's go"

    scene bg render2112 with dissolve
    pause

    scene bg render2113 with dissolve
    pause

    scene bg render2114 with dissolve
    player_name "Don't forget what I said: always stay in groups of two or more."

    scene bg render2115 with dissolve
    player_name "Don't leave the house until I get back."

    scene bg render2116 with dissolve
    player_name "I'll be back before lunch."

    scene bg render2117 with fade
    Mei "You know.."

    scene bg render2118 with dissolve
    Mei "I think we should review the plan."

    scene bg render2119 with dissolve
    Rim "I agree"

    scene bg render2120 with dissolve
    player_name "Hm! I don't see why not."

    scene bg render2121 with dissolve
    Mei "I confess that I don't really like your plan B."

    scene bg render2122 with dissolve
    player_name "I don't think we'll need it."

    scene bg render2123 with dissolve
    player_name "Okay so..."

    scene bg render2124 with dissolve
    player_name "Mei will find some high ground."

    scene bg render2125 with dissolve
    player_name "You said you knew a good spot"

    scene bg render2126 with dissolve
    player_name "You'll be our eyes and help us in case we need it"

    scene bg render2127 with dissolve
    pause

    scene bg render2130 with dissolve
    player_name "Rim and I are going through the front door..."
    scene bg render2129 with dissolve
    pause
    scene bg render2128 with dissolve
    pause


    scene bg render2131 with dissolve
    Mitcher "Stay right there"
    scene bg render2132 with dissolve
    Mitcher "Who the fuck are you?"
    pause

    scene bg render2133 with dissolve
    player_name "My name is [p] and I would like to volunteer to serve as a soldier"

    scene bg render2134 with dissolve
    player_name "I brought a gift as a gesture of good faith."

    scene bg render2135 with dissolve
    player_name "She is young and still a virgin; from what I heard, you'll put her to good use."

    scene bg render2136 with dissolve
    Mitcher "Is this true darling? Are you still virgin?"

    scene bg render2137 with dissolve
    Mitcher "She is cute and her skin is soft. That's rare"

    scene bg render2138 with dissolve
    Mitcher "Well done. But only our boss can allow you
    to join the gang. However, given your gift, I think it’s very unlikely he’ll refuse."

    scene bg render2139 with dissolve
    Mitcher "But if you want to go in, you'll need to leave this piece you're carrying on your back right here."
    Mitcher "We get a lot of guys wanting to join, but they usually don't fit your profile."
    Mitcher "What's in the bag?"
    player_name "Her belongings"
    Mitcher "Come."
    play music "audio/0.5 soundtrack/general/universfield-dark-tension-atmosphere-516336.mp3"

    play sound "audio/0.5 soundtrack/general/soul_serenity_sounds-ambient-noise-236388.mp3" loop
    scene bg render2402 with dissolve
    pause
    Mitcher "Most of the fuckers are still sleeping"
    Mitcher "Don't get used to this quiet vibe"

    scene bg render2140 with dissolve
    pause
    Mitcher "It is generally noisier."
    scene bg render2141 with dissolve
    pause

    scene bg render2142 with dissolve
    pause

    scene bg render2403 with dissolve
    Mitcher "Follow me"
    pause
    stop sound
    scene bg render2144 with dissolve
    pause

    play sound "audio/0.5 soundtrack/general/Group of People Walking on Concrete SFX - Myles Moss (youtube).mp3"
    scene bg render2145 with dissolve
    pause
    stop sound fadeout 1.0
    Jonathan "MITCHER! I missed you man"
    scene bg render2146 with dissolve
    Mitcher "You say that every day."
    Jonathan "That's how much you mean to me"
    scene bg render2147 with dissolve
    pause

    scene bg render2148 with dissolve
    Mitcher "Shut up"

    scene bg render2149 with dissolve
    Jonathan "You don't have to be so mean."

    scene bg render2150 with dissolve
    Jonathan "You know there’s a beautiful friendship between us just waiting to blossom."
    Mitcher "Your jokes are weird, man."
    scene bg render2151 with dissolve
    Jonathan "Jokes?"

    scene bg render2152 with dissolve
    pause
    Jonathan "If I were joking, how would I know that your favorite color is blue?"

    scene bg render2153 with dissolve
    Jonathan "Ham?"
    pause

    scene bg render2154 with dissolve
    pause

    scene bg render2155 with dissolve
    Jonathan "Hey, Mitcher. Who are these two"

    scene bg render2156 with dissolve
    pause
    Mitcher "A new recruit and the gift he brought to melt our hearts."
    Jonathan "Really?"
    play sound "audio/0.5 soundtrack/general/WAR DRUM.mp3"
    scene bg render2157 with dissolve
    pause

    scene bg render2158 with dissolve
    pause

    scene bg render2159 with dissolve
    pause

    scene bg render2160 with dissolve
    pause

    scene bg render2161 with dissolve
    Jonathan "They look fun"
    Jonathan "There are plenty of openings in Wing B. The list you're looking at is for the wrong place."
    scene bg render2162 with dissolve
    player_name "* This guy could be a problem. *"

    scene bg render2163 with dissolve
    pause
    Rim "* Just wait a little longer, Mom. I'm close *"
    stop music
    scene bg render2164 with dissolve
    pause
    play music "audio/0.5 soundtrack/general/atlasaudio-suspense-tension-510043.mp3"
    Mitcher "Listen, you don't need to be afraid. You just need to behave."

    scene bg render2165 with dissolve
    Mitcher "One of the leaders will be here soon and decide who you'll stay with."
    Mitcher "It might seem scary, but it’s not that bad; you’ll have a roof over your head and food, and you’ll only need to satisfy your partner."
    scene bg render2166 with dissolve
    Mitcher "Some guys here even treat the girls as if they were wives."

    scene bg render2167 with dissolve
    Mitcher "But if you resist, I cannot guarantee your safety."


    scene bg render2168 with dissolve
    Rim "I don't think we need to worry about that. "

    scene bg render2169 with dissolve
    Mitcher "How so?"
    pause

    scene bg render2170 with dissolve
    Rim "..."
    play sound "audio/0.5 soundtrack/general/tap.mp3"
    scene bg render2171 with dissolve
    pause
    Mitcher "Ham?"

    scene bg render2172 with dissolve
    player_name "Where is HR? I want to resign."

    scene bg render2415 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/dodge.mp3"
    scene bg render2416 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/dragon-studio-simple-whoosh-382724.mp3"
    scene bg render2174
    pause 0.5
    play sound "audio/0.5 soundtrack/general/universfield-power-punch-192118.mp3"
    scene bg render2175
    pause

    scene bg render2176 with dissolve
    pause

    scene bg render2177 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/imagne_impossible-horror-body-drop-152091.mp3"
    scene bg render2178 with dissolve
    pause

    scene bg render2179 with dissolve
    Rim "Well"

    scene bg render2180 with dissolve
    Rim "Take this off please"

    scene bg render2181 with dissolve
    Rim "MOM? Mom it's me, Rim"

    scene bg render2182 with dissolve
    Rim "... Mom are you-"

    scene bg render2183 with dissolve
    Lucy "Whoever you're looking for, You won't find here"

    scene bg render2184 with dissolve
    Lucy "I'm sorry"

    scene bg render2185 with dissolve
    pause

    scene bg render2186 with dissolve
    pause

    scene bg render2187 with dissolve
    Lucy "Your mom isn't here."
    Rim "Who- How... How do you know?"

    scene bg render2188 with dissolve
    Lucy "They put me here yesterday, but I know it"
    Lucy "Sorry."
    scene bg render2189 with dissolve
    pause

    scene bg render2190 with dissolve
    Rim "Listen, I can't guarantee I can get you out of here, but if you give me some information, maybe we can help each other."

    scene bg render2191 with dissolve
    Lucy "I've already told you what you need to know."

    scene bg render2192 with dissolve
    Lucy "Do yourself a favor and leave while you still can."

    scene bg render2193 with dissolve
    Lucy "Women here are treated worse than animals."
    Lucy "And there's nothing you can-"
    stop music
    scene bg render2194 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/floraphonic-scratching-metal-4-188119.mp3"
    scene bg render2195 with dissolve
    Lucy "What the..."

    scene bg render2196 with dissolve
    Lucy "How did you..."

    scene bg render2197 with dissolve
    player_name "This place wasn't originally a prison, and whoever built it was an idiot."
    scene bg render2198 with dissolve
    player_name "Come on, you're free."

    scene bg render2199 with dissolve
    player_name "You can ask your questions now"
    

    scene bg render2200 with dissolve
    Lucy "Thank you very much."

    scene bg render2201 with dissolve
    player_name "No problem"

    scene bg render2202 with dissolve
    Rim "Now, please."

    scene bg render2203 with dissolve
    Lucy "Fine"

    scene bg render2204 with dissolve
    Lucy "Yesterday, when we arrived here, they told us the same thing—to behave ourselves, because the last person who didn't behave was killed."
    Lucy "To be honest. I think he was lying"
    scene bg render2205 with dissolve
    Lucy "Women here are treated as bargaining chips. They wouldn't kill just for that. So, I believe she killed herself."
    Lucy "She knew she was going to be raped, so she killed herself."
    Lucy "They put me in her cell. To intimidate me. I'm really sorry"

    scene bg render2206 with dissolve
    Lucy "I was starting to consider the same thing."
    play music "audio/0.5 soundtrack/general/soundreality-heart-beat-137135.mp3"
    scene bg render2207 with dissolve
    Rim "No. It can't be."

    scene bg render2208 with dissolve
    Rim "uh-huh-huh NOooo."

   
    scene bg render2210 with dissolve
    Rim "Mooom, I'm sorry. I was too late"
    pause

    scene bg render2211 with dissolve
    Rim "*Sob* *Sob*"
    player_name "She died with honor."
    stop music fadeout 1.0
    scene bg render2212 with dissolve
    Elen "Hmm excuse me. Could you do with my cell what you did to hers?"

    scene bg render2213 with dissolve
    Elen "I really really really don't want to be raped"

    scene bg render2214 with dissolve
    pause
    Elen "Would you be so kind?"

    scene bg render2215 with dissolve
    Elen "Thank you very much"

    scene bg render2216 with dissolve
    player_name "Do you have any valuable information?"

    scene bg render2217 with dissolve
    pause
    Elen "Hmmm.. All I know is that They leave few guards here so that none of them rape any of us, and most of the guards look after the men's section. "

    scene bg render2218 with dissolve
    Elen "They said that early in the morning someone would come to decide our new 'owners'."

    scene bg render2219 with dissolve
    Elen "I guess that means we don't have much time."

    scene bg render2220 with dissolve
    player_name "Rim. We don't have much time"
    player_name "I know you're falling apart right now. I've been there."
    scene bg render2221 with dissolve
    player_name " But I need you to pick up those pieces and be the strong woman your mother raised you to be."
    player_name "Your sister still needs you. She can't lose you too"
    scene bg render2222 with dissolve
    player_name "Don't focus on what you've lost, but on what you still have."
    Rim "..."
    scene bg render2223 with dissolve
    pause

    scene bg render2224 with dissolve
    Lucy "So what's the plan?"

    scene bg render2225 with dissolve
    pause

    scene bg render2226 with dissolve
    Lucy "Do we have to fight our way out?"

    scene bg render2227 with dissolve
    player_name "Let's hope not"

    scene bg render2228 with dissolve
    pause

    scene bg render2229 with dissolve
    Rim "I hope so."

    label prisonpath:
        if AlanDead:
            $ JonathanAlive = True
            jump jonathanLives
        else:
            jump prisonFight


    label prisonFight:
    scene bg render2230 with dissolve
    pause
    "*Footsteps*"

    scene bg render2231 with dissolve
    pause

    scene bg render2232 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/AlanArrives.mp3"
    scene bg render2233
    pause

    scene bg render2234 with dissolve
    Jonathan "What are you doing here."

    scene bg render2235 with dissolve
    Alan "Boss said I could pick one"

    scene bg render2238 with dissolve
    Jonathan "For what? Getting shot and running like a bitch?"

    scene bg render2236 with dissolve
    Alan "Tsk! whatever man."

    scene bg render2239 with dissolve
    Jonathan "You know... A new guy came up today and he brought a girl as a gift"
    Jonathan "He's been here for 5 minutes and he's already more useful than you, hahaha."

    scene bg render2237 with dissolve
    Alan "What new guy?"

    scene bg render2240 with dissolve
    Jonathan "Jealous?"
    Alan "Just answer me."
    scene bg render2241 with dissolve
    pause
    Lucy "I could really have a gun right now"


    scene bg render2243 with dissolve
    player_name "We're going to get plenty, don't worry."

    scene bg render2244 with dissolve
    player_name "Just stay together."
    pause

    scene bg render2245 with dissolve
    pause

    scene bg render2246 with dissolve
    pause

    play music "audio/0.5 soundtrack/general/daughter.mp3"
    scene bg render2247 with fade
    pause
    scene bg render2248 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/knifetrow.mp3"
    scene bg render2249 with dissolve
    pause

    scene bg render2250 with dissolve
    pause
    
    scene bg render2251 with dissolve
    pause

    scene bg render2252 with dissolve
    pause

    scene bg render2253 with dissolve
    Rim "[p]!"
    

    scene bg render2254 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/dorshut.mp3"
    scene bg render2255 with dissolve
    Lucy "Fuck. It's locked"
    Alan "Heh!"
    stop music fadeout 0.5
    scene bg render2256 with dissolve
    pause

    play sound "audio/0.5 soundtrack/general/u_mx4xkr2bzy-slow-cinematic-clock-ticking-tension-323080.mp3"
    scene bg render2257 with dissolve
    pause

    scene bg render2258 with dissolve
    Alan "It's going to be hard to choose just one."



    scene bg render2269 with dissolve
    pause

    scene bg render2270 with dissolve
    pause
    stop sound 
    play music "audio/0.5 soundtrack/LucyPureAction.mp3"
    scene bg render2338 with dissolve
    pause 0.3 


    scene bg render2271 with dissolve
    pause 0.3

    scene bg render2272 with dissolve
    pause 0.3

    scene bg render2273 with dissolve
    pause 0.3

    scene bg render2274 with dissolve
    pause 0.3

    scene bg render2275 with dissolve
    pause 0.3

    scene bg render2276 with dissolve
    pause 0.3

    scene bg render2277 with dissolve
    pause 0.3

    scene bg render2278 with dissolve
    pause 0.3

    scene bg render2279 with dissolve
    pause 0.3

    scene bg render2280 with dissolve
    pause 0.3

    scene bg render2281 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/floraphonic-bone-break-2-218511.mp3"
    scene bg render2287 with dissolve
    pause

    scene bg render2282 with dissolve
    Lucy "Asshole"

    scene bg render2283 with dissolve
    pause

    scene bg render2284 with dissolve
    pause
    Rim ""
    scene bg render2285 with dissolve
    Elen "Abso-"

    scene bg render2286 with dissolve
    Elen "Girl?"


    scene bg render2288 with dissolve
    Lucy "Here, take this and try to open that door"

    scene bg render2289 with dissolve
    Lucy "I'll grab our ticket out of here"

    scene bg render2290 with dissolve
    pause

    
    scene bg render2340 with dissolve
    pause

    scene bg render2341 with dissolve
    pause
    Lucy "Found it"

    scene bg render2342 with dissolve
    pause

    scene bg render2343 with dissolve
    pause

    scene bg render2344 with dissolve
    pause

    scene bg render2345 with dissolve
    Lucy "* Shit! *"

    scene bg render2346 with dissolve
    pause

    scene bg render2347 with dissolve
    Yuri "* Where is Jona? *"

    scene bg render2348 with dissolve
    Unknown "Hey little kitty"

    scene bg render2349 with dissolve
    Unknown "How did you scape?"

    scene bg render2350 with dissolve
    Unknown "Were you in a rush to feel a real man?"
    Unknown "Don't be shy baby"
    scene bg render2351 with dissolve
    Lucy "HA! HA! HA!"

    scene bg render2352 with dissolve
    pause
    Lucy "FINALLY"

    scene bg render2353 with dissolve
    pause

    scene bg render2354 with dissolve
    Unknown "Kitty c-"
    play sound "audio/0.5 soundtrack/general/mrfriends-pistol-shot-233473.mp3"
    scene bg render2355 with dissolve
    pause

    scene bg render2356 with dissolve
    Yuri "Kill that bitch"
    scene bg render2357 with dissolve
    Lucy "One down"
    pause
    play sound "audio/0.5 soundtrack/general/freesound_community-m4-assault-rifle-long-burst-102682.mp3"

    scene bg render2358 with dissolve
    pause

    scene bg render2359 with dissolve
    pause

    scene bg render2360 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/lordsonny-long-whoosh-194554.mp3"
    scene bg render2361 with dissolve
    pause

    scene bg render2362 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/freesound_community-m4-assault-rifle-long-burst-102682.mp3"

    scene bg render2363 with dissolve
    pause

    scene bg render2364 with dissolve
    Lucy "Fuck! Think. Think."
    play sound "audio/0.5 soundtrack/general/daviddumaisaudio-sword-slash-and-swing-185432.mp3"
    scene bg render2365 with dissolve
    pause 0.2
    Lucy "What the-"

    scene bg render2366 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/dragon-studio-violent-sword-slice-393839 (1).mp3"
    stop music
    scene black
    pause
    scene bg render2367 with dissolve
    pause

    scene bg render2368 with dissolve
    pause

    scene bg render2369 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/wings_of_freedom-bomb-explosion-469038.mp3"
    scene bg render2370 with dissolve
    pause

    scene bg render2404 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/distantFire.mp3"
    Sam "..."

    scene bg render2405 with dissolve
    Sam "Go back inside."

    scene bg render2406 with dissolve
    pause
    Sam "Something is up."

    scene bg 2min with dissolve
    pause

    play sound "audio/0.5 soundtrack/general/WAR DRUM.mp3" loop

    scene bg render2259 with dissolve
    pause
    player_name "*Cough* *Cough*"

    scene bg render2260 with dissolve
    pause

    scene bg render2261 with dissolve
    Jonathan "Come on"
    pause

    scene bg render2262 with dissolve
    Jonathan "Get up, it wasn't even all that"
    Jonathan "I know you can do better."
    scene bg render2264 with dissolve
    pause


    scene bg render2265 with dissolve
    Jonathan "There we go"

    scene bg render2266 with dissolve
    pause

    scene bg render2267 with dissolve
    pause
    stop sound
    scene bg render2268 with dissolve
    pause

    play music "audio/AJ.mp3" noloop
    scene bg render2291  
    pause 0.5
    play sound "audio/0.5 soundtrack/general/dodge.mp3"
    scene bg render2292
    pause 0.5

    scene bg render2293 
    pause 0.5
    play sound "audio/0.5 soundtrack/general/dodge.mp3"
    scene bg render2294 
    pause 0.5
    play sound "audio/0.5 soundtrack/general/dodge.mp3"
    scene bg render2295 with dissolve
    pause 0.5
    play sound "audio/0.5 soundtrack/general/dragon-studio-hard-punch-sfx-515251 (1).mp3"
    scene bg render2296
    pause 0.1

    scene bg render2297 with dissolve
    pause

   
    play sound "audio/0.5 soundtrack/general/dodge.mp3"
    scene bg render2642 with dissolve
    pause

    play sound "audio/freesound_community-block-6839.mp3"
    scene bg render2643 with dissolve
    pause

    play sound "audio/0.5 soundtrack/general/dragon-studio-hard-punch-sfx-515251 (1).mp3"
    scene bg render2644 with dissolve
    pause

    scene bg render2645 with dissolve
    pause
    play sound "audio/freesound_community-block-6839.mp3"
    scene bg render2646 with dissolve
    pause

    scene bg render2647 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/dodge.mp3"

    scene bg render2648 with dissolve
    pause

    scene bg render2649 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/universfield-punch-impact-hit-567196.mp3"
    scene bg render2650 with dissolve
    pause 0.3

    scene bg render2651 with dissolve
    pause

    scene bg render2652 with dissolve
    pause

    scene bg render2653 with dissolve
    pause
    play sound "audio/freesound_community-block-6839.mp3"
    scene bg render2654 with dissolve
    pause

    scene bg render2655 with dissolve
    pause

    scene bg render2656 with dissolve
    pause

    scene bg render2657 with dissolve
    pause

    scene bg render2658 with dissolve
    pause

    scene bg render2659 with dissolve
    pause

    scene bg render2660 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/dodge.mp3"

    scene bg render2661 with dissolve
    pause

    scene bg render2662 with dissolve
    pause
  
    scene bg render2298 with dissolve
    pause 0.3


    play sound "audio/0.5 soundtrack/general/Kick.mp3"
    scene bg render2299 with dissolve
    pause

    scene bg render2300 with dissolve
    pause

    scene bg render2301 with dissolve
    pause

    scene bg render2302 with dissolve
    pause

    scene bg render2303 with dissolve
    pause

    scene bg render2304 with dissolve
    pause

    scene bg render2305 with dissolve
    pause

    scene bg render2306 with dissolve
    pause

    scene bg render2307 with dissolve
    pause

    scene bg render2308 with dissolve
    player_name "Muay Thai?"

    scene bg render2309 with dissolve
    pause

    scene bg render2310 with dissolve
    pause 0.2

    scene bg render2311 with dissolve
    pause 0.2
    play sound "audio/0.5 soundtrack/general/Kick.mp3"

    scene bg render2312 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/Kick.mp3"

    scene bg render2313 with dissolve
    pause

    scene bg render2314 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/thud.mp3"
    scene bg render2315 with dissolve
    pause 0.2
    play sound "audio/0.5 soundtrack/general/thud.mp3"

    scene bg render2316 with dissolve
    pause 0.2
    play sound "audio/0.5 soundtrack/general/thud.mp3"
    scene bg render2317 with dissolve
    pause 0.3

    scene black 
    pause

    scene bg render2318 with dissolve
    pause

    scene bg render2319 with dissolve
    pause

    scene bg render2320 with dissolve
    pause

    scene bg render2321 with dissolve
    pause
    player_name "Come on. Get up"
    play sound "audio/0.5 soundtrack/general/tightning.mp3"
    scene bg render2322 with dissolve
    pause

    scene bg render2323 with dissolve
    pause
    player_name "You can do better."
    scene bg render2324 with dissolve
    pause

    play sound "audio/0.5 soundtrack/general/dodge.mp3"
    scene bg render2325 with dissolve
    pause
    scene bg render2326 with dissolve
    pause

    scene bg render2327 with dissolve
    Jonathan "AAAAAAh!"

    scene bg render2328 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/dragon-studio-hard-punch-sfx-515251 (1).mp3"
    scene bg render2329 with dissolve
    pause

    scene bg render2330 with dissolve
    pause

    scene bg render2331 with dissolve
    pause

    play sound "audio/dragon-studio-car-crash-sound-effect-376874.mp3"
    scene bg render2332 with dissolve
    pause

    scene bg render2333 with dissolve
    pause

    scene bg render2334 with dissolve
    pause

    scene bg render2335 with dissolve
    pause
    play sound "audio/lordsonny-whoosh-cinematic-161021.mp3"
    scene bg render2337 with dissolve
    pause
    play sound "audio/0.5 soundtrack/general/floraphonic-bone-break-10-218514.mp3"
    scene bg render2336
    pause 0.5

    scene black 
    pause

    scene bg render2663 with dissolve
    pause
    
    scene bg render2664 with dissolve
    player_name "You fought well."


    stop music fadeout 1.0
    scene bg render2371 with fade
    pause
    Rim "She told us to wait here"
    Rim "We tried to open the door but-"
    play sound "audio/0.5 soundtrack/general/dragon-studio-distant-bang-472364.mp3"
    scene bg render2372 with dissolve
    pause
    scene bg render2373 with dissolve
    player_name "Stay here. I'll look for her"

    scene bg render2374 with dissolve
    Rim "I'm coming with you"

    scene bg render2375 with dissolve
    pause
    player_name "We have no time f-"
    play sound "audio/0.5 soundtrack/general/freesound_community-9mm-pistol-shoot-short-reverb-7152.mp3"
    scene bg render2376 with dissolve
    pause 0.5

    scene bg render2377 with dissolve
    pause
    play music "audio/0.5 soundtrack/general/leavingPrison.mp3"
    scene bg render2378 with dissolve
    pause

    scene bg render2379 with dissolve
    Lucy "Let's get the fuck out of here"
    pause

    scene bg render2380 with dissolve
    pause

    scene bg render2381 with dissolve
    pause
    player_name "Clear!"

    scene bg render2382 with dissolve
    pause

    scene bg render2383 with dissolve
    pause
    play sound "audio/0.4/u_68csiaifb5-bulletimpact3-442719.mp3"

    scene bg render2384 with dissolve
    pause

    scene bg render2385 with dissolve
    pause

    scene bg render2386 with dissolve
    pause

    scene bg render2387 with dissolve
    pause

    scene bg render2388 with dissolve
    player_name "Careful"

    scene bg render2389 with dissolve
    pause
    Unknown "What the hell is going on?"
    Unknown "Help! We are under atack!"

    scene bg render2390 with dissolve
    pause
    Unknown "I just saw Yuri going in there"

    scene bg render2391 with dissolve
    pause
    Unknown "Shit! Let's go"

    scene bg render2392 with dissolve
    pause
    Lucy "What now?"
    player_name "We have to pick up a friend."
    play sound "audio/car.mp3" loop
    scene bg render2393 with fade
    pause

    scene bg render2394 with dissolve
    pause

    scene bg render2395 with dissolve
    pause

    scene bg render2396 with dissolve
    pause

    scene bg render2397 with dissolve
    pause

    scene bg render2398 with dissolve
    pause

    scene bg render2399 with dissolve
    pause

    scene bg render2400 with dissolve
    pause

    scene bg render2401 with dissolve
    pause
    stop sound
    

    jump afterfight

    label jonathanLives:
    scene bg render2407 with dissolve
    pause


    scene bg render2408 with dissolve
    pause

    scene bg render2409 with dissolve
    Jonathan "Hey man, wasup?"

    scene bg render2410 with dissolve
    player_name "Mitcher asked me to bring her things. He said he knows who she is and wants information or something like that—honestly, I didn't understand."

    scene bg render2411 with dissolve
    player_name "So why are you wasting your time, lil bro? Go get her shit"

    scene bg render2412 with dissolve
    player_name "Okay, you are cool man"
    Jonathan "That's what everyone says."
    scene bg render2413 with dissolve
    pause
    play music "audio/0.5 soundtrack/general/leavingPrison.mp3"
    scene bg render2414 with dissolve
    pause
    player_name "I got it."
    
    scene bg render2380 with dissolve
    pause

    scene bg render2381 with dissolve
    pause
    player_name "Clear!"

    scene bg render2382 with dissolve
    pause

    scene bg render2383 with dissolve
    pause
    play sound "audio/0.4/u_68csiaifb5-bulletimpact3-442719.mp3"

    scene bg render2384 with dissolve
    pause

    scene bg render2385 with dissolve
    pause

    scene bg render2386 with dissolve
    pause

    scene bg render2387 with dissolve
    pause

    scene bg render2388 with dissolve
    player_name "Careful"

    scene bg render2389 with dissolve
    pause
    scene bg render2390 with dissolve
    pause
    scene bg render2391 with dissolve
    pause
    scene bg render2392 with dissolve
    pause
    Lucy "What now?"
    player_name "We have to pick up a friend."

    scene bg render2393 with fade
    pause

    scene bg render2394 with dissolve
    pause

    scene bg render2395 with dissolve
    pause

    scene bg render2396 with dissolve
    pause

    scene bg render2397 with dissolve
    pause

    scene bg render2398 with dissolve
    pause

    scene bg render2399 with dissolve
    pause

    scene bg render2400 with dissolve
    pause

    scene bg render2401 with dissolve
    pause

    label afterfight:

    scene bg render2418 with dissolve
    pause
    player_name "Let's leave the car here and walk. It's about a 20-minute walk, but it's necessary."
    scene bg render2419 with dissolve
    Lucy "Smart."

    scene bg render2420 with dissolve
    pause

    scene bg render2421 with dissolve
    pause

    scene bg render2422 with dissolve
    pause

    scene bg render2423 with dissolve
    Alice "Emily!"

    scene bg render2424 with dissolve
    Alice "Look."
    Emily "He's back."

    scene bg render2425 with fade
    pause
    player_name "Did you misse-"

    scene bg render2426 with dissolve
    pause

    scene bg render2427 with dissolve
    pause
    Lucy "Is there room for more?"

    scene bg render2428 with dissolve
    Lucy "Call me Lucy"
    pause

    scene bg render2429 with dissolve
    pause

    scene bg render2430 with dissolve
    Anne "You went through the same thing I went through."
    pause

    scene bg render2431 with dissolve
    Anne "You know how intelligent Tom was, and in the same way, we know how capable [p] is."

    scene bg render2432 with dissolve
    pause
    Anne "Trust me, he'll be back soon."

    scene bg render2433 with dissolve
    player_name "How soon is that?"

    scene bg render2434 with dissolve
    pause
    Lucy "So he's the only man in a house full of baddies?"

    scene bg render2435 with dissolve
    player_name "Everything went well."

    scene bg render2436 with dissolve
    player_name " And we have company."

    scene bg render2437 with dissolve
    Lucy "Nice to meet you; you must be the baddie number 1"
    Anne "What?"
    player_name "Just ignore her."
    stop music fadeout 1.5
    scene bg render2438 with dissolve
    pause

    scene bg render2439 with dissolve
    pause

    scene bg render2440 with dissolve
    pause

    scene bg render2441 with dissolve
    pause

    scene bg render2442 with dissolve
    Alice "[p] is back."
    Luna "What? really?"

    scene bg render2443 with dissolve
    Luna "I didn't even hear it."
    Alice "They came back walking"
    Alice "What are you doing?"

    scene bg render2444 with dissolve
    Luna "Just learning how to use this"
    Luna "Relax, the gun isn't loaded."

    scene bg render2445 with dissolve
    Elen "Excuse me, could you point out the restroom?"

    scene bg render2446 with fade
    pause

    scene bg render2447 with dissolve
    pause

    scene bg render2448 with dissolve
    pause

    scene bg render2449 with dissolve
    pause

    scene bg render2450 with dissolve
    pause 0.3

    scene bg render2451 with dissolve
    pause

    scene bg render2452 with dissolve
    pause

    scene bg render2453 with dissolve
    pause

    scene bg render2454 with dissolve
    pause

    scene bg render2455 with dissolve
    Elen "My hair is filthy."

    scene bg render2456 with dissolve
    pause

    scene bg render2457 with dissolve
    pause
    Lucy "Can I talk with for a sec?"

    scene bg render2458 with dissolve
    pause

    scene bg render2459 with dissolve
    player_name "Of course."
    pause

    scene bg render2460 with dissolve
    Lucy "This place is really cute and all... It's surrounded by mountains—hard to find."
    pause
    scene bg render2461 with dissolve
    Lucy "And I'm so grateful that you helped me, I really mean it."

    scene bg render2462 with dissolve
    Lucy "But they’re going to find us, and it won’t take long."
    Lucy "I know that..."

    scene bg render2463 with dissolve
    pause

    scene bg render2464 with dissolve
    Lucy "I thought it was impossible for them to find me, that I had the perfect hiding place. And that illusion cost the lives of everyone who was with me."
    Lucy "I’m the only one left."
    scene bg render2465 with dissolve
    Lucy "There’s a guy—I think they call him Sam. I fought him and got humiliated. He wiped the floor with me and let me live because he said he liked my spirit."

    scene bg render2466 with dissolve
    Lucy "So I think there's only one question left for you."
    Lucy "What are you going to do?"

    scene bg render2467 with dissolve
    player_name "That's an easy one."
    play music "audio/0.5 soundtrack/general/Audiomachine   Earth Shaker Drums - Stravaganti NUOVI (youtube).mp3"
    scene bg render2468 with dissolve
    player_name "Slaughter them before they can even think."

    scene bg render2469 with dissolve
    Lucy "And that is the right answer"
    Mei "I'm in."
    scene bg render2470 with dissolve
    pause
    scene bg render2471 with dissolve
    pause

    label gravesdialogue:
        if AlanDead:
            jump skipgraves
 
    scene bg render2472 with fade
    pause
    Graves "It was a quick fight."

    scene bg render2473 with dissolve
    Graves "He was easily overpowered."
    Williams "Meh, he was an average fighter. I don't even know why you left him guarding the prison."
    Graves "I could trust him not to get someone pregnant without permission."
    scene bg render2474 with dissolve
    pause

    scene bg render2475 with dissolve
    Graves "Do we have the location?"

    scene bg render2476 with dissolve
    Williams "Sir, that's the easy part."

    scene bg render2477 with dissolve
    Williams "What pisses me off is knowing someone had the balls to come to our house, trash the place and get out alive."

    scene bg render2478 with dissolve
    pause

    scene bg render2479 with dissolve
    Sam "I know where they are."

    scene bg render2480 with dissolve
    Graves "Very well. We have a target."
    
    label skipgraves:
    stop music fadeout 0.5
    scene bg render2481 with fade
    pause
    player_name "Mei and Rim used to sleep here, but now they’re going to sleep closer to us."

    scene bg render2482 with dissolve
    player_name "I was the one who asked for that; since they’re going through a tough time, it’s good to be surrounded by people."

    scene bg render2483 with dissolve
    Lucy "There is no fucking way I’m sleeping here."

    scene bg render2484 with dissolve
    Lucy "This room is in a terrible strategic location. It has a glass door that makes me an easy target, I can't see if any enemies are approaching, and it's far from the bathroom and the rest of the group and don't even get me started on..."

    scene bg render2485 with dissolve
    player_name "Okay. I get it"

    scene bg render2486 with dissolve
    pause
    scene bg render2487 with dissolve
    pause

    scene bg render2488 with dissolve
    Lucy "How did you know the prison was connected to that watchtower?"

    scene bg render2489 with dissolve
    player_name "Mei watched them for a few days. She saw the same guard enter the prison and appear in the tower. It’s called reasoning."
    pause

    scene bg render2490 with dissolve
    Lucy "HA HA! So funny"

    scene bg render2491 with dissolve
    pause

    scene bg render2492 with dissolve
    player_name "Ladies first"

    scene bg render2493 with dissolve
    Lucy "You better hope I don't get caught in a trap"

    scene bg render2494 with dissolve
    pause
    Lucy "Wow!"

    scene bg render2495 with dissolve
    pause
    Lucy "I... Loved it"

    scene bg render2496 with dissolve
    Lucy "Damn. I can see everything"

    scene bg render2497 with dissolve
    player_name "I told you."

    scene bg render2498 with dissolve
    Lucy "Thank you [p]"

    scene bg render2499 with dissolve
    pause
    scene bg render2500 with dissolve
    Lucy "I have just one more question."

    scene bg render2501 with dissolve
    pause
    Lucy "How many of these girls are you sleeping with?"

    scene bg render2502 with dissolve
    player_name "Wha-How-you-I"
    Lucy "HAHHAHA! I knew it"

    scene bg render2503 with dissolve
    pause
    scene bg render2504 with dissolve
    pause

    scene bg render2505 with dissolve
    pause

    scene bg render2506 with dissolve
    pause

    scene bg render2507 with dissolve
    pause

    scene bg render2508 with dissolve
    pause

    scene bg render2509 with dissolve
    pause

    scene bg render2510 with dissolve
    pause

    scene bg render2511 with dissolve
    pause

    scene bg render2512 with dissolve
    pause

    scene bg render2513 with dissolve
    pause

    scene bg render2514 with dissolve
    pause
    Rim "I loved this room"

    scene bg render2515 with dissolve
    Mei "Me too."

    scene bg render2516 with dissolve
    Rim "Yeah, I know why you like it"
    pause
    scene bg render2517 with dissolve
    Mei "What are talking about?"
    pause
    scene bg render2518 with dissolve
    Rim "You are happy cuz you get to be closer to your boyfriend"
    pause
    scene bg render2519 with dissolve
    Mei "Will you stop it?"

    scene bg render2520 with dissolve
    pause
    Mei "He's cool. That's all"
    scene bg render2521 with dissolve
    Mei "Nothing more, nothing less"
    play sound "audio/0.4/koiroylers-door-opening-356028.mp3"
    scene bg render2522 with dissolve
    player_name "Hey girls"

    scene bg render2523 with dissolve
    player_name "* Damn *"
    menu:
        "Close your eyes":
            jump closedeyes

        "Look":
            jump MeiShy



    label closedeyes:
    scene bg render2525 with dissolve
    pause
    player_name "Sorry, I didn't know."
    Rim "That's okay. Did something happened?"
    player_name "No. I just wanted to say goodnight"
    Mei "Night [p]"
    jump AnneLingerieNightTIme

    label MeiShy:
    scene bg render2524 with dissolve
    player_name "I just wanted to wish you all a good night. And I'm glad I came."

    scene bg render2526 with dissolve
    pause

    scene bg render2527 with dissolve
    Rim "Hehehe! I bet Mei is glad too."

    scene bg render2528 with dissolve
    Mei "Thank you- I mean- goodnight."

    scene bg render2529 with dissolve
    Rim "Heheheh"
    pause

    label AnneLingerieNightTIme:
    scene bg render2530 with fade
    pause

    scene bg render2531 with dissolve
    pause
    play music "audio/0.5 soundtrack/sex/Anne And Emi song.mp3"
    scene bg render2532 with dissolve
    pause

    scene bg render2533 with dissolve
    pause

    scene bg render2534 with dissolve
    pause

    scene bg render2535 with dissolve
    pause

    scene bg render2536 with dissolve
    pause

    scene bg render2537 with dissolve
    pause

    scene bg render2538 with dissolve
    pause
    
    scene bg render2539 with dissolve
    player_name "GOD! I won in the wife lottery for sure."
    pause

    scene bg render2540 with dissolve
    Anne "Did you? Maybe I did all this just to punish you."
    pause

    scene bg render2541 with dissolve
    player_name "Punish me? You probably want to have sex even more than I do."

    scene bg render2542 with dissolve
    pause
    Anne "Don't compare my desire to your boyish horniness."
    player_name "*mwah*"

    scene bg render2543 with dissolve
    player_name "*Sniff*"
    pause

    scene bg render2544 with dissolve
    Anne "Hmmmf"
    pause

    scene bg render2545 with dissolve
    Anne "Your big cock is pressed between my tighs"
    pause

    scene bg render2546 with dissolve
    Anne "Hmf hmm"

    scene bg render2547 with dissolve
    pause

    scene bg render2548 with dissolve
    pause

    scene bg render2549 with dissolve
    Anne "Take it out"

    scene bg render2550 with dissolve
    pause

    scene bg render2551 with dissolve
    Anne "Aren't you going to tear it?"
    pause

    scene bg render2552 with dissolve
    player_name "I want to see you wear that again."

    scene bg render2553 with dissolve
    pause
    Anne "I'm wet enough baby. "

    scene bg render2554 with dissolve
    Anne "God, I love this cock."
    pause

    play sound "audio/0.5 soundtrack/sex/AnneMoaningLingerie.mp3" loop
    image AnneAndAdamNightTime = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/10001-0120-efsiyq.webm", loop=True)
    show AnneAndAdamNightTime with dissolve
    pause
    Anne "Ah... when you put it in slowly like that, I can feel everything."
    Anne "I can even feel your veins sometimes."
    player_name "I like it slowly too baby"
    player_name "But nothing beats your moaning when I start thrusting hard-"
    stop sound
    play sound "audio/0.5 soundtrack/sex/MoaningSound3.mp3" loop
    image AnneAndAdamNightTime2 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/20001-0080-mh5epx.webm", loop=True)
    show AnneAndAdamNightTime2 with dissolve
    pause
    Anne "Ahhhng Ahhnnn yes."
    Anne "I love it. I love your big cock so much."
    Anne "We're going to fuck until dawn today. Hhhhmmm yeah"
    Anne "I want to fall asleep with your cock deep inside me."
    player_name "You've never been this wet baby"
    pause

    scene bg render2555 with dissolve
    Anne "Oh GOD, I'm cumming! Cummmhh Aahhn"
    pause
    stop sound
    scene bg render2556 with dissolve
    Anne "Ah! I came so hard"
    pause

    scene bg render2557 with dissolve
    player_name "* Hm?* "
    player_name "* Emi is watching. *"

    menu:
        "Let her watch":
            $ HadThreesomeWithAnneEmily = True
            jump ThreesomeEmiAnne

        "Send her away":
            jump SoloAnne


    label ThreesomeEmiAnne:

    scene bg render2559 with dissolve
    player_name "*She is so cute *"
    pause

    scene bg render2560 with dissolve
    Anne "Don't stop I want more"
    pause

    scene bg render2561 with dissolve
    pause
    Emily "* They seem to be having fun. *"

    scene bg render2562 with dissolve
    Emily "* I even put this on for him *"
    pause

    scene bg render2563 with dissolve
    Emily "* I wish I could- *"
    Emily "* You know what... *"

    scene bg render2564 with dissolve
    Emily "* My Dad always told me to fight for what I want. *"
    Emily "* Fuck it *"
    stop sound
    scene bg render2565 with dissolve
    Anne "Emily? Sweetie what are you doing?"
    pause

    scene bg render2566 with dissolve
    Anne "Is that my lingerie?"

    scene bg render2567 with dissolve
    Anne "What? You need to leave."
    pause

    scene bg render2568 with dissolve
    Anne "..."

    scene bg render2569 with dissolve
    pause
    player_name "* Shit. She went all in *"

    scene bg render2570 with dissolve
    Anne "Honey? Are you okay?"

    scene bg render2571 with dissolve
    pause

    scene bg render2572 with dissolve
    Anne "Hmmf"

    scene bg render2573 with dissolve
    Anne "* What the fuck? *"
    pause
 
    scene bg render2574 with dissolve
    Anne "* Is she crazy? *"
    Anne "Wait-"

    scene bg render2575 with dissolve
    Anne "* Why is [p] still fucking me? *"

    play sound "audio/0.5 soundtrack/sex/MoaningSound1.mp3" loop
    scene bg render2576 with dissolve
    Anne "He won't stop"
    Anne "* Why is this so good? *"
    pause

    image ThreesomeEmiAnneAdam = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/30001-0080-4ws1us.webm", loop=True)
    show ThreesomeEmiAnneAdam with dissolve
    pause
    Anne "Hmm Hmmmm Hmmf"
    player_name "* Holy Shit this is so fucking hot*"
    player_name "* I've never felt this turned on. FUCK *"
    Anne "* Ahng Aahng [p], I need a break. This is too much *"
    Anne "* GOD! I just came, take it easy baby *"
    stop sound
    scene bg render2577 with dissolve
    pause
    player_name "* I'm in heaven! *"

    scene bg render2578 with dissolve
    pause

    scene bg render2579 with dissolve
    pause

    scene bg render2580 with dissolve
    pause

    scene bg render2581 with dissolve
    pause

    scene bg render2582 with dissolve
    pause
    player_name "* This girl... *"
    pause

    scene bg render2583 with dissolve
    Anne "Ah! Thank you for stopping. That was way too much"
    Anne "You two are going to kill me"
    scene bg render2584 with dissolve
    pause
    Anne "Baby Emi, you can't just do that"
    Anne "Even though I kind of liked it"

    scene bg render2585 with dissolve
    Emily "Ahn!"
    Anne "What's wrong?"
    pause

    scene bg render2586 with dissolve
    Emily "Oouhh Yeah. I missed this"
    pause

    scene bg render2587 with dissolve
    Anne "No way. Is he..."
    play sound "audio/0.5 soundtrack/sex/Sound4Standing.mp3" loop
    image ThreesomeEmiAnneAdam2 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/40001-0080-sbvhl4.webm", loop=True)
    show ThreesomeEmiAnneAdam2 with dissolve
    pause
    Emily "Oh Yes. I would fucking die for this dick"
    Emily "Fuck me good. Just like that"
    Anne "Emi, You are being too loud."
    player_name "* I'm glad that's what she is worried about *"
    player_name "* Uhmn her pussy is so tight *"
    stop sound
    scene bg render2588 with dissolve
    Emily "Oh GOD!"
    player_name "Emily, don't leave her out"
    pause
    scene bg render2589 with dissolve
    Emily "Okay."
    Anne "Uhh Wait-"
    pause

    scene bg render2590 with dissolve
    pause 0.5

    scene bg render2591 with dissolve
    Anne "Uughhh!"

    scene bg render2592 with dissolve
    Anne "Aahhhnnnnnngg ❤️"
    play sound "audio/0.5 soundtrack/sex/Sound4Standing.mp3" loop

    
    image ThreesomeEmiAnneAdam4 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/extrathree0001-0080-bmvqc6.webm", loop=True)
    show ThreesomeEmiAnneAdam4 with dissolve
    pause
    Emily "Ouhhnnn So big"
    Anne " *This is so wrong* "
    Anne "Why is this turning me on so much?"
    player_name " *Fuck, it's actually hard to pull my dick out—she's squeezing me so tight. *"
    image ThreesomeEmiAnneAdam3 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/dooveremi0001-0080-mm08wa.webm", loop=True)
    show ThreesomeEmiAnneAdam3 with dissolve
    pause
    Emily "Oh God, pound me harder please"
    Anne "Ahnng I think I-Fuuuu- I'm going"
    Anne "I- Ahhhhhnng"
    stop sound
    
    
    scene bg render2594 with dissolve
    pause 0.5
    play sound "audio/0.5 soundtrack/sex/AnneCuming.mp3"
    scene bg render2595 with dissolve
    pause
    scene bg render2596 with dissolve
    pause

    scene bg render2597 with dissolve
    Anne "I came so hard!"
    Anne "You're in big trouble Emily."
    pause

    scene bg render2598 with fade
    pause

    scene bg render2599 with dissolve
    pause

    scene bg render2600 with dissolve
    pause
    play sound "audio/0.5 soundtrack/sex/EmiGettingFilled..mp3" loop
    image ThreesomeEmiAnneAdamLast = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/6emi0001-0080-22mjt0.webm", loop=True)
    show ThreesomeEmiAnneAdamLast with dissolve
    pause
    Anne "This is going to be your punishment."
    Anne "Honey, you decide what to do."
    Anne "Are you going to cover her face or breed this little slut"
    Emily "Ahn Ahng Ahhnn"
    pause
    menu:
        "Breed Emily (Pregnancy)":
            $ EmilyIsPregnant = True
            jump EmilyIsPregnant

        "Paint her body":
            jump AnneEmmiKiss

    stop sound
    label EmilyIsPregnant:
    play sound "audio/0.5 soundtrack/sex/creampie.mp3"
    scene bg render2601 with dissolve
    Emily "Huuugh"
    pause

    scene bg render2602 with dissolve
    Anne "My dear, you really filled her up to the brim."
    Anne "This is so hot"
    pause

    scene bg render2603 with dissolve
    Emily "Ahhgn"
    pause
    scene bg render2604 with dissolve
    pause 
    scene bg render2635 with fade
    pause
    Emily "Can we go again?"
    jump endVersion05

    label AnneEmmiKiss:
    stop sound
    scene bg render2605 with dissolve
    pause

    scene bg render2606 with dissolve
    pause 0.4

    scene bg render2607 with dissolve
    pause

    scene bg render2608 with dissolve
    pause

    scene bg render2609 with fade
    pause
    Anne "Oh my God."
    Anne "How can you look so cute even covered in cum?"

    scene bg render2610 with dissolve
    pause

    scene bg render2611 with dissolve
    pause
    scene bg render2612 with fade
    pause

    scene bg render2613 with dissolve
    pause
    player_name "You two are turning me on again."

    scene bg render2614 with dissolve
    pause
    player_name "Who wants round two?"
    scene bg render2635 with fade
    pause
    Emily "I do!"
    jump endVersion05

    label SoloAnne:
    scene bg render2558 with dissolve
    player_name "* Sorry baby, I want to have some time alone *"
    pause

    scene bg render2615 with dissolve
    pause

    scene bg render2616 with dissolve
    pause

  
    scene bg render2618 with dissolve
    pause
    image AnneSolo = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/annesolo20001-0080-6z8ctt.webm", loop=True)
    show AnneSolo with dissolve
    pause
    Anne "Ahng! Too deep baby."
    player_name "The way you're squeezing feels so good."
    image AnneSolo2 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/annesolo2pov20001-0080-0uwu3v.webm", loop=True)
    show AnneSolo2 with dissolve
    pause
  
    scene bg render2619 with dissolve
    Anne "Baby, can we do that one?"
    Anne "I wanna feel you deeper"
    scene bg render2620 with dissolve
    Anne "Please."
  
  
    scene bg render2622 with dissolve
    pause
    Anne "Oh I love it."
  
    scene bg render2623 with dissolve
    Anne "You look so strong"
    pause
    Anne "You are so fucking deep"
  
    scene bg render2624 with dissolve
    pause
    scene bg render2625 with dissolve
    pause
    Anne "I'll never get tired off this"
    play sound "audio/slowed.mp3"
    image AnneSoloStanding = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/standinglast0001-0080-8occoi.webm", loop=True)
    show AnneSoloStanding with dissolve
    pause
    Anne "OH MY Fucking Gohhhnnng"

    image AnneSoloStanding2 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/standinglast20001-0080-c5mumu.webm", loop=True)
    show AnneSoloStanding2 with dissolve
    pause
    player_name "The way you are gripping my dick... I'm going to cum"
    Anne "Where do you want it?"
    player_name "Fuck"
    stop sound
    play sound "audio/0.5 soundtrack/sex/insideAnne.mp3" loop
    image AnneSoloStanding3 = Movie(play="images/animation/0.5 ALL ANIMATIONS/ANNE+EMI/webm/extra0000-0059-jiytvt.webm", loop=True)
    show AnneSoloStanding3 with dissolve
    pause
    Anne "Ooouuuhhnn"
    Anne "Pleeeease, cuuum inside meee."
    Anne "I need to feel it"
    player_name "Ugh!"
 
    menu:
        "Breed your wife (Pregnancy)":
            $ AnneIsPregnant = True
            jump AnnePregnant

        "Let her drink it":
            jump AnneDrinkingCum


    label AnnePregnant:
    stop sound
    play sound "audio/0.5 soundtrack/sex/creampie.mp3"

    scene bg render2626 with dissolve
    pause
    Anne "Hmm SO Good. You really came a bucketload this time."
    scene bg render2627 with dissolve
    pause
    player_name "I couldn't resist filling you with cum."
    scene bg render2628 with dissolve
    pause
    Anne "Good! I love being filled"
    scene bg render2635 with dissolve
    pause
    player_name "Should we go again?"

    jump endVersion05

    label AnneDrinkingCum:
    stop sound
    scene bg render2629 with dissolve
    pause
    player_name "Hhmmmm Take it baby"

    scene bg render2630 with dissolve
    pause 0.5

    scene bg render2631 with dissolve
    pause

    scene bg render2632 with dissolve
    pause 
    play sound "audio/swallowIt.mp3"
    scene bg render2633 with dissolve
    Anne "*Gulp*"
    pause


    scene bg render2634 with dissolve
    pause
    player_name "Good girl!"

    scene bg render2635 with fade
    pause
    player_name "Are you up for more?"




    
    label endVersion05:
    

    scene bg render2636 with dissolve
    pause

    scene bg render2637 with dissolve
    pause

    scene bg render2638 with dissolve
    pause

    play sound "audio/Demon.mp3"
    scene bg render2639 with dissolve
    pause
    scene bg render2640 with dissolve
    pause
    scene bg render2641 with dissolve
    pause
    Woman "Bring it on!"
    pause
    
 
    scene bg ENDOF05 with dissolve
    pause

    scene black
    pause
    scene bg warnin with dissolve
    pause



    return

    
label menor_de_idade:
    "Sorry, you can't play it yet."
    $ renpy.quit()
